## Optimal short-time measurements for Hamiltonian learning

Assaf Zubida, Elad Yitzhaki, Netanel H. Lindner, and Eyal Bairey

Physics Department, Technion, 3200003, Haifa, Israel

**Characterizing noisy quantum devices requires methods for learning the underlying quantum Hamiltonian which governs their dynamics. Often, such methods compare measurements to simulations of candidate Hamiltonians, a task which requires exponential computational complexity. Here, we propose efficient measurement schemes based on shorttime dynamics which circumvent this exponential difficulty. We provide estimates for the optimal measurement schedule and reconstruction error, and verify these estimates numerically. We demonstrate that the reconstruction requires a system-size independent number of experimental shots, and identify a minimal set of state preparations and measurements which yields optimal accuracy for learning short-ranged Hamiltonians. Finally, we show how grouping of commuting observables and use of Hamiltonian symmetries improve the accuracy of the Hamiltonian reconstruction.**

**Introduction.** Recovering the unknown Hamiltonian of a quantum system is becoming an increasingly important task for modelling quantum materials [\[1,](#page-5-0) [2\]](#page-5-1), characterizing quantum states [\[3–](#page-5-2)[9\]](#page-5-3) and engineering quantum devices [\[10](#page-5-4)[–13\]](#page-6-0). Whereas benchmarking protocols can extract the average error rates of quantum devices [\[14\]](#page-6-1), Hamiltonian learning provides a detailed characterization of their real-time dynamics, allowing to identify physical sources of errors [\[15](#page-6-2)[–18\]](#page-6-3).

Many Hamiltonian learning methods are based on measurements of time-dependent observables in quantum states evolved over time [\[19–](#page-6-4)[25\]](#page-6-5). However, as time progresses, the dynamics of many-body Hamiltonians become exponentially complex, posing a computational challenge when attempting to find the Hamiltonian which matches the observed behaviour. To deal with this exponential complexity, some approaches assume partial control of the quantum system to be characterized [\[26](#page-6-6)[–29\]](#page-6-7), or employ an additional trusted quantum simulator [\[30–](#page-6-8)[34\]](#page-7-0). Here the complexity refers both to the number of measurements and the classical computation involved in the learning procedure.

A promising approach which avoids this complex-

Eyal Bairey: [baeyal@gmail.com](mailto:baeyal@gmail.com)

ity learns Hamiltonians from short-time dynamics [\[35,](#page-7-1) [36\]](#page-7-2). This approach learns short-ranged Hamiltonians by preparing various product states, and measuring the time-derivative of different observables [\[36\]](#page-7-2). The short-time dynamics are linear in the Hamiltonian parameters, allowing a computationally-efficient reconstruction. The rapid experimental preparation of product states provides an advantage over approaches which learn the dynamics from their steady states [\[37–](#page-7-3)[47\]](#page-7-4).

Here we propose optimized measurement protocols for learning short-ranged Hamiltonians from shorttime dynamics. We analyze the reconstruction error in a protocol that prepares random product states and measures in random local bases, as in recent randomized measurement schemes [\[47](#page-7-4)[–50\]](#page-7-5). We then develop a derandomized protocol that guarantees the same reconstruction accuracy with a fixed set of initial states and measurements. For a given state, the measurements of this protocol characterize all geometricallylocal reduced density matrices using a fixed set of measurement bases, adapting overlapping tomography methods [\[51](#page-7-6)[–53\]](#page-8-0) to the special case of lattices. Our analysis shows that the total number of measurements required to recover a short-ranged Hamiltonian to a fixed accuracy is in fact system-size independent. Importantly, it provides an accurate numerical estimate for the optimal measurement time based on a rough prior guess of the Hamiltonian.

**Problem setting.** The goal of the scheme we analyze is to recover short-ranged Hamiltonians from their short-time dynamics [\[36\]](#page-7-2). We say that a closed quantum system on a lattice is governed by a *k*-ranged Hamiltonian if each term in the Hamiltonian is contained in a cube of side length *k*. The procedure for learning a *k*-ranged Hamiltonian *H* consists of (i) initializing the system in different product states, (ii) evolving the initial states for a short-time under *H*, and (iii) measuring the evolved states in various bases. Our goal is to reconstruct *H* to a given accuracy using a minimal number of shots *N*, defined as the total number of experiments, from state preparation to measurement. Both the number of shots and the classical computation should scale favourably with the size of the system.

Any *k*-ranged Hamiltonian *H* may be expanded in a basis {*Sj*} for the space of *k*-ranged operators,

$$H = \sum_{j} c_j S_j,\tag{1}$$

such that the Hamiltonian is determined by the coefficients  $c_j$ . The reconstruction of H then boils down to finding the coefficient vector  $\vec{c}$ . For concreteness, we describe the reconstruction algorithm for spin 1/2 systems, where  $S_j$  are products of Paulis acting on contiguous sites. While we describe it for closed systems, the algorithm can also recover the dynamics of a subsystem embedded in a larger system as in Ref. [43], as well as Markovian dissipative dynamics as in Refs. [44, 45].

**Algorithm.** The dynamics of an observable A in an initial state  $|\psi\rangle$  is governed by Ehrenfest's equation,

<span id="page-1-0"></span>
$$\partial_t \langle A \rangle_{\psi} = i \langle [H, A] \rangle_{\psi} = i \sum_j c_j \langle [S_j, A] \rangle_{\psi},$$
 (2)

where  $\langle A \rangle_{\psi} = \langle \psi | A | \psi \rangle$ . For a known initial state  $|\psi\rangle$  at t = 0, Eq. (2) yields an equation for the Hamiltonian coefficients  $c_j$ . We can get a set of equations using different pairs of initial states  $\{|\psi_{\alpha}\rangle\}$  and observables  $\{A_{\beta}\}$ . Denoting

<span id="page-1-5"></span>
$$b_{(\alpha,\beta)} \stackrel{\text{def}}{=} \partial_t \langle A_\beta \rangle_{\psi_\alpha}, \quad K_{(\alpha,\beta),j} \stackrel{\text{def}}{=} i \langle [S_j, A_\beta] \rangle_{\psi_\alpha},$$
(3)

where we treat the pair  $(\alpha, \beta)$  as a super index, Eq. (2) becomes

$$b_{(\alpha,\beta)} = \sum_{j} K_{(\alpha,\beta),j} c_j, \tag{4}$$

yielding a set of linear equations

<span id="page-1-1"></span>
$$\vec{b} = K\vec{c}.\tag{5}$$

With sufficiently many initial states and observables, K becomes full rank, and the Hamiltonian  $\vec{c}$  is uniquely given by the solution  $\vec{c} = K^+ \vec{b}$ , where  $K^+ = (K^T K)^{-1} K^T$  is the pseudo inverse of K.

As can be seen in Eq. (5), the matrix K maps Hamiltonians to observable dynamics. The matrix does not depend on the unknown Hamiltonian, and can be calculated in advance given a set of initial states and observables. The observable dynamics  $\vec{b}$  contain information about H, and must be estimated from measurements to recover H. Each entry  $b_{(\alpha,\beta)}$  is a derivative which can be approximated by a forward finite difference method,

<span id="page-1-4"></span>
$$\partial_t \langle A \rangle_{\psi} = \frac{\langle A \rangle_{\psi(\delta t)} - \langle A \rangle_{\psi(0)}}{\delta t} + \mathcal{O}(\delta t). \tag{6}$$

Starting with a known initial state, the only term we need to measure is  $\langle A \rangle_{\psi(\delta t)}$ , which we can evaluate by measuring  $|\psi(\delta t)\rangle$  in a basis compatible with A, as we now explain.

To construct a set of equations, we initialize the system with random Pauli eigenstates and measure by projecting on random Pauli bases. We initialize

<span id="page-1-2"></span>
$$|\psi(0)\rangle = \prod_{i} |\phi_{i}\rangle,$$
 (7)

where each  $\phi_i$  is chosen uniformly from one of the six  $\pm 1$  eigenstates of X,Y and Z. We propagate  $|\psi\rangle$  under H for a time  $\delta t$ . We then measure each site of  $|\psi(\delta t)\rangle$  randomly in one of the 3 Pauli bases X,Y or Z. Namely, we measure  $R^{\dagger} |\psi(\delta t)\rangle$  in the standard (Z) basis, where  $R = \prod_i R_i$  and  $R_i$  are chosen uniformly from  $R_y(\pi/2), R_x(\pi/2)$ , and  $\mathbbm{1}$ . We call each choice of state preparation and measurement basis a SPAM setting, and denote the number of different SPAM settings used for reconstruction by  $N_{spam}$ .

In a system with n sites, each SPAM setting potentially contributes  $2^n - 1$  equations to the set (5), corresponding to  $\partial_t \langle A \rangle_{\psi}$  for commuting Pauli observables A. For instance, consider a measurement in the XZZX basis, which allows to estimate the single-site observables  $\langle X_1 \rangle$ ,  $\langle Z_2 \rangle$  and so on at  $|\psi(\delta t)\rangle$ . Moreover, it allows to estimate the two-site correlators  $\langle X_1 Z_2 \rangle$  as well as higher-order correlators. Fixing a set of  $N_{spam}$  different SPAM settings yields a system (5) with up to  $\approx N_{spam} \cdot 2^n$  equations. In practice, we only estimate observables up to a given range  $k_{\beta}$ , corresponding to  $\approx n \cdot 2^{k_{\beta}-1}$  equations per SPAM setting  $(2^{k_{\beta}-1})$  correlators extending from each site. up to boundary corrections). Collecting a total of Nshots distributed equally among the  $N_{spam}$  settings allows to estimate each of these equations to accuracy

 $\sim \frac{1}{\sqrt{N/N_{spam}}} = \sqrt{\frac{N_{spam}}{N}}.$  This scheme raises a few questions, which we now address:

- 1. What is the optimal measurement time  $\delta t$ ?
- 2. How many experiments are needed to recover a short-ranged Hamiltonian to a given accuracy?
- 3. How does the number of required experiments depend on the system size?
- 4. Which observables should we estimate from each measurement setting?

Estimating the reconstruction error and optimal measurement time. We start by simulating our reconstruction algorithm on spin chains with random 2-ranged interactions, using single-site observables. To this end, we generated Hamiltonians with nearest neighbor Paulis  $S_j$ ,

<span id="page-1-3"></span>
$$H_{random} = \sum_{j} c_{j} S_{j}, \tag{8}$$

where  $S_j \in \{\sigma_i \otimes \sigma_{i+1}\}$  form a basis for all nearest neighbor Paulis, with  $\sigma_i \in \{\mathbb{1}_i, X_i, Y_i, Z_i\}$  a Pauli operator on site i. The coefficients were drawn from a Gaussian distribution with zero mean and unit variance  $c_j \sim G(0,1)$ , setting the time scale for what follows. We initialized each system in  $N_{spam} = 648$  random product states [Eq. (7)], and evolved them for time  $\delta t$ . We measured each evolved state  $N_{spam}$ 

<span id="page-2-1"></span>![](_page_2_Figure_0.jpeg)

Figure 1: Tradeoff between statistical and systematic errors determines optimal measurement time. Left: reconstruction error  $\Delta$  [Eq. (9)] of a random 2-ranged Hamiltonian as a function of the measurement time  $\delta t$  for a fixed measurement budget  $N=10^6$ . While the statistical error in the finite difference method decreases with  $\delta t$ , the systematic error increases with  $\delta t$ , dictating an optimal measurement time. A prior estimate of the reconstruction error (gray line), calculated using a noisy guess of the Hamiltonian [Eq. (15)], predicts the optimal time (blue 'x'). Time is measured in units of the variance of the Hamiltonain couplings [see Eq. (8)]. Right: optimal measurement time  $\delta t^*$  as a function of the number of shots N (dots measured, circles predicted). The dashed line is a fit to the asymptotic scaling  $\delta t^* \sim N^{-\gamma}$  with  $\gamma=1/4$ . The reported values average over 10 different realizations of the statistical estimation error for the observables; errorbars are smaller than the markers.

times in a random measurement basis, and estimated the expectation values of all single-site Paulis  $\langle A_{\beta} \rangle_{\psi(\delta t)}$  compatible with that basis from the measurement results. We then reconstructed the Hamiltonian coefficients  $\vec{c}$  from Eq. (5), approximating the time-derivative of each observable using finite differences [Eq. (6)].

Reconstructing a random Hamiltonian using various evolution times  $\delta t$  and a fixed measurement budget  $N=10^6$ , the reconstruction error was minimized at an optimal measurement time  $\delta t^* \approx 0.02$  (Fig. 1, left). We define the reconstruction error as the relative error of the reconstructed coefficients,

<span id="page-2-0"></span>
$$\Delta \stackrel{\text{def}}{=} \frac{\|\delta \vec{c}\|}{\|\vec{c}\|}.\tag{9}$$

Away from the optimal time, the reconstruction error increased significantly. Repeating the reconstruction with various measurement budgets N, the optimal measurement time  $\delta t^*$  scaled as  $N^{-1/4}$  (Fig. 1, right, dots). Can we predict the optimal measurement time  $\delta t^*$  and its reconstruction error  $\Delta^*$ ?

The accuracy of the Hamiltonian reconstruction from Eq. (5) is determined by the estimation accuracy of  $\vec{b}$ . In any experiment, instead of the exact  $\vec{b}$  we can only obtain a noisy estimate  $\vec{b} + \delta \vec{b}$ . The estimation error  $\delta \vec{b}$  corrupts the recovered coefficients, given by  $\vec{c} + \delta \vec{c} = K^+ (\vec{b} + \delta \vec{b})$ . This leads to an error in the reconstructed Hamiltonian, such that the devi-

ation between the true and the recovered coefficients is given by  $\delta \vec{c} = K^+ \delta \vec{b}$ .

The error  $\delta \vec{b}$  in estimating the time-derivatives from Eq. (6) arises due to two factors: the finite measurement budget (number of experimental shots) and the finite-time approximation of the derivative. The finite sampling of  $\frac{\langle A(\delta t) \rangle}{\delta t}$  leads to statistical error which decreases with the number of experiments and measurement time,  $\|\delta \vec{b}_{stat}\| \sim \frac{1}{\sqrt{N}\delta t}$  (for a fixed  $N_{spam}$ ). The finite-time approximation of the derivative leads to a systematic error which increases with time,  $\|\delta \vec{b}_{sys}\| \sim \delta t$ . The optimal measurement time is determined by a tradeoff between those two factors. The total estimation error  $\delta \vec{b} = \delta \vec{b}_{stat} + \delta \vec{b}_{sys}$  is minimized when they are both of comparable magnitude  $\frac{1}{\sqrt{N}\delta t} \sim \delta t$ , which occurs at an optimal measurement time scaling with the number of experiments as  $\delta t^* \sim N^{-1/4}$ .

The  $N^{-1/4}$  scaling can be undertstood intuitively as follows. To achieve a reconstruction which is twice more accurate, the total estimation error must be reduced by a factor of 2. This requires measuring at a time shorter by a factor of 2; however, to reduce the statistical error  $\left\|\delta\vec{b}_{stat}\right\| \sim \frac{1}{\sqrt{N}\delta t}$  by a factor of 2 at this twice shorter measurement time, the measurements must be 4 times more accurate, which requires a number of shots 16 times larger.

To estimate the optimal  $\delta t^*$  more accurately, we analyze in Appendix A the contributions of the statistical and systematic errors to the reconstruction error,

<span id="page-2-4"></span>
$$\|\delta\vec{c}\| = \|K^+ \left(\delta\vec{b}_{stat} + \delta\vec{b}_{sys}\right)\|. \tag{10}$$

Since the statistical error averages to zero, we find that these contributions factorize, and to leading order in  $\delta t$ .

$$\mathbb{E}\|\delta\vec{c}\|^{2} = \mathbb{E}\|K^{+}\delta\vec{b}_{stat}\|^{2} + \|K^{+}\delta\vec{b}_{sys}\|^{2}$$

$$\approx \frac{a_{stat}}{N(\delta t)^{2}} + a_{sys}(\delta t)^{2},$$
(11)

for suitable constants  $a_{stat}$  and  $a_{sys}$ . The optimal time  $\delta t^*$ , and the corresponding optimal reconstruction error  $\Delta^*$  are therefore approximated by

<span id="page-2-2"></span>
$$\delta t^* \approx \left(\frac{a_{stat}}{a_{sys}N}\right)^{\frac{1}{4}}, \quad \Delta^* \approx \left(4\frac{a_{stat}a_{sys}}{N}\right)^{\frac{1}{4}}/\|\vec{c}\|.$$
(12)

The statistical component  $a_{stat}$  determines how finite sampling errors degrade the reconstruction. We find that it is given by the spectrum of  $\frac{1}{\sqrt{N_{spam}}}K$ , which quantifies the sensitivity of the SPAM settings to all the Hamiltonian parameters, averaged over the  $N_{spam}$  SPAM settings,

<span id="page-2-3"></span>
$$a_{stat} = \text{Tr}\left(\left(\frac{1}{N_{spam}}K^TK\right)^{-1}\right).$$
 (13)

The systematic compenent of the error stems from the higher-order derivatives of the estimated observables. When the systematic error is calculated to leading order in  $\delta t$ , it is given by

<span id="page-3-3"></span>
$$a_{sys} = \left\| K^{+} \partial_{tt} \left\langle \vec{A} \right\rangle |_{t=0} \right\|^{2}, \tag{14}$$

where  $\partial_{tt} \langle A \rangle = -\langle [H, [H, A]] \rangle$ . A more accurate estimate for long times (small N) can be calculated using higher orders derivatives (e.g. using  $\partial_{ttt} \langle A \rangle$  as well, see Appendix A.2). Since the systematic error depends on the unknown Hamiltonian we wish to reconstruct, it must be estimated separately; for instance, by computing it with respect to a guess of the true Hamiltonian.

Remarkably, a rough guess of the true Hamiltonian provides an excellent estimate for the reconstruction error and optimal measurement time. We estimated these quantities for the experiments presented in Fig. 1, using the second-order estimate for the systematic error  $a_{sys}$  described in Appendix A.2. We assumed that the true Hamiltonian is known to an accuracy of 10%, and estimated  $a_{sys}$  according to a perturbed version of the true Hamiltonian

<span id="page-3-0"></span>
$$H + H' = \sum_{j} c_j (1 + e_j) S_j,$$
 (15)

where  $e_j \sim N(0, 0.1^2)$ . Plugged in Eq. (12), this estimate reproduced the reconstruction error in Fig. 1 near its optimum to an excellent accuracy (Fig. 1, left, gray line). The predicted optimal measurement time matched the empirical optimum even at moderate measurement budgets N. While it is tempting to improve the reconstruction using higher order finite difference methods [45], our experiments found an advantage for these methods only at impractical measurement budgets  $N \geq 10^{11}$  (see Appendix A.3).

System size scaling. So far, we numerically estimated the reconstruction error at a fixed number of SPAM settings  $N_{spam} = 648$  and system size n = 7. How many SPAM settings  $N_{spam}$  are required for reconstruction, and how does the measurement budget N required for reconstruction scale with system size?

We repeated the reconstruction experiment of random 2-ranged Hamiltonians [Eq. (8)] with varying numbers of different SPAM settings  $N_{spam}$  and a constant total budget of measurements N. The reconstruction error saturated at  $N_{spam}^* \approx 10^3$  SPAM settings (Fig. 2, left, dots). Crucially, both  $N_{spam}^*$  and the reconstruction error remained unchanged when we increased the system size from n=5 to n=11, keeping the total measurement budget fixed. The larger system yielded the same reconstruction error, saturating at the same number of SPAM settings.

To understand the saturation of the reconstruction error as a function of the number of SPAM settings  $N_{spam}$ , we consider the  $N_{spam} \to \infty$  limit of all SPAM

<span id="page-3-1"></span>![](_page_3_Figure_9.jpeg)

Figure 2: Left: Reconstruction error as a function of the number of different state preparation and measurement (SPAM) settings for various system sizes and a fixed total number of shots ( $N = 8 \cdot 10^6$ ). The reconstruction accuracy of both random SPAM settings (circles) and cyclic SPAM settings (crosses) does not depend on system size, and saturates with sufficiently many settings. The saturation point is predicted by the number of settings  $N_{spam}^* = 6^3 \cdot 3$  in the full set of cyclic settings (vertical dotted line); for  $N_{spam} < N_{spam}^*$ , the crosses correspond to random subsets of this set. Right: the measurements of the cyclic protocol (Overlapping Local Tomography) for the case of  $k_{\beta}=3$ -ranged observables. Partition the lattice to unit cells of length  $k_{\beta}$ , then measure each unit cell in an informationally complete set of bases ( $3^{k_{\beta}}$ in one dimension) to obtain its reduced density matrix, repeating the bases periodically across unit cells. The reduced density matrices of overlapping partitions (gray braces) are obtained for free, since the measurement bases of the different partitions are equal up to a permutation. Initial states in the cyclic SPAM scheme are chosen similarly.

settings. Averaging over all product states and measurement bases, the correlation matrix  $\frac{1}{N_{spam}}K^TK$  converges to a diagonal matrix with system size independent entries (see Appendix B). The entry for each Hamiltonian term depends only on its support and on the set of measured observables. For example, if only single-site observables  $A_{\beta}$  are used,

<span id="page-3-2"></span>
$$\frac{1}{N_{spam}} \left( K^T K \right)_{j,j'} \underset{p \to \infty}{\to} 4 \cdot \frac{2k_j}{3^{k_j + 1}} \delta_{j,j'}, \tag{16}$$

where  $k_j$  is the weight of the corresponding Hamiltonian term  $S_i$ , which is the size of its support.

The insensitivity of the reconstruction to system size is apparent in the  $N_{spam} \to \infty$  average over SPAM settings [Eq. (16)]. The system-size independence of the correlation matrix entries implies a system-size independent statistical error [Eq. (13)] per Hamiltonian term, as the average singular value of K becomes constant. The systematic error [Eq. (14)] per Hamiltonian term is also constant for short-ranged Hamiltonians, since each Hamiltonian term affects a fixed number of observables.

More generally, the system-size independence follows from the local structure of the reconstruction algorithm, since the equations for each Hamiltonian term involve only observables in its vicinity [43]. This local structure also implies that the  $N_{spam} \to \infty$  limit of Eq. (16) does not require all SPAM settings; only

the local configuration of each initial state and measurement basis matters. To predict the number of SPAM configurations required to saturate the reconstruction error, we now devise a structured SPAM scheme. This structured scheme uses a finite number of 'cyclic' SPAM configurations which are equivalent to the  $N_{spam} \rightarrow \infty$  average over all configurations.

The cyclic measurement bases of the structured scheme are chosen to estimate all observables of a constant range  $k_{\beta}$  in a given initial state. We construct these measurement by partitioning the lattice to unit cells of length  $k_{\beta}$ , and iterating over all measurement configurations within a unit cell (Fig. 2, right). The configurations are copied between unit cells, defining a set of  $3^{k_{\beta}}$  measurement bases in one dimension, or  $3^{k_{\beta}^D}$  bases in a D-dimensional lattice, independent of system size. Inspired by Ref. [51], we call this measurement process 'Overlapping local tomography', since it characterizes all the  $k_{\beta}$ -ranged reduced density matrices of a given state.

The cyclic initial states are constructed similarly to the cyclic measurement bases. For the purposes of reconstructing a k-ranged Hamiltonian, cyclic initial states with periodicity 2k-1 are equivalent to the full set of initial product states. This periodicity is chosen to uniformly cover the shared support of every pair of overlapping Hamiltonian terms  $S_i$ ,  $S_j$  (see Appendix B). For the k=2-ranged Hamiltonians and 1-ranged observables considered so far, this structured scheme consists of  $N_{spam}^*=648=6^3\cdot 3$  configurations, corresponding to the saturation point of Fig. 2. These structured configurations yield a similar reconstruction accuracy as the random configurations (Fig. 2, left, crosses).

Choosing the observables. An important factor in the reconstruction is the choice of observables  $\{A_{\beta}\}$  used for building the linear equation Eq. (5). Each measurement setting can be used to estimate  $2^n-1$  commuting Pauli observables. Our previous simulations used only single-site observables in the reconstruction. How does the choice of estimated observables affect the reconstruction quality?

To test this, we repeated our simulations with different choices of observables. We used a fixed dataset of experimental outcomes to estimate all observables up to range  $k_{\beta}$  for  $k_{\beta}=1,2,3$ . While reconstruction with  $k_{\beta}=1$  observables was improved by the addition of  $k_{\beta}=2$  observables (Fig. 3, warm colors), the addition of  $k_{\beta}=3$  degraded the reconstruction (not shown). Correlations between estimated observables cause the degradation for  $k_{\beta}=3$ , as well as the deviation between predicted and measured errors for  $k_{\beta}=2$  (see Appendix A.1); we conjecture that observables up to a range matching that of the Hamiltonian  $k_{\beta}=k$  are optimal more generally.

<span id="page-4-0"></span>![](_page_4_Figure_5.jpeg)

Figure 3: Reconstruction error as a function of the total number of shots. Warm colors: reconstruction of random 2-ranged Hamiltonians using all observables up to range  $k_\beta=1$  (orange) and  $k_\beta=2$  (red). Addition of 2-ranged observables improves the reconstruction accuracy at the same measurement budget N. Blue: reconstruction of random XXZ Hamiltonians using 1-ranged observables in a cyclic measurement scheme with periodicity 2. Symmetries of the XXZ model lead to an easier reconstruction, with error scaling asymptotically as  $N^{-1/3}$  in contrast to the  $N^{-1/4}$  scaling predicted for generic Hamiltonians.

#### Symmetry eases Hamiltonian reconstruction.

In contrast to the Hamiltonians we simulated so far, realistic Hamiltonians are not fully random and often have symmetries. How does symmetry affect the reconstruction quality and the accuracy of the our predictions?

To address this question, we repeated our experiments with random XXZ Hamiltonians:

<span id="page-4-1"></span>
$$H_{XXZ} = \sum_{i=0}^{n-1} c_i Z_i Z_{i+1} + a_i (X_i X_{i+1} + Y_i Y_{i+1}), \quad (17)$$

where  $c_i, a_i \sim N(0,1)$  are drawn from a Gaussian distribution. These XXZ Hamiltonians are invariant under three anti-unitary symmetries  $\forall i: \sigma_i^\alpha \mapsto -\sigma_i^\alpha$ , each of which flips one of the Bloch axes  $\alpha$  for all spins i [54]. Interestingly, the reconstruction error of these Hamiltonians in a cyclic measurement scheme decreased more rapidly with the total number of shots  $\Delta \sim N^{-1/3}$  compared to the naive prediction  $N^{-1/4}$  of Eq. (12) (Fig. 3, blue). We find that for initial states that respect at least one of the anti-unitary symmetries of the Hamiltonian, the systematic error  $a_{sys}$  [Eq. (14)] vanishes to first order (see Appendix C). As a result, the systematic error scales as  $\left\|\delta \vec{b}_{sys}\right\| \sim \mathcal{O}(\delta t^2)$  instead of  $\mathcal{O}(dt)$ , explaining the  $N^{-1/3}$  scaling of the reconstruction error.

Conclusions. We have shown that a system-size independent number of short-time measurements fully characterizes short-ranged Hamiltonians to any given accuracy. Fixing the total number of experimental shots, the error decreases with the number of experimental configurations up to a saturation point. While the error is very sensitive to the measurement time, the optimal time can be predicted using minimal prior knowledge.

Short-time measurements for Hamiltonian reconstruction benefit from computational and analytical tractability, as well as favorable system-size scaling. However, the reconstruction scales poorly with the number of shots, since the derivative estimation requires evolution times which decrease with the desired reconstruction accuracy. Longer measurement times can be utilized by substituting the differential Ehrenfest equation [Eq. [\(2\)](#page-1-0)] by an integral equation for the dynamics of observables over a time period. Altenatively, a higher-order Taylor expansion of the observable dynamics would lead to a non-linear set of equations, allowing longer measurement times at the cost of higher computational effort as in the recent Ref. [\[55\]](#page-8-4). The optimal measurement time for these higher order methods can be estimated using extensions of the method we presented here.

Alternatively, recent works discuss a scheme for dynamical Hamiltonian learning which is based on on energy conservation [\[48,](#page-7-10) [56\]](#page-8-5). These works look for a local observable which does not change with time. In the absence of other local symmetries, the only conserved observable is the Hamiltonian. Thus, each initial state or measurement time gives a single linear equation for the Hamiltonian, such that O(*n*) suffice to uniquely identify it. The equations remain computationally tractable for long evolution times, increasing their sensitivity at a fixed system size. In our short-time approach, each measurement settings yields not one but O(*n*) local equations for the Hamiltonian, providing an advantage at large system sizes.

### Acknowledgments

We thank Itai Arad, Barak Gur and Tasneem Watad for useful discussions. We acknowledge financial support from the European Research Council (ERC) under the European Union Horizon 2020 Research and Innovation Programme (Grant Agreement No. 639172), the Defense Advanced Research Projects Agency through the DRINQS program, grant No. D18AC00025, and from the Israel Science Foundation within the ISF-Quantum program (Grant No. 2074/19). The content of the information presented here does not necessarily reflect the position or the policy of the U.S. government, and no official endorsement should be inferred.

### References

<span id="page-5-0"></span>[1] H. Y. Kwon, H. G. Yoon, C. Lee, G. Chen, K. Liu, A. K. Schmid, Y. Z. Wu, J. W. Choi, and C. Won. Magnetic Hamiltonian parameter esti-

- mation using deep learning techniques. Science Advances, 6(39), 2020. ISSN 23752548. [DOI:](https://doi.org/10.1126/sciadv.abb0872) [10.1126/sciadv.abb0872.](https://doi.org/10.1126/sciadv.abb0872)
- <span id="page-5-1"></span>[2] Dingchen Wang, Songrui Wei, Anran Yuan, Fanghua Tian, Kaiyan Cao, Qizhong Zhao, Yin Zhang, Chao Zhou, Xiaoping Song, Dezhen Xue, and Sen Yang. Machine Learning Magnetic Parameters from Spin Configurations. Advanced Science, 7(16), 2020. ISSN 21983844. [DOI:](https://doi.org/10.1002/advs.202000566) [10.1002/advs.202000566.](https://doi.org/10.1002/advs.202000566)
- <span id="page-5-2"></span>[3] Hui Li and F. D.M. Haldane. Entanglement spectrum as a generalization of entanglement entropy: Identification of topological order in non-Abelian fractional quantum hall effect states. Physical Review Letters, 101(1), 2008. ISSN 00319007. [DOI: 10.1103/Phys-](https://doi.org/10.1103/PhysRevLett.101.010504)[RevLett.101.010504.](https://doi.org/10.1103/PhysRevLett.101.010504)
- [4] X. Turkeshi, T. Mendes-Santos, G. Giudici, and M. Dalmonte. Entanglement-Guided Search for Parent Hamiltonians. Physical Review Letters, 122(15), 7 2019. ISSN 10797114. [DOI:](https://doi.org/10.1103/PhysRevLett.122.150606) [10.1103/PhysRevLett.122.150606.](https://doi.org/10.1103/PhysRevLett.122.150606) URL [http:](http://arxiv.org/abs/1807.06113) [//arxiv.org/abs/1807.06113](http://arxiv.org/abs/1807.06113).
- [5] G. Giudici, T. Mendes-Santos, P. Calabrese, and M. Dalmonte. Entanglement Hamiltonians of lattice models via the Bisognano-Wichmann theorem. Physical Review B, 98(13), 7 2018. ISSN 24699969. [DOI: 10.1103/PhysRevB.98.134403.](https://doi.org/10.1103/PhysRevB.98.134403) URL <https://arxiv.org/abs/1807.01322>.
- [6] W. Zhu, Zhoushen Huang, and Yin Chen He. Reconstructing entanglement Hamiltonian via entanglement eigenstates. Physical Review B, 99(23), 6 2019. ISSN 24699969. [DOI:](https://doi.org/10.1103/PhysRevB.99.235109) [10.1103/PhysRevB.99.235109.](https://doi.org/10.1103/PhysRevB.99.235109) URL [http://](http://arxiv.org/abs/1806.08060) [arxiv.org/abs/1806.08060](http://arxiv.org/abs/1806.08060).
- [7] M. Dalmonte, B. Vermersch, and P. Zoller. Quantum simulation and spectroscopy of entanglement Hamiltonians. Nature Physics, 14(8), 2018. ISSN 17452481. [DOI: 10.1038/s41567-018-](https://doi.org/10.1038/s41567-018-0151-7) [0151-7.](https://doi.org/10.1038/s41567-018-0151-7)
- [8] Christian Kokail, Rick van Bijnen, Andreas Elben, Benoˆıt Vermersch, and Peter Zoller. Entanglement hamiltonian tomography in quantum simulation, 2020. ISSN 23318422.
- <span id="page-5-3"></span>[9] Davide Rattacaso, Gianluca Passarelli, Antonio Mezzacapo, Procolo Lucignano, and Rosario Fazio. Optimal parent Hamiltonians for timedependent states. Phys. Rev. A, 104(2):022611, 5 2021. [DOI: 10.1103/PhysRevA.104.022611.](https://doi.org/10.1103/PhysRevA.104.022611) URL [http://arxiv.org/abs/2105.10187http://](http://arxiv.org/abs/2105.10187 http://dx.doi.org/10.1103/PhysRevA.104.022611) [dx.doi.org/10.1103/PhysRevA.104.022611](http://arxiv.org/abs/2105.10187 http://dx.doi.org/10.1103/PhysRevA.104.022611).
- <span id="page-5-4"></span>[10] N. Boulant, T. F. Havel, M. A. Pravia, and D. G. Cory. Robust method for estimating the Lindblad operators of a dissipative quantum process from measurements of the density operator at multiple time points. Physical Review A - Atomic, Molecular, and Optical Physics, 67(4):

- 12, 2003. ISSN 10941622. [DOI: 10.1103/Phys-](https://doi.org/10.1103/PhysRevA.67.042322)[RevA.67.042322.](https://doi.org/10.1103/PhysRevA.67.042322)
- [11] Luca Innocenti, Leonardo Banchi, Alessandro Ferraro, Sougato Bose, and Mauro Paternostro. Supervised learning of time-independent Hamiltonians for gate design. New Journal of Physics, 22(6), 2020. ISSN 13672630. [DOI: 10.1088/1367-](https://doi.org/10.1088/1367-2630/ab8aaf) [2630/ab8aaf.](https://doi.org/10.1088/1367-2630/ab8aaf)
- [12] Eitan Ben Av, Yotam Shapira, Nitzan Akerman, and Roee Ozeri. Direct reconstruction of the quantum-master-equation dynamics of a trapped-ion qubit. Physical Review A, 101(6), 2020. ISSN 24699934. [DOI: 10.1103/Phys-](https://doi.org/10.1103/PhysRevA.101.062305)[RevA.101.062305.](https://doi.org/10.1103/PhysRevA.101.062305)
- <span id="page-6-0"></span>[13] Jose Carrasco, Andreas Elben, Christian Kokail, Barbara Kraus, and Peter Zoller. Theoretical and Experimental Perspectives of Quantum Verification. PRX Quantum, 2(1):010102, 3 2021. ISSN 2691-3399. [DOI: 10.1103/PRXQuan](https://doi.org/10.1103/PRXQuantum.2.010102)[tum.2.010102.](https://doi.org/10.1103/PRXQuantum.2.010102) URL [https://link.aps.org/](https://link.aps.org/doi/10.1103/PRXQuantum.2.010102) [doi/10.1103/PRXQuantum.2.010102](https://link.aps.org/doi/10.1103/PRXQuantum.2.010102).
- <span id="page-6-1"></span>[14] Easwar Magesan, J. M. Gambetta, and Joseph Emerson. Scalable and Robust Randomized Benchmarking of Quantum Processes. Physical Review Letters, 106(18):180504, 5 2011. ISSN 0031-9007. [DOI: 10.1103/Phys-](https://doi.org/10.1103/PhysRevLett.106.180504)[RevLett.106.180504.](https://doi.org/10.1103/PhysRevLett.106.180504) URL [https://link.aps.](https://link.aps.org/doi/10.1103/PhysRevLett.106.180504) [org/doi/10.1103/PhysRevLett.106.180504](https://link.aps.org/doi/10.1103/PhysRevLett.106.180504).
- <span id="page-6-2"></span>[15] M. D. Shulman, S. P. Harvey, J. M. Nichol, S. D. Bartlett, A. C. Doherty, V. Umansky, and A. Yacoby. Suppressing qubit dephasing using real-time Hamiltonian estimation. Nature Communications, 5, 2014. ISSN 20411723. [DOI:](https://doi.org/10.1038/ncomms6156) [10.1038/ncomms6156.](https://doi.org/10.1038/ncomms6156)
- [16] Sarah Sheldon, Easwar Magesan, Jerry M. Chow, and Jay M. Gambetta. Procedure for systematically tuning up cross-talk in the cross-resonance gate. Physical Review A, 93(6), 2016. ISSN 24699934. [DOI: 10.1103/PhysRevA.93.060302.](https://doi.org/10.1103/PhysRevA.93.060302)
- [17] Neereja Sundaresan, Isaac Lauer, Emily Pritchett, Easwar Magesan, Petar Jurcevic, and Jay M. Gambetta. Reducing Unitary and Spectator Errors in Cross Resonance with Optimized Rotary Echoes. PRX Quantum, 1(2):020318, 12 2020. ISSN 2691-3399. [DOI: 10.1103/PRXQuan](https://doi.org/10.1103/PRXQuantum.1.020318)[tum.1.020318.](https://doi.org/10.1103/PRXQuantum.1.020318) URL [https://link.aps.org/](https://link.aps.org/doi/10.1103/PRXQuantum.1.020318) [doi/10.1103/PRXQuantum.1.020318](https://link.aps.org/doi/10.1103/PRXQuantum.1.020318).
- <span id="page-6-3"></span>[18] Jens Eisert, Dominik Hangleiter, Nathan Walk, Ingo Roth, Damian Markham, Rhea Parekh, Ulysse Chabaud, and Elham Kashefi. Quantum certification and benchmarking, 2020. ISSN 25225820.
- <span id="page-6-4"></span>[19] Chen-Di Han, Bryan Glaz, Mulugeta Haile, and Ying-Cheng Lai. Tomography of time-dependent quantum spin networks with machine learning. 3 2021. URL [https://arxiv.org/abs/2103.](https://arxiv.org/abs/2103.08645) [08645](https://arxiv.org/abs/2103.08645).
- [20] Akira Sone and Paola Cappellaro. Hamiltonian

- identifiability assisted by a single-probe measurement. Phys. Rev. A, 95(2), 2017. ISSN 24699934. [DOI: 10.1103/PhysRevA.95.022335.](https://doi.org/10.1103/PhysRevA.95.022335)
- [21] Jun Zhang and Mohan Sarovar. Quantum hamiltonian identification from measurement time traces. Physical Review Letters, 113(8):080401, 8 2014. ISSN 10797114. [DOI: 10.1103/Phys-](https://doi.org/10.1103/PhysRevLett.113.080401)[RevLett.113.080401.](https://doi.org/10.1103/PhysRevLett.113.080401) URL [https://link.aps.](https://link.aps.org/doi/10.1103/PhysRevLett.113.080401) [org/doi/10.1103/PhysRevLett.113.080401](https://link.aps.org/doi/10.1103/PhysRevLett.113.080401).
- [22] Jun Zhang and Mohan Sarovar. Identification of open quantum systems from observable time traces. Physical Review A - Atomic, Molecular, and Optical Physics, 91(5), 2015. ISSN 10941622. [DOI: 10.1103/PhysRevA.91.052121.](https://doi.org/10.1103/PhysRevA.91.052121)
- [23] C. Di Franco, M. Paternostro, and M. S. Kim. Hamiltonian tomography in an access-limited setting without state initialization. Phys. Rev. Lett., 102(18), 2009. ISSN 00319007. [DOI:](https://doi.org/10.1103/PhysRevLett.102.187203) [10.1103/PhysRevLett.102.187203.](https://doi.org/10.1103/PhysRevLett.102.187203)
- [24] Daniel Burgarth, Koji Maruyama, and Franco Nori. Coupling strength estimation for spin chains despite restricted access. Phys. Rev. A, 79 (2), 2009. ISSN 10502947. [DOI: 10.1103/Phys-](https://doi.org/10.1103/PhysRevA.79.020305)[RevA.79.020305.](https://doi.org/10.1103/PhysRevA.79.020305)
- <span id="page-6-5"></span>[25] Gabriel O. Samach, Ami Greene, Johannes Borregaard, Matthias Christandl, David K. Kim, Christopher M. McNally, Alexander Melville, Bethany M. Niedzielski, Youngkyu Sung, Danna Rosenberg, Mollie E. Schwartz, Jonilyn L. Yoder, Terry P. Orlando, Joel I-Jan Wang, Simon Gustavsson, Morten Kjaergaard, and William D. Oliver. Lindblad Tomography of a Superconducting Quantum Processor. 5 2021. URL [https:](https://arxiv.org/abs/2105.02338) [//arxiv.org/abs/2105.02338](https://arxiv.org/abs/2105.02338).
- <span id="page-6-6"></span>[26] Sheng Tao Wang, Dong Ling Deng, and L. M. Duan. Hamiltonian tomography for quantum many-body systems with arbitrary couplings. New Journal of Physics, 17(9), 2015. ISSN 13672630. [DOI: 10.1088/1367-](https://doi.org/10.1088/1367-2630/17/9/093017) [2630/17/9/093017.](https://doi.org/10.1088/1367-2630/17/9/093017)
- [27] Agnes Valenti, Evert van Nieuwenburg, Sebastian Huber, and Eliska Greplova. Hamiltonian learning for quantum error correction. Physical Review Research, 1(3), 7 2019. [DOI:](https://doi.org/10.1103/physrevresearch.1.033092) [10.1103/physrevresearch.1.033092.](https://doi.org/10.1103/physrevresearch.1.033092) URL [http:](http://arxiv.org/abs/1907.02540) [//arxiv.org/abs/1907.02540](http://arxiv.org/abs/1907.02540).
- [28] Stefan Krastanov, Sisi Zhou, Steven T. Flammia, and Liang Jiang. Stochastic estimation of dynamical variables. Quantum Science and Technology, 4(3), 2019. ISSN 20589565. [DOI:](https://doi.org/10.1088/2058-9565/ab18d5) [10.1088/2058-9565/ab18d5.](https://doi.org/10.1088/2058-9565/ab18d5)
- <span id="page-6-7"></span>[29] Agnes Valenti, Guliuxin Jin, Julian L´eonard, Sebastian D. Huber, and Eliska Greplova. Scalable Hamiltonian learning for large-scale out-ofequilibrium quantum dynamics. 3 2021. URL <https://arxiv.org/abs/2103.01240>.
- <span id="page-6-8"></span>[30] Christopher E. Granade, Christopher Ferrie, Nathan Wiebe, and D. G. Cory. Robust online

- Hamiltonian learning. New Journal of Physics, 14, 2012. ISSN 13672630. [DOI: 10.1088/1367-](https://doi.org/10.1088/1367-2630/14/10/103013) [2630/14/10/103013.](https://doi.org/10.1088/1367-2630/14/10/103013)
- [31] Nathan Wiebe, Christopher Granade, Christopher Ferrie, and D. G. Cory. Hamiltonian learning and certification using quantum resources. Phys. Rev. Lett., 112(19), 2014. ISSN 10797114. [DOI: 10.1103/PhysRevLett.112.190501.](https://doi.org/10.1103/PhysRevLett.112.190501)
- [32] Nathan Wiebe, Christopher Granade, Christopher Ferrie, and David Cory. Quantum Hamiltonian learning using imperfect quantum resources. Phys. Rev. A, 89(4), 2014. ISSN 10941622. [DOI:](https://doi.org/10.1103/PhysRevA.89.042314) [10.1103/PhysRevA.89.042314.](https://doi.org/10.1103/PhysRevA.89.042314)
- [33] Nathan Wiebe, Christopher Granade, and D. G. Cory. Quantum bootstrapping via compressed quantum Hamiltonian learning. New Journal of Physics, 17, 2015. ISSN 13672630. [DOI:](https://doi.org/10.1088/1367-2630/17/2/022005) [10.1088/1367-2630/17/2/022005.](https://doi.org/10.1088/1367-2630/17/2/022005)
- <span id="page-7-0"></span>[34] Jianwei Wang, Stefano Paesani, Raffaele Santagati, Sebastian Knauer, Antonio A. Gentile, Nathan Wiebe, Maurangelo Petruzzella, Jeremy L. O'brien, John G. Rarity, Anthony Laing, and Mark G. Thompson. Experimental quantum Hamiltonian learning. Nat. Phys., 13(6):551–555, 2017. ISSN 17452481. [DOI:](https://doi.org/10.1038/nphys4074) [10.1038/nphys4074.](https://doi.org/10.1038/nphys4074)
- <span id="page-7-1"></span>[35] A. Shabani, M. Mohseni, S. Lloyd, R. L. Kosut, and H. Rabitz. Estimation of many-body quantum hamiltonians via compressive sensing. Phys. Rev. A, 84(1), 2011. ISSN 10502947. [DOI:](https://doi.org/10.1103/PhysRevA.84.012107) [10.1103/PhysRevA.84.012107.](https://doi.org/10.1103/PhysRevA.84.012107)
- <span id="page-7-2"></span>[36] Marcus P. Da Silva, Olivier Landon-Cardinal, and David Poulin. Practical characterization of quantum devices without tomography. Physical Review Letters, 107(21), 2011. ISSN 00319007. [DOI: 10.1103/PhysRevLett.107.210404.](https://doi.org/10.1103/PhysRevLett.107.210404)
- <span id="page-7-3"></span>[37] Xiao-Liang Qi and Daniel Ranard. Determining a local Hamiltonian from a single eigenstate. Quantum, 3:159, 12 2019. [DOI: 10.22331/q-2019-](https://doi.org/10.22331/q-2019-07-08-159) [07-08-159.](https://doi.org/10.22331/q-2019-07-08-159) URL [https://doi.org/10.22331/](https://doi.org/10.22331/q-2019-07-08-159) [q-2019-07-08-159](https://doi.org/10.22331/q-2019-07-08-159).
- [38] Eli Chertkov and Bryan K. Clark. Computational Inverse Method for Constructing Spaces of Quantum Models from Wave Functions. Physical Review X, 8(3):031029, 7 2018. ISSN 21603308. [DOI: 10.1103/Phys-](https://doi.org/10.1103/PhysRevX.8.031029)[RevX.8.031029.](https://doi.org/10.1103/PhysRevX.8.031029) URL [https://link.aps.org/](https://link.aps.org/doi/10.1103/PhysRevX.8.031029) [doi/10.1103/PhysRevX.8.031029](https://link.aps.org/doi/10.1103/PhysRevX.8.031029).
- [39] Martin Greiter, Vera Schnells, and Ronny Thomale. Method to identify parent Hamiltonians for trial states. Physical Review B, 98(8):081113(R), 8 2018. ISSN 24699969. [DOI: 10.1103/PhysRevB.98.081113.](https://doi.org/10.1103/PhysRevB.98.081113) URL [https://link.aps.org/doi/10.1103/](https://link.aps.org/doi/10.1103/PhysRevB.98.081113) [PhysRevB.98.081113](https://link.aps.org/doi/10.1103/PhysRevB.98.081113).
- [40] Kenneth Rudinger and Robert Joynt. Compressed sensing for Hamiltonian reconstruction.

- Phys. Rev. A, 92(5), 2015. ISSN 10941622. [DOI:](https://doi.org/10.1103/PhysRevA.92.052322) [10.1103/PhysRevA.92.052322.](https://doi.org/10.1103/PhysRevA.92.052322)
- [41] M´aria Kieferov´a and Nathan Wiebe. Tomography and generative training with quantum Boltzmann machines. Phys. Rev. A, 2017. ISSN 24699934. [DOI: 10.1103/PhysRevA.96.062327.](https://doi.org/10.1103/PhysRevA.96.062327)
- [42] Hilbert J Kappen. Learning quantum models from quantum or classical data. arXiv:1803.11278, 3 2018. URL <http://arxiv.org/abs/1803.11278>.
- <span id="page-7-7"></span>[43] Eyal Bairey, Itai Arad, and Netanel H. Lindner. Learning a Local Hamiltonian from Local Measurements. Physical Review Letters, 122 (2), 2019. ISSN 10797114. [DOI: 10.1103/Phys-](https://doi.org/10.1103/PhysRevLett.122.020504)[RevLett.122.020504.](https://doi.org/10.1103/PhysRevLett.122.020504)
- <span id="page-7-8"></span>[44] Eyal Bairey, Chu Guo, Dario Poletti, Netanel H. Lindner, and Itai Arad. Learning the dynamics of open quantum systems from their steady states. New Journal of Physics, 22(3), 7 2020. ISSN 13672630. [DOI: 10.1088/1367-](https://doi.org/10.1088/1367-2630/ab73cd) [2630/ab73cd.](https://doi.org/10.1088/1367-2630/ab73cd) URL [http://arxiv.org/abs/](http://arxiv.org/abs/1907.11154) [1907.11154](http://arxiv.org/abs/1907.11154).
- <span id="page-7-9"></span>[45] Eugene F. Dumitrescu and Pavel Lougovski. Hamiltonian Assignment for Open Quantum Systems, 2019. ISSN 23318422.
- [46] Anurag Anshu, Srinivasan Arunachalam, Tomotaka Kuwahara, and Mehdi Soleimanifar. Sample-efficient learning of quantum many-body systems. arXiv, 2020.
- <span id="page-7-4"></span>[47] Tim J. Evans, Robin Harper, and Steven T. Flammia. Scalable Bayesian Hamiltonian learning. 12 2019. URL [http://arxiv.org/abs/](http://arxiv.org/abs/1912.07636) [1912.07636](http://arxiv.org/abs/1912.07636).
- <span id="page-7-10"></span>[48] Zhi Li, Liujun Zou, and Timothy H. Hsieh. Hamiltonian Tomography via Quantum Quench. Physical Review Letters, 124 (16), 12 2020. ISSN 10797114. [DOI:](https://doi.org/10.1103/PhysRevLett.124.160502) [10.1103/PhysRevLett.124.160502.](https://doi.org/10.1103/PhysRevLett.124.160502) URL <http://arxiv.org/abs/1912.09492>.
- [49] A. Elben, B. Vermersch, C. F. Roos, and P. Zoller. Statistical correlations between locally randomized measurements: A toolbox for probing entanglement in many-body quantum states. Physical Review A, 99(5), 2019. ISSN 24699934. [DOI: 10.1103/PhysRevA.99.052323.](https://doi.org/10.1103/PhysRevA.99.052323)
- <span id="page-7-5"></span>[50] Hsin Yuan Huang, Richard Kueng, and John Preskill. Predicting many properties of a quantum system from very few measurements. Nature Physics, 16(10), 2020. ISSN 17452481. [DOI:](https://doi.org/10.1038/s41567-020-0932-7) [10.1038/s41567-020-0932-7.](https://doi.org/10.1038/s41567-020-0932-7)
- <span id="page-7-6"></span>[51] Jordan Cotler and Frank Wilczek. Quantum Overlapping Tomography. Physical Review Letters, 124(10), 2020. ISSN 10797114. [DOI:](https://doi.org/10.1103/PhysRevLett.124.100401) [10.1103/PhysRevLett.124.100401.](https://doi.org/10.1103/PhysRevLett.124.100401)
- [52] Guillermo Garcia-Perez, Matteo A. C. Rossi, Boris Sokolov, Elsi-Mari Borrelli, and Sabrina Maniscalco. Pairwise tomography networks for many-body quantum systems. Physical Review

Research, 2(2), 2020. ISSN 2643-1564. DOI: 10.1103/physrevresearch.2.023393.

- <span id="page-8-0"></span>[53] Xavier Bonet-Monroig, Ryan Babbush, and Thomas E. O'Brien. Nearly Optimal Measurement Scheduling for Partial Tomography of Quantum States. *Physical Review X*, 10(3), 2020. ISSN 21603308. DOI: 10.1103/Phys-RevX.10.031064.
- <span id="page-8-3"></span>[54] Meng Cheng. Time reversal symmetry of transverse field Ising model. Physics Stack Exchange. URL https://physics.stackexchange.com/q/228830.
- <span id="page-8-4"></span>[55] Jeongwan Haah, Robin Kothari, and Ewin Tang. Optimal learning of quantum Hamiltonians from high-temperature Gibbs states. arXiv, 8 2021. URL https://arxiv.org/abs/2108.04842.
- <span id="page-8-5"></span>[56] Gregory Bentsen, Ionut-Dragos Potirniche, Vir B. Bulchandani, Thomas Scaffidi, Xiangyu Cao, Xiao-Liang Qi, Monika Schleier-Smith, and Ehud Altman. Integrable and Chaotic Dynamics of Spins Coupled to an Optical Cavity. Physical Review X, 9(4):041011, 10 2019. ISSN 2160-3308. DOI: 10.1103/PhysRevX.9.041011. URL https://link.aps.org/doi/10.1103/ PhysRevX.9.041011.

### <span id="page-8-1"></span>A Derivative estimation

## <span id="page-8-2"></span>A.1 Full derivation of the optimal measurement time

#### A.1.1 Full derivation of $\mathbb{E}\|\delta\vec{c}\|$ bound

We want to estimate how  $\delta t$  affects  $\mathbb{E}||\delta \vec{c}||$ . The effect of  $\delta t$  on  $\delta \vec{b}$  can be written as sum of two contributions  $\delta \vec{b} = \delta \vec{b}_{sys} + \delta \vec{b}_{stat}$  where

<span id="page-8-7"></span>
$$\delta b_{sys_{(\alpha,\beta)}} = b_{(\alpha,\beta)} - \frac{\langle A_{\beta} \rangle_{\psi_{\alpha}(\delta t)} - \langle A_{\beta} \rangle_{\psi_{\alpha}(0)}}{\delta t}, \quad (18)$$

with expectation values evaluated exactly (in the limit of infinite shots), is the systematic error of the estimation (Eq. (6)) and

$$\delta b_{stat_{(\alpha,\beta)}} = \frac{\delta \langle A_{\beta} \rangle_{\psi_{\alpha}(\delta t)}}{\delta t} \sim G\left(0, \frac{1}{\delta t^2} \frac{N_{spam}}{N}\right),\tag{19}$$

with expectation values estimated using  $\frac{N}{N_{spam}}$  shots, is the statistical error due to finite sampling. Writing  $\delta \vec{c} = K^+ \delta \vec{b} = K^+ \left( \delta \vec{b}_{stat} + \delta \vec{b}_{sys} \right)$  as sum of two independent errors allows us to find a value for  $\mathbb{E} \| \delta \vec{c} \|^2$  using the following lemma on the expectation value of a quadratic form.

**Lemma A.1.** Let  $\vec{x}$  be a random vector with mean  $\vec{\mu}$  and covariance matrix  $\Sigma$  then for any  $A \in M_{n,m}(\mathbb{R})$ ,  $\mathbb{E}\|A\vec{x}\|^2 = \operatorname{Tr}(\Sigma A^T A) + \|A\vec{\mu}\|^2$ .

Proof. Note that

$$||A\vec{x}||^2 = \vec{x}^T A^T A \vec{x}$$

Because  $||A\vec{x}||$  is a scalar, we can write

$$||A\vec{x}||^2 = \operatorname{Tr}\left(\vec{x}^T A^T A \vec{x}\right)$$

Using the cyclic property of the trace

$$||A\vec{x}||^2 = \operatorname{Tr}\left(A^T A \vec{x} \vec{x}^T\right)$$

As trace and matrix multiplication are essentially additions and scalar multiplications we can write

$$\mathbb{E}\operatorname{Tr}\left(A^{T}A\vec{x}\vec{x}^{T}\right)=\operatorname{Tr}\left(A^{T}A\mathbb{E}\left(\vec{x}\vec{x}^{T}\right)\right)$$

Using the definition of the covariance matrix

$$\mathbb{E}\|A\vec{x}\|^2 = \operatorname{Tr}\left(A^T A\left(\Sigma + \vec{\mu}\vec{\mu}^T\right)\right)$$

and from linearity of the trace

$$\mathbb{E}\|A\vec{x}\|^2 = Tr\left(A^T A \Sigma\right) + Tr\left(A^T A \vec{\mu} \vec{\mu}^T\right)$$

Again from the cyclic properties of the trace and the fact that  $\text{Tr}(\vec{\mu}^T A^T A \vec{\mu}) = ||A\vec{\mu}||^2$  (as it is a scalar):

$$\mathbb{E}||A\vec{x}||^2 = \operatorname{Tr}\left(\Sigma A^T A\right) + ||A\vec{\mu}||^2$$

In our case  $\delta \vec{b}$  is a random vector with mean  $\delta \vec{b}_{sys}$  and covariance matrix  $\Sigma_{\delta \vec{b}_{stat}} = \mathbb{E} \delta \vec{b}_{stat} \delta \vec{b}_{stat}^T$ . Using that lemma for  $\mathbb{E} \|\delta \vec{c}\|^2 = \mathbb{E} \|K^+ \delta \vec{b}\|^2$  we can find a bound on  $\mathbb{E} \|\delta \vec{c}\|$  using Jensen inequality  $\mathbb{E} \|\delta \vec{c}\| \leq \sqrt{\mathbb{E} \|\delta \vec{c}\|^2}$ :

$$\mathbb{E}\|\delta\vec{c}\| \leq \sqrt{\operatorname{Tr}\left(\mathbb{E}\left(\delta\vec{b}_{stat}\delta\vec{b}_{stat}^{T}\right)K^{+T}K^{+}\right) + \left\|K^{+}\delta\vec{b}_{sys}\right\|^{2}}.$$

Assuming each entry of  $\delta \vec{b}_{stat}$  is independent random variable with variance  $\sigma^2_{(\alpha,\beta)}$  and zero mean we get that

<span id="page-8-6"></span>
$$\mathbb{E}\|\delta\vec{c}\| \le \sqrt{\operatorname{Tr}\left(\Sigma_{\delta\vec{b}_{stat}}K^{+T}K^{+}\right) + \left\|K^{+}\delta\vec{b}_{sys}\right\|^{2}},\tag{20}$$

where  $\Sigma_{\delta \vec{b}_{stat}}$  is diagonal with elements  $\sigma^2_{(\alpha,\beta)}$ . Assuming  $\sigma_{(\alpha,\beta)} \sim \left(\frac{N}{N_{spam}}\right)^{-1/2} \frac{1}{\delta t}$  we can define

$$a_{stat} = \operatorname{Tr}\left(\Sigma_{\delta \vec{b}_{stat}}^* N_{spam} K^{+T} K^+\right)$$

where  $\Sigma_{\delta \vec{b}_{stat}}^* = \frac{N}{N_{spam}} \delta t^2 \Sigma_{\delta \vec{b}_{stat}}$  is a diagonal matrix which is independent of  $N, p, \delta t$  and

$$a_{sys} = \frac{1}{\delta t^2} \left\| K^+ \delta \vec{b}_{sys} \right\|^2$$

Assuming  $\delta \vec{b}_{sys} \sim \delta t$  (first order estimation of the systematic error) we get Eq. (11), and if we assume that

 $\Sigma_{\delta \vec{b}_{stat}}^* = 1$  (i.e. all the observables have the same statistical error magnitude) using the cyclic property of the trace we can write  $a_{stat} = \text{Tr}\left(N_{spam}\left(K^TK\right)^{-1}\right)$ .

In practice, the standard deviations varies between observables depending on the initial state. Moreover, when different observables are estimated from the same set of measurements, off-diagonal entries appear in the covariance matrix. These correlations explain the deviation between the predicted and observed accuracies in Fig. 3. They can be taken into account in order to improve the prediction of the reconstruction, and to predict the optimal set of estimated observables.

#### A.1.2 Estimating the optimal $\delta t$

In Eq. (11) and subsequent derivations, we have assumed that the statistical error scales as  $\delta \vec{b}_{stat} \propto \left(\frac{N}{N_{spam}}\right)^{-1/2} \delta t^{-1}$  and the systematic error as  $\delta \vec{b}_{sys} \propto \delta t$ . We can examine a more general case with

$$\delta \vec{b}_{stat} = \vec{a}_{stat} \left( \frac{N}{N_{spam}} \right)^{-1/2} \delta t^{-\gamma}$$
$$\delta \vec{b}_{sys} = \vec{a}_{sys} \delta t^{\lambda} + \mathcal{O}(\delta t^{\lambda+1})$$

for  $\lambda, \gamma \neq 1$ .  $\vec{a}_{stat}, \vec{a}_{sys}$  are defined such that they are independent of  $\delta t$ . The optimal  $\delta t$  is achieved when  $\mathbb{E}\|\delta\vec{c}\|$  is minimal. As an approximation, we use the bound  $\|\delta c\|_{bound} = \sqrt{\text{Tr}\left(\Sigma_{\delta\vec{b}_{stat}}K^{+T}K^{+}\right) + \left\|K^{+}\delta\vec{b}_{sys}\right\|^{2}}$  of Eq. (20), and minimize it with respect to  $\delta t$ . To leading order in  $\delta t$  we get

$$\|\delta c\|_{bound}^{2} = \frac{\delta t^{-2\gamma}}{N} \operatorname{Tr} \left( \sum_{\vec{a}_{stat}} K^{+T} K^{+} \right) + \delta t^{2\lambda} \|K^{+} \delta \vec{a}_{sys}\|^{2}.$$

The derivative is given by

$$\frac{d}{d(\delta t)} \|\delta c\|_{bound}^{2} = -2 \frac{\gamma \delta t^{-2\gamma - 1}}{N} \operatorname{Tr} \left( \sum_{\vec{a}_{stat}} K^{+T} K^{+} \right) + 2\lambda \delta t^{2\lambda - 1} \|K^{+} \delta \vec{a}_{sys}\|^{2}$$

The minimum is achieved when the derivative vanishes, which occurs at

$$\delta t^* = \left(\frac{1}{N} \cdot \frac{\gamma \operatorname{Tr}\left(\Sigma_{\vec{a}_{stat}} K^{+T} K^{+}\right)}{\lambda \|K^{+} \delta \vec{a}_{sys}\|^{2}}\right)^{1/2(\gamma+\lambda)}, \quad (21)$$

which corresponds to reconstruction error

$$\|\delta c^*\|_{bound} = \left(\sqrt{\frac{1}{1-\kappa}} \frac{1}{\sqrt{N}} \sqrt{\operatorname{Tr}\left(\Sigma_{\vec{a}_{stat}} K^{+T} K^{+}\right)}\right)^{1-\kappa} \cdot \left(\sqrt{\frac{1}{\kappa}} \|K^{+} \delta \vec{a}_{sys}\|\right)^{\kappa}, \quad (22)$$

where  $\kappa = \frac{\gamma}{\lambda + \gamma}$ . This result generalizes Eq. (12), where  $\gamma = \lambda = 1$  and  $\kappa = 1/2$ .

## <span id="page-9-0"></span>A.2 Estimation used in the Hamiltonian reconstruction simulations

In our simulations, the systematic error due to the finite derivative method was estimated using a perturbed version of the real Hamiltonian, used to calculate the higher derivatives  $\partial_{tt} \langle A_j \rangle_{t=0}$  and  $\partial_{ttt} \langle A_j \rangle_{t=0}$  of the observables. The systematic error is defined as

$$a_{sys} = \left\| K^{+} \left( \partial_{t} \left\langle \vec{A} \right\rangle |_{t=0} - \frac{\left\langle \vec{A} \right\rangle_{\delta t} - \left\langle \vec{A} \right\rangle_{0}}{\delta t} \right) \right\|^{2}.$$

Writing  $\left\langle \vec{A} \right\rangle_{\delta t}$  as a Taylor expansion around t=0 gives:

$$\left\langle \vec{A} \right\rangle_{\delta t} = \left\langle \vec{A} \right\rangle_{0} + \delta t \partial_{t} \left\langle \vec{A} \right\rangle|_{0} + \frac{\delta t^{2}}{2} \partial_{t t} \left\langle \vec{A} \right\rangle|_{0} + \frac{\delta t^{3}}{6} \partial_{t t t} \left\langle \vec{A} \right\rangle|_{0} + \mathcal{O}(\delta t^{4}) \quad (23)$$

Then for first order in  $\delta t$  the systematic error is:

$$a_{sys} = \left\| K^+ \left( \frac{1}{2} \partial_{tt} \left\langle \vec{A} \right\rangle |_{t=0} \right) \right\|^2$$

and for second order in  $\delta t$ :

<span id="page-9-3"></span>
$$a_{sys} = \left\| K^{+} \left( \frac{1}{2} \partial_{tt} \left\langle \vec{A} \right\rangle |_{t=0} + \frac{\delta t}{6} \partial_{ttt} \left\langle \vec{A} \right\rangle |_{t=0} \right) \right\|^{2}$$
(24)

Evaluating this second order estimate for  $a_{sys}$  requires to know  $\delta t$  which is our ultimate goal to find. In order to bypass this difficulty, we used the first order estimate of  $a_{sys}$  in Eq. (12) to get a first order estimate of  $\delta t$ , and used that estimate in the second order estimate of  $a_{sys}$  to get a better prediction of  $\delta t$ .

## <span id="page-9-1"></span>A.3 Higher order finite difference approximations

Examining the analytical results we got for the reconstruction error bound in Eq. (22) we can try to improve the reconstruction using higher-order estimates for the derivative. Instead of using the finite difference method with a single forward point (Eq. (6)), we can use forward finite difference method with  $\lambda > 1$  points

$$\partial_t \langle A \rangle_{\psi} = \frac{\sum_{r=0}^{\lambda} w_r \langle A \rangle_{\psi(r \cdot \delta t)}}{\delta t} + \mathcal{O}(\delta t^{\lambda})$$
 (25)

<span id="page-9-2"></span>where  $w_r$  are the weights of each point such that the estimation error is  $\mathcal{O}(\delta t^{\lambda})$ . In that case we will achieve better asymptotic behaviour with respect to the number of measurements (as  $\|\delta c^*\|_{bound} \propto$ 

![](_page_10_Figure_0.jpeg)

Figure S4: Predicting the optimal measurement time using first order (green hollow triangles, Eq. (14)) or second order (blue circles, Eq. (24)) methods in a random 2-local Hamiltonian compared to the measured optimal time (red dots). Here we used 2-ranged observables in a randomized measurement scheme.

 $\sqrt{N^{\frac{\lambda}{\lambda+1}}}$ , Eq. (22)) but the measurement budget will split between  $\lambda$  measurement times. The measurement budget at different times can allocated wisely by finding a set  $\{N_r\}_{r=1}^{\lambda}; \sum_{r=1}^{\lambda} N_r = N$  which minimizes the variance of the statistical error  $\sigma^2 = \sum_{r=1}^{\lambda} w_r^2/N_r$ , which is achieved for

$$N_r = N \frac{|w_r|}{\sum_{r=1}^{\lambda} |w_r|}.$$
 (26)

Hence, the N used in the statistical error should be replaced with  $N_{effective} = N \left( \frac{1}{\sum_{r=1}^{\lambda} |w_r|} \right)^2$ , which yields an additional  $\left( \sum_{r=1}^{\lambda} |w_r| \right)^{\frac{\lambda}{\lambda+1}}$  factor to the re-

yields an additional  $\left(\sum_{r=1} |w_r|\right)$  factor to the reconstruction error bound because of the statistical error (Eq. (22)). Additional factors can arise due to the systematic error.

We examined the results of reconstruction using finite difference with  $\lambda=2$  uniformly spaced forward points

<span id="page-10-1"></span>
$$\partial_t \left\langle A \right\rangle_{\psi} = \frac{-\frac{3}{2} \left\langle A \right\rangle_{\psi(0)} + 2 \left\langle A \right\rangle_{\psi(\delta t)} - \frac{1}{2} \left\langle A \right\rangle_{\psi(2\delta t)}}{\delta t} + \mathcal{O} \left( \delta t^2 \right). \tag{27}$$

Comparing the results we got using 1 forward point finite difference (Eq. (6)) to the results using 2 forward points finite difference (Eq. (27)) we observed that the scaling advantage from the the 2 forward points estimation method yields better reconstruction only for  $N > 10^{11}$  as can be seen in Fig. S5.

# <span id="page-10-0"></span>B Analytic estimate of the statistical reconstruction error

A unique reconstruction requires a set of initial states and measurement bases leading to a full rank recon-

<span id="page-10-2"></span>![](_page_10_Figure_11.jpeg)

Figure S5: Reconstruction error of a random 2-local Hamiltonian as a function of the total number of shots using different methods of derivative estimation: 2 points forward finite difference (blue dots, Eq. (6)) and 3 points forward finite difference (red dots, Eq. (27)).

struction matrix K. More generally, the choice of experiments determines the spectrum of  $K^TK$ , which quantifies the sensitivity of the experiments to the Hamiltonian terms through the statistical error of Eq. (13). We now derive the analytical form of  $K^TK$  when averaged over all experimental configurations, and show that it is sufficient to average over a finite set of local configurations.

For a given set of initial states  $|\psi_{\alpha}\rangle$  and observables  $A_{\beta}$ ,

<span id="page-10-4"></span>
$$(K^T K)_{ij} = -\sum_{\alpha,\beta} \langle i[S_i, A_\beta] \rangle_{\psi_\alpha} \langle i[S_j, A_\beta] \rangle_{\psi_\alpha}, \quad (28)$$

by the definition of K [Eq. (3)]. Here,  $A_{\beta}$  denote all the observables compatible with the measurement basis for the initial state  $|\psi_{\alpha}\rangle$  up to the chosen locality. When averaging over all possible configurations, each of the  $6^n$  initial states is measured in  $3^n$  measurement bases. However, for a given initial state  $|\psi_{\alpha}\rangle$ , each observable  $A_{\beta}$  is compatible with many measurement bases. An observable with support  $s \subseteq [1, \ldots, n]$  is compatible with  $\frac{1}{3^{|s|}}$  of all measurement bases; for instance,  $X_1$  is compatible with  $\frac{1}{3}$  of all bases. Therefore, the average  $\frac{1}{N_{spam}}(K^TK)_{ij}$  over all configurations  $N_{spam} = \frac{1}{3^n \cdot 6^n}$  takes the form

<span id="page-10-3"></span>
$$\sum_{\beta} \frac{1}{3^{|S_{\beta}|}} \sum_{\alpha} \frac{1}{6^n} \left\langle i[S_i, A_{\beta}] \right\rangle_{\psi_{\alpha}} \left\langle i[S_j, A_{\beta}] \right\rangle_{\psi_{\alpha}}. \tag{29}$$

where  $\beta$  runs over all estimated observables. We will now show that this average

- 1. Vanishes for off-diagonal elements where  $S_i \neq S_i$ .
- 2. For the diagonal element corresponding to  $S_i$ , it counts the number of observables  $A_{\beta}$  that fail to commute with  $S_i$ , normalized by the weight  $s_{\beta}$  of  $A_{\beta}$  and the weight  $s_{i,\beta}$  of the commutator  $[S_i, A_{\beta}]$ .

- 3. Depends only on initial state and measurement configurations on sites supported by  $S_i$  or  $S_j$ .
- 4. Vanishes identically for any initial state  $|\psi_{\alpha}\rangle$  when  $S_i, S_j$  do not overlap at least on one site, so that averaging over  $2k_h 1$ -local configurations suffices.

For the first two claims, we invoke the following formula for product state averages of Pauli strings [48]:

<span id="page-11-0"></span>
$$\frac{1}{6^n} \sum_{\alpha} \langle P_r \rangle_{\psi_{\alpha}} \langle P_r' \rangle_{\psi_{\alpha}} = \frac{1}{3^{|s_r|}} \delta_{r,r'}, \tag{30}$$

which states that the average over all initial states vanishes whenever the two Pauli strings are different, and decays with their support  $|s_r|$  otherwise. In our case,  $i[S_i, A_\beta] = 2P_{r_{i,\beta}}$  is a Pauli string since both  $S_i$  and  $A_\beta$  are.

Off-diagonal terms vanish. Considering Eq. (30), it is sufficient to show that different Hamiltonian terms  $S_i \neq S_j$  have different commutators with a shared Pauli observable  $[S_i, A_\beta] \neq [S_j, A_\beta]$ , assuming that both commutators are non-zero. To see this, we recall that any pair of Paulis either commutes or anticommutes. Therefore, if  $[S_i, A_\beta] \neq 0$ , we can write  $[S_i, A_\beta] = \theta_{i,\beta} S_i A_\beta$  for some  $\theta_{i,\beta} \neq 0$ , and similarly for  $S_j$ . If  $[S_i, A_\beta] = [S_j, A_\beta]$ , then  $\theta_{i,\beta} S_i A_\beta = \theta_{j,\beta} S_j A_\beta$ , and  $S_i = \theta_{i,\beta}^{-1} \theta_{j,\beta} S_j$ , in contradiction to our assumption.

Diagonal elements count non-commuting observables. For diagonal elements i = j, Eq. (30) gives a positive contribution whenever  $[S_i, A_{\beta}] \neq 0$ . The average over initial states  $\alpha$  yields a contribution  $\frac{4}{3^{|s_i,\beta|}}$  which depends only on the size of the support  $s_{i,\beta}$  of the commutator  $[S_i, A_{\beta}]$ , such that Eq. (29) becomes

<span id="page-11-2"></span>
$$\sum_{A_{\mathcal{S}}:[S_{i},A_{\mathcal{S}}]\neq 0} \frac{4}{3^{|s_{\mathcal{S}}|+|s_{i,\mathcal{S}}|}},\tag{31}$$

where the sum runs over all observables  $A_{\beta}$  up to the chosen observable locality that fail to commute with  $S_i$ , and the factor 4 comes from the two commutators. For example, for single-site  $S_i$  and  $A_{\beta}$  we get  $4 \cdot \frac{2}{9}$ , since  $\frac{2}{3}$  of all single-site Paulis  $A_{\beta}$  fail some commute with a single-site Hamiltonian Pauli  $S_i$ ; and  $\frac{1}{3}$  of the Pauli measurement bases match each given commutator.

More generally, since our measurement bases average equally over all observables  $A_{\beta}$  with the same support, the value of Eq. (29) depends only on the support of  $S_i$ , i.e. its locality and range. It can be calculated explicitly for a given set of estimated observables  $A_{\beta}$ .

Only local configurations matter. We now show that for each i, j, Eq. (29) depends only on local configurations within the support of  $S_i$  and  $S_j$ . Namely, it does not depend on the initial state configuration on sites supported by the observable  $A_{\beta}$  but not by any of the Hamiltonian terms. We assume that all observables  $A_{\beta}$  with a given support are sampled equally, as in the overlapping local tomography ('cyclic') measurement scheme.

Consider a fixed initial state  $|\psi_{\alpha}\rangle$ , and the average over all observables  $A_{\beta}$  with a given support s:

<span id="page-11-1"></span>
$$\frac{1}{3^{|s|}} \sum_{A_{\beta}: \text{supp}(A_{\beta}) = s} \langle i[S_i, A_{\beta}] \rangle_{\psi_{\alpha}} \langle i[S_j, A_{\beta}] \rangle_{\psi_{\alpha}}. \quad (32)$$

The Paulis of  $A_{\beta}$  on the sites are untouched by  $S_i$  or  $S_j$  factor out of both commutators. When we average over all observables with the same support, only a single observable configuration on those sites matches the initial state  $|\psi_{\alpha}\rangle$ , regardless of the initial state or Hamiltonian terms. Formally, we split  $A_{\beta}$  to the part that intersects  $S_i$  or  $S_j$  and the part that does not,

$$A_{\beta} = A_{\beta}^{s \cap s_{ij}} \cdot A_{\beta}^{s \setminus s_{ij}} = \prod_{i=1}^{|s \cap s_{ij}|} \sigma_{m_i}^{\beta_{m_i}} \prod_{i=|s \cap s_{ij}|+1}^{|s|} \sigma_{m_i}^{\beta_{m_i}}$$
(33)

where m is a site index,  $\beta_m \in \{X, Y, Z\}$  is a Pauli index, and  $s_{ij} \stackrel{\text{def}}{=} \text{supp}(S_i) \cup \text{supp}(S_j)$ . We can then write Eq. (32) as

$$\frac{1}{3^{|s|}} \sum_{\beta_{m_1}, \dots, \beta_{m_{|s\cap s_{ij}|}}} \left\langle i[S_i, A_{\beta}^{s\cap s_{ij}}] \right\rangle_{\psi_{\alpha}} \left\langle i[S_j, A_{\beta}^{s\cap s_{ij}}] \right\rangle_{\psi_{\alpha}}$$

$$(34)$$

$$\cdot \sum_{\beta_{|s\cap s_{ij}|+1},\dots,\beta_{|s|}} \left\langle A_{\beta}^{s\backslash s_{ij}} \right\rangle_{\psi_{\alpha}}^{2}. (35)$$

For any given initial state, the second sum over all observable configurations that are untouched by  $S_i$  or  $S_j$  gives 1. Since the first sum depends only on the initial state configurations in  $s \cap s_{ij}$ , it is sufficient to average over those.

Distant off-diagonal terms vanish for any product state. We now show that  $(K^TK)_{ij}$  vanishes for each of our initial states whenever  $S_i, S_j$  do not overlap. For a given Pauli observable  $A_{\beta}$ , we done its part that intersects  $S_i$  by  $A_{\beta}^{s_i}$ ; namely, we partition  $A_{\beta}$  to

$$A_{\beta} = A_{\beta}^{s_i} \cdot A_{\beta}^{s \setminus s_i}. \tag{36}$$

If  $A_{\beta}$  commutes with  $S_i$ , its contribution to Eq. (29) vanishes. To have a non-vanishing contribution, it must anticommute with  $S_i$ , since Pauli strings either commute or anticommute. In this case, we must have that  $A_{\beta}^{s_i}$  anticommutes with  $S_i$ , since  $A_{\beta}^{s \setminus s_i}$  trivially commutes with it. However,  $A_{\beta}^{s_i}$  commutes with  $S_j$ ,

since they do not overlap. Therefore, since expectation values in product states factorize,

$$\langle i[S_i, A_\beta] \rangle_{\psi_\alpha} \langle i[S_j, A_\beta] \rangle_{\psi_\alpha} =$$
 (37)

$$= \left\langle i[S_i, A_{\beta}^{s_i}] \right\rangle \left\langle A_{\beta}^{s \setminus s_i} \right\rangle \left\langle A_{\beta}^{s_i} \right\rangle \left\langle i[S_i, A_{\beta}^{s \setminus s_i}] \right\rangle. \tag{38}$$

This product includes the expectation values of anticommuting Pauli strings:  $A_{\beta}^{s_i}$  anticommutes with  $i\left[S_i,A_{\beta}^{s_i}\right]$ , since we assumed it anticommutes with  $S_i$ . As our initial states are stabilizer states, their expectation value cannot be non-zero for a pair of anticommuting Pauli strings, leading to a vanishing contribution to Eq. (29) for any Pauli observable  $A_{\beta}$ .

 $2k_h - 1$ -local configurations suffice. We have shown that for pair of Hamiltonian terms  $S_i, S_j$ , it is sufficient to sample local configurations on their shared support; and that it is sufficient to consider Hamiltonian terms that intersect. Therefore,  $\frac{1}{N_{spam}}K^TK$  becomes diagonal with entries described by Eq. (31) if all the local initial state configurations are uniformly sampled within any  $2k_h - 1$ -ranged patch.

#### B.1 Examples for diagonal entry calculations

We would like to evaluate the diagonal entries of  $\frac{1}{N_{spam}}K^TK$  in the limit of all SPAM settings  $N_{spam} \to \infty$  [Eq. (28)] for a few simple cases: (i) 1-local observables and generic Hamiltonian terms, corresponding to the result of Eq. (16) and (ii) 1-local Hamiltonian terms and generic observables.

The diagonal entry for a Hamiltonian term  $S_i$  [Eq. (31)] counts the number of measured observables that do not commute with it, normalized by the weight of the observable and of the commutator. For instance, each 1-local observable  $A_{\beta}$  is compatible with one third of all measurement bases, yielding a normalization factor  $\frac{1}{3}$  for the observable locality  $(s_{\beta} = 1)$ . Given a weight  $k_i$  Hamiltonian term  $S_i$ , any non-zero commutator  $[S_i, A_{\beta}]$  is itself of weight  $k_i$ , vanishing in all but  $\frac{1}{3^{k_i}}$  of all initial states  $(s_{i,\beta} = k_i)$ . Finally, for each of the  $k_i$  sites in the support of  $S_i$  there are two single-site Paulis that differ from it on that site, yielding a combinatorial factor of  $2k_i$  non-commuting observables. We conclude that

$$\frac{1}{N_{spam}}(K^TK)_{ii} = \sum_{\substack{A_{\beta}: [S_i, A_{\beta}] \neq 0}} \frac{4}{3^{|s_{\beta}| + |s_{i,\beta}|}}, = 4 \cdot \frac{2k_i}{3^{k_i + 1}}.$$

As another example, we examine the case of a 1- local Hamiltonian term  $k_i=1$  and range  $k_\beta$  observables in a one-dimensional chain with periodic boundary conditions. In that case  $|s_\beta|=|s_{i,\beta}|$ . For  $k_\beta=2$ -ranged observables,

$$\frac{1}{N_{spam}}(K^TK)_{ii} = \frac{4}{3^{2+2}} \cdot 2 \cdot 2 \cdot 3 = 4 \cdot \frac{4}{3^3}.$$
 (39)

The combinatorial factor consists of three contributions: 2 possible Pauli operators that anticommute with  $S_i$  on the site that intersects with it; 2 possible choices of a neighboring site for the observable support; and 3 possible Pauli operators on the neighboring site. Similarly, for  $k_{\beta}=3$ -ranged observables,  $\frac{1}{N_{spam}}(K^TK)_{ii}=\frac{4}{3^3+3}\cdot 2\cdot 3\cdot 3^2+\frac{4}{3^2+2}\cdot 2\cdot 2\cdot 3=4\cdot \frac{18}{3^4}.$  The left term counts the observables with both range and weight 3, while the right term counts observables with range 3 and weight 2.

The Table below sums results for  $\frac{1}{4p}(K^TK)_{ii}$  with up to range 3 observables and weight 3 Hamiltonian terms:

| $k_{i}$ | 1         | 2          | 3           |
|---------|-----------|------------|-------------|
| 1       | $2/3^{2}$ | $4/3^{3}$  | $18/3^{4}$  |
| 2       | $4/3^{3}$ | $16/3^4$   | $52/3^{5}$  |
| 3       | $6/3^{4}$ | $28/3^{5}$ | $114/3^{6}$ |

The first column and row are the examples calculated above. The columns denote the contribution of all the observables with exact range  $k_{\beta}$  to the diagonal entry. In the rows, we consider terms acting nontrivially on each of  $k_i$  contiguous sites, such that  $k_i$  denotes both the weight and range of the  $S_i$  term. This assumption is not necessary for  $k_{\beta} = 1$ , where the result depends only on the weight of  $S_i$ .

#### B.2 Cyclic measurement scheme in higherdimensional lattices

How many copies of a state  $|\psi\rangle$  on a d-dimensional lattice do we need to measure each k-ranged observable at least once? In 1D we defined a unit cell of length k. To measure all the k-ranged observables, it sufficed to iterate over the  $3^k$  Pauli bases of a single unit cell, repeating measurement bases between different unit cells. Since different unit cell partitions are equivalent up to a permutation, this process yields at least one shot of each observable using exactly  $3^k$  copies of the state.

We can generalize this approach to d-dimensional lattices. We choose a d-dimensional square unit cell of side length k, containing  $k^d$  sites (see 2D case in Fig. S6). As in the 1D case, we evaluate all the k-local observables within it using  $3^{\binom{k^d}{}}$  different copies, repeating the measurement bases between unit cells. This procedure yields at least one sample of any observable residing within length k cube, even if it does not respect the original lattice partition. Similarly, since there are 6 Pauli eigenstates per site,  $6^{k^d}$  initial states cover all the Pauli eigenstates in each length k cube.

The local measurement process we described improves upon the overlapping tomography protocol of Ref. [51] for the special case of geometrically local lattices. The protocol of Ref. [51] recovers all k-local observables (maximal weight k) without assuming any

<span id="page-13-1"></span>![](_page_13_Figure_0.jpeg)

Figure S6: Example of overlapping tomography (cyclic method) in a *d* = 2 dimension square lattice with *k<sup>β</sup>* = 3. The boundary of unit cells is colored in blue for two of the unit cells. In this example we need 3 9 copies of |*ψ*i to get one sample of every 3-ranged observable in the system.

spatial structure. The protocol requires O(log<sup>2</sup> *n*) copies of a state of *n* qudits to recover all observables of a fixed locality to a given worst-case error. Our protocol requires an *n*-independent number of copies to recover all short-ranged observables to a constant average accuracy. It effectively eliminates one log *n* factor, which is required in order to cover all long-ranged observables. The other log *n* factor stems only from the different error metric (worst-case vs. average-case).

### <span id="page-13-0"></span>C XXZ model

Why does the reconstruction error for the *XXZ* Hamiltonians of Eq. [\(17\)](#page-4-1) decrease more rapidly with the measurement count ∆ ∼ *N* <sup>−</sup>1*/*<sup>3</sup> compared to the *N* <sup>−</sup>1*/*<sup>4</sup> scaling of generic 2-local Hamiltonians?

Since the *XXZ* Hamiltonians are real in the computational basis, they are invariant under the antiunitary complex conjugation operator which flips *Yi* 7→ −*Y<sup>i</sup>* [\[54\]](#page-8-3). As these Hamiltonian contain only even combinations of the other Paulis *X, Z* as well, they are actually invariant under a time-reversal symmetry for each axis *α* = 1*,* 2*,* 3 of the Bloch sphere, which flips *σ α i* 7→ −*σ α i* .

Incidentally, each of the 2-periodic cyclic initial states we have chosen in Fig. [3](#page-4-0) is invariant under one of those symmetries, as the spins of each of these states are polarized only within a plane in the Bloch sphere. In other words, each of these states contains only two of the three Paulis, and is invariant under an inversion of the third. We now explain why this implies that for any Pauli observable *A*, either (i) the time derivative vanishes *∂<sup>t</sup>* h*A*i = 0, or (b) the second time-derivative vanishes *∂tt* h*A*i = 0.

Without loss of generality, we focus on the *Y* 7→ −*Y* time reversal symmetry, and consider a real-valued initial state which is invariant under the standard complex conjugation, such as |*ψ*i = |↑↑↑ · · ·i. Each Pauli observable *A* has a definite parity under this symmetry: it is either real (even) or purely imaginary (odd), depending on the parity of its number of *Y* operators. Since the Hamiltonian is real, it flips the parity of *A* under Heisenberg evolution: if *A* is real, then *∂tA* = *i*[*H, A*] is imaginary and vice versa.

Importantly, if an observable *O* and a state *ρ* have definite time reversal parities, they must match for the observable to take an expectation value. If *ρ* is a real density matrix and *O* an imaginary observable, then

$$\operatorname{Tr}(\rho O) = \operatorname{Tr}((\rho O)^T) = \operatorname{Tr}(\rho^T O^T)$$
  
=  $-\operatorname{Tr}(O\rho) = -\operatorname{Tr}(\rho O),$ 

since *O<sup>T</sup>* = (*O*† ) <sup>∗</sup> = *O*<sup>∗</sup> = −*O*, and the trace of any operator is the same as the trace of its transpose.

Therefore, only time-reversal odd observables *A* contribute to the reconstruction in a time-reversal even initial state. If *A* is time-reversal even, then *∂tA* = *i*[*H, A*] is time-reversal odd; in this case, *∂<sup>t</sup>* h*A*i*<sup>ψ</sup>* vanishes for a time-reversal even state |*ψ*i regardless of the particular coefficients of the *XXZ* Hamiltonian. In contrast, time-reversal odd observables *A* have a non-trivial time derivative, since *∂tA* is time-reversal even; however, in this case *∂ttA* = − [*H,* [*H, A*]] is again time reversal odd, so that *∂tt* h*A*i = 0, and the systematic error [Eq. [\(18\)](#page-8-7)] vanishes to first order in *δt*. Therefore, the time-reversal odd observables *A* that participate in the reconstruction can be measured at later times compared to a generic Hamiltonian, leading to an improved scaling of the reconstruction error *N* <sup>−</sup>1*/*<sup>3</sup> according to Eq. [\(22\)](#page-9-2).

This analysis holds for every Pauli observable in a state whose spins are polarized along the *X* − *Z* plane, based on the *Y* 7→ −*Y* symmetry. Since the *XXZ* Hamiltonian is invariant under inversion of any axis of the Bloch sphere, it generalizes to any initial state whose spins are polarized along a plane. The 2 periodic initial states satisfy this condition, explaining the findings of Fig. [3.](#page-4-0) More generally, if a Hamiltonian has time-reversal symmetry along one axis, initial states polarized along the perpendicular plane will yield the improved scaling of the reconstruction error.