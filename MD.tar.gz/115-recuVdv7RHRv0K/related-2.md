## [Weizmann Logo](http://www.weizmann.ac.il) [ECCC](file:///)

## Electronic Colloquium on Computational Complexity

Under the auspices of the [Computational Complexity Foundation \(CCF\)](http://computationalcomplexity.org/foundation)

Search [Login](file:///login/) | [Register](file:///register) | [Classic Style](file:///view/) icon Submit Paper

- • [Home](file:///)
- • [Call for](file:///colloquium/call_for_papers)
- [Papers](file:///colloquium/call_for_papers) • [Reports](file:///reports/menu)
  - ◦ [A-Z](file:///title/)
  - [2025](file:///year/2025) ◦
  - [2024](file:///year/2024) ◦
  - [2023](file:///year/2023) ◦
  - [2025...1994](file:///years/) ◦
  - ◦ [Keywords](file:///keywords/)
- • [Authors](file:///authors/)
- • [Books +](file:///static/books/menu)

## [Lectures](file:///static/books/menu)

- ◦ [Monographs](file:///static/books/monographs/)
- ◦ [Lecture](file:///static/books/lecture_notes/)
  - [Notes](file:///static/books/lecture_notes/)
- ◦ [Online](file:///static/books/online_lectures/)
- [Lectures](file:///static/books/online_lectures/)
- ◦ [Survey](file:///books/survey_papers/)
  - [Papers](file:///books/survey_papers/)
- ◦ [Theses](file:///static/books/theses/)
- ◦ [Position](file:///static/books/position_papers/)
  - [papers](file:///static/books/position_papers/)

# • [About](file:///static/colloquium/menu)

#### [ECCC](file:///static/colloquium/menu)

◦ [Call](file:///colloquium/call_for_papers/) [for](file:///colloquium/call_for_papers/)

[Papers](file:///colloquium/call_for_papers/)

- ◦ [How](file:///static/colloquium/how_to_use/)
  - [to](file:///static/colloquium/how_to_use/)
  - [use](file:///static/colloquium/how_to_use/)
- ◦ [Scientific](file:///colloquium/scientific_board/)
- [Board](file:///colloquium/scientific_board/)
- ◦ [Local](file:///static/colloquium/local_office/)
  - [Office](file:///static/colloquium/local_office/)
- ◦ [Copyright](file:///static/colloquium/copyright_notice/)
- [Notice](file:///static/colloquium/copyright_notice/)
- ◦ [Read](file:///static/colloquium/read_more/)
  - [more...](file:///static/colloquium/read_more/)
- • [Pointers to](file:///static/pointers/menu)
  - ◦ [Books](file:///static/pointers/books/)

- ◦ [Lecture](file:///static/pointers/lecture_notes/)
  - [Notes](file:///static/pointers/lecture_notes/)
- ◦ [Surveys](file:///static/pointers/surveys/)
- ◦ [Home](file:///static/pointers/personal_www_home_pages_of_complexity_theorists/)
  - [pages](file:///static/pointers/personal_www_home_pages_of_complexity_theorists/) [of](file:///static/pointers/personal_www_home_pages_of_complexity_theorists/)
- [theorists](file:///static/pointers/personal_www_home_pages_of_complexity_theorists/)
- ◦ [Current](file:///static/pointers/current_discussions/)
  - [discussions](file:///static/pointers/current_discussions/)
- ◦ [ECCC](file:///static/impressions/impressions)
  - [Impressions](file:///static/impressions/impressions)
- • [Further links](file:///static/links/menu)
  - ◦ [Bibliography](file:///static/links/bibliography_data_bases/)
    - [Data](file:///static/links/bibliography_data_bases/)
    - [Bases](file:///static/links/bibliography_data_bases/)
  - ◦ [Mathematical](file:///static/links/departements_mathematical_resources/)
  - [Resources](file:///static/links/departements_mathematical_resources/)
  - ◦ [Journals](file:///static/links/journals/)
  - ◦ [People](file:///static/links/people/)
  - ◦ [Preprint](file:///static/links/preprint_servers/)
    - [Servers](file:///static/links/preprint_servers/)
  - ◦ [Electronic](file:///static/links/societies_and_electronic_forums/)
  - [Forums](file:///static/links/societies_and_electronic_forums/)
- • [Newsletter](file:///newsletter)

### [RSS-Feed](file:///feeds/reports)

#### **REPORTS > DETAIL:**

## **Paper:**

**TR04-010 | 26th January 2004 00:00** 

Contact Add Comment

**Tolerant Property Testing and Distance Approximation**

[RSS-Feed](file:///feeds/report/2004/010)

[Authors: Mi](file:///report/2004/010/download)[chal Parnas](file:///author/02602), [Dana Ron,](file:///author/86) [Ronitt Rubinfeld](file:///author/02317)

Publication: 2nd February 2004 22:28

Downloads: 4664

TR04-010 Keywords:

[Approximation Algorithms,](file:///keyword/13496) [Clustering](file:///keyword/15583), [Monotonicity](file:///keyword/14818), [Property Testing](file:///keyword/13354)

#### **Abstract:**

A standard property testing algorithm is required to determine with high probability whether a given object has property P or whether it is \epsilon-far from having P, for any given distance parameter \epsilon. An object is said to be \epsilon-far from having property P if at least an \epsilon-fraction of the object should be modified so that it obtains P.

In this paper we study a generalization of standard property testing where the algorithms are required to be more \*tolerant\*. Specifically, a tolerant property testing algorithm is required to accept objects that are \epsilon\_1-close to having a given property P and reject objects that are \epsilon\_2-far from having P, for some parameters 0 <= \epsilon\_1 < \epsilon\_2 <= 1. Another related natural extension of standard property testing that we study, is distance approximation. Here the algorithm should output an estimate \hat{\epsilon} of the distance of the object to P, where there are certain provable upper and lower bounds on \hat{\epsilon} in terms of the correct distance.

We first formalize the notions of tolerant property testing and distance approximation and discuss the relationship between the two tasks, as well as their relationship to standard testing. We then study two problems: The first is distance approximation for monotonicity, and the second is tolerant testing of clustering. We present and analyze algorithms whose query complexity is either polylogarithmic or independent of the size of the input. Our distance approximation algorithm for monotonicity works by defining a certain tree structure by which upper and lower bounds on the distance of the function to monotonicity can be obtained, and then constructing only a small number of random paths in the tree. Our tolerant testing algorithms for clustering for tolerant testing of other cost measures for clustering, as well as for tolerant testing of other properties.

ISSN 1433-8092 | [Imprint](file:///static/website/imprint)