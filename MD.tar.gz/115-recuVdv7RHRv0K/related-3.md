# Quantum boolean functions

# Ashley Montanaro<sup>∗</sup> and Tobias J. Osborne† October 22, 2018

#### Abstract

In this paper we introduce the study of quantum boolean functions, which are unitary operators f whose square is the identity: f <sup>2</sup> = I. We describe several generalisations of well-known results in the theory of boolean functions, including quantum property testing; a quantum version of the Goldreich-Levin algorithm for finding the large Fourier coefficients of boolean functions; and two quantum versions of a theorem of Friedgut, Kalai and Naor on the Fourier spectra of boolean functions. In order to obtain one of these generalisations, we prove a quantum extension of the hypercontractive inequality of Bonami, Gross and Beckner.

# Contents

| 1 | Introduction                                          | 2  |
|---|-------------------------------------------------------|----|
|   | 1.1<br>Summary of results                             | 3  |
|   | 1.2<br>Related work<br>                               | 4  |
| 2 | Preliminaries                                         | 4  |
| 3 | Quantum boolean functions                             | 6  |
| 4 | Examples of quantum boolean functions                 | 7  |
|   | 4.1<br>New quantum boolean functions from old<br><br> | 8  |
| 5 | Fourier analysis                                      | 8  |
| 6 | Testing quantum boolean functions                     | 11 |
|   | 6.1<br>Closeness<br>                                  | 11 |
|   | 6.2<br>The quantum stabilizer test<br><br>            | 12 |
|   | 6.3<br>Testing dictators<br>                          | 15 |

<sup>∗</sup>Department of Computer Science, University of Bristol, Woodland Road, Bristol, BS8 1UB, UK; montanar@cs.bris.ac.uk.

<sup>†</sup>Department of Mathematics, Royal Holloway, University of London, Egham, TW20 0EX, UK; tobias.osborne@rhul.ac.uk.

| 7 | Learning quantum boolean functions                                              | 16 |
|---|---------------------------------------------------------------------------------|----|
|   | 7.1<br>Learning stabilizer operators and approximating Fourier coefficients<br> | 17 |
|   | 7.2<br>The quantum Goldreich-Levin algorithm<br>                                | 19 |
|   | 7.3<br>Learning quantum dynamics<br>                                            | 22 |
| 8 | Noise and quantum hypercontractivity                                            | 24 |
| 9 | A quantum FKN theorem                                                           | 30 |
|   | 9.1<br>Balancing quantum boolean functions<br><br>                              | 30 |
|   | 9.2<br>Exact quantum FKN                                                        | 31 |
|   | 9.3<br>Quantum FKN in the 2-norm<br>                                            | 32 |
|   | 9.4<br>Quantum FKN in the<br>∞-norm<br>                                         | 33 |
|   | 10 Influence of quantum variables                                               | 35 |
|   | 11 Towards a quantum KKL theorem                                                | 38 |
|   | 11.1 A quantum Talagrand's lemma for KKL<br><br>                                | 39 |
|   | 11.2 A KKL theorem for anticommuting quantum boolean functions                  | 40 |
|   | 12 Conclusions and conjectures                                                  | 42 |

# <span id="page-1-0"></span>1 Introduction

Boolean functions stand at the crossroads between many areas of study, such as social science, combinatorics, computational complexity, and statistical mechanics, to name but a few (see, e.g., [\[O'D07\]](#page-45-0) or [\[Wol08\]](#page-46-0) for an introduction). The theory of boolean functions has reached a maturity of sorts, and the foundational results of the subject are now well established.

The advent of quantum algorithms (see, e.g., [\[NC00\]](#page-45-1)) has added a twist to the computational complexity theory landscape of which boolean functions are an integral part, and there are many reasons to expect that this development will have more than superficial consequences. Indeed, quantum algorithmic techniques have already had important consequences within the field of classical complexity theory alone, leading to a simple proof of the closure of PP under intersection [\[Aar05\]](#page-42-0) as well as proofs of new lower bounds for locally decodable codes [\[KdW04\]](#page-44-0), amongst many others.

In this context it is natural to consider a generalisation of the notion of a boolean function to the quantum domain. While there is always a temptation to quantise an existing classical concept, there are other motivations for considering a quantum analogue of the theory of boolean functions. One reason is to develop lower bounds for quantum circuits. Another reason is to understand the propagation of correlations through multipartite quantum systems. Finally, and perhaps most importantly, we hope that a mature theory of quantum boolean functions will lead the way to a proof of a quantum generalisation of the PCP theorem [\[Aha08\]](#page-42-1). We believe this should occur because the extant classical proofs (see, eg., [\[RS06,](#page-45-2) [Din07\]](#page-43-0)) draw heavily on results from the property testing of boolean functions, which, as we'll see, generalise naturally to the quantum domain.

In this paper we pursue one particular generalisation of a boolean function to the quantum domain, namely a unitary operator f which squares to the identity. We provide several arguments for why our definition is a natural generalisation of the classical definition, not least of which are several quantum generalisations of well-known classical results. These quantum generalisations often require new proof techniques, and since they reduce in each case to the classical results when f is diagonal in the computational basis, we sometimes obtain different proofs for the original classical results.

#### <span id="page-2-0"></span>1.1 Summary of results

The main results we obtain can be summarised as follows.

- Quantum property testing. We give quantum tests that determine whether a unitary operator is a tensor product of Pauli operators, or far from any such tensor product; and similarly whether a unitary operator is a Pauli operator acting on only one qubit, or is far from any such operator. These are quantum generalisations of properties considered in the classical field of property testing of boolean functions. In particular, when applied to classical boolean functions, these tests have better parameters than the original classical tests.
- Learning quantum boolean functions. We develop a quantum analogue of the Goldreich-Levin algorithm, which is an important tool for approximately learning boolean functions [GL89, KM93]. This algorithm allows the approximate learning of quantum dynamics, giving a natural counterpart to recent results of Aaronson on approximately learning quantum states [Aar07].
- Hypercontractivity and a quantum FKN theorem. The Friedgut-Kalai-Naor (FKN) theorem [FKN02] states that boolean functions whose Fourier transform is concentrated on the first level approximately depend on a single variable. We prove a quantum analogue of this statement. In order to obtain this result, we state and prove a quantum generalisation of the hypercontractive inequality of Bonami-Gross-Beckner [Bon70, Gro75, Bec75] for functions  $\{0,1\}^n \to \mathbb{R}$ . This generalisation may be of independent interest and has several corollaries. Our result is an alternative generalisation of this inequality to that recently proven by Ben-Aroya et al [BARW08].
- Influences and progress towards a quantum KKL theorem. The Kahn-Kalai-Linial (KKL) theorem [KKL88] states that every balanced boolean function must have a variable with high influence (qv.). Defining a suitable quantum generalisation of the concept of influence, we prove the generalised theorem in several special cases, and conjecture that it holds in full generality. We also prove a weaker variant (a quantum Poincaré inequality).

Our presentation is based on the lecture notes [O'D07], which are an excellent introduction to the field of the analysis of boolean functions.

#### <span id="page-3-0"></span>1.2 Related work

This paper draws heavily on the classical field of the analysis of boolean functions, which for our purposes essentially began with the seminal paper of Kahn, Kalai and Linial [KKL88], which proved that every balanced boolean function must have an influential variable (see Section 10). Since then, a substantial literature has developed, in which statements of interest about boolean functions are proven using mathematical techniques of increasing sophistication, and in particular Fourier analysis. Other important works in this area include a result of Bourgain concerning the Fourier spectrum of boolean functions [Bou02], and a result of Friedgut stating that boolean functions which are insensitive on average are close to depending on a small number of variables [Fri98].

Ideas relating to the analysis of boolean functions have recently proven fruitful in the study of quantum computation. Indeed, the result of Bernstein and Vazirani giving the first super-polynomial separation between quantum and classical computation [BV97] is that quantum computers can distinguish certain boolean functions more efficiently than classical computers can. More recent cases where a quantum advantage is found for classical tasks relating to boolean functions include the quantum Goldreich-Levin algorithm of Adcock and Cleve [AC02]; the work of Buhrman et al [BFNR03] on quantum property testing of classical boolean functions; and the computational learning algorithms of Bshouty and Jackson [BJ99], and also Atici and Servedio [AS07].

Fourier analysis of boolean functions has been used explicitly to obtain two recent results in quantum computation. The first is an exponential separation between quantum and classical one-way communication complexity proven by Gavinsky et al [GKK<sup>+</sup>07]. This separation uses the results of Kahn, Kalai and Linial [KKL88] to lower bound the classical communication complexity of a particular partial function. The second result is a lower bound on the size of quantum random access codes obtained by Ben-Aroya et al [BARW08], in which the key technical ingredient is the proof of a matrix-valued extension of the hypercontractive inequality on which [KKL88] is based.

### <span id="page-3-1"></span>2 Preliminaries

In this section we set up our notation and describe the objects we'll work with in the sequel. We will sometimes use several notations for the same objects. We've made this decision for two reasons. The first is that the notations natural in the study of boolean functions are unnatural in quantum mechanics, and vice versa, and some fluidity with the notation greatly simplifies the transition between these two domains. Secondly, two notations means that practitioners in classical complexity theory and quantum mechanics can (hopefully) adapt to the tools of the other field.

In the classical domain we work with boolean functions of n variables, which are simply functions  $f: \{0,1\}^n \to \{0,1\}$ . We write elements of  $\{0,1\}$  as regular letters, eg. y, and we write elements of  $\{0,1\}^n - strings$  – as boldface letters, eg.,  $\mathbf{x} \equiv x_1x_2 \cdots x_n$ ,  $x_j \in \{0,1\}$ ,  $j=1,2,\ldots,n$ . Similarly, we'll write strings in  $\{0,1,2,3\}^n$  as boldface letters starting at  $\mathbf{s}$ . It is often convenient to exploit the isomorphism between the set  $\{0,1\}^n$  of all strings and the set  $\mathcal{P}([n])$  of all subsets of  $[n] \equiv \{1,2,\ldots,n\}$  by letting  $\mathbf{x}$  define the subset  $S = \{j \in S \mid x_j \neq 0\}$ . We write subsets of [n] as capital letters beginning with S.

There are several elementary functions on  $\{0,1\}^n$  and  $\{0,1,2,3\}^n$  that will be useful in the sequel. Firstly, we define the *support* of a string  $\mathbf{x} \in \{0,1\}^n$ , written  $\text{supp}(\mathbf{x})$ , via

$$\operatorname{supp}(\mathbf{x}) \equiv \{ j \mid x_i \neq 0 \}, \tag{1}$$

and for  $\mathbf{s} \in \{0, 1, 2, 3\}^n$  via

$$\operatorname{supp}(\mathbf{s}) \equiv \{ j \mid s_i \neq 0 \}. \tag{2}$$

We define the Hamming weight  $|\mathbf{x}|$  of a string  $\mathbf{x} \in \{0,1\}^n$  (respectively,  $\mathbf{s} \in \{0,1,2,3\}^n$ ) via  $|\mathbf{x}| \equiv |\operatorname{supp}(\mathbf{x})|$  (respectively,  $|\mathbf{s}| \equiv |\operatorname{supp}(\mathbf{s})|$ ). The intersection of two strings  $\mathbf{s}$  and  $\mathbf{t}$ , written  $\mathbf{s} \cap \mathbf{t}$ , is the set  $\{i : s_i \neq 0, t_i \neq 0\}$ .

We now make the notational switch to identifying  $\{0,1\}$  with  $\{+1,-1\}$  via  $0 \equiv 1$  and  $1 \equiv -1$ . This takes a little getting used to, but is standard in the boolean function literature; it's often abundantly clear from the context which notation is being used. Unless otherwise noted, we'll use the  $\{+1,-1\}$  notation. We identify  $\{0,1\}$  with  $\mathbb{Z}/2\mathbb{Z}$ , with addition written  $x \oplus y$ . We identify  $\{+1,-1\}$  with the multiplicative group of two elements, also isomorphic to  $\mathbb{Z}/2\mathbb{Z}$ , and write products as xy. This second identification still allows us to identify elements of the multiplicative group of two elements with elements of  $\mathbb{Z}$  and to use addition defined as in  $\mathbb{Z}$ . Thus we say that a boolean function is balanced if  $\sum_{\mathbf{x}} f(\mathbf{x}) = 0$  (here we've made the notational switch).

We denote by  $\chi_S$  the linear function on subset S, defined by

$$\chi_S \equiv \prod_{j \in S} x_j. \tag{3}$$

Exploiting the connection between strings and subsets of [n] allows us to write this as

$$\chi_S(\mathbf{x}) \equiv \chi_S(T) \equiv (-1)^{|S \cap T|},$$
(4)

where T is the set defined by  $\mathbf{x}$ .

In the quantum domain we work with the Hilbert space of n qubits. This is the Hilbert space  $\mathcal{H} \equiv (\mathbb{C}^2)^{\otimes n}$ . We write elements of  $\mathcal{H}$  as  $kets |\psi\rangle$ , and the inner product between two kets  $|\phi\rangle$  and  $|\psi\rangle$  is written  $\langle\phi|\psi\rangle$ . There is a distinguished basis for  $\mathcal{H}$ , called the *computational basis*, written  $|\mathbf{x}\rangle$ ,  $\mathbf{x} \in \{0,1\}^n$ , with inner product  $\langle\mathbf{x}|\mathbf{y}\rangle = \delta_{x_1,y_1}\delta_{x_2,y_2}\cdots\delta_{x_n,y_n}$ . We'll also refer to another Hilbert space, namely the Hilbert space  $\mathcal{B}(\mathcal{H})$  of (bounded) operators on  $\mathcal{H}$ . The inner product on  $\mathcal{B}(\mathcal{H})$  is given by the Hilbert-Schmidt inner product  $\langle M, N \rangle \equiv \frac{1}{2^n} \operatorname{tr}(M^{\dagger}N), M, N \in \mathcal{B}(\mathcal{H})$ .

We define the (normalised Schatten) p-norm of a d-dimensional operator f in terms of the singular values  $\{s_j(f)\}$  of f as

$$||f||_p \equiv \left(\frac{1}{d} \sum_{j=1}^d s_j(f)^p\right)^{\frac{1}{p}}.$$
 (5)

If we define  $|f| \equiv \sqrt{f^{\dagger}f}$  (note the overload of notation) we can write the p-norm as

$$||f||_p \equiv \left(\frac{1}{d}\operatorname{tr}(|f|^p)\right)^{\frac{1}{p}}.$$
 (6)

Note the useful equalities  $||f^p||_q = ||f||_{pq}^p$  and  $||f||_q^p = ||f^p||_{q/p}$ . One unfortunate side effect of this normalisation is that  $||f||_p$  is not a submultiplicative matrix norm (except at  $p = \infty$ ). However, we do still have Hölder's inequality [Bha97]: for 1/p + 1/q = 1,

$$|\langle f, g \rangle| \le ||f||_p ||g||_q. \tag{7}$$

### <span id="page-5-0"></span>3 Quantum boolean functions

The first question we attempt to answer is: what is the right quantum generalisation of a classical boolean function? We would expect the concept of a quantum boolean function to at least satisfy the following properties.

- 1. A quantum boolean function should be a unitary operator, so it can be implemented on a quantum computer.
- 2. Every classical boolean function should give rise to a quantum boolean function in a natural way.
- 3. Concepts from classical analysis of boolean functions should have natural quantum analogues.

Happily, we can achieve these requirements with the following definition.

<span id="page-5-1"></span>**Definition 1.** A quantum boolean function of n qubits is a unitary operator f on n qubits such that  $f^2 = \mathbb{I}$ .

We note that it is immediate that f is Hermitian (indeed, all f's eigenvalues are  $\pm 1$ ), and that every unitary Hermitian operator is quantum boolean. Turning to the task of demonstrating the second desired property, there are at least two natural ways of implementing a classical boolean function  $f: \{0,1\}^n \to \{0,1\}$  on a quantum computer. These are as the so-called *bit oracle* [KKVB02]:

$$|\mathbf{x}\rangle|y\rangle \mapsto U_f|\mathbf{x}\rangle|y\rangle \equiv |\mathbf{x}\rangle|y \oplus f(\mathbf{x})\rangle,$$
 (8)

and as what's known as the *phase oracle*:

$$|\mathbf{x}\rangle \mapsto (-1)^{f(\mathbf{x})}|\mathbf{x}\rangle.$$
 (9)

Making the previously discussed notational switch allows us to write the second action as

$$|\mathbf{x}\rangle \mapsto f(\mathbf{x})|\mathbf{x}\rangle.$$
 (10)

When f acts as a bit oracle it defines a unitary operator  $U_f$ . When f acts as a phase oracle, we also obtain a unitary operator, which we simply write as f. As a sanity check of Definition 1 we have that these operators square to the identity:  $U_f^2 = \mathbb{I}$  and  $f^2 = \mathbb{I}$ , and so are examples of quantum boolean functions. It turns out that these two actions are almost equivalent: the phase oracle can be obtained from one use of the bit oracle and a one-qubit ancilla, via

$$f(\mathbf{x})|\mathbf{x}\rangle \frac{1}{\sqrt{2}}(|0\rangle - |1\rangle) \equiv U_f|\mathbf{x}\rangle \frac{1}{\sqrt{2}}(|0\rangle - |1\rangle),$$
 (11)

while the bit oracle can be similarly recovered, given access to a controlled-phase oracle

$$|\mathbf{x}\rangle|y\rangle \mapsto (-1)^{y \cdot f(\mathbf{x})}|\mathbf{x}\rangle|y\rangle,$$
 (12)

where we introduce a one-qubit control register  $|y\rangle$ .

Having accepted Definition 1 for a quantum boolean function we should at least demonstrate that there is something quantum about it. This can be easily accomplished by noting that the theory of quantum boolean functions is at least as general as that of quantum error correction and quantum algorithms for decision problems. Firstly, any quantum error correcting code is a subspace P of  $\mathcal{H}$ . Using this code we define a quantum boolean function via  $f = \mathbb{I} - 2P$ . Secondly, note that any quantum algorithm for a decision problem naturally gives rise to a quantum boolean function in the Heisenberg picture: if U is the quantum circuit in question, and the answer (either 0 or 1, or some superposition thereof) is placed in some output qubit q, then measuring the observable  $A = |0\rangle_q \langle 0| - |1\rangle_q \langle 1|$  (with an implied action as the identity on the remaining qubits) will read out the answer. However, this is equivalent to measuring the observable  $f = U^{\dagger}AU$  on the initial state. It is easy to verify that f is quantum boolean.

### <span id="page-6-0"></span>4 Examples of quantum boolean functions

In this section we introduce several different examples of quantum boolean functions. We have already met our first such examples, namely quantisations of classical boolean functions  $f(\mathbf{x})$ . Our next example quantum boolean functions are aimed at generalising various classes of classical boolean functions.

First, we note the obvious fact that even in the single qubit case, there are infinitely many quantum boolean functions. By contrast, there are only four one-bit classical boolean functions.

**Example 2.** For any real  $\theta$ , the matrix

$$\begin{pmatrix}
\cos\theta & \sin\theta \\
\sin\theta & -\cos\theta
\end{pmatrix}$$
(13)

is a quantum boolean function.

Single qubit quantum boolean functions can of course be combined to form n qubit quantum boolean functions, as follows.

**Definition 3.** Let f be a quantum boolean function. Then we say that f is *local* if it can be written as

$$f = U_1 \otimes U_2 \otimes \dots \otimes U_n, \tag{14}$$

where  $U_j$  is a  $2 \times 2$  matrix satisfying  $U_j^2 = \mathbb{I}, \forall j \in [n]$ .

Local quantum boolean functions are the natural generalisation of linear boolean functions (indeed, every linear boolean function is a local quantum boolean function). One might reasonably argue that local quantum boolean functions aren't really quantum: after all, there exists a local rotation which diagonalises such an operator and reduces it to a classical linear boolean function. The next example illustrates that the generic situation is probably very far from this.

**Example 4.** Let  $P^2 = P$  be a projector. Then  $f = \mathbb{I} - 2P$  is a quantum boolean function. In particular, if  $|\psi\rangle$  is an arbitrary quantum state, then  $f = \mathbb{I} - 2|\psi\rangle\langle\psi|$  is a quantum boolean function.

If we set  $|\psi\rangle = \frac{1}{\sqrt{2}}(|\mathbf{0}\rangle + |\mathbf{1}\rangle)$  then we see that there is no local rotation  $V_1 \otimes V_2 \otimes \cdots \otimes V_n$  which diagonalises  $f = \mathbb{I} - 2|\psi\rangle\langle\psi|$ .

#### <span id="page-7-0"></span>4.1 New quantum boolean functions from old

There are several ways to obtain new quantum boolean functions from existing quantum boolean functions. We summarise these constructions below.

**Lemma 5.** Let f be a quantum boolean function and U be a unitary operator. Then  $U^{\dagger}fU$  is a quantum boolean function.

**Lemma 6.** Let h be a Hermitian operator. Then f = sgn(h) is a quantum boolean function, where

$$sgn(x) = \begin{cases} 1, & x > 0 \\ -1, & x \le 0, \end{cases}$$
 (15)

and as usual the notation f = g(h), for a Hermitian operator h, means the operator obtained by applying the function  $g : \mathbb{R} \to \mathbb{R}$  to the eigenvalues of h.

<span id="page-7-2"></span>**Lemma 7.** Let  $\alpha_j \in \mathbb{R}$ ,  $j \in [m]$ , satisfy  $\sum_{j=1}^m \alpha_j^2 = 1$  and  $\{f_j\}$ ,  $j \in [m]$ , be a set of anticommuting quantum boolean functions, i.e.

$$\{f_j, f_k\} \equiv f_j f_k + f_k f_j = 2\delta_{jk} \mathbb{I}. \tag{16}$$

Then

$$f = \sum_{j=1}^{m} \alpha_j f_j \tag{17}$$

is a quantum boolean function.

*Proof.* Squaring f gives

$$f^{2} = \sum_{j=1}^{m} \alpha_{j}^{2} f_{j}^{2} + \sum_{j < k} \alpha_{j} \alpha_{k} \{ f_{j}, f_{k} \} = \mathbb{I}.$$
 (18)

That f is Hermitian follows because it is a real-linear combination of Hermitian operators.

# <span id="page-7-1"></span>5 Fourier analysis

It is well-known that every function  $f:\{0,1\}^n\to\mathbb{R}$  can be expanded in terms of the characters of the group  $(\mathbb{Z}/2\mathbb{Z})^n$ . These characters are given by the set of linear functions  $\chi_S(T)=(-1)^{|S\cap T|}$  (we are identifying input strings  $\mathbf{x}$  with the subset T). This expansion is called the Fourier transform over  $(\mathbb{Z}/2\mathbb{Z})^n$ .

The use of Fourier analysis in the study of boolean functions was pioneered by Kahn, Kalai, and Linial, who were responsible for the eponymous KKL theorem [KKL88], and has facilitated many of the core foundational results relating to boolean functions. We seek an analogous expansion for quantum boolean functions.

Our quantum analogues of the characters of  $\mathbb{Z}/2\mathbb{Z}$  will be the Pauli matrices  $\{\sigma^0, \sigma^1, \sigma^2, \sigma^3\}^1$ . These are defined as

$$\sigma^0 = \begin{pmatrix} 1 & 0 \\ 0 & 1 \end{pmatrix}, \ \sigma^1 = \begin{pmatrix} 0 & 1 \\ 1 & 0 \end{pmatrix}, \ \sigma^2 = \begin{pmatrix} 0 & -i \\ i & 0 \end{pmatrix}, \ \text{and} \ \sigma^3 = \begin{pmatrix} 1 & 0 \\ 0 & -1 \end{pmatrix}. \tag{19}$$

It is clear that the Pauli operators are quantum boolean functions. A tensor product of Paulis (also known as a *stabilizer operator*) is written as  $\sigma^{\mathbf{s}} \equiv \sigma^{s_1} \otimes \sigma^{s_2} \otimes \cdots \otimes \sigma^{s_n}$ , where  $s_j \in \{0, 1, 2, 3\}$ . We use the notation  $\sigma_i^j$  for the operator which acts as  $\sigma^j$  at the *i*'th position, and trivially elsewhere.

Where convenient we'll use one of two other different notations to refer to the operators  $\sigma^{\mathbf{s}}$ , namely as  $\chi_{\mathbf{s}}$  and as  $|\mathbf{s}\rangle$ . We use the first of these alternate notations to bring out the parallels between the classical theory of boolean functions and the quantum theory, and the second to emphasise the Hilbert space structure of  $\mathcal{B}(\mathcal{H})$ . We write the inner products in each case as

$$\langle \mathbf{s} | \mathbf{t} \rangle \equiv \frac{1}{2^n} \operatorname{tr}((\sigma^{\mathbf{s}})^{\dagger} \sigma^{\mathbf{t}}) \equiv \langle \chi_{\mathbf{s}}, \chi_{\mathbf{t}} \rangle.$$
 (20)

The set of stabilizer operators is orthonormal with respect to the Hilbert-Schmidt inner product, and thus forms a basis for the vector space  $\mathcal{B}(\mathcal{H})$ . So we can express any (bounded) operator f on n qubits in terms of stabilizer operators, with the explicit expansion

$$f = \sum_{\mathbf{s} \in \{0,1,2,3\}^n} \hat{f}_{\mathbf{s}} \chi_{\mathbf{s}},\tag{21}$$

where  $\hat{f}_{\mathbf{s}} = \langle \chi_{\mathbf{s}}, f \rangle$ . In an abuse of terminology, we call the set  $\{\hat{f}_{\mathbf{s}}\}$  indexed by  $\mathbf{s} \in \{0,1,2,3\}^n$  the Fourier coefficients of f. Note that, if f is Hermitian, these coefficients are all real. This expansion is well-known in quantum information theory and, for example, was recently used by Kempe et al [KRUW08] to give upper bounds on fault-tolerance thresholds.

We extend the definition of support to operators via

$$\operatorname{supp}(f) \equiv \bigcup_{\mathbf{s} \mid \hat{f}_{\mathbf{s}} \neq 0} \operatorname{supp}(\mathbf{s}). \tag{22}$$

Similarly, we define the weight wgt(M) of an operator M via  $wgt(M) \equiv |supp(M)|$ .

**Definition 8.** Let f be a quantum boolean function. If  $|\operatorname{supp}(f)| = k$  then we say that f is a k-junta. If k = 1 then we say that f is a dictator. If k = 0 then we say that f is constant.

We note that while, classically, there is a distinction between dictators (functions  $f: \{0,1\}^n \to \{0,1\}$  such that  $f(\mathbf{x}) = x_i$  for some i) and so-called *anti-dictators* (functions where  $f(\mathbf{x}) = 1 - x_i$  for some i), there is no such distinction in our terminology here.

<span id="page-8-0"></span>The Pauli matrices are often written as  $\sigma^0 \equiv \mathbb{I}$ ,  $\sigma^1 \equiv \sigma^x$ ,  $\sigma^2 \equiv \sigma^y$ , and  $\sigma^3 \equiv \sigma^z$ .

Our definition of  $\{\hat{f}_{\mathbf{s}}\}$  as the Fourier coefficients for an operator f is no accident. Indeed, it turns out that when one expands a boolean function f (represented as a phase oracle) in terms of  $\chi_{\mathbf{s}}$  then we recover the classical Fourier transform of f.

**Proposition 9.** Let f be a boolean function  $f: \{0,1\}^n \to \{1,-1\}$ . Then if f acts as  $f|\mathbf{x}\rangle = f(\mathbf{x})|\mathbf{x}\rangle$ , and if

$$f = \sum_{\mathbf{s}} \hat{f}_{\mathbf{s}} \chi_{\mathbf{s}},\tag{23}$$

then the set  $\{\hat{f}_{\mathbf{s}}\}$  are given by

$$\hat{f}_{\mathbf{s}} = \begin{cases} 0, & \mathbf{s} \notin \{0, 3\}^n, \\ \frac{1}{2^n} \sum_{T \subset [n]} (-1)^{|S \cap T|} f(T), & \mathbf{s} \in \{0, 3\}^n, \end{cases}$$
(24)

where  $S = \text{supp}(\mathbf{s})$  and T is the support of the string  $\mathbf{t} = t_1 t_2 \cdots t_n$ , where  $t_j = 0$  if  $j \notin T$  and  $t_j = 3$  if  $j \in T$ .

*Proof.* Because  $f(\mathbf{x})$  is diagonal in the computational basis we immediately learn that  $\langle \chi_{\mathbf{s}}, f \rangle = 0$  for any  $\mathbf{s} \notin \{0, 3\}^n$ . When  $\mathbf{s} \in \{0, 3\}^n$  we have that

$$\hat{f}_{\mathbf{s}} = \langle \chi_{\mathbf{s}}, f \rangle = \frac{1}{2^n} \operatorname{tr} \left( f \prod_{j \in \operatorname{supp}(\mathbf{s})} \sigma_j^3 \right)$$

$$= \frac{1}{2^n} \sum_{\mathbf{x}} \left( \prod_{j \in \operatorname{supp}(\mathbf{s})} (-1)^{x_j} \right) f(\mathbf{x}) = \frac{1}{2^n} \sum_{T \subset [n]} (-1)^{|S \cap T|} f(T).$$
(25)

We also immediately have the quantum analogues of Plancherel's theorem and Parseval's equality.

**Proposition 10.** Let f and g be operators on n qubits. Then  $\langle f, g \rangle = \sum_{\mathbf{s}} \hat{f}_{\mathbf{s}}^* \hat{g}_{\mathbf{s}}$ . Moreover,  $||f||_2^2 = \sum_{\mathbf{s}} |\hat{f}_{\mathbf{s}}|^2$ . Thus, if f is quantum boolean,  $\sum_{\mathbf{s}} \hat{f}_{\mathbf{s}}^2 = 1$ .

It is often convenient to decompose the Fourier expansion of an operator into different levels. An arbitrary n-qubit operator f can be expanded as

$$f = \sum_{\mathbf{s}} \hat{f}_{\mathbf{s}} \chi_{\mathbf{s}} = \sum_{k=0}^{n} f^{-k}, \tag{26}$$

where

$$f^{=k} \equiv \sum_{\mathbf{s}, |\mathbf{s}| = k} \hat{f}_{\mathbf{s}} \chi_{\mathbf{s}}.$$
 (27)

(One can define  $f^{< k}$ , etc., similarly.) The weight of f at level k is then defined as  $||f^{=k}||_2^2$ . A natural measure of the complexity of f is its degree, which is defined as

$$\deg(f) \equiv \max_{\mathbf{s}, \hat{f}_{\mathbf{s}} \neq 0} |\mathbf{s}|. \tag{28}$$

We pause to note an important difference between quantum and classical boolean functions. In the classical case, it is easy to show that every non-zero Fourier coefficient of a boolean function on n bits is at least  $2^{1-n}$  in absolute value. However, this does not hold for quantum boolean functions. Consider the operator

<span id="page-10-2"></span>
$$f = \epsilon \,\sigma^1 \otimes \sigma^1 + \sqrt{1 - \epsilon^2} \,\sigma^2 \otimes \mathbb{I}. \tag{29}$$

By Lemma 7, this is a quantum boolean function for any  $0 \le \epsilon \le 1$ . Taking  $\epsilon \to 0$ , we see that the coefficient of  $\sigma^1 \otimes \sigma^1$  may be arbitrarily small.

### <span id="page-10-0"></span>6 Testing quantum boolean functions

The field of classical property testing solves problems of the following kind. Given access to a boolean function f that is promised to either have some property, or to be "far" from having some property, determine which is the case, using a small number of queries to f. Property testers are an important component of many results in classical computer science, e.g. [Hås01, Din07]; see the review [Fis01] for an introduction to the area.

In this section we describe property testing for *quantum* boolean functions: we give quantum algorithms which determine whether a unitary operator, implemented as an oracle, has the property of being, variously, a stabilizer operator, or both a stabilizer operator and a dictator. These tests differ substantially from their classical counterparts and typically require fewer queries. However, as with their classical equivalents, we use Fourier analysis to bound their probabilities of success.

We note that Buhrman et al [BFNR03] have already shown that quantum computers can obtain an advantage over classical computers for the property testing of *classical* boolean functions.

#### <span id="page-10-1"></span>6.1 Closeness

The tests that we define will, informally, output either that a unitary operator has some property, or is "far" from any operator with that property. In order to define the concept of property testing of quantum boolean functions, we thus need to define what it means for two operators to be close.

**Definition 11.** Let f and g be two operators. Then we say that f and g are  $\epsilon$ -close if  $||f-g||_2^2 \leq 4\epsilon$ .

In quantum theory, it is often natural to use the infinity, or sup, norm to measure closeness of operators (i.e., the magnitude of the largest eigenvalue). However, the 2-norm seems more intuitive when dealing with boolean functions; for example, if we produce a pair of quantum boolean functions f, g from any classical boolean functions that differ at any position, then  $||f - g||_{\infty} = 2$ . Intuitively, the 2-norm tells us how the function behaves on average, and the infinity norm tells us about the worst case behaviour. There is also the following relationship to unitary operator discrimination.

**Proposition 12.** Given a unitary operator f promised to be one of two unitary operators  $f_1$ ,  $f_2$ , there is a procedure that determines whether  $f = f_1$  or  $f = f_2$  with one use of f and success probability

$$\frac{1}{2} + \frac{1}{2}\sqrt{1 - |\langle f_1, f_2 \rangle|^2}. (30)$$

*Proof.* The proof rests on the fundamental result of Holevo and Helstrom [Hol73, Hel76] which says that the exact minimum probability of error that can be achieved when discriminating between two pure states  $|\psi_1\rangle$  and  $|\psi_2\rangle$  with a priori probabilities p and 1-p is given by

$$\mathbb{P}[\text{test succeeds}] = \frac{1}{2} + \frac{1}{2}\sqrt{1 - 4p(1-p)|\langle\psi_1|\psi_2\rangle|^2}.$$
 (31)

We now apply  $f_1$  and  $f_2$  to halves of two maximally entangled states  $|\Phi\rangle \equiv \frac{1}{2^{n/2}} \sum_{\mathbf{x}} |\mathbf{x}\rangle |\mathbf{x}\rangle$ . This produces the states

$$|f_1\rangle \equiv f_1 \otimes \mathbb{I}|\Phi\rangle, \quad \text{and} \quad |f_2\rangle \equiv f_2 \otimes \mathbb{I}|\Phi\rangle.$$
 (32)

The overlap between these two states can be calculated as follows:

$$\langle f_1 | f_2 \rangle = \frac{1}{2^n} \sum_{\mathbf{x}, \mathbf{y}} \langle \mathbf{y} | \langle \mathbf{y} | (f_1^{\dagger} f_2) \otimes \mathbb{I} | \mathbf{x} \rangle | \mathbf{x} \rangle$$

$$= \frac{1}{2^n} \sum_{\mathbf{x}, \mathbf{y}} \langle \mathbf{y} | f_1^{\dagger} f_2 | \mathbf{x} \rangle \langle \mathbf{y} | \mathbf{x} \rangle$$

$$= \frac{1}{2^n} \sum_{\mathbf{x}} \langle \mathbf{x} | f_1^{\dagger} f_2 | \mathbf{x} \rangle = \frac{1}{2^n} \operatorname{tr}(f_1^{\dagger} f_2) = \langle f_1, f_2 \rangle.$$
(33)

The lemma follows when we apply the Holevo-Helstrom result to  $|f_1\rangle$  and  $|f_2\rangle$  and minimise over p.

#### <span id="page-11-0"></span>6.2 The quantum stabilizer test

In this subsection we describe a quantum test, the quantum stabilizer test, which decides, using only two queries, whether a unitary operator f is either  $\epsilon$ -close to a stabilizer operator  $\chi_s$  up to a phase, or is far from any such operator. We also describe a test which is conjectured to decide whether a unitary operator is  $\epsilon$ -close to local or not.

The idea behind our tests is very simple: suppose f is a unitary operator, and we want to work out if it is a stabilizer, i.e. if  $f = \chi_s$  for some s. One way to do this is to apply f to the halves of n maximally entangled states resulting in a quantum state  $f \otimes \mathbb{I}|\Phi\rangle$ . If f is local then the result will just be a tensor product of n (possibly rotated) maximally entangled states, and if f is a stabilizer then it should be an n-fold product of one of four possible states. If not, then there will be entanglement between the n subsystems. The way to test this hypothesis is to create another identical state  $f \otimes \mathbb{I}|\Phi\rangle$  by again applying f to another set of n maximally entangled states and separately apply an equality test to each of the n subsystems which are meant to be disentangled from each other.

**Definition 13.** Let f be a unitary operator on n qubits. The quantum stabilizer and locality tests proceed as follows.

1. Prepare 4n quantum registers in the state

$$|\Phi\rangle_{\mathbf{A}\mathbf{A}'}|\Phi\rangle_{\mathbf{B}\mathbf{B}'} \equiv \frac{1}{2^n} \sum_{\mathbf{x},\mathbf{y}} |\mathbf{x}\rangle_{\mathbf{A}} |\mathbf{x}\rangle_{\mathbf{A}'} |\mathbf{y}\rangle_{\mathbf{B}} |\mathbf{y}\rangle_{\mathbf{B}'} = |\phi\rangle_{\mathbf{A}\mathbf{A}'}^{\otimes n} \otimes |\phi\rangle_{\mathbf{B}\mathbf{B}'}^{\otimes n}, \tag{34}$$

where  $|\phi\rangle \equiv \frac{1}{\sqrt{2}} \sum_{x \in \{\pm 1\}} |xx\rangle$ , and  $\mathbf{A} = A_1 A_2 \cdots A_n$ ,  $\mathbf{A}' = A'_1 A'_2 \cdots A'_n$ ,  $\mathbf{B} = B_1 B_2 \cdots B_n$ , and  $\mathbf{B}' = B'_1 B'_2 \cdots B'_n$ .

2. Apply f to  $\mathbf{A}$  and once more to  $\mathbf{B}$  to give

$$|f\rangle|f\rangle = f_{\mathbf{A}} \otimes \mathbb{I}_{\mathbf{A}'} \otimes f_{\mathbf{B}} \otimes \mathbb{I}_{\mathbf{B}'}|\Phi\rangle|\Phi\rangle.$$
 (35)

3. To test if f is a stabilizer measure the equality observable<sup>2</sup>:

$$EQ = \left(\sum_{s=0}^{3} |s\rangle_{AA'} \langle s| \otimes |s\rangle_{BB'} \langle s|\right)^{\otimes n}, \tag{36}$$

where

$$|s\rangle \equiv \chi_s \otimes \mathbb{I}|\phi\rangle, \quad s \in \{0, 1, 2, 3\},$$
 (37)

giving

$$\mathbb{P}[\text{test accepts}] = \langle f | \langle f | \text{EQ} | f \rangle | f \rangle. \tag{38}$$

4. To test locality measure the swap observable

$$SW = \frac{1}{2^n} \left( \mathbb{I}_{AA':BB'} + SWAP_{AA':BB'} \right)^{\otimes n}, \tag{39}$$

where  $SWAP_{X:Y}$  is the operator that swaps the two subsystems X and Y. This gives

$$\mathbb{P}[\text{test accepts}] = \langle f | \langle f | \text{sw} | f \rangle | f \rangle. \tag{40}$$

We now prove the following

**Proposition 14.** Suppose that a unitary operator f passes the quantum stabilizer test with probability  $1 - \epsilon$ , where  $\epsilon < 1/2$ . Then f is  $\epsilon$ -close to an operator  $e^{i\phi}\chi_{\mathbf{s}}$ ,  $\mathbf{s} \in \{0, 1, 2, 3\}^n$ , for some phase  $\phi$ . If f is a stabilizer operator then it passes the stabilizer test with probability 1.

*Proof.* Expand f in the Fourier basis as

<span id="page-12-1"></span>
$$f = \sum_{\hat{\mathbf{s}}} \hat{f}_{\mathbf{s}} \chi_{\mathbf{s}}. \tag{41}$$

Noting that

$$\langle f | \langle f | \mathrm{EQ} | f \rangle | f \rangle = \sum_{\mathbf{s}, \mathbf{t}} |\hat{f}_{\mathbf{s}}|^2 |\hat{f}_{\mathbf{t}}|^2 \langle \mathbf{t} \mathbf{t} | \mathbf{s} \mathbf{s} \rangle,$$

<span id="page-12-0"></span><sup>&</sup>lt;sup>2</sup>This is not quite the same as measuring both subsystems and checking if the result is equal, as that would destroy coherent superpositions like  $1/\sqrt{2}(|00\rangle + |11\rangle)$  which would otherwise be left undisturbed by measurement of EQ.

we see that

$$\mathbb{P}[\text{test accepts}] = \sum_{\mathbf{s}} |\hat{f}_{\mathbf{s}}|^4. \tag{42}$$

Now, thanks to Parseval's relation, we have that

$$1 = \sum_{\mathbf{s}} |\hat{f}_{\mathbf{s}}|^2,\tag{43}$$

and, given that the test passes with probability  $1 - \epsilon$ , we thus have

$$1 - \epsilon \le \sum_{\mathbf{s}} |\hat{f}_{\mathbf{s}}|^4 \le \left( \max_{\mathbf{s}} |\hat{f}_{\mathbf{s}}|^2 \right) \sum_{\mathbf{s}} |\hat{f}_{\mathbf{s}}|^2 = \max_{\mathbf{s}} |\hat{f}_{\mathbf{s}}|^2.$$
 (44)

So, according to Parseval, there is exactly one term  $|\hat{f}_{\mathbf{s}}|^2$  in the expansion (41) which is at least  $1 - \epsilon$ , and the rest are each at most  $\epsilon$ . Thus f is  $\epsilon$ -close to  $e^{i\phi}\chi_{\mathbf{s}}$  for some phase  $\phi$  (we have that  $|\langle f, \chi_{\mathbf{s}} \rangle| \geq \sqrt{1 - \epsilon}$ ).

Remark 15. The stabilizer test is a quantum generalisation of the classical linearity test of Blum, Luby, and Rubenfeld [BLR93] (the BLR test). When interpreted in quantum language the BLR test can be seen as a method to test if a quantum boolean function diagonal in the computational basis is close to a tensor product of  $\sigma^3$ s. (A task for which the stabilizer test can also be applied.) It is notable that the BLR test requires three queries to f in order to achieve the same success probability as its quantum counterpart, which only requires two queries. Thus, the stabilizer test can be said to have better parameters than its classical counterpart.

Now we turn to the quantum locality test.

**Proposition 16.** The probability that the quantum locality test accepts when applied to an operator f is equal to

$$\frac{1}{2^n} \left( \sum_{S \subset [n]} \operatorname{tr}(\rho_S^2) \right),\tag{45}$$

where  $\rho_S$  is the partial trace of  $|f\rangle\langle f|$  over all subsystems  $A_jA'_j$  with  $j \notin S$ , and we define  $\operatorname{tr}(\rho_0^2) = 1$ .

*Proof.* The proof proceeds via direct calculation:

$$\mathbb{P}[\text{test accepts}] = \langle f | \langle f | \left( \frac{\mathbb{I}_{AA':BB'} + \text{SWAP}_{AA':BB'}}{2} \right)^{\otimes n} | f \rangle | f \rangle$$

$$= \frac{1}{2^n} \sum_{S \subset [n]} \langle f | \langle f | \text{SWAP}_{A_S A'_S:B_S B'_S} | f \rangle | f \rangle$$

$$= \frac{1}{2^n} \sum_{S \subset [n]} \text{tr}(\text{SWAP}_{A_S A'_S:B_S B'_S} \rho_S \otimes \rho_S)$$

$$= \frac{1}{2^n} \sum_{S \subset [n]} \text{tr}(\rho_S^2),$$
(46)

where we use the notation  $A_S$  for an operator which is applied to the subsystems S, and acts as the identity elsewhere.

It is easy to see that if f is local then the probability the quantum locality test accepts is equal to 1. We have been unable to show that if the test accepts with probability greater than  $1 - \epsilon$  then f is close to being local. Thus we have the following

<span id="page-14-1"></span>**Conjecture 17.** Suppose f passes the quantum locality test with probability  $\geq 1 - \epsilon$ . Then there exist  $U_j$ ,  $j \in [n]$ , with  $U_j^2 = \mathbb{I}$  such that

$$\langle f, U_1 \otimes U_2 \otimes \dots \otimes U_n \rangle \ge 1 - 2\epsilon.$$
 (47)

#### <span id="page-14-0"></span>6.3 Testing dictators

In this subsection we describe a quantum test — a quantisation of the Håstad test [Hås01] — which tests whether a unitary operator f is  $\epsilon$ -close to a dictator. In fact, we give two such tests. The first determines whether f is close, up to a phase, to a dictator which is also a stabilizer operator (a *stabilizer dictator*). The second is intended to determine whether f is close to a dictator. As with the situation for quantum locality testing, we are able to analyse the first test, but leave the second as a conjecture.

The dictator — or quantum Håstad — test is defined as follows.

**Definition 18.** Let f be a unitary operator and let  $0 \le \delta \le 1$ . Then the quantum Håstad test proceeds as follows.

1. Prepare 4n quantum registers in the state

$$|\Phi\rangle_{\mathbf{A}\mathbf{A}'}|\Phi\rangle_{\mathbf{B}\mathbf{B}'}.$$
 (48)

(Our notation is identical to that of the quantum locality test.)

2. Apply f to  $\mathbf{A}$  and once more to  $\mathbf{B}$  to give

$$|f\rangle|f\rangle = f_{\mathbf{A}} \otimes \mathbb{I}_{\mathbf{A}'} \otimes f_{\mathbf{B}} \otimes \mathbb{I}_{\mathbf{B}'}|\Phi\rangle|\Phi\rangle.$$
 (49)

3. To test if f is close to a stabilizer dictator measure the  $\delta$ -equality POVM given by the operators  $\{EQ_{\delta}, \mathbb{I} - EQ_{\delta}\}$ , where

$$EQ_{\delta} = \left( |00\rangle\langle 00| + (1 - \delta) \sum_{s=1}^{3} |s\rangle_{AA'}\langle s| \otimes |s\rangle_{BB'}\langle s| \right)^{\otimes n}.$$
 (50)

This measurement is easy to implement by flipping a  $\delta$ -biased coin, and gives

$$\mathbb{P}[\text{test accepts}] = \langle f | \langle f | \text{EQ}_{\delta} | f \rangle | f \rangle. \tag{51}$$

4. To test if f is a dictator measure the  $\delta$ -swap observable

$$sw_{\delta} = \frac{1}{2^n} \left( T(\delta)_{AA':BB'} + \sqrt{T(\delta)} swap \sqrt{T(\delta)}_{AA':BB'} \right)^{\otimes n},$$
 (52)

where

$$T(\delta) = \sum_{s,t} (1 - \delta)^{\frac{|s| + |t|}{2}} |s, t\rangle \langle s, t|$$
(53)

(recall that |s| = 1 if s > 0, for  $s \in \{0, 1, 2, 3\}$ ), giving

$$\mathbb{P}[\text{test accepts}] = \langle f | \langle f | \text{sw} | f \rangle | f \rangle. \tag{54}$$

We now prove the following

**Proposition 19.** Suppose that a unitary operator f passes the stabilizer Håstad test with  $\delta = \frac{3}{4}\epsilon$  with probability  $1 - \epsilon$ . Then f is  $\epsilon$ -close, up to a phase, to  $\mathbb{I}$  or a stabilizer dictator. (We assume  $\epsilon \leq 0.01$ .)

*Proof.* Write the Fourier expansion of f as follows:

$$f = \sum_{\mathbf{s}} \hat{f}_{\mathbf{s}} \chi_{\mathbf{s}}.$$
 (55)

It is easy to verify that

$$\mathbb{P}[\text{test accepts}] = \sum_{\mathbf{s}} (1 - \delta)^{|\mathbf{s}|} |\hat{f}_{\mathbf{s}}|^4.$$
 (56)

Now suppose that f is a stabilizer dictator, up to a phase, on some variable  $j \in [n]$ , i.e., f is  $e^{i\phi}\sigma_j^s$ , for some  $s \in \{0, 1, 2, 3\}$ . Then f passes the quantum Håstad test with probability

$$\mathbb{P}[\text{test accepts}] = (1 - \delta)|\hat{f}_{\mathbf{s}}|^4 = 1 - \delta. \tag{57}$$

On the other hand, suppose that

$$1 - \epsilon \le \mathbb{P}[\text{test accepts}] \le \left(\sum_{\mathbf{s}} |\hat{f}_{\mathbf{s}}|^2\right) \max_{\mathbf{s}} (1 - \delta)^{|\mathbf{s}|} |\hat{f}_{\mathbf{s}}|^2 = \max_{\mathbf{s}} \left(1 - \frac{3}{4}\epsilon\right)^{|\mathbf{s}|} |\hat{f}_{\mathbf{s}}|^2. \tag{58}$$

Since  $(1-\delta)^{|\mathbf{s}|} \le 1$  it follows that there exists some  $\mathbf{s}$  such that  $|\hat{f}_{\mathbf{s}}|^2 \ge 1 - \epsilon$ . Using the fact that  $(1-\frac{3}{4}\epsilon)^{|\mathbf{s}|} < 1 - \epsilon$  for  $\mathrm{supp}(\mathbf{s}) \ge 2$ , we know that this maximum occurs on a string  $\mathbf{s}$  with support one or zero. That is, there exists a Fourier coefficient of magnitude at least  $1-\epsilon$  on a string with support at most one.

We have been unable to prove the corresponding result for the full quantum dictator test, so we leave this as a conjecture.

<span id="page-15-1"></span>Conjecture 20. Suppose that a unitary operator f passes the quantum Håstad dictator test with  $\delta = \frac{3}{4}\epsilon$  with probability  $1 - \epsilon$ . Then f is  $\epsilon$ -close, up to a phase, to  $\mathbb{I}$  or a dictator. (Assume  $\epsilon \leq 0.01$ .)

# <span id="page-15-0"></span>7 Learning quantum boolean functions

The purpose of this section is to describe a family of results in the spirit of the *Goldreich-Levin algorithm* [GL89], an algorithm which was originally defined in a cryptographic context, but was shown by Kushilevitz and Mansour [KM93] to be a useful tool for learning boolean functions. Continuing the theme of the previous sections, we'll see that quantum computers are polynomially more efficient at learning tasks for boolean functions. Heuristically, this is because quantum computers can exploit quantum superposition to carry out "super-dense" coding [NC00], allowing us to pack more information in a single quantum query.

The presentation of the results in this section is based on [O'D07].

#### <span id="page-16-0"></span>7.1 Learning stabilizer operators and approximating Fourier coefficients

We begin by learning the class of stabilizer operators. It turns out that this can be done with only one quantum query, in contrast to the n queries required classically. This is a natural generalisation of the quantum algorithm of Bernstein and Vazirani [BV97], which learns linear boolean functions with one quantum query. For simplicity, the results in this subsection are given in terms of quantum boolean functions, but it should be clear how to extend them to general unitary operators.

**Proposition 21.** If a quantum boolean function f is a stabilizer operator, then we can identify f with 1 quantum query, using O(n) quantum measurements of Pauli operators.

*Proof.* The idea behind the proof is simple: we apply f to one half of a collection of n maximally entangled states and then measure in a basis of maximally entangled states. More precisely, suppose that  $f = \chi_{\mathbf{s}}$  for some  $\mathbf{s}$ . Then the first step of our algorithm queries f to produce the state (our notation is identical to that of the previous section)

$$f \otimes \mathbb{I}|\Phi\rangle_{\mathbf{A}\mathbf{A}'} \equiv |\mathbf{s}\rangle. \tag{59}$$

Since the set of states  $\{|\mathbf{s}\rangle\}$  indexed by  $\mathbf{s}$  forms an orthonormal basis for  $\mathbf{A}\mathbf{A}'$  we can simply measure the state  $|\mathbf{s}\rangle$  to find out  $\mathbf{s}$ . (The O(n) measurements bit comes from the preparation step and the measurement step; one needs to measure each register  $A_jA'_j$  separately.)

The next proposition shows us that the previous result is robust against perturbations.

<span id="page-16-2"></span>**Proposition 22.** Suppose that a quantum boolean function f satisfies

<span id="page-16-1"></span>
$$\hat{f}_{\mathbf{s}} \ge \frac{1+\epsilon}{\sqrt{2}} \tag{60}$$

for some s. Then  $\chi_s$  can be identified with probability  $1 - \delta$  with  $O\left(\frac{1}{\epsilon^2}\log\left(\frac{1}{\delta}\right)\right)$  uses of f.

*Proof.* Note that, by Parseval, there can only be one character  $\chi_s$  which satisfies (60); the rest of the characters must be further from f than  $\chi_s$ .

The strategy of our proof is simple: we make q queries to f by applying it to sets of maximally entangled states  $|\Phi\rangle$  and then measure each resulting state in the  $\{|\mathbf{s}\rangle\}$  basis. We then take a majority vote. For each query, with probability  $\mathbb{P}[\mathrm{succ}] \geq \frac{1}{2} + \epsilon$ , we get the right answer. To work out the probability that the test fails we bound the failure probability by bounding the cumulative distribution function of the binomial distribution B(q,p) with  $p = \frac{1}{2} + \epsilon$ :

$$\mathbb{P}[\text{test fails}] = \mathbb{P}[\text{at least } q/2 \text{ failures}] \leq e^{-2\frac{(qp-\frac{q}{2})^2}{q}}$$
$$= e^{-2q\epsilon^2} = \delta. \tag{61}$$

so that choosing  $q = O\left(\frac{1}{\epsilon^2}\log\left(\frac{1}{\delta}\right)\right)$  gives us the desired result.

<span id="page-16-3"></span>**Lemma 23.** Let  $f = \sum_{\mathbf{s} \in \{0,1,2,3\}^n} \hat{f}_{\mathbf{s}} \chi_{\mathbf{s}}$  be a quantum boolean function. Then  $\hat{f}_{\mathbf{s}}^2 \geq \gamma^2$  for at most  $\frac{1}{\gamma^2}$  terms.

*Proof.* This is a simple consequence of Parseval's relation.

<span id="page-17-0"></span>**Lemma 24.** For any  $\mathbf{s} \in \{0, 1, 2, 3\}^n$  it is possible to estimate  $\hat{f}_{\mathbf{s}}$  to within  $\pm \eta$  with probability  $1 - \delta$  using  $O\left(\frac{1}{\eta^2}\log\left(\frac{1}{\delta}\right)\right)$  queries.

*Proof.* To prove this lemma we need access to the controlled-f quantum boolean function  $U_f = |0\rangle_C \langle 0| \otimes \mathbb{I}_A + |1\rangle_C \langle 1| \otimes f_A$ . (This can be easily implemented using f alone by adjoining n ancilla qubits and pre-applying a controlled-SWAP operation between the main qubits and ancilla qubits, applying f to the ancillas and post-applying a controlled-SWAP operation and then discarding the ancillas.)

The method takes place on a register consisting of the system A and a copy of the system A' and a control qubit. It proceeds as follows.

- 1. Prepare the control+system+copy in  $|0\rangle_C|\Phi\rangle_{\mathbf{A}\mathbf{A}'}$ .
- 2. Apply a Hadamard operation  $H = \frac{1}{\sqrt{2}} \begin{pmatrix} 1 & 1 \\ 1 & -1 \end{pmatrix}$  to C: the system is now in the state

$$\frac{1}{\sqrt{2}}|0\rangle_C|\Phi\rangle_{\mathbf{A}\mathbf{A}'} + \frac{1}{\sqrt{2}}|1\rangle_C|\Phi\rangle_{\mathbf{A}\mathbf{A}'}.$$
 (62)

3. Apply the controlled- $\chi_{\mathbf{s}}$  operation  $V_{\chi_{\mathbf{s}}} = |0\rangle_C \langle 0| \otimes \chi_{\mathbf{s}} + |1\rangle_C \langle 1| \otimes \mathbb{I}$  (implemented in the same way as  $U_f$ , above) to yield

$$\frac{1}{\sqrt{2}}|0\rangle_C \chi_{\mathbf{s}}|\Phi\rangle_{\mathbf{A}\mathbf{A}'} + \frac{1}{\sqrt{2}}|1\rangle_C|\Phi\rangle_{\mathbf{A}\mathbf{A}'}.$$
 (63)

4. Next apply  $U_f$  to give

$$\frac{1}{\sqrt{2}}|0\rangle_C \chi_{\mathbf{s}}|\Phi\rangle_{\mathbf{A}\mathbf{A}'} + \frac{1}{\sqrt{2}}|1\rangle_C f|\Phi\rangle_{\mathbf{A}\mathbf{A}'}.$$
 (64)

5. Apply a Hadamard operation once again to C. The system is now in the state

$$\frac{1}{2}|0\rangle_C(\chi_{\mathbf{s}}|\Phi\rangle_{\mathbf{A}\mathbf{A}'} + f|\Phi\rangle_{\mathbf{A}\mathbf{A}'}) + \frac{1}{2}|1\rangle_C(\chi_{\mathbf{s}}|\Phi\rangle_{\mathbf{A}\mathbf{A}'} - f|\Phi\rangle_{\mathbf{A}\mathbf{A}'}). \tag{65}$$

6. Now measure the control qubit in the computational basis. This gives "0" with probability

$$\mathbb{P}[0] = \langle \Phi | \frac{(\chi_{\mathbf{s}} + f)^2}{4} | \Phi \rangle = \frac{1}{2} + \frac{1}{2 \cdot 2^n} \operatorname{tr}(\chi_{\mathbf{s}} f) = \frac{1}{2} + \frac{1}{2} \hat{f}_{\mathbf{s}}$$
 (66)

and "1" with probability

$$\mathbb{P}[1] = \langle \Phi | \frac{(\chi_{\mathbf{s}} - f)^2}{4} | \Phi \rangle = \frac{1}{2} - \frac{1}{2 \cdot 2^n} \operatorname{tr}(\chi_{\mathbf{s}} f) = \frac{1}{2} - \frac{1}{2} \hat{f}_{\mathbf{s}}.$$
 (67)

An application of Hoeffding's inequality yields the desired result.

Remark 25. Note that one may improve the performance of the procedures involved the proofs of Proposition 22 and Lemma 24 by exploiting quantum amplitude amplification. This achieves a square-root improvement of the dependence on  $\epsilon$  and  $\eta$ , respectively.

#### <span id="page-18-0"></span>7.2 The quantum Goldreich-Levin algorithm

In this subsection we describe the quantum Goldreich-Levin algorithm.

<span id="page-18-1"></span>**Theorem 26** (quantum Goldreich-Levin). Given oracle access to a unitary operator f on n qubits and its adjoint  $f^{\dagger}$ , and given  $\gamma, \delta > 0$ , there is a poly  $\left(n, \frac{1}{\gamma}\right) \log\left(\frac{1}{\delta}\right)$ -time algorithm which outputs a list  $L = \{\mathbf{s}_1, \mathbf{s}_2, \ldots, \mathbf{s}_m\}$  such that with probability  $1 - \delta$ : (1) if  $|\hat{f}_{\mathbf{s}}| \geq \gamma$ , then  $\mathbf{s} \in L$ ; and (2) for all  $\mathbf{s} \in L$ ,  $|\hat{f}_{\mathbf{s}}| \geq \gamma/2$ .

This quantum algorithm can be understood as a kind of branch and bound algorithm: we initially assume that the set  $S_n$  of all  $4^n$  strings **s** contributes significantly to the Fourier expansion of f. We then partition this set into four equal chunks and efficiently estimate (via Proposition 32) the total weight of the Fourier expansion on each of these chunks. We then throw away the chunks with low weight and repeat the process by successively partitioning the remaining chunks into four, etc. The reason the total number of remaining chunks doesn't blow up exponentially is because of Lemma 23.

**Definition 27.** Let f be a unitary operator on n qubits. Let  $I \subset [n]$ . For any  $\mathbf{s} \in \{0,1,2,3\}^{|I|}$  with  $S \equiv \operatorname{supp}(\mathbf{s}) \subset I$  define

$$F_{\mathbf{s};I} \equiv \frac{1}{2^{|I|}} \operatorname{tr}_{I}(\chi_{\mathbf{s}} f). \tag{68}$$

**Lemma 28.** Let f be a unitary operator on n qubits, then

$$\frac{1}{2^{n-|I|}}\operatorname{tr}(\chi_{\mathbf{t}}F_{\mathbf{s};I}) = \hat{f}_{\mathbf{s}\cup\mathbf{t}},\tag{69}$$

for any  $\mathbf{t} \in \{0, 1, 2, 3\}^{n-|I|}$  with  $T \equiv \operatorname{supp}(\mathbf{t}) \subset I^c$ , where  $I^c$  denotes the complement of the set I and  $\mathbf{s} \cup \mathbf{t}$  denotes concatenation, i.e.,

$$[\mathbf{s} \cup \mathbf{t}]_j = \begin{cases} s_j, & j \in I \\ t_j, & j \notin I. \end{cases}$$
 (70)

Proof. Note that

$$F_{\mathbf{s};I} = \frac{1}{2^{n-|I|}} \sum_{\text{supp}(\mathbf{t}) \subset I^c} \text{tr}(\chi_{\mathbf{t}} F_{\mathbf{s};I}) \chi_{\mathbf{t}}$$

$$= \frac{1}{2^n} \sum_{\text{supp}(\mathbf{t}) \subset I^c} \text{tr}(\chi_{\mathbf{s}} \otimes \chi_{\mathbf{t}} f) \chi_{\mathbf{t}},$$
(71)

from which the result follows.

**Lemma 29.** Let f be a unitary operator on n qubits. Then

$$\frac{1}{2^{n-|I|}}\operatorname{tr}(F_{\mathbf{s};I}^{\dagger}F_{\mathbf{s};I}) = \sum_{\mathbf{t}\mid t_j = s_j, \forall j \in I} |\hat{f}_{\mathbf{t}}|^2.$$

$$(72)$$

*Proof.* Consider

$$\frac{1}{2^{n-|I|}}\operatorname{tr}(F_{\mathbf{s};I}^{\dagger}F_{\mathbf{s};I}) = \sum_{\sup_{\mathbf{t} \mid I} \mathbf{f}_{\mathbf{s} \cup \mathbf{u}}|^{2}} |\hat{f}_{\mathbf{s} \cup \mathbf{u}}|^{2} = \sum_{\mathbf{t} \mid t_{j} = s_{j}, j \in I} |\hat{f}_{\mathbf{t}}|^{2}.$$
(73)

It is convenient to write the set S of all t such that  $t_j = s_j$ ,  $j \in I$  as an indicator string:

**Definition 30.** Let  $I \subset [n]$ . The indicator string  $S = (s_{j_1}, s_{j_2}, \dots, s_{j_{|I|}}, *, *, \dots, *)$ , where  $s_{j_k} \in \{0, 1, 2, 3\}$ , is the set

$$\{\mathbf{t} \mid t_{j_k} = s_{j_k}, j_k \in I\}.$$
 (74)

**Definition 31.** The weight W(S) of an indicator string S is

$$W(\mathcal{S}) = \sum_{\mathbf{t} \in \mathcal{S}} |\hat{f}_{\mathbf{t}}|^2. \tag{75}$$

It turns out that we can efficiently estimate W(S).

<span id="page-19-0"></span>**Proposition 32.** Let f be a unitary operator on n qubits. Then for any indicator string S it is possible to efficiently estimate the weight W(S) to within  $\pm \gamma^2$  with probability  $1 - \delta$  using  $O\left(\frac{1}{\gamma^4}\log\left(\frac{1}{\delta}\right)\right)$  queries to f and  $f^{\dagger}$ .

*Proof.* Our method takes place in a system consisting of one ancilla qubit C, four copies, called  $A_1$ ,  $A'_1$ ,  $A_2$ , and  $A'_2$ , of the qubits in I and two copies, called B and B', of the qubits in  $I^c$ . Thus the total system is  $CA_1A'_1A_2A'_2BB'$ . The algorithm proceeds as follows.

1. Initialise the system (by applying a Hadamard on C) into

$$\frac{1}{\sqrt{2}}(|0\rangle + |1\rangle)_C |\Phi\rangle_{A_1 A_1'} |\Phi\rangle_{A_2 A_2'} |\Phi\rangle_{BB'}. \tag{76}$$

(From now on, for simplicity, we write  $|\Phi\rangle \equiv |\Phi\rangle_{A_1A_1'}|\Phi\rangle_{A_2A_2'}|\Phi\rangle_{BB'}$ .)

2. Apply the operation  $U \equiv |0\rangle_C \langle 0| \otimes \chi_{\mathbf{s}} \otimes \chi_{\mathbf{s}} + |1\rangle_C \langle 1| \otimes \mathbb{I}_{A_1 A_2}$  on  $CA_1 A_2$ . The system is now in the state

$$\frac{1}{\sqrt{2}}|0\rangle_C(\chi_{\mathbf{s}}\otimes\chi_{\mathbf{s}}|\mathbf{\Phi}\rangle) + \frac{1}{\sqrt{2}}|1\rangle_C|\mathbf{\Phi}\rangle. \tag{77}$$

3. Apply the controlled- $(f, f^{\dagger})$  operation  $V \equiv |0\rangle_C \langle 0| \otimes \mathbb{I}_{A_1A_2B} + |1\rangle_C \langle 1| \otimes f_{A_1B}f_{A_2B}^{\dagger}$  on  $CA_1A_2B$ . (This operation is easy to implement with two applications of controlled-f and controlled- $f^{\dagger}$  operations.) The system is now in the state

$$\frac{1}{\sqrt{2}}|0\rangle_C(\chi_{\mathbf{s}}\otimes\chi_{\mathbf{s}}|\mathbf{\Phi}\rangle) + \frac{1}{\sqrt{2}}|1\rangle_C(f_{A_1B}f_{A_2B}^{\dagger}|\mathbf{\Phi}\rangle). \tag{78}$$

4. Apply a Hadamard to the control register:

$$\frac{1}{2}|0\rangle_C(\chi_{\mathbf{s}}\otimes\chi_{\mathbf{s}}+f_{A_1B}f_{A_2B}^{\dagger})|\mathbf{\Phi}\rangle+\frac{1}{2}|1\rangle_C(\chi_{\mathbf{s}}\otimes\chi_{\mathbf{s}}-f_{A_1B}f_{A_2B}^{\dagger})|\mathbf{\Phi}\rangle. \tag{79}$$

5. Measure the control register in the computational basis. We get "0" with probability:

$$\mathbb{P}[0] = \frac{1}{4} \langle \mathbf{\Phi} | (\chi_{\mathbf{s}} \otimes \chi_{\mathbf{s}} + f_{A_2B} f_{A_1B}^{\dagger}) (\chi_{\mathbf{s}} \otimes \chi_{\mathbf{s}} + f_{A_1B} f_{A_2B}^{\dagger}) | \mathbf{\Phi} \rangle$$

$$= \frac{1}{2} + \frac{1}{2} \frac{1}{2^{n+|I|}} \operatorname{Re}(\operatorname{tr}(\chi_{\mathbf{s}} \otimes \chi_{\mathbf{s}} f_{A_1B} f_{A_2B}^{\dagger}))$$

$$= \frac{1}{2} + \frac{1}{2} \left( \frac{1}{2^{n-|I|}} \operatorname{tr}(F_{\mathbf{s};I}^{\dagger} F_{\mathbf{s};I}) \right) = \frac{1}{2} + \frac{1}{2} W(\mathcal{S}),$$
(80)

with a similar formula for  $\mathbb{P}[1]$ ; the second equality follows from noting that  $\langle \Phi | M_{A_1 A_2 B} \otimes \mathbb{I}_{A_1' A_2' B'} | \Phi \rangle = \frac{1}{2^{n+|I|}} \operatorname{tr}(M)$ , for any operator M on  $A_1 A_2 B$  (the extra |I| comes from the fact that A appears twice). An application of Hoeffding's inequality gives the desired result.

We now describe the quantum Goldreich-Levin algorithm.

#### Algorithm 1 Quantum Goldreich-Levin algorithm

```
L \leftarrow (*,*,\dots,*) for k=1 to n do for each \mathcal{S} \in L, \mathcal{S} = (s_1,s_2,\dots,s_{k-1},*,*,\dots,*) do Let \mathcal{S}_{s_k} = (s_1,s_2,\dots,s_{k-1},s_k,*,*,\dots,*) then for s_k = 0,1,2,3 estimate W(\mathcal{S}_{s_k}) to within \pm \gamma^2/4 with probability at least 1-\delta. Remove \mathcal{S} from L. Add \mathcal{S}_{s_k} if the estimate of W(\mathcal{S}_{s_k}) is at least \gamma^2/2 for s_k = 0,1,2,3. end for end for
```

We now analyse the algorithm. To simplify the analysis we'll assume that all estimations are accurate. We'll remove this assumption later.

**Lemma 33.** After 1 iteration of the algorithm,  $W(S) \geq \frac{\gamma^2}{4}$  for all  $S \in L$ .

*Proof.* All the estimates are assumed to be correct, and for all  $S \in L$ , S was entered into the list L because its estimated weight was at least  $\frac{\gamma^2}{2}$ , and the estimate is correct to within an additive  $\frac{\gamma^2}{4}$ .

**Lemma 34.** At any time  $|L| \leq \frac{4}{\gamma^2}$ .

*Proof.* The result follows from Lemma 23.

**Lemma 35.** The quantum Goldreich-Levin algorithm requires at most a total of  $\frac{16n}{\gamma^2}$  estimations.

*Proof.* At each iteration there are at most  $\frac{4}{\gamma^2}$  items in the list and the algorithm needs at most 4 estimations per iteration. There are only n iterations.

**Lemma 36.** For any **s** such that  $|\hat{f}_{\mathbf{s}}| \geq \gamma$ , there exists  $S \in L$  such that  $\mathbf{s} \in S$ .

*Proof.* It suffices to note that  $|\hat{f}_{\mathbf{s}}|^2 \geq \gamma^2$ , thus the weight of any string  $\mathcal{S}$  containing  $\mathbf{s}$  is greater than  $\gamma^2$ , hence at least once such  $\mathcal{S}$  remains in the list L after the first step.

To remove the accuracy assumption, given  $\delta > 0$ , we define  $\delta' = \frac{\delta \gamma^2}{16n}$ , and perform each estimation with confidence  $1 - \delta'$ . By the union bound, if the algorithm performs  $\frac{16n}{\gamma^2}$  estimations, they are all correct with probability at least  $1 - \delta$ , so the algorithm is correct with probability at least  $1 - \delta$ .

We now have all the ingredients to prove Theorem 26:

Proof of Theorem 26. The total running time is dominated by the estimations. There are at most  $\frac{16n}{\gamma^2}$ , and each takes  $O(\log(\frac{1}{\delta})/\gamma^2)$  samples to estimate, so the overall running time is  $\operatorname{poly}(n, \frac{1}{\delta}) \log(\frac{1}{\delta})$ .

#### <span id="page-21-0"></span>7.3 Learning quantum dynamics

In this subsection we show how to apply the quantum Goldreich-Levin algorithm to learn the dynamics generated by local quantum systems. In principle one needs an exponential number of queries to learn the dynamics associated with a quantum system of n qubits. However, if we make the key physical assumption that the dynamics are generated by a geometrically local quantum system, then it turns out that we can do much better. We'll focus, for simplicity, on one-dimensional quantum systems, but our results extend pretty easily to higher dimensional systems and to any system which is local on a graph with bounded isoperimetric dimension. There are even some results available for quantum dynamics on general graphs, which we leave to future works.

Before we begin we'll provide some background on quantum dynamics. Let  $\mathcal{H} \cong \mathbb{C}(2^n)$  be the Hilbert space associated with a collection of n qubits. A *Hamiltonian* is a Hermitian operator H on  $\mathcal{H}$ . The *dynamics generated by* H is the one-parameter family of unitary operators  $U(t) = e^{itH}$ .

We now need to describe what it means to learn the dynamics generated by a Hamiltonian H:

**Definition 37.** Let U be a unitary operator (not necessarily a quantum boolean function). We say that we have  $(\gamma, \epsilon)$ -learned the dynamics of a known Hermitian operator M if, given  $\gamma$  queries of U, we can provide an estimate  $U^{\dagger}MU$  of  $U^{\dagger}MU$  such that  $||U^{\dagger}MU-U^{\dagger}MU||_2^2 \leq \epsilon$  with probability greater than  $1 - \delta$ .

**Definition 38.** A one-dimensional quantum Hamiltonian H is any Hamiltonian which can be written

$$H = \sum_{j=1}^{n-1} h_j \tag{81}$$

with  $h_j$  Hermitian,  $||h_j||_{\infty} = O(1)$ , and supp $(h_j) \subset \{j, j+1\}$  for  $j \leq n-1$ .

The key to our main result is the following estimate.

**Theorem 39** (Lieb-Robinson bound [LR72]). Let H be a one-dimensional quantum system. Then for all s and j

$$||e^{-itH}\sigma_i^s e^{itH} - e^{-itH_\Lambda}\sigma_i^s e^{itH_\Lambda}||_{\infty} \le ce^{k|t|-v|\Lambda|},$$
(82)

where c, k, and v are constants independent of n,  $\Lambda \subset [n-1]$  is any contiguous subset centred on j, and  $H_{\Lambda} = \sum_{j \in \Lambda} h_j$ .

We can use the Lieb-Robinson bound to establish the following corollary

Corollary 40. Let H be a one-dimensional quantum system. Then

$$\frac{1}{2^n} \|e^{-itH}\sigma_j^s e^{itH} - e^{-itH_{\Lambda}}\sigma_j^s e^{itH_{\Lambda}}\|_2^2 \le ce^{k|t|-v|\Lambda|},\tag{83}$$

with possibly new constants c, k, and v.

*Proof.* The result is a simple application of the matrix norm inequality

$$||M||_2^2 \le m||M||_{\infty}^2 \tag{84}$$

for Hermitian  $m \times m$  matrices M.

**Proposition 41.** Let  $t = O(\log(n))$ . Then, with probability  $1 - \delta$  we can  $(\gamma, \epsilon)$ -learn the quantum boolean functions  $\sigma_j^s(t) \equiv e^{-itH}\sigma_j^s e^{itH}$  using  $\gamma = \text{poly}(n, 1/\epsilon, \log(1/\delta))$  queries of  $e^{itH}$ . (Note that all queries are made to the unitary operator  $U = e^{itH}$  and the pauli operators are assumed to be not evolving during the execution of the algorithm.)

Proof. The Lieb-Robinson bound tells us that if  $t = O(\log(n))$  then the only significant Fourier coefficients of the quantum boolean function  $\sigma_j^s(t)$  are those whose support is centred on j and have size the same order as |t|. Since there are at most  $O(n4^{|t|}) = O(\text{poly}(n))$  such coefficients we can *efficiently* apply the quantum Goldreich-Levin algorithm to output a list of them. Given this list we then use Lemma 24 to individually estimate them to accuracy  $\epsilon$ . An application of the union bound gives us the result.

Remark 42. The operators  $\sigma_j^s(t)$  are significant in condensed matter physics as they represent the dynamics of applied magnetic fields.

Although it is straightforward to compute an approximation to  $\langle \psi | \sigma_j^s(t) | \psi \rangle$  for a given initial quantum state  $|\psi\rangle$ , when we  $(\gamma,\epsilon)$ -learn  $\sigma_j^s(t)$  we are demanding that we can, on average, calculate a good approximation to  $\langle \psi | \sigma_j^s(t) | \psi \rangle$  for arbitrary quantum states which are randomly chosen after the algorithm has terminated. Notice also that the algorithm we've presented here doesn't need to know which qubit interacts with which, just that the qubits interact in a line. Indeed, simple modifications of the Lieb-Robinson bound allow us to conclude that we can efficiently learn the dynamics of qubits which interact on graphs with, eg., a finite number of randomly placed bridges.

### <span id="page-23-0"></span>8 Noise and quantum hypercontractivity

One of the most useful tools in the classical analysis of boolean functions has been the hypercontractive (also known as "Bonami-Gross-Beckner") inequality [Bec75, Bon68, Bon70, Gro75, Nel66, Nel73, Rud60]. Perhaps the most intuitive way to write down this inequality is in terms of a *noise operator* on functions, which can be defined in two equivalent ways.

**Definition 43.** For a bit-string  $x \in \{0,1\}^n$ , define the distribution  $y \sim_{\epsilon} x$  as follows: each bit of y is equal to the corresponding bit of x with probability  $1/2 + \epsilon/2$ , and flipped with probability  $1/2 - \epsilon/2$ . Then the noise operator with rate  $-1 \le \epsilon \le 1$ , written  $T_{\epsilon}$ , is defined via

<span id="page-23-2"></span>
$$(T_{\epsilon}f)(x) = \mathbb{E}_{y \sim_{\epsilon} x}[f(y)]. \tag{85}$$

Equivalently,  $T_{\epsilon}$  may be defined by its action on Fourier coefficients, as follows.

$$T_{\epsilon}f = \sum_{\mathbf{s} \in \{0,1\}^n} \epsilon^{|\mathbf{s}|} \hat{f}_{\mathbf{s}} \chi_{\mathbf{s}}.$$
 (86)

It is easy to see that noise rate 1 leaves the function as it is, whereas noise rate 0 replaces the function with the constant function  $\hat{f}_{0}\mathbb{I}$ . The Fourier-analytic definition given above immediately extends to the quantum setting, giving a superoperator defined as follows.

**Definition 44.** The noise superoperator with rate<sup>3</sup>  $-1/3 \le \epsilon \le 1$ , written  $T_{\epsilon}$ , is defined as follows.

$$T_{\epsilon}f = \sum_{\mathbf{s} \in \{0,1,2,3\}^n} \epsilon^{|\mathbf{s}|} \hat{f}_{\mathbf{s}} \chi_{\mathbf{s}}.$$
 (87)

Perhaps surprisingly, just as the classical noise operator has an alternative natural definition in terms of "local smoothing" (eqn. (85)), its quantum generalisation has a natural definition too, in terms of the action of the qubit depolarising channel.

**Proposition 45.** Let f be a Hermitian operator on n qubits. Then, for  $-1/3 \le \epsilon \le 1$ ,  $T_{\epsilon}f = \mathcal{D}_{\epsilon}^{\otimes n}f$ , where  $\mathcal{D}_{\epsilon}$  is the qubit depolarising channel with noise rate  $\epsilon$ , i.e.

<span id="page-23-3"></span>
$$\mathcal{D}_{\epsilon}(f) = \frac{(1 - \epsilon)}{2} \operatorname{tr}(f) \mathbb{I} + \epsilon f. \tag{88}$$

*Proof.* To verify the claim it is only necessary to check (88) on the characters  $\chi_s$  and then extend by linearity. Thus, since for a single qubit  $\mathcal{D}_{\epsilon}(\chi_0) = \chi_0$ , and  $\mathcal{D}_{\epsilon}(\chi_j) = \epsilon \chi_j$  for  $j \neq 0$  we have that

$$\mathcal{D}_{\epsilon}^{\otimes n}(\chi_{\mathbf{s}}) = \epsilon^{|\mathbf{s}|} \chi_{\mathbf{s}} = T_{\epsilon}(\chi_{\mathbf{s}}). \tag{89}$$

We have the following easy observations about the behaviour of the noise superoperator.

•  $||T_{\epsilon}f||_p \le ||f||_p$  for any  $0 \le \epsilon \le 1$ . Follows because  $T_{\epsilon}f$  is a convex combination of conjugations by unitaries.

<span id="page-23-1"></span><sup>&</sup>lt;sup>3</sup>This restriction on  $\epsilon$  is necessary for the map to be completely positive [KR01].

- The semigroup property  $T_{\delta}T_{\epsilon} = T_{\delta\epsilon}$  is immediate.
- If  $\delta \leq \epsilon$ ,  $||T_{\delta}f||_p \leq ||T_{\epsilon}f||_p$  for any  $p \geq 1$ . Follows from the previous two properties.
- For any f and g,  $\langle T_{\epsilon}f, g \rangle = \langle f, T_{\epsilon}g \rangle$ . Follows from Plancherel's theorem:  $\langle T_{\epsilon}f, g \rangle = \sum_{\mathbf{s}} \widehat{T_{\epsilon}f}_{\mathbf{s}}^* \hat{g}_{\mathbf{s}} = \sum_{\mathbf{s}} \epsilon^{|\mathbf{s}|} \hat{f}_{\mathbf{s}}^* \hat{g}_{\mathbf{s}} = \sum_{\mathbf{s}} \widehat{f}_{\mathbf{s}}^* \widehat{T_{\epsilon}g}_{\mathbf{s}} = \langle f, T_{\epsilon}g \rangle$ .

We are now ready to state the quantum hypercontractive inequality. By the identification of the noise superoperator with a tensor product of qubit depolarising channels, this inequality is really a statement about the properties of this channel, and can also be seen as a generalisation of a hypercontractive inequality of Carlen and Lieb [CL93].

<span id="page-24-0"></span>**Theorem 46.** Let f be a Hermitian operator on n qubits and assume that  $1 \le p \le 2 \le q \le \infty$ . Then, provided that

$$\epsilon \le \sqrt{\frac{p-1}{q-1}},\tag{90}$$

we have

$$||T_{\epsilon}f||_q \le ||f||_p. \tag{91}$$

Just as in the classical case, the proof of this inequality will involve two steps: first, a proof for n=1, and then an inductive step to extend to all n. The proof of the base case is essentially the same as in the classical setting. In the classical proof, the inductive step uses a quite general tensor product argument. One might hope that this argument extended to the quantum setting. This would be true if it held that, for any channels (superoperators) C and D on n qubits,

$$||C \otimes D||_{q \to p} \le ||C||_{q \to p} ||D||_{q \to p},$$
 (92)

where we define the  $q \to p$  norm as

$$||C||_{q \to p} = \sup_{f} \frac{||Cf||_p}{||f||_q}.$$
(93)

However, this most general statement is actually false, as it would imply the so-called "maximal output p-norm multiplicativity conjecture" in the case q=1, to which counterexamples have recently been found by Hayden and Winter [HW08] for all p>1 and for p=1 by Hastings [Has08]. Our proof must therefore be specific to the depolarising channel, and will turn out to rely on a non-commutative generalisation of Hanner's inequality recently proven by King [Kin03], rather than the Minkowski inequality used in the classical proof. In fact, a corollary of our result is the proof of multiplicativity of the maximum output  $q \to p$  norm for the depolarising channel for certain values of q and p.

Before we begin the proof of Theorem 46 in earnest, we will need some subsidiary lemmata.

<span id="page-24-2"></span>**Lemma 47.** Let f be a single qubit Hermitian operator and let  $1 \le p \le q \le \infty$ . Then, provided that

$$\epsilon \le \sqrt{\frac{p-1}{a-1}} \tag{94}$$

we have

<span id="page-24-1"></span>
$$||T_{\epsilon}f||_q \le ||f||_p. \tag{95}$$

*Proof.* We diagonalise f as  $U^{\dagger}\Lambda U$ , where  $\Lambda$  is diagonal. Since the depolarising channel is symmetric we have that  $T_{\epsilon}(U^{\dagger}\Lambda U) = \mathcal{D}_{\epsilon}(U^{\dagger}\Lambda U) = U^{\dagger}\mathcal{D}_{\epsilon}(\Lambda)U = U^{\dagger}T_{\epsilon}(\Lambda)U$  and since the q-norm is unitarily invariant we have that  $||T_{\epsilon}(f)||_q = ||T_{\epsilon}(\Lambda)||_q$ . So we may as well focus on diagonal operators  $\Lambda = \begin{pmatrix} \lambda_1 & 0 \\ 0 & \lambda_2 \end{pmatrix}$ . In terms of the eigenvalues of  $\Lambda$  the inequality (95) is just the two-point inequality established by Bonami [Bon70], Gross [Gro75] and Beckner [Bec75].

<span id="page-25-0"></span>**Lemma 48.** It suffices to prove Theorem 46 for p = 2.

*Proof.* The classical proof (see, e.g., [Mos05, Lecture 12]) goes through unchanged. The first step is to prove that Theorem 46 holds for q=2, and any  $1 \leq p \leq 2$ . Assume the theorem holds for p=2 and any q, and take p' such that 1/p'+1/p=1; then

$$||T_{\sqrt{p-1}}f||_{2} = \sup_{\|g\|_{2}=1} |\langle g, T_{\sqrt{p-1}}f \rangle| = \sup_{\|g\|_{2}=1} |\langle T_{\sqrt{p-1}}g, f \rangle|$$

$$\leq ||f||_{p} \sup_{\|g\|_{2}=1} ||T_{\sqrt{p-1}}g||_{p'} \leq ||f||_{p},$$
(97)

$$\leq \|f\|_{p} \sup_{\|g\|_{2}=1} \|T_{\sqrt{p-1}}g\|_{p'} \leq \|f\|_{p},$$
(97)

where the first inequality is Hölder's inequality. Now, to prove the theorem when  $1 \le p < p$ 2 < q, we use the semigroup property:

$$||T_{\sqrt{\frac{p-1}{q-1}}}f||_q = ||T_{1/\sqrt{q-1}}T_{\sqrt{p-1}}f||_q \le ||T_{\sqrt{p-1}}f||_2 \le ||f||_p.$$
(98)

<span id="page-25-1"></span>**Lemma 49.** For all  $p \ge 1$ ,  $||T_{\epsilon}f||_p \le ||T_{\epsilon}|f||_p$ , where |f| is the operator  $\sqrt{f^2}$ .

*Proof.* This holds because  $f \leq |f|$  (in a positive semidefinite sense) and applying  $T_{\epsilon}$  doesn't change this ordering because it is a convex combination of conjugations by unitaries.

We are now ready to prove Theorem 46. By Lemma 48, it suffices to prove the following statement.

**Proposition 50.** Let f be a Hermitian operator. Then  $||T_{\epsilon}f||_{1+1/\epsilon^2} \leq ||f||_2$  for any  $0 \leq 1$  $\epsilon \leq 1$ .

*Proof.* For readability, it will be convenient to switch to the un-normalised standard Schatten p-norm, so for the remainder of the proof  $||f||_p = (\operatorname{tr} |f|^p)^{1/p}$ . With this normalisation, what we want to prove is

$$||T_{\epsilon}f||_{1+1/\epsilon^2} \le 2^{-n\left(\frac{1-\epsilon^2}{2(1+\epsilon^2)}\right)} ||f||_2.$$
 (99)

The proof is by induction on n. The theorem is true for n=1 by Lemma 47, so assume n > 1 and expand f as follows.

$$f = \mathbb{I} \otimes a + \sigma^1 \otimes b + \sigma^2 \otimes c + \sigma^3 \otimes d = \begin{pmatrix} a + d & b - ic \\ b + ic & a - d \end{pmatrix}.$$
 (100)

Then, by direct calculation, we have

$$T_{\epsilon}f = \begin{pmatrix} T_{\epsilon}(a+\epsilon d) & \epsilon T_{\epsilon}(b-ic) \\ \epsilon T_{\epsilon}(b+ic) & T_{\epsilon}(a-\epsilon d) \end{pmatrix}, \tag{101}$$

where the operator  $T_{\epsilon}$  on the left-hand side acts on n qubits, while the operator  $T_{\epsilon}$  on the right-hand side acts on n-1 qubits. For brevity, set  $q=1+1/\epsilon^2$ , and assume that  $||T_{\epsilon}f||_q^q \leq 2^{-(n-1)(q/2-1)}||f||_2^q$  for any (n-1)-qubit Hermitian operator f. Using a non-commutative Hanner's inequality for positive block matrices [Kin03], which holds for  $q \geq 2$ , and noting that we can assume that f is positive by Lemma 49, we obtain

$$||T_{\epsilon}f||_{q}^{q} \leq \left\| \left( ||T_{\epsilon}(a+\epsilon d)||_{q} \|\epsilon T_{\epsilon}(b-ic)||_{q} \right) ||_{q}^{q} \right.$$

$$\leq 2^{-(n-1)(q/2-1)} \left\| \left( ||a+\epsilon d||_{2} \epsilon ||b-ic||_{2} \right) ||_{q}^{q} \right.$$

$$\leq 2^{-(n-1)(q/2-1)} \left\| \left( ||a+\epsilon d||_{2} \epsilon ||b-ic||_{2} \right) ||_{q}^{q} ,$$

where we use the inductive hypothesis. The proposition will thus be proven if we can show that

$$||g||_q^q \equiv \left\| \begin{pmatrix} ||a + \epsilon d||_2 & \epsilon ||b - ic||_2 \\ \epsilon ||b + ic||_2 & ||a - \epsilon d||_2 \end{pmatrix} \right\|_q^q$$

$$\leq 2^{-(q/2 - 1)} ||f||_2^q = 2 \left( ||a||_2^2 + ||d||_2^2 + ||b - ic||_2^2 \right)^{q/2},$$

where we call the matrix on the left-hand side of the inequality g. Write  $g = T_{\epsilon}h$  for some h, where the elements of h are

$$h_{11} = \frac{1}{2} \left( \left( 1 + \frac{1}{\epsilon} \right) \| a + \epsilon d \|_{2} + \left( 1 - \frac{1}{\epsilon} \right) \| a - \epsilon d \|_{2} \right),$$

$$h_{12} = \| b - ic \|_{2},$$

$$h_{21} = \| b + ic \|_{2},$$

$$h_{22} = \frac{1}{2} \left( \left( 1 - \frac{1}{\epsilon} \right) \| a + \epsilon d \|_{2} + \left( 1 + \frac{1}{\epsilon} \right) \| a - \epsilon d \|_{2} \right).$$

Note that h is indeed Hermitian;  $||b-ic||_2 = ||b+ic||_2$ , using the cyclicity of trace. Now, by Lemma 47,  $||g||_q^q \le 2^{-(q/2-1)} ||h||_2^q = 2\left(\frac{1}{2}||h||_2^2\right)^{q/2}$ . An explicit expansion gives

$$||h||_{2}^{2} = 2||b - ic||_{2}^{2} + \left(1 + \frac{1}{\epsilon^{2}}\right) \left(||a||_{2}^{2} + \epsilon^{2}||d||_{2}^{2}\right) + \left(1 - \frac{1}{\epsilon^{2}}\right) ||a + \epsilon d||_{2} ||a - \epsilon d||_{2}, \quad (102)$$

implying that, in order to prove the proposition, we need

$$\left(\frac{1}{2} + \frac{1}{2\epsilon^2}\right) \left(\|a\|_2^2 + \epsilon^2 \|d\|_2^2\right) + \left(\frac{1}{2} - \frac{1}{2\epsilon^2}\right) \|a + \epsilon d\|_2 \|a - \epsilon d\|_2 \le \|a\|_2^2 + \|d\|_2^2. \tag{103}$$

So, noting that  $1/2 - 1/(2\epsilon^2)$  is negative, it suffices to show that

$$||a||_2^2 - \epsilon^2 ||d||_2^2 \le ||a + \epsilon d||_2 ||a - \epsilon d||_2.$$
(104)

This last inequality can be proven using the matrix Cauchy-Schwarz inequality:

$$||a||_{2}^{2} - \epsilon^{2}||d||_{2}^{2} = \operatorname{tr}((a + \epsilon d)(a - \epsilon d))$$

$$\leq \sqrt{\operatorname{tr}((a + \epsilon d)^{2})} \sqrt{\operatorname{tr}((a - \epsilon d)^{2})}$$
(105)

$$\leq \sqrt{\operatorname{tr}((a+\epsilon d)^2)}\sqrt{\operatorname{tr}((a-\epsilon d)^2)}$$
 (106)

$$= \|a + \epsilon d\|_2 \|a - \epsilon d\|_2, \tag{107}$$

so we are done.

Theorem 46 has the following easy corollaries. The first says, informally, that low-degree quantum boolean functions are smooth.

<span id="page-27-0"></span>Corollary 51. Let f be a Hermitian operator on n qubits with degree at most d. Then, for any  $q \ge 2$ ,  $||f||_q \le (q-1)^{d/2} ||f||_2$ . Also, for any  $p \le 2$ ,  $||f||_p \ge (p-1)^{d/2} ||f||_2$ .

*Proof.* The proof follows that of Corollary 1.3 in Lecture 16 of [O'D07] with no changes required. Explicitly,

$$||f||_q^2 = \left\| \sum_{k=0}^d f^{-k} \right\|_q^2 = \left\| T_{1/\sqrt{q-1}} \left( \sum_{k=0}^d (q-1)^{k/2} f^{-k} \right) \right\|_q^2$$
 (108)

$$\leq \left\| \sum_{k=0}^{d} (q-1)^{k/2} f^{-k} \right\|_{2}^{2} = \sum_{k=0}^{d} (q-1)^{k} \sum_{\mathbf{s}, |\mathbf{s}| = k} \hat{f}_{\mathbf{s}}^{2}$$
(109)

$$\leq (q-1)^d \sum_{\mathbf{s}} \hat{f}_{\mathbf{s}}^2 = (q-1)^d ||f||_2^2.$$
 (110)

The second part is proved using the first part and Hölder's inequality, following immediately from

$$||f||_2^2 = \langle f, f \rangle \le ||f||_p ||f||_q \le (q-1)^{d/2} ||f||_p ||f||_2, \tag{111}$$

where 
$$1/p + 1/q = 1$$
.

The second corollary is a quantum counterpart of the fundamental Schwartz-Zippel Lemma [Sch80, Zip79]. This lemma states that any non-zero function  $f:\{0,1\}^n\to\mathbb{R}$  of degree d must take a non-zero value on at least a  $2^{-d}$  fraction of the inputs. By analogy with the classical lemma, we conjecture that the constant in the exponent of this corollary can be improved.

Corollary 52. Let f be a non-zero Hermitian operator on n qubits with m non-zero eigenvalues and degree d. Then  $m \ge 2^{n-(2\log e)d} \approx 2^{n-2.89d}$ .

*Proof.* Let  $f_1$  denote the projector onto the subspace spanned by f's eigenvectors that have non-zero eigenvalues. Then, for any  $q \ge p \ge 1$ ,

$$||f||_p = \langle f^p, f_1 \rangle^{1/p} \le (||f^p||_{q/p} ||f_1||_{q/(q-p)})^{1/p} = ||f||_q \left(\frac{m}{2^n}\right)^{1/p-1/q}, \tag{112}$$

where we use Hölder's inequality and the fact that  $f_1$ 's non-zero eigenvalues are all 1. Thus, using Corollary 51, for any  $q \geq 2$  we have

$$\left(\frac{m}{2^n}\right)^{1/2-1/q} \ge \frac{\|f\|_2}{\|f\|_q} \ge (q-1)^{-d/2},$$
 (113)

implying

$$m \ge \frac{2^n}{\left((q-1)^{q/(q-2)}\right)^d}.$$
 (114)

Taking the limit of this expression as  $q \to 2$  gives the desired result.

The final corollary is a quantum generalisation of a lemma attributed to Talagrand [Tal96], which bounds the weight of a projector on the first level in terms of its 1-norm (equivalently, its dimension). This lemma quantifies the intuition that low-rank projections (eg., pure states) on the Hilbert space of n qubits must have a Fourier spectrum whose support includes high-weight Fourier coefficients.

Corollary 53. Let  $P^2 = P$  be a projector. Then

$$||P^{-1}||_{2}^{2} \le (q-1)||P||_{1}^{\frac{2}{p}},\tag{115}$$

where  $\frac{1}{p} + \frac{1}{q} = 1$ .

*Proof.* We begin by writing

$$P = \sum_{\mathbf{s}} \hat{P}_{\mathbf{s}} \chi_{\mathbf{s}} = P^{-1} + h, \tag{116}$$

where

$$P^{=1} = \sum_{\mathbf{s} \mid |\mathbf{s}| = 1} \hat{P}_{\mathbf{s}} \chi_{\mathbf{s}}.$$
 (117)

Note that  $||P^{=1}||_2^2 = \langle P^{=1}, P \rangle$ . Applying Hölder's inequality:

$$||P^{-1}||_2^2 = \langle P^{-1}, P \rangle \le ||P||_p ||P^{-1}||_q,$$
 (118)

where  $\frac{1}{p} + \frac{1}{q} = 1$ . Next we use hypercontractivity to show that  $||P^{=1}||_q \le \sqrt{q-1}||P^{=1}||_2$ , so that

$$||P^{-1}||_2^2 \le \sqrt{q-1}||P^{-1}||_2||P||_p = \sqrt{q-1}||P^{-1}||_2||P||_1^{\frac{1}{p}}.$$
 (119)

Dividing both sides by  $||P^{-1}||_2$  and squaring both sides gives us

$$||P^{-1}||_2^2 \le (q-1)||P||_p^{\frac{2}{p}}. (120)$$

### <span id="page-29-0"></span>9 A quantum FKN theorem

The Friedgut-Kalai-Naor (FKN) theorem [FKN02] states that, if a boolean function has most of its Fourier weight on the first level or below, then it is close to being a dictator. It has proven useful in social choice theory [Kal02] and the study of hardness of approximation [KKMO04, Din07]. In this section, we state and prove two quantum variants of the FKN theorem. The first is a direct generalisation of the classical result, and uses the quantum hypercontractive inequality. The second is a different generalisation, to the ∞-norm.

#### <span id="page-29-1"></span>9.1 Balancing quantum boolean functions

It will be convenient for the later results in this section to deal only with quantum boolean functions which have no weight on level 0 (i.e. are traceless). We therefore describe a method to balance quantum boolean functions. That is, from a quantum boolean function f we produce another quantum boolean function g which satisfies  $\operatorname{tr}(g) = 0$  and has  $\|f^{\leq 1}\|_2^2 = \|g^{=1}\|_2^2$ .

**Definition 54.** The *spin flip* operation S is defined as

<span id="page-29-2"></span>
$$S(M) = \sigma^2 M^* \sigma^2 \tag{121}$$

for any single qubit operator M.

The spin flip operation is a superoperator but is not a CP map. Note that  $S(\sigma^j) = -\sigma^j$  for all  $j \in \{1, 2, 3\}$ .

**Definition 55.** The balancing operation  $\mathcal{B}$  is the superoperator

$$\mathcal{B}(f) = |0\rangle\langle 0| \otimes f - |1\rangle\langle 1| \otimes S^{\otimes n}(f)$$
  
=  $|0\rangle\langle 0| \otimes f - |1\rangle\langle 1| \otimes (\sigma^2 \otimes \cdots \otimes \sigma^2) f^*(\sigma^2 \otimes \cdots \otimes \sigma^2),$  (122)

where we attach an ancilla qubit, denoted A.

**Lemma 56.** Let f be a quantum boolean function. Then  $g = \mathcal{B}(f)$  is a quantum boolean function.

Proof. Consider

$$g^{2} = |0\rangle\langle 0| \otimes f^{2} + |1\rangle\langle 1| \otimes S^{\otimes n}(f^{2})$$
  
=  $|0\rangle\langle 0| \otimes \mathbb{I} + |1\rangle\langle 1| \otimes S^{\otimes n}(\mathbb{I}) = \mathbb{I}.$  (123)

**Proposition 57.** Let f be a quantum boolean function. Then  $tr(\mathcal{B}(f)) = 0$ .

*Proof.* The proof is by direct calculation.

$$\operatorname{tr}(\mathcal{B}(f)) = \operatorname{tr}(f) - \operatorname{tr}(f^*) = 2\operatorname{Im}(\operatorname{tr}(f)) = 0, \tag{124}$$

where the first equality follows from an application of the cyclic rule of trace.  $\Box$ 

**Proposition 58.** Let f be a quantum boolean function, and  $g = \mathcal{B}(f)$ . Then  $\|g^{\leq 1}\|_2^2 = \|f^{\leq 1}\|_2^2$ .

*Proof.* We can calculate the first level of  $\mathcal{B}(f)$  by tracing against weight-1 operators on the system:

$$\operatorname{tr}(\sigma_j^s \mathcal{B}(f)) = \operatorname{tr}(\sigma_j^s f) - \operatorname{tr}(\sigma_j^s (\sigma^2 \otimes \cdots \otimes \sigma^2)(f^*)(\sigma^2 \otimes \cdots \otimes \sigma^2))$$

$$= 2 \operatorname{tr}(\sigma_j^s f), \tag{125}$$

recalling that the notation  $\sigma_i^j$  is used for the operator which acts as  $\sigma^j$  at the *i*'th position, and trivially elsewhere. That is,  $\langle \sigma_j^s, g \rangle = \langle \sigma_j^s, f \rangle$ , so all the degree 1 terms in the Fourier expansion of g (on the system) are identical to those for f. The only non-zero weight-1 term of g on the ancilla A is given by

$$tr(\sigma_A^3 g) = 2 tr(f). \tag{126}$$

Our balancing operation reduces to the previously known classical balancing operation on classical boolean functions [FKN02].

#### <span id="page-30-0"></span>9.2 Exact quantum FKN

To gain some intuition for the later results, we begin by sketching the (straightforward) proof of an exact variant of the FKN theorem.

**Proposition 59.** Let f be a quantum boolean function on n qubits. If  $\sum_{|s|>1} \hat{f}_s^2 = 0$ , then f is either a dictator or constant.

*Proof.* By the results of Section 9.1, we can assume that f is balanced. Expand f as

$$f = \sum_{i=1}^{n} U_i, \tag{127}$$

where  $U_i$  is a traceless operator that acts non-trivially on only the i'th qubit, with at most two distinct eigenvalues. Let the positive eigenvalue of the non-trivial component of  $U_i$  be  $\lambda_i$ , and the corresponding eigenvector be  $|e_i\rangle$ . Then the tensor product  $\bigotimes_i |e_i\rangle$  is an eigenvector of f with eigenvalue  $\lambda = \sum_i \lambda_i \leq ||f||_{\infty}$ . Let  $\mathbf{i} : \mathbf{x}$  denote the string of length n with value x at position i, and 0 elsewhere. Because  $U_i = \mathbb{I}_{[i-1]} \otimes M_i \otimes \mathbb{I}_{[i+1,\dots,n]}$  and  $M_i = \hat{f}_{\mathbf{i}:\mathbf{1}}\sigma_i^1 + \hat{f}_{\mathbf{i}:\mathbf{2}}\sigma_i^2 + \hat{f}_{\mathbf{i}:\mathbf{1}}\sigma_i^3 = \begin{pmatrix} \hat{f}_{\mathbf{i}:\mathbf{3}} & \hat{f}_{\mathbf{i}:\mathbf{1}}-i\hat{f}_{\mathbf{i}:\mathbf{2}} \\ \hat{f}_{\mathbf{i}:\mathbf{1}}+i\hat{f}_{\mathbf{i}:\mathbf{2}} & -\hat{f}_{\mathbf{i}:\mathbf{3}} \end{pmatrix}$ , we have that

$$\lambda_i = \sqrt{\hat{f}_{i:1}^2 + \hat{f}_{i:2}^2 + \hat{f}_{i:3}^2}.$$
 (128)

Thus  $\sum_{i} \lambda_{i}$  is strictly greater than 1 unless f is a dictator.

#### <span id="page-31-0"></span>9.3 Quantum FKN in the 2-norm

In this section, we will prove the following result.

<span id="page-31-1"></span>**Theorem 60.** There is a constant K such that, for every quantum boolean function f, if  $\sum_{|s|>1} \hat{f}_s^2 < \epsilon$ , f is  $K\epsilon$ -close to being a dictator or constant.

The proof is essentially a quantisation of one of the two proofs of the classical theorem given in the original paper [FKN02]; see also the exposition in Lecture 13 of [O'D07]. We will require the following lemma.

<span id="page-31-2"></span>**Lemma 61.** Let q be a degree 2 Hermitian operator on n qubits such that  $\Pr_i[|\lambda_i(q)| > \delta] = p$ , where the probability is taken with respect to the uniform distribution on the eigenvalues of q. Then  $||q||_2^2 \leq \frac{\delta^2(1-p)}{1-9\sqrt{p}}$ .

*Proof.* Expand  $q = r \oplus s$ , where r projects onto the eigenvectors of q with eigenvalues at most  $\delta$  in absolute value. Thus  $\operatorname{rank}(r) \leq (1-p)2^n$  and  $\operatorname{rank}(s) = p2^n$ . Then the lemma follows from

$$||q||_{2}^{2} = ||r||_{2}^{2} + ||s||_{2}^{2} \le (1-p)\delta^{2} + \sqrt{p}||s||_{4}^{2}$$
  
$$\le (1-p)\delta^{2} + \sqrt{p}||q||_{4}^{2} \le (1-p)\delta^{2} + 9\sqrt{p}||q||_{2}^{2},$$

where the final inequality is Corollary 51.

We now turn to the proof of Theorem 60.

Proof of Theorem 60. By the results of Section 9.1, we can assume that f has no weight on level 0, i.e. is traceless. Given  $f = \sum_{|s|=1} \hat{f}_s \chi_s + \sum_{|s|>1} \hat{f}_s \chi_s$ , call the first sum l and the second h ("low" and "high"). As f is quantum boolean,  $(l+h)^2 = \mathbb{I}$ . Thus  $l^2 + hl + lh + h^2 = \mathbb{I}$ . On the other hand, by explicit expansion of l, we have

$$l^{2} = \sum_{\mathbf{s}, |\mathbf{s}|=1} \hat{f}_{\mathbf{s}}^{2} \mathbb{I} + \sum_{\substack{\mathbf{s}, \mathbf{t}, \\ |\mathbf{s}|=|\mathbf{t}|=1, \\ |\mathbf{s} \cap \mathbf{t}|=0}} \hat{f}_{\mathbf{s}} \hat{f}_{\mathbf{t}} \chi_{\mathbf{s}} \chi_{\mathbf{t}} = (1 - \epsilon) \mathbb{I} + q, \tag{129}$$

where we define a new operator q. Our goal will be to show that  $||q||_2^2$  is small, i.e. at most  $K\epsilon$  for some constant K. The theorem will follow: if

$$K\epsilon \ge ||q||_{2}^{2} = \sum_{\substack{\mathbf{s},\mathbf{t},\\|\mathbf{s}|=|\mathbf{t}|=1,\\|\mathbf{s}\cap\mathbf{t}|=0}} \hat{f}_{\mathbf{s}}^{2} \hat{f}_{\mathbf{t}}^{2} = \left(\sum_{\mathbf{s},|\mathbf{s}|=1} \hat{f}_{\mathbf{s}}^{2}\right)^{2} - \sum_{\substack{\mathbf{s},\mathbf{t},\\|\mathbf{s}|=|\mathbf{t}|=1,\\|\mathbf{s}\cap\mathbf{t}|=1}} \hat{f}_{\mathbf{s}}^{2} \hat{f}_{\mathbf{t}}^{2}$$
(130)

$$= (1 - \epsilon)^2 - \sum_{\substack{\mathbf{s}, \mathbf{t}, \\ |\mathbf{s}| = |\mathbf{t}| = 1, \\ |\mathbf{s} \cap \mathbf{t}| = 1}} \hat{f}_{\mathbf{s}}^2 \hat{f}_{\mathbf{t}}^2, \tag{131}$$

then, for some K',

$$1 - K'\epsilon \leq \sum_{\substack{\mathbf{s}, \mathbf{t}, \\ |\mathbf{s}| = |\mathbf{t}| = 1, \\ |\mathbf{s} \cap \mathbf{t}| = 1}} \hat{f}_{\mathbf{s}}^{2} \hat{f}_{\mathbf{t}}^{2} = \sum_{\substack{\mathbf{s}, |\mathbf{s}| = 1 \\ |\mathbf{s} \cap \mathbf{t}| = 1}} \hat{f}_{\mathbf{s}}^{2} \left( \sum_{\substack{\mathbf{t}, |\mathbf{t}| = 1, \\ |\mathbf{s} \cap \mathbf{t}| = 1}} \hat{f}_{\mathbf{t}}^{2} \right)$$

$$(132)$$

$$\leq \max_{\mathbf{s},|\mathbf{s}|=1} \sum_{\substack{\mathbf{t},|\mathbf{t}|=1,\\|\mathbf{s}\cap\mathbf{t}|=1}} \hat{f}_{\mathbf{t}}^{2}, \tag{133}$$

so there exists some index i such that all but  $K'\epsilon$  of the weight of f is on terms that only depend on the i'th qubit. Setting all the other terms in the Fourier expansion of f to zero and renormalising gives a quantum boolean function that is a dictator (on the i'th qubit) and is distance  $K''\epsilon$  from f, for some other constant K''.

It remains to show that  $||q||_2^2$  is small. Expand q as

$$q = \epsilon \mathbb{I} - hl - lh - h^2 = \epsilon \mathbb{I} - h(f - h) - (f - h)h - h^2 = \epsilon \mathbb{I} - hf - fh + h^2$$
 (134)

and consider the terms in this sum. By the hypothesis of the theorem,  $||h||_2^2 = \frac{1}{2^n} \sum_i \lambda_i(h)^2 = \epsilon$ . We also have tr h = 0. By Chebyshev's inequality, this implies that, for any K > 0,  $\Pr_i[|\lambda_i(h)| > K\sqrt{\epsilon}] \le 1/K^2$  (taking the uniform distribution on the eigenvalues of h).

We also have  $\sigma_i(hf) \leq \sigma_i(h)$  (see [Bha97, Problem III.6.2] and note that  $||f||_{\infty} = 1$ ), and similarly for  $\sigma_i(fh)$ . As  $h^2 \leq \mathbb{I}$ , for all  $i, |\lambda_i| \leq 1$  and so  $\Pr_i[|\lambda_i(h^2)| > K\sqrt{\epsilon}] \leq \Pr_i[|\lambda_i(h)| > K\sqrt{\epsilon}] \leq 1/K^2$ . This implies that (see [Bha97, Problem III.6.5])

$$\Pr_{i}[|\lambda_{i}(q)| > 3K\sqrt{\epsilon} + \epsilon] \le 3/K^{2}. \tag{135}$$

Using Lemma 61, taking K to be a sufficiently small constant, the result follows.

#### <span id="page-32-0"></span>9.4 Quantum FKN in the $\infty$ -norm

In this subsection we'll prove a quantum generalisation of the FKN theorem in terms of the supremum or infinity norm  $\|\cdot\|_{\infty}$ . Our proof doesn't make use of hypercontractivity: only standard results from matrix analysis are employed.

**Theorem 62.** Let f be a quantum boolean function. If  $||f-g||_{\infty} \leq \epsilon$ , where g is a Hermitian operator with  $g = g^{-1}$  and  $\epsilon < \frac{1}{2}$ , then f is close to a dictator h, i.e.,  $||f-h||_{\infty} \leq 2\epsilon$ .

Remark 63. This result has no classical analogue as  $||f - g||_{\infty}$  can never be small if f and g are different.

*Proof.* By the results of Section 9.1, we can assume that f is traceless. Our proof works by using the infinity-norm closeness of f and g in an application of Weyl's perturbation theorem [Bha97] to force the eigenvalues of f to be close to those of g:

$$|\lambda_j^{\downarrow}(f) - \lambda_j^{\downarrow}(g)| \le \epsilon, \quad j = 1, 2, \dots, 2^n,$$
 (136)

where  $\lambda_i^{\downarrow}(M)$  denote the eigenvalues of M, in descending order. Thus:

$$\lambda_j^{\downarrow}(f) = \lambda_j^{\downarrow}(g) + \epsilon(j), \quad j = 1, 2, \dots, 2^n.$$
(137)

Since g can be written as  $g = \sum_{j \in [n]} g_j$ , with  $\operatorname{supp}(g_j) = \{j\}$  and  $\operatorname{tr}(g_j) = 0$ , the eigenvalues of g are given by  $\sum_{j=1}^n x_j \mu_j$ , where  $x_j \in \{-1, +1\}$  and  $\mu_j = \|g_j\|_{\infty}$ . (This follows because  $g_j$  is acts on the jth qubit as a 2-dimensional matrix.)

So we can label the eigenvalues of g with  $\mathbf{x} \in \{-1, +1\}^n$  and we rewrite the perturbation condition as

<span id="page-33-0"></span>
$$\lambda(\mathbf{x}) = \sum_{j=1}^{n} x_j \mu_j + \epsilon(\mathbf{x}), \tag{138}$$

where  $\lambda(\mathbf{x})$  is the eigenvalue of f corresponding to the eigenvalue  $\sum_{j=1}^{n} x_j \mu_j$  of g and  $\epsilon(\mathbf{x})$  is a correction. Our strategy is to now show that  $\epsilon(\mathbf{x})$  is a linear function.

To this end, we differentiate the  $2^n$  equations (138) with respect to  $x_j$ :

<span id="page-33-1"></span>
$$\mu_j = D_j \lambda - D_j \epsilon(\mathbf{x}), \tag{139}$$

where, eg.,

$$D_{j}\lambda = \frac{\lambda(x_{1}, \dots, x_{j} = +1, \dots, x_{n}) - \lambda(x_{1}, \dots, x_{j} = -1, \dots, x_{n})}{2},$$
(140)

i.e., we take the difference between  $\lambda$  with the jth variable assigned to 1 and to -1. Note that  $D_j\lambda:\{-1,+1\}^{n-1}\to\mathbb{R}$ .

Since f is quantum boolean, by assumption, we have that  $|\lambda(\mathbf{x})| = 1$ ,  $\forall \mathbf{x}$ . So, because  $\mu_j$  is constant and  $|D_j\epsilon(\mathbf{x})| \leq \epsilon < 1/2$ , and (139) is true for all  $(x_1, \ldots, x_{j-1}, x_{j+1}, \ldots x_n)$ , we conclude that  $D_j\epsilon(\mathbf{x})$  is constant for all  $(x_1, \ldots, x_{j-1}, x_{j+1}, \ldots x_n)$ . (Otherwise we'd have a contradiction: as we run through all the assignments of  $(x_1, \ldots, x_{j-1}, x_{j+1}, \ldots, x_n)$  the value of  $D_j\lambda$  can, in principle, take both the values 0 and 1. However, owing to the constancy of  $\mu_j$  and the fact that  $|D_j\epsilon(\mathbf{x})| \leq \epsilon < 1/2$  only one of two possible values can be taken.) This is true for all  $j \in [n]$ . So we learn that  $\epsilon(\mathbf{x})$  is linear:

$$\epsilon(\mathbf{x}) = \sum_{j=1}^{n} x_j \epsilon_j. \tag{141}$$

But the condition that  $|\epsilon(\mathbf{x})| \leq \epsilon$ ,  $\forall \mathbf{x}$ , implies that

$$\sum_{j=1}^{n} |\epsilon_j| \le \epsilon. \tag{142}$$

Summarising what we've learnt so far:

$$D_j \lambda = \mu_j + \epsilon_j. \tag{143}$$

Since  $D_j\lambda: \{-1,+1\}^{n-1} \to \{-1,0,1\}$  we must have that  $(\mu_j + \epsilon_j) \in \{-1,0,1\}, j \in [n]$ . But this actually means that there is exactly one j for which  $\mu_j = 1 - \epsilon_j$  (or  $-1 - \epsilon_j$ ); the

rest satisfy  $|\mu_j| = \epsilon_j$ . The reason for this is as follows. Suppose there was more than one such j. This would then lead to a contradiction as one can always find an assignment of the variables  $x_k$  so that  $|\lambda(\mathbf{x})| > 1$ , contradicting the quantum booleanity of f.

We now need to show that f is in fact close to a dictator. We define our dictator to be  $h = \operatorname{sgn}(g)$ . An application of the triangle inequality gives us the result:

$$||f - h||_{\infty} \le ||f - g||_{\infty} + ||g - h||_{\infty}$$

$$\le \epsilon + \sum_{j=1}^{n} |\epsilon_j| \le 2\epsilon$$
(144)

### <span id="page-34-0"></span>10 Influence of quantum variables

In this section we introduce the notion of *influence* for quantum boolean functions, and establish some basic properties of the influence.

The classical definition of the influence of variable j on a boolean function f is the probability that f's value is undefined if the value of j is unknown, formally defined as

$$I_j(f) = \mathbb{P}_x[f(x) \neq f(x \oplus e_j)],\tag{145}$$

where  $x \oplus e_j$  flips the jth bit of x. In the quantum case, we define the influence in terms of derivative operators.

**Definition 64.** The jth derivative operator  $d_j$  is the superoperator

$$d_j \equiv \frac{1}{2}(\mathcal{I} - S_j),\tag{146}$$

where  $\mathcal{I}$  is the identity superoperator and  $S_j$  is the spin flip operation (121) on the jth qubit. Note that

$$d_j(\chi_{\mathbf{s}}) = \begin{cases} \chi_{\mathbf{s}}, & s_j \neq 0 \\ 0, & s_j = 0. \end{cases}$$
 (147)

The gradient of f is

$$\nabla f \equiv (d_1(f), d_2(f), \dots, d_n(f)). \tag{148}$$

The laplacian of f is

$$\nabla^2 f = \|\nabla f\|_2^2 = \sum_{j=1}^n \|d_j(f)\|_2^2. \tag{149}$$

The following lemma is immediate from the definition of the derivative operator.

**Lemma 65.** Let f be an operator on n qubits. Then the  $d_i$  operator acts as follows.

$$d_j(f) = \sum_{\mathbf{s}|s_j \neq 0} \hat{f}_{\mathbf{s}} \chi_{\mathbf{s}}.$$
 (150)

**Definition 66.** Let f be a quantum boolean function. We define the *influence* of the jth qubit to be

$$I_j(f) \equiv ||d_j(f)||_2^2,$$
 (151)

and the total influence I(f) to be

$$I(f) \equiv \sum_{j=1}^{n} I_j(f). \tag{152}$$

Note that this definition reduces to the classical definition when f is diagonal in the computational basis. Intuitively the quantum influence of the jth qubit measures the extent to which the value of a quantum boolean function is changed when in the input the state of jth qubit is inverted through the origin of the Bloch sphere.

**Proposition 67.** Let f be a quantum boolean function. Then

$$I_j(f) = \sum_{\mathbf{s}|s_j \neq 0} \hat{f}_{\mathbf{s}}^2 \tag{153}$$

and

$$I(f) = \sum_{\mathbf{s}} |\mathbf{s}| \hat{f}_{\mathbf{s}}^2. \tag{154}$$

*Proof.* Both results follow immediately from the definition of influence.

The next result provides two other characterisations of the derivative.

<span id="page-35-0"></span>**Lemma 68.** Let f be a quantum boolean function. Then

$$d_{j}(f) = f - \operatorname{tr}_{j}(f) \otimes \frac{\mathbb{I}_{j}}{2}$$

$$= f - \int dU U_{j}^{\dagger} f U_{j}$$
(155)

and

$$I_j(f) = \frac{1}{2} \int dU \| [U_j, f] \|_2^2, \tag{156}$$

where the commutator  $[U_j, f] \equiv U_j f - f U_j$ , dU is the Haar measure on U(2) and  $U_j \equiv \mathbb{I} \otimes \cdots \otimes U \otimes \cdots \otimes \mathbb{I}$  with  $\operatorname{supp}(U_j) = \{j\}$ .

*Proof.* Both of the first two identities can be established by checking  $d_j$  on single qubit operators and extending by linearity.

The alternative characterisation of the influence can be proven as follows.

$$I_{j}(f) = \left\| f - \int dU U_{j}^{\dagger} f U_{j} \right\|_{2}^{2}$$

$$= \frac{1}{2^{n}} \int dU dV \operatorname{tr} \left( (f - U_{j}^{\dagger} f U_{j}) (f - V_{j}^{\dagger} f V_{j}) \right)$$

$$= \frac{1}{2^{n}} \int dU dV \operatorname{tr} \left( \mathbb{I} - U_{j}^{\dagger} f U_{j} f - f V_{j}^{\dagger} f V_{j} + U_{j}^{\dagger} f U_{j} V_{j}^{\dagger} f V_{j} \right)$$

$$= 1 - \frac{2}{2^{n}} \int dU \operatorname{tr} \left( U_{j}^{\dagger} f U_{j} f \right) + \frac{1}{2^{n}} \int dU \operatorname{dV} \operatorname{tr} \left( f U_{j} V_{j}^{\dagger} f V_{j} U_{j}^{\dagger} \right)$$

$$= 1 - \frac{2}{2^{n}} \int dU \operatorname{tr} \left( U_{j}^{\dagger} f U_{j} f \right) + \frac{1}{2^{n}} \int dU \operatorname{tr} \left( f U_{j} f U_{j}^{\dagger} \right)$$

$$= 1 - \frac{1}{2^{n}} \int dU \operatorname{tr} \left( U_{j}^{\dagger} f U_{j} f \right)$$

$$= \frac{1}{2^{n}} \int dU \operatorname{tr} \left( \mathbb{I} - U_{j}^{\dagger} f U_{j} f \right)$$

$$= \frac{1}{2^{n+1}} \int dU \operatorname{tr} \left( [U_{j}, f] [f, U_{j}^{\dagger}] \right) = \frac{1}{2} \int dU \|[U_{j}, f]\|_{2}^{2}.$$

$$(157)$$

Now we generalise the single-qubit influence to multiple qubits.

**Definition 69.** Let f be a quantum boolean function. Then the influence of a set  $J \subset [n]$  on f, written  $I_J(f)$ , is the quantity

$$I_J(f) \equiv ||d_J(f)||_2^2,$$
 (158)

where

$$d_J(f) \equiv f - \operatorname{tr}_J(f) \otimes \frac{\mathbb{I}_J}{2^{|J|}}.$$
 (159)

The next result is a straightforward generalisation of Lemma 68.

Corollary 70. Let f be a quantum boolean function,  $J \subset [n]$ , and m = |J|. Then

$$d_J(f) = f - \int dU_1 dU_2 \cdots dU_m \left( U_1 \otimes U_2 \otimes \cdots \otimes U_m \right)^{\dagger} f(U_1 \otimes U_2 \otimes \cdots \otimes U_m)$$
 (160)

and

$$I_{J}(f) = \int dU_{1}dU_{2} \cdots dU_{m} \| [U_{1} \otimes U_{2} \otimes \cdots \otimes U_{m}, f] \|_{2}^{2},$$
(161)

where  $J = \bigcup_{j=1}^m \operatorname{supp}(U_j)$ .

Unlike the definition of influence on a single qubit, the physical interpretation of multiple qubit influence is less clear, and we leave it as an open question.

**Definition 71.** Let f be a quantum boolean function. Then we define the *variance* of f to be

$$var(f) = \frac{1}{2^n} tr(f^2) - \left(\frac{1}{2^n} tr(f)\right)^2.$$
 (162)

**Proposition 72** (Quantum Poincaré inequality for n qubits). Let f be a quantum boolean function. Then

$$var(f) \le \nabla^2(f) = I(f). \tag{163}$$

*Proof.* The proof follows from writing left and right-hand sides in terms of the Fourier expansion:

$$\operatorname{var}(f) = \sum_{\mathbf{s}} \hat{f}_{\mathbf{s}}^2 - f_{\mathbf{0}}^2 \tag{164}$$

and

$$I(f) = \sum_{\mathbf{s}} |\mathbf{s}| \hat{f}_{\mathbf{s}}^2. \tag{165}$$

The inequality is now obvious.

<span id="page-37-1"></span>Corollary 73. Let f be a quantum boolean function such that tr(f) = 0. Then there is a  $j \in [n]$  such that  $I_j(f) \geq 1/n$ .

### <span id="page-37-0"></span>11 Towards a quantum KKL theorem

An influential paper of Kahn, Kalai and Linial [KKL88] proved the following result, known as the KKL theorem. For every balanced boolean function  $f:\{0,1\}^n \to \{1,-1\}$ , there exists a variable x such that  $I_j(f) = \Omega\left(\frac{\log n}{n}\right)$ . By Corollary 73, for every balanced quantum boolean function f on n qubits there is a qubit j such that  $I_j(f) \geq \frac{1}{n}$ . It is thus natural to conjecture that a quantum analogue of the KKL theorem holds – and also a quantum analogue of Friedgut's theorem [Fri98], which is based on similar ideas.

However, the immediate quantum generalisation of the classical proof does not go through. Intuitively, the reason for this is as follows. The classical proof shows that, if the influences are all small, then their sum is large. This holds because, if the derivative operator in a particular direction has low norm, then it has small support, implying that it has some Fourier weight on a high level, which must be included in derivatives in many different directions. In the quantum case, this is not true: there exist quantum boolean functions whose derivative is small in a particular direction, but which are also low-degree.

On the other hand, it is immediate that the KKL theorem holds for quantum boolean functions which can be diagonalised by local unitaries, as these do not change the influence on each qubit. In this section we describe three partial results aimed at generalising the KKL theorem further. The first result is a simple quantisation of one of the classical proofs. This serves to illustrate what goes wrong when we generalise to the quantum world. Our next result shows that the classical proof technique breaks down precisely for anticommuting quantum boolean functions (qv.). Our final result is then a stronger version of KKL for a class of anticommuting quantum boolean functions.

#### <span id="page-38-0"></span>11.1 A quantum Talagrand's lemma for KKL

The purpose of this section is to prove the following quantum generalisation of a theorem of Talagrand [Tal94].

<span id="page-38-1"></span>**Proposition 74.** Let f be a traceless Hermitian operator on n qubits. Then

$$||f||_2^2 \le \sum_{i=1}^n \frac{10||d_i f||_2^2}{(2/3)\log(||d_i f||_2/||d_i f||_1) + 1}.$$
 (166)

In the case of classical boolean functions, this result can be applied to give an essentially immediate proof of the KKL theorem, using the fact that the functions  $\{d_i f\}$  take values in  $\{-1,0,1\}$ . However, this does not extend to the quantum case, as the operators  $d_i f$  have no such constraint on their eigenvalues. The proof of Proposition 74, on the other hand, is essentially an immediate generalisation of the classical proof in [Tal94] (alternatively, see the exposition in [Wol08]).

Proof of Proposition 74. For any operator g, define

$$M^{2}(g) = \sum_{\mathbf{s} \neq 0} \frac{\hat{g}_{\mathbf{s}}^{2}}{|\mathbf{s}|}.$$
 (167)

Then it is clear that

$$||f||_2^2 = \sum_{i=1}^n M^2(d_i(f)). \tag{168}$$

Our strategy will be to find upper bounds on  $M^2(g)$  for any traceless operator g. For some integer  $m \geq 0$ , expand

$$M^{2}(g) = \sum_{1 \leq |\mathbf{s}| \leq m} \frac{\hat{g}_{\mathbf{s}}^{2}}{|\mathbf{s}|} + \sum_{|\mathbf{s}| > m} \frac{\hat{g}_{\mathbf{s}}^{2}}{|\mathbf{s}|}$$

$$\tag{169}$$

$$\leq \sum_{k=1}^{m} \left(\frac{2^{k}}{k}\right) \|g^{=k}\|_{3/2}^{2} + \frac{1}{m+1} \sum_{|\mathbf{s}| > m} \hat{g}_{\mathbf{s}}^{2} \tag{170}$$

$$\leq \|g\|_{3/2}^2 \sum_{k=1}^m \frac{2^k}{k} + \frac{1}{m+1} \|g\|_2^2, \tag{171}$$

where we use quantum hypercontractivity (Corollary 51) in the first inequality. In order to bound the first sum, we note that  $\sum_{k=1}^{m} 2^k/k \le 4 \cdot 2^m/(m+1)$ , which can be proved by induction, so

$$M^{2}(g) \le \frac{1}{m+1} \left( 4 \cdot 2^{m} \|g\|_{3/2}^{2} + \|g\|_{2}^{2} \right). \tag{172}$$

Now pick m to be the largest integer such that  $2^m \|g\|_{3/2}^2 \le \|g\|_2^2$ . Then  $2^{m+1} \|g\|_{3/2}^2 \ge \|g\|_2^2$ , and also  $m+1 \ge 1$ . Thus

$$m+1 \ge \frac{1}{2} \left( 2\log\left(\frac{\|g\|_2}{\|g\|_{3/2}}\right) + 1 \right),$$
 (173)

implying

$$M^{2}(g) \le \frac{10 \|g\|_{2}^{2}}{2 \log(\|g\|_{2}/\|g\|_{3/2}) + 1}.$$
(174)

Noting that  $||g||_2/||g||_{3/2} \ge (||g||_2/||g||_1)^{1/3}$ , which can be proven using Cauchy-Schwarz, and summing  $M^2(d_i f)$  over i completes the proof of the proposition.

The worst case for this inequality is where the 2-norms and 1-norms of the operators  $\{d_i f\}$  are the same. We therefore address this case in the next section.

#### <span id="page-39-0"></span>11.2 A KKL theorem for anticommuting quantum boolean functions

In this subsection we study the situation where the 2-norms and 1-norms of the operators  $\{d_if\}$  are the same. This situation is the "worst-case scenario" for a straightforward quantum generalisation of the classical proof. We show that if this is the case then f must be a sum of anticommuting quantum boolean functions and so we identify this class as the "most quantum" of quantum boolean functions. While this class might be expected to avoid a KKL-type theorem, we then study a subclass of such quantum boolean functions and the nevertheless provide a lower bound for the influence (which is better than a KKL-type bound).

**Definition 75.** Let f be a quantum boolean function. Then the set  $J \subset [n]$  of variables is said to have *bad influence* on f if

$$\left\| f - \operatorname{tr}_{J}(f) \otimes \frac{\mathbb{I}}{2^{|J|}} \right\|_{2} = \left\| f - \operatorname{tr}_{J}(f) \otimes \frac{\mathbb{I}}{2^{|J|}} \right\|_{1}. \tag{175}$$

<span id="page-39-1"></span>**Lemma 76.** Let M be an  $n \times n$  Hermitian matrix. If  $||M||_2 = ||M||_1$  then the eigenvalues  $\lambda_i$  of M satisfy

$$\lambda_j \in \{-\alpha, +\alpha\}, \quad j \in [n], \tag{176}$$

for some  $\alpha \in \mathbb{R}$ .

*Proof.* Diagonalising M and writing out the equality  $||M||_2^2 = ||M||_1^2$  gives us

$$\frac{1}{n}\sum_{j=1}^{n}|\lambda_{j}|^{2} = \frac{1}{n^{2}} \left( \sum_{j=1}^{n}|\lambda_{j}|^{2} + 2\sum_{j< k}^{n}|\lambda_{j}||\lambda_{k}| \right). \tag{177}$$

Multiplying through by  $n^2$  and rearranging gives us

$$(n-1)\sum_{j=1}^{n} |\lambda_j|^2 - 2\sum_{j< k}^{n} |\lambda_j| |\lambda_k| = 0$$
 (178)

But this is the same as

$$\sum_{j \le k} (|\lambda_j| - |\lambda_k|)^2 = 0, \tag{179}$$

so that  $|\lambda_j| = |\lambda_k| = \alpha$ , j < k, for some constant  $\alpha$ .

The next lemma quantifies the structure of quantum boolean functions with bad influence. We will see that they are highly constrained: they must be a sum of anticommuting quantum boolean functions.

**Lemma 77.** Let f be a quantum boolean function. Then  $J \subset [n]$  has bad influence on f if and only if

$$f = \sqrt{1 - \alpha^2} f' \otimes \mathbb{I}_J + \alpha g \tag{180}$$

where f' and g are quantum boolean functions,  $\{f' \otimes \mathbb{I}_J, g\} = 0$ , and  $\alpha^2 = I_J(f)$ .

*Proof.* Write

$$f = f_{J^c} \otimes \mathbb{I}_J + \sum_{\substack{\sup(\mathbf{s}) \subset J \\ \mathbf{s} \neq \mathbf{0}}} f_{\mathbf{s}} \otimes \chi_{\mathbf{s}}.$$
 (181)

The derivative of f with respect to J is given by

$$d_J(f) = \sum_{\substack{\text{supp}(\mathbf{s}) \subset J\\ \mathbf{s} \neq \mathbf{0}}} f_{\mathbf{s}} \otimes \chi_{\mathbf{s}}.$$
 (182)

Since J has bad influence we have, according to Lemma 76, that

$$|d_J(f)| = \alpha \mathbb{I},\tag{183}$$

so that, defining  $g = \frac{1}{\alpha} d_J(f)$ , we have  $g^2 = \mathbb{I}$ . Thus we can write  $f = f_{J^c} \otimes \mathbb{I}_J + \alpha g$ . We now square f to find

$$\mathbb{I} = f_{J^c}^2 \otimes \mathbb{I}_J + \alpha^2 \mathbb{I} + \alpha \{ f_{J^c} \otimes \mathbb{I}_J, g \}.$$
 (184)

This implies that  $\{f_{J^c} \otimes \mathbb{I}_J, g\} = 0$ . Thus, defining

$$f' = \frac{1}{\sqrt{1 - \alpha^2}} f_{J^c},\tag{185}$$

we have  $f'^2 = \mathbb{I}$  and the result follows.

Let f be quantum boolean with Fourier expansion  $f = \sum_s \hat{f}_s \chi_s$ . If  $[\chi_s, \chi_t] = 0$  for all  $s \neq t$  where  $\hat{f}_s$  and  $\hat{f}_t$  are both non-zero, then we call f commuting. Similarly, if  $\{\chi_s, \chi_t\} = 0$  for all  $s \neq t$  where  $\hat{f}_s$  and  $\hat{f}_t$  are both non-zero, then we call f anticommuting. It follows from the classical KKL theorem that those commuting quantum boolean functions that can be diagonalised by local unitaries have a qubit with influence at least  $\Omega\left(\frac{\log n}{n}\right)$ . In the remainder of this section, we will show that anticommuting quantum boolean functions also have an influential qubit. Indeed, the influence of this qubit must be very high.

**Proposition 78.** Let f be an anticommuting quantum boolean function on n qubits. Then there exists a j such that  $I_j(f) \geq \frac{1}{\sqrt{n}}$ .

*Proof.* Our approach will be to show that  $\sum_{j=1}^n I_j(f)^2 \geq 1$ , whence the theorem follows trivially. Write  $f = \sum_{i=1}^m w_i f_i$  for some m, where  $w_i$  is real and  $f_i$  is an arbitrary stabilizer operator. Let  $S_j$  be the set of indices of the stabilizer operators that act non-trivially on qubit j, i.e. the set  $\{i: d_j(f_i) \neq 0\}$ . Then  $I_j(f) = \sum_{i \in S_j} w_i^2$ , so

$$\sum_{j=1}^{n} I_j(f)^2 = \sum_{j=1}^{n} \left( \sum_{i \in S_j} w_i^2 \right)^2 = \sum_{j=1}^{n} \sum_{i,k \in S_j} w_i^2 w_k^2.$$

Rearrange the sum as follows.

$$\sum_{j=1}^{n} I_j(f)^2 = \sum_{i,k=1}^{m} w_i^2 w_k^2 |\{j : i \in S_j, k \in S_j\}|.$$

For each pair of stabilizer operators  $f_i$ ,  $f_k$  to anticommute, they must both act non-trivially on the same qubit in at least one place. Thus

$$\sum_{j=1}^{n} I_j(f)^2 \ge \sum_{i,k=1}^{m} w_i^2 w_k^2 = \left(\sum_{i=1}^{m} w_i^2\right)^2 = 1$$

and the proof is complete.

This result hints that quantum KKL may be true, as it holds for two "extremal" cases (classical boolean functions and anticommuting quantum boolean functions).

# <span id="page-41-0"></span>12 Conclusions and conjectures

We have introduced the concept of a quantum boolean function, and have quantised some results from the classical theory of boolean functions. However, there is still a hoard of interesting results which we have not yet been able to plunder. We list some specific conjectures in this vein below.

- 1. Quantum locality and dictator testing. We have candidate quantum tests for the properties of locality and being a dictator (Conjectures 17 and 20), but have not been able to analyse their probability of success.
- 2. **General hypercontractivity.** We have proven hypercontractivity of the noise superoperator (Theorem 46) only in the case where  $1 \le p \le 2 \le q \le \infty$ . We conjecture that, as with the classical case, this in fact holds for all  $1 \le p \le q \le \infty$ .
- 3. Every quantum boolean function has an influential variable. The results of Section 11 prove a quantum generalisation of the KKL theorem in some special cases. We conjecture that it holds in general, but, as we argued, a proof of such a theorem appears to require quite different techniques to the classical case.

4. Lower bounds on the degree of quantum boolean functions. A classical result of Nisan and Szegedy [\[NS94\]](#page-45-14) states that the degree of any boolean function that depends on n variables must be at least log n − O(log log n). We conjecture that the degree of any quantum boolean function that acts non-trivially on n qubits is also Ω(log n). The classical proof does not go through immediately: it relies on the fact that the influence of each variable of a degree d boolean function is at least 1/2 d , which is not the case for degree d quantum boolean functions (for a counterexample, see [\(29\)](#page-10-2)).

It is interesting to note that the proofs in the classical theory of boolean functions which go through easily to the quantum case tend to be those based around techniques such as Fourier analysis, whereas proofs based on combinatorial and discrete techniques do not translate easily in general. There are many such combinatorial results which would be interesting to prove or disprove in the quantum regime.

# Acknowledgements

AM was supported by the EC-FP6-STREP network QICS. TJO was supported by the University of London central research fund. We'd like to thank Koenraad Audenaert, Jens Eisert, and Aram Harrow for helpful conversations, and also Ronald de Wolf and a STOC'09 referee for helpful comments on a previous version.

# References

- <span id="page-42-0"></span>[Aar05] Scott Aaronson, Quantum computing, postselection, and probabilistic polynomial-time, Proc. R. Soc. Lond. Ser. A Math. Phys. Eng. Sci. 461 (2005), no. 2063, 3473–3482.
- <span id="page-42-2"></span>[Aar07] , The learnability of quantum states, Proceedings of the Royal Society A 463 (2007), 3089–3114.
- <span id="page-42-4"></span>[AC02] Mark Adcock and Richard Cleve, A quantum Goldreich-Levin Theorem with cryptographic applications, 19th Annual Symposium on Theoretical Aspects of Computer Science (Heidelberg, Berlin) (G. Goos, J. Hartmanis, and J. van Leeuwen, eds.), Lecture notes in computer science, no. 2285, Springer-Verlag, 2002, pp. 323–334.
- <span id="page-42-1"></span>[Aha08] Dorit Aharonov, Pondering about QPCP's, http://cnls.lanl. gov/ CQIT/aharonov.pdf, 2008.
- <span id="page-42-5"></span>[AS07] Alp Atici and Rocco A. Servedio, Quantum algorithms for learning and testing juntas, Quantum Information Processing 6 (2007), 323–348.
- <span id="page-42-3"></span>[BARW08] Avraham Ben-Aroya, Oded Regev, and Ronald de Wolf, A hypercontractive inequality for matrix-valued functions with applications to quantum computing and LDCs, Proceedings of the 49th Annual IEEE Symposium on Foundations of

- Computer Science held in Philadelphia, PA, October 25–28, 2008 (New York), IEEE Computer Society, 2008.
- <span id="page-43-3"></span>[Bec75] William Beckner, Inequalities in Fourier analysis, Ann. of Math. 102 (1975), no. 1, 159–182. MR 0385456 (52 #6317)
- <span id="page-43-6"></span>[BFNR03] Harry Buhrman, Lance Fortnow, Ilan Newman, and Hein R¨ohrig, Quantum property testing, Proceedings of the fourteenth annual ACM-SIAM symposium on Discrete Algorithms 2003 held in Baltimore, Maryland, January 12–14, 2003 (New York), Association for Computing Machinery (ACM), 2003, pp. 480–488.
- <span id="page-43-8"></span>[Bha97] Rajendra Bhatia, Matrix analysis, Springer-Verlag, New York, 1997. MR 98i:15003
- <span id="page-43-7"></span>[BJ99] N. H. Bshouty and J. C. Jackson, Learning DNF over the uniform distribution using a quantum example oracle, SIAM J. Comput. 28 (1999), 1136–1153.
- <span id="page-43-10"></span>[BLR93] Manuel Blum, Michael Luby, and Ronitt Rubinfeld, Self-testing/correcting with applications to numerical problems, Proceedings of the 22nd Annual ACM Symposium on Theory of Computing (Baltimore, MD, 1990), vol. 47, 1993, pp. 549– 595. MR 1248868 (94m:65020)
- <span id="page-43-11"></span>[Bon68] Aline Bonami, Ensembles Λ(p) dans le dual de D∞, Ann. Inst. Fourier 18 (1968), no. fasc. 2, 193–204 (1969). MR 0249940 (40 #3181)
- <span id="page-43-2"></span>[Bon70] , Etude des coefficients de Fourier des fonctions de ´ L p (G), Ann. Inst. Fourier 20 (1970), no. fasc. 2, 335–402 (1971). MR 0283496 (44 #727)
- <span id="page-43-4"></span>[Bou02] Jean Bourgain, On the distribution of the Fourier spectrum of Boolean functions, Isr. J. Math. 131 (2002), no. 1, 269–276.
- <span id="page-43-5"></span>[BV97] Ethan Bernstein and Umesh Vazirani, Quantum complexity theory, SIAM J. Comput. 26 (1997), no. 5, 1411–1473. MR 99a:68053
- <span id="page-43-12"></span>[CL93] E. Carlen and E. Lieb, Optimal hypercontractivity for Fermi fields and related non-commutative integration inequalities, Comm. Math. Phys 155 (1993), 27– 46.
- <span id="page-43-0"></span>[Din07] Irit Dinur, The PCP theorem by gap amplification, Journal of the ACM 54 (2007), no. 3, 241–250.
- <span id="page-43-9"></span>[Fis01] E. Fischer, The art of uninformed decisions: A primer to property testing, Bulletin of the European Association for Theoretical Computer Science 75 (2001), 97–126.
- <span id="page-43-1"></span>[FKN02] Ehud Friedgut, Gil Kalai, and Assaf Naor, Boolean functions whose Fourier transform is concentrated on the first two levels, Adv. in Appl. Math. 29 (2002), no. 3, 427–437.

- <span id="page-44-4"></span>[Fri98] Ehud Friedgut, Boolean functions with low average sensitivity depend on few coordinates, Combinatorica 18 (1998), no. 1, 27–35.
- <span id="page-44-5"></span>[GKK+07] Dmitry Gavinsky, Julia Kempe, Iordanis Kerenidis, Ran Raz, and Ronald de Wolf, Exponential separations for one-way quantum communication complexity, with applications to cryptography, Proceedings of the 39th Annual ACM Symposium on Theory of Computing held in San Diego, CA, June 11–13, 2007 (New York), Association for Computing Machinery (ACM), 2007, pp. 516–525.
- <span id="page-44-1"></span>[GL89] Oded Goldreich and Leonid A. Levin, A hard-core predicate for all one-way functions, In Proceedings of the Twenty First Annual ACM Symposium on Theory of Computing, 1989, pp. 25–32.
- <span id="page-44-2"></span>[Gro75] Leonard Gross, Logarithmic Sobolev inequalities, Amer. J. Math. 97 (1975), no. 4, 1061–1083. MR 0420249 (54 #8263)
- <span id="page-44-6"></span>[H˚as01] Johan H˚astad, Some optimal inapproximability results, J. ACM 48 (2001), no. 4, 798–859 (electronic). MR MR2144931 (2006c:68066)
- <span id="page-44-10"></span>[Has08] M. B. Hastings, A counterexample to additivity of minimum output entropy, Nature Physics 5 (2008), 255.
- <span id="page-44-8"></span>[Hel76] C. W. Helstrom, Quantum detection and estimation theory, Academic Press, New York, 1976.
- <span id="page-44-7"></span>[Hol73] A. S. Holevo, Statistical decision theory for quantum systems, Journal of Multivariate Analysis 3 (1973), 337–394.
- <span id="page-44-9"></span>[HW08] Patrick Hayden and Andreas Winter, Counterexamples to the maximal p-norm multiplicativity conjecture for all p > 1, 2008.
- <span id="page-44-12"></span>[Kal02] G. Kalai, A Fourier-theoretic perspective on the Condorcet paradox and Arrow's theorem, Advances in Applied Mathematics 29 (2002), no. 3, 412–426.
- <span id="page-44-0"></span>[KdW04] Iordanis Kerenidis and Ronald de Wolf, Exponential lower bound for 2-query locally decodable codes via a quantum argument, J. Comput. System Sci. 69 (2004), no. 3, 395–420.
- <span id="page-44-11"></span>[Kin03] C. King, Inequalities for trace norms of 2x2 block matrices, Comm. Math. Phys. 242 (2003), no. 3, 531–545.
- <span id="page-44-3"></span>[KKL88] J. Kahn, G. Kalai, and N. Linial, The influence of variables on Boolean functions, Proceedings of the 29th Annual IEEE Symposium on Foundations of Computer Science (FOCS'88) (Los Alamitos, CA, USA), IEEE Computer Society, 1988, pp. 68–80.
- <span id="page-44-13"></span>[KKMO04] S. Khot, G. Kindler, E. Mossel, and R. O'Donnell, Optimal inapproximability results for MAX-CUT and other 2-variable CSPs?, Proceedings of the 45th Annual IEEE Symposium on Foundations of Computer Science held in Rome,

- Italy, October 17–19, 2004 (New York), IEEE Computer Society, 2004, pp. 146– 154.
- <span id="page-45-4"></span>[KKVB02] E. Kashefi, A. Kent, V. Vedral, and K. Banaszek, A comparison of quantum oracles, Phys. Rev. A 65 (2002), no. 5, 050304.
- <span id="page-45-3"></span>[KM93] E. Kushilevitz and Y. Mansour, Learning decision trees using the Fourier spectrum, Siam J. Comput. 22 (1993), no. 6, 1331–1348.
- <span id="page-45-10"></span>[KR01] C. King and M. B. Ruskai, Minimal entropy of states emerging from noisy quantum channels, Comm. Math. Phys. 47 (2001), no. 1, 192–209.
- <span id="page-45-5"></span>[KRUW08] J. Kempe, O. Regev, F. Unger, and R. de Wolf, Upper bounds on the noise threshold for fault-tolerant quantum computing, Proc. 35th International Colloquium on Automata, Languages and Programming (ICALP'08), 2008, p. 856.
- <span id="page-45-6"></span>[LR72] Elliott H. Lieb and Derek W. Robinson, The finite group velocity of quantum spin systems, Commun. math. Phys. 28 (1972), 251–257. MR 47 #1415
- <span id="page-45-11"></span>[Mos05] Elchanan Mossel, Stat 206A: Polynomials of Random Variables. Berkeley. http://www.stat.berkeley.edu/ mossel/teach/206af05/, 2005.
- <span id="page-45-1"></span>[NC00] Michael A. Nielsen and Isaac L. Chuang, Quantum computation and quantum information, Cambridge University Press, Cambridge, 2000. MR 1 796 805
- <span id="page-45-7"></span>[Nel66] Edward Nelson, A quartic interaction in two dimensions, Mathematical Theory of Elementary Particles (Proc. Conf., Dedham, Mass., 1965), M.I.T. Press, Cambridge, Mass., 1966, pp. 69–73. MR 0210416 (35 #1309)
- <span id="page-45-8"></span>[Nel73] , Construction of quantum fields from Markoff fields, J. Functional Analysis 12 (1973), 97–112. MR 0343815 (49 #8555)
- <span id="page-45-14"></span>[NS94] Noam Nisan and Mario Szegedy, On the degree of Boolean functions as real polynomials, Computational Complexity 4 (1994), no. 4, 301–313.
- <span id="page-45-0"></span>[O'D07] Ryan O'Donnell, 15-859S: Analysis of Boolean Functions. Carnegie Mellon University. http://www.cs.cmu.edu/∼odonnell/boolean-analysis/, 2007.
- <span id="page-45-2"></span>[RS06] Jaikumar Radhakrishnan and Madhu Sudan, On Dinur's proof of the PCP theorem, Bull. Amer. Math. Soc. 44 (2006), no. 1, 19–61.
- <span id="page-45-9"></span>[Rud60] Walter Rudin, Trigonometric series with gaps, J. Math. Mech. 9 (1960), 203– 227. MR 0116177 (22 #6972)
- <span id="page-45-12"></span>[Sch80] J. T. Schwartz, Fast probabilistic algorithms for verification of polynomial identities, J. Assoc. Comput. Mach. 27 (1980), 701–717.
- <span id="page-45-13"></span>[Tal94] Michel Talagrand, On Russo's approximate zero-one law, Ann. Prob. 23 (1994), no. 3, 1576–1587.

- <span id="page-46-2"></span>[Tal96] , How much are increasing sets positively correlated?, Combinatorica 16 (1996), no. 2, 243–258.
- <span id="page-46-0"></span>[Wol08] Ronald de Wolf, A brief introduction to Fourier analysis on the boolean cube, Theory of Computing Library, Graduate Surveys 1 (2008), 1–20.
- <span id="page-46-1"></span>[Zip79] R. Zippel, Probabilistic algorithms for sparse polynomials, Proc. EUROSAM'79, Lecture Notes in Computer Science, vol. 72, Springer-Verlag, 1979, pp. 216–226.