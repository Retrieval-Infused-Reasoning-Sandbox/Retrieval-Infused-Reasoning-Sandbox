# Simple algorithms to test and learn local Hamiltonians

Francisco Escudero Gutiérrez\*

April 10, 2024

#### Abstract

We consider the problems of testing and learning an n-qubit k-local Hamiltonian from queries to its evolution operator with respect the 2-norm of the Pauli spectrum, or equivalently, the normalized Frobenius norm. For testing whether a Hamiltonian is  $\varepsilon_1$ -close to k-local or  $\varepsilon_2$ -far from k-local, we show that  $O(1/(\varepsilon_2 - \varepsilon_1)^8)$  queries suffice. This solves two questions posed in a recent work by Bluhm, Caro and Oufkir. For learning up to error  $\varepsilon$ , we show that  $\exp(O(k^2 + k \log(1/\varepsilon)))$  queries suffice. Our proofs are simple, concise and based on Paulianalytic techniques.

## 1 Introduction

In this work we consider the problems of testing and learning a local Hamiltonian from its time evolution operator. These kinds of Hamiltonians govern the dynamics of many physical systems, which motivates the problem of testing if an unknown Hamiltonian is local and, if it is local, to learn it in an efficient way. In fact, there is vast and recent literature about learning a local Hamiltonian from its time evolution operator [dSLCP11, BAL19, ZYLB21, HKT22, WKR<sup>+</sup>22, YSHY23, Car23, DOS23, HTFS23, CW23, LTN<sup>+</sup>23, MBC<sup>+</sup>23, SFMD<sup>+</sup>24, GCC24], but the first testing algorithm was only proposed recently by Bluhm, Caro and Oufkir [BCO24a]. There are also many of results about learning a Hamiltonian from its Gibbs state [AAKS21, HKT22, RSF23, ORSFW23, BLMT23, GCC24], but in this work we will only consider the model where one accesses the Hamiltonian through queries to its evolution operator.

An *n*-qubit Hamiltonian H is a self-adjoint operator acting on  $(\mathbb{C}^2)^{\otimes n}$ . As such, it can be expanded in terms of the Pauli strings as

$$H = \sum_{x \in \{0,1,2,3\}^n} h_x \sigma_x,$$

where  $h_x$  are real numbers and  $\sigma_x = \bigotimes_{i \in [n]} \sigma_{x_i}$ , where  $\sigma_0 = \operatorname{Id}_2$ ,  $\sigma_1 = X$ ,  $\sigma_2 = Y$ ,  $\sigma_3 = Z$ . The coefficients  $h_x$  are known as the Pauli spectrum of the Hamiltonian. A Hamiltonian H is k-local if it is supported on Pauli strings that act trivially on all but at most k qubits. In other words, H is k-local if  $h_x = 0$  for all  $x \in \{0, 1, 2, 3\}^n$  that take values different from 0 on more than k sites. If H is the Hamiltonian describing the dynamics of a certain physical system, then the states of that system evolve according to the time evolution operator  $U(t) = e^{-iHt}$ . This means that if  $\rho(0)$  is the state at time 0, at time t the state will have evolved to  $\rho(t) = U(t)\rho(0)U^{\dagger}(t)$ . Hence,

<sup>\*</sup>Qusoft and CWI feg@cwi.nl

to test and learn a Hamiltonian one can do the following: prepare a desired state, apply U(t) or tensor products of U(t) with identity to the state (i.e., query U(t)), and finally measure in a chosen basis. It is usual to impose the normalization condition  $||H||_{\infty} \leq 1$  (i.e., that the eigenvalues of H are bounded in absolute value by 1), as otherwise the complexities scale with the norm of the Hamiltonian. Given a distance d in the space of Hamiltonians, H is  $\varepsilon$ -far from being k-local if for every k-local H' it satisfies that  $d(H, H') > \varepsilon$ , and otherwise is  $\varepsilon$ -close. Now we are ready to state the testing and learning problems.

<span id="page-1-0"></span>**Problem 1** (Tolerant Hamiltonian locality testing). Let  $0 \le \varepsilon_1 < \varepsilon_2$ ,  $\delta \in (0,1)$ ,  $k \in \mathbb{N}$  and d be a distance between Hamiltonians. Let H be an n-qubit Hamiltonian with  $||H||_{\infty} \le 1$  that is promised to be either  $\varepsilon_1$ -close to k-local or  $\varepsilon_2$ -far from k-local. The problem is to decide between those cases with success probability  $\ge 1 - \delta$  by making queries to U(t).

<span id="page-1-3"></span>**Problem 2** (Local Hamiltonian learning). Let  $\varepsilon > 0$ ,  $\delta \in (0,1)$ ,  $k \in \mathbb{N}$  and d be a distance between Hamiltonians. Let H be a k-local n-qubit Hamiltonian with  $||H||_{\infty} \le 1$ . The problem is to output a classical description of a k-local Hamiltonian H' that is  $\varepsilon$ -close to H with probability  $\ge 1 - \delta$  by making queries to U(t).

In both problems, the main goals are minimizing the number of queries and the total evolution time. These quantities depend on the distance d. The recent learning literature usually takes d to be the supremum distance of the Pauli spectrum  $(d(H, H') = ||H - H'||_{\text{Pauli},\infty} = \max_x |h_x - h'_x|),$ and imposes extra constraints on the Pauli spectrum (generally some kind of geometrical locality, such as assuming that the qubits are displayed in a grid and the Pauli terms only act on neighboring qubits). However, if one wants to convert these learning algorithms to learners under a finer distance such as the 2-norm of the Pauli spectrum  $(d(H,H) = ||H - H'||_2 = \sqrt{\sum_x |h_x - h_x'|^2}$ , which equals the normalized Frobenius norm due to Parseval's identity) it is not clear how to avoid a poly $(n^k)$ term appearing, due to the fact that there are  $n^k$  Pauli strings that are k-local. This 2-norm of the Pauli spectrum was recently considered by Bluhm, Caro and Oufkir [BCO24a], who proved that to learn an arbitrary n-qubit Hamiltonian under this distance it is necessary to make  $\Omega(2^{2n})$ queries to the time evolution operator. In the first version of their work, they also proposed a nontolerant testing algorithm, meaning that it only works for the case  $\varepsilon_1 = 0$ , whose query complexity is  $O(n^{2k+2}/(\varepsilon_2-\varepsilon_1)^4)$  and with total evolution time  $O(n^{k+1}/(\varepsilon_2-\varepsilon_1)^3)$ . They posed as open questions whether the dependence on n could be removed and whether an efficient tolerant-tester was possible BCO24a, Section 1.5. Our first result gives positive answer to both questions. From now on, unless otherwise mentioned, we will consider the distance d to be the one induced by the 2-norm of the Pauli spectrum.

<span id="page-1-2"></span>**Theorem 3** (Locality testing). There is an algorithm that solves the locality testing problem (Problem 1) by making  $O(1/(\varepsilon_2 - \varepsilon_1)^8 \cdot \log(1/\delta))$  queries to the evolution operator and with  $O(1/(\varepsilon_2 - \varepsilon_1)^7 \cdot \log(1/\delta))$  total evolution time.

Our algorithm to test for locality is simple. It consists of repeating the following process  $1/(\varepsilon_2 - \varepsilon_1)^8$  times: prepare n EPR pairs, apply  $U(\varepsilon_2 - \varepsilon_1) \otimes \operatorname{Id}_{2^n}$  to them and measure in the Bell basis. Each time that we repeat this process, we sample from the Pauli sprectrum of  $U(\varepsilon_2 - \varepsilon_1)^1$ . As  $\varepsilon_2 - \varepsilon_1$  is small, Taylor expansion ensures that  $U(\varepsilon_2 - \varepsilon_1) \approx \operatorname{Id}_{2^n} -i(\varepsilon_2 - \varepsilon_1)H$ , so sampling from the Pauli spectrum of  $U(\varepsilon_2 - \varepsilon_1)$  allows us to estimate the weight of the non-local terms of H. If that weight is big, we output that H is far from k-local, and otherwise we conclude that H is close to k-local.

<span id="page-1-1"></span>The Pauli spectrum of a unitary  $U = \sum_x u_x \sigma_x$  determines a probability distribution because  $\sum_x |u_x|^2 = 1$ .

After sharing Theorem 3 with Bluhm, Caro and Oufkir, they independently improved the analysis of their testing algorithm. They showed that in a certain broad regime their tester is tolerant, only makes  $O(1/((\varepsilon_2 - \varepsilon_1)^3 \varepsilon_2))$  queries and just requires  $O(1/((\varepsilon_2 - \varepsilon_1)^{2.5} \varepsilon_2^{0.5}))$  total evolution time [BCO24b, Theorem B.5]. To compare Theorem 3 with the improved testing result of Bluhm, Caro and Oufkir, we should introduce a family of problems that has locality testing as an instance. Given a subset S of  $\{0,1,2,3\}^n$ , we define the problem of testing property S as the problem of testing whether H is  $\varepsilon_1$ -close to be supported on S or  $\varepsilon_2$ -far from being supported on S. By taking S equal to the set of strings that take the value 0 on at least n-k sites one recovers the k-locality testing problem. Both our Theorem 3 and their testing result work for testing properties defined by sets S. The advantages of their algorithm are that it uses no auxiliary qubits, while ours requires n, and it is quadratically better than ours with respect to  $\varepsilon_2 - \varepsilon_1$ . The advantages of our algorithm are that it works for any S, while theirs only works for  $|S| = O(2^n(\varepsilon_2^2 - \varepsilon_1^2)^2)$ , although they can remove this constraint by allowing access to  $O(\log(|S|^3/2^n) + \log(1/(\varepsilon_2 - \varepsilon_1)))$  auxiliary qubits; that our algorithm just needs  $O(1/(\varepsilon_2 - \varepsilon_1)^8)$  classical post-processing time, while theirs requires  $O(n^2|S|/((\varepsilon_2-\varepsilon_1)^3\varepsilon_2))$  time; and that theirs needs H to be traceless, while ours does not. A technical feature of our result is that the proof is simpler and more concise than theirs.

<span id="page-2-0"></span>Our second result is a learning algorithm for k-local Hamiltonians.

**Theorem 4** (Local Hamiltonian learning). There is an algorithm that solves the local Hamiltonian learning problem (Problem 2) by making  $\exp(O(k^2 + k \log(1/\varepsilon)) \log(1/\delta))$  queries to the evolution operator with  $\exp(O(k^2 + k \log(1/\varepsilon)) \log(1/\delta))$  total evolution time.

The learning algorithm of Theorem 4 has two stages. In the first stage one samples from the Pauli distribution of  $U(\varepsilon)$ , as in the testing algorithm, and from that one can detect which are the big Pauli coefficients of H. In the second stage we learn those big Pauli coefficients using the SWAP test on  $U(\varepsilon)$ , as proposed by Montanaro and Osborne [MO08, Lemma 24]. One can ensure that the coefficients not detected as big in the first stage of the algorithm can be neglected. To do that we borrow the ideas of Eskenazis and Ivanisvili for the classical low-degree learning problem [EI22], combined with the non-commutative Bohnenblust-Hille inequality proved by Huang, Chen and Preskill [HCP23], and improved by Volberg and Zhang [VZ23].

Most previous work on Hamiltonian learning is done under the distance induced by the supremum norm of the Pauli spectrum and with extra constraints apart from locality [dSLCP11, BAL19, ZYLB21, HKT22, WKR<sup>+</sup>22, YSHY23, Car23, DOS23, HTFS23, LTN<sup>+</sup>23, MBC<sup>+</sup>23, SFMD<sup>+</sup>24, GCC24]. When transformed into learning algorithms under the finer distance induced by the 2-norm of the Pauli spectrum, these proposals yield complexities that depend polynomially on  $n^k$  and only work for a restricted family of k-local Hamiltonians. A work that explicitly considers the problem of learning under the 2-norm of the Pauli spectrum is the one of Castaneda and Wiebe [CW23]. However, their results require query access to the inverse time evolution operator  $e^{-itH}$  and yield complexities of order  $O(n^k)$ . Hence, to the best of our knowledge, Theorem 4 is the first learning result that has no dependence on n when considering the 2-norm of Pauli spectrum and works for any kind of k-local Hamiltonian. Regarding the tightness of its query complexity, the  $\exp(\Omega(k))$  query lower bound of Bluhm, Caro and Oufkir [BCO24a] to learn k-qubit Hamiltonians shows that our algorithm cannot be improved much. Closing the gap between this lower bound and our  $\exp(O(k^2))$  query upper bound remains an intriguing open problem.

## 2 Preliminaries

In this section we collect a few well-known facts that we will repeatedly use in our proofs. Given an *n*-qubit operator  $A = \sum_{x} a_x \sigma_x$ , Parseval's identity states that its normalized Frobenius norm equals the 2-norm of its Pauli spectrum. We will denote both by  $||A||_2$ ,

$$||A||_2 = \sqrt{\frac{\text{Tr}[A^{\dagger}A]}{2^n}} = \sqrt{\sum_{x \in \{0,1,2,3\}^2} |a_x|^2}.$$

Given  $x \in \{0, 1, 2, 3\}^n$ , we define |x| as the number of sites where x does not take the value  $0, A_{>k}$  as  $\sum_{|x|>k} a_x \sigma_x$  and  $A_{\leq k}$  as  $\sum_{|x|\leq k} a_x \sigma_x$ . From the formulation of the 2-norm in terms of the Pauli coefficients it follows that  $\|A_{>k}\|_2 \leq \|A\|_2$ , while from its formulation as the normalized Frobenius norm one has that  $\|A\|_2 \leq \|A\|_\infty$ . We recall that  $\|A\|_\infty$  is the biggest singular value of A. We note that the distance of a Hamiltonian H from the space of k-local Hamiltonians is given by  $\|H_{>k}\|_2$ , as  $H_{< k}$  is the k-local Hamiltonian closest to H.

It follows from Parseval's identity that if U is a unitary, then  $\sum |u_x|^2 = 1$ . In other words,  $(|u_x|^2)_x$  is a probability distribution. Applying  $U \otimes \operatorname{Id}_{2^n}$  to n EPR pairs (i.e., preparing the Choi-Jamiolkowski state of U) and measuring in the Bell basis allows one to sample from this distribution, because

$$U \otimes \operatorname{Id}_{2^n} | \operatorname{EPR}_n \rangle = \sum_{x \in \{0.1, 2.3\}^n} u_x \otimes_{i \in [n]} (\sigma_{x_i} \otimes \operatorname{Id}_2 | \operatorname{EPR} \rangle),$$

and the Bell states can be written as  $\sigma_x \otimes \operatorname{Id}_2 | \operatorname{EPR} \rangle$  for  $x \in \{0, 1, 2, 3\}$ .

We will also use that given a Hamiltonian H with  $||H||_{\infty} \leq 1$ , the Taylor expansion of the exponential allows us to approximate the time evolution operator as

$$U(t) = e^{-itH} = \text{Id}_{2^n} - itH + ct^2 R_2(t)$$

for  $t \leq 1/2$ , where the second order remainder  $R_2(t)$  is bounded  $||R_2(t)||_{\infty} \leq 1$  and c > 0 is a universal constant.

# 3 Testing locality

In this section we prove Theorem 3. First, we prove a claim regarding the discrepancy on the weights of non-local terms of the short-time evolution operator for close-to-local and far-from-local Hamiltonians.

<span id="page-3-0"></span>Claim 5. Let  $0 \le \varepsilon_1 < \varepsilon_2$ . Let  $\alpha = (\varepsilon_2 - \varepsilon_1)/(3c)$  and H be an n-qubit Hamiltonian with  $||H||_{\infty} \le 1$ . We have that if H is  $\varepsilon_1$ -close k-local, then

$$\|U(\alpha)_{>k}\|_{2} \leq (\varepsilon_{2} - \varepsilon_{1}) \frac{2\varepsilon_{1} + \varepsilon_{2}}{9c},$$

and if H is  $\varepsilon_2$ -far from being k-local, then

$$||U(\alpha)\rangle_k||_2 \ge (\varepsilon_2 - \varepsilon_1) \frac{\varepsilon_1 + 2\varepsilon_2}{9c}.$$

*Proof:* To save on notation, we set  $U = U(\alpha)$  and  $R = R_2(\alpha)$ . First, assume that H is  $\varepsilon_1$ -close k-local. Then

$$\|U_{>k}\|_{2} \le \alpha \|H_{>k}\|_{2} + c\alpha^{2} \|R_{>k}\|_{2} \le \frac{\varepsilon_{2} - \varepsilon_{1}}{3c} \varepsilon_{1} + c\left(\frac{\varepsilon_{2} - \varepsilon_{1}}{3c}\right)^{2} = (\varepsilon_{2} - \varepsilon_{1}) \frac{2\varepsilon_{1} + \varepsilon_{2}}{9c},$$

where in the first inequality we have used the triangle inequality and the Taylor expansion, and in the second that H is  $\varepsilon_1$ -close to k-local and that  $\|R_{>k}\|_2 \le \|R\|_2 \le 1$  because  $\|R\|_2 \le \|R\|_\infty \le 1$ . Now, assume that H is  $\varepsilon_2$ -far from being k-local. Then

$$||U_{>k}||_2 \ge \alpha ||H_{>k}||_2 - c\alpha^2 ||R_{>k}||_2 \ge \frac{\varepsilon_2 - \varepsilon_1}{3c} \varepsilon_2 - c\left(\frac{\varepsilon_2 - \varepsilon_1}{3c}\right)^2 \ge (\varepsilon_2 - \varepsilon_1) \frac{\varepsilon_1 + 2\varepsilon_2}{9c},$$

where in first inequality we have used again Taylor expansion and the triangle inequality, and in the second the fact that being  $\varepsilon_2$ -far from k-local implies that  $\|H_{>k}\|_2 \ge \varepsilon_2$ .

Proof of Theorem 3: Applying  $U(\alpha) \otimes \operatorname{Id}_{2^n}$  to  $|\operatorname{EPR}_n\rangle$  and measuring in the Bell basis allows one to sample from  $(|U(\alpha)_x|^2)_x$ . Thus, by the Hoeffding bound, with  $O(1/(\varepsilon_2 - \varepsilon_1)^8 \cdot \log(1/\delta))$  queries to  $U(\alpha) \otimes \operatorname{Id}_{2^n}$  one can estimate  $\sum_{|x|>k} |U(\alpha)_x|^2$  up to an error  $((\varepsilon_2 - \varepsilon_1)^2/(18c))^2$  with success probability  $1-\delta$ . Taking  $\alpha = (\varepsilon_2 - \varepsilon_1)/(3c)$ , thanks to Claim 5, this is enough for testing k-locality.  $\square$ 

Remark 6. The algorithm of Theorem 3 also works to test any property defined by a set of Pauli strings  $S \subseteq \{0,1,2,3\}^n$ , i.e., to test whether  $\sqrt{\sum_{x\notin S} h_x^2} \le \varepsilon_1$  or  $\sqrt{\sum_{x\notin S} h_x^2} \ge \varepsilon_2$ . Also, a union bound allows us to simultaneously test M properties defined by sets  $S_1,...,S_M$  by paying a factor of  $\log M$  in the query complexity and total evolution time.

## 4 Learning local Hamiltonians

In this section we prove Theorem 4. To do that, we need the non-commutative Bohnenblust-Hille inequality by Volberg and Zhang [VZ23], which they used to give an algorithm to learn local observables.

<span id="page-4-1"></span>**Theorem 7** (Non-Commutative Bohnenblust-Hille inequality). Let  $H = \sum_x h_x \sigma_x$  be a k-local Hamiltonian with  $||H||_{\infty} \leq 1$ . Then, there is a universal constant C such that

$$\sum_{x \in \{0,1,2,3\}^n} |h_x|^{\frac{2k}{k+1}} \le C^k.$$

Proof of Theorem 4: Let  $\alpha, \beta, \gamma$  be fixed later. Let U be the evolution operator  $U(\alpha)$  at time  $\alpha$  and R be the Taylor remainder  $R_2(\alpha)$ . Our learning algorithm has two stages, the first to detect the big Pauli coefficients and the second to learn those big Pauli coefficients.

First stage of the algorithm: detect the big Pauli coefficients. In this stage we prepare  $U \otimes \operatorname{Id}_{2^n} | \operatorname{EPR}_n \rangle$  and measure in the Bell basis  $O(\gamma^4 \log(1/\delta))$  times. This way we sample  $O(\gamma^4 \log(1/\delta))$  times from  $(|u_x|^2)_x$ . By [Can20, Theorem 9] the empirical distribution  $|u_x'|^2$  obtained from these samples approximates  $|u_x|^2$  up to error  $\gamma^2$  for every  $x \in \{0, 1, 2, 3\}^n$  with success probability  $\geq 1 - \delta$ . Let  $S_{\gamma} = \{x : |u_x'| > \gamma\} \setminus \{0^n\}$  be the set of big Pauli coefficients. Note that if x does not belong to  $S_{\gamma}$ , then  $u_x$  is indeed small since

<span id="page-4-0"></span>
$$x \notin S_{\gamma} \land x \neq 0 \implies |u_x| \leq |u_x'| + |u_x - u_x'| \leq 2\gamma. \tag{1}$$

Also note that  $u_0 = 1 - i\alpha h_0 + c\alpha^2 R_0$  and that  $u_x = -i\alpha h_x + c\alpha^2 R_x$  for every  $x \neq 0^n$ . As  $||R||_{\infty} \leq 1$ , we have that  $||c\alpha^2 R||_{\infty}^2 \leq c^2 \alpha^4$ . As  $||R||_{\infty} \leq ||R||_{\infty}$ , this implies that

<span id="page-5-1"></span>
$$|(u_0 - 1) + i\alpha h_0|^2 + \sum_{x \neq 0} |u_x + i\alpha h_x|^2 \le c^2 \alpha^4$$
(2)

and in particular for every  $x \neq 0$ 

<span id="page-5-0"></span>
$$|u_x + i\alpha h_x| \le c\alpha^2. (3)$$

Putting Eqs. (1) and (3) together it follows that

$$x \notin S_{\gamma} \land x \neq 0 \implies |h_x| \leq \alpha^{-1}[|u_x| + |u_x + i\alpha h_x|] \leq \alpha^{-1}(2\gamma + c\alpha^2). \tag{4}$$

Moreover, as  $\sum_{x} |u'_{x}|^{2} = 1$ , we have that  $|S_{\gamma}| \leq \gamma^{-2}$ .

Second stage of the algorithm: learn the big Pauli coefficients. Montanaro and Osborne proposed a simple primitive to estimate a given Pauli coefficient of a unitary up to error  $\beta$  with success probability  $\geq 1 - \delta$  by making  $O((1/\beta)^2 \log(1/\delta))$  queries [MO08, Lemma 24]. We use this primitive to learn the Pauli coefficients of  $u_x$  up to error  $\beta$  with success probability  $\geq 1 - \delta$  for every  $x \in S_\gamma \cup \{0^n\}$ . As,  $|S_\gamma| \leq \gamma^{-2}$ , by a union bound, this stage requires  $O(\beta^{-2}\gamma^{-2}\log(1/(\gamma^2\delta)))$  queries to U. Let  $u_x''$  be these estimates. We output  $H'' = \text{Re}(i\alpha^{-1}(u_0''-1))\sigma_0 + \sum_{x \in S_\gamma} \text{Re}(i\alpha^{-1}u_x'')\sigma_x$  as our approximation of H (we take the real part to ensure that H'' is self-adjoint).

Correctness of the algorithm. We claim that with an appropriate choice of the parameters H'' is a good approximation of H. First, as the Pauli coefficients of H are real we have that

$$||H - H''||_{2}^{2} = \alpha^{-2}|\operatorname{Re}(i(u_{0}'' - 1)) - \alpha h_{0}|^{2} + \alpha^{-2} \sum_{x \in S_{\gamma}} |\operatorname{Re}(iu_{x}'') - \alpha h_{x}|^{2} + \sum_{x \notin S_{\gamma}} |h_{x}|^{2}$$

$$\leq \alpha^{-2}|(u_{0}'' - 1) + i\alpha h_{0}|^{2} + \alpha^{-2} \sum_{x \in S_{\gamma}} |u_{x}'' + i\alpha h_{x}|^{2} + \sum_{x \notin S_{\gamma}} |h_{x}|^{2}.$$
(II)

Second, we give an upper bound to term (I):

$$\begin{aligned} &(\mathrm{I}) \leq 2\alpha^{-2}[|(u_0 - 1) + i\alpha h_0|^2 + |u_0'' - u_0|^2] + 2\alpha^{-2} \sum_{x \in S_\gamma} [|u_x + i\alpha h_x|^2 + |u_x'' - u_x|^2] \\ &\leq 2c^2\alpha^2 + 2\alpha^{-2}\beta^2(\gamma^{-2} + 1) \end{aligned}$$

where in the first step we have used the triangle inequality and that  $(a+b)^2 \leq 2(a^2+b^2)$ ; and in the second step Eq. (2) to upper bound the error due to approximating  $h_x$  from  $u_x$ , and the learning guarantees of the second stage of the algorithm and that  $|S_{\gamma}| \leq \gamma^{-2}$  to upper bound the error due to approximating  $u_x$  by  $u_x''$ . Third, we upper bound term (II)

(II) 
$$\leq \max_{x \notin S_{\gamma}} \{|h_x|^{2/k+1}\} \sum_{x \notin S_{\gamma}} |h_x|^{2k/k+1} \leq (2\gamma\alpha^{-1} + c\alpha)^{2/k+1}C^k,$$

where in the first step we have used that 2 = 2/(k+1) + 2k/(k+1), and in the second step Theorem 7 and Eq. (2). Finally, if we put everything together we get

$$||H - H''||_2^2 \le 2c^2\alpha^2 + 2\alpha^{-2}\beta^2(\gamma^{-2} + 1) + (2\gamma\alpha^{-1} + c\alpha)^{2/k+1}C^k.$$

Thus, if we take  $\alpha = \varepsilon^{k+1} C^{-k(k+1)/2}$ ,  $\gamma = \alpha^2$ , and  $\beta = \alpha^3 \varepsilon$  it follows that  $||H - H''||_2^2 \le O(\varepsilon^2)$ , as desired.

Query complexity and total evolution time. Taking both stages of the algorithm into account we make  $O(\gamma^{-4}\log(1/\delta) + \gamma^{-2}\beta^{-2}\log(1/(\gamma^2\delta)))$  queries to  $U(\alpha)$ . Hence, by taking  $\alpha, \beta$  and  $\gamma$  as above, one obtains the claimed query complexity and total evolution time.

**Acknowledgements.** I thank Srinivasan Arunachalam and Matthias Caro for detailed comments and advice about presentation. I thank Amira Abbas and Jop Briët for useful comments, discussions and encouragement. I thank Andreas Bluhm, Arkopal Dutt and Aadil Oufkir for useful comments and discussions. This research was supported by the European Union's Horizon 2020 research and innovation programme under the Marie Skłodowska-Curie grant agreement no. 945045, and by the NWO Gravitation project NETWORKS under grant no. 024.002.003.

### References

- <span id="page-6-6"></span>[AAKS21] Anurag Anshu, Srinivasan Arunachalam, Tomotaka Kuwahara, and Mehdi Soleimanifar. Sample-efficient learning of interacting quantum systems. *Nature Physics*, 17(8):931–935, 2021. doi:10.1038/s41567-021-01232-0.
- <span id="page-6-1"></span>[BAL19] Eyal Bairey, Itai Arad, and Netanel H. Lindner. Learning a local Hamiltonian from local measurements. *Physical Review Letters*, 122(2):020504, 2019. doi:10.1103/PhysRevLett.122.020504.
- <span id="page-6-5"></span>[BCO24a] Andreas Bluhm, Matthias C Caro, and Aadil Oufkir. Hamiltonian property testing (version 1). 2024. arXiv:2403.02968v1.
- <span id="page-6-8"></span>[BCO24b] Andreas Bluhm, Matthias C Caro, and Aadil Oufkir. Hamiltonian property testing (version 2). 2024. arXiv:2403.02968v2.
- <span id="page-6-7"></span>[BLMT23] Ainesh Bakshi, Allen Liu, Ankur Moitra, and Ewin Tang. Learning quantum hamiltonians at any temperature in polynomial time, 2023. arXiv:2310.02243.
- <span id="page-6-9"></span>[Can20] Clément L Canonne. A short note on learning discrete distributions. 2020. arXiv:2002.11457.
- <span id="page-6-2"></span>[Car23] Matthias C. Caro. Learning quantum processes and hamiltonians via the pauli transfer matrix, 2023. arXiv:2212.04471.
- <span id="page-6-4"></span>[CW23] Juan Castaneda and Nathan Wiebe. Hamiltonian learning via shadow tomography of pseudo-choi states, 2023. arXiv:2308.13020.
- <span id="page-6-3"></span>[DOS23] Alicja Dutkiewicz, Thomas E. O'Brien, and Thomas Schuster. The advantage of quantum control in many-body hamiltonian learning, 2023. arXiv:2304.07172.
- <span id="page-6-0"></span>[dSLCP11] Marcus P. da Silva, Olivier Landon-Cardinal, and David Poulin. Practical characterization of quantum devices without tomography. *Physical Review Letters*, 107(21):210404, 2011. doi:10.1103/PhysRevLett.107.210404.

- <span id="page-7-11"></span>[EI22] Alexandros Eskenazis and Paata Ivanisvili. Learning low-degree functions from a logarithmic number of random queries. In *Proceedings of the 54th Annual ACM SIGACT Symposium on Theory of Computing*, STOC 2022, page 203–207, New York, NY, USA, 2022. Association for Computing Machinery. [doi:10.1145/3519935.3519981](https://doi.org/10.1145/3519935.3519981).
- <span id="page-7-7"></span>[GCC24] Andi Gu, Lukasz Cincio, and Patrick J. Coles. Practical hamiltonian learning with unitary dynamics and gibbs states. *Nature Communications*, 15(1), 2024. [doi:10.1038/s41467-023-44008-1](https://doi.org/10.1038/s41467-023-44008-1).
- <span id="page-7-12"></span>[HCP23] Hsin-Yuan Huang, Sitan Chen, and John Preskill. Learning to predict arbitrary quantum processes. *PRX Quantum*, 4(4):040337, 2023. [doi:10.1103/PRXQuantum.4.040337](https://doi.org/10.1103/PRXQuantum.4.040337).
- <span id="page-7-0"></span>[HKT22] Jeongwan Haah, Robin Kothari, and Ewin Tang. Optimal learning of quantum hamiltonians from high-temperature gibbs states. In *2022 IEEE 63rd Annual Symposium on Foundations of Computer Science (FOCS)*, pages 135–146. IEEE, 2022. [doi:10.1109/FOCS54457.2022.00020](https://doi.org/10.1109/FOCS54457.2022.00020).
- <span id="page-7-3"></span>[HTFS23] Hsin-Yuan Huang, Yu Tong, Di Fang, and Yuan Su. Learning many-body hamiltonians with heisenberg-limited scaling. *Physical Review Letters*, 130(20):200403, 2023. [doi:10.1103/PhysRevLett.130.200403](https://doi.org/10.1103/PhysRevLett.130.200403).
- <span id="page-7-4"></span>[LTN+23] Haoya Li, Yu Tong, Hongkang Ni, Tuvia Gefen, and Lexing Ying. Heisenberg-limited hamiltonian learning for interacting bosons, 2023. [arXiv:2307.04690](https://arxiv.org/abs/2307.04690).
- <span id="page-7-5"></span>[MBC+23] Tim M¨obus, Andreas Bluhm, Matthias C. Caro, Albert H. Werner, and Cambyse Rouz´e. Dissipation-enabled bosonic hamiltonian learning via new informationpropagation bounds, 2023. [arXiv:2307.15026](https://arxiv.org/abs/2307.15026).
- <span id="page-7-10"></span>[MO08] Ashley Montanaro and Tobias J Osborne. Quantum Boolean functions. 2008. [arXiv:0810.2435](https://arxiv.org/abs/0810.2435).
- <span id="page-7-9"></span>[ORSFW23] Emilio Onorati, Cambyse Rouz´e, Daniel Stilck Fran¸ca, and James D. Watson. Efficient learning of ground & thermal states within phases of matter, 2023. [arXiv:2301.12946](https://arxiv.org/abs/2301.12946).
- <span id="page-7-8"></span>[RSF23] Cambyse Rouz´e and Daniel Stilck Fran¸ca. Learning quantum many-body systems from a few copies, 2023. [arXiv:2107.03333](https://arxiv.org/abs/2107.03333).
- <span id="page-7-6"></span>[SFMD+24] Daniel Stilck Fran¸ca, Liubov A. Markovich, V. V. Dobrovitski, Albert H. Werner, and Johannes Borregaard. Efficient and robust estimation of many-qubit hamiltonians. *Nature Communications*, 15:311, 2024. [doi:10.1038/s41467-023-44012-5](https://doi.org/10.1038/s41467-023-44012-5).
- <span id="page-7-13"></span>[VZ23] Alexander Volberg and Haonan Zhang. Noncommutative Bohnenblust–Hille inequalities. *Mathematische Annalen*, pages 1–20, 2023. [doi:10.1007/s00208-023-02680-0](https://doi.org/10.1007/s00208-023-02680-0).
- <span id="page-7-1"></span>[WKR+22] Frederik Wilde, Augustine Kshetrimayum, Ingo Roth, Dominik Hangleiter, Ryan Sweke, and Jens Eisert. Scalably learning quantum many-body hamiltonians from dynamical data, 2022. [arXiv:2209.14328](https://arxiv.org/abs/2209.14328).
- <span id="page-7-2"></span>[YSHY23] Wenjun Yu, Jinzhao Sun, Zeyao Han, and Xiao Yuan. Robust and efficient hamiltonian learning. *Quantum*, 7:1045, 2023. [doi:10.22331/q-2023-06-29-1045](https://doi.org/10.22331/q-2023-06-29-1045).

<span id="page-8-0"></span>[ZYLB21] Assaf Zubida, Elad Yitzhaki, Netanel H. Lindner, and Eyal Bairey. Optimal shorttime measurements for hamiltonian learning, 2021. [arXiv:2108.08824](https://arxiv.org/abs/2108.08824).