## Mathematics Department, Princeton University

On the Absolute Convergence of Dirichlet Series Author(s): H. F. Bohnenblust and Einar Hille

Source: Annals of Mathematics, Vol. 32, No. 3 (Jul., 1931), pp. 600-622

Published by: Mathematics Department, Princeton University

Stable URL: https://www.jstor.org/stable/1968255

Accessed: 25-10-2025 11:42 UTC

JSTOR is a not-for-profit service that helps scholars, researchers, and students discover, use, and build upon a wide range of content in a trusted digital archive. We use information technology and tools to increase productivity and facilitate new forms of scholarship. For more information about JSTOR, please contact support@jstor.org.

Your use of the JSTOR archive indicates your acceptance of the Terms & Conditions of Use, available at https://about.jstor.org/terms

![](_page_0_Picture_8.jpeg)

Mathematics Department, Princeton University is collaborating with JSTOR to digitize, preserve and extend access to Annals of Mathematics

## ON THE ABSOLUTE CONVERGENCE OF DIRICHLET SERIES.<sup>1</sup>

By H. F. Bohnenblust and Einar Hille.

The problem of the absolute convergence for Dirichlet series  $\sum a_n e^{-\lambda_n s}$  deals with the relative position of the abscissa  $\sigma_a$  of absolute convergence and the abscissae  $\sigma_u$  of uniform convergence and  $\sigma_b$  of boundedness and regularity. For ordinary Dirichlet series  $\sum a_n n^{-s}$  we have  $\sigma_u = \sigma_b$ .

In order to find an upper bound for the difference  $\sigma_a - \sigma_u$ , H. Bohr established in a paper published in  $1913^2$  a connection between the behavior of ordinary Dirichlet series and of power series in an infinite number of variables. Writing n as a product of prime numbers, the Dirichlet series

$$(1) \sum_{n=1}^{\infty} a_n n^{-s}$$

can be written as a power series

(2) 
$$c + \sum_{i_1=1}^{\infty} c_{i_1} x_{i_1} + \sum_{i_1 \le i_2=1}^{\infty} c_{i_1 i_2} x_{i_1} x_{i_2} + \cdots$$

in the variables  $x_n = p_n^{-s}$ , where  $p_n$  is the *n*-th prime number. The coefficient  $c_{i_1 i_2 \cdots i_m}$  of (2) is equal to the coefficient  $a_n$  of (1), whose index n is equal to  $p_{i_1} p_{i_2} \cdots p_{i_m}$ . Bohr showed that, though actually functions of a single variable s, the variables  $x_n = p_n^{-s}$  behave in many ways as if they were independent of one another. This is due to the linear independence of the quantities  $\log p_n$ .

The power series (2) will be said to be bounded in the domain  $(G): |x_n| \leq G_n$ ; where the  $G_n$  are non negative numbers, if 1° for every integer m, the m-truncated power series

(3) 
$$c + \sum_{i_1=1}^{m} c_{i_1} x_{i_1} + \sum_{i_1 \le i_2=1}^{m} c_{i_1 i_2} x_{i_1} x_{i_2} + \cdots$$

obtained from (2) by putting  $x_{m+1} = x_{m+2} = \cdots = 0$  is absolutely convergent in the domain (G), and

<sup>&</sup>lt;sup>1</sup> Received March 10, 1931.—Presented to the American Mathematical Society, Dec. 31, 1930, (abstract nos. 37-1-91, 95). A short account of the main results of this paper appeared in the Comptes Rendus, t. 192, pp. 30-32, seance du 5 janvier 1931.

<sup>&</sup>lt;sup>2</sup> H. Bohr, Über die Bedeutung der Potenzreihen unendlich vieler Variablen in der Theorie der Dirichletschen Reihen  $\sum a_n n^{-\epsilon}$ , Gött. Nachr. (1913), p. 441-488.

2? if there exists an upper bound H, such that for every x, of (G) and every m, the truncated power series (3) is in absolute value ? H.8 By means of this definition, Bohr was able to establish:'

THEOREM A: Let ao be the abscissa of uniform convergence of the Dirichlet series (1), then the associated power series (2) is bounded in every domain Xt < Gn p;(6u+J) where d is any arbitrarily small positive number, and the converse

THEOREM B: If the powemr series (2) is bounded in the domain I Xn I \_ = P-paro, thenr or. < odo.

The problem of the absolute convergence of (1) is thus reduced to a problem on power series in an infinite number of variables.

.If S is the least upper bound of all positive numbers a, such that every power series (2) bounded in (G) is absolutely convergent in (G'): j x\$ I \_ G?n en Go/, whenever 0 < en.< 1 and z en converges, then

THEOREM C:5 The maximal width of the strip in which a Dirichlet series is uniformly, but non-absolutely convergent is = i1 S.

Bohr showed that S > 2, but could not prove the finiteness of S. In the same year, Toeplitz6 settled this question by showing that S < 4. There exist Dirichlet series for which the width oa a- of the strip of uniform but non-absolute convergence is arbitrarily close to l. His examples were constructed by means of quadratic forms in the xn; the coefficients of which are essentially the elements of orthogonal (not normalized) matrices, and have the values +41.

For general Dirichlet series I an e n we have to consider the abscissa ab of regularity and boundedness. Hardy, Carlson and Neder proved'

$$\sigma_a - \sigma_b \leq \frac{D}{2},$$

where
$$(4) D = \overline{\lim}_{n \to \infty} \frac{\log n}{\lambda_n}$$

while Neder showed that this result is the best possible:

<sup>3</sup> D. Hilbert, Wesen und Ziele einer Analysis der unendlich vielen unabhangigen Variablen, Palermo Rend., 27, (1909), p. 59-74.

H . Bohr, loc. cit. Theorems VII and VIHI, p. 472 and p. 475.

H. Bohr, loc. cit. Theorem IX, p. 477.

<sup>6</sup> O. Toeplitz, tber eine bei den Dirichletschen Reihen auftretende Aufgabe aus der Theorie der Potenzreihen von unendlich vielen Veranderlichen, Gottinger Nachrichten (1913), p. 417-432.

<sup>7 0.</sup> H. Hardy, The application of Abel's method of summation to Dirichlet series, Quarterly Journal, 47 (1916), p. 176-192.-F. Carlson, Sur les series de Dirichlet, Comptes Rendus, t. 172 (1921), p. 838.-L. Neder, Zum Konvergenzprobleiu der Dirichletsclhen Reihen beschrankter Funktionen, Mathematische Zeitschrift, 14 (1922), p. 149-158.

For every D ? 0, there exist types satisfying (4) for which cia,-b =:D In the case D = 1 however, the type considered by Neder is not the type A,, logn of ordinary Dirichlet series.

In a different connection Littlewood8 has considered bounded bilinear forms in an infinite number of variables. He obtained necessary conditions for boundedness and showed that they are the best of their kind.

In this paper we generalize in the two first sections the conditions of Littlewood to cover m-linear forms in an infinite number of variables and in the third section to cover symmetrical linear forms and rnic forms. Then we apply the result to power series in an infinite number of variables (section 4) and to Dirichlet series (section 5). We shall prove that if ci is the abscissa of uniform convergence of the Dirichlet series (1), the series 2b.n-n, where

$$b_n = \begin{cases} a_n & \text{when } n \text{ does not contain more than } m \text{ prime factors (the same or different),} \\ 0 & \text{otherwise,} \end{cases}$$

has an abscissa of absolute convergence < '1+ 2 ,and also that these inequalities are the best of their kind. Taking m 2, we see that Toeplitz obtained the largest width da -acu possible for Dirichlet series associated with quadratic forms.

Then combining forms of different degrees, we shall prove in section 6 the main result

THEOREM VII. For any given a in the interval 0 ? a ? 1i, there exist ordinary Dirichlet series for which the width of the strip of uniform, but non-absolute convergence is exactly equal to a.

This theorem cannot be generalized to all types of Dirichlet series. However Bohr' has extended his results to cover certain types of Dirichiet series. Accordingly we are able to extend (section 7) our results for certain types and we obtain at the same time new examples proving Neder's result.

Throughout this paper we shall write the power series associated with (1) not in the form (2), where the summations are subject to the conditions il < i2< ... < im, but in the symmetrical form 00 00

$$c + \sum_{i_1=1}^{\infty} c_{i_1} x_{i_1} + \sum_{i_1 i_2=1}^{\infty} c_{i_1 i_2} x_{i_1} x_{i_2} + \cdots,$$

whose coefficients are the old ones divided by binomial factors.

<sup>8</sup> J. E. Littlewood, On bounded bilinear forms, Quarterly Journal of Mathematics (Oxford series), 1 (1930), p. 164-174.

<sup>9</sup> H. Bohr, Zur Theorie der allgemeinen Dirichletschen Reihen, Mathematische Annalen, 79 (1919), p. 136-156.

1. Bounded m-linear forms in an infinite number of variables. Let us consider the m-linear form

$$(1.1) L(x^{(1)}, x^{(2)}, \dots, x^{(m)}) \equiv \sum a_{i_1 i_2 \cdots i_m} x_{i_1}^{(1)} x_{i_2}^{(2)} \cdots x_{i_m}^{(m)},$$

where the indices il, i2, - i" independently assume all positive integral values. The coefficients ail.. im and the variables xi,) are complex. The vector

$$x^{(\nu)} \equiv \{x_1^{(\nu)}, x_2^{(\nu)}, \cdots, x_n^{(\nu)}, \cdots\}$$

is said to belong to the domain (GO) if for all values of n

$$|x_n^{(\nu)}| \leq 1.$$

DEFINITION: An m-linear form L(x('), ... , x(m")) is said to be bounded by H in the domain (Go) if all the truncated forms

$$\sum_{i_1=1}^{N_1} \sum_{i_2=1}^{N_2} \cdots \sum_{i_m=1}^{N_m} a_{i_1 i_2 \cdots i_m} x_{i_1}^{(1)} x_{i_2}^{(2)} \cdots x_{i_m}^{(m)}$$

are absolutely ? H in (Go).1?

We can evidently suppose all the N, to be equal, say equal to N. In order to generalize the Littlewood inequalities we first introduce the following notations

$$arrho = rac{2\,m}{m+1},$$
  $S = \left[\sum_{i_1,\cdots,i_m=1}^{\infty}|a_{i_1\cdots i_m}|^2
ight]^{rac{1}{arrho}}, \qquad T_{i_p}^{(
u)} = \left[\sum|a_{i_1\cdots i_m}|^2
ight]^{rac{1}{2}},$ 

where the last sum is to be extended over il. \* ,-12 +v?1, .., im from 1 to x; and finally

$$T^{(\nu)} = \sum_{i_{\nu}=1}^{\infty} T_{i_{\nu}}^{(\nu)}.$$

These values S, T1VT,) T(v) may of course be equal to x.

The first step in establishing the necessary conditions for boundedness

is to prove the inequality
$$(1.2) S^{\varrho} \leq \sum_{\nu=1}^{m} T^{(\nu)\varrho},$$

which shows in particular that S is finite if all the TP") are finite. If one of the TO') is divergent, there is nothing to prove. We may therefore suppose all the T(') and hence all the Tlf) to be finite. We can also assume for the proof that all the coefficients al... im are real and non-

<sup>10</sup>This definition is equivalent to Hilbert's, since the truncated forms, containing only a finite number of terms, are absolutely convergent.

negative and that for every fixed v, T'V) is a non-increasing function of i,,. Should the last not be the case initially, the following permutation of the indices i, \*, i, will ensure it: Consider first the quantities Ti. A permutation of the i4 interchanges the T1), but does not alter T('), nor 8, nor any T774) with a v > 2. Since 711) O0 when il -x , we can rearrange the T11) in non-increasing order of magnitude. Proceeding similarly for I2,..\*, mn we obtain the desired order. Hence for all v -1, 2,. n

and all 
$$i_{\nu}=1,\,2,\,\cdots$$
  $(1.3)$   $i_{\nu}\,T_{i_{\nu}}^{(\nu)}\leqq T^{(\nu)}.$ 

Using the notation to indicate that v and iv are fixed and that the summation is to be extended

10 over those values of it, .. 4i, which do not exceed i4, and 20 over those values of i,,+j, i ink which are smaller than 4, we have by Holder's inequality with p = 2- =m+ I, q =2 i +m 2\_ ()2

$$\begin{split} \sum_{(i_{\nu})}^{(\nu)} a_{i_{1} \cdots i_{m}}^{\varrho} & \leq \left( \sum_{(i_{\nu})}^{(\nu)} 1 \right)^{\frac{1}{m+1}} \cdot \left( \sum_{(i_{\nu})}^{(\nu)} a_{i_{1} \cdots i_{m}}^{2} \right)^{\frac{\varrho}{2}} \\ & \leq i_{\nu}^{\frac{m-1}{m+1}} \cdot \left( \sum_{(i_{\nu})}^{(\nu)} a_{i_{1} \cdots i_{m}}^{2} \right)^{\frac{\varrho}{2}}. \end{split}$$

Extending the summation in the last sum over the range ii, \* \*, iv iv+1' i - 1, 2..B increases the right hand side; hence

$$\sum\nolimits_{(i_{\nu})}^{(\nu)}a_{i,\cdots i_{m}}^{\varrho}\leqq i_{\nu}^{\frac{m-1}{m+1}}\cdot T_{i_{\nu}}^{(\nu)\frac{\varrho}{2}}$$

or

$$\sum_{(i_{m{
u}})}^{(m{
u})} a_{i_{1} \cdots i_{m}}^{m{
u}} \leq \left(i_{m{
u}} T_{i_{m{
u}}}^{(m{
u})}\right)^{rac{m-1}{m+1}} T_{i_{m{
u}}}^{(m{
u})}$$

Applying (1.3) we obtain

(1.4) 
$$\sum_{(i_{\nu})}^{(\nu)} a_{i_{1} \cdots i_{m}}^{\varrho} \leq \left(T^{(\nu)}\right)^{\frac{m-1}{m+1}} \cdot T_{i_{\nu}}^{(\nu)}.$$

On the other hand, as there is always a last largest number in a finite sequence of positive integers, every term in the infinite sum se appears in one and only one H(')); hence

and by (1.4) 
$$S^{\varrho} = \sum_{\nu=1}^{m} \left( \sum_{i_{\nu}=1}^{\infty} \left( \sum_{(i_{\nu})}^{(\nu)} a_{i_{1} \cdots i_{m}}^{\varrho} \right) \right)$$
$$S^{\varrho} \leq \sum_{\nu=1}^{m} \left( \sum_{i_{\nu}=1}^{\infty} T^{(\nu) \frac{m-1}{m+1}} T^{(\nu)}_{(i_{\nu})} \right) = \sum_{\nu=1}^{m} T^{(\nu) \varrho}$$

which is the inequality (1.2).

We now proceed to the second step. Supposing that H is an upper bound of the form (1.1), we are going to compare the series TP") with II and prove the existence of a constant A (determined byi m), such that

$$(1.5) T^{(\nu)} \leq A \cdot H,$$

for all forms (1.1). The proof of these inequalities is based upon the following lemma: "

Let 2 >0 and let Mi (f) denote the 1-th root of the mean value of the numbers If jX with respect to a set of discrete or continuous. variables.

LEMMA 1: Suppose that 15I2 (f) \_ T, 14 (f) \_ A' T. (The A's are absolute constants, while T may depend on the function f). Then will

$$A'' \cdot T \leq M_1(f) \leq A''' \cdot T.$$

We shall apply this lemma, taking for f the function

$$f \equiv \sum_{i_1, \dots, i_m = 1}^n a_{i_1 \dots i_m} x_{i_1 \dots}^{(1)} x_{i_m}^{(m)}$$

with complex coefficients as1 i, of m points Px(V), x2(1 \* \* \*, x.v)). The mean value is the mean value of f, when each point Pv runs independently through the vertices (? 1, ? 1, \* , ?1) of the unit cube in the n-dimensional euclidean space.

We first evaluate M(f). Evidently

$$\begin{split} M_2^2(f) \; &= \; \frac{1}{2^{n \cdot m}} \sum_{P} \left( \sum_{i=1}^n a_{i_1 \cdots i_m} x_{i_1}^{(1)} \cdots x_{i_m}^{(m)} \right) \left( \sum_{j=1}^n \overline{a}_{j_1 \cdots j_m} x_{j_1}^{(1)} \cdots x_{j_m}^{(m)} \right) \\ &= \; \frac{1}{2^{n \cdot m}} \sum_{i,j} \; \left( a_{i_1 \cdots i_m} \overline{a}_{j_1 \cdots j_m} \sum_{P} x_{i_1}^{(1)} \cdots x_{j_m}^{(m)} \right). \end{split}$$

But since

$$\sum_{P_{\nu}} x_{i_{\nu}}^{(\nu)} x_{j_{\nu}}^{(\nu)} = 2^{n} \cdot \delta_{i_{\nu}, j_{\nu}},$$

it follows that

$$\sum_{P} x_{i_1}^{(1)} \cdots x_{j_m}^{(m)} = 2^{n \cdot m} \, \delta_{i_1 j_1} \cdots \delta_{i_m j_m},$$

and we obtain 
$$M_2^2(f) = \sum_{i_1, \ldots, i_m=1}^n |\, a_{i_1 \cdots i_m}^2|,$$

1. e.

(1.6) 
$$M_2(f) = \left\{ \sum_{i_1, \dots, i_m = 1}^n |a_{i_1 \dots i_m}| \right\}^{\frac{1}{2}}.$$

<sup>1</sup> J. E. Littlewood, loc. cit. p. 169-170.

We next evaluate  $M_4(f)$ . We have

$$\begin{split} M_4^4(f) &= \frac{1}{2^{n \cdot m}} \sum_{P, \, i, j, \, k, \, l} \, a_{i_1 \cdots i_m} \, a_{j_1 \cdots j_m} \, \overline{a}_{k_1 \cdots k_m} \, \overline{a}_{l_1 \cdots l_m} \, x_{i_1}^{(1)} \cdots \, x_{l_m}^{(m)} \\ &= \frac{1}{2^{n \cdot m}} \sum_{i, j, \, k, \, l_i} \left\{ a_{i_1 \cdots i_m} \cdots \, \overline{a}_{l_1 \cdots l_m} \, \sum_{P_1} x_{i_1}^{(1)} \cdots \, x_{l_1}^{(1)} \cdots \, \sum_{P_m} x_{i_m}^{(m)} \cdots \, x_{l_m}^{(m)} \right\}. \end{split}$$

But the sum  $\sum_{P_{\nu}} x_{l_{\nu}}^{(\nu)} \cdots x_{l_{\nu}}^{(\nu)}$  is equal to  $2^{n}$  when either

(1.7) 
$$\alpha \quad i_{\nu} = j_{\nu} \text{ and } k_{\nu} = l_{\nu},$$
or  $\beta$   $i_{\nu} = k_{\nu} \text{ and } j_{\nu} = l_{\nu},$ 
or  $\gamma$   $i_{\nu} = l_{\nu} \text{ and } j_{\nu} = k_{\nu},$ 

and equal to zero otherwise. Hence

$$M_4^4(f) = \sum a_{i_1 \cdots i_m} \cdots \overline{a}_{i_1 \cdots i_m} \leq \sum |a_{i_1 \cdots i_m}| \cdots |a_{i_1 \cdots i_m}|,$$

where these sums are to be extended over all possible combinations (1.7) for all  $\nu$ 's. The combinations (1.7) are not mutually exclusive; but counting each of the overlapping terms separately on each occurrence, we increase the right hand side and obtain

$$(1.8) M_4^4(f) \leq \sum_{\alpha, \dots, \alpha, \alpha} + \sum_{\alpha, \dots, \alpha, \beta} + \dots + \sum_{\gamma, \dots, \gamma, \gamma}$$

These sums are to be understood as follows: for the indices  $i_{\nu}$ ,  $j_{\nu}$ ,  $k_{\nu}$ ,  $l_{\nu}$  we take the combination  $\alpha$ ,  $\beta$ , or  $\gamma$  in (1.7) according to the letter in the  $\nu$ -th place under the sign  $\Sigma$ . Then we sum over all  $n^{2m}$  terms thus obtained. The right hand side of (1.8) contains exactly  $3^m$  sums. Each of them is of the form

$$(1.9) \qquad \sum_{\alpha,\dots,\alpha,\beta,\dots,\beta,\gamma,\dots,\gamma} |a_{i_1\dots i_m}| |a_{j_1\dots j_m}| |a_{k_1\dots k_m}| |a_{l_1\dots l_m}|,$$

where the combination  $\alpha$  occurs  $\omega_1$ , the combination  $\beta$   $\omega_2$  and the combination  $\gamma$   $\omega_3$  times and  $\omega_1 + \omega_2 + \omega_3 = m$ . Let the indices  $i_{\alpha} (=1, 2, \cdots, n^{\omega_1}), i_{\beta} (=1, 2, \cdots, n^{\omega_2})$  and  $i_{\gamma} (=1, 2, \cdots, n^{\omega_3})$  replace respectively the indices  $i_1, i_2, \cdots, i_{\omega_1}; i_{\omega_1+1}, \cdots, i_{\omega_1+\omega_2}; i_{\omega_1+\omega_2+1}, \cdots, i_m$ , then the sum (1.9) can be written in the form

$$= \sum_{\substack{i_{\alpha}, i_{\beta}, i_{\gamma} \\ j_{\alpha}, j_{\beta}, j_{\gamma}}} |a_{i_{\alpha}i_{\beta}i_{\gamma}}| |a_{i_{\alpha}j_{\beta}j_{\gamma}}| |a_{j_{\alpha}i_{\beta}j_{\gamma}}| |a_{j_{\alpha}j_{\beta}i_{\gamma}}|$$

$$= \sum_{\substack{i_{\alpha}i_{\beta}j_{\alpha}j_{\beta}}} \left( \sum_{i_{\gamma}} |a_{i_{\alpha}i_{\beta}i_{\gamma}}| |a_{j_{\alpha}j_{\beta}i_{\gamma}}| \right) \left( \sum_{i_{\gamma}} |a_{j_{\alpha}i_{\beta}i_{\gamma}}| |a_{j_{\alpha}j_{\beta}i_{\gamma}}| \right)$$

and using Cauchy's inequality

$$\begin{split} & \leq \sum_{i_{\alpha}i_{\beta}j_{\alpha}j_{\beta}} \left\{ \sum_{i_{\gamma}} \mid a_{i_{\alpha}i_{\beta}i_{\gamma}}^{2} \mid \right\}^{\frac{1}{2}} \left\{ \sum_{i_{\gamma}} \mid a_{j_{\alpha}j_{\beta}i_{\gamma}}^{2} \mid \right\}^{\frac{1}{2}} \left\{ \sum_{i_{\gamma}} \mid a_{j_{\alpha}i_{\beta}i_{\gamma}}^{2} \mid \right\}^{\frac{1}{2}} \left\{ \sum_{i_{\gamma}} \mid a_{i_{\alpha}j_{\beta}i_{\gamma}}^{2} \mid \right\}^{\frac{1}{2}} \\ & = \sum_{i_{\alpha}j_{\alpha}} \left\{ \sum_{i_{\beta}} \left\{ \sum_{i_{\gamma}} \mid a_{i_{\alpha}i_{\beta}i_{\gamma}}^{2} \mid \right\}^{\frac{1}{2}} \left\{ \sum_{i_{\gamma}} \mid a_{j_{\alpha}i_{\beta}i_{\gamma}}^{2} \mid \right\}^{\frac{1}{2}} \right\}^{2}. \end{split}$$

Applying Cauchy's inequality a second time, we see that (1.4) is

$$\leq \sum_{i_{\alpha}j_{\alpha}} \left( \sum_{i_{\beta}i_{\gamma}} |a_{i_{\alpha}i_{\beta}i_{\gamma}}^{2}| \right) \left( \sum_{i_{\beta}i_{\gamma}} |a_{j_{\alpha}i_{\beta}i_{\gamma}}^{2}| \right)$$

$$= \left\{ \sum_{i_{\alpha}i_{\beta}i_{\gamma}} |a_{i_{\alpha}i_{\beta}i_{\gamma}}^{2}| \right\}^{2} = \left\{ \sum_{i_{1}\cdots i_{m}} |a_{i_{1}\cdots i_{m}}^{2}| \right\}^{2}.$$

Since this result is independent of the choice of the combinations, the same evaluation applies for every term of (1.8). Hence

$$M_4^4(f) \leq 3^m \left( \sum_{i_1 \cdots i_m} |a_{i_1 \cdots i_m}^2| \right)^2,$$

or

(1.10) 
$$M_{4}(f) \leq 3^{\frac{m}{4}} \left( \sum_{i_{1} \cdots i_{m}} |a_{i_{1} \cdots i_{m}}^{2}| \right)^{\frac{1}{2}}.$$

The integer m being fixed,  $3^{\frac{m}{4}}$  is an absolute constant, and the hypotheses of Littlewood's lemma are satisfied with

$$T = \left\{ \sum_{\mathbf{i}_1 \cdots \mathbf{i}_{\mathbf{m}}} \mid a_{\mathbf{i}_1 \cdots \mathbf{i}_{\mathbf{m}}}^2 \mid \right\}^{\frac{1}{2}}.$$

There exist therefore two constants  $A^{\prime\prime}$  and  $A^{\prime\prime\prime}$  (depending only on m) such that

$$(1.11) A'' \cdot (\sum |a|^2)^{\frac{1}{2}} \leq M_1(f) \leq A''' (\sum |a|^2)^{\frac{1}{2}}.$$

We can now prove (1.5) without difficulty. The maximum of every truncated form

$$\sum_{i_1,\dots,i_m=1}^n a_{i_1\dots i_m} x_{i_1}^{(1)} \cdots x_{i_m}^{(m)}$$

of a form (1.1) in the domain  $(G_0)$  is equal to the maximum of

$$\sum_{i_1=1}^n \left| \sum_{i_2 \cdots i_m=1}^n a_{i_1 \cdots i_m} x_{i_2}^{(2)} \cdots x_{i_m}^{(m)} \right|$$

in the same domain. This maximum is larger or at least not less than any mean value taken with respect to vectors of the domain  $(G_0)$ . We

can apply (1.11) to every term, <sup>12</sup> and if H is an upper bound of (1.1) we obtain

$$H \geq A^* \sum_{i_1=1}^n \left\{ \sum_{i_2\cdots i_m=1}^n |a_{i_1\cdots i_m}^2| 
ight\}^{rac{1}{2}}$$

for every n, and therefore

$$H \geq A^* \sum_{i_1=1}^{\infty} \left\{ \sum_{i_2 \cdots i_m=1}^{\infty} |a_{i_1 \cdots i_m}^2| 
ight\}^{rac{1}{2}} = A^* \cdot T^{(1)},$$

and similarly for all other  $T^{(\nu)}$ :

$$(1.5) T^{(\nu)} \leq A \cdot H$$

and using (1.2)

$$(1.12) S \leq A_1 \cdot H.$$

This proves

THEOREM I. In order that an m-linear form (1.1) be bounded by H in the domain  $(G_0)$ , it is necessary that  $T^{(1)}$ ,  $T^{(2)}$ ,  $\cdots$ ,  $T^{(m)}$  and S should all be less than  $A \cdot H$ , where A is a constant depending only on m.

2. Theorem I in the first section is the best result of its kind. As in the case m=2, the proof is based upon the construction for every n of m-linear forms

(2.1) 
$$\sum_{i_1,\dots,i_m=1}^n a_{i_1\cdots i_m} x_{i_1}^{(1)} \dots x_{i_m}^{(m)},$$

for which

$$(2.2) \qquad \left\{ \sum_{i_1,\dots,i_m=1}^n |a_{i_1\dots i_m}|^{\frac{2m}{m+1}} \right\}^{\frac{m+1}{2m}} \geq A_m \cdot H_n.$$

The value  $A_m$  is determined by m, independently of n; and  $H_n$  is the maximum of the absolute value of the form (2.1) in the domain  $(G_0)$ . We can express these results by means of the series S,  $T^{(\nu)}$ :

THEOREM II. Given any positive  $t_{i_v}^{(v)}$  and  $s_{i_1 \cdots i_m}$ , for which

$$\lim_{i_{\nu}\to\infty}t_{i_{\nu}}^{(\nu)}=\lim_{i_{1},\cdots,i_{m}\to\infty}s_{i_{1}\cdots i_{m}}=\infty,$$

there exist bounded forms for which

$$\sum t_{i_{v}}^{(v)} T_{i_{v}}^{(v)} \quad and \quad \sum s_{i_{1} \cdots i_{m}} \mid a_{i_{1} \cdots i_{m}} \mid^{\frac{2m}{m+1}}$$

are divergent.

We turn first to the construction of the special forms (2.1). Let  $\|a_{rs}\|$  be an *n*-rowed square matrix satisfying the conditions

<sup>&</sup>lt;sup>12</sup> We use (1.11) for (m-1) instead of m.

(2.3) 
$$\begin{cases} \sum_{t=1}^{n} a_{rt} \overline{a}_{st} = n \cdot \delta_{rs} \\ |a_{rs}| = 1. \end{cases}$$

Examples of such matrices have been given by Toeplitz<sup>13</sup> and Littlewood.<sup>14</sup> The simplest is

$$a_{rs} = e^{2\pi i \frac{r \cdot s}{n}} \qquad (r, s = 1, 2, \dots, n).$$

From any two matrices satisfying (2.3)  $||a_{rs}||$ ,  $||b_{pq}||$  (with possibly not the same number of rows) we can construct a third by "substituting" the second into the first one:

$$\left\|\begin{array}{cccccccccccccccccccccccccccccccccccc$$

the resulting array we regard as a new matrix, whose number of rows will be equal to the product of the number of rows of  $||a_{rs}||$  and  $||b_{pq}||$ . Let  $||a_{rs}||$  be any *n*-rowed matrix satisfying (2.3) and consider the form

(2.4) 
$$\sum_{i_1,\dots,i_m=1}^n a_{i_1 i_2} \cdot a_{i_2 i_3} \cdot \dots \cdot a_{i_{m-1} i_m} x_{i_1}^{(1)} \cdot \dots \cdot x_{i_m}^{(m)}.$$

The coefficients of this form are all equal to one in absolute value, hence

$$T^{(\nu)} = S = n^{\frac{m+1}{2}}$$

We now proceed to evaluate the maximum H of this form in the domain  $(G_0)$ . For any vectors  $x^{(\nu)}$  in  $(G_0)$  we have

$$\begin{split} & \left| \sum_{i_1, \dots, i_m = 1}^n a_{i_1 i_2} \cdots a_{i_{m-1} i_m} x_{i_1}^{(1)} \cdots x_{i_m}^{(m)} \right| \\ & \leq \sum_{i_m = 1}^n \left| \sum_{i_1, \dots, i_{m-1} = 1}^n a_{i_1 i_2} \cdots a_{i_{m-1} i_m} x_{i_1}^{(1)} \cdots x_{i_{m-1}}^{(m-1)} \right|, \end{split}$$

which by Cauchy's inequality is

$$\leq n^{\frac{1}{2}} \left\{ \sum_{\substack{i_{m}=1 \ j_{1}, \dots, j_{m-1} \\ j_{1}, \dots, j_{m-1} \\ j_{1}, \dots, j_{m-1} \\ \}}^{n} = 1^{a_{i_{1}i_{2}}} \overline{a_{j_{1}j_{2}} \cdots a_{i_{m-1}i_{m}}} \overline{a_{j_{m-1}i_{m}}} x_{i_{1}}^{(1)} \cdots \overline{x_{j_{m-1}}^{(m-1)}} \right\}^{\frac{1}{2}}$$

$$= n^{\frac{1}{2}} \left\{ \sum_{\substack{i_{1}, \dots, i_{m-1} \\ j_{1}, \dots, j_{m-1} \\ \}}^{n} = 1^{a_{i_{1}i_{2}} \cdots \overline{a_{j_{m-2}j_{m-1}}}} x_{i_{1}}^{(1)} \cdots \overline{x_{j_{m-1}}^{(m-1)}} \sum_{\substack{i_{m}=1 \\ i_{m}=1}}^{n} a_{i_{m-1}i_{m}} \overline{a_{j_{m-1}i_{m}}} \right\}^{\frac{1}{2}}$$

<sup>&</sup>lt;sup>13</sup> O. Toeplitz, loc. cit. p. 422-424.

<sup>&</sup>lt;sup>14</sup> J. E. Littlewood, loc. cit. p. 172,

$$= n \left\{ \sum_{\substack{i_1, \dots, i_{m-2} \\ j_1, \dots, j_{m-2}}} \sum_{\substack{i_{m-1} \\ i_{m-1}}} a_{i_1 i_2} \dots \overline{a}_{j_{m-2} i_{m-1}} x_{i_1}^{(1)} \dots \overline{x}_{i_{m-1}}^{(m-1)} \right\}^{\frac{1}{2}}$$

$$\leq n \left\{ \sum_{\substack{i_1, \dots, i_{m-2} \\ j_1, \dots, j_{m-2} \\ j_{m-1} = 2}} \sum_{\substack{i_{m-1} \\ j_{m-1} = 2}} a_{i_1 i_2} \dots \overline{a}_{j_{m-2} i_{m-1}} x_{i_1}^{(1)} \dots \overline{x}_{j_{m-2}}^{(m-2)} \right\}^{\frac{1}{2}},$$

since the coefficients of  $|x_{i_{m-1}}^{(m-1)}|^2$  are  $\geq 0$ . Repeating this evaluation for the summation over the other indices, we obtain by induction

$$H \leqq n^{rac{m+1}{2}}$$

and therefore

$$S=T^{(\nu)}\geq H,$$

that is (2.2). The proof of Theorem II proceeds now on exactly the same lines as Littlewood's proof for the case m = 2.

3. Symmetric m-linear forms and m-ic forms. In the application to Dirichlet series, we shall deal with forms

$$Q(x) \equiv \sum a_{i_1 \cdots i_m} x_{i_1} \cdots x_{i_m}$$

of the m-th degree instead of m-linear forms, where the coefficients  $a_{i_1\cdots i_m}$  are supposed to be symmetrical. To every such form we associate the m-linear form

$$L(x^{(1)}, x^{(2)}, \dots, x^{(m)}) \equiv \sum a_{i_1 \dots i_m} x_{i_1}^{(1)} \dots x_{i_m}^{(m)}$$

and conversely, to every symmetrical linear form there corresponds an m-ic form, obtained by putting all  $x^{(\nu)} = x$ . Denoting by H, resp.  $\mathfrak{F}$ , the maxima of Q(x), resp.  $L(x^{(1)}, \dots, x^{(m)})$  for the domain  $(G_0)$ , we obviously have  $H \leq \mathfrak{F}$ . On the other hand the identity

(3.1) 
$$= \frac{L(x^{(1)}, \dots, x^{(m)})}{\frac{1}{2^{m-1} \cdot m!} \sum_{\varepsilon} (-1)^{\varepsilon_2 + \varepsilon_3 + \dots + \varepsilon_m} Q(x^{(1)} + (-1)^{\varepsilon_2} x^{(2)} + \dots + (-1)^{\varepsilon_m} x^{(m)}), }$$

where the sum is to be extended over  $\epsilon_{\nu}=0,1;\ \nu=2,3,\cdots,m,$  shows that

$$\mathfrak{F} \leqq \frac{m^m}{m!} H.$$

Hence:

A symmetrical m-linear form is bounded in the domain  $(G_0)$  if and only if the corresponding m-ic form is bounded in  $(G_0)$ .

The identity (3.1) can be proved as follows. We have

$$\sum_{\varepsilon} (-1)^{\varepsilon_{2}+\cdots+\varepsilon_{m}} Q(x^{(1)}+(-1)^{\varepsilon_{2}} x^{(2)}+\cdots+(-1)^{\varepsilon_{m}} x^{(m)})$$

$$=\sum_{\varepsilon,i,\nu} (-1)^{\varepsilon_{2}+\cdots+\varepsilon_{m}+\varepsilon_{\nu_{1}}+\cdots+\varepsilon_{\nu_{m}}} \cdot a_{i_{1}\cdots i_{m}} x_{i_{1}}^{(\nu_{1})}\cdots x_{i_{m}}^{(\nu_{m})}$$

$$=\sum_{i,\nu} a_{i_{1}\cdots i_{m}} x_{i_{1}}^{(\nu_{1})}\cdots x_{i_{m}}^{(\nu_{m})} \sum_{\varepsilon} (-1)^{\varepsilon_{2}+\cdots+\varepsilon_{m}+\varepsilon_{\nu_{1}}+\cdots+\varepsilon_{\nu_{m}}}.$$
<sup>15</sup>

Let  $\alpha_r$  be the number of  $\nu$ 's equal to r  $(r=1, 2, \dots, m)$  for a fixed set of values  $\nu$ . We have  $\alpha_1 + \alpha_2 + \dots + \alpha_m = m$ , where the  $\alpha$ 's are nonnegative integers. Then

(3.2) 
$$\sum_{\epsilon} (-1)^{\epsilon_2 + \dots + \epsilon_{\nu_m}} = \prod_{r=2}^m (1 + (-1)^{\alpha_r + 1})$$
$$= \begin{cases} 2^{m-1} & \text{when all } \alpha_r + 1 \text{ are even,} \\ 0 & \text{otherwise.} \end{cases}$$

In the first case, since  $\alpha_r \geq 0$ , all  $\alpha_r (r = 2, 3, \dots, m)$  are positive odd integers and therefore

$$\alpha_1 + (m-1) + 2x = m_1$$

where x is an integer larger than the number of  $\alpha_r \ge 3$ . Hence x = 0,  $\alpha_1 = \alpha_r = 1$  and the sum (3.2) is zero except, when the  $\nu_1, \nu_2, \dots, \nu_m$  are a permutation of  $1, 2, \dots, m$ , and the proof of (3.1) is completed.

Theorem I therefore holds for m-ic forms; but as the examples we have constructed for Theorem II are not symmetrical, we must refine them in order to show that Theorem I is also the best result of its kind for the symmetrical case. We can still vary the matrix  $||a_{rs}||$ , subject only to conditions (2.3). Let p be a prime number > m. Starting from the matrix

$$M_1 \equiv \left\| e^{2\pi i \frac{r \cdot s}{p}} \right\|, \qquad (r, s = 1, 2, \dots, p),$$

with p rows, we form successively for  $\mu=2,3,\cdots$  the matrices  $M_{\mu}$ , which are obtained by "substituting" the matrix  $M_{\mu-1}$  into  $M_1$ :

$$M_{\mu} = \left\| e^{2\pi i rac{r \cdot s}{p}} M_{\mu-1} \right\|.$$

The matrix  $M_{\mu}$  contains  $p^{2\mu}$  elements, each being a root of the equation  $z^p-1=0$ .

We put

$$||a_{rs}|| = M_{\mu}$$
  $(r, s = 1, 2, \dots, p^{\mu})$ 

and form for this matrix, the form (2.5)

$$\sum_{i_1,\dots,i_m=1}^{p^{\mu}} a_{i_1 i_2} a_{i_2 i_3} \dots a_{i_{m-1} i_m} x_{i_1} \dots x_{i_m}.$$

<sup>&</sup>lt;sup>15</sup> Whenever  $\epsilon_1$  appears, it is put equal to 0, as the coefficient of  $x^{(1)}$  is always +1.

The coefficients of this form are all roots of  $z^p-1=0$ . It is not symmetrical, but by adding all the forms obtained by permuting the indices  $i_1, i_2, \dots, i_m$  we obtain a symmetrical one. Every coefficient of it is equal to

$$\sum_{k=0}^{p-1} \lambda_k \cdot \zeta_k,$$

where the  $\zeta_k$  are the roots of  $z^p = 1$ , and where the  $\lambda_k$  are non negative integers, whose sum  $\sum \lambda_k = m!$ . Since p is a prime number, there are no relations of the form<sup>16</sup>

$$\sum_{k=0}^{p-1} \lambda_k \, \zeta_k = 0,$$

except possibly those in which all  $\lambda$ 's are equal, say  $=\lambda$ . In such a case  $\lambda$  satisfies the equation

 $p \cdot \lambda = m!$ 

which is impossible, since p is a prime number larger than m. Thus No coefficient of our symmetrical form is zero.

Every  $\lambda_k$  being  $\leq m!$ , there exists only a finite number of values  $\sum \lambda_k \zeta_k$ , thus

There are only a finite number of coefficients different from each other. There exists therefore an  $\eta > 0$ , such that all coefficients of the form are  $\geq \eta$  in absolute value. Then

$$S \geqq \eta \cdot n^{rac{m+1}{2}}$$
 and therefore  $S \ge A_m \, H_n, \qquad (n = p^\mu).$ 

It is readily verified, that for the proof of Theorem II it suffices to have forms satisfying (3.3) for all  $n = p^{\mu}$ .

Theorem II remains true for symmetrical and for m-ic forms.

The coefficients of the form (3.1) possess a certain symmetry, since the permutation

$$\begin{pmatrix} i_1 & i_2 & \cdots & i_n \\ i_n & i_{n-1} & \cdots & i_1 \end{pmatrix}$$

leaves the coefficients  $a_{i_1 \cdots i_m}$  invariant. In order to obtain a symmetrical form it suffices therefore to consider m!/2 permutations instead of m!. For m=3, this enables us to take p=2 and to construct "best possible" examples with real coefficients, these all have one of the values  $\pm 1$ ,  $\pm 3$ .

<sup>&</sup>lt;sup>16</sup> Such a relation with different  $\lambda$ 's, would imply the existence of a polynomial P(z) of degree m-1 with rational coefficients, essentially different from the irreducible polynomial  $z^{p-1} + z^{p-2} + \cdots + 1$  and having roots in common with it.

4. Application to power series in an infinite number of variables. In this section we take the first steps toward the application of the preceding results to ordinary Dirichlet series. Bohr proved the following

theorem. 17

Let 
$$G_n$$
 be a sequence of positive numbers and 
$$P(x_1, x_2, \dots, x_n, \dots) \equiv c + \sum_{i=1}^{\infty} c_i x_i + \sum_{i_1, i_2=1}^{\infty} c_{i_1 i_2} x_{i_1} x_{i_2} + \dots$$

a power series in an infinite number of variables, bounded in the domain In I < G3n. Let further en be a sequence of positive number such that 1 0 <en<1 and 2? .2 is convergent; then the power series P is absolutely convergent in the domain Xn \_ en Gn.

We now prove the following results, which complete Bohr's theorem. THEOREM III. If the power series P is bounded in jX.|\_ Gn: then its m-th polynomial Pm

$$P_m \equiv c + \sum_{i=1}^{\infty} c_i x_i + \cdots + \sum_{i_1, \dots, i_m = 1}^{\infty} c_{i_1 \dots i_m} x_{i_1} \dots x_{i_m}$$

is absolutely convergent in j Xn I e-n GOn, when z-,a converges, cr. 2 m

This exponent am is the best possible one:

THEOREM IV. There exist polynomials of the m-th degree in an infinite number of variables bounded in IxnI? 1, such that for every J >0, the polynomial is non-absolutely convergent for Xn = en although? the series Eun+d converges.

Since a. - 2, when m -e w it follows immediately from this theorem that the exponent 2 of Bohr's theorem cannot be increased.

REMARK: Condition 10 of Bohr's theorem, namely 0< e. < 1, is not essential to the truth of Theorem Ill.

Proof of Theorem III. It is obviously sufficient to prove this theorem for the domain (G6). We show first the truth of

LEMMA 2. If the power series P(xl, \* \* \*) is bounded by H in (GO); then H is also an zipper bound for the form

$$(4.1) \qquad \sum_{i_1,\dots,i_m=1}^{\infty} c_{i_1\dots i_m} x_{i_1} \dots x_{i_m}.$$

The proof follows the same lines as Bohr's proof in the case m = 1. (Theorem V of Bohr). We have to show, that every truncated form

$$\sum_{i_1,\dots,i_m=1}^N c_{i_1\dots i_m} x_{i_1} \cdot \dots \cdot x_{i_m}$$

<sup>1</sup> H. Bohr, loc. cit. p. 462.

is in absolute value  $\leqq H$ . Let  $x_n^*$  be the set of the variables for which the truncated form takes on a value  $H^*$ , which is absolutely the largest. This set exists since the truncated domain  $(G_0):|x_n|\leqq 1$ ,  $n\leqq N$ ;  $x_n=0$ , n>N, is compact. Put  $x_n=t\cdot x_n^*$ , then the truncated power series is a power series in t, such that the coefficient of  $t^m$  equals this value  $H^*$ . By Cauchy's evaluation of the coefficients of a power series, we see that this value is absolutely  $\leqq H$ .

It suffices therefore to prove Theorem III for m-ic forms. Let  $\epsilon_n > 0$  be any sequence for which  $\sum \epsilon_n^{\sigma_m}$  converges. By Hölder's inequality with

$$p = \frac{2m}{m-1}, q = \frac{2m}{m+1}$$

$$\begin{split} \sum_{i_1,\cdots,i_m=1}^N \varepsilon_{i_1}\cdots\varepsilon_{i_m} \,|\, c_{i_1\cdots i_m}| \, & \leqq \left(\sum_1^N \left(\varepsilon_{i_1}\cdots\varepsilon_{i_m}\right)^{\frac{2m}{m-1}}\right)^{\frac{m-1}{2m}} \cdot \left(\sum_1^N |\, c_{i_1\cdots i_m}|^{\frac{2m}{m+1}}\right)^{\frac{m+1}{2m}} \\ & \leqq E^{\frac{m-1}{2}} \cdot A_m \cdot H, \end{split}$$

where E is the sum of the series  $\sum \epsilon_n^{\sigma_m}$ ,  $A_m$  a constant determined by m and H an upper bound of the form (4.1). Hence the sum

$$\sum_{1}^{\infty} |c_{i_{1}\cdots i_{m}}| \, \epsilon_{i_{1}} \cdots \, \epsilon_{i_{m}}$$

is convergent, which proves Theorem III.

In the case m=2, Theorem III shows that the examples given by Toeplitz were the best obtainable from quadratic forms.

Proof of Theorem IV. We use the examples constructed in section 3. The integers m and p being fixed, let  $Q_{\mu}(x)$  be the m-ic form corresponding to  $n = p^{\mu}$ . The variables which enter in the different  $Q_{\mu}(x)$  shall be independent of each other; in order to differentiate between them we use a superscript  $\mu$ :

$$Q_{\mu}(x^{(\mu)}) \equiv \sum_{i_1,\dots,i_m=1}^{p^{\mu}} c_{i_1\dots i_m} x_{i_1}^{(\mu)} \dots x_{i_m}^{(\mu)}.$$

Let

$$Q(x) \equiv \sum_{\mu=1}^{\infty} \frac{1}{\mu^2} p^{-\mu \cdot \frac{m+1}{2}} Q_{\mu}(x^{(\mu)}).$$

This form Q(x) is an m-ic form in the variables

$$\{x_n\} \equiv \{x_1^{(1)}, \cdots, x_n^{(1)}; x_1^{(2)}, \cdots, x_n^{(2)}; x_1^{(3)}, \cdots \}.$$

It is bounded in the domain  $(G_0)$ , because the maxima of the forms  $Q_{\mu}$  (truncated or not) are of order of magnitude  $p^{\mu \cdot \frac{m+1}{2}}$ , and the series  $\sum \frac{1}{\mu^2}$  is convergent.

To study the absolute convergence, we use the fact, that there exists an  $\eta > 0$ , such that all coefficients of the forms  $Q_{\mu}$  are in absolute value  $\geq \eta$ . The *m*-ic form Q(x) will therefore be non-absolutely convergent for a set of values  $x_{\mu}^{(\mu)}$  if

(4.3) 
$$\sum_{\mu=1}^{\infty} \frac{1}{\mu^2} p^{-\mu \cdot \frac{m+1}{2}} \left\{ \sum_{n=1}^{p^{\mu}} |x_n^{(\mu)}| \right\}^m$$

diverges.

Given an arbitrarily small number  $\delta > 0$ ,  $p^{\sigma}$  is larger than one and we can choose k < 1, so that

$$h = p^{d} \cdot k^{\frac{m-1}{2} \cdot (1-d)} > 1.$$

We then take all the variables  $x_n^{(\mu)}$  of the same form  $Q_{\mu}$  equal to each other,

$$x_n^{(\mu)} = (k \cdot p^{-1})^{\mu \cdot \frac{m-1}{2m}(1-\delta)}$$

The series  $\sum x_n^{\frac{2m}{m-1}} \frac{1}{1-\delta}$  is thus equal to

$$\sum_{\mu=1}^{\infty} \sum_{n=1}^{p^{\mu}} (x_n^{(\mu)})^{\frac{2m}{m-1} \cdot \frac{1}{1-\sigma}} = \sum_{\mu=1}^{\infty} k^{\mu},$$

which converges since k < 1.

But for these special values  $x_n^{(\mu)}$  the expression (4.3) diverges. It is equal to

$$\sum_{\mu=1}^{\infty} \frac{1}{\mu^2} \left( p^{\sigma} k^{\frac{m-1}{2}(1-\sigma)} \right)^{\mu} = \sum_{\mu=1}^{\infty} \frac{1}{\mu^2} h^{\mu}$$

and the last series is divergent, since h>1. When  $\delta \to 0$ 

$$\frac{2m}{m-1}\cdot\frac{1}{1-\delta}\to\frac{2m}{m-1};$$

we have therefore constructed a form in the variables  $x_n$ , bounded in  $(G_0)$ , which for any given  $\delta' > 0$ , is non-absolutely convergent for a certain set of values  $x_n$  with convergent  $\sum x_n^{\sigma_m + \delta'}$ ; completing thus the proof of Theorem IV.

5. Applications to ordinary Dirichlet series. We now apply the results of the preceding section to ordinary Dirichlet series, with the help of Bohr's Theorems A, B, and C, mentioned in the introduction. We proved S=2, hence by Theorem C:

There exist ordinary Dirichlet series for which the widths of their strips of uniform, non-absolute convergence are arbitrarily close to  $\frac{1}{2}$ .

Consider now Theorems III and IV; applying them to the theory of Dirichlet series we shall prove

Theorem V. Let  $\sigma_u$  be the abscissa of uniform convergence of the Dirichlet series

$$\sum_{n=1}^{\infty} a_n n^{-s}.$$

If we replace by zero those terms for which n, decomposed into a product of prime numbers, contains more than m factors, then the new series is absolutely convergent in the half plane

$$\sigma > \sigma_u + \frac{m-1}{2m}$$

and

Theorem VI. There exist ordinary Dirichlet series with  $a_n = 0$ , when n contains more than m prime factors, which converge uniformly, but non-absolutely in strips whose widths are exactly equal to  $\frac{m-1}{2m}$ :

$$\sigma_a-\sigma_u=\frac{m-1}{2m}.^{18}$$

When m = 1, we obtain a result proved by Bohr.<sup>19</sup>

The proof of these two theorems proceeds in the same way as Bohr's proof of Theorem C.

Let  $\sigma_u$  be the abscissa of uniform convergence of (5.1). Then by Theorem A of Bohr the power series corresponding to (5.1) is bounded in the domain  $|x_n| \leq p_n^{-\sigma_u - \delta}$ , for every  $\delta > 0$ . Hence by Theorem III, and since

$$\sum_{n=1}^{\infty} p_n^{-1-\delta \cdot \frac{2m}{m-1}}$$

is convergent, the *m*-th polynomial is absolutely convergent in the domain  $|x_n| \leq p_n^{-\sigma_u - \frac{m-1}{2m} - 2\delta}$  By Theorem B of Bohr, the Dirichlet series associated with this *m*-th polynomial is absolutely convergent in

$$\sigma > \sigma_u + \frac{m-1}{2m} + 2 \delta$$

which proves Theorem V.20

<sup>&</sup>lt;sup>18</sup> If the abscissa of uniform convergence is  $\leq 0$ , then as Hardy and Carlson (cf. introduction) have proved, the series  $\sum a_n^2$  is convergent. Theorem V states essentially that  $\sum a_n^{2m/(m+1)}$  converges, if the summation is extended only over those indices n, which contain no more than m prime factors. Theorem VI shows that this exponent 2m/(m+1) is the best possible.

<sup>19</sup> H. Bohr, loc. cit. p. 468.

<sup>&</sup>lt;sup>20</sup> It is interesting to interpret Lemma 2 as a result concerning Dirichlet series. Putting certain coefficients of a Dirichlet series equal to zero can change the position of the abscissa  $\sigma_{\omega}$  of uniform convergence. Lemma 2 states that  $\sigma_{\omega}$  is never shifted to the right, when all coefficients, whose indices contain more than m prime factors, are replaced by zero.

In order to prove Theorem VI, we consider the Dirichlet series associated with the example (4.2). By Theorem B, the abscissa of uniform convergence is ? 0. On the other hand, there exists for any 3'>0, at least one set of real, non-increasing values x, with convergent

$$\sum_{n=1}^{\infty} x_n^{\frac{2m}{m-1}} + \delta',$$

such that the form (4.2) is non-absolutely convergent for these x,. They are non-inci'easing, hence

$$x_n^{\frac{2m}{m-1}+\delta'} = O\left(\frac{1}{n}\right)$$

as nit , or

$$x_n = O\left(n^{-\frac{1}{\frac{2m}{m-1}+\delta'}}\right).$$

But p, being the n-th prime number, we know that for any 6" > 0

d, - O(n logn) = o(n+ );

hence

$$n^{-(1+\delta'')} = o(p_n^{-1})$$

and

$$x_n = o\left(p_n^{-\frac{m-1}{2m}+\delta}\right)$$

for every d >0. Thus there exist a constant A, such that

$$x_n \leq A \cdot p_n^{-\frac{m-1}{2m} + \delta}$$

This shows that the Dirichlet series associated with (4.2) is non-absolutely

convergent in any half-plane 
$$\sigma \geq rac{m-1}{2 \ m} - \delta \qquad \qquad (\delta > 0)$$

and therefore

$$\sigma_a \geq \frac{m-1}{2 m}$$

Since a" < 0

$$\sigma_a - \sigma_u \geq \frac{m-1}{2m}$$

but by Theorem V, the left hand side cannot exceed-2 m hence

This is not true in general. Given any Dirichlet series for which X. - a. is different from zero, there exist coefficients, such that putting these equal to zero shifts au to the right by the difference -au.

$$\sigma_u = 0, \quad \sigma_a = \frac{m-1}{2m}, \quad \sigma_a - \sigma_u = \frac{m-1}{2m}.$$

6. Solution of the main problem. We give first an example of an ordinary Dirichlet series, for which aa -u = .

In the preceding sections we have only shown, that the inequality ala ?" - i cannot be replaced by a better one. But it is now easy to construct a Dirichlet series for which the width of the strip of uniform, but non-absolute convergence is exactly equal to 4.

We start from the examples (4.2)

$$Q_m(x) \equiv \sum_{\mu=1}^{\infty} \frac{1}{\mu^2} p^{-\mu \cdot \frac{m+1}{2}} Q_{\mu}(x^{(\mu)}),$$

where the index m refers to the degree of the form. Dividing each of these forms by its upper bound, we obtain new forms Q\* (x) bounded by 1 in the domain (Go). Let qm be any sequence of positive numbers, such that the series I qm is convergent. Put

$$P(x) \equiv \sum_{m=1}^{\infty} q_m \ Q_m^*(x).$$

The power series P is obviously bounded by I q. in (G0), the abscissa of uniform convergence of the associated Dirichlet series is non-positive

$$\sigma_u \leq 0$$

On the other hand, the forms Q\* have no term in common, because of their different degrees. Hence the power series is non-absolutely convergent as soon as one of the forms Q\* is non-absolutely convergent. This implies

$$\sigma_{a} \geqq rac{1}{2}$$
 ,

because, if a<4 we can find an m large enough, such that the corresponding Q\* would be non-absolutely convergent for x. = o,0 where a< < a<i<. But since au ? 0 and since the difference a -au ? 4, it must be exactly = 4:

$$\sigma_a = \frac{1}{2}; \quad \sigma_u = 0.$$

We turn now to the proof of the main theorem:

THEOREM VII. For any given a, in the interval 0 \_ a < 4, there exist ordinary Dirichiet series for which the width of the strip of uniform, but nonabsolute convergence is exactly equal to a.2"

The preceding example proved this theorem in the case a = , we therefore can suppose a<4. We determine m such that

<sup>21</sup> Cf. Remark at the end of the paper.

$$\frac{m-1}{2m} \geq \sigma$$

and Theorem VII will be proved, if we can show

THEOREM VIII. There exist ordinary Dirichiet series associated with m-ic forms, for which -a - = a, for every a in the interval 0 ? a \_ - 1 2 m

We take up again the r-ic forms

$$Q_{\mu}(x^{(\mu)}) \equiv \sum_{i_1, \dots i_m = 1}^{p^{\mu}} c_{i_1 \dots i_m} x_{i_1}^{(\mu)} \dots x_{i_m}^{(\mu)},$$

which were used to build up the example (4.2). By means of a parameter u, 0 ? u < 1, we are going to deform them into the worst examples, where all the coefficients are positive. We put

$$Q_{\mu}(x^{(\mu)}, u) \equiv \sum_{1}^{p^{\mu}} \epsilon_{i_{1} \cdots i_{m}}(u) c_{i_{1} \cdots i_{m}} x_{i_{1}}^{(\mu)} \cdots x_{i_{m}}^{(\mu)},$$

and suppose that the functions s j..m.(u) are continuous in u; equal to one in absolute value, and satisfy the boundary conditions

$$\epsilon_{i_1\cdots i_m}(0) = 1$$
 and  $\epsilon_{i_1\cdots i_m}(1) = \frac{|c_{i_1\cdots i_m}|}{c_{i_1\cdots i_m}}$ .

Let Hy (u) denote the maximum of the form Q, (u) in the domain (6%). It is readily seen that for all El, Hp, (u) is a continuous function of u with the following properties:

There exist absolute constants Al, A2, As such that 10 for all values u and all n =p

$$H_{\mu}\left(u
ight)\geqq A_{1}\cdot n^{rac{m+1}{2}}\,.$$
 (Theorem I)

20 for u 0 and all n = p"l

$$H_{\mu}(0) \leq A_2 n^{\frac{m+1}{2}}$$
. (Theorem II)

30 for u 1 and all n =pfL

$$H_{\mu}(1) \geq A_3 n^m$$
. 22

We have A, ? A2 and can suppose A, ? AS.

LEMMA 3. There exist two constants B1 and B2 such that for every r, m+1 < < m< and every p,, there exists a up for which 2 =

$$B_1 \cdot n^{\tau} \leq H_{\mu} \left( u_{\mu} \right) \leq B_2 \cdot n^{\tau}$$
.

<sup>22</sup> This follows from the fact that there exists an fi > 0, such that I cy1. i.

It is evidently sufficient to prove this lemma for large values of n. Let N be so large that

$$A_2 N^{\frac{m+1}{2}} \leq A_3 N^m.$$

Then for all n > N, we shall prove

$$(6.1) A_1 n^{\tau} \leq H_{\mu}(u_{\mu}) \leq A_2 n^{\tau}.$$

Since (Condition 2) 
$$H_{\mu}\left(0\right) \leqq A_2 \, n^{\frac{m+1}{2}} \leqq \left\{ \begin{matrix} A_3 \, n^m, \\ A_2 \, n^\tau, \end{matrix} \right.$$

and (Condition 3)

$$H_{\mu}\left(1\right) \geq A_{\mathbf{3}} n^{m},$$

we can find a up, such that

(6.2) 
$$H_{\mu}(u_{\mu}) = \min(A_3 n^m, A_2 n^{\tau})$$

This Hp (u,,) satisfies (6.1) because

$$A_1 n^{\tau} \leq \min(A_3 n^m, A_2 n^{\tau}).$$

LEMMA 4. For every Q in the interval 1 < Q < 2+I and everyrn n, there exist r-ic forms in n dimensions, for which

$$C_1 \cdot n^{rac{m}{arrho}} \leq C_2 H \mu \leq \left\{ \sum_{i_1 \cdots i_m = 1}^n |C_{i_1 \cdots i_m}|^{arrho} 
ight\}^{rac{1}{arrho}} \leq C_3 H \mu \leq C_4 n^{rac{m}{arrho}},$$

where the constants C1, C2, Cs and C4 are independent of n.

It is easily verified that the forms Q,1(xl"?, u1), where u. is determined by (6.2) satisfy these conditions.

We proceed from now on exactly as for the extreme case e - 2 ? We put

$$Q(x) \equiv \sum_{\mu=1}^{\infty} \frac{1}{\mu^2} p^{-\mu \cdot \frac{m}{\varrho}} Q_{\mu}(x^{(\mu)}, u_{\mu})$$

and prove that Q(x) satisfies the following conditions:

10 If Q(x) is bounded in |XnI \_ Gn, then it is absolutely convergent in X. |I ? En Gn; when ex converges x = )

20 Q(x) is bounded in IXn I 1.

30 For every 6 >0, there exist a set of real values Xn with convergent ' XX+6 for which Q (x) is non-absolutely convergent.

The associated Dirichlet series will be an example proving Theorem VIII, if we take e 1\_I1 -

7. Generalization to more general types of Dirichlet series. A theorem similar to Theorem VII cannot be formulated for general Dirichlet series Jae 27,S. The inequality

(7.1) 
$$\sigma_a - \sigma_u \leq \frac{D}{2}; \qquad D = \overline{\lim} \frac{\log n}{\lambda_n},$$

is not necessarily the best possible one, when the type {i} is given and not merely the quantity D, as in the case considered by Neder. For the type determined by the Dirichlet series associated with the polynomials of the mth degree, (7.1) ean be replaced (TheoremV) by

$$\sigma_a - \sigma_u \leq \frac{m-1}{m} \cdot \frac{D}{2}$$

the upper limit D being equal to one for this type.

However Bohr2" extended the results of his paper in the Gottinger Nachrichten to cover certain types of general Dirichlet series and for these types, with a further restriction to prevent the occurrence of examples similar to the one just mentioned, the inequality (7.1) is the best obtainable result.

Suppose that {b.} is a sequence of increasing positive numbers, which tend to oo and which are linearly independent in the field of rational numbers. Consider then the values

$$\sum_{\nu=1}^n r_{\nu} b_{\nu},$$

for any positive n, and any non-negative integral coefficients r,,. These values form a sequence, {4}, which can be arranged in increasing order

$$\lambda_1 < \lambda_2 < \cdots < \lambda_n < \cdots,$$

and whose elements An tend to A. This sequence can therefore be considered as the type of a Dirichlet series. The first sequence {bn} forms an integral base for {in}; the associated function obtained by putting Xn e bn is a power series in Xn. The methods of proving Theorems A, B of Bohr and our results apply in this case:

For such types the inequality (7.1) is the best possible result.

In the construction of examples for which dra-a 2 it is essential to observe that

$$D(b) = \overline{\lim} \frac{\log n}{b_n} = D(\lambda) = \overline{\lim} \frac{\log n}{\lambda_n},$$

<sup>23</sup> H. Bohr, Zur Theorie der allgemeinen Dirichletschen Reihen, Math. Annalen 79, (1919), p. 136-156.

which is equivalent to the statement:

The exponent D (b) of convergence of the sequence {eb'} is equal to the exponent D1(i) of convergence of the sequence {e i-}.

We have obviously in ? b. and therefore

$$D(b) \leq D(\lambda),$$

and it remains only to show that I e An converges when ;e- b~ a converges. For the subsequence {i}, obtained by taking only the m first elements

of the base, we have 
$$\sum e^{-\lambda_n'\sigma} = \sum_{r_1, \cdots r_m = 0}^{\infty} e^{-\sigma \sum_1^m r_{\nu}b_{\nu}} = \prod_{\nu=1}^m \frac{1}{1 - e^{-\sigma b_{\nu}}}$$

$$\leq \prod_{\nu=1}^m \left(1 + \frac{e^{-\sigma b_{\nu}}}{1 - e^{-\sigma b_1}}\right) \leq \prod_{\nu=1}^{\infty} \left(1 + \frac{e^{-\sigma b_{\nu}}}{1 - e^{-\sigma b_1}}\right).$$

This last infinite product is convergent, proving thus

$$D(b) \geq D(\lambda),$$

and therefore 
$$D(b) = D(\lambda)$$

We are able now to construct new examples proving Neder's result. Given any non-negative D, there exist Dirichlet series for which

$$\sigma_a - \sigma_u = \frac{D}{2}$$

of all types {in}, obtained from a base {bn}, 0< b, < bn satisfying

$$D = \overline{\lim} \, \frac{\log n}{b_n}.$$

The simplest example is

$$b_n = \frac{1}{D} \cdot \log n,$$

which gives Dirichlet series of the type I an \* n D, obtained from ordinary Dirichlet series by the substitution s

PRINCETON UNIVERSITY.

REMARK (added in proof, May, 1931). As Prof. Bohr pointed out to us, Theorem VII can be proved more simply as follows. Let f (s) be a Dirichlet series whose -O 0 and whose ma-ok. If C(s) denotes the Riemann Zeta-function (a, = = 1) and a any real number 0 < a <, then f (s) + C'(s + 1 - a) is a Dirichlet series for which Maa-a6= Similar examples prove Theorem VIII. It may be interesting however, to see that the method used to obtain best possible examples is flexible enough to give the whole range of possible values for the difference iaa ,-