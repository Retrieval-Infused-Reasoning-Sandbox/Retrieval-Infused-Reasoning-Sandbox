## nature genetics

**Article** 

https://doi.org/10.1038/s41588-024-01914-4

# Spatial transcriptomic analysis of primary and metastatic pancreatic cancers highlights tumor microenvironmental heterogeneity

Received: 23 February 2024

Accepted: 19 August 2024

Published online: 18 September 2024

![](_page_0_Picture_7.jpeg)

Ateeq M. Khaliq © <sup>1,2</sup>, Meenakshi Rajamohan © <sup>3</sup>, Omer Saeed <sup>4</sup>, Kimia Mansouri © <sup>3</sup>, Asif Adil © <sup>2</sup>, Chi Zhang <sup>1,5</sup>, Anita Turk <sup>1,2</sup>, Julienne L. Carstens <sup>6</sup>, Michael House <sup>1</sup>, Sikander Hayat © <sup>7</sup>, Ganji P. Nagaraju <sup>6</sup>, Sam G. Pappas <sup>8</sup>, Y. Alan. Wang © <sup>1,2</sup>, Nicholas J. Zyromski <sup>1</sup>, Mateusz Opyrchal © <sup>1,2</sup>, Kelvin P. Lee <sup>1,2</sup>, Heather O'Hagan © <sup>1,5</sup>, Bassel El Rayes <sup>6,9</sup> & Ashiq Masood © <sup>1,2,3,9</sup>

Although the spatial, cellular and molecular landscapes of resected pancreatic ductal adenocarcinoma (PDAC) are well documented, the characteristics of its metastatic ecology remain elusive. By applying spatially resolved transcriptomics to matched primary and metastatic PDAC samples, we discovered a conserved continuum of fibrotic, metabolic and immunosuppressive spatial ecotypes across anatomical regions. We observed spatial tumor microenvironment heterogeneity spanning beyond that previously appreciated in PDAC. Through comparative analysis, we show that the spatial ecotypes exhibit distinct enrichment between primary and metastatic sites, implying adaptability to the local environment for survival and progression. The invasive border ecotype exhibits both pro-tumorigenic and anti-tumorigenic cell-type enrichment, suggesting a potential immunotherapy target. The ecotype heterogeneity across patients emphasizes the need to map individual patient landscapes to develop personalized treatment strategies. Collectively, our findings provide critical insights into metastatic PDAC biology and serve as a valuable resource for future therapeutic exploration and molecular investigations.

PDAC is an inherently aggressive disease. Only about 15% of patients present with resectable tumors at diagnosis; the majority are diagnosed with either locally advanced or metastatic disease. Approximately 50% of patients have metastatic disease at diagnosis, with over 80% of these metastases occurring in the liver  $^{1-3}$ . Surgery remains the sole curative approach for PDAC treatment. When locally advanced or distant metastases are identified, radical surgical therapy is not the standard of care  $^4$ . Therefore, obtaining matched primary and metastatic samples,

especially large tissue sections for spatial transcriptomics (ST), is a major challenge. Consequently, most genomic analyses are based on early-stage disease, which represents a minority of the real-world patient population<sup>5–9</sup>. Recent bulk RNA sequencing of primary and metastatic PDAC revealed epithelial–mesenchymal transition (EMT) downregulation, increased M2 macrophages and complement activation in liver metastases<sup>10</sup>. However, bulk transcriptomic approaches provide average gene expression, overlooking distinct

<sup>1</sup>Melvin and Bren Simon Comprehensive Cancer Center, Indiana University School of Medicine, Indianapolis, IN, USA. <sup>2</sup>Department of Medicine, Division of Hematology/Oncology, Indiana University School of Medicine, Indianapolis, IN, USA. <sup>3</sup>Luddy School of Informatics, Computing, and Engineering, Indiana University, Indianapolis, IN, USA. <sup>4</sup>Department of Pathology, Indiana University School of Medicine, Indianapolis, IN, USA. <sup>5</sup>Department of Medical and Molecular Genetics, Indiana University School of Medicine, Indianapolis, IN, USA. <sup>6</sup>Division of Hematology and Oncology, O'Neal Comprehensive Cancer Center, University of Alabama at Birmingham, Birmingham, AL, USA. <sup>7</sup>University Hospital RWTH Aachen, Aachen, Germany. <sup>8</sup>Division of Surgical Oncology, Rush University Medical Center, Chicago, IL, USA. <sup>9</sup>These authors jointly supervised this work: Bassel El Rayes, Ashig Masood. ⋈e-mail: asmasood@iu.edu

![](_page_1_Figure_2.jpeg)

<span id="page-1-0"></span>**Fig. 1** | **Spatial transcriptomic profiling of human pancreatic cancer and metastasis. a**, Outline of the research methodology and analytical approach. FFPE, formalin-fixed, paraffin-embedded; Min, minimum expression; Max, maximum expression. **b**, H&E micrographs of primary tumor (PT), hepatic metastasis (HM), lymph node metastasis (LNM) and normal pancreas (NP).

 ${f c}$ , Cell marker gene expression levels in PT, HM, LNM and NP samples.  ${f d}$ ,  ${f e}$ , Description of ST data using cell-type deconvolution ( ${f d}$ ) and cellular and pathway activation using functional gene expression signature (Fges) gene sets ( ${f e}$ ). For details on visualization, statistics and reproducibility, see Methods. TE cells, tumor epithelial cells; Tumor P rate, tumor proliferation rate. Created using BioRender.

microenvironmental ecosystems driving progression. Additionally, elucidating the precise spatial and cellular contexts of these molecular changes requires resolving localized heterogeneous signals that are obscured in bulk profiling 11. Recent single-cell RNA sequencing (scRNA-seq) studies have unveiled the extensive heterogeneity of malignant and non-malignant cells in PDAC 12-19. Although a subset of these studies have characterized tumor ecosystems in primary PDAC tumors, the spatial context of diverse cell populations and a comprehensive understanding of metastatic biology remain elusive 17-19. Determining the spatial organization of tumor ecosystems and the cellular dynamics underlying metastasis is crucial for advancing our understanding of PDAC biology and developing effective therapies.

By acquiring a cohort of matched primary tumors, lymph nodes and liver metastases from patients with PDAC, we successfully overcome these long-standing barriers. Through integrated spatially resolved transcriptomics, we constructed spatial maps revealing the distinct cellular states and ecological dynamics of PDAC progression. By accounting for interindividual differences with paired sampling and deconvoluting cell-type compositions, our study revealed conserved and differential ecosystems between primary and metastatic sites. These results suggest the simultaneous targeting of diverse ecological ecotypes within each patient for optimal therapeutic impact against this aggressive malignancy. Overall, this study uses

ST on patient-matched samples to reveal important differences in the tumor microenvironment (TME) of PDAC, which could guide the development of more effective treatments.

#### Results

#### A spatial transcriptome map of PDAC

To map the molecular and cellular architecture of various anatomical regions in PDAC, we initially identified 39 samples from 13 patients, including matched primary PDAC tumors, corresponding liver metastases, three normal adjacent pancreatic tissues, three adjacent normal liver tissues and seven metastatic lymph nodes (Supplementary Table 1). After quality control and discarding of low-quality samples, we generated an atlas of ST from a cohort of 30 specimens: ten primary PDAC tumors, three normal pancreata, 12 matched hepatic metastases and five matched lymph node metastases, along with adjacent normal liver and lymph node tissues (Fig. 1a). The clinical and histopathological characteristics of the patients are described in the Extended Data section (Supplementary Table 2). We applied Visium v.1 Spatial Gene Expression for FFPE (10× Genomics) to our sample cohort. Low-quality spots (gene count of <200) were removed, leaving 35,458 primary tumor spots, 28,520 hepatic metastasis spots, 17,698 lymph node metastasis spots and 9,820 normal pancreas spots (totaling 91,496 spots) for downstream analysis (Fig. 1a). We meticulously implemented a standardized quality-control pipeline (Extended Data Fig. 1a, Supplementary Table 2 and Methods) and precisely assessed the effectiveness of our methods to ensure accurate and reliable results (Fig. [1b–e](#page-1-0) and Extended Data Fig. 1b,c).

A multistep approach was used to ensure that each cellular state was accurately located within its expected histologically identified structures. First, an expert board-certified pathologist (O.S.) performed histological structural annotation on hematoxylin and eosin (H&E) images (Fig. [1b](#page-1-0)). Next, mapping of the expected major cell markers including epithelial cells (*EPCAM*<sup>+</sup> , *KRT8*<sup>+</sup> and *KRT18*<sup>+</sup> ), fibroblasts (*COL1A1*<sup>+</sup> ), endothelial cells (*CLDN5*<sup>+</sup> ), T cells (*CD3D*<sup>+</sup> ), B cells (*CD79A*<sup>+</sup> ) and myeloid cells (*LYZ*<sup>+</sup> ) to the structures was confirmed (Fig. [1c\)](#page-1-0). Our heterogeneous ST data covered a variety of tissue regions, including normal pancreas, primary tumor, hepatic metastasis and lymph node metastases, as well as the adjacent liver and lymph node tissues. To enable higher-resolution analysis at the cellular level, we deconvoluted our ST data using a diverse set of published scRNA-seq datasets encompassing all tissue types analyzed in our study[8,](#page-8-10)[12,](#page-8-7)[20](#page-9-0). Leveraging these datasets, we mapped fine granular cell states defined by scRNA-seq to our ST data using the reference-based robust cell-type decomposition (RCTD) deconvolution algorithm (Fig. [1d,](#page-1-0) Supplementary Data 1 and Methods[\)21](#page-9-1). Our deconvolution analysis corroborated the major histological regions, including tumor and stromal compartments as well as the main cell-type regions annotated by a gastrointestinal pathologist (O.S.) (Fig.[1b–e\)](#page-1-0). Tumor regions were accurately identified as tumor cells by RCTD, whereas stromal regions in tumor areas were annotated as cancer-associated fibroblasts (CAFs) across anatomical regions annotated by the gastrointestinal pathologist (O.S.). Additionally, the RCTD deconvoluted various immune cell types, showing their presence in both the tumor and stromal areas, in line with previous scRNA-seq data[8](#page-8-10)[,12](#page-8-7)[–20](#page-9-0) (Fig. [1d](#page-1-0) and Extended Data Fig. 1b,c). The deconvolution results revealed distinctly annotated hepatocytes only in adjacent normal liver tissue (Extended Data Fig. 1b)[20.](#page-9-0) Normal pancreatic tissue was annotated as normal pancreatic cells (Extended Data Fig. 1b). Additionally, normal liver regions were infiltrated by immune and stromal cells, consistent with the findings of a previous scRNA-seq study[20](#page-9-0). Similarly, adjacent lymph nodes contained a high proportion of various immune cells, including B cells, T cells and natural killer cells[22](#page-9-2).

Integrating these robust cellular annotations with our spatial molecular profiles enabled a detailed interrogation of the tumor and its microenvironment. Furthermore, we evaluated the expression of cell type-specific functional gene signatures to identify critical functional and cellular characteristics of the tumor and its microenvironment within spatial ecotypes and enrichment scores to confirm fine granular cell states (see below) (Fig. [1e](#page-1-0) and Supplementary Data 2[\)23.](#page-9-3) Consequently, our integrated spatial atlas mapped cell composition, gene expression and signaling pathways across pancreatic tissue anatomical zones, allowing us to study complex TME dynamics in human PDAC across various stages.

#### **Spatial architecture of pancreatic cancer**

To elucidate the spatial dynamics of cellular interactions and abundance in PDAC, we applied MISTy, an explainable machine-learning framework, to probe whether the abundance of major cell types within individual transcriptomic spots could be predicted from their spatial context, defined by the cell-type compositions of their microenvironment[24.](#page-9-4) Specifically, we examined whether the local neighborhood cellular milieu, characterized by relative cell-type proportions, could determine the abundance of key cellular compartments across intra-spot (~55 μm), juxta view (~200 μm; five spot radius) and para view (~3,000 μm; 15 spot radius) spatial scales. Across tumor regions, co-localized interactions within individual tissue spots (intraview) emerged as the most predictive feature, revealing co-occurrences between malignant cells and non-neoplastic populations, including CAFs, lymphoid cells (for example, T cells and B cells) and tumorassociated macrophages (TAMs) (Fig. [2a](#page-3-0), Extended Data Fig. 2a,b and Supplementary Table 3). The myofibroblastic CAFs (myCAFs) exhibited juxtaposition with tumor cells, whereas inflammatory CAFs resided distally, potentially fostering an inflammatory environment, consistent with existing data on their spatial distribution relative to malignant cells (Fig. [2a](#page-3-0) and Extended Data Fig. 2b)[25.](#page-9-5) Endothelial cell and perivascular-like fibroblast co-occurrence mirrored interdependencies among vasculature-related cell types and their significance in PDAC biology across anatomical location[s26.](#page-9-6) Homotypic interactions predominated across immune subsets, implying a spatially coordinated TME[27](#page-9-7). Interestingly, TAM subtypes with contrasting functionalities, such as inflammatory FCN1+ and immunosuppressive SPP1+ and C1Q<sup>+</sup> phenotypes, co-localized within tumors, corroborating recent findings that TAMs with both immunostimulatory and immunosuppressive roles can coexist in the same TME (Fig. [2a](#page-3-0) and Extended Data Fig. 2b)[28](#page-9-8). The spatial dynamics between cell types, such as tumor and dendritic cells, diverged from expectations based on frequencies alone, underscoring that spatial interactions may be more critical than cell frequencies alone[27.](#page-9-7) Collectively, these findings highlight the importance of spatial relationships between cell types in the PDAC TME that may potentially inform our understanding of tumor biology and treatment approaches.

The co-localization of tumor, immune and stromal cells highlights the potential to gain insights into the functional roles of cancer cell states by studying the tumor architecture. Consequently, we sought to determine whether spatially organized multicellular communities exist beyond co-occurrence and abundance in PDAC, which could provide critical insights into tumor biology and therapeutic vulnerabilities. We reasoned that disruption of cellular neighborhoods in cancer mirrors disturbances in natural ecosystems, affecting disease progression and treatment[29.](#page-9-9) To identify these multicellular communities and their spatial distribution in PDAC, we used ISCHIA, a probabilistic methodology to identify cellular neighborhoods through co-occurrence analysis, inspired by models of species co-occurrence in ecology[30](#page-9-10). This composition-based clustering approach enables the reconstruction of the local TME architecture based on spatial co-occurrence and potential collaborations of diverse cell types within each spot. Clustering of spots from all samples based on their cell-type compositions revealed ten heterogeneous compositional clusters (CCs), which we called 'spatial ecotypes' (Fig. [2b–d,](#page-3-0) Extended Data Fig. 2b and Supplementary Table 4). Visualization of the slides revealed that several ecotypes aligned with the underlying sample conditions, with ecotype CC10 uniformly distributed across the normal pancreatic parenchyma and ecotypes CC6 and CC9 localized to adjacent non-neoplastic liver and lymph nodes, respectively (Fig. [2e](#page-3-0) and Extended Data Fig. 2c).

Next, we investigated whether the distinct annotated cell types identified by scRNA-seq were overrepresented in specific spatial ecotypes across the PDAC ecosystem. ST analysis unveiled transcriptionally defined ecotypes with varying compositions of tumor cells, stromal cells and infiltrating immune cells (Fig. [2d](#page-3-0) and Extended Data Fig. 2d,e). Interestingly, each tumor ecotype localized to distinct regions on histomorphology slides across samples, suggesting that these ecotypes represent foundational spatial units that could facilitate comparisons (Fig. [2e\)](#page-3-0). We identified contrasting cellular ecotypes based on their predominant cell-type composition. Two ecotypes, CC1 and CC5, were predominantly enriched for CAFs alongside tumor cells and various immune subsets, reminiscent of a highly desmoplastic TME subtype previously recognized in single-cell analysis (see below)[19.](#page-8-8) Prompted by the realization that we noted two desmoplastic ecotypes as opposed to the previous single subtype based on a single-cell study, we carried out detailed pathological evaluation that revealed key differences between the CAF-enriched ecotypes (CC1 and CC5), including stromal architecture, CAF enrichment and tumor and immune cell compositions (Fig. [2f](#page-3-0)). Compared with CC5, CC1 exhibited a remarkably dense stromal architecture with a greater prevalence of myCAFs

![](_page_3_Figure_2.jpeg)

<span id="page-3-0"></span> $\label{lem:continuous} \textbf{Fig. 2} | \textbf{Identification of pancreatic cancer architecture. a}, \textbf{Schematic} \\ \textbf{representation of intraview cell-cell interaction networks using MISTy within} \\ \textbf{Visium spots. b}, \textbf{Heatmap showing the scaled median compositions of cell types} \\ \textbf{within each spatial ecotype (CC1-CC10)}. \textbf{The scaled median cell-type compositions} \\ \textbf{were determined using a one-sided Wilcoxon rank-sum test, with adjustments for multiple comparisons (adj. <math>P < 0.05$ ), denoted by an asterisk.  $\mathbf{c}$ , Uniform manifold

approximation and projection (UMAP) plot of ST spots clustered by cell-type composition-based k-means clustering colored by the ten spatial ecotypes.  $\mathbf{d}$ , Bar plots showing cell-type composition of each spatial ecotype.  $\mathbf{e}$ , Visualization of spatial ecotypes in PT, NP, LNM and HM samples.  $\mathbf{f}$ , Structural annotations by a gastrointestinal pathologist show dense stroma in CC1 compared with CC5. PVL, perivascular-like; NK, natural killer; iCAF, inflammatory CAF; DC, dendritic cell.

![](_page_4_Figure_2.jpeg)

<span id="page-4-0"></span>**Fig. 3** | **Spatial ecotype analyses of primary and metastatic pancreatic cancer. a**, Sankey plot and bar plot showing the pattern of spatial enrichment (CCs) across different histological subtypes. The bandwidth in the Sankey plot is proportional to the number of spots. **b**, Heatmap of relative Fges for scaled GSEA across ecotypes. **c**, Expression of the top enriched pathways in PT, LNM and HM samples, showing ST sections colored by ecotype (left) and pathway activity (right). **d**, Box plots comparing scaled GSEA scores for Fges, MSigDB

gene sets and cell-type proportions between CC1, CC2, CC3 and CC5 ecotypes. Data represent n=9,236,12,679,13,276 and 8,147 spots for CC1, CC2, CC3 and CC5, respectively, collected from 13 individual patients. The number of patients contributing to each ecotype varies: CC1 (12 patients), CC2 (12 patients), CC3 (12 patients) and CC5 (13 patients). Each spot represents an independent data point. For details on visualization, statistics and reproducibility, see Methods.

infiltration (Fig. 2f and Extended Data Fig. 2c,d). Trajectory analysis suggested that the CC5 ecotype represents an early desmoplastic state transitioning toward the late, fibrotic, myCAF-enriched CC1 ecotype, consistent with evidence that desmoplasia increases as PDAC progresses<sup>17</sup>. The existence of these distinct ecotypes highlights further TME heterogeneity within the desmoplastic subtype than previously appreciated<sup>31,32</sup>. By contrast, two other ecotypes, CC2 and CC3, were enriched for tumor cells with reduced CAF infiltration, followed by immune components (Supplementary Figs. 2 and 3). These ecotypes correspond to a less desmoplastic milieu analogous to the previously described 'loose' subtype<sup>19</sup>. Notably, the CC2 ecotype harbored a prominent enrichment of TAMs, T cell infiltrates, active endothelial cells and angiogenesis compared to the CC3 ecotype (Supplementary Figs. 2 and 3). Additionally, we observed two immune cell-dominant ecotypes, CC7 and CC8, exhibiting varying myeloid-to-lymphoid ratios with minor fractions of tumor and stromal cells. Furthermore, a mixed ecotype, CC4, contained both tumor cells and CAFs (Fig. 2b,d).

An area exhibiting CC2 and CC3 spatial ecotypes in a normal pancreas sample was re-examined and verified as a pancreatic intra-epithelial neoplasia lesion, potentially explaining its transcriptomic resemblance to PDAC (Supplementary Figs. 1a–d)<sup>33</sup>. Conversely, it is possible that our dataset was too deficient in adequate pancreatic intraepithelial neoplasia lesions to generate discrete spatial ecotypes. Additionally, an area resembling a normal lymph node (CC9) within

a primary tumor was confirmed as an attached normal lymph node upon reassessment by a pathologist (O.S.).

Overall, comprehensive spatial mapping revealed substantial TME heterogeneity in PDAC stemming from the variable composition of malignant, stromal and immune cell populations in each distinct spatial location (ecotype), laying the groundwork for comparative analyses.

#### Structural variations in pancreatic cancer ecosystems

To identify differences in spatial ecotypes during PDAC progression, we compared samples from distinct histomorphological regions at molecular and compositional levels. We observed distinct enrichment patterns across five of seven tumor-associated spatial ecotypes between primary PDAC and its metastatic sites (Fig. 3a-d, Extended Data Fig. 3a-c and Supplementary Data 2). Primary pancreatic tumors were dominated by desmoplastic and hypoxic fibrotic niches (CC1 and CC5) enriched with abundant extracellular matrix deposition and a dense stromal compartment populated predominantly by myCAFs, perivascular-like fibroblasts and immunosuppressive immune cells, notably regulatory T cells (T<sub>reg</sub> cells) and TAMs (Fig. 3b, Extended Data Fig. 3d, Supplementary Data 2 and Supplementary Figs. 2 and 3). These observations corroborate previous findings of an 'activated stroma' subtype in PDAC enriched for myCAFs, M2-like macrophages and T<sub>reg</sub> cells as well as the well-established immunosuppressive and desmoplastic nature of the primary PDAC TME<sup>18,34</sup>. Concordantly, gene

![](_page_5_Figure_2.jpeg)

<span id="page-5-0"></span>**Fig. 4 | Metabolic flux analysis of spatial ecotypes. a**, Schematic overview of neural-network-based metabolic flux perturbations. **b**, Depiction of metabolic flux in key ecotypes (CC1, CC3 and CC5). **c**, Metabolic flux perturbation within key ecotypes, plotted for representative PT, HM and LN samples.

enrichment analysis revealed upregulation of EMT-related signature, angiogenesis and coagulation cellular adaptations to the hypoxic stress prevalent in these ecotypes (Fig. [3b–d](#page-4-0), Supplementary Data 2 and Supplementary Figs. 2–4)[35](#page-9-15)[–42.](#page-9-16) Within these primary tumor-enriched ecotypes (CC1, CC5), we noted enrichment of CD4<sup>+</sup> helper T cells, CD8<sup>+</sup> cytotoxic T cells, TH2 cell enrichment and upregulation of checkpoint inhibition compared to CC2 and CC3 ecotypes (see below), consistent with the literature (Fig. [3d](#page-4-0) and Supplementary Fig. 3[\)8](#page-8-10)[,12](#page-8-7). Notably, both hypoxia and EMT have been implicated in modulating the TME through the recruitment of immunosuppressive cell types, including Treg cells and TAM[s43–](#page-9-17)[49.](#page-9-18) Similarly, there is some evidence that hypoxia can induce coagulation in the TME, increasing interstitial fluid pressure and reducing tumor vessel lumen, which may further exacerbate hypoxi[a50](#page-9-19)[,51.](#page-9-20) Conversely, the metastasis-enriched ecotypes (CC2 and CC3) exhibited a distinct phenotype characterized by a lower desmoplastic stroma with reduced CAF infiltration and a more proliferative phenotype, as indicated by the activation of proliferative pathways including E2F, MYC and G2M checkpoint pathways (Fig. [3b–d,](#page-4-0) Extended Data Fig. 3d, Supplementary Fig. 4 and Supplementary Data 3[\)10,](#page-8-5)[52.](#page-9-21) Notably, these ecotypes mirrored the metabolically active subtype recently identified in primary PDAC tumors with low desmoplasia, exhibiting high glycolytic activit[y19.](#page-8-8) Additionally, metastasis-enriched ecotypes display oncogenic activation of *TP53*, the inflammatory response and the PI3K–AKT–mTOR pathway. The PI3K–AKT signaling may synergize with *MYC* to drive glycolysis, fueling the biosynthetic demands of highly proliferative metastatic cells (Fig. [3d](#page-4-0), Extended Data Fig. 3d, Supplementary Fig. 4 and Supplementary Data 3)[53–](#page-9-22)[59](#page-9-23). Metabolic reprogramming is known to induce immunosuppression[60](#page-9-24),[61.](#page-9-25) The CC4 ecotype, with mixed immune, stromal and tumor cell enrichment, was shared across anatomical locations. Collectively, these findings highlight the complex, context-dependent interactions between the tumor, stromal and immune compartments that shape distinct spatial ecotypes within the PDAC ecosystem, from the primary tumor to metastatic sites.

Despite engaging in critical roles within PDAC spatial biology, our analyses revealed marked interpatient heterogeneities among these ecotypes, evident both within individual patient samples and between matched primary and metastatic lesions (Fig. [2d](#page-3-0) and Extended Data Fig. 3a). These findings clarify the complex and variable ecological topography underlying the marked heterogeneity of PDAC.

#### **Metabolic rewiring and vulnerabilities in pancreatic cancer**

Following the identification of metabolic heterogeneity across spatial ecotypes, especially in primary and metastatic enriched ecosystems, we systematically investigated metabolic flux through single-cell flux estimation analysis (Fig. [4a–c](#page-5-0), Extended Data Figs. 4a,b and 5a and Supplementary Table 5)[62](#page-9-26). Single-cell flux estimation analysis uses a graph neural-network-based model to approximate the metabolic flux rate in each spatial spot using ST data (Fig. [4a\)](#page-5-0). The primary tumor-enriched ecotype (CC1) demonstrated reduced glycolysis and pentose flux, along with increased dependence on glutamine and disrupted nucleotide synthesis (Fig. [4b,c](#page-5-0) and Extended Data Fig. 4a)[63](#page-9-27).

![](_page_6_Figure_2.jpeg)

<span id="page-6-0"></span>**Fig. 5 | Invasive ecotype and immune enrichment in pancreatic cancer. a**–**c**, Invasive border on an H&E image at ×20 resolution (**a**), zoomed in ×100 showing the blue hue characteristics of the invasive border (**b**) and zoomed in ×400 resolution showing the histopathological annotation of major cell types (**c**). **d**, Immunohistochemistry images showing CD4<sup>+</sup> T cells (anti-CD4), M2-like

macrophages (anti-CD68), pan-macrophages (anti-CD163) and CD8<sup>+</sup> T cells (anti-CD8) at the invasive front. **e**, Co-occurrence analysis showing relationships between the deconvolution estimations (cell types) within a spot. **f**, Schematic representation of the immunogenic invasive border ecotype.

By contrast, CC5 (another primary tumor-enriched ecotype) exhibited a distinct decrease in tricarboxylic acid cycle activity, indicating impaired mitochondrial function even though glycolytic flow remained intact (Fig. [4b,c](#page-5-0) and Extended Data Fig. 4b)[64](#page-9-28). CC5 demonstrates impaired glycoprotein assembly, probably impairing its secretion and signaling. Additionally, it decreases fatty acid synthesis because of its decreased acetyl-CoA carboxylase activity. By contrast, the metastatic enriched spatial ecotype (CC3) exhibited increased glycolytic activity and pentose flux as well as increased amino acid and glycan synthesis (Fig. [4b,c](#page-5-0) and Extended Data Fig. 5a)[65](#page-10-0)[,66.](#page-10-1) This eventually enabled enhanced nutrient incorporation into the biomass. Although both CC4 and CC5 spatial ecotypes showed altered metabolism, CC4 displayed broad central carbon restrictions, whereas CC5 showed more targeted biosynthesis limitations (Fig. [4b,c](#page-5-0)). CC4 displayed attenuated flux through key metabolic pathways, such as glycolysis and the tricarboxylic acid cycle, indicating impaired central carbon metabolism. Moreover, the presence of amino acid catabolic enzymes, such as proline dehydrogenase, coupled with dysregulated pyrimidine synthesis suggests altered nitrogen balance. In summary, these results clearly depict spatially dependent metabolic heterogeneity in the TME of PDAC. Developing therapeutic strategies based on cellular compositional spatial ecotypes across anatomical locations could selectively target metabolic defects that promote PDAC progression and survival.

#### **ST of immune landscapes at tumor border**

Examination of PDAC samples across primary and metastatic samples revealed a marked increase in immune cell infiltration compared to that in normal pancreatic samples (Figs. [2d,e](#page-3-0) and [5a–f,](#page-6-0) Extended Data Fig. 6a,b and Supplementary Fig. 5). Specifically, the immunogenic CC7 ecotype, enriched in metastatic lesions, was observed at the boundary zone between the tumor mass and the adjacent normal tissue, aligning with the invasive tumor front (Fig. [5a,b](#page-6-0) and Extended Data Fig. 6a). Upon further evaluation by a gastrointestinal pathologist (O.S.), areas of dense immune cell infiltration exhibited a bluish hue on H&E staining, and high-magnification (×400) analysis revealed extracellular matrix deposition containing prominent fibroblasts, inflammatory cells and cancer cells (Fig. [5b,c\)](#page-6-0). These pathological findings are known to represent the host immune response to tumor cells

![](_page_7_Figure_2.jpeg)

<span id="page-7-0"></span>**Fig. 6 | Atlas of pancreatic adenocarcinoma and metastasis.** Schematic representation of spatial tumor microenvironment heterogeneity across various stages of pancreatic cancer. Primary tumor-enriched ecotypes are characterized by highly desmoplastic spatial ecotypes with abundant CAFs, extensive ECM

and hypoxic regions. Metastasis-enriched ecotypes are distinguished by high enrichment of malignant cells with high proliferative behavior evidenced by enrichment of E2F targets and MYC amplification. ECM, extracellular matrix. Created using [BioRender](https://www.biorender.com).

(invasive border)[67.](#page-10-2) The invasive (CC7 ecotype) tumor border exhibited endothelial activation, EMT, angiogenesis and notably high levels of myCAF and inflammatory CAFs, M1-like and M2-like macrophages and enrichment of Treg cells, CD8+ cytotoxic T cells, TH1, TH2 and natural killer cells, indicating a dynamic interaction between pro-tumorigenic and anti-tumor factors, consistent with previous data (Figs. [3b](#page-4-0) and [5c,d](#page-6-0) and Supplementary Fig. 5)[68](#page-10-3). Immunohistochemistry confirmed the presence of CD4+ T cells, CD8+ T cells and macrophages, especially M2-like, at the invasive front (Fig. [5d](#page-6-0) and Supplementary Fig. 5). To explore the interconnectedness of the TME in CC7, we carried out co-occurrence analysis and noted complex interconnectedness of tumors, stromal and immune cells (Fig. [5e](#page-6-0) and Extended Data Fig. 6b). More importantly, we noted co-occurrences of both pro-tumor and anti-tumor cell types. For instance, we noted that IL-1B monocytes, FCN1+ TAMs and C1Q+ TAMs depicted strong co-occurrences. Additionally, we noted the interconnectedness of distinct T cell subsets, such as CD8<sup>+</sup> T cells, Treg cells and other subsets of T cells in their neighborhood. This suggests a complex interplay of tumor-promoting factors like TAMs and tumor-suppressing factors like effector T cells in the CC7 ecotype (Fig. [5f](#page-6-0)).

A distinct secondary ecotype (CC8) formed an abnormal transitional zone, specifically separating CC7 from healthy liver tissue (CC6) (Fig. [2d,e](#page-3-0)). This spatial ecotype was unique to the liver and was composed of fibroblasts, tumor cells, hepatocytes and immune cells. It had similarities with both CC6 and invasive CC7, suggesting a continuum between normal liver parenchyma, the CC8 zone and CC7. In addition, we found pro-tumor signatures that were surprisingly present even in adjacent normal lymph node regions (CC9) and the liver (CC6). These include Treg cell trafficking and myeloid cell immunosuppression, aligning with recent evidence that metastatic cells rewire normal lymph node immune cells and complement the unique immunosuppressive hepatic architecture enabling tumor immune tolerance[69](#page-10-4)[,70](#page-10-5).

#### **Discussion**

In this study, we integrated spatially resolved transcriptomics and ecotype analyses to map the PDAC tumor immune microenvironment across anatomical regions. Analyzing a unique cohort of matched primary and metastatic PDAC samples, we uncovered valuable insights that appreciably advance our understanding of PDAC biology. Our findings reveal a complex continuum of metabolic, stromal and immune spatial ecotypes that vary across PDAC anatomical regions, demonstrating a level of TME heterogeneity that extends beyond previous single-cell studies. This work provides an important spatial perspective on ecotype changes from primary to metastatic sites in PDAC, offering an enhanced framework for understanding disease progression. By capturing crucial spatial relationships within tumors, our approach provides additional insights into PDAC complexity, potentially informing future therapeutic strategies.

Notably, we identified differential enrichment patterns of spatial ecotypes between primary and metastatic sites in matched samples. By integrating our ST-derived insights with prior PDAC scRNA-seq studies and independent targeted functional studies, as cited throughout the Results, we identify candidate mechanisms for how diverse cellular states and pathway alterations shape the primary and metastatic environments. Notably, although previous scRNA-seq studies defined distinct loose (low desmoplasia) and dense (high desmoplasia) PDAC subtypes, our ST analysis revealed that features of both subtypes can coexist within the same patient[19,](#page-8-8)[71.](#page-10-6) The coexistence of multiple ecotypes within individual patients suggests a more nuanced perspective than the mutually exclusive subtypes derived from scRNA-seq studies, underscoring the complexity and heterogeneity of the TME that can only be appreciated through spatial analysis.

The primary tumor-enriched ecotypes (for example, CC1, CC5) were characterized by desmoplastic, hypoxic, EMT-related gene signatures and immunosuppressive features reminiscent of the documented primary desmoplastic PDAC subtype[19](#page-8-8) (Fig. [6\)](#page-7-0). However, our spatial mapping revealed additional heterogeneity within this subtype. By contrast, the metastasis-enriched ecotypes (CC2, CC3) exhibited diminished desmoplasia, reduced CAF infiltration and an intensified proliferative phenotype coupled with metabolic reprogramming toward oxidative phosphorylation, glycolytic flux and biosynthetic pathways[17](#page-8-9)[–19](#page-8-8). This metabolic shift probably exacerbates immunosuppression, undermining anti-tumor immunity and promoting metastatic cell survival, as corroborated by the low CD8<sup>+</sup> T cell and natural killer cell enrichment[60,](#page-9-24)[61](#page-9-25)[,72,](#page-10-7)[73](#page-10-8). Significantly, the loose subtype was predicted to have metastatic potential using primary tumors, and our ST study confirmed their enrichment in metastasis, providing direct evidence that may have important therapeutic and prognostic implications[19.](#page-8-8) Our study validates and expands upon this prediction from primary tumor analysis, demonstrating the power of ST in elucidating metastatic biology and underscoring the critical need to include matched metastatic samples to fully understand the progression and heterogeneity of PDAC.

Importantly, the CC7 ecotype at the invasive tumor border contains diverse cell types expressing a range of immune-related targetable genes, including pro-tumorigenic components such as M2-like macrophages and Treg cells as well as anti-tumorigenic elements like CD8<sup>+</sup> cytotoxic T cells and M1-like macrophages. This finding, which cannot be fully captured through scRNA-seq alone, highlights the CC7 ecotype as a potential target for immunotherapeutic intervention.

Our findings elucidate context-dependent therapeutic vulnerabilities within the diverse fibroinflammatory, metabolic and immune ecotypes amenable to targeted intervention strategies. The observed interpatient heterogeneity underscores an unmet need for precision medicine approaches, mapping individual tumor ecosystems to tailor therapeutic regimens, potentially achieving more durable responses.

While expanding our understanding of PDAC biology, this study has certain limitations. The 55 μm spatial resolution may not fully capture cellular interaction complexities, although integrating single-cell datasets and advanced machine-learning algorithms partly mitigated this limitation. Although this represents one of the largest ST studies comparing primary and metastatic PDAC, the enrichment trends of certain spatial ecotypes in either primary or metastatic samples did not reach statistical significance. This can be attributed to the inherent sample-to-sample variation and limited sample sizes in the study. Our work focused on the biology of liver and lymph node metastasis; excluding lung and peritoneal metastases limits the generalizability across all PDAC metastatic sites. We also acknowledge that the normal pancreatic tissues, although histologically normal, were obtained near the PDAC region, which can potentially influence gene expression patterns. Furthermore, our metabolic flux analyses are predictions that will need functional validation and lack single-cell resolution to pinpoint specific cell types driving the observed metabolic phenotypes within each ecotype.

Overall, our integrated spatial atlas provides a valuable framework for understanding PDAC heterogeneity, revealing distinctive disease features across the progression continuum. Our findings, corroborated by past literature, may provide important context for future molecular studies. Future studies dissecting the functional roles and distinct spatial ecotypes at single-cell resolution are warranted to develop effective combination strategies targeting diverse tumor ecosystems.

#### **Online content**

Any methods, additional references, Nature Portfolio reporting summaries, source data, extended data, supplementary information, acknowledgements, peer review information; details of author contributions and competing interests; and statements of data and code availability are available at<https://doi.org/10.1038/s41588-024-01914-4>.

#### **References**

- <span id="page-8-0"></span>1. Hosein, A. N., Dougan, S. K., Aguirre, A. J. & Maitra, A. Translational advances in pancreatic ductal adenocarcinoma therapy. *Nat. Cancer* **3**, 272–286 (2022).
- 2. Siegel, R. L., Giaquinto, A. N. & Jemal, A. Cancer statistics, 2024. *CA Cancer J. Clin.* **74**, 12–49 (2024).
- <span id="page-8-1"></span>3. Houg, D. S. & Bijlsma, M. F. The hepatic pre-metastatic niche in pancreatic ductal adenocarcinoma. *Mol. Cancer* **17**, 95 (2018).
- <span id="page-8-2"></span>4. Orth, M. et al. Pancreatic ductal adenocarcinoma: biological hallmarks, current status, and future perspectives of combined modality treatment approaches. *Radiat. Oncol.* **14**, 141 (2019).
- <span id="page-8-3"></span>5. Mofitt, R. A. et al. Virtual microdissection identifies distinct tumor- and stroma-specific subtypes of pancreatic ductal adenocarcinoma. *Nat. Genet.* **47**, 1168–1178 (2015).
- 6. Bailey, P. et al. Genomic analyses identify molecular subtypes of pancreatic cancer. *Nature* **531**, 47–52 (2016).
- 7. Chan-Seng-Yue, M. et al. Transcription phenotypes of pancreatic cancer are driven by genomic events during tumor evolution. *Nat. Genet.* **52**, 231–240 (2020).
- <span id="page-8-10"></span>8. Raghavan, S. et al. Microenvironment drives cell state, plasticity, and drug response in pancreatic cancer. *Cell* **184**, 6119–6137.e26 (2021).
- <span id="page-8-4"></span>9. The Cancer Genome Atlas Research Network et al. The Cancer Genome Atlas pan-cancer analysis project. *Nat. Genet.* **45**, 1113–1120 (2013).
- <span id="page-8-5"></span>10. Yang, J. et al. Integrated genomic and transcriptomic analysis reveals unique characteristics of hepatic metastases and pro-metastatic role of complement C1q in pancreatic ductal adenocarcinoma. *Genome Biol.* **22**, 4 (2021).
- <span id="page-8-6"></span>11. Li, X. & Wang, C. Y. From bulk, single-cell to spatial RNA sequencing. *Int J. Oral. Sci.* **13**, 36 (2021).
- <span id="page-8-7"></span>12. Peng, J. et al. Single-cell RNA-seq highlights intra-tumoral heterogeneity and malignant progression in pancreatic ductal adenocarcinoma. *Cell Res.* **29**, 725–738 (2019).
- 13. Hwang, W. L. et al. Single-nucleus and spatial transcriptome profiling of pancreatic cancer identifies multicellular dynamics associated with neoadjuvant treatment. *Nat. Genet.* **54**, 1178–1191 (2022).
- 14. Zhang, S. et al. Single cell transcriptomic analyses implicate an immunosuppressive tumor microenvironment in pancreatic cancer liver metastasis. *Nat. Commun.* **14**, 5123 (2023).
- <span id="page-8-12"></span>15. Storrs, E. P. et al. High-dimensional deconstruction of pancreatic cancer identifies tumor microenvironmental and developmental stemness features that predict survival. *NPJ Precis. Oncol.* **7**, 105 (2023).
- <span id="page-8-13"></span>16. Cui Zhou, D. et al. Spatially restricted drivers and transitional cell populations cooperate with the microenvironment in untreated and chemo-resistant pancreatic cancer. *Nat. Genet.* **54**, 1390–1405 (2022).
- <span id="page-8-9"></span>17. Chen, K. et al. Single-cell RNA-seq reveals dynamic change in tumor microenvironment during pancreatic ductal adenocarcinoma malignant progression. *EBioMedicine* **66**, 103315 (2021).
- <span id="page-8-11"></span>18. Oh, K. et al. Coordinated single-cell tumor microenvironment dynamics reinforce pancreatic cancer subtype. *Nat. Commun.* **14**, 5226 (2023).
- <span id="page-8-8"></span>19. Wang, Y. et al. Single-cell analysis of pancreatic ductal adenocarcinoma identifies a novel fibroblast subtype associated with poor prognosis but better immunotherapy response. *Cell Discov.* **7**, 36 (2021).

- <span id="page-9-0"></span>20. MacParland, S. A. et al. Single cell RNA sequencing of human liver reveals distinct intrahepatic macrophage populations. *Nat. Commun.* **9**, 4383 (2018).
- <span id="page-9-1"></span>21. Cable, D. M. et al. Robust decomposition of cell type mixtures in spatial transcriptomics. *Nat. Biotechnol.* **40**, 517–526 (2022).
- <span id="page-9-2"></span>22. Abe, Y. et al. A single-cell atlas of non-haematopoietic cells in human lymph nodes and lymphoma reveals a landscape of stromal remodelling. *Nat. Cell Biol.* **24**, 565–578 (2022).
- <span id="page-9-3"></span>23. Bagaev, A. et al. Conserved pan-cancer microenvironment subtypes predict response to immunotherapy. *Cancer Cell* **39**, 845–865.e7 (2021).
- <span id="page-9-4"></span>24. Tanevski, J., Flores, R. O. R., Gabor, A., Schapiro, D. & Saez-Rodriguez, J. Explainable multiview framework for dissecting spatial relationships from highly multiplexed data. *Genome Biol.* **23**, 97 (2022).
- <span id="page-9-5"></span>25. Zhang, T., Ren, Y., Yang, P., Wang, J. & Zhou, H. Cancer-associated fibroblasts in pancreatic ductal adenocarcinoma. *Cell Death Dis.* **13**, 897 (2022).
- <span id="page-9-6"></span>26. Roos-Mattila, M. et al. The possible dual role of Ang-2 in the prognosis of pancreatic cancer. *Sci. Rep.* **13**, 18725 (2023).
- <span id="page-9-7"></span>27. Sorin, M. et al. Single-cell spatial landscapes of the lung tumour immune microenvironment. *Nature* **614**, 548–554 (2023).
- <span id="page-9-8"></span>28. Astuti, Y. et al. Eferocytosis reprograms the tumor microenvironment to promote pancreatic cancer liver metastasis. *Nat. Cancer* **5**, 774–790 (2024).
- <span id="page-9-9"></span>29. Maley, C. C. et al. Classifying the evolutionary and ecological features of neoplasms. *Nat. Rev. Cancer* **17**, 605–619 (2017).
- <span id="page-9-10"></span>30. Lafzi, A. et al. Identifying Spatial Co-occurrence in Healthy and InflAmed tissues (ISCHIA). *Mol. Syst. Biol.* **20**, 98–119 (2024).
- <span id="page-9-11"></span>31. Kalluri, R. The biology and function of fibroblasts in cancer. *Nat. Rev. Cancer* **16**, 582–598 (2016).
- <span id="page-9-12"></span>32. Kahounová, Z. et al. The fibroblast surface markers FAP, anti-fibroblast, and FSP are expressed by cells of epithelial origin and may be altered during epithelial-to-mesenchymal transition. *Cytometry A* **93**, 941–951 (2018).
- <span id="page-9-13"></span>33. Carpenter, E. S. et al. Analysis of donor pancreata defines the transcriptomic signature and microenvironment of early neoplastic lesions. *Cancer Discov.* **13**, 1324–1345 (2023).
- <span id="page-9-14"></span>34. Cannon, A. et al. Desmoplasia in pancreatic ductal adenocarcinoma: insight into pathological function and therapeutic potential. *Genes Cancer* **9**, 78–86 (2018).
- <span id="page-9-15"></span>35. Chen, S. et al. Hypoxia induces TWIST-activated epithelial– mesenchymal transition and proliferation of pancreatic cancer cells in vitro and in nude mice. *Cancer Lett.* **383**, 73–84 (2016).
- 36. Hotz, B. et al. Epithelial to mesenchymal transition: expression of the regulators snail, slug, and twist in pancreatic cancer. *Clin. Cancer Res.* **13**, 4769–4776 (2007).
- 37. Büchler, P. et al. Hypoxia-inducible factor 1 regulates vascular endothelial growth factor expression in human pancreatic cancer. *Pancreas* **26**, 56–64 (2003).
- 38. Pugh, C. W. & Ratclife, P. J. Regulation of angiogenesis by hypoxia: role of the HIF system. *Nat. Med.* **9**, 677–684 (2003).
- 39. Masamune, A. et al. Hypoxia stimulates pancreatic stellate cells to induce fibrosis and angiogenesis in pancreatic cancer. *Am. J. Physiol. Gastrointest. Liver Physiol.* **295**, G709–G717 (2008).
- 40. Galmiche, A., Rak, J., Roumenina, L. T. & Saidak, Z. Coagulome and the tumor microenvironment: an actionable interplay. *Trends Cancer* **8**, 369–383 (2022).
- 41. Puram, S. V. et al. Single-cell transcriptomic analysis of primary and metastatic tumor ecosystems in head and neck cancer. *Cell* **171**, 1611–1624.e24 (2017).
- <span id="page-9-16"></span>42. Terry, S. et al. Acquisition of tumor cell phenotypic diversity along the EMT spectrum under hypoxic pressure: consequences on susceptibility to cell-mediated cytotoxicity. *Oncoimmunology* **6**, e1271858 (2017).

- <span id="page-9-17"></span>43. Grimshaw, M. J. & Balkwill, F. R. Inhibition of monocyte and macrophage chemotaxis by hypoxia and inflammation a potential mechanism. *Eur. J. Immunol.* **31**, 480–489 (2001).
- 44. Clambey, E. T. et al. Hypoxia-inducible factor-1 alpha-dependent induction of FoxP3 drives regulatory T-cell abundance and function during inflammatory hypoxia of the mucosa. *Proc. Natl Acad. Sci. USA* **109**, E2784–E2793 (2012).
- 45. Facciabene, A. et al. Tumour hypoxia promotes tolerance and angiogenesis via CCL28 and Treg cells. *Nature* **475**, 226–230 (2011).
- 46. Doedens, A. L. et al. Macrophage expression of hypoxia-inducible factor-1α suppresses T-cell function and promotes tumor progression. *Cancer Res.* **70**, 7465–7475 (2010).
- 47. Emami Nejad, A. et al. The role of hypoxia in the tumor microenvironment and development of cancer stem cell: a novel approach to developing treatment. *Cancer Cell Int.* **21**, 62 (2021).
- 48. Imtiyaz, H. Z. et al. Hypoxia-inducible factor 2α regulates macrophage function in mouse models of acute and tumor inflammation. *J. Clin. Invest.* **120**, 2699–2714 (2010).
- <span id="page-9-18"></span>49. Taki, M. et al. Tumor immune microenvironment during epithelial– mesenchymal transition. *Clin. Cancer Res.* **27**, 4669–4679 (2021).
- <span id="page-9-19"></span>50. Dvorak, H. F. Tumors: wounds that do not heal—a historical perspective with a focus on the fundamental roles of increased vascular permeability and clotting. *Semin. Thromb. Hemost.* **45**, 576–592 (2019).
- <span id="page-9-20"></span>51. Nia, H. T., Munn, L. L. & Jain, R. K. Physical traits of cancer. *Science* **370**, eaaz0868 (2020).
- <span id="page-9-21"></span>52. Torphy, R. J. et al. Stromal content is correlated with tissue site, contrast retention, and survival in pancreatic adenocarcinoma. *JCO Precis. Oncol.* **2**, PO.17.00121 (2018).
- <span id="page-9-22"></span>53. Hoxhaj, G. & Manning, B. D. The PI3K–AKT network at the interface of oncogenic signalling and cancer metabolism. *Nat. Rev. Cancer* **20**, 74–88 (2020).
- 54. Stine, Z. E., Walton, Z. E., Altman, B. J., Hsieh, A. L. & Dang, C. V. MYC, metabolism, and cancer. *Cancer Discov.* **5**, 1024–1039 (2015).
- 55. West, M. J., Stoneley, M. & Willis, A. E. Translational induction of the c-*myc* oncogene via activation of the FRAP/TOR signalling pathway. *Oncogene* **17**, 769–780 (1998).
- 56. Welcker, M. et al. The Fbw7 tumor suppressor regulates glycogen synthase kinase 3 phosphorylation-dependent c-Myc protein degradation. *Proc. Natl Acad. Sci. USA* **101**, 9085–9090 (2004).
- 57. Gregory, M. A., Qi, Y. & Hann, S. R. Phosphorylation by glycogen synthase kinase-3 controls c-myc proteolysis and subnuclear localization. *J. Biol. Chem.* **278**, 51606–51612 (2003).
- 58. Sears, R. et al. Multiple Ras-dependent phosphorylation pathways regulate Myc protein stability. *Genes Dev.* **14**, 2501–2514 (2000).
- <span id="page-9-23"></span>59. Bouchard, C., Marquardt, J., Bras, A., Medema, R. H. & Eilers, M. Myc-induced proliferation and transformation require Akt-mediated phosphorylation of FoxO proteins. *EMBO J.* **23**, 2830–2840 (2004).
- <span id="page-9-24"></span>60. Chang, C. H. et al. Metabolic competition in the tumor microenvironment is a driver of cancer progression. *Cell* **162**, 1229–1241 (2015).
- <span id="page-9-25"></span>61. Jian, S. L. et al. Glycolysis regulates the expansion of myeloidderived suppressor cells in tumor-bearing hosts through prevention of ROS-mediated apoptosis. *Cell Death Dis.* **8**, e2779 (2017).
- <span id="page-9-26"></span>62. Alghamdi, N. et al. A graph neural network model to estimate cell-wise metabolic flux using single-cell RNA-seq data. *Genome Res.* **31**, 1867–1884 (2021).
- <span id="page-9-27"></span>63. Jin, L. & Zhou, Y. Crucial role of the pentose phosphate pathway in malignant tumors. *Oncol. Lett.* **17**, 4213–4221 (2019).
- <span id="page-9-28"></span>64. Sonveaux, P. et al. Targeting lactate-fueled respiration selectively kills hypoxic tumor cells in mice. *J. Clin. Invest.* **118**, 3930–3942 (2008).

- <span id="page-10-0"></span>65. Lyssiotis, C. A., Son, J., Cantley, L. C. & Kimmelman, A. C. Pancreatic cancers rely on a novel glutamine metabolism pathway to maintain redox balance. *Cell Cycle* **12**, 1987–1988 (2013).
- <span id="page-10-1"></span>66. Lyssiotis, C. A. & Kimmelman, A. C. Metabolic Interactions in the tumor microenvironment. *Trends Cell Biol.* **27**, 863–875 (2017).
- <span id="page-10-2"></span>67. Saito, K. et al. PODXL1 promotes metastasis of the pancreatic ductal adenocarcinoma by activating the C5aR/C5a axis from the tumor microenvironment. *Neoplasia* **21**, 1121–1132 (2019).
- <span id="page-10-3"></span>68. Ino, Y. et al. Immune cell infiltration as an indicator of the immune microenvironment of pancreatic cancer. *Br. J. Cancer* **108**, 914–923 (2013).
- <span id="page-10-4"></span>69. Chan, H. L. & Zhang, X. H. Node foretold: cancer cells in lymph node rewire the immune system to enable further metastases. *Cancer Cell* **40**, 812–814 (2022).
- <span id="page-10-5"></span>70. Yu, J. et al. Liver metastasis restrains immunotherapy eficacy via macrophage-mediated T cell elimination. *Nat. Med.* **27**, 152–164 (2021).
- <span id="page-10-6"></span>71. Grünwald, B. T. et al. Spatially confined sub-tumor microenvironments in pancreatic cancer. *Cell* **184**, 5577–5592.e18 (2021).

- <span id="page-10-7"></span>72. Wang, Z. et al. Glycolysis and oxidative phosphorylation play critical roles in natural killer cell receptor-mediated natural killer cell functions. *Front. Immunol.* **11**, 202 (2020).
- <span id="page-10-8"></span>73. Yang, J. et al. IRAK2-NF-κB signaling promotes glycolysis-dependent tumor growth in pancreatic cancer. *Cell. Oncol. (Dordr.)* **45**, 367–379 (2022).

**Publisher's note** Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional afiliations.

Springer Nature or its licensor (e.g. a society or other partner) holds exclusive rights to this article under a publishing agreement with the author(s) or other rightsholder(s); author self-archiving of the accepted manuscript version of this article is solely governed by the terms of such publishing agreement and applicable law.

© The Author(s), under exclusive licence to Springer Nature America, Inc. 2024

#### **Methods**

#### **Ethics**

We identified a retrospective cohort of PDAC patients who underwent surgical resection of primary tumor, adjacent lymph nodes and liver metastasis. Many of these patients presented with bleeding or obstruction that warranted surgical resection. The study was approved by the Indiana University Institutional Review Board (no. 18266) committee. The study adhered to the code of conduct for the responsible use of human tissue, meeting all criteria. Informed consent was waived by the Institutional Review Board.

#### **Histomorphological annotation**

Each sample was annotated by a board-certified gastrointestinal pathologist (O.S.) to ensure a thorough examination. Each region was annotated as a normal region, tumor region or stromal region within each sample.

#### **ST analysis**

**Visium spatial tissue optimization protocol.** Visium spatial gene expression data for formalin-fixed, paraffin-embedded tissue were obtained following protocols CG000408, CG000409 and CG000407 provided by 10× Genomics for tissue preparation and library construction[74](#page-12-0)[–76.](#page-13-0) The tissues were then deparaffinized, stained and decrosslinked. Next, version 1 human whole transcriptome probe panels were added to the deparaffinized, stained and decrosslinked tissues. After hybridization, the probes were ligated, and the ligation products were released from the tissue upon RNase treatment and permeabilization. The ligated probe products were captured by spatially barcoded oligonucleotides, and the probes were extended. Libraries were generated from the extended probes. The quantity and quality of each resulting library were assessed with a Qubit and Agilent TapeStatio[n77.](#page-13-1) The final libraries were sequenced on Illumina NovaSeq 6000 28-bp reads, including spatial barcode and unique molecular identifier (UMI) sequences, and 50-bp probe reads were generated[78](#page-13-2).

#### **Sequence alignment and data processing**

**Demultiplexing, sample alignment, UMI and gene count matrix generation.** Gene expression alignment and quantification were performed using the Space Ranger software suite (v.2.0.0)[79.](#page-13-3) First, the reads were assigned spatial barcodes through demultiplexing. Then, the Space Ranger mkfastq() function was used to convert the BCL files to FASTQ format while also filtering out low-quality reads. The sequencing data were mapped to the human reference genome (GRCh38) using the Space Ranger count module, with GENCODE v.32 serving as the gene annotation reference (Supplementary Table 6). The output matrix included UMI tallies and gene expression tallies for every spatially barcoded spot, which represented tissue regions with a diameter of 55 μm and a center-to-center spacing of 100 μm.

#### **Quality control and filtering**

SpotClean (v.1.0.1) was used to adjust for spot swapping on each sampl[e80](#page-13-4). Spot swapping adjustment was carried out by applying the spotclean() function to the slide object, setting the maximum number of iterations to ten and the candidate neighborhood radius to 20. This returned a decontaminated slide object with adjusted gene expression values and updated metadata containing SpotClean's model parameter estimates and per-spot contamination rate measurements. The level of ambient RNA contamination before adjustment was also assessed using the arcScore() function. The adjusted slide object was then converted into a Seurat-compatible spatial object using the convertToSeurat() function.

Before performing downstream analysis, spots exhibiting poor quality, defined as having fewer than 200 identified genes and UMIs, were systematically eliminated. Seurat v.4 software was used to perform subsequent spot filtering[81](#page-13-5). The PercentageFeatureSet() function was used to eliminate artefacts such as mitochondrial, hemoglobin, empty droplet barcode, ribosomal, heat shock and dissociation genes[82](#page-13-6). Hence, high-fidelity spots were successfully preserved through a multistep cleaning process.

#### **Cell-type deconvolution**

**scRNA-seq reference datasets.** We incorporated multiple scRNA-seq datasets from previous publications on PDAC[12](#page-8-7), PDAC and metastatic sample[s8](#page-8-10) and normal live[r20.](#page-9-0) The scRNA-seq data were analyzed using the Seurat framework. Cells with <300 detected genes and >15% mitochondrial read counts were filtered out using the PercentageFeature-Set() function. Additionally, cells exhibiting ribosomal gene expression, estimated through the PercentageFeatureSet() function, were excluded from downstream analyses. Potential multiplets were addressed using DoubletFinder (v.2.0.2), and cells expressing hemoglobin and curated dissociation genes were filtered out[82](#page-13-6)[,83.](#page-13-7) Subsequently, data normalization and scaling were conducted using the NormalizeData() and ScaleData() functions. After filtering low-quality cells, highly variable genes were selected using the FindVariableFeatures() function with a variance-stabilizing transformation approach. Batch correction was implemented using canonical correlation analysis (IntegrateData() function). Dimensionality reduction, achieved through principal component analysis (PCA) (RunPCA() function, PC = 30) and *t*-distributed stochastic neighbor embedding (RunTSNE() function) along with graph-based clustering (FindNeighbors()/FindClusters() functions using the Louvain algorithm at an optimal resolution) facilitated unbiased identification of transcriptionally distinct subsets. An iterative clustering strategy based on known markers was pursued for finer resolution. Differential gene expression analysis, using the Seurat FindAllMarkers() functions, was extensively leveraged for cell-type annotation at fine-grained resolution, guided by published signatures and manual gene marker inspection (Supplementary Data 4[\)12](#page-8-7)[,15,](#page-8-12)[16](#page-8-13)[,84](#page-13-8).

#### **ST analysis**

The cell-type compositions for each spot were determined using the RCTD algorithm within the Spacexr computational framework (v.2.2.0) in R[21](#page-9-1). An RCTD object was constructed from the ST data along with the annotated data described above to reference scRNA-seq profiles encompassing 15 cell states. RCTD modeling was executed in fullmode() to infer per-spot fractions of each cellular phenotype, resulting in a matrix of abundance weights. These estimates were normalized such that the enumerated proportions for every spot were summed to unity.

#### **Spatial map of cell dependencies in pancreatic cancer**

We used the MISTy implementation in mistyR (v.1.9.1) to estimate the predictive importance of the abundance of each major cell type in explaining the abundance of other cell types[24.](#page-9-4) Multiview modeling with three distinct spatial contexts was performed: an intra-spot intrinsic view, measuring co-localized deconvolution relationships; a juxta view, summing immediate neighbor abundances (radius, five spots); and a para view, weighting more distant neighbor abundances (radius, 15 spots) to capture short-range and long-range interactions. MISTy was run on default parameters, and the median standardized importance across samples was aggregated for each view and cell‒cell pairing as a measure of spatial interdependence.

#### **Identification of cellular networks (spatial ecotypes) in ST data**

To identify compositional cluster ecotypes, we applied the ISCHIA (Identifying Spatial Co-occurrence in Healthy and InflAmed tissues; v.1.0.0.0) algorithm implemented in [R30.](#page-9-10) The optimal number of clusters (*k*) was determined to be ten, using the elbow method on the mean cluster variance plot over a range of *k* from 2–20 (Composition. cluster.k()). PCA was used for dimensionality reduction before inputting Visium data into ISCHIA. The Composition.cluster() function was then applied to the ten PCA dimensions of the 91,496 gene expression spots. This function grouped the spots into ten distinct clusters, each representing a unique cellular composition. These clusters, or 'spatial ecotypes', were identified based on the principle that functionally related cell types tend to co-occur in specific spatial patterns within the TME. Differential gene expression analysis between ecotypes was conducted using the FindAllMarkers() function.

#### **Functional enrichment and pathway analysis**

Pathway analysis using gene set enrichment analysis (GSEA) was performed on the ecotypes using predefined gene sets to determine the enrichment of specific biological pathways within each ecotype, using the Kolmogorov‒Smirnov test[85.](#page-13-9) GSEA was implemented using the enrichIt() function from the escapeR package (v.1.12.0) in [R86](#page-13-10). GSEA was performed on TMEs using transcriptomic-based functional gene expression signatures sourced from a previous publicatio[n23](#page-9-3) on spatial ecotypes, using default parameters. We used single-sample GSEA at the feature leve[l87](#page-13-11). This involved applying single-sample GSEA to the expression data of individual spatial features, using gene sets from the hallmark collection to generate feature enrichment scores[87.](#page-13-11) Subsequently, Wilcoxon rank-sum tests were performed for each CC, and the genes were subjected to preranked GSEA against the hallmark gene sets.

#### **Spatial trajectory inference**

We conducted spatial trajectory analysis using stLearn software (v.0.4.8) in Python (v.3.10.5[\)88.](#page-13-12) The analysis involved using the pseudotime–space method at the global level through the st.spatial.trajectory. pseudotimespace\_global() function. Additionally, we applied Louvain clustering across the spatial object to reconstruct the spatial trajectory between the ecotypes.

#### **Estimation of spotwise metabolic flux**

To estimate spotwise metabolic flux, we used the single-cell flux estimation analysis neural network model on our spatial transcriptomic data[62](#page-9-26). The ST data underwent imputation, and the model predicted flux with observed metabolic imbalances under perturbed conditions. The spotwise flux estimates were averaged to the CCs for the estimates.

#### **Visualization and statistical analysis**

For each spatial ecotype, scaled median cell-type compositions were determined using a one-sided Wilcoxon rank-sum test, with adjustments for multiple comparisons (adj. *P* < 0.05) (Fig. [2b](#page-3-0)). Relative abundances were computed by dividing the total number of spots per condition by the number of spots per CC (Fig. [3a](#page-4-0)). All reported *P* values from multiple comparison tests were subjected to correction using the Benjamini–Hochberg method. Schematic pathways and representations were created using [BioRender](https://www.biorender.com).

#### **Immunohistochemistry**

Tissue samples were fixed in 4% formalin for 24 h at 21–25 °C (room temperature) and embedded in paraffin. Immunohistochemistry was performed using a Dako Omnis automated stainer (Agilent Technologies). Antigen retrieval was performed at high pH. The Envision FLEX+ detection system (Agilent Technologies) was used for all antibodies. The following antibodies and protocols were used: anti-CD4 (clone 4B12, Dako IR082, ready-to-use), anti-CD8 (clone C8/144B, Dako GA623, ready-to-use), anti-CD68 (clone KP1, Dako GA609, ready-to-use) and anti-CD163 (clone 10D6, Leica NCL-L-CD163, 1:100). Primary antibody incubation times were 30 min for CD4, 25 min for CD8 and 20 min for CD68 and CD163. Mouse Link was applied for 10 min for CD4, CD8 and CD163. Horseradish peroxidase was applied for 20 min, followed by 3,3'-diaminobenzidine (DAB) for 5 min for all antibodies. All Dako antibodies were used at their ready-to-use concentrations. The Leica CD163 antibody was diluted 1:100 in Dako antibody diluent (Agilent Technologies). Negative controls were performed by omitting the primary antibody and replacing it with non-immune serum. Slides were counterstained with hematoxylin, dehydrated and mounted with a permanent mounting medium.

#### **Visualization, statistics and reproducibility**

In data represented as box plots (Fig. [3d,](#page-4-0) Extended Data Fig. 3e and Supplementary Figs. 2, 3 and 4), the middle line corresponds to the median, the lower and upper hinges describe the first and third quartiles, the upper whisker extends from the hinge to the largest value no further than 1.5× the inter-quartile range from the hinge and the lower whisker extends from the hinge to the smallest value, at most 1.5× the inter-quartile range of the hinge. Data beyond the end of the whiskers are outlying points that are plotted individually. Statistical significance was determined using two-sided unpaired *t*-tests for multiple comparisons. *P* values are indicated by asterisks (ns, *P* > 0.05; \**P* ≤ 0.05; \*\**P* ≤ 0.01; \*\*\**P* ≤ 0.001; \*\*\*\**P* ≤ 0.0001). Comparisons were made between CC1 and CC2, CC1 and CC3, CC1 and CC5, CC2 and CC3, CC2 and CC5, and CC3 and CC5. The H&E micrographs (Figs. [1b](#page-1-0), [2f](#page-3-0) and [5a;](#page-6-0) Extended Data Figs. 1b, 3c and 6a; and Supplementary Figs. 1a,b and 5) and immunohistochemistry images (Fig. [5d](#page-6-0) and Supplementary Fig. 5) are representative of experiments performed on matched primary and metastatic PDAC samples from a cohort of 13 individual patients. ST experiments (Figs. [1c–e,](#page-1-0) [2b–e](#page-3-0) and [3b–d\)](#page-4-0) were performed on samples from these 13 individual patients. The *x* axis in relevant figures represents CCs, while the *y* axis represents cell-type proportions or other relevant measures as indicated in individual figure legends. Several figures contain panels created using [BioRender.](https://www.biorender.com) Overall, no statistical method was used to predetermine sample size. No data were excluded from the analyses. The experiments were not randomized. The investigators were not blinded to allocation during experiments and outcome assessment.

#### **Reporting summary**

Further information on research design is available in the Nature Portfolio Reporting Summary linked to this article.

#### **Data availability**

The data related to the ST and scRNA-seq analyses, including quality control, merging, doublet removal, cell annotation and downstream analysis, are available at<https://zenodo.org/records/10712047>(ref. [89](#page-13-13)). The ST data generated for the study have been deposited in the Gene Expression Omnibus (GEO) with accession number [GSE272362](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE272362). All other essential data supporting the pivotal findings of this study are provided within the article and its Supplementary Information.

#### **Code availability**

Standard and default parameters were used for all tools used in this study. All codes have been deposited in GitHub. The data, codes, quality control metrics, results of analysis and gastrointestinal pathology annotations by a board-certified gastrointestinal pathologist (O.S.) relevant to the content of this manuscript can be accessed through the GitHub repository of scRNA-seq data and spatial data at [https://](https://github.com/Masood-Lab/PDAC_Mets) [github.com/Masood-Lab/PDAC\\_Mets.](https://github.com/Masood-Lab/PDAC_Mets)

#### **References**

- <span id="page-12-0"></span>74. 10× Genomics. *Visium Spatial Gene Expression for FFPE— Deparafinization, H&E Staining, Imaging & Decrosslinking* [https://cdn.10xgenomics.com/image/upload/v1660261285/](https://cdn.10xgenomics.com/image/upload/v1660261285/support-documents/CG000409_Demonstrated_Protocol_VisiumSpatialFFPE_Deparaffin_H_E_RevC.pdf) [support-documents/CG000409\\_Demonstrated\\_Protocol\\_](https://cdn.10xgenomics.com/image/upload/v1660261285/support-documents/CG000409_Demonstrated_Protocol_VisiumSpatialFFPE_Deparaffin_H_E_RevC.pdf) [VisiumSpatialFFPE\\_Deparafin\\_H\\_E\\_RevC.pdf](https://cdn.10xgenomics.com/image/upload/v1660261285/support-documents/CG000409_Demonstrated_Protocol_VisiumSpatialFFPE_Deparaffin_H_E_RevC.pdf) (10× Genomics, 2022).
- 75. 10× Genomics. *Visium Spatial Gene Expression Reagent Kits for FFPE: CG000407* [https://assets.ctfassets.net/an68im79xiti/](https://assets.ctfassets.net/an68im79xiti/53n8zLAfJlm9oGzwIAU2fr/8f84ed7918a508220a82a75296ef2bc5/CG000407_VisiumSpatialGeneExpressionforFFPE_UserGuide_RevA.pdf) [53n8zLAfJlm9oGzwIAU2fr/8f84ed7918a508220a82a75296ef2bc5/](https://assets.ctfassets.net/an68im79xiti/53n8zLAfJlm9oGzwIAU2fr/8f84ed7918a508220a82a75296ef2bc5/CG000407_VisiumSpatialGeneExpressionforFFPE_UserGuide_RevA.pdf) [CG000407\\_VisiumSpatialGeneExpressionforFFPE\\_UserGuide\\_](https://assets.ctfassets.net/an68im79xiti/53n8zLAfJlm9oGzwIAU2fr/8f84ed7918a508220a82a75296ef2bc5/CG000407_VisiumSpatialGeneExpressionforFFPE_UserGuide_RevA.pdf) [RevA.pdf](https://assets.ctfassets.net/an68im79xiti/53n8zLAfJlm9oGzwIAU2fr/8f84ed7918a508220a82a75296ef2bc5/CG000407_VisiumSpatialGeneExpressionforFFPE_UserGuide_RevA.pdf) (10× Genomics, 2021).

- <span id="page-13-0"></span>76. 10× Genomics. *Visium Spatial Gene Expression for FFPE—Tissue Preparation Guide: CG000408* [https://assets.ctfassets.net/](https://assets.ctfassets.net/an68im79xiti/64u9VJe7gIipxyHyafGFa7/6de9a14826ba25dd08469c468ddf8208/CG000408_Demonstrated_Protocol_VisiumSpatialProtocolsFFPE_TissuePreparationGuide_RevA.pdf) [an68im79xiti/64u9VJe7gIipxyHyafGFa7/6de9a14826ba25d](https://assets.ctfassets.net/an68im79xiti/64u9VJe7gIipxyHyafGFa7/6de9a14826ba25dd08469c468ddf8208/CG000408_Demonstrated_Protocol_VisiumSpatialProtocolsFFPE_TissuePreparationGuide_RevA.pdf) [d08469c468ddf8208/CG000408\\_Demonstrated\\_Protocol\\_](https://assets.ctfassets.net/an68im79xiti/64u9VJe7gIipxyHyafGFa7/6de9a14826ba25dd08469c468ddf8208/CG000408_Demonstrated_Protocol_VisiumSpatialProtocolsFFPE_TissuePreparationGuide_RevA.pdf) [VisiumSpatialProtocolsFFPE\\_TissuePreparationGuide\\_RevA.pdf](https://assets.ctfassets.net/an68im79xiti/64u9VJe7gIipxyHyafGFa7/6de9a14826ba25dd08469c468ddf8208/CG000408_Demonstrated_Protocol_VisiumSpatialProtocolsFFPE_TissuePreparationGuide_RevA.pdf) (10× Genomics, 2021).
- <span id="page-13-1"></span>77. Guettouche, T. *Genomic DNA Analysis with the Agilent 2200 TapeStation System and Agilent Genomic DNA ScreenTape* <https://www.agilent.com/library/applications/5991-3427EN.pdf> (Agilent Technologies, 2016).
- <span id="page-13-2"></span>78. Modi, A., Vai, S., Caramelli, D. & Lari, M. The Illumina sequencing protocol and the NovaSeq 6000 system. *Methods Mol. Biol.* **2242**, 15–42 (2021).
- <span id="page-13-3"></span>79. 10× Genomics. *What is Space Ranger?* [https://www.10xgenomics.](https://www.10xgenomics.com/support/software/space-ranger/latest/getting-started/what-is-space-ranger) [com/support/software/space-ranger/latest/getting-started/](https://www.10xgenomics.com/support/software/space-ranger/latest/getting-started/what-is-space-ranger) [what-is-space-ranger](https://www.10xgenomics.com/support/software/space-ranger/latest/getting-started/what-is-space-ranger) (10× Genomics, 2024).
- <span id="page-13-4"></span>80. Ni, Z. et al. SpotClean adjusts for spot swapping in spatial transcriptomics data. *Nat. Commun.* **13**, 2971 (2022).
- <span id="page-13-5"></span>81. Hao, Y. et al. Integrated analysis of multimodal single-cell data. *Cell* **184**, 3573–3587.e29 (2021).
- <span id="page-13-6"></span>82. Xue, R. et al. Liver tumour immune microenvironment subtypes and neutrophil heterogeneity. *Nature* **612**, 141–147 (2022).
- <span id="page-13-7"></span>83. McGinnis, C. S., Murrow, L. M. & Gartner, Z. J. DoubletFinder: doublet detection in single-cell RNA sequencing data using artificial nearest neighbors. *Cell Syst.* **8**, 329–337.e4 (2019).
- <span id="page-13-8"></span>84. Khaliq, A. M. et al. Refining colorectal cancer classification and clinical stratification through a single-cell atlas. *Genome Biol.* **23**, 113 (2022).
- <span id="page-13-9"></span>85. Mootha, V. K. et al. PGC-1α-responsive genes involved in oxidative phosphorylation are coordinately downregulated in human diabetes. *Nat. Genet.* **34**, 267–273 (2003).
- <span id="page-13-10"></span>86. Borcherding, N. et al. Mapping the immune environment in clear cell renal carcinoma by single-cell genomics. *Commun. Biol.***4**, 122 (2021).
- <span id="page-13-11"></span>87. Subramanian, A. et al. Gene set enrichment analysis: a knowledgebased approach for interpreting genome-wide expression profiles. *Proc. Natl Acad. Sci. USA* **102**, 15545–15550 (2005).
- <span id="page-13-12"></span>88. Pham, D. et al. Robust mapping of spatiotemporal trajectories and cell–cell interactions in healthy and diseased tissues. *Nat. Commun.* **14**, 7739 (2023).
- <span id="page-13-13"></span>89. Khaliq, A. M. Spatially resolved transcriptomics atlas of matched primary and metastatic pancreatic cancer reveal principles of ecological adaptation [data set]. *Zenodo* [https://doi.org/10.5281/](https://doi.org/10.5281/zenodo.10712047) [zenodo.10712047](https://doi.org/10.5281/zenodo.10712047) (2024).

#### **Acknowledgements**

Sequencing analysis was carried out at the Center for Medical Genomics at Indiana University School of Medicine, which is partially supported by the Indiana University Grand Challenges Precision Health Initiative. Funded by Indiana University start-up package for A.M. (Masood Lab). We acknowledge the Research Technologies division of University Information Technology Services at Indiana University for providing high-performance computing resources critical for the data analysis.

#### **Author contributions**

A.M. conceived and supervised the study, conducted the data analysis and mentorship and wrote the manuscript. A.M.K. performed the data analyses, wrote the manuscript and created the figures. B.E. supervised the study and provided mentorship. M.R. conducted the data analysis. K.M. created the figures and helped with the manuscript. S.H. provided bioinformatics expertise. C.Z. carried out the metabolic flux analysis. All other authors contributed to data interpretation and manuscript editing.

#### **Competing interests**

A.M. declares that he served as a consultant for Ipsen. This afiliation poses no conflict of interest regarding the design, execution or interpretation of the data presented in this study. All other authors report no competing interests.

#### **Additional information**

**Extended data** is available for this paper at <https://doi.org/10.1038/s41588-024-01914-4>.

**Supplementary information** The online version contains supplementary material available at <https://doi.org/10.1038/s41588-024-01914-4>.

**Correspondence and requests for materials** should be addressed to Ashiq Masood.

**Peer review information** *Nature Genetics* thanks the anonymous reviewer(s) for their contribution to the peer review of this work.

**Reprints and permissions information** is available at [www.nature.com/reprints](http://www.nature.com/reprints).

![](_page_14_Figure_2.jpeg)

**Extended Data Fig. 1 | Computational workflow of scRNA-Seq data analysis and spatially resolved Transcriptomics. a**, Computational workflow of scRNA-seq and ST-seq data. **b**, H&E micrographs of NP, HM, LN and PT, with deconvolution results and enrichment scores of granular cell types. **c**, Barplots

depicting cell-type deconvolution in each sample. H&E = Hematoxylin & Eosin; NP = Normal Pancreas; PT = Pancreatic Tumor; HM = Hepatic Metastasis with adjacent normal liver; LN = Lymph Node metastasis with adjacent normal lymph node.

![](_page_15_Figure_2.jpeg)

**Extended Data Fig. 2 | Details of MISTy Results, Spatial Ecotype Analysis. a**, Barplots showing the relative contribution of view (Intraview, Juxtaview and Paraview) to the prediction of the cell-types. **b**, Heatmap shows the median standardized importance ( > 0) of cell-type abundances within the spot.

**c**, Barplots showing Spatial Ecotype proportions in each sample. **d**, Heatmap showing the gene set Enrichment scores of Immune and Epithelium cells in each Ecotypes. **e**, Heatmap showing the Gene Set Enrichment scores of various CAFs in each Ecotype.

![](_page_16_Figure_2.jpeg)

#### **Extended Data Fig. 3 | Pathological annotation of Spatial ecotypes.**

**Trajectory Analysis. a**, Sankey plot showing the pattern of spatial ecotype enrichment (compositional clusters; CCs) across different histological subtypes. Bandwidth is proportional to number of spots and Barplots showing Spatial Ecotype proportions in each sample. **b**, Heatmap of Molecular Signatures Database (MSigDB) hallmark gene set collection across ecotypes. **c**, Structural annotations by GI pathologist show dense stroma in CC1 and CC5 ecotypes. **d**, Reconstructing the spatial trajectory between CC1 and CC5 clusters in the

PT sample. **e**, Box plots comparing GSEA scores for Fges, MSigDB gene sets and cell type proportions between CC1, CC2, CC3, and CC5 ecotypes. Data represent n = 9,236, 12,679, 13,276 and 8,147 spots for CC1, CC2, CC3, and CC5 respectively, collected from 13 individual patients. The number of patients contributing to each ecotype varies: CC1 (12 patients), CC2 (12 patients), CC3 (12 patients), and CC5 (13 patients). Each spot represents an independent data point. For details on visualization, statistics and reproducibility, see Methods. PT= Primary tumor; LNM= Lymph node metastasis; HM= Hepatic metastasis; NP= Normal pancreas.

![](_page_17_Figure_3.jpeg)

![](_page_17_Figure_4.jpeg)

**Extended Data Fig. 4 | Flux Perturbation Analysis in Spatial Ecotypes. a, b**, Schematic representation of flux perturbations in CC1 and CC5 ecotype. The color of the flux indicates the relative flux level (Z score) and the width of the flux indicates the exact level of the flux.

![](_page_18_Figure_3.jpeg)

**Extended Data Fig. 5 | Flux Perturbation Analysis in Spatial Ecotypes.** Schematic representation of flux perturbations in CC3 ecotype. The color of the flux indicates the relative flux level (Z score) and the width of the flux indicates the exact level of the flux.

**Tumor Lymphocytes Fibroblasts 50μm** Tumor **50μm Fibroblasts 50μm**

**Extended Data Fig. 6 | Histology annotated CC7 ecotype to show key immune cell types. a**, Structural annotations by GI pathologist in Hepatic Metastasis (HM) sample highlighting the tumor-tissue interface in a spatial 'tug-of-war' between immune defense and malignant progression within the tumor TME. Scale bars,

20 µm for magnified image sections. Black arrows indicate lymphocytes; pink arrows indicate fibroblasts; and a circle indicates tumor cells. **b**, A juxta view that sums the observed deconvolution estimations of immediate neighbors (largest distance threshold = 5).

| Corresponding author(s):                | Ashiq Masood |
|-----------------------------------------|--------------|
| Last updated by author(s): Jul 16, 2024 |              |

# Reporting Summary

Nature Portfolio wishes to improve the reproducibility of the work that we publish. This form provides structure for consistency and transparency in reporting. For further information on Nature Portfolio policies, see our Editorial Policies and the Editorial Policy Checklist.

For all statistical analyses, confirm that the following items are present in the figure legend, table legend, main text, or Methods section.

|  |  | Statistics |
|--|--|------------|

| n/a | Confirmed                                                                                                                                                                                                                                                     |
|-----|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|     | The exact sample size (n) for each experimental group/condition, given as a discrete number and unit of measurement                                                                                                                                           |
|     | A statement on whether measurements were taken from distinct samples or whether the same sample was measured repeatedly                                                                                                                                       |
|     | The statistical test(s) used AND whether they are one- or two-sided<br>Only common tests should be described solely by name; describe more complex techniques in the Methods section.                                                                         |
|     | A description of all covariates tested                                                                                                                                                                                                                        |
|     | A description of any assumptions or corrections, such as tests of normality and adjustment for multiple comparisons                                                                                                                                           |
|     | A full description of the statistical parameters including central tendency (e.g. means) or other basic estimates (e.g. regression coefficient)<br>AND variation (e.g. standard deviation) or associated estimates of uncertainty (e.g. confidence intervals) |
|     | For null hypothesis testing, the test statistic (e.g. F, t, r) with confidence intervals, effect sizes, degrees of freedom and P value noted<br>Give P values as exact values whenever suitable.                                                              |
|     | For Bayesian analysis, information on the choice of priors and Markov chain Monte Carlo settings                                                                                                                                                              |
|     | For hierarchical and complex designs, identification of the appropriate level for tests and full reporting of outcomes                                                                                                                                        |
|     | Estimates of effect sizes (e.g. Cohen's d, Pearson's r), indicating how they were calculated                                                                                                                                                                  |
|     | Our web collection on statistics for biologists contains articles on many of the points above.                                                                                                                                                                |

## Software and code

Policy information about availability of computer code

Data collection Biorender(https://www.biorender.com/); Inkscape (v1.3.2)

Data analysis All software/scripts used in data analysis is described here: https://github.com/Masood-Lab/PDAC\_Mets/tree/main/Data.; https:// zenodo.org/uploads/10712047

Softwares Used: Space Ranger software suite (v2.0.0); SpotClean(1.0.1); Seurat(v4.3.0.1); SpaceXR(v2.2.0); mistyR (v1.9.1); ISCHIA(v1.0.0.0); escapeR package (v1.12.0); stLearn software (version 0.4.8) ;Niche-DE (v0.0.0.9000); scFEA(v1.1);ChEMBL database (v30)

For manuscripts utilizing custom algorithms or software that are central to the research but not yet described in published literature, software must be made available to editors and reviewers. We strongly encourage code deposition in a community repository (e.g. GitHub). See the Nature Portfolio guidelines for submitting code & software for further information.

## Data

Policy information about availability of data

All manuscripts must include a data availability statement. This statement should provide the following information, where applicable:

- Accession codes, unique identifiers, or web links for publicly available datasets
- A description of any restrictions on data availability
- For clinical datasets or third party data, please ensure that the statement adheres to our policy

The data is made available through the github and can be accessed here: https://github.com/Masood-Lab/PDAC\_Mets/tree/main/Data. RAW data is submitted to GEO with accession no : GSE272362 and also uploaded in Zonodo : https://zenodo.org/records/10712047

## Research involving human participants, their data, or biological material

Policy information about studies with human participants or human data. See also policy information about sex, gender (identity/presentation), and sexual orientation and race, ethnicity and racism.

| Reporting on sex and gender                                              | Please see Supplementary table 1 for the clinical characteristics of the patients used in this study. |  |
|--------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------|--|
| Reporting on race, ethnicity, or<br>other socially relevant<br>groupings | Please see Supplementary table 1 for the clinical characteristics of the patients used in this study. |  |
| Population characteristics                                               | Please see Supplementary table 1 for the clinical characteristics of the patients used in this study. |  |
|                                                                          |                                                                                                       |  |
| Recruitment                                                              | All tissue samples were obtained from the IU pathology biorepository after the IRB Approval.          |  |
| Ethics oversight                                                         | IRB Indiana University                                                                                |  |

Note that full information on the approval of the study protocol must also be provided in the manuscript.

## Field-specific reporting

|               |                               | Please select the one below that is the best fit for your research. If you are not sure, read the appropriate sections before making your selection. |
|---------------|-------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------|
| Life sciences | Behavioural & social sciences | Ecological, evolutionary & environmental sciences                                                                                                    |

For a reference copy of the document with all sections, see nature.com/documents/nr-reporting-summary-flat.pdf

## Life sciences study design

All studies must disclose on these points even when the disclosure is negative.

Data exclusions For full details see description in Methods. For spatial transcriptomics experiments, spots were excluded based on their (1) transcript count and (2) gene recovery.

Replication *Describe the measures taken to verify the reproducibility of the experimental findings. If all attempts at replication were successful, confirm this*

*OR if there are any findings that were not replicated or cannot be reproduced, note this and describe why.*

Randomization Randomisation was not relevant due to the study design where human tissues were used on availability

Sample size For an overview on sample please see supplementary table l. No statistical methods were used to predetermine sample size.

Blinding *Describe whether the investigators were blinded to group allocation during data collection and/or analysis. If blinding was not possible, describe why OR explain why blinding was not relevant to your study.*

## Reporting for specific materials, systems and methods

We require information from authors about some types of materials, experimental systems and methods used in many studies. Here, indicate whether each material, system or method listed is relevant to your study. If you are not sure if a list item applies to your research, read the appropriate section before selecting a response.

| ₻         |
|-----------|
| ≂         |
| $\simeq$  |
| ≘         |
|           |
| N,        |
| $^{\sim}$ |
| ベ         |
|           |
| ч         |
|           |

| Materials & experimental systems |                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |  | Methods                      |
|----------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--|------------------------------|
| n/a                              | Involved in the study                                                                                                                                                                                                                                                                                                                                                                                                                                                         |  | n/a<br>Involved in the study |
|                                  | Antibodies                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |  | ChIP-seq                     |
|                                  | Eukaryotic cell lines                                                                                                                                                                                                                                                                                                                                                                                                                                                         |  | Flow cytometry               |
|                                  | Palaeontology and archaeology                                                                                                                                                                                                                                                                                                                                                                                                                                                 |  | MRI-based neuroimaging       |
|                                  | Animals and other organisms                                                                                                                                                                                                                                                                                                                                                                                                                                                   |  |                              |
|                                  | Clinical data                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |  |                              |
|                                  | Dual use research of concern                                                                                                                                                                                                                                                                                                                                                                                                                                                  |  |                              |
|                                  | Plants                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |  |                              |
|                                  |                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |  |                              |
| Antibodies                       |                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |  |                              |
|                                  | Antibodies used<br>Anti-CD4 (clone 4B12, Dako IR082, ready-to-use)<br>Anti-CD8 (clone C8/144B, Dako GA623, ready-to-use)<br>Anti-CD68 (clone KP1, Dako GA609, ready-to-use)<br>Anti-CD163 (clone 10D6, Leica NCL-L-CD163, diluted 1:100)<br>Usage details:<br>CD4, CD8, and CD68 antibodies were used at their ready-to-use (RTU) concentrations as supplied by the manufacturer.<br>The CD163 antibody was diluted 1:100 using Dako antibody diluent (Agilent Technologies). |  |                              |

Validation All antibodies are commercially available and have been validated by the manufacturers for immunohistochemistry applications in human tissues.

We performed additional validation steps:

Positive controls: Known positive tissue samples were used to confirm specific staining patterns for each antibody.

Negative controls: Primary antibodies were omitted and replaced with non-immune serum to check for non-specific staining. The diluted CD163 antibody was validated for use in the Dako Omnis system by comparing staining patterns with manufacturerrecommended protocols.

Staining patterns were consistent with expected cellular localization and distribution for each marker.

Lot-to-lot consistency was ensured by using the same lot of antibodies throughout the study when possible.

## Plants

Seed stocks *Report on the source of all seed stocks or other plant material used. If applicable, state the seed stock centre and catalogue number. If plant specimens were collected from the field, describe the collection location, date and sampling procedures.*

Novel plant genotypes *Describe the methods by which all novel plant genotypes were produced. This includes those generated by transgenic approaches, gene editing, chemical/radiation-based mutagenesis and hybridization. For transgenic lines, describe the transformation method, the number of independent lines analyzed and the generation upon which experiments were performed. For gene-edited lines, describe the editor used, the endogenous sequence targeted for editing, the targeting guide RNA sequence (if applicable) and how the editor was applied.*

Authentication *Describe any authentication procedures for each seed stock used or novel genotype generated. Describe any experiments used to assess the effect of a mutation and, where applicable, how potential secondary effects (e.g. second site T-DNA insertions, mosiacism, off-target gene editing) were examined.*