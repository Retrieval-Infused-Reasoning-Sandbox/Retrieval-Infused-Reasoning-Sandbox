![](_page_0_Picture_1.jpeg)

# Extracellular vesicles from the lung pro-thrombotic niche drive cancer-associated thrombosis and metastasis via integrin beta 2

## Graphical abstract

![](_page_0_Figure_4.jpeg)

## Authors

Serena Lucotti, Yusuke Ogitani, Candia M. Kenific, ..., Jacqueline F. Bromberg, Diane M. Simeone, David Lyden

## Correspondence

sel4002@med.cornell.edu (S.L.), bromberj@mskcc.org (J.F.B.), dsimeone@ucsd.edu (D.M.S.), dcl2001@med.cornell.edu (D.L.)

## In brief

Cancer-associated thrombosis is a leading cause of mortality. Lucotti et al. uncover the formation of a prothrombotic niche in the non-metastatic lung microenvironment that promotes thrombosis and metastasis across multiple cancer types via the release of extracellular vesicles carrying integrin b2.

## Highlights

- <sup>d</sup> The lung is a major site for thrombosis generation in cancer patients
- <sup>d</sup> Lung interstitial macrophages produce integrin b<sup>2</sup> <sup>+</sup> small extracellular vesicles (sEVs)
- <sup>d</sup> sEV-b<sup>2</sup> dimerizes with a<sup>x</sup> and interacts with platelet GPIb to induce their aggregation
- <sup>d</sup> Integrin b<sup>2</sup> levels in plasma sEVs predict thrombotic risk in cancer patients

![](_page_0_Picture_16.jpeg)

![](_page_0_Picture_17.jpeg)

![](_page_1_Picture_0.jpeg)

![](_page_1_Picture_1.jpeg)

## Article

# Extracellular vesicles from the lung pro-thrombotic niche drive cancer-associated thrombosis and metastasis via integrin beta 2

Serena Lucotti,1,2,\* Yusuke Ogitani,1,2 Candia M. Kenific,1,2 Jacob Geri,<sup>3</sup> Young Hun Kim,<sup>4</sup> Jinghua Gu,2 Uthra Balaji,<sup>2</sup> Linda Bojmar,1,2,5 Lee Shaashua,1,2 Yi Song,<sup>6</sup> Michele Cioffi,1,2 Pernille Lauritzen,1,2 Oveen M. Joseph,1,2 Tetsuhiko Asao,1,2,7,8 Paul M. Grandgenett,<sup>9</sup> Michael A. Hollingsworth,<sup>9</sup> Christopher Peralta,10 Alexandra E. Pagano,<sup>10</sup> Henrik Molina,<sup>10</sup> Harry B. Lengel,<sup>7</sup> Elizabeth G. Dunne,<sup>7</sup> Xiaohong Jing,<sup>11</sup> Madeleine Schmitter,11 Lucia Borriello,13,14 Thomas Miller,1,2 Haiying Zhang,1,2 Yevgeniy Romin,<sup>4</sup> Katia Manova,<sup>4</sup> Doru Paul,<sup>15</sup>

*(Author list continued on next page)*

*(Affiliations continued on next page)*

### SUMMARY

Cancer is a systemic disease with complications beyond the primary tumor site. Among them, thrombosis is the second leading cause of death in patients with certain cancers (e.g., pancreatic ductal adenocarcinoma [PDAC]) and advanced-stage disease. Here, we demonstrate that pro-thrombotic small extracellular vesicles (sEVs) are secreted by C-X-C motif chemokine 13 (CXCL13)-reprogrammed interstitial macrophages in the non-metastatic lung microenvironment of multiple cancers, a niche that we define as the pro-thrombotic niche (PTN). These sEVs package clustered integrin b<sup>2</sup> that dimerizes with integrin a<sup>X</sup> and interacts with platelet-bound glycoprotein (GP)Ib to induce platelet aggregation. Blocking integrin b<sup>2</sup> decreases both sEV-induced thrombosis and lung metastasis. Importantly, sEV-b<sup>2</sup> levels are elevated in the plasma of PDAC patients prior to thrombotic events compared with patients with no history of thrombosis. We show that lung PTN establishment is a systemic consequence of cancer progression and identify sEV-b<sup>2</sup> as a prognostic biomarker of thrombosis risk as well as a target to prevent thrombosis and metastasis.

### INTRODUCTION

Cancer-associated thrombosis develops, at least in part, via cooperation between tumor cells and platelets. Platelets that aggregate in response to tumor cues (e.g., membrane-bound platelet-adhesion proteins and soluble pro-aggregatory factors) then support metastatic dissemination and growth.1–3This tumor-platelet cooperation creates a self-perpetuating environment that accelerates

![](_page_1_Picture_31.jpeg)

<sup>1</sup>Children's Cancer and Blood Foundation Laboratories, Departments of Pediatrics and Cell and Developmental Biology, Meyer Cancer Center, Weill Cornell Medicine, New York, NY, USA

<sup>2</sup>Drukier Institute for Children's Health and Department of Pediatrics, Weill Cornell Medicine, New York, NY, USA

<sup>3</sup>Department of Pharmacology, Weill Cornell Medicine, New York, NY, USA

<sup>4</sup>Molecular Cytology Core Facility, Memorial Sloan Kettering Cancer Center, New York, NY, USA

<sup>5</sup>Department of Biomedical and Clinical Sciences, Linko¨ ping University, Linko¨ ping, Sweden

<sup>6</sup>Department of Surgery, Memorial Sloan Kettering Cancer Center, New York, NY, USA

<sup>7</sup>Thoracic Surgery Service, Department of Surgery, Memorial Sloan Kettering Cancer Center, New York, NY, USA 8Department of Respiratory Medicine, Juntendo University, Tokyo, Japan

<sup>9</sup>Eppley Institute for Research in Cancer and Allied Diseases, University of Nebraska Medical Center, Omaha, NE, USA

<sup>10</sup>Proteomics Resource Center, The Rockefeller University, New York, NY, USA

<sup>11</sup>Perlmutter Cancer Center, New York University Langone Health, New York, NY, USA

<sup>12</sup>Department of Surgery, UC San Diego Health, San Diego, CA, USA

<sup>13</sup>Department of Cancer and Cellular Biology, Lewis Katz School of Medicine, Temple University, Philadelphia, PA, USA

<sup>14</sup>Fox Chase Cancer Center, Cancer Signaling and Microenvironment Program, Philadelphia, PA, USA

<sup>15</sup>Division of Hematology and Medical Oncology, Department of Medicine, Weill Cornell Medicine, New York, NY, USA

<sup>16</sup>Atossa Therapeutics, Inc., Seattle, WA, USA

<sup>17</sup>Department of Pathology, University Medical Center Utrecht, Utrecht, the Netherlands

<sup>18</sup>Gastrointestinal Oncology Service, Department of Medicine, Memorial Sloan Kettering Cancer Center, New York, NY, USA

<sup>19</sup>Department of Pediatrics, Emory University School of Medicine, Atlanta, GA, USA

![](_page_2_Picture_0.jpeg)

![](_page_2_Picture_1.jpeg)

H. Lawrence Remmel,<sup>1,2,16,17</sup> Eileen M. O'Reilly,<sup>18</sup> William R. Jarnagin,<sup>6</sup> David Kelsen,<sup>18</sup> Sharon M. Castellino,<sup>19,20</sup> Lisa Giulino-Roth,<sup>21</sup> David R. Jones,<sup>7</sup> John S. Condeelis,<sup>22,23,24,25,26,27</sup> Virginia Pascual,<sup>1,2</sup> James B. Bussel,<sup>2,21</sup> Nancy Boudreau,<sup>1,2</sup> Irina Matei,<sup>1,2</sup> David Entenberg,<sup>23,24,25,26,27,28</sup> Jacqueline F. Bromberg,<sup>29,30,\*</sup> Diane M. Simeone,<sup>12,31,\*</sup> and David Lyden<sup>1,2,32,\*</sup>

<sup>20</sup>Aflac Cancer & Blood Disorders Center, Children's Healthcare of Atlanta, Atlanta, GA, USA

https://doi.org/10.1016/j.cell.2025.01.025

disease progression and mortality. The resulting thrombotic complications, especially disseminated intravascular coagulation (DIC) and thromboembolism (TE), are leading causes of cancer-related death.<sup>4-9</sup> DIC is a systemic syndrome associated with deposition of microthrombi in multiple tissues leading to poor perfusion, organ failure, and bleeding due to depletion of clotting factors and platelets. 6,10 As such, DIC often precedes overt thromboembolic events and poor survival. 11,12 DIC is diagnosed in 7%-20% of patients with solid malignancies, although autopsy findings suggest that almost all cancer patients suffer from occult DIC. 9,13,14 Conversely, cancer-associated TE is often clinically overt, with pancreatic ductal adenocarcinoma (PDAC, 12%-36% of patients), lung, and brain malignancies (>10% of patients) posing the highest risk of TE. 15-17 Breast cancer and melanoma have a lower, yet substantial degree of risk (3%-5% of patients). Regardless of cancer type, all advanced-stage cancers are associated with a greater risk of thrombosis, highlighting the link between thrombosis and metastasis.5,18-20 Both symptomatic and clinically occult thrombotic events are associated with shortened survival and higher mortality. 15,16 Additionally, 50% of TE survivors, including those receiving anti-coagulant therapy, develop post-thrombotic syndrome, which includes longer-term infirmity and increased morbidity and mortality.<sup>21</sup> Despite the benefits of thromboprophylaxis in patients with symptomatic thrombosis, including lower risk of developing metastatic disease, 22 diagnosis of sub-clinical DIC and prevention of thrombosis and metastasis remain unmet clinical needs due to the lack of risk-predictive biomarkers or bleeding complications associated with the use of routine anti-coagulants, especially in surgical patients. 21,23,24

Several mechanisms, including mutations in hemostatic factor genes tissue factor (TF) and podoplanin, are linked to increased risk of thrombosis. 17,25–27 Whereas high levels of these factors on tumor cells may account for intra-tumoral thrombosis, their presence on circulating extracellular vesicles (EVs) may explain systemic thrombosis patterns. Ectosomes and small EVs (sEVs), including exosomes and exomeres, mediate cell-to-cell communication and have a therapeutic and predictive value in systemic diseases. TF is preferentially associated with

ectosomes in cancer patient blood. <sup>37–41</sup> However, an association between EV-TF and cancer TE risk in some but not all studies suggests the existence of yet unidentified, TF-independent pathways driving EV-induced thrombosis. <sup>25,42–48</sup> Previous pre-clinical evidence suggests that sEV-mediated coagulation and platelet aggregation were independent of ectosome TF activity, <sup>28,49–52</sup> but their predictive value in cancer-associated thrombosis remains unknown. Moreover, the pro-coagulant profile of EVs from non-cancerous cells in the tumor microenvironment remains an understudied yet clinically important area of investigation.

Here, we demonstrate that sEVs from lung interstitial macrophages (IMs) in non-metastatic and metastatic lungs of tumorbearing mice and cancer patients are key contributors to elevated thrombotic risk, indicating the lung as a major site for initiation of cancer-associated thrombosis. We identify the activated and clustered form of integrin  $\beta_2$  on the surface of sEVs as an initiator of intravascular thrombosis. Selective  $\beta_2$  blockade not only prevents thrombosis but also reduces metastatic disease in pre-clinical models. We show that  $\alpha_X \beta_2$  dimers on lung sEVs from tumorbearing mice and cancer patients interact with platelet glycoprotein (GP)Ib to initiate platelet aggregation. Moreover, we find that, in PDAC patients, elevated β<sub>2</sub> levels in plasma sEVs correlate with subsequent development of TE. Thus, lung-derived, sEV-associated integrin  $\beta_2$  is both a new liquid biopsy analyte for stratification of patients at high risk for thrombosis and a potential target for prevention of thrombosis and metastasis.

### **RESULTS**

# sEVs from metastatic lungs have pro-thrombotic properties

To study the effect of sEVs from different organs on clotting during cancer, sEVs were isolated by ultracentrifugation of conditioned media from tissue explant cultures from PDAC-bearing KPC mice (Kras<sup>Het</sup>) or control littermates (Kras<sup>WT</sup>) (Figures 1A and S1A). Lungs, liver, and pancreas were collected from "stage IV" 18-week-old mice bearing liver metastasis.<sup>53</sup> Following retroorbital injection into naive mice, sEVs from lungs of PDAC-bearing

<sup>&</sup>lt;sup>21</sup>Department of Pediatrics, Division of Hematology/Oncology, Weill Cornell Medicine, New York, NY, USA

<sup>&</sup>lt;sup>22</sup>Department of Surgery, Einstein College of Medicine/Montefiore Medical Center, Bronx, NY, USA

<sup>&</sup>lt;sup>23</sup>Integrated Imaging Program for Cancer Research, Einstein College of Medicine/Montefiore Medical Center, Bronx, NY, USA

<sup>&</sup>lt;sup>24</sup>Montefiore Einstein Comprehensive Cancer Center, Einstein College of Medicine/Montefiore Medical Center, Bronx, NY, USA

<sup>&</sup>lt;sup>25</sup>Gruss-Lipper Biophotonics Center, Einstein College of Medicine/Montefiore Medical Center, Bronx, NY, USA

<sup>&</sup>lt;sup>26</sup>Department of Cell Biology, Einstein College of Medicine/Montefiore Medical Center, Bronx, NY, USA

<sup>&</sup>lt;sup>27</sup>Cancer Dormancy Institute, Einstein College of Medicine/Montefiore Medical Center, Bronx, NY, USA

<sup>&</sup>lt;sup>28</sup>Department of Pathology, Einstein College of Medicine/Montefiore Medical Center, Bronx, NY, USA

<sup>&</sup>lt;sup>29</sup>Department of Medicine, Memorial Sloan Kettering Cancer Center, New York, NY, USA

<sup>&</sup>lt;sup>30</sup>Department of Medicine, Weill Cornell Medicine, New York, NY, USA

<sup>&</sup>lt;sup>31</sup>Moores Cancer Center, UC San Diego Health, San Diego, CA, USA

<sup>32</sup>Lead contact

<sup>\*</sup>Correspondence: sel4002@med.cornell.edu (S.L.), bromberj@mskcc.org (J.F.B.), dsimeone@ucsd.edu (D.M.S.), dcl2001@med.cornell.edu (D.L.)

![](_page_3_Figure_2.jpeg)

Figure 1. sEVs from non-metastatic and metastatic lung tissue induce thrombosis in mice

(A) Diagram of the experimental setup for tissue sEV isolation. Tissues from tumor-bearing or control mice were cultured for 24 h in RPMI, and sEVs were collected by sequential ultracentrifugation of the conditioned medium. 5–10 mg of sEVs were retro-orbitally injected into naive, syngeneic mice to study changes in coagulation parameters. MFP, mammary fat pad; s.c., subcutaneous.

(B and C) Survival curves (B, left, or C, top) and platelet counts (B, right, or C, bottom) in mice injected with sEVs from tumor cells or tissue explants of mice with PDAC (KPC mice or KPC4662 cells in C57BL/6J mice), breast cancer (MMTV-PyMT mice or 4T1 cells in BALB/c mice), or melanoma (B16F10 in C57BL/6J mice). (D) Immunohistochemistry (IHC) staining of lung sections from mice in (A), stained for H&E, platelets (GPIb), and fibrin (phosphotungstic acid-haematoxylin [PTAH]).

(E) Representative confocal images of platelets (DyLight649-labeled anti-GPIbb antibody, magenta) and sEVs from B16F10 metastasis-bearing lungs (NIR815, green) within intravascular clots in the lungs of sEV recipient mice.

![](_page_4_Picture_0.jpeg)

![](_page_4_Picture_1.jpeg)

mice, with or without metastasis (indicated as [non-]metastatic lungs), induced respiratory distress and death of the animals within 5 min. Reduced platelet count (thrombocytopenia, indicative of platelet consumption in thrombi) (Figure 1B) and increased plasma D-dimer levels (representing fibrin deposition; Figure S1B) in mice injected with (non-)metastatic lung sEVs indicated intravascular thrombosis. Notably, sEVs from lungs of tumor-free mice (normal lungs), from normal pancreas or PDAC primary tumors, and from normal or metastasis-bearing livers did not induce clot formation or thrombocytopenia (Figure 1B). In other cancer models, including melanoma (B16F10 cell injection), breast cancer (4T1 cell injection or MMTV-PyMT mice), and experimental PDAC models (tail vein injection of KPC4662 cells<sup>54</sup> or PDAC patient organoids) (Figures 1C and S1C), sEVs from metastasis-bearing lungs similarly induced systemic thrombosis, marked by thrombocytopenia, elevated D-dimer levels, and death (Figures 1C, S1B, and S1C). In contrast, sEVs from normal lungs, primary tumors (melanoma and breast cancer), tumor cell lines (B16F10 and 4T1), and PDAC organoids did not induce thrombosis (Figures 1C and S1C). This effect was observed irrespective of sEV isolation methods (Figures S1D-S1F). To define the type of cancer-associated thrombosis, we injected mice with a platelet-labeling antibody and a sub-lethal amount of labeled pro-thrombotic sEVs from B16F10 metastasis-bearing lungs. We observed nonoccluding microclots (10-20 µm) in organs commonly affected by thrombosis, including liver, brain, heart, and leg muscle, and large occlusive clots (>20  $\mu$ m) in the lungs, possibly formed by microclot accumulation in small pre-capillary beds (Figure S1G). Immunohistochemistry of lungs revealed large fibrin clots containing sEVs within both arterial (endomucin-) and venous (endomucin<sup>+</sup>) vasculature (Figures 1D, 1E, and S1H). Multi-organ microclot formation, thrombocytopenia, fibrin deposition, and elevated D-dimer reflect the clinical picture of DIC. Together, these data suggest that pro-thrombotic niches (PTNs) in lungs of mice harboring different primary tumors are marked by the production of sEVs with autonomous, systemic pro-thrombotic properties.

To understand the kinetics of thrombus formation following sEV injection, we performed intravital microscopy of the lung vasculature. <sup>55</sup> Mice were retro-orbitally injected with labeled dextran for blood visualization and a platelet-labeling antibody, followed by lung sEVs from control or B16F10 metastasis-bearing lungs. Within 20 s of metastatic lung sEV injection, large platelet thrombi developed in the lung vasculature and arrested blood flow within 10 min (Figures 1F and 1G; Video S1). Also,

infusion of pro-thrombotic sEVs caused the accumulation and growth of small "seeding" clots in the pre-capillary beds that blocked blood perfusion in downstream capillary beds within 2 min, consistent with the timing of respiratory failure (Figure S1I). No clots formed in the lung vasculature of mice injected with sEVs from normal lungs (Figures 1F and 1G).

In vitro incubation of platelets with sEVs from (non-)metastatic lungs of PDAC-bearing mice (Figures 1H–1J) or B16F10 metastasis-bearing lungs (Figures S1J–S1L) induced platelet CD62P exposure, reflective of platelet activation, and platelet aggregation. Moreover, platelets actively adhered and formed large clots on the surface of immobilized metastasis-bearing lung sEVs, but not normal lung sEVs (Figures S1M–S1O). Similarly, in vivo injection of a sub-lethal dose of B16F10 metastasis-bearing lung sEVs induced sustained platelet activation within 10 min of injection and concomitant sEV-platelet interaction (Figures 1K–1N). Platelet depletion prior to sEV injection prevented lethal thrombosis and prolonged mouse survival (Figures 1O and 1P), implicating platelets in sEV-induced clotting.

We also observed immune cells in clots induced by lung-derived sEVs, including monocytes/macrophages and T cells (Figures S2A and S2B). However, antibody-mediated depletion of monocytes/macrophages, T and B cells, and neutrophils or inhibition of neutrophil de-granulation (in peptidyl arginine deiminase 4 [PAD4] knockout [KO] mice) prior to pro-thrombotic sEV injection did not prevent thrombosis (Figures S2C and S2D). Thus sEV-induced coagulation relies on platelets but not immune cells.

Collectively, our data show that a PTN forms in both non-metastatic and metastatic lungs of multiple murine cancer models and generates sEVs supporting DIC.

## Integrin $\beta_2$ on sEVs initiates cancer-associated thrombosis

To identify the cargo of pro-thrombotic sEVs, we performed unbiased, quantitative liquid chromatography mass spectrometry (LC-MS) on sEVs from mouse primary tumors, livers, and lungs from the cancer models described in Figures 1B and 1C.  $^{30}$  We observed distinct proteomic profiles, enriched in proteins involved in immune cell responses, in (non-)metastatic lung sEVs compared with normal lung sEVs (Figures 2A, 2B, and S3A–S3D). Integrin  $\beta_2$  was the most significantly enriched protein in pro-thrombotic sEVs in all cancer models tested. CD45/Ptprc was also present on these sEVs (Figures 2A, S3A, and S3C), suggesting immune cell origin. Western blot and super-resolution direct stochastic

(F and G) Representative confocal images (F) and quantification of fluorescence intensity (FI) (G) of thrombus formation in C57BL/6J mice via lung intravital imaging. Mice were injected with TRITC-conjugated 155 kDa dextran (red), DyLight649-conjugated platelet-labeling antibody (white), and 5 μg of sEVs from lungs of control or B16F10 metastasis-bearing C57BL/6J mice, resuspended in fluorescein-conjugated 70 kDa dextran (green).

(H–J) Quantification (H and I) and contour plot (J) of flow cytometry analysis of platelet aggregation induced by sEVs from tissues of PDAC-bearing KPC mice. Platelet aggregation and activation were measured based on aggregate formation on the CD61 gate (all platelets) and CD62P gate (activated platelets), respectively

(K-N) Quantification (K and M) and density plots (L and N) of flow cytometry analysis of CD62P exposure and sEV interaction on circulating platelets from whole blood of C57BL/6J mice injected retro-orbitally with 3  $\mu$ g of PKH26-labeled sEVs from B16F10 metastasis-bearing lungs and anti-GPlb $\beta$  platelet-labeling antibody. Blood was sampled 1 min before and every 1–2 min after sEV injection (t = 0) via retro-orbital bleeding.

(O and P) Survival curves (O) and H&E staining (P) of lung sections from C57BL/6J mice treated with isotype control (IgG) or anti-GPIb $\alpha$  platelet-depleting antibody 24 h before injection of 5  $\mu$ g of B16F10 metastasis-bearing lung sEVs.

See also Figures S1 and S2.

Data are represented as mean  $\pm$  SD (B, C, H, and I) or mean  $\pm$  SEM (G, K, and M). Statistical significance was evaluated using one-way ANOVA with Tukey test. \*\*p < 0.01; \*\*\*\*p < 0.0001.

![](_page_5_Picture_0.jpeg)

![](_page_5_Figure_2.jpeg)

Figure 2. sEV-associated integrin  $\beta_2$  initiates thrombosis

(A and B) Heatmap (A) and quantification (B) of proteins via LS-MS of sEVs from pancreas, liver, and lung tissue explants of 18-week-old KPC control mice (Kras<sup>WT</sup>) or PDAC-bearing mice (Kras<sup>Het</sup>).

(C) Western blot of integrin  $\beta_2$  and loading control (CD9) in sEVs from tissues of KPC mice.

(D–F) Representative dSTORM images of  $\beta_2$  (cyan) and CD9 (magenta) (D) and quantification (E and F) of  $\beta_2$  localizations and clusters per sEV from different tissues of B16F10 metastasis-bearing C57BL/6J mice or KPC mice (E) and metastatic/adjacent lung tissues from patients with lung metastasis from various primary tumors, including leiomyosarcoma, ovarian cancer, thymic lymphoma, and colon cancer (F).

(G and H) Quantification (G) and contour plot (H) of CD61<sup>+</sup> platelet aggregates after incubation of platelet-rich plasma with KPC (non-)metastatic lung sEVs and  $100 \mu g/mL$  integrin  $\beta_2$  blocking antibody or isotope control (lgG).

(I–N) Survival curves (I and L), platelet count (J and M), and H&E staining of lungs (K and N) from C57BL/6J mice injected with 10  $\mu$ g of sEVs from lungs of PDAC-bearing mice or PBS. In (I)–(K), sEVs were pre-incubated with IgG or anti- $\beta_2$  antibody. In (L) and (M), mice were retro-orbitally injected with IgG or anti- $\beta_2$  antibody 30 min prior to sEV injection.

(legend continued on next page)

## **Cell** Article

![](_page_6_Picture_1.jpeg)

optical reconstruction microscopy (dSTORM) imaging confirmed enrichment of  $\beta_2$  on sEVs from (non-)metastatic lungs compared with normal lungs or other tissues (Figures 2C-2E and S3E). Interestingly, integrin  $\beta_2$  was scattered on the surface of sEVs from normal lungs but localized in discrete clusters on pro-thrombotic sEVs from (non-)metastatic lungs of tumor-bearing mice (Figure 2D), reminiscent of focal adhesions where integrins exist in a ligand-binding conformation. 56,57 Notably, the levels of other EVassociated hemostatic factors, including TF or phosphatidylserine (PS), did not differ between pro-thrombotic, lung-derived sEVs and non-thrombotic sEVs from primary tumors, cell lines, or normal lungs from either PDAC or melanoma models, as determined by LC-MS, ELISA, western blot, and dSTORM (Figures S3F-S3J). For clinical relevance, we separated metastatic nodules from uninvolved, adjacent lung tissue from rapid autopsy patients with leiomyosarcoma, ovarian cancer, thymic lymphoma, or colon cancer and isolated sEVs from tissue culture medium for dSTORM imaging. Surprisingly, the adjacent lung tissue, but not metastatic nodules, produced sEVs with highly clustered  $\beta_2$  (Figures 2D and 2F), suggesting that the PTN originates within the peri-metastatic luna.

Functional blockade of integrin  $\beta_2$  on sEVs from lungs of PDAC-bearing mice (Figures 2G and 2H) or melanoma-metastasis-bearing mice (Figures S4A and S4B) prevented platelet aggregation in vitro. Moreover, blocking  $\beta_2$  on (non-)metastatic lung-derived sEVs prior to injection, or systemic β<sub>2</sub> blockade in mice before sEV injection, prevented pulmonary embolism and death of recipient mice (Figures 2I-2N and S4C-S4F) by reducing lung fibrin clots and thrombocytopenia. We performed similar experiments in an Itab2 KO mouse (Itab2-/-). We implanted syngeneic breast cancer 4T1 cells into the mammary fat pad of wild-type (Itgb2+/-), Itgb2+/-, or Itgb2-/- mice, which spontaneously metastasized to lungs. Primary tumor growth was not affected by integrin  $\beta_2$  loss (Figures S4G and S4H). Compared to Itgb2+/+ or Itgb2+/- mice with similar metastatic burden, sEVs from lungs of 4T1 tumor-bearing Itgb2<sup>-/-</sup> mice did not contain integrin  $\beta_2$  (Figure S4I) and lacked pro-coagulant effects when injected into naive mice (Figures 20-2Q), despite high levels of TF (Figures S4I and S4J), consistent with a primary role for sEV- $\beta_2$  in cancer-associated thrombosis.

Lung intravital imaging revealed that pre-treatment of mice with  $\beta_2$ -blocking antibody prior to injection of sEVs from B16F10 metastasis-bearing lungs limited clot size, maintained blood flow, and prevented death (Figures 2R and 2S; Video S2). Moreover, the smaller clots in anti- $\beta_2$  treated mice dissolved within 20 min after sEV injection (Figures 2R and 2S; Video S2). Collectively, these findings demonstrate that integrin  $\beta_2$  on sEVs from the lung PTN is required for acute thrombosis in our experimental models.

### Anti- $\beta_2$ therapy prevents metastasis

To determine whether long-term anti- $\beta_2$  therapy lowers cancer-associated thrombosis risk, mice bearing early-stage, subcutaneous B16F10 tumors received isotype control or anti- $\beta_2$  anti-body twice a week for up to 3 weeks (Figure 3A). To avoid elevated neutrophil counts observed in *Itgb2* KO mice, <sup>58</sup> we titrated the anti- $\beta_2$  dose to 10 mg/kg (Figure S4K). While primary tumor growth was comparable in control and treatment groups (Figure 3B), lung thrombi were reduced by 50% in mice treated with anti- $\beta_2$  antibody compared with IgG (Figures 3C and 3D). Moreover, anti- $\beta_2$  treatment reduced the number and size of MelanA+ micrometastatic nodules in the lungs by more than 4-fold (Figures 3E–3G), suggesting that prolonged  $\beta_2$  blockade prevents both thrombosis and early metastasis.

To further test whether integrin  $\beta_2$  blockade prevented thrombosis in advanced-stage cancer, B16F10 cells were injected intravenously into C57BL/6J mice, and, once metastasis developed, mice received isotype control or anti- $\beta_2$  antibody twice weekly for 4 weeks (Figure 3H). Anti- $\beta_2$  treatment reduced the occurrence of thrombocytopenia and DIC, indicated by normal platelet counts and a 2-fold reduction in thrombi in the lung vasculature (Figures 3I–3K). Strikingly,  $\beta_2$  blockade also significantly reduced metastatic burden by 50%, measured as number and size of lung nodules (Figures 3L and 3M), and prolonged mouse survival (Figure 3N).

As anti-coagulants are often associated with higher bleeding risk in cancer patients, we evaluated tail bleeding in melanomabearing mice treated with vehicle, heparin, isotype control, or anti- $\beta_2$  antibody (Figure 3O). Heparin treatment caused a significant increase in both bleeding time and hemoglobin concentration in lysed blood samples compared with vehicle, whereas anti- $\beta_2$  antibody did not alter these parameters (Figures 3P and 3Q).

### Lung IMs are the main source of $\beta_2^+$ sEVs

To identify the source of  $\beta_2^+$  sEVs in the lung PTN, we used flow cytometry to analyze integrin  $\beta_2$  expression in the predominant lung cell subpopulations, including CD31+ endothelial cells, CD45+ immune cells, EpCam+ epithelial cells, and CD140+ fibroblasts. We found a significant >2-fold increase in  $\beta_2^+$  cells in the lungs of mice bearing PDAC (Figures 4A and 4B) or melanoma metastases (Figure S5A) compared with controls, with 96% of  $\beta_2^+$  cells being immune cells. We next performed 10× Chromium-based single-cell (sc)RNA-seq and cellular indexing of transcriptomes and epitopes by sequencing (CITE-seq) analysis on sorted CD45+ cells from metastasis-free lungs of 18-week-old mice with PDAC tumors (Kras<sup>Het</sup>) and agematched controls (Kras<sup>WT</sup>) (Figure 4C). Immune cell clusters were defined according to the marker panel in Figure S5B.

(O–Q) Survival curve (O), platelet count (P), and H&E staining of lung sections (Q) from BALB/c mice injected with sEVs from wild-type mice ( $ltgb2^{+l'+}$ ) or ltgb2 KO mice (homozygous  $ltgb2^{-l'-}$  or heterozygous  $ltgb2^{-l'-}$ ) bearing spontaneous lung metastasis from 4T1 mammary fat pad tumors.

(R and S) Representative confocal images (R) and quantification of FI (S) of thrombus formation in C57BL/6J mice using lung intravital imaging following retroorbital injection of IgG or anti- $\beta_2$  antibody 30 min before infusion of TRITC-conjugated dextran (red), DyLight649-conjugated platelet-labeling antibody (white), and 5  $\mu$ g of sEVs from B16F10 metastasis-bearing lungs, diluted in fluorescein-conjugated dextran (green).

Data are represented as min to max (B), mean  $\pm$  SD (E, F, G, J, M, and P), and mean  $\pm$  SEM (S). Statistical significance was evaluated using one-way ANOVA with Tukey test. ns, not significant; \*p < 0.05; \*\*p < 0.01; \*\*\*p < 0.001; \*\*\*\*p < 0.0001. See also Figures S3 and S4.

![](_page_7_Picture_0.jpeg)

![](_page_7_Figure_2.jpeg)

Figure 3. Integrin b<sup>2</sup> blockade prevents metastasis and thrombosis

(A) Diagram of experimental setup for (B)–(G). C57BL/6J mice bearing subcutaneous (s.c.) B16F10 tumors were injected retro-orbitally with isotype control (IgG) or anti-b<sup>2</sup> antibody twice per week for 3 weeks. Lungs, primary tumor, and blood were collected at the endpoint. (B) Growth curve of primary B16F10 melanoma tumors in mice in (A).

(C and D) Lung section H&E staining (C) and quantification (D) of clots in lung sections from mice receiving IgG or anti-b<sup>2</sup> antibody as per (A).

(E–G) Representative images (E) and quantification (F and G) of Melan-A<sup>+</sup> micrometastatic nodule number and size in lung sections of mice in (A)–(D).

(H) Diagram of experimental setup for (I)–(N). C57BL/6J mice intravenously (i.v.) injected with B16F10 cells and bearing established lung metastases were treated retro-orbitally with IgG or anti-b<sup>2</sup> twice per week or up to 4 weeks before blood and tissue collection.

(I–K) Lung section H&E staining (I), blood platelet count (J), and number of fibrin clots per field of view (FOV) (K) in untreated C57BL/6J mice (naive) or C57BL/6J mice bearing B16F10 metastases and receiving IgG or anti-b<sup>2</sup> antibody.

(L–N) Quantification of metastases number (L), size (M), and survival curve (N) of mice in (H)–(K).

(O–Q) Diagram of the bleeding test (O). Mice bearing B16F10 s.c. tumors were injected retro-orbitally with vehicle (PBS), heparin, IgG, or anti-b<sup>2</sup> antibody. After 30 min, mice were anesthetized with 2.5% isoflurane and their tails submerged in warm saline. Bleeding time was measured for 20 min following 3 mm tail cut (P). Hemoglobin optical density (O.D., 550 nm) was quantified in lysed blood (Q) as a surrogate measurement of blood volume.59

Data are represented as mean ± SD (B, D, F, G, J, K, and M) and min to max (L, P, and Q). Statistical significance was evaluated using two-tailed unpaired t test (D, F, G, K, L, and M), one-way ANOVA with Tukey test (J, P, and Q), and Mantel-Cox Log-rank test (N). ns, not significant; \**p* < 0.05; \*\**p* < 0.01; \*\*\**p* < 0.001; \*\*\*\**p* < 0.0001.

See also Figure S4.

We observed dramatic changes in frequencies of immune populations with granulocytes, including neutrophils and basophils, significantly reduced and effector T cells, B cells, natural killer (NK) cells, and macrophages enriched in the lungs of PDACbearing mice (Figure 4D).

Complementary to immune landscape alterations, pathway analysis of differentially expressed genes revealed significant reprogramming of infiltrating macrophages and dendritic cells (DCs), with integrin signaling being among the top upregulated pathways (Figure S5C). We also observed transcriptomic

![](_page_8_Picture_1.jpeg)

![](_page_8_Figure_2.jpeg)

Figure 4. Activated IMs are the source of  $\beta_2^+$  sEVs in the lung PTN

(A and B) Flow cytometry histogram (A, left) and quantification (A, right, and B) of the proportion and subtype of  $\beta_2^+$  live single cells in the lungs of 18-week-old control (Kras<sup>WT</sup>) or tumor-bearing (Kras<sup>Het</sup>) KPC mice.

(C and D) Uniform manifold approximation and projection (UMAP) plot of combined scRNA-seq and CITE-seq data from CD45<sup>+</sup> immune cells sorted from 18-week-old Kras<sup>WT</sup> or Kras<sup>Het</sup> KPC mice (C) and quantification of proportions of cell subtypes (D).

(E and F) Sub-clustering of macrophages (cluster #8 in C) into DCs (cluster 0), interstitial macrophages (IMs, cluster 1) and plasmacytoid DCs (pDCs, cluster 2) (E), and quantification of  $\beta_2$ <sup>+</sup> cluster 1 (IMs) proportions (F).

(G–I) Flow cytometry (G and H) and IF (I) quantification of F4/80\*Ly6C<sup>-</sup>MHC-II\*SiglecF<sup>-</sup> IMs in lungs of Kras<sup>WT</sup> and Kras<sup>Het</sup> KPC mice.

(J) Heatmap of RNA levels of markers of M1- and M2-like phenotypes in IMs (cluster #8-1) from Kras<sup>WT</sup> and Kras<sup>Het</sup> KPC mice.

(K–M) Quantification of M2-like markers CD206 and CD163 in F4/80+Ly6C<sup>-</sup>SiglecF<sup>-</sup> IMs by flow cytometry (K and L) and IF (M) in lungs from Kras<sup>WT</sup> and Kras<sup>Het</sup> KPC mice. AS, alveolar space.

(N–Q) Experimental layout (N), survival curves (O), blood platelet count (P), and H&E staining of lung sections (Q) from C57BL/6J mice injected with 10 μg of sEVs from lungs of mice bearing KPC4662 metastases, treated with anti-CSF1R antibody for IM depletion for 2 days before lung dissection and sEVs isolation. Data are represented as mean ± SD (A, F, G, K, and P) and mean (D). Statistical significance was evaluated using two-tailed unpaired t test (A, F, G, and K) and one-way ANOVA with Tukey test (P). \*p < 0.05; \*\*\*p < 0.001; \*\*\*\*p < 0.0001.

changes in metabolic pathways in macrophages, including biosynthesis of D-myo-inositol-5-phosphate (IP3) and its soluble product D-myo-inositol (3,4,5,6)-tetrakisphosphate (IP4), and downregulation of macrophage-stimulating protein-recepteur d'origine nantais (MSP-RON) and eukaryotic initiation factor 2

(EIF2) signaling, hallmarks of inflammatory responses, 60-63

See also Figure S5.

suggesting that macrophages undergo an alternative (or M2-like) activation in the lung PTN. Several pathways associated with T cell activation were also upregulated in macrophages and CD4<sup>+</sup>/CD8<sup>+</sup> T cells (Figure S5C).<sup>64</sup> Together, these findings suggest that the PTN is primarily an immunoreactive and anti-tumor niche.

![](_page_9_Picture_0.jpeg)

![](_page_9_Picture_1.jpeg)

Since integrin signaling and  $\beta_2$  expression were higher in macrophages than other immune cells (Figures S5C and S5D), we annotated macrophages and DCs into three subclusters: DCs (cluster 0), IMs (cluster 1), and plasmacytoid DCs (pDCs, cluster 2) (Figure 4E). We observed a 5-fold expansion of the β<sub>2</sub>+CD11c+CD11b+Ly6C-SiglecF-F4/80+ IM compartment (Figure 4F), 65 validated by flow cytometry and immunofluorescence (IF) of lungs from mice with PDAC tumors (Figures 4G-4I) or B16F10 metastases (Figures S5E-S5H) and their controls. The frequency of other resident macrophages, including alveolar macrophages, did not change (Figure S5F). Transcriptomic and CITE-seq analysis revealed that IMs in the lung PTN were polarized toward an M2-like phenotype, as indicated by expression of CD206, Cx<sub>3</sub>CR1, Mrc1, and other previously identified markers (Figures 4J-4M and S5G). 65-68 These data indicate that β2+ immune-regulatory, alternatively activated IMs are enriched in the lung PTN.

To evaluate whether IMs produce pro-thrombotic sEVs, we depleted lung IMs in mice bearing B16F10 or KPC4662 lung metastases. Anti-colony stimulating factor 1 receptor (CSF1R) antibody treatment depleted CSF1R<sup>+</sup> IMs but not CSF1R<sup>-</sup> alveolar macrophages and other immune cells (Figures S5I and S5J). While it did not affect metastatic growth (Figures S5K and S5L), short-term depletion of IMs yielded lung sEVs that failed to cause thrombosis in naive mice (Figures 4N–4Q, S5M, and S5N). In contrast, depletion of neutrophils (anti-Ly6G/C antibody) or mature T/B cells (Rag2 KO mice) did not affect pro-thrombotic properties of lung-derived sEVs (Figures S5M and S5N). This implicates IMs as the main source of pro-thrombotic  $\beta_2^+$  sEVs in the PTN.

# Primary and metastatic tumors induce tissue-resident IM proliferation and activation

Lung CD206<sup>+</sup> IMs proliferate in response to lipopolysaccharides (LPS) and lung injury or differentiate from recruited blood monocytes. <sup>65,69,70</sup> Markers of monocyte-derived macrophages were downregulated in the lung IMs of PDAC-bearing mice (Kras<sup>Het</sup>) (Figure S6A). Furthermore, the numbers of blood monocytes and lung F4/80<sup>+</sup>CCR2<sup>+</sup> monocytes were similar in control and PDAC-bearing mice (Figures S6B–S6D), suggesting that monocytes are not actively recruited to the lung PTN. F4/80<sup>+</sup>CCR2<sup>-</sup> IMs were also positive for the proliferation marker Ki67 (Figures S6C and S6E), suggesting that IMs self-replicate in the lung PTN.

To determine how tumors promote CD206<sup>+</sup> IM proliferation and production of pro-thrombotic sEVs, non-obese diabetic (NOD) severe combined immunodeficiency (SCID) mice were educated with sEVs from PDAC patient-derived organoids for 3 weeks. sEV treatment did not alter the frequency of  $\beta_2^+$  IMs in the lungs (Figures S6F and S6G), suggesting that paracrine tumor-derived factors drive the formation of the lung PTN. We measured levels of chemokines and cytokines in matched pancreas-conditioned medium (CM) and plasma from control and PDAC-bearing KPC mice. The C-X-C motif chemokine 13 (CXCL13) was upregulated 50-fold in plasma and more than 200-fold in the CM of Kras Het mouse pancreas relative to controls (Figures 5A-5C). We also found significantly higher levels of circulating CXCL13 in plasma of mice bearing metastatic breast cancer (PyMT) and melanoma lung metastases (B16F10 cells) compared with their non-tumor-bearing counterparts (Fig-

ure 5C), suggesting that CXCL13 derives from both primary and metastatic tumors. We subsequently treated human monocytederived macrophages from peripheral blood of healthy donors with CM of tumor tissue (CM<sub>TT</sub>) from three distinct PDAC patients in the presence of isotype control or anti-CXCL13 antibody and assessed expression of M1/M2 polarization markers (Figure 5D). CXCL13 inhibition abrogated the CM<sub>TT</sub>-mediated increase in CD206<sup>+</sup> M2-like macrophages without affecting CD80 expression (Figures 5E and 5F). Moreover, sEVs from macrophages treated with CM<sub>TT</sub> and anti-CXCL13 lacked pro-thrombotic effects when incubated with platelets (Figure 5G). In vivo, naive C57BL/6J mice were treated with isotype control or anti-CXCL13 antibody plus CM from PDAC tumors of KPC mice (CM<sub>TT</sub>) or recombinant mouse CXCL13 (rmCXCL13) for 2 weeks (Figure 5H). Lung sEVs isolated from mice treated with  $CM_{TT}$  and isotype control or rmCXCL13, but not those from mice treated with CM<sub>TT</sub> and anti-CXCL13 antibody, induced pulmonary thrombi and thrombocytopenia in naive mice (Figures 5I-5K), similar to sEVs from lungs of tumor-bearing mice (Figures 1B-1E). Importantly, treatment with rmCXCL13 and CM<sub>TT</sub> was sufficient to induce PTN formation and  $\beta_2^+$  IM expansion in the lungs, effects abrogated by anti-CXCL13 antibody treatment (Figures 5L and 5M). Together, these data indicate that circulating tumor-derived CXCL13 induces lung IM reprogramming and production of pro-thrombotic sEVs.

### Pro-thrombotic sEVs bear activated $\alpha_x \beta_2$ heterodimers

Integrins are heterodimers comprised of  $\alpha$  and  $\beta$  subunits, with integrins  $\alpha_D$ ,  $\alpha_L$ ,  $\alpha_M$ , and  $\alpha_X$  being potential partners of integrin  $\beta_2$ . We adapted the photocatalytic proximity labeling technology  $(\mu Map)^{71}$  to identify the  $\alpha$  partner of  $\beta_2$  on pro-thrombotic sEVs. In this unbiased approach, organometallic iridium complex conjugated to a secondary antibody against the anti- $\beta_2$  antibody promotes conversion of diazirines into short-lived carbene intermediates that irreversibly crosslink biomolecules within 20 nm of  $\beta_2$  (Figure 6A).<sup>71</sup> Integrins  $\alpha_M$  and  $\alpha_X$  were identified as  $\beta_2$ interactors on sEVs from (non-)metastatic lungs of melanomabearing mice (Figure 6B), as confirmed by co-immunoprecipitation (Figure S7A). dSTORM confirmed that integrin  $\beta_2$ ,  $\alpha_X$ , and  $\alpha_M$ were present on the surface of sEVs from (non-)metastatic lungs, with  $\alpha_x$  preferentially found in close proximity to  $\beta_2$  (Figure 6C). Furthermore, scRNA-seq and immunofluorescence analysis revealed that  $\alpha_M$  was downregulated while  $\alpha_X$  was upregulated at both transcriptional and protein levels in lung CD206+ IMs from mice with PDAC and melanoma (Figures 6D and 6E). These data suggest that integrin  $\beta_2$  preferentially associates with integrin  $\alpha_X$  on sEVs from IMs in the lung PTN.

Ligand-binding activity of integrins requires inside-out signaling to shift from a "closed" to an "open" conformation, followed by clustering at focal adhesions.  $^{56,57,73}$  We observed clustered integrin  $\beta_2$  on lung sEVs from tumor-bearing mice and human lung tissue adjacent to metastatic nodules (Figure 2D), suggesting presence of active  $\alpha_X\beta_2$  dimers. We therefore quantified levels of activated integrin  $\beta_2$  (act  $\beta_2$ ) on IMs from lungs of patients with pulmonary metastases from various primary tumors using a conformation-sensitive antibody that recognizes epitopes on activated human  $\beta_2$  (MEM-148).  $^{74}$  IMs expressing act  $\beta_2$  and  $\alpha_X$  were found in adjacent areas of

![](_page_10_Picture_1.jpeg)

![](_page_10_Figure_2.jpeg)

Figure 5. Tumor-derived CXCL13 promotes IM reprogramming and release of pro-thrombotic sEVs

(A and B) Images (A) and quantification (B) of proteome cytokine array of EV-depleted plasma and pancreas explant conditioned medium (CM, both post 100,000 ×g spin) from matched Kras<sup>WT</sup> and Kras<sup>Het</sup> KPC mice.

(C) ELISA of CXCL13 in EV-depleted plasma from mice with breast cancer (PyMT, 14 weeks), B16F10 lung metastasis, or PDAC (KPC, 18 weeks), and tumor-free

(D-F) Experimental plan (D) and quantification by flow cytometry (E and F) of M1/M2 marker levels in human monocyte-derived macrophages co-incubated with EV-depleted conditioned medium of tumor explants from PDAC patients (CM<sub>TT</sub>, 1:1 dilution in RPMI) for 48 h.

(G) Flow-cytometry quantification of CD61+ platelet aggregation in response to sEVs from macrophages in (D)-(F).

(H–K) Experimental layout (H), survival curve (I), platelet count (J), and H&E staining of lung sections (K) from C57BL/6J mice injected with 10 μg of lung seVs, which were previously isolated from mice injected retro-orbitally every 2-3 days for 2 weeks with recombinant mouse CXCL13 (rmCXCL13) or KPC CM<sub>TT</sub> (concentrated 400 µL, a volume equivalent to 10 µg of sEVs). CM<sub>TT</sub>-recipient mice also received IgG or anti-CXCL13 antibody twice weekly.

(L and M) Quantification (L) and representative confocal images (M) of  $\beta_2$  expression in F4/80<sup>+</sup> lung IMs from mice in (H)–(K).

Data are represented as mean (B) and mean ± SD (C, E, G, J, and L). Statistical significance was evaluated using two-tailed unpaired t test (C) and one-way ANOVA with Tukey test (E, G, J, and L).

See also Figure S6.

![](_page_11_Picture_0.jpeg)

![](_page_11_Picture_1.jpeg)

![](_page_11_Figure_2.jpeg)

*(legend on next page)*

![](_page_12_Picture_0.jpeg)

![](_page_12_Picture_1.jpeg)

metastasis-bearing lungs but not within metastatic nodules (Figure 6F). The percentage of  $act\beta_2^+$  sEVs and number of  $act\beta_2$  molecules per vesicle also increased in the conditioned medium from peri-metastatic lung tissue compared with metastatic nodules or healthy lungs (Figures 6G–6I). Together, these data support the notion that pro-thrombotic sEVs from IMs in peri-metastatic or non-metastatic areas of the lung bear activated  $\alpha_X\beta_2$  dimers.

## **Direct interaction of sEVs with platelets drives** thrombosis

Platelets and sEVs directly interact in the bloodstream of injected mice (Figures 1M and 1N). Integrin  $\beta_2$  binds components of the coagulation cascade, including fibrin and fibrinogen, and various ligands expressed on both resting and activated platelets. <sup>75–79</sup> We employed  $\mu$ Map to identify the platelet ligand of sEV  $\beta_2$  (Figure 6J). GPIb subunits  $\alpha$  and  $\beta$  (Gp1ba and GP1bb) were significantly enriched in the integrin  $\beta_2$ -platelet interactome of lung sEVs from both melanoma and PDAC-bearing mice (Figure 6K). Other known  $\beta_2$  ligands, including Intercellular Adhesion Molecule 1 (ICAM-1), GPIlb/Illa, and protease activated receptor (PAR)4, were not enriched in this interactome. We validated this with single-molecule force spectroscopy (SMFS) that calculates the pico-Newton range of force needed to detach ligand-coated atomic force microscopy (AFM) tips from the surface of immobilized sEVs from normal lungs or (non-)metastatic lungs from

mice with melanoma or PDAC (Figure 6L). The interaction of pro-thrombotic sEVs with GPIb $\alpha$ -coated tips was much stronger than the interaction with ICAM-1-coated, GFP-coated (negative control), or untreated tips (Figure 6M). Furthermore, sEVs from (non-)metastatic, PTN-bearing lungs had much stronger interactions with GPIb $\alpha$ -coated tips than sEVs from normal lungs (Figure 6N). Pre-incubation of sEVs with an anti- $\beta_2$  antibody before binding with GPIb $\alpha$  tips reduced the force of interaction between sEVs and GPIb $\alpha$  (Figure 6O). We also verified that GPIb $\alpha$ -coated tips bind to immobilized recombinant  $\alpha_x\beta_2$  protein (Figure 6P).

GPIb binding to its canonical ligand von Willebrand factor initiates a cascade of events, including exposure of PS on the platelet membrane and assembly of the TF/FVIIa/FXa prothrombinase complex, culminating in thrombin generation and fibrinogen cleavage.<sup>80</sup> To determine whether sEV-β<sub>2</sub> initiated the same cascade, sub-lethal amounts of sEVs from B16F10 metastasis-bearing lungs were injected into C57BL/6J mice, followed by blood sampling and platelet staining with PS-binding annexin V. We observed peak PS exposure on circulating platelets within a minute following sEV injection (Figures 6Q and 6R). Similarly, in vitro incubation of metastasis-bearing lungs sEVs with platelets resulted in significantly higher annexin V binding compared with vehicle or collagen stimulation (Figures S7B and S7C). We also observed prolonged survival and higher platelet count in mice treated with annexin V versus PBS before injection of pro-thrombotic sEVs (Figures 6S and 6T), suggesting that

### Figure 6. Activated integrin $\alpha_x \beta_2$ dimers on PTN-derived sEVs interact with platelet GPIb to drive thrombosis

(A) Diagram of the photocatalytic proximity labeling technology (μMap) used to identify β<sub>2</sub> alpha partner(s) on pro-thrombotic sEVs.<sup>71</sup>

(B and C) Volcano plot of  $\beta_2$  interactors integrin  $\alpha_M$  and  $\alpha_X$ , identified by  $\mu$ Map (B), and representative dSTORM images of  $\alpha_M$  (green),  $\alpha_X$  (yellow), and  $\beta_2$  (cyan) on the surface of pro-thrombotic sEVs from B16F10 metastasis-bearing lungs (CD9, magenta) (C).

- (D) Quantification of Itgb2, Itgam, and Itgax RNA levels in IMs from scRNA-seq analysis of lungs of Kras<sup>WT</sup> and Kras<sup>Het</sup> KPC mice.
- (E) Representative confocal images of  $\beta_2$  (magenta) and  $\alpha_X$  (green) in lung sections from B16F10 metastasis-bearing mice or Kras<sup>WT</sup> and Kras<sup>Het</sup> KPC mice. MET, metastatic nodule; ADJ, adjacent lung.
- (F) Representative confocal images of  $act\beta_2$  (magenta) and  $\alpha_X$  (green) in lung sections from patients with lung metastasis from different primary tumors (leio-myosarcoma, ovarian cancer, thymic lymphoma, or colon cancer). AS, alveolar space.
- (G–I) Proportion of  $(act)\beta_2^+$  sEVs (G), number of  $(act)\beta_2$  localizations per sEV (H), and representative dSTORM images (I) of sEVs from metastasis-bearing lung and adjacent lung explants from patients in (F).
- (J) Diagram of  $\mu$ Map technology to identify  $\beta_2$  interactors on platelets following incubation with sEVs from B16F10- or KPC4662-metastasis-bearing lungs. (K) Volcano plot of platelet-sEV interactome, showing platelet GPIb $\alpha$  and  $\beta$  subunits association with sEV- $\beta_2$ .
- (L–P) Experimental diagram of the single-molecule force spectroscopy (SMFS) method (L) and quantification (M–P) of interaction force of ICAM-1, GPIb $\alpha$ , and GFP (negative control) coated tips with immobilized sEVs from B16F10 metastasis-bearing lungs or lungs from Kras<sup>Het</sup> KPC mice (M–O) or recombinant  $\alpha_x\beta_2$  protein (P). In (O), sEVs were incubated with IgG or anti- $\beta_2$  antibody.
- (Q and R) Whole blood flow-cytometry analysis (Q) and density plots (R) of PS exposure, measured via e350-annexin V binding, on circulating platelets from C57BL/6J mice injected with 3 μg sEVs from B16F10 metastasis-bearing lungs and DyLight-conjugated anti-GP1bβ platelet-labeling antibody. Blood was sampled 1 min before and every 1–2 min following sEV injection via retro-orbital bleeding.
- (S and T) Survival curve (S) and blood platelet count (T) in C57BL/6J mice treated with PBS or annexin V 30 min before injection of 5  $\mu$ g of sEVs from B16F10 metastasis-bearing lungs.
- (U) FVIIa, FXa, and thrombin generation in platelet-rich plasma in response to PBS, recombinant mouse TF (rmTF), or sEVs from B16F10 cells, melanoma primary tumors, C57BL/6J normal lungs, or B16F10 metastasis-bearing lungs, measured as 405 nm O.D. of chromogenic substrates of FVIIa (SCP-0248), FXa (S-2765), or thrombin (S-2238).
- (V) Diagram of the proposed mechanism of sEV-platelet interaction and thrombus formation mediated by sEV- $\alpha_x\beta_2$ .
- (W) Quantification of platelet aggregometry upon blockade of GPIbα (R300 antibody, 100 μg/mL), ICAM-1 (anti-ICAM-1 antibody, 100 μg/mL), PAR4 (BMS986120, 13.3 μg/mL), thrombin (heparin, 13.3 U/mL), and/or GPIIb/IIIa (eptifibatide, 6.7 μg/mL) on platelets and/or sEVs from metastasis-bearing lungs of Kras<sup>Het</sup> KPC mice.
- (X) Aggregation of healthy donor platelets incubated with sEVs from peri-metastatic, adjacent lungs of patients with leiomyosarcoma, ovarian cancer, thymic lymphoma, or colon cancer in the presence of  $100 \,\mu\text{g/mL}$  anti-GPlb $\alpha$  antibody (6D1) or anti-GPllb/IIIa antibody (7E3).
- (Y and Z) Survival curve (Y) and platelet count (Z) in mice treated systemically with aspirin (ASA), heparin, hirudin, eptifibatide, and/or anti- $\beta_2$  antibody prior to injection of 5  $\mu$ g of sEVs from B16F10 metastasis-bearing lungs.
- Data are represented as min to max with density curves (D), mean  $\pm$  SD (G, H, M–P, T, W, X, and Z), mean  $\pm$  SEM (Q), and min to max (U). Statistical significance was evaluated using one-way ANOVA with Tukey test (G, H, T, U, and Z) or Dunnett test (W and X). ns, not significant; \*p < 0.05; \*\*p < 0.01; \*\*\*\*p < 0.001; \*\*\*\*p < 0.0001. See also Figure S7.

![](_page_13_Picture_0.jpeg)

![](_page_13_Picture_1.jpeg)

platelet PS exposure is a necessary step for sEV-induced thrombosis. To exclude PS+ sEV as source of PS on sEV-interacting platelets, we incubated formaldehyde-fixed or heparin-treated platelets, neither of which can actively expose PS, with sEVs from B16F10 or KPC4662 metastasis-bearing lungs and did not observe increased annexin V binding on the platelet surface (Figures S7D-S7F). To further exclude that sEVs provide PS to the platelet surface by endocytosis and redistribution to the plasma membrane,81 platelets were treated with amiloride (inhibitor of micropinocytosis) or chlorpromazine (inhibitor of clathrin-dependent endocytosis)82 before incubation with sEVs. Neither inhibitor affected platelet activation (CD62P+ platelets) nor PS exposure (annexin V+ platelets) in response to collagen or sEVs from B16F10 and KPC4662 metastasis-bearing lungs (Figures S7G-S7J). dSTORM of sEV incubated with platelets further demonstrated most PS localized on the platelet surface rather than on platelet-bound sEVs (Figure S7B), indicating that PS exposure arises from canonical platelet activation induced by sEV binding.

Next, we tested whether functional TF/FVIIa/FXa prothrombinase complexes form on the surface of sEVs bound to PSexposing platelets for thrombin generation. dSTORM imaging showed an association of FVII and FX with TF on the surface of pro-thrombotic sEVs incubated with platelets (Figure S7K). Supplementation of platelet-rich plasma with chromogenic substrates demonstrated generation of FVIIa, FXa, and thrombin in response to sEVs from B16F10 metastasis-bearing lungs and recombinant mouse TF (rmTF, positive control) but not in response to sEVs from B16F10 cells, primary tumors, or normal lungs (Figure 6U). Furthermore, functional blockade of TF on B16F10 metastasis-bearing lung sEVs via TF-blocking antibody or TF pathway inhibitor (TFPI) before incubation with platelets did not prevent PS exposure on platelets, whereas both  $\beta_2$  and TF blockade reduced platelet aggregation (Figures S7L-S7N), suggesting that TF is required for sEV-induced thrombosis but acts downstream of sEV-β<sub>2</sub>. Together, these data indicate that the direct interaction between sEV  $\alpha_x\beta_2$  and platelet GPIb initiates a platelet activation cascade involving PS presentation on the platelet surface that promotes TF-mediated generation of FVIIa, FXa, and thrombin, leading to fibrin deposition and thrombus growth (Figure 6V).

We also tested whether blocking GPIb or other platelet ligands prevented sEV-induced platelet aggregation. In vitro, blockade of platelet GPIbα (R300 antibody, mouse; 6D1 antibody, human) and inhibition of thrombin (heparin), but not ICAM-1 (anti-ICAM-1 antibody), GPIIb/IIIa (eptifibatide, mouse; 7E3 antibody, human), or thrombin receptor PAR4 (BMS986120), prevented platelet aggregation by sEVs from metastasis-bearing lungs of mice with melanoma/PDAC or patients with lung metastases (Figures 6W, 6X, and S7O). Similarly, in vivo inhibition of PS exposure via annexin V treatment (Figures 6S and 6T) and thrombin generation via heparin or hirudin (Figures 6Y and 6Z) prevented lethal thrombosis and thrombocytopenia in mice receiving sEVs from B16F10 metastasis-bearing lungs, while eptifibatide or aspirin (COX-1/2 inhibitor) treatment did not. β<sub>2</sub> blockade was as effective as heparin in preventing thrombosis, but heparin and anti-β<sub>2</sub> blockade did not synergize (Figures 6Y and 6Z). Together, this experimental evidence supports the requirement

for platelet PS exposure and thrombin generation in  $\beta_2^+$  sEV-induced thrombosis (Figure 6V).

# sEV-associated integrin $\beta_2$ correlates with thrombotic risk in cancer patients

To evaluate the potential of integrin  $\beta_2$  as a biomarker for thrombotic risk in cancer patients, we measured the concentration of sEVs and their  $\beta_2$  levels in plasma from healthy controls or stage I-IV PDAC patients with or without a history of TE (Table S1). The concentration and  $\beta_2$  levels in plasma sEVs were higher prior to a TE event than after or when compared with patients with no TE (Figures 7A-7C). sEV-associated β2 levels peaked with a 4-fold increase in the 30 days prior to a TE event (Figure 7D) and were particularly high in stage IV patients (Figure 7E). Similarly, β<sub>2</sub> was enriched in plasma sEVs from patients with lung adenocarcinoma (LUAD), second only to PDAC in terms of TE risk, compared with healthy controls (Figure 7F). Among pediatric cancers, we found significantly higher levels of  $\beta_2$  in circulating sEVs from patients with Hodgkin's lymphoma compared with neuroblastoma and osteosarcoma (Figure 7G), reflecting the corresponding risk of thrombotic complications.83,8

Lung biopsies from patients with LUAD and PDAC were immunostained to evaluate PTN formation in tumor-adjacent or non-metastatic tissue, as suggested by the plasma levels of sEV- $\beta_2$ . In LUAD patients, we observed increased numbers of  $\alpha_X$  act  $\beta_2^+$  and CSF1R+F4/80+ IMs in the non-involved lung but not in the primary tumor (Figures 7H and 7I). Similarly, in PDAC patients, we detected significantly higher proportions of act  $\beta_2^+$  and CSF1R+ IMs in the peri- or non-metastatic lung but not in metastatic nodules (Figures 7J–7L).

Finally, as our previous results indicated that tumor-derived CXCL13 might serve as a biomarker for lung PTN formation, we assessed circulating CXCL13 in the sEV-depleted plasma of the PDAC patient cohort (Table S1). Similar to sEV- $\beta_2$ , CXCL13 levels were significantly higher in the plasma of patients experiencing a TE event compared with patients with no TE (Figure 7M). Moreover, circulating CXCL13 levels correlated with cancer stage (Figure 7N).

Collectively, our data indicate that primary tumor CXCL13 reprograms lung IMs to release integrin  $\beta_2^+$  sEVs that initiate thrombosis and may serve as predictive biomarker and therapeutic target for TE.

### **DISCUSSION**

Thrombosis is a major, yet poorly understood, cause of cancer-related morbidity and mortality. Here we have shown that tumor-derived CXCL13 reprograms IMs in the lung PTN to produce sEVs carrying activated integrin  $\alpha_X\beta_2$ , which directly engages platelet GPIb to induce systemic platelet activation and aggregation. Blocking integrin  $\beta_2$  on sEVs or systemically prevented lethal thrombosis and reduced metastatic burden. High levels of  $\beta_2$  were detected in plasma sEVs from stage I–IV PDAC patients prior to TE compared with stage-matched PDAC patients with no evidence of TE, as well as in other cancer types with high thrombosis risk, namely LUAD and pediatric Hodgkin lymphoma. Thus, sEV- $\beta_2$  can serve as a novel, blood-based biomarker for

![](_page_14_Picture_1.jpeg)

![](_page_14_Figure_2.jpeg)

Figure 7. sEV-b<sup>2</sup> correlates with TE risk and prognosis in cancer patients

(A–E) Concentration of sEVs (A and B, nanoparticle tracking analysis [NTA]) and sEV-b<sup>2</sup> (C and E, ELISA) in plasma from a cohort of healthy controls and stage I-IV PDAC patients with or without clinical history of TE (Table S1). (B) shows matched pre- and post-thrombosis plasma pairs from the same donor. NED, no evidence of disease.

(F and G) LC-MS quantification of sEV-b<sup>2</sup> levels in plasma from patients with lung adenocarcinoma (LUAD) (F) or pediatric neuroblastoma, osteosarcoma, and Hodgkin lymphoma (G) and age-matched healthy controls.

(H and I) Representative confocal images (H) and quantification (I) of IF staining of tissue sections from primary tumor (LUAD) and adjacent lung (ADJ) from LUAD lung biopsies.

(J–L) Representative images (J) and quantification (K and L) of 3,3'-diaminobenzidine (DAB) staining of actb<sup>2</sup> and CSF1R in formalin-fixed, paraffin-embedded (FFPE) lung sections from healthy controls (normal lungs) or PDAC patients with no lung metastasis (non-metastatic lung) or with lung metastasis. In the latter group, both regions of tumor involvement (MET) and adjacent lung (ADJ) were analyzed.

(M and N) CXCL13 levels measured by ELISA in EV-depleted plasma from the PDAC patient cohort in (A)–(E) and Table S1.

Data are represented as median with min to max (A, C, F, G, M, and N) and mean ± SD (D, I, K, and L). Statistical significance was evaluated using two-way ANOVA with Tukey test (A), one-way ANOVA with Tukey test (C, G, K, and L), and two-tailed unpaired t test (F, I, and M). ns, not significant; \**p* < 0.05; \*\**p* < 0.01; \*\*\**p* < 0.001; \*\*\*\**p* < 0.0001.

thrombosis risk and a target to prevent thrombosis and metastasis in cancer patients.

Cancer-associated chronic DIC and recurrent venous TE represent independent predictors of mortality and post-thrombotic sequelae, such as venous ulcers and long-term infirmity.27,85,86 Current anti-coagulants, such as low molecular weight heparin (LMWH) or direct oral anti-coagulants (DOACs), significantly reduce the risk of cancer-associated thrombosis recurrence and mortality,85,87 albeit at the cost of hemorrhage and thrombocytopenia.24,88,89 Here, we have provided evidence that thrombosis risk estimation based on plasma EV-b<sup>2</sup> levels may guide timely prophylactic anti-coagulation in at-risk patients. Moreover, our work identified integrin <sup>b</sup><sup>2</sup> and GPIb as potential targets for thromboprophylaxis. Whereas it is unlikely that chronic anti-GPIb therapy will have an acceptable safety profile, we showed that anti-b<sup>2</sup> therapy did not cause neutropenia, thrombocytopenia, or hemorrhage in tumor-bearing mice, confirming data from previous clinical trials.90,91

![](_page_15_Picture_0.jpeg)

Hemostatic factors, such as TF, and negatively charged phospholipids are exposed on microvesicles circulating in the blood of cancer patients  $^{38,40,41}$  and accumulate in the developing thrombus.  $^{38,39,50,92,93}$  In particular, PS has been shown to promote the assembly of coagulation factor complexes on the surface of activated platelets and apoptotic cells.  $^{94}$  We did not detect differences in TF or PS levels in sEVs from (non-)metastatic lungs and other tissue sources.  $^{42-48}$  We have instead shown that sEV-bound TF is required for the assembly of the TF/FVIIa/FXa prothrombinase complex on the surface in PS-exposed platelets following GPIb- $\beta_2$  interaction, leading to thrombin generation and fibrin deposition.  $^{80}$  The interaction of platelet GPIb with DC-bound  $\beta_2$  was previously noted in thromboinflammation,  $^{79}$  supporting the results of our unbiased sEV- $\beta_2$  binding partner search.

The lung is a common site of metastasis in melanoma and breast cancer, while lung metastases are less frequent in PDAC. Here, we have shown that, irrespective of metastatic status, the extra-metastatic portion of the lung influences thrombosis at a systemic level through the formation of the PTN. In contrast to the immunosuppressive pre-metastatic niche (PMN), 32 features of the PTN include expansion of resident cells (e.g., IMs) and immune surveying cells (e.g., B/T cells) and loss of pro-tumorigenic immune cells (e.g., neutrophils). Hence, the PTN is an immunoreactive and likely tumor suppressive niche. Our findings also highlight a central role of IMs in the lung PTN. While well studied in health and lung disease, 95,96 the role of IMs in lung metastasis is less clear. We have shown that, rather than recruiting monocytes, tumor cells induce expansion of resident IMs in the lung PTN, reprogramming them toward a CD163<sup>+</sup>/CD206<sup>+</sup> M2-like phenotype. The high expression of major histocompatibility complex (MHC)-II-related hla genes by IMs in the PTN suggests a role in antigen presentation and activation of anti-tumor immune responses that we observed. Moreover, their expression of interleukin-10 (il-10) may underlie reduced neutrophil infiltration and T-helper 17 (Th17) activity in the PTN. 97,98 The role of IMs in orchestrating PTN establishment and metastatic outcome warrants further research.

While EVs contribute to PMN formation, 29,31 our work has shown that the tumor-derived chemokine CXCL13 supports PTN establishment by reprogramming lung IMs to release integrin  $\beta_2^+$  sEVs. We found significantly upregulated CXCL13 in plasma of PDAC patients suffering from TE events and with advanced disease stage, suggesting that CXCL13 levels may reflect lung PTN generation and guide therapies to prevent thrombosis. While previous reports showed that CXCL13 orchestrates the generation of inducible bronchus associated lymphoid tissues (iBALTs), ectopic tertiary lymphoid structures comprising T and B cells, and that CD4+ T cell-derived IL-9 mediated IM expansion and reprogramming, 99-101 we observed that CXCL13 treatment directly reprogrammed lung IMs toward a pro-thrombotic phenotype. Interestingly, lung CXCL13 expression increases in pulmonary disease, including microbial infections, pulmonary fibrosis, chronic obstructive pulmonary disease, autoimmunity, and lung carcinogenesis, 102-108 possibly explaining the high prevalence of thrombotic complications in affected patients.

The interplay between cancer and platelets supports various steps of the metastatic cascade. 1,2,20,109 The anti-thrombotic ef-

fect of sEV- $\beta_2$  blockade might reduce the release of pro-metastatic factors by activated platelets or impair platelet coating of tumor cells to reduce metastasis. However, treatment with anti- $\beta_2$  antibody in mice with advanced disease also yielded significant shrinkage of metastatic nodules. As integrin  $\beta_2$  is expressed by various immune cells, we cannot exclude the possibility of reduced activity or recruitment of pro-tumorigenic  $\beta_2$  immune cells contributing to the anti-metastatic effects of  $\beta_2$  blockade. Before the reduced activity of the anti-metastatic effects of  $\beta_2$  blockade.

Our work also supports the notion of cancer as a systemic disease. We showed that intravenous injection of sEVs mimics the clinical presentation of DIC,  $^{14}$  suggesting that continuous shedding of  $\beta_2^+$  sEVs by the lung PTN contributes to a hypercoagulable state that may predispose to multi-organ dysfunction and failure. Thus, there is an unmet need to develop tailored multi-organ and systemic treatments that prevent tumor progression and systemic co-morbidities.

In conclusion, we have provided novel evidence that active integrin  ${\beta_2}^+$  sEVs from either non-metastatic or peri-metastatic lung PTNs initiate thrombosis in cancer patients and may serve as a predictive/prognostic biomarker for thrombosis risk assessment. Moreover, targeting  $\alpha_X\beta_2$  heterodimers may both prevent thrombosis and reduce metastatic diseases in advanced-cancer patients.

### **Limitations of the study**

This study provides evidence of systemic cancer-associated thrombosis induced by sEVs from resident IMs in the lung PTN. Whereas lung metastasis is not required for PTN formation, CXCL13 from primary or metastatic tumors directs IM reprogramming. Thus, this signaling axis may not be prominent in cancers with low *cxcl13* expression, such as glioblastoma, where tumor-associated hemostatic factors, including podoplanin, determine thrombosis risk. Further investigation is required to establish the cancer type-specific correlation between *cxcl13* expression, PTN formation, and thrombosis risk.

Although most of our studies were performed following injection of a bolus of sEVs and examining lungs as the main site of thrombosis, we also utilized a sub-lethal dose of sEVs and identified microclots in a variety of other organs, including limb muscles, heart, brain, and liver (Figure S1G). Future studies should address the effects of endogenous PTN-derived  $\beta_2^+$  sEVs on thrombotic and/or hemorrhagic events in tumor-bearing mice.

### RESOURCE AVAILABILITY

### Lead contact

Further information and requests for resources and reagents should be directed to and will be fulfilled by the lead contact, David Lyden (dcl2001@med.cornell.edu).

### Materials availability

This study did not generate new unique reagents.

### Data and code availability

- All data reported in this paper will be shared by the lead contact upon request.
- This paper does not report original code.
- Any additional information required to reanalyze the data reported in this
  paper is available from the lead contact upon request.

![](_page_16_Picture_0.jpeg)

![](_page_16_Picture_1.jpeg)

### ACKNOWLEDGMENTS

The authors thank Barry Coller for the expert advice and guidance on platelet experiments and for providing the 6D1 and 7E3 antibodies. The authors acknowledge the Epigenomics Core, Flow Cytometry Core, and Electron Microscopy and Histology Core facilities (Weill Cornell Medicine), the Molecular Cytology Core, and the Laboratory of Comparative Pathology (MSKCC) for their high-quality service. The authors gratefully acknowledge support from the United States Department of Defense (W81XWH-20-1-0263 to S.L.); the WCM Children Health Investigators Fund (to S.L.); the National Cancer Institute (CA232093 to D.L., CA218513 to D.L. and H.Z., and CA285856-01A1 and CA234617-01 to D.R.J.); the Thompson Family Foundation (to D.L. and D.K.); the Tortolani Foundation, Lerner Foundation, and Sussman Fund (to S.L., J.F.B., and D.L.); the MSKCC core grant P30 CA008748 (to J.F.B.); the AHEPA Vth District Cancer Research Foundation (to S.L. and D.L.); and the Pediatric Oncology Experimental Therapeutics Investigator's Consortium, the Malcolm Hewitt Weiner Foundation, the Manning Foundation, the Sohn Foundation, the Children's Cancer and Blood Foundation, and the Hartwell Foundation (to D.L.).

### AUTHOR CONTRIBUTIONS

Conceptualization, S.L., Y.O., I.M., D.E., J.F.B., D.M.S., and D.L.; methodology, S.L., Y.O., J. Geri, Y.H.K., Y.R., L.B., and D.E.; software, D.E.; formal analysis, J. Geri, J. Gu, U.B., C.P., A.E.P., and H.M.; investigation, S.L., Y.O., C.M.K., J.G., Y.H.K., L. Bojmar, L.S., Y.S., M.C., P.L., O.M.J., T.A., L. Borriello, and T.M.; resources, P.M.G., M.A.H., H.B.L., E.G.D., X.J., M.S., Y.R., K.M., D.P., E.M.O., W.R.J., D.K., S.M.C., L.G.-R., D.R.J., and D.M.S.; writing – original draft, S.L. and D.L.; writing – review and editing, S.L., Y.O., C.M.K., L.S., H.Z., H.L.R., J.B.B., N.B., I.M., D.E., J.F.B., D.M.S., and D.L.; visualization, S.L., Y.O., J. Gu, U.B., and D.E.; supervision, Y.R., K.M., J.S.C., V.P., I.M., J.F.B., D.M.S., and D.L.; funding acquisition, S.L., J.F.B., and D.L.

### DECLARATION OF INTERESTS

Y.O. is employed by Daiichi Sankyo Co., Ltd., Tokyo, Japan. H.L.R. holds shares in Atossa Therapeutics, Inc. but declares no non-financial competing interests. H.L.R. is the lead independent director of Atossa Therapeutics, Inc. D.L. is on the scientific advisory board of Aufbau Holdings, Ltd. D.L. receives research grant support from Aufbau/Sonder Research X and Atossa Therapeutics.

### STAR+METHODS

Detailed methods are provided in the online version of this paper and include the following:

- d KEY RESOURCES TABLE
- d EXPERIMENTAL MODEL AND STUDY PARTICIPANT DETAILS
  - B Cell lines
  - B Animals
  - B Human participants
- d METHOD DETAILS
  - B Tumor inoculation
  - B Platelet isolation and aggregometry
  - B Platelet adhesion assay
  - B sEV isolation from tissues, cell lines, and plasma
  - B Immunohistochemistry
  - B Lung intravital microscopy
  - B Immunofluorescence
  - B Flow cytometry of lungs
  - B Liquid chromatography mass spectrometry
  - B dSTORM imaging
  - B Macrophage isolation and treatment
  - B scRNA-seq and CITEseq analysis
  - <sup>B</sup> mMap
  - B Single Molecule Force Spectroscopy (SMFS)
  - B Co-Immunoprecipitation

### d QUANTIFICATION AND STATISTICAL ANALYSIS

B Statistical analysis

### SUPPLEMENTAL INFORMATION

Supplemental information can be found online at https://doi.org/10.1016/j.cell. 2025.01.025.

Received: January 30, 2024 Revised: August 8, 2024 Accepted: January 15, 2025 Published: February 11, 2025

#### REFERENCES

- 1. Lucotti, S., and Muschel, R.J. (2020). Platelets and metastasis: new implications of an old interplay. Front. Oncol. *10*, 1350. https://doi.org/10. 3389/fonc.2020.01350.
- 2. Lucotti, S., Cerutti, C., Soyer, M., Gil-Bernabe´ , A.M., Gomes, A.L., Allen, P.D., Smart, S., Markelc, B., Watson, K., Armstrong, P.C., et al. (2019). Aspirin blocks formation of metastatic intravascular niches by inhibiting platelet-derived COX-1/thromboxane A2. J. Clin. Invest. *129*, 1845– 1862. https://doi.org/10.1172/JCI121985.
- 3. Gasic, G.J., Gasic, T.B., and Stewart, C.C. (1968). Antimetastatic effects associated with platelet reduction. Proc. Natl. Acad. Sci. USA *61*, 46–52. https://doi.org/10.1073/pnas.61.1.46.
- 4. Prandoni, P., Falanga, A., and Piccioli, A. (2005). Cancer and venous thromboembolism. Lancet Oncol. *6*, 401–410. https://doi.org/10.1016/ S1470-2045(05)70207-2.
- 5. Tuzovic, M., Herrmann, J., Iliescu, C., Marmagkiolis, K., Ziaeian, B., and Yang, E.H. (2018). Arterial thrombosis in patients with cancer. Curr. Treat. Options Cardiovasc. Med. *20*, 40. https://doi.org/10.1007/s11936-018- 0635-x.
- 6. Thachil, J., Falanga, A., Levi, M., Liebman, H., and Di Nisio, M.; Scientific; Standardization Committee; International Society; Thrombosis; Hemostasis (2015). Management of cancer-associated disseminated intravascular coagulation: guidance from the SSC of the ISTH. J. Thromb. Haemost. *13*, 671–675. https://doi.org/10.1111/jth.12838.
- 7. Herna´ ndez-Ramı´rez, O., Sa´ nchez-Hurtado, L.A., Ferrer-Burgos, G., Guevara-Garcı´a, H., Garcı´a-Guillen, F.J., and N˜ amendys-Silva, S.A. (2019). Incidence of disseminated intravascular coagulation in critically ill cancer patients. J. Intensive Care Soc. *20*, NP17–NP18. https://doi. org/10.1177/1751143719840262.
- 8. Sørensen, H.T., Pedersen, L., van Es, N., Bu¨ ller, H.R., and Horva´th-Puho´ , E. (2023). Impact of venous thromboembolism on the mortality in patients with cancer: a population-based cohort study. Lancet Reg Health Eur. *34*, 100739. https://doi.org/10.1016/j.lanepe.2023.100739.
- 9. Carlson, K.S., and DeSancho, M.T. (2010). Hematological issues in critically ill patients with cancer. Crit. Care Clin. *26*, 107–132. https://doi.org/ 10.1016/j.ccc.2009.09.006.
- 10. Sallah, S., Wan, J.Y., Nguyen, N.P., Hanrahan, L.R., and Sigounas, G. (2001). Disseminated intravascular coagulation in solid tumors: clinical and pathologic study. Thromb. Haemost. *86*, 828–833.
- 11. Khorana, A.A., DeSancho, M.T., Liebman, H., Rosovsky, R., Connors, J.M., and Zwicker, J. (2021). Prediction and prevention of cancer-associated thromboembolism. Oncologist *26*, e2–e7. https://doi.org/10. 1002/onco.13569.
- 12. Libourel, E.J., Klerk, C.P.W., van Norden, Y., de Maat, M.P.M., Kruip, M.J., Sonneveld, P., Lo¨ wenberg, B., and Leebeek, F.W.G. (2016). Disseminated intravascular coagulation at diagnosis is a strong predictor for thrombosis in acute myeloid leukemia. Blood *128*, 1854–1861. https://doi.org/10.1182/blood-2016-02-701094.
- 13. Colman, R.W., and Rubin, R.N. (1990). Disseminated intravascular coagulation due to malignancy. Semin. Oncol. *17*, 172–186.

![](_page_17_Picture_0.jpeg)

![](_page_17_Picture_1.jpeg)

- 14. Saba, H.I., Morelli, G.A., and Saba, R.I. (2009). Disseminated intravascular coagulation (DIC) in cancer. Cancer Treat. Res. *148*, 137–156. https://doi.org/10.1007/978-0-387-79962-9\_9.
- 15. Menapace, L.A., Peterson, D.R., Berry, A., Sousou, T., and Khorana, A.A. (2011). Symptomatic and incidental thromboembolism are both associated with mortality in pancreatic cancer. Thromb. Haemost. *106*, 371–378. https://doi.org/10.1160/TH10-12-0789.
- 16. Khorana, A.A., and Fine, R.L. (2004). Pancreatic cancer and thromboembolic disease. Lancet Oncol. *5*, 655–663. https://doi.org/10.1016/S1470- 2045(04)01606-7.
- 17. Campello, E., Ilich, A., Simioni, P., and Key, N.S. (2019). The relationship between pancreatic cancer and hypercoagulability: a comprehensive review on epidemiological and biological issues. Br. J. Cancer *121*, 359–371. https://doi.org/10.1038/s41416-019-0510-x.
- 18. Grilz, E., Ko¨ nigsbru¨ gge, O., Posch, F., Schmidinger, M., Pirker, R., Lang, I.M., Pabinger, I., and Ay, C. (2018). Frequency, risk factors, and impact on mortality of arterial thromboembolism in patients with cancer. Haematologica *103*, 1549–1556. https://doi.org/10.3324/haematol.2018.192419.
- 19. Khorana, A.A. (2010). Venous thromboembolism and prognosis in cancer. Thromb. Res. *125*, 490–493. https://doi.org/10.1016/j.thromres. 2009.12.023.
- 20. Gil-Bernabe´ , A.M., Lucotti, S., and Muschel, R.J. (2013). Coagulation and metastasis: what does the experimental literature tell us? Br. J. Haematol. *162*, 433–441. https://doi.org/10.1111/bjh.12381.
- 21. Kearon, C., and Kahn, S.R. (2020). Long-term treatment of venous thromboembolism. Blood *135*, 317–325. https://doi.org/10.1182/blood. 2019002364.
- 22. Rothwell, P.M., Wilson, M., Price, J.F., Belch, J.F.F., Meade, T.W., and Mehta, Z. (2012). Effect of daily aspirin on risk of cancer metastasis: a study of incident cancers during randomised controlled trials. Lancet *379*, 1591–1601. https://doi.org/10.1016/S0140-6736(12)60209-8.
- 23. Brenner, B., Hull, R., Arya, R., Beyer-Westendorf, J., Douketis, J., Elalamy, I., Imberti, D., and Zhai, Z. (2019). Evaluation of unmet clinical needs in prophylaxis and treatment of venous thromboembolism in high-risk patient groups: cancer and critically ill. Thromb. J. *17*, 6. https://doi. org/10.1186/s12959-019-0196-6.
- 24. Macbeth, F., Noble, S., Evans, J., Ahmed, S., Cohen, D., Hood, K., Knoyle, D., Linnane, S., Longo, M., Moore, B., et al. (2016). Randomized Phase III trial of standard therapy plus low molecular weight heparin in patients with lung cancer: FRAGMATIC trial. J. Clin. Oncol. *34*, 488–494. https://doi.org/10.1200/JCO.2015.64.0268.
- 25. Hisada, Y., and Mackman, N. (2023). Mechanisms of cancer-associated thrombosis. Res. Pract. Thromb. Haemost. *7*, 100123. https://doi.org/10. 1016/j.rpth.2023.100123.
- 26. Wang, J.G., Geddings, J.E., Aleman, M.M., Cardenas, J.C., Chantrathammachart, P., Williams, J.C., Kirchhofer, D., Bogdanov, V.Y., Bach, R.R., Rak, J., et al. (2012). Tumor-derived tissue factor activates coagulation and enhances thrombosis in a mouse xenograft model of human pancreatic cancer. Blood *119*, 5543–5552. https://doi.org/10.1182/ blood-2012-01-402156.
- 27. Khorana, A.A., Mackman, N., Falanga, A., Pabinger, I., Noble, S., Ageno, W., Moik, F., and Lee, A.Y.Y. (2022). Cancer-associated venous thromboembolism. Nat. Rev. Dis. Primers *8*, 11. https://doi.org/10.1038/ s41572-022-00336-y.
- 28. Tawil, N., Bassawon, R., Meehan, B., Nehme, A., Montermini, L., Gayden, T., De Jay, N., Spinelli, C., Chennakrishnaiah, S., Choi, D., et al. (2021). Glioblastoma cell populations with distinct oncogenic programs release podoplanin as procoagulant extracellular vesicles. Blood Adv. *5*, 1682–1694. https://doi.org/10.1182/bloodadvances.2020002998.
- 29. Hoshino, A., Costa-Silva, B., Shen, T.L., Rodrigues, G., Hashimoto, A., Tesic Mark, M., Molina, H., Kohsaka, S., Di Giannatale, A., Ceder, S.,

- et al. (2015). Tumour exosome integrins determine organotropic metastasis. Nature *527*, 329–335. https://doi.org/10.1038/nature15756.
- 30. Hoshino, A., Kim, H.S., Bojmar, L., Gyan, K.E., Cioffi, M., Hernandez, J., Zambirinis, C.P., Rodrigues, G., Molina, H., Heissel, S., et al. (2020). Extracellular vesicle and particle biomarkers define multiple human cancers. Cell *182*, 1044–1061.e18. https://doi.org/10.1016/j.cell.2020. 07.009.
- 31. Peinado, H., Aleckovi c, M., Lavotshkin, S., Matei, I., Costa-Silva, B., Mor eno-Bueno, G., Hergueta-Redondo, M., Williams, C., Garcı´a-Santos, G., Ghajar, C., et al. (2012). Melanoma exosomes educate bone marrow progenitor cells toward a pro-metastatic phenotype through MET. Nat. Med. *18*, 883–891. https://doi.org/10.1038/nm.2753.
- 32. Peinado, H., Zhang, H., Matei, I.R., Costa-Silva, B., Hoshino, A., Rodrigues, G., Psaila, B., Kaplan, R.N., Bromberg, J.F., Kang, Y., et al. (2017). Pre-metastatic niches: organ-specific homes for metastases. Nat. Rev. Cancer *17*, 302–317. https://doi.org/10.1038/nrc.2017.6.
- 33. Rodrigues, G., Hoshino, A., Kenific, C.M., Matei, I.R., Steiner, L., Freitas, D., Kim, H.S., Oxley, P.R., Scandariato, I., Casanova-Salas, I., et al. (2019). Tumour exosomal CEMIP protein promotes cancer cell colonization in brain metastasis. Nat. Cell Biol. *21*, 1403–1412. https://doi.org/10. 1038/s41556-019-0404-4.
- 34. Zhang, H., Freitas, D., Kim, H.S., Fabijanic, K., Li, Z., Chen, H., Mark, M.T., Molina, H., Martin, A.B., Bojmar, L., et al. (2018). Identification of distinct nanoparticles and subsets of extracellular vesicles by asymmetric flow field-flow fractionation. Nat. Cell Biol. *20*, 332–343. https:// doi.org/10.1038/s41556-018-0040-4.
- 35. Costa-Silva, B., Aiello, N.M., Ocean, A.J., Singh, S., Zhang, H., Thakur, B.K., Becker, A., Hoshino, A., Mark, M.T., Molina, H., et al. (2015). Pancreatic cancer exosomes initiate pre-metastatic niche formation in the liver. Nat. Cell Biol. *17*, 816–826. https://doi.org/10.1038/ncb3169.
- 36. Dvorak, H.F., Quay, S.C., Orenstein, N.S., Dvorak, A.M., Hahn, P., Bitzer, A.M., and Carvalho, A.C. (1981). Tumor shedding and coagulation. Science *212*, 923–924. https://doi.org/10.1126/science.7195067.
- 37. Mesri, M., and Altieri, D.C. (1999). Leukocyte microparticles stimulate endothelial cell cytokine release and tissue factor induction in a JNK1 signaling pathway. J. Biol. Chem. *274*, 23111–23118. https://doi.org/ 10.1074/jbc.274.33.23111.
- 38. Biro´ , E., Sturk-Maquelin, K.N., Vogel, G.M.T., Meuleman, D.G., Smit, M.J., Hack, C.E., Sturk, A., and Nieuwland, R. (2003). Human cell-derived microparticles promote thrombus formation in vivo in a tissue factordependent manner. J. Thromb. Haemost. *1*, 2561–2568. https://doi. org/10.1046/j.1538-7836.2003.00456.x.
- 39. Falati, S., Liu, Q., Gross, P., Merrill-Skoloff, G., Chou, J., Vandendries, E., Celi, A., Croce, K., Furie, B.C., and Furie, B. (2003). Accumulation of tissue factor into developing thrombi in vivo is dependent upon microparticle P-selectin glycoprotein ligand 1 and platelet P-selectin. J. Exp. Med. *197*, 1585–1598. https://doi.org/10.1084/jem.20021868.
- 40. Falanga, A., Panova-Noeva, M., and Russo, L. (2009). Procoagulant mechanisms in tumour cells. Best Pract. Res. Clin. Haematol. *22*, 49–60. https://doi.org/10.1016/j.beha.2008.12.009.
- 41. Zwicker, J.I., Furie, B.C., Kos, C.A., LaRocca, T., Bauer, K.A., and Furie, B. (2005). Trousseau's syndrome revisited: tissue factor-bearing microparticles in pancreatic cancer. Blood *106*, 259.
- 42. Zwicker, J.I., Liebman, H.A., Neuberg, D., Lacroix, R., Bauer, K.A., Furie, B.C., and Furie, B. (2009). Tumor-derived tissue factor-bearing microparticles are associated with venous thromboembolic events in malignancy. Clin. Cancer Res. *15*, 6830–6840. https://doi.org/10.1158/1078-0432. CCR-09-0371.
- 43. van Doormaal, F., Kleinjan, A., Berckmans, R.J., Mackman, N., Manly, D., Kamphuisen, P.W., Richel, D.J., Bu¨ ller, H.R., Sturk, A., and Nieuwland, R. (2012). Coagulation activation and microparticle-associated coagulant activity in cancer patients. An exploratory prospective study. Thromb. Haemost. *108*, 160–165. https://doi.org/10.1160/TH12-02-0099.

# Article

![](_page_18_Picture_1.jpeg)

- 44. Thaler, J., Ay, C., Mackman, N., Bertina, R.M., Kaider, A., Marosi, C., Key, N.S., Barcel, D.A., Scheithauer, W., Kornek, G., et al. (2012). Microparticle-associated tissue factor activity, venous thromboembolism and mortality in pancreatic, gastric, colorectal and brain cancer patients. J. Thromb. Haemost. *10*, 1363–1370. https://doi.org/10.1111/j.1538- 7836.2012.04754.x.
- 45. Herna´ ndez, C., Orbe, J., Roncal, C., Alvarez-Hernandez, M., Martinez de Lizarrondo, S., Alves, M.T., Garcı´a Mata, J., and Pa´ramo, J.A. (2013). Tissue factor expressed by microparticles is associated with mortality but not with thrombosis in cancer patients. Thromb. Haemost. *110*, 598–608. https://doi.org/10.1160/TH13-02-0122.
- 46. Bharthuar, A., Khorana, A.A., Hutson, A., Wang, J.G., Key, N.S., Mackman, N., and Iyer, R.V. (2013). Circulating microparticle tissue factor, thromboembolism and survival in pancreaticobiliary cancers. Thromb. Res. *132*, 180–184. https://doi.org/10.1016/j.thromres.2013.06.026.
- 47. van Es, N., Hisada, Y., Di Nisio, M., Cesarman, G., Kleinjan, A., Mahe´ , I., Otten, H.M., Kamphuisen, P.W., Berckmans, R.J., Bu¨ ller, H.R., et al. (2018). Extracellular vesicles exposing tissue factor for the prediction of venous thromboembolism in patients with cancer: A prospective cohort study. Thromb. Res. *166*, 54–59. https://doi.org/10.1016/j.thromres. 2018.04.009.
- 48. Bang, O.Y., Chung, J.W., Lee, M.J., Kim, S.J., Cho, Y.H., Kim, G.M., Chung, C.S., Lee, K.H., Ahn, M.J., and Moon, G.J. (2016). Cancer cellderived extracellular vesicles are associated with coagulopathy causing ischemic stroke via tissue factor-independent way: the OASIS-CANCER study. PLoS One *11*, e0159170. https://doi.org/10.1371/journal.pone. 0159170.
- 49. Leal, A.C., Mizurini, D.M., Gomes, T., Rochael, N.C., Saraiva, E.M., Dias, M.S., Werneck, C.C., Sielski, M.S., Vicente, C.P., and Monteiro, R.Q. (2017). Tumor-derived exosomes induce the formation of neutrophil extracellular traps: implications for the establishment of cancer-associated thrombosis. Sci. Rep. *7*, 6438. https://doi.org/10.1038/s41598- 017-06893-7.
- 50. Gomes, F.G., Sandim, V., Almeida, V.H., Rondon, A.M.R., Succar, B.B., Hottz, E.D., Leal, A.C., Verc¸ oza, B.R.F., Rodrigues, J.C.F., Bozza, P.T., et al. (2017). Breast-cancer extracellular vesicles induce platelet activation and aggregation by tissue factor-independent and -dependent mechanisms. Thromb. Res. *159*, 24–32. https://doi.org/10.1016/j. thromres.2017.09.019.
- 51. Sachetto, A.T.A., Archibald, S.J., Hisada, Y., Rosell, A., Havervall, S., van Es, N., Nieuwland, R., Campbell, R.A., Middleton, E.A., Rondina, M.T., et al. (2023). Tissue factor activity of small and large extracellular vesicles in different diseases. Res. Pract. Thromb. Haemost. *7*, 100124. https:// doi.org/10.1016/j.rpth.2023.100124.
- 52. Garnier, D., Magnus, N., Lee, T.H., Bentley, V., Meehan, B., Milsom, C., Montermini, L., Kislinger, T., and Rak, J. (2012). Cancer cells induced to express mesenchymal phenotype release exosome-like extracellular vesicles carrying tissue factor. J. Biol. Chem. *287*, 43565–43572. https://doi.org/10.1074/jbc.M112.401760.
- 53. Maddipati, R., and Stanger, B.Z. (2015). Pancreatic cancer metastases harbor evidence of polyclonality. Cancer Discov. *5*, 1086–1097. https:// doi.org/10.1158/2159-8290.CD-15-0120.
- 54. Evans, R.A., Diamond, M.S., Rech, A.J., Chao, T., Richardson, M.W., Lin, J.H., Bajor, D.L., Byrne, K.T., Stanger, B.Z., Riley, J.L., et al. (2016). Lack of immunoediting in murine pancreatic cancer reversed with neoantigen. JCI Insight *1*, e88328. https://doi.org/10.1172/jci.insight.88328.
- 55. Entenberg, D., Voiculescu, S., Guo, P., Borriello, L., Wang, Y., Karagiannis, G.S., Jones, J., Baccay, F., Oktay, M., and Condeelis, J. (2018). A permanent window for the murine lung enables high-resolution imaging of cancer metastasis. Nat. Methods *15*, 73–80. https://doi.org/10.1038/ nmeth.4511.
- 56. Rossier, O., Octeau, V., Sibarita, J.B., Leduc, C., Tessier, B., Nair, D., Gatterdam, V., Destaing, O., Albige` s-Rizo, C., Tampe´ , R., et al. (2012). Integrins beta1 and beta3 exhibit distinct dynamic nanoscale organizations

- inside focal adhesions. Nat. Cell Biol. *14*, 1057–1067. https://doi.org/10. 1038/ncb2588.
- 57. Ivaska, J. (2012). Unanchoring integrins in focal adhesions. Nat. Cell Biol. *14*, 981–983. https://doi.org/10.1038/ncb2592.
- 58. Scharffetter-Kochanek, K., Lu, H., Norman, K., van Nood, N., Munoz, F., Grabbe, S., McArthur, M., Lorenzo, I., Kaplan, S., Ley, K., et al. (1998). Spontaneous skin ulceration and defective T cell function in CD18 null mice. J. Exp. Med. *188*, 119–131. https://doi.org/10.1084/jem.188. 1.119.
- 59. Liu, Y., Jennings, N.L., Dart, A.M., and Du, X.J. (2012). Standardizing a simpler, more sensitive and accurate tail bleeding assay in mice. World J. Exp. Med. *2*, 30–36. https://doi.org/10.5493/wjem.v2.i2.30.
- 60. Shrestha, N., Bahnan, W., Wiley, D.J., Barber, G., Fields, K.A., and Schesser, K. (2012). Eukaryotic initiation factor 2 (eIF2) signaling regulates proinflammatory cytokine expression and bacterial invasion. J. Biol. Chem. *287*, 28738–28744. https://doi.org/10.1074/jbc.M112. 375915.
- 61. Weisser, S.B., McLarren, K.W., Voglmaier, N., van Netten-Thomas, C.J., Antov, A., Flavell, R.A., and Sly, L.M. (2011). Alternative activation of macrophages by IL-4 requires SHIP degradation. Eur. J. Immunol. *41*, 1742–1753. https://doi.org/10.1002/eji.201041105.
- 62. Marongiu, L., Mingozzi, F., Cigni, C., Marzi, R., Di Gioia, M., Garre` , M., Parazzoli, D., Sironi, L., Collini, M., Sakaguchi, R., et al. (2021). Inositol 1,4,5-trisphosphate 3-kinase B promotes Ca(2+) mobilization and the inflammatory activity of dendritic cells. Sci. Signal. *14*, eaaz2120. https:// doi.org/10.1126/scisignal.aaz2120.
- 63. Lee, M.S., and Bensinger, S.J. (2022). Reprogramming cholesterol metabolism in macrophages and its role in host defense against cholesteroldependent cytolysins. Cell. Mol. Immunol. *19*, 327–336. https://doi.org/ 10.1038/s41423-021-00827-0.
- 64. Vardhana, S.A., Hwee, M.A., Berisa, M., Wells, D.K., Yost, K.E., King, B., Smith, M., Herrera, P.S., Chang, H.Y., Satpathy, A.T., et al. (2020). Impaired mitochondrial oxidative phosphorylation limits the self-renewal of T cells exposed to persistent antigen. Nat. Immunol. *21*, 1022–1033. https://doi.org/10.1038/s41590-020-0725-2.
- 65. Gibbings, S.L., Thomas, S.M., Atif, S.M., McCubbrey, A.L., Desch, A.N., Danhorn, T., Leach, S.M., Bratton, D.L., Henson, P.M., Janssen, W.J., et al. (2017). Three unique interstitial macrophages in the murine lung at steady state. Am. J. Respir. Cell Mol. Biol. *57*, 66–76. https://doi.org/ 10.1165/rcmb.2016-0361OC.
- 66. Ural, B.B., Yeung, S.T., Damani-Yokota, P., Devlin, J.C., de Vries, M., Vera-Licona, P., Samji, T., Sawai, C.M., Jang, G., Perez, O.A., et al. (2020). Identification of a nerve-associated, lung-resident interstitial macrophage subset with distinct localization and immunoregulatory properties. Sci. Immunol. *5*, eaax8756. https://doi.org/10.1126/sciimmunol.aax8756.
- 67. Ma, R.Y., Black, A., and Qian, B.Z. (2022). Macrophage diversity in cancer revisited in the era of single-cell omics. Trends Immunol. *43*, 546–563. https://doi.org/10.1016/j.it.2022.04.008.
- 68. Jayasingam, S.D., Citartan, M., Thang, T.H., Mat Zin, A.A., Ang, K.C., and Ch'ng, E.S. (2019). Evaluating the Polarization of Tumor-Associated Macrophages Into M1 and M2 Phenotypes in Human Cancer Tissue: Technicalities and Challenges in Routine Clinical Practice. Front. Oncol. *9*, 1512. https://doi.org/10.3389/fonc.2019.01512.
- 69. Schyns, J., Bai, Q., Ruscitti, C., Radermecker, C., De Schepper, S., Chakarov, S., Farnir, F., Pirottin, D., Ginhoux, F., Boeckxstaens, G., et al. (2019). Non-classical tissue monocytes and two functionally distinct populations of interstitial macrophages populate the mouse lung. Nat. Commun. *10*, 3964. https://doi.org/10.1038/s41467-019-11843-0.
- 70. Lechner, A.J., Driver, I.H., Lee, J., Conroy, C.M., Nagle, A., Locksley, R.M., and Rock, J.R. (2017). Recruited monocytes and Type 2 Immunity Promote Lung Regeneration following Pneumonectomy. Cell Stem Cell *21*, 120–134.e7. https://doi.org/10.1016/j.stem.2017.03.024.

![](_page_19_Picture_0.jpeg)

![](_page_19_Picture_1.jpeg)

- 71. Geri, J.B., Oakley, J.V., Reyes-Robles, T., Wang, T., McCarver, S.J., White, C.H., Rodriguez-Rivera, F.P., Parker, D.L., Jr., Hett, E.C., Fadeyi, O.O., et al. (2020). Microenvironment mapping via Dexter energy transfer on immune cells. Science *367*, 1091–1097. https://doi.org/10.1126/science.aay4106.
- 72. Armstrong, P.C.J., Kirkby, N.S., Chan, M.V., Finsterbusch, M., Hogg, N., Nourshargh, S., and Warner, T.D. (2015). Novel whole blood assay for phenotyping platelet reactivity in mice identifies ICAM-1 as a mediator of platelet-monocyte interaction. Blood *126*, e11–e18. https://doi.org/ 10.1182/blood-2015-01-621656.
- 73. Fagerholm, S.C., Guenther, C., Llort Asens, M., Savinko, T., and Uotila, L.M. (2019). Beta2-Integrins and interacting proteins in leukocyte trafficking, immune suppression, and immunodeficiency disease. Front. Immunol. *10*, 254. https://doi.org/10.3389/fimmu.2019.00254.
- 74. Tang, R.H., Tng, E., Law, S.K.A., and Tan, S.M. (2005). Epitope mapping of monoclonal antibody to integrin alphaL beta2 hybrid domain suggests different requirements of affinity states for intercellular adhesion molecules (ICAM)-1 and ICAM-3 binding. J. Biol. Chem. *280*, 29208–29216. https://doi.org/10.1074/jbc.M503239200.
- 75. Wang, Y., Gao, H., Shi, C., Erhardt, P.W., Pavlovsky, A., A.S., D., Bledzka, K., Ustinov, V., Zhu, L., Qin, J., et al. (2017). Leukocyte integrin Mac-1 regulates thrombosis via interaction with platelet GPIbalpha. Nat. Commun. *8*, 15559. https://doi.org/10.1038/ncomms15559.
- 76. Flick, M.J., Du, X., Witte, D.P., Jirouskova´ , M., Soloviev, D.A., Busuttil, S.J., Plow, E.F., and Degen, J.L. (2004). Leukocyte engagement of fibrin( ogen) via the integrin receptor alphaMbeta2/Mac-1 is critical for host inflammatory response in vivo. J. Clin. Invest. *113*, 1596–1606. https://doi. org/10.1172/JCI20741.
- 77. Lishko, V.K., Yakubenko, V.P., Ugarova, T.P., and Podolnikova, N.P. (2018). Leukocyte integrin Mac-1 (CD11b/CD18, alphaMbeta2, CR3) acts as a functional receptor for platelet factor 4. J. Biol. Chem. *293*, 6869–6882. https://doi.org/10.1074/jbc.RA117.000515.
- 78. Hamad, O.A., Mitroulis, I., Fromell, K., Kozarcanin, H., Chavakis, T., Ricklin, D., Lambris, J.D., Ekdahl, K.N., and Nilsson, B. (2015). Contact activation of C3 enables tethering between activated platelets and polymorphonuclear leukocytes via CD11b/CD18. Thromb. Haemost. *114*, 1207–1217. https://doi.org/10.1160/TH15-02-0162.
- 79. Nording, H., Sauter, M., Lin, C., Steubing, R., Geisler, S., Sun, Y., Niethammer, J., Emschermann, F., Wang, Y., Zieger, B., et al. (2022). Activated platelets upregulate beta(2) integrin Mac-1 (CD11b/CD18) on dendritic cells, which mediates heterotypic cell-cell interaction. J. Immunol. *208*, 1729–1741. https://doi.org/10.4049/jimmunol.2100557.
- 80. Monroe, D.M., Hoffman, M., and Roberts, H.R. (2002). Platelets and thrombin generation. Arterioscler. Thromb. Vasc. Biol. *22*, 1381–1389. https://doi.org/10.1161/01.atv.0000031340.68494.34.
- 81. Gurung, S., Perocheau, D., Touramanidou, L., and Baruteau, J. (2021). The exosome journey: from biogenesis to uptake and intracellular signalling. Cell Commun. Signal. *19*, 47. https://doi.org/10.1186/s12964-021- 00730-1.
- 82. Yang, Z., Huo, Y., Zhou, S., Guo, J., Ma, X., Li, T., Fan, C., and Wang, L. (2022). Cancer cell-intrinsic XBP1 drives immunosuppressive reprogramming of intratumoral myeloid cells by promoting cholesterol production. Cell Metab. *34*, 2018–2035.e8. https://doi.org/10.1016/j.cmet.2022. 10.010.
- 83. Scho¨ nning, A., Karle´ n, J., Frisk, T., Heyman, M., Svahn, J.E., Øra, I., Kawan, L., Holmqvist, B.M., Bjo¨ rklund, C., Harila-Saari, A., et al. (2017). Venous thrombosis in children and adolescents with Hodgkin lymphoma in Sweden. Thromb. Res. *152*, 64–68. https://doi.org/10.1016/j. thromres.2017.02.011.
- 84. Barg, A.A., and Kenet, G. (2022). Cancer associated thrombosis in pediatric patients. Best Pract. Res. Clin. Haematol. *35*, 101352. https://doi. org/10.1016/j.beha.2022.101352.
- 85. Lee, A.Y.Y. (2017). When can we stop anticoagulation in patients with cancer-associated thrombosis? Hematology Am. Soc. Hematol. Educ.

- Program *2017*, 128–135. https://doi.org/10.1182/asheducation-2017. 1.128.
- 86. Paterno, G., Palmieri, R., Tesei, C., Nunzi, A., Ranucci, G., Mallegni, F., Moretti, F., Meddi, E., Tiravanti, I., Marinoni, M., et al. (2024). The ISTH DIC-score predicts early mortality in patients with non-promyelocitic acute myeloid leukemia. Thromb. Res. *236*, 30–36. https://doi.org/10. 1016/j.thromres.2024.02.017.
- 87. Riaz, I.B., Fuentes, H., Deng, Y., Naqvi, S.A.A., Yao, X., Sangaralingham, L.R., Houghton, D.E., Padrnos, L.J., Shamoun, F.E., Wysokinski, W.E., et al. (2023). Comparative effectiveness of anticoagulants in patients with cancer-associated thrombosis. JAMA Netw. Open *6*, e2325283. https://doi.org/10.1001/jamanetworkopen.2023.25283.
- 88. Arepally, G.M. (2017). Heparin-induced thrombocytopenia. Blood *129*, 2864–2872. https://doi.org/10.1182/blood-2016-11-709873.
- 89. Prandoni, P., Falanga, A., and Piccioli, A. (2007). Cancer, thrombosis and heparin-induced thrombocytopenia. Thromb. Res. *120*, S137–S140. https://doi.org/10.1016/S0049-3848(07)70143-3.
- 90. Baran, K.W., Nguyen, M., McKendall, G.R., Lambrew, C.T., Dykstra, G., Palmeri, S.T., Gibbons, R.J., Borzak, S., Sobel, B.E., Gourlay, S.G., et al. (2001). Double-blind, randomized trial of an anti-CD18 antibody in conjunction with recombinant tissue plasminogen activator for acute myocardial infarction: limitation of myocardial infarction following thrombolysis in acute myocardial infarction (LIMIT AMI) study. Circulation *104*, 2778–2783. https://doi.org/10.1161/hc4801.100236.
- 91. Becker, K.J. (2002). Anti-leukocyte antibodies: LeukArrest (Hu23F2G) and enlimomab (R6.5) in acute stroke. Curr. Med. Res. Opin. *18*, s18–s22. https://doi.org/10.1185/030079902125000688.
- 92. Jimenez, J.J., Jy, W., Mauro, L.M., Horstman, L.L., and Ahn, Y.S. (2001). Elevated endothelial microparticles in thrombotic thrombocytopenic purpura: findings from brain and renal microvascular cell culture and patients with active disease. Br. J. Haematol. *112*, 81–90.
- 93. Lima, L.G., Leal, A.C., Vargas, G., Porto-Carreiro, I., and Monteiro, R.Q. (2013). Intercellular transfer of tissue factor via the uptake of tumorderived microvesicles. Thromb. Res. *132*, 450–456. https://doi.org/10. 1016/j.thromres.2013.07.026.
- 94. Zifkos, K., Dubois, C., and Scha¨ fer, K. (2021). Extracellular vesicles and thrombosis: update on the clinical and experimental evidence. Int. J. Mol. Sci. *22*, 9317. https://doi.org/10.3390/ijms22179317.
- 95. Chakarov, S., Lim, H.Y., Tan, L., Lim, S.Y., See, P., Lum, J., Zhang, X.M., Foo, S., Nakamizo, S., Duan, K., et al. (2019). Two distinct interstitial macrophage populations coexist across tissues in specific subtissular niches. Science *363*, eaau0964. https://doi.org/10.1126/science. aau0964.
- 96. Johnston, L.K., Rims, C.R., Gill, S.E., McGuire, J.K., and Manicone, A.M. (2012). Pulmonary macrophage subpopulations in the induction and resolution of acute lung injury. Am. J. Respir. Cell Mol. Biol. *47*, 417–426. https://doi.org/10.1165/rcmb.2012-0090OC.
- 97. Kawano, H., Kayama, H., Nakama, T., Hashimoto, T., Umemoto, E., and Takeda, K. (2016). IL-10-producing lung interstitial macrophages prevent neutrophilic asthma. Int. Immunol. *28*, 489–501. https://doi.org/10.1093/ intimm/dxw012.
- 98. Schyns, J., Bureau, F., and Marichal, T. (2018). Lung interstitial macrophages: past, present, and future. J. Immunol. Res. *2018*, 5160794. https://doi.org/10.1155/2018/5160794.
- 99. Cyster, J.G. (1999). Chemokines and cell migration in secondary lymphoid organs. Science *286*, 2098–2102. https://doi.org/10.1126/science.286.5447.2098.
- 100. Moyron-Quiroz, J.E., Rangel-Moreno, J., Kusser, K., Hartson, L., Sprague, F., Goodrich, S., Woodland, D.L., Lund, F.E., and Randall, T.D. (2004). Role of inducible bronchus associated lymphoid tissue (iBALT) in respiratory immunity. Nat. Med. *10*, 927–934. https://doi.org/ 10.1038/nm1091.

# Article

![](_page_20_Picture_1.jpeg)

- 101. Fu, Y., Pajulas, A., Wang, J., Zhou, B., Cannon, A., Cheung, C.C.L., Zhang, J., Zhou, H., Fisher, A.J., Omstead, D.T., et al. (2022). Mouse pulmonary interstitial macrophages mediate the pro-tumorigenic effects of IL-9. Nat. Commun. *13*, 3811. https://doi.org/10.1038/s41467-022- 31596-7.
- 102. Rangel-Moreno, J., Moyron-Quiroz, J.E., Hartson, L., Kusser, K., and Randall, T.D. (2007). Pulmonary expression of CXC chemokine ligand 13, CC chemokine ligand 19, and CC chemokine ligand 21 is essential for local immunity to influenza. Proc. Natl. Acad. Sci. USA *104*, 10577– 10582. https://doi.org/10.1073/pnas.0700591104.
- 103. Wang, G.Z., Cheng, X., Zhou, B., Wen, Z.S., Huang, Y.C., Chen, H.B., Li, G.F., Huang, Z.L., Zhou, Y.C., Feng, L., et al. (2015). The chemokine CXCL13 in lung cancers associated with environmental polycyclic aromatic hydrocarbons pollution. eLife *4*, e09419. https://doi.org/10.7554/ eLife.09419.
- 104. Zhang, Y., Yu, K., Hu, S., Lou, Y., Liu, C., Xu, J., Li, R., Zhang, X., Wang, H., and Han, B. (2016). MDC and BLC are independently associated with the significant risk of early stage lung adenocarcinoma. Oncotarget *7*, 83051–83059. https://doi.org/10.18632/oncotarget.13031.
- 105. Vuga, L.J., Tedrow, J.R., Pandit, K.V., Tan, J., Kass, D.J., Xue, J., Chandra, D., Leader, J.K., Gibson, K.F., Kaminski, N., et al. (2014). C-X-C motif chemokine 13 (CXCL13) is a prognostic biomarker of idiopathic pulmonary fibrosis. Am. J. Respir. Crit. Care Med. *189*, 966–974. https://doi. org/10.1164/rccm.201309-1592OC.
- 106. Litsiou, E., Semitekolou, M., Galani, I.E., Morianos, I., Tsoutsa, A., Kara, P., Rontogianni, D., Bellenis, I., Konstantinou, M., Potaris, K., et al. (2013). CXCL13 production in B cells via toll-like receptor/lymphotoxin receptor signaling is involved in lymphoid neogenesis in chronic obstructive pulmonary disease. Am. J. Respir. Crit. Care Med. *187*, 1194–1202. https://doi.org/10.1164/rccm.201208-1543OC.
- 107. Rangel-Moreno, J., Hartson, L., Navarro, C., Gaxiola, M., Selman, M., and Randall, T.D. (2006). Inducible bronchus-associated lymphoid tissue (iBALT) in patients with pulmonary complications of rheumatoid arthritis. J. Clin. Invest. *116*, 3183–3194. https://doi.org/10.1172/JCI28756.
- 108. Eddens, T., Elsegeiny, W., Garcia-Hernadez, M.L., Castillo, P., Trevejo-Nunez, G., Serody, K., Campfield, B.T., Khader, S.A., Chen, K., Rangel-Moreno, J., et al. (2017). Pneumocystis-driven inducible bronchusassociated lymphoid tissue formation requires Th2 and Th17 immunity. Cell Rep. *18*, 3078–3090. https://doi.org/10.1016/j.celrep.2017.03.016.
- 109. Lucotti, S. (2022). Handbook of Cancer and Immunology (Springer).
- 110. Broutier, L., Andersson-Rolf, A., Hindley, C.J., Boj, S.F., Clevers, H., Koo, B.K., and Huch, M. (2016). Culture and establishment of self-renewing human and mouse adult liver and pancreas 3D organoids and their genetic manipulation. Nat. Protoc. *11*, 1724–1743. https://doi.org/10. 1038/nprot.2016.097.
- 111. Bojmar, L., Kim, H.S., Sugiura, K., Heissel, S., Lucotti, S., Cioffi, M., Johnson, K.E., Cohen-Gould, L., Zhang, H., Molina, H., et al. (2024). Protocol for cross-platform characterization of human and murine extracellular vesicles and particles. Star Protoc. *5*, 102754. https://doi.org/10.1016/ j.xpro.2023.102754.
- 112. Borriello, L., Traub, B., Coste, A., Oktay, M.H., and Entenberg, D. (2021). A permanent window for investigating cancer metastasis to the lung. J. Vis. Exp. https://doi.org/10.3791/62761.

- 113. Entenberg, D., Wyckoff, J., Gligorijevic, B., Roussos, E.T., Verkhusha, V.V., Pollard, J.W., and Condeelis, J. (2011). Setup and use of a two-laser multiphoton microscope for multichannel intravital fluorescence imaging. Nat. Protoc. *6*, 1500–1520. https://doi.org/10.1038/nprot.2011.376.
- 114. Rappsilber, J., Mann, M., and Ishihama, Y. (2007). Protocol for micro-purification, enrichment, pre-fractionation and storage of peptides for proteomics using StageTips. Nat. Protoc. *2*, 1896–1906. https://doi.org/10. 1038/nprot.2007.261.
- 115. Bunkenborg, J., Garcı´a, G.E., Paz, M.I.P., Andersen, J.S., and Molina, H. (2010). The minotaur proteome: avoiding cross-species identifications deriving from bovine serum in cell culture models. Proteomics *10*, 3040–3044. https://doi.org/10.1002/pmic.201000103.
- 116. Ka¨ ll, L., Canterbury, J.D., Weston, J., Noble, W.S., and MacCoss, M.J. (2007). Semi-supervised learning for peptide identification from shotgun proteomics datasets. Nat. Methods *4*, 923–925. https://doi.org/10.1038/ nmeth1113.
- 117. Nielsen, M.C., Andersen, M.N., and Møller, H.J. (2020). Monocyte isolation techniques significantly impact the phenotype of both isolated monocytes and derived macrophages in vitro. Immunology *159*, 63–74. https://doi.org/10.1111/imm.13125.
- 118. Hao, Y., Hao, S., Andersen-Nissen, E., Mauck, W.M., 3rd, Zheng, S., Butler, A., Lee, M.J., Wilk, A.J., Darby, C., Zager, M., et al. (2021). Integrated analysis of multimodal single-cell data. Cell *184*, 3573–3587.e29. https:// doi.org/10.1016/j.cell.2021.04.048.
- 119. R Core Team (2021). R: A Language and Environment for Statistical Computing (R Foundation for Statistical Computing).
- 120. Wolock, S.L., Lopez, R., and Klein, A.M. (2019). Scrublet: computational identification of cell doublets in single-cell transcriptomic data. Cell Syst. *8*, 281–291.e9. https://doi.org/10.1016/j.cels.2018.11.005.
- 121. Korsunsky, I., Millard, N., Fan, J., Slowikowski, K., Zhang, F., Wei, K., Baglaenko, Y., Brenner, M., Loh, P.R., and Raychaudhuri, S. (2019). Fast, sensitive and accurate integration of single-cell data with Harmony. Nat. Methods *16*, 1289–1296. https://doi.org/10.1038/s41592-019- 0619-0.
- 122. Becht, E., McInnes, L., Healy, J., Dutertre, C.A., Kwok, I.W.H., Ng, L.G., Ginhoux, F., and Newell, E.W. (2018). Dimensionality reduction for visualizing single-cell data using UMAP. Nat. Biotechnol. https://doi.org/10. 1038/nbt.4314.
- 123. Xiao, Y., Qureischi, M., Dietz, L., Vaeth, M., Vallabhapurapu, S.D., Klein-Hessling, S., Klein, M., Liang, C., Ko¨ nig, A., Serfling, E., et al. (2021). Lack of NFATc1 SUMOylation prevents autoimmunity and alloreactivity. J. Exp. Med. *218*, e20181853. https://doi.org/10.1084/jem.20181853.
- 124. Knochelmann, H.M., Dwyer, C.J., Bailey, S.R., Amaya, S.M., Elston, D.M., Mazza-McCrann, J.M., and Paulos, C.M. (2018). When worlds collide: Th17 and Treg cells in cancer and autoimmunity. Cell. Mol. Immunol. *15*, 458–469. https://doi.org/10.1038/s41423-018-0004-4.
- 125. Liu, Z., Gu, Y., Shin, A., Zhang, S., and Ginhoux, F. (2020). Analysis of myeloid cells in mouse tissues with flow cytometry. Star Protoc. *1*, 100029. https://doi.org/10.1016/j.xpro.2020.100029.

![](_page_21_Picture_0.jpeg)

![](_page_21_Picture_1.jpeg)

### **STAR**\***METHODS**

### **KEY RESOURCES TABLE**

| REAGENT or RESOURCE                                                  | SOURCE                              | IDENTIFIER                         |
|----------------------------------------------------------------------|-------------------------------------|------------------------------------|
| Antibodies                                                           |                                     |                                    |
| nVivoMAb anti-mouse CD18 Antibody                                    | BioXCell                            | Cat #BE0009; RRID: AB_1107607      |
| nVivoMAb anti-mouse CSF1R (CD115) Antibody                           | BioXCell                            | Cat #BE0213; RRID: AB_2687699      |
| nVivoMAb anti-mouse Ly6G/Ly6C Antibody                               | BioXCell                            | Cat #BE0075; RRID: AB_10312146     |
| nVivoMAb rat IgG2a isotype control, anti-trinitrophenol              | BioXCell                            | Cat #BE0089; RRID: AB_1107769      |
| nVivoMAb rat IgG2b isotype control, anti-keyhole limpet nemocyanin   | BioXCell                            | Cat #BE0090; RRID: AB_1107780      |
| Anti-mouse GPIbα Antibody                                            | Emfret                              | Cat #R300; RRID: AB_2721041        |
| Rat IgG isotype control                                              | Emfret                              | Cat #C301; RRID: AB_2734715        |
| Anti-mouse/rat CD61 Antibody - FITC conjugated                       | Biolegend                           | Cat #104306; RRID: AB_313083       |
| Anti-mouse/rat CD62P (P-selectin) Antibody – APC conjugated          | Biolegend                           | Cat #148304; RRID: AB_2565273      |
| Anti-human CD61 Antibody – FITC conjugated                           | Biolegend                           | Cat #336404; RRID: AB_1227580      |
| Anti-human CD62P (P-Selectin) Antibody – APC conjugated              | Biolegend                           | Cat #304910; RRID: AB_314482       |
| Anti-mouse/human CD9 [EPR2949] Antibody                              | Abcam                               | Cat #ab92726; RRID: AB_10561589    |
| Anti-mouse/human Syntenin Antibody                                   | Abcam                               | Cat #ab19903; RRID: AB_445200      |
| Anti-mouse integrin α <sub>X</sub> [D1V9Y] Antibody                  | Cell Signaling                      | Cat #97585; RRID: AB_2800282       |
| Anti-mouse integrin α <sub>D</sub> Antibody                          | LSBio                               | Cat #LS-C294684-100                |
| anti-mouse integrin α <sub>L</sub> Antibody                          | Thermo Fisher                       | Cat #MA11A5; RRID: AB_ 223586      |
| Anti-mouse integrin α <sub>M</sub> Antibody                          | Abcam                               | Cat #ab133357; RRID: AB_2650514    |
| Anti-mouse integrin β <sub>2</sub> Antibody                          | Cell Signaling                      | Cat #47598                         |
| nti-human integrin β <sub>2</sub> Antibody                           | Cell Signaling                      | Cat #7366S                         |
| Anti-rat IgG2a Antibody                                              | Biolegend                           | Cat #407502; RRID: AB_345338       |
| Anti-mouse IgG (H+L) Antibody – Peroxidase AffiniPure™ conjugated    | Jackson Immunoresearch laboratories | Cat #711-035-151; RRID: AB_2340771 |
| Ant-rabbit IgG (H+L) Antibody – Peroxidase AffiniPure™<br>conjugated | Jackson Immunoresearch laboratories | Cat #711-035-152; RRID: AB_1001528 |
| Ant-rat IgG (H+L) Antibody – Peroxidase AffiniPure™<br>conjugated    | Jackson Immunoresearch laboratories | Cat #712-035-153; RRID: AB_2340639 |
| Anti-mouse endomucin Antibody                                        | Santa Cruz                          | Cat #sc-65495; RRID: AB_2100037    |
| Anti-mouse/human MelanA [EPR20380] Antibody                          | Abcam                               | Cat #ab210546; RRID: AB_2889292    |
| Anti-human activated integrin β <sub>2</sub> [MEM-148] Antibody      | Bio-Rad                             | Cat #MCA2086; RRID: AB_323889      |
| Anti-human CSF1R [SP211] Antibody                                    | Abcam                               | Cat #ab183316; RRID: AB_2885197    |
| Anti-mouse IgG (H+L) Antibody – Biotinylated                         | Vector                              | Cat #BA-2000; RRID: AB_2313581     |
| nti-rabbit IgG (H+L) Antibody – Biotinylated                         | Vector                              | Cat #BA-1100; RRID: AB_2336201     |
| nti-human integrin β <sub>2</sub> [TS1/18] Antibody                  | Thermo Fisher                       | Cat #MA1810; RRID: AB_223514       |
| nti-mouse integrin β <sub>2</sub> Antibody                           | R&D                                 | Cat #AF2618; RRID: AB_416646       |
| anti-mouse integrin $\alpha_X$ [D1V9Y] Antibody                      | Cell Signaling                      | Cat #97585; RRID: AB_2800282       |
| Anti-human integrin α <sub>X</sub> Antibody                          | Proteintech                         | Cat #17342-1-AP; RRID: AB_2129787  |
| Anti-human/mouse CD163 Antibody                                      | Proteintech                         | Cat #16646-1-AP; RRID: AB_2756528  |
| Anti-mouse F4/80 [BM8] Antibody                                      | Thermo Fisher                       | Cat #14-4801-82; RRID: AB_467558   |
|                                                                      | D                                   | C++ #07044 1 AD: DDID: AD 0710014  |
| Anti-human/mouse EMR1 Antibody                                       | Proteintech                         | Cat #27044-1-AP; RRID: AB_2716814  |

![](_page_22_Picture_0.jpeg)

![](_page_22_Picture_1.jpeg)

| Continued                                                                                            |                   |                                    |
|------------------------------------------------------------------------------------------------------|-------------------|------------------------------------|
| REAGENT or RESOURCE                                                                                  | SOURCE            | IDENTIFIER                         |
| Anti-mouse Siglec-F Antibody                                                                         | BD Biosciences    | Cat #552125; RRID: AB_394340       |
| Anti-mouse/human Ki67 Antibody                                                                       | Thermo Fisher     | Cat #14-5698-82; RRID: AB_10854564 |
| Anti-mouse/human CCR2 Antibody                                                                       | Novus Biologicals | Cat #NBP1-48338; RRID: AB_10011103 |
| Anti-mouse/human Factor X Antibody                                                                   | GeneTex           | Cat #GTX110300; RRID: AB_1950240   |
| Anti-mouse Coagulation Factor VII Antibody                                                           | R&D               | Cat #AF3305; RRID: AB_ 2293786     |
| Anti-mouse Coagulation Factor III/Tissue Factor Antibody                                             | R&D               | Cat #AF3178; RRID: AB_2278143      |
| Anti-mouse GPIbβ – DyLight649 conjugated (X649)                                                      | Emfret            | Cat #X649; RRID: AB_2861336        |
| Anti-rabbit IgG (H+L) Highly Cross-Adsorbed Secondary<br>Antibody – Alexa Fluor™ Plus 488 conjugated | Thermo Fisher     | Cat #A-32790; RRID: AB_2762833     |
| Anti-rabbit IgG (H+L) Highly Cross-Adsorbed Secondary<br>Antibody – Alexa Fluor™ 594 conjugated      | Thermo Fisher     | Cat #A-21207; RRID: AB_141637      |
| Anti-goat IgG (H+L) Highly Cross-Adsorbed Secondary<br>Antibody – Alexa Fluor™ 546 conjugated        | Thermo Fisher     | Cat #A-11056; RRID: AB_2534103     |
| Anti-mouse IgG (H+L) Highly Cross-Adsorbed Secondary<br>Antibody – Alexa Fluor™ Plus 647 conjugated  | Thermo Fisher     | Cat #A-32787; RRID: AB_2762830     |
| Anti-rat IgG (H+L) Highly Cross-Adsorbed Secondary<br>Antibody – Alexa Fluor™ 594 conjugated         | Thermo Fisher     | Cat #A-21209; RRID: AB_2535795     |
| Anti-rat IgG (H+L) Cross-Adsorbed Secondary Antibody –<br>Alexa Fluor™ 633 conjugated                | Thermo Fisher     | Cat #A-21094; RRID: AB_2535749     |
| Anti-rat IgG (H+L) Cross-Adsorbed Secondary Antibody –<br>Alexa Fluor™ 568 conjugated                | Thermo Fisher     | Cat #A-11077; RRID: AB_2534121     |
| Anti-rat IgG (H+L) Cross-Adsorbed Secondary Antibody –<br>Alexa Fluor™ 594 conjugated                | Thermo Fisher     | Cat #A-11007; RRID: AB_10561522    |
| Anti-rabbit IgG (H+L) Cross-Adsorbed Secondary<br>Antibody – Alexa Fluor™ 633 conjugated             | Thermo Fisher     | Cat #A-21070; RRID: AB_2535731     |
| Anti-rabbit IgG (H+L) Cross-Adsorbed Secondary<br>Antibody – Alexa Fluor™ 488 conjugated             | Thermo Fisher     | Cat #A-11008; RRID: AB_143165      |
| Anti-goat IgG (H+L) Cross-Adsorbed Secondary<br>Antibody – Alexa Fluor™ 633 conjugated               | Thermo Fisher     | Cat #A-21082; RRID: AB_2535739     |
| Anti-mouse IgG (H+L) Cross-Adsorbed Secondary<br>Antibody – Alexa Fluor™ 594 conjugated              | Thermo Fisher     | Cat #A-11005; RRID: AB_2534073     |
| Anti-mouse IgG, IgM, IgA (H+L) Secondary Antibody –<br>Alexa Fluor™ 488 conjugated                   | Thermo Fisher     | Cat #A-10667; RRID: AB_2534057     |
| Anti-sheep IgG (H+L) Cross-Adsorbed Secondary<br>Antibody – Alexa Fluor™ 594 conjugated              | Thermo Fisher     | Cat #A-11016; RRID: AB_2534083     |
| Anti-Rat IgG (H+L), Highly Cross-Adsorbed – CF®647<br>conjugated                                     | Biotium           | Cat #20843                         |
| Anti-Goat IgG (H+L) Highly Cross-Adsorbed Secondary<br>Antibody – CF®568 conjugated                  | Biotium           | Cat #20106-1; RRID: AB_10854239    |
| Anti-mouse integrin $\beta_2$ [68-5A5] Antibody – CF $^{\odot}$ 647 conjugated                       | Biotium           | Cat #BNC470321                     |
| Anti-human integrin α <sub>M</sub> [M1/70] Antibody – CF®568<br>conjugated                           | Biotium           | Cat #BNC680720                     |
| Anti-human integrin α <sub>X</sub> [1284] Antibody – CF®568<br>conjugated                            | Biotium           | Cat #BNC681284                     |
| Anti-mouse/human CD9 [1619] Antibody – CF488®A<br>conjugated                                         | Biotium           | Cat #BNC881619                     |
| Anti-mouse CD63 [MX-49.129.5] Antibody – CF488®A<br>conjugated                                       | Biotium           | Cat #BNC880525                     |
|                                                                                                      |                   |                                    |

![](_page_23_Picture_0.jpeg)

![](_page_23_Picture_1.jpeg)

| Continued                                                                  |                |                                                  |
|----------------------------------------------------------------------------|----------------|--------------------------------------------------|
| REAGENT or RESOURCE                                                        | SOURCE         | IDENTIFIER                                       |
| Anti-mouse CD81/TAPA-1 [1.3.3.22] Antibody – CF488®A conjugated            | Biotium        | Cat #BNC880391                                   |
| Anti-human/mouse CD81 / TAPA-1 [1.3.3.22] Antibody –<br>CF®568 conjugated  | Biotium        | Cat #BNC680391                                   |
| Purified Rat Anti-Mouse CD16/CD32 (Mouse BD Fc<br>Block <sup>TM</sup> )    | BD Biosciences | Cat #553142; RRID: AB_394657                     |
| TruStain FcX™ PLUS (anti-mouse CD16/32) Antibody                           | Biolegend      | Cat #156604; RRID: AB_2783138                    |
| Anti-mouse Ly-6G Antibody – PE/Cyanine7 conjugated                         | Biolegend      | Cat #127618; RRID: AB_1877261                    |
| Anti-mouse CD3 Antibody – Brilliant Violet 785™<br>conjugated              | Biolegend      | Cat #100231; RRID: AB_11218805                   |
| Anti-mouse/human CD11b Antibody – Brilliant Violet 605™<br>conjugated      | Biolegend      | Cat #101257; RRID: AB_2565431                    |
| Anti-mouse CD24 Antibody – PE/Dazzle™ 594 conjugated                       | Biolegend      | Cat #101837; RRID: AB_2566731                    |
| Anti-mouse CD64 (FcγRI) Antibody – PE conjugated                           | Biolegend      | Cat #139303; RRID: AB_10613467                   |
| Anti-mouse CD11c Antibody – Brilliant Violet 785™<br>conjugated            | Biolegend      | Cat #117336; RRID: AB_2565268                    |
| Anti-mouse integrin $\beta_2$ Antibody – FITC conjugated                   | Biolegend      | Cat #101405; RRID: AB_312814                     |
| Anti-mouse NK-1.1 Antibody – Brilliant Violet 650™<br>conjugated           | Biolegend      | Cat #108736; RRID: AB_2563159                    |
| Anti-mouse CD80 Antibody – PerCP/Cyanine5.5<br>conjugated                  | Biolegend      | Cat #104721; RRID: AB_893406                     |
| Anti-mouse CD206 (MMR) Antibody – Brilliant Violet 650™<br>conjugated      | Biolegend      | Cat #141723; RRID: AB_2562445                    |
| Anti-mouse CD103 Antibody – Brilliant Violet 711™<br>conjugated            | Biolegend      | Cat #121435; RRID: AB_2686970                    |
| Anti-mouse CD170 (Siglec-F) Antibody – PE/Cyanine7<br>conjugated           | Biolegend      | Cat #155527; RRID: AB_2890715                    |
| Anti-mouse CD31 Antibody – Brilliant Violet 421™<br>conjugated             | Biolegend      | Cat #102424; RRID: AB_2650892                    |
| Anti-mouse CD326 (Ep-CAM) Antibody – PerCP/<br>Cyanine5.5 conjugated       | Biolegend      | Cat #118220; RRID: AB_2246499                    |
| Anti-mouse CD140a Antibody – APC conjugated                                | Biolegend      | Cat #135908; RRID: AB_2043970                    |
| Anti-mouse/human CD11b Antibody – Brilliant Violet 785™ conjugated         | Biolegend      | Cat #101243; RRID: AB_2561373                    |
| Anti-mouse Ly-6C Antibody – APC/Cyanine7 conjugated                        | Biolegend      | Cat #128026; RRID: AB_10640120                   |
| Anti-mouse CD11a Antibody - PE conjugated                                  | Biolegend      | Cat #153104; RRID: AB_2716034                    |
| Anti-mouse CD19 Antibody – PerCP/Cyanine5.5<br>conjugated                  | Biolegend      | Cat #115534; RRID: AB_2072925                    |
| Anti-mouse CD19 Antibody − Brilliant Violet 421™<br>conjugated             | Biolegend      | Cat #115537; RRID: AB_10895761                   |
| Anti-mouse CD8a Antibody – Brilliant Violet 605™<br>conjugated             | Biolegend      | Cat #100743; RRID: AB_2561352                    |
| Anti-mouse Ly-6G Antibody – Brilliant Violet 605™<br>conjugated            | Biolegend      | Cat #127639; RRID: AB_2565880                    |
| Anti-mouse I-A/I-E (MHC-II) Antibody – Brilliant Violet<br>421™ conjugated | Biolegend      | Cat #107631; RRID: AB_10900075                   |
| Anti-mouse CD31 Antibody – Pacific Blue™ conjugated                        | Biolegend      | Cat #102422; RRID: AB_10612926                   |
| Anti-human CD206 (MMR) Antibody – APC conjugated                           | Biolegend      | Cat #321110; RRID: AB_571885 (Continued on next) |

![](_page_24_Picture_0.jpeg)

![](_page_24_Picture_1.jpeg)

| Continued                                                                                     |                        |                                  |
|-----------------------------------------------------------------------------------------------|------------------------|----------------------------------|
| REAGENT or RESOURCE                                                                           | SOURCE                 | IDENTIFIER                       |
| Anti-human CD14 Antibody – Brilliant Violet 421™<br>conjugated                                | Biolegend              | Cat #325628; RRID: AB_2563296    |
| Anti-human CD80 Recombinant Antibody - PE conjugated                                          | Biolegend              | Cat #370612; RRD: AB_2890803     |
| Anti-Mouse CD45 Antibody – BD OptiBuild™ BUV496<br>conjugated                                 | BD Biosciences         | Cat #752411; RRID: AB_2917425    |
| Anti-Mouse Ly-6G Antibody – BD Horizon™ BV605<br>conjugated                                   | BD Biosciences         | Cat #563005; RRID: AB_2737946    |
| Anti-mouse CD4 Antibody – APC conjugated                                                      | Thermo Fisher          | Cat #17-0041-82; RRID: AB_469320 |
| Chemicals, peptides, and recombinant proteins                                                 |                        |                                  |
| DMEM                                                                                          | Corning                | Cat #10-013-CV                   |
| RPMI-1640                                                                                     | Corning                | Cat #10-040-CV                   |
| EMEM                                                                                          | ATCC                   | Cat #30-2003                     |
| PBS                                                                                           | Corning                | Cat #21-040-CV                   |
| Fetal Bovine Serum, Heat inactivated                                                          | Thermo Fisher          | Cat #10438-026                   |
| Penicillin-streptomycin                                                                       | Thermo Fisher          | Cat #15070063                    |
| Dimethyl Sulfoxide                                                                            | EMD Millipore          | Cat #317275                      |
| Ethanol, Anhydrous                                                                            | KOPTEC                 | Cat #V1001                       |
| Ultrapure™ Distilled Water                                                                    | Thermo Fisher          | Cat #10977-015                   |
| Sodium Hydroxide                                                                              | Calbiochem             | Cat #567530                      |
| Hydrochloric acid                                                                             | Sigma                  | Cat #H1758                       |
| Sodium citrate, Dihydrate                                                                     | Calbiochem             | Cat #567444                      |
| Sodium Chloride (NaCl)                                                                        | Sigma-Aldrich          | Cat #S5886                       |
| Sodium phosphate monobasic dihydrate<br>(NaH <sub>2</sub> PO <sub>4</sub> •2H <sub>2</sub> O) | Sigma-Aldrich          | Cat #71505                       |
| Potassium Chloride (KCI)                                                                      | Sigma-Aldrich          | Cat #P9541                       |
| HEPES                                                                                         | Sigma-Aldrich          | Cat #H3375                       |
| HEPES 1M                                                                                      | Thermo Fisher          | Cat #15630080                    |
| D-(+)-Glucose                                                                                 | Sigma-Aldrich          | Cat #G7021                       |
| Magnesium Chloride (MgCl <sub>2</sub> )                                                       | Sigma-Aldrich          | Cat #M8266                       |
| Apyrase from potatoes                                                                         | Sigma-Aldrich          | Cat #A6535                       |
| Prostaglandin E1                                                                              | Sigma-Aldrich          | Cat #P5515                       |
| Collagen                                                                                      | Chrono-Log Corporation | Cat #385                         |
| Citric Acid, monohydrate                                                                      | Calbiochem             | Cat #231211                      |
| Formaldehyde 37% solution                                                                     | J.T.Baker              | Cat #2106-04                     |
| CountBright™ Absolute Counting Beads, for flow cytometry                                      | Thermo                 | Cat #C36950                      |
| Histoclear                                                                                    | National Diagnostics   | Cat #HS-200                      |
| Mayer's Hematoxylin solution                                                                  | Sigma-Aldrich          | Cat #MHS32                       |
| Epredia™ Shandon™ Bluing Reagent                                                              | Fisher scientific      | Cat #6769002                     |
| Eosin Y solution                                                                              | Sigma-Aldrich          | Cat #HT110116                    |
| Antigen Unmasking Solution, Citrate-Based                                                     | Vector                 | Cat #H-3300                      |
| Hydrogen peroxide (H <sub>2</sub> O <sub>2</sub> )                                            | Calbiochem             | Cat #386790                      |
| Methanol                                                                                      | Sigma-Aldrich          | Cat #439193                      |
| Cytoseal™ 60                                                                                  | VWR                    | Cat #48212-154                   |
| 70 kDa dextran – fluorescein conjugated                                                       | Thermo Fisher          | Cat #D1822                       |
| 155 kDa dextran - TRITC conjugated                                                            | Sigma-Aldrich          | Cat #T1287-100MG                 |
| ACK Lysing Buffer                                                                             | Thermo Fisher          | Cat #A10492-01                   |
|                                                                                               |                        |                                  |

![](_page_25_Picture_0.jpeg)

![](_page_25_Picture_1.jpeg)

| Continued                                        |                              |                   |
|--------------------------------------------------|------------------------------|-------------------|
| REAGENT or RESOURCE                              | SOURCE                       | IDENTIFIER        |
| UltraComp eBeads<br>Compensation Beads           | Thermo Fisher                | Cat #01-2222-42   |
| Sucrose                                          | Sigma-Aldrich                | Cat #S0389        |
| Paraformaldehyde 16% solution                    | Electron Microscopy Sciences | Cat #15710        |
| Tissue-Tek O.C.T Compound                        | Sakura                       | Cat #4583         |
| Isofluorane                                      | Covetrus                     | Cat #11695-6777-2 |
| Tris Buffered Saline (TBS)                       | Boston Bioproducts           | Cat #BM-300       |
| Triton X-100                                     | Sigma-Aldrich                | Cat #X100         |
| Normal Goat Serum Blocking Solution              | Vector                       | Cat #S-1000-20    |
| DAPI                                             | Biolegend                    | Cat #422801       |
| Hoechst 33342 solution                           | Thermo Fisher                | Cat #62249        |
| Cell Staining Buffer                             | Biolegend                    | 420201            |
| EDTA 0.5M                                        | Thermo Fisher                | Cat #15575-038    |
| Ficoll-Paque<br>PLUS Media                       | GE Healthcare                | Cat #17-1440-02   |
| Bovine Serum Albumin (BSA)                       | Millipore                    | Cat #12659        |
| M-CSF                                            | Peprotech                    | Cat #300-25       |
| GM-CSF                                           | Peprotech                    | Cat #300-03       |
| Eptifibatide acetate                             | Sigma-Aldrich                | Cat #SML1042      |
| Acetylsalicylic acid (ASA)                       | Sigma-Aldrich                | Cat #A5376        |
| Heparin sodium                                   | Sigma-Aldrich                | Cat #SLBS9674     |
| Hirudin                                          | Sigma-Aldrich                | Cat #H0393        |
| Tris-Glycine-SDS Running Buffer (10X)            | Boston BioProducts           | Cat #BP-150       |
| Transfer Buffer (10X)                            | Boston BioProducts           | Cat #BP-190       |
| Pierce ECL Western Blotting Substrate            | Thermo Fisher                | Cat #32106        |
| NuPAGE LDS Sample Buffer                         | Thermo Fisher                | Cat #2083421      |
| NuPAGE<br>Sample Reducing Agent (10X)            | Thermo Fisher                | Cat #NP0009       |
| Tween-20                                         | ChemCruz                     | Cat #sc-29113     |
| Urea                                             | Sigma-Aldrich                | Cat #Ge17-1319-01 |
| Ammonium Bicarbonate                             | Sigma-Aldrich                | Cat #09830        |
| DTT                                              | Sigma-Aldrich                | Cat #233155       |
| Iodoacetamide                                    | Sigma-Aldrich                | Cat #I1149        |
| Lysyl Endopeptidase                              | Fujifilm Wako                | Cat #125-05061    |
| Trypsin Platinum                                 | Promega                      | Cat #VA9000       |
| Trifluoroacetic acid                             | Thermo Fisher                | Cat #85183        |
| Acetonitrile                                     | Fisher Scientific            | Cat #A955-4       |
| Formic Acid                                      | Fisher Scientific            | Cat #A117-50      |
| ATPES ((3-aminoproply)triethoxysilane)           | Sigma-Aldrich                | Cat #440140       |
|                                                  |                              |                   |
| Acetal-PEG-NHS                                   | Creative PEGWorks            | Cat #PJK-1702     |
| Triethylamine                                    | Sigma-Aldrich                | Cat #90340        |
| Chloroform                                       | Sigma-Aldrich                | Cat #288306       |
| Sodium cyanoborohydride (NaCNBH3)                | Sigma-Aldrich                | Cat #156159       |
| Poly-L-lysine solution                           | Sigma-Aldrich                | Cat #P8920        |
| Recombinant Mouse CD42b/GPIba Protein            | R&D                          | Cat #8428-GP-050  |
| Recombinant Mouse ICAM-1/CD54 Fc Chimera Protein | R&D                          | Cat #796-IC-050   |
| Recombinant A. victoria GFP protein              | Abcam                        | Cat #ab84191      |
| RIPA lysis buffer                                | Thermo Fisher                | Cat #89900        |
| PhosSTOP                                         | Sigma-Aldrich                | Cat #4906845001   |

![](_page_26_Picture_0.jpeg)

![](_page_26_Picture_1.jpeg)

| Continued                                                               |                       |                  |
|-------------------------------------------------------------------------|-----------------------|------------------|
| REAGENT or RESOURCE                                                     | SOURCE                | IDENTIFIER       |
| cOmplete<br>, Mini, EDTA-free Protease Inhibitor Cocktail               | Sigma-Aldrich         | Cat #4693159001  |
| 4x Laemmli Sample Buffer                                                | Bio-Rad               | Cat #1610747     |
| b-mercaptoethanol                                                       | Sigma                 | Cat #63689       |
| Annexin V – CF568 conjugated                                            | Biotium               | Cat #29010R      |
| Annexin V – Alexa Fluor<br>350 conjugated                               | Thermo Fisher         | Cat #A23202      |
| Annexin Binding Buffer (5X)                                             | Thermo Fisher         | Cat #V13246      |
| Chromogenix S-2765                                                      | Thermo Fisher         | Cat # NC9781310  |
| SCP-0248                                                                | Sigma                 | Cat #SCP0248     |
| S-2238 (hydrochloride)                                                  | Cayman Chemical       | Cat #34944       |
| Recombinant Mouse Coagulation Factor III/Tissue Factor<br>Protein       | R&D                   | Cat #3178-PA-10  |
| Recombinant Mouse TFPI Protein                                          | R&D                   | Cat #2975-PI-010 |
| ProLong<br>Diamond Antifade Mountant                                    | Thermo Fisher         | Cat #P36961      |
| Amiloride (hydrochloride)                                               | Cayman Chemical       | Cat #14409       |
| Chlorpromazine (hydrochloride)                                          | Cayman Chemical       | Cat #16129       |
| Critical commercial assays                                              |                       |                  |
| MycoAlert Detection Kit                                                 | Lonza                 | Cat #LT07-318    |
| Blocking kit                                                            | Vector                | Cat #SP-2001     |
| VECTASTAIN ABC-HRP Kit, Peroxidase (Standard)                           | Vector                | Cat #PK-4000     |
| PTAH stain kit                                                          | Diagnostic BioSystems | Cat #KT029       |
| Antigen Unmasking Solution, Citrate-Based                               | Vector                | Cat #H-3300      |
| ImmPACT DAB Substrate, Peroxidase (HRP)                                 | Vector                | Cat #SK-4105     |
| Streptavidin/Biotin Blocking Kit                                        | Vector                | Cat #SP-2002     |
| EV Profiler kit                                                         | ONI                   | N/A              |
| TotalSeq-C Mouse pre-catalog release panel                              | Biolegend             | Cat #90002539    |
| CD14 MicroBeads, human                                                  | Miletnyi Biotec       | Cat #130-050-201 |
| PKH26 Red Fluorescent Cell Linker Kit                                   | Sigma-Aldrich         | Cat #PKH26GL-1KT |
| CellVue<br>NIR815 Cell Labeling Kit                                     | Thermo Fisher         | Cat #88-0874-16  |
| LIVE/DEAD<br>Fixable Blue Dead Cell Stain Kit, for UV<br>excitation     | Thermo Fisher         | Cat #L34962      |
| Mouse Fibrin Degradation Product D-Dimer ELISA Kit<br>(Competitive EIA) | LSBio                 | Cat #LS-F6179    |
| Proteome Profiler Mouse XL Cytokine Array                               | R&D                   | Cat #ARY028      |
| Pierce<br>Streptavidin Magnetic Beads                                   | Thermo Fisher         | Cat #88816       |
| Protein A/G agarose beads                                               | Santa Cruz            | Cat #sc-2003     |
| Mouse CXCL13/BLC/BCA-1 Quantikine ELISA Kit                             | R&D                   | Cat #MCX130      |
| Human CXCL13/BLC/BCA-1 Quantikine ELISA Kit                             | R&D                   | Cat #DCX130      |
| Mouse Integrin b2 ELISA Kit                                             | Aviva system biology  | Cat #OKEH05898   |
| Human Integrin b2/CD18 ELISA Kit                                        | Ray Biotech           | Cat #ELH-ITGB2-1 |
| Experimental models: Cell lines                                         |                       |                  |
| Mouse: B16F10                                                           | ATCC                  | CRL-6475         |
| Mouse: 4T1                                                              | ATCC                  | CRL-2539         |
| Mouse: KPC4662                                                          | Evans et al.54        | N/A              |
| Experimental models: Organisms/strains                                  |                       |                  |
| Mouse: C57BL/6J                                                         | Jackson Laboratories  | 000664           |
| Mouse: BALB/cJ                                                          | Jackson Laboratories  | 000651           |
| Mouse: J:NU                                                             | Jackson Laboratories  | 007850           |

![](_page_27_Picture_0.jpeg)

![](_page_27_Picture_1.jpeg)

| Continued                                                                                    |                             |                         |
|----------------------------------------------------------------------------------------------|-----------------------------|-------------------------|
| REAGENT or RESOURCE                                                                          | SOURCE                      | IDENTIFIER              |
| Mouse: MMTV-PyMT mice (FVB/N-Tg(MMTV-PyVT)634Mul/J)                                          | Jackson Laboratories        | 002374                  |
| Mouse: Itgb2 KO (C.129S7(B6)-Itgb2 <sup>tm2Bay</sup> /AbhmJ)                                 | Jackson Laboratories        | 027003                  |
| Mouse: KPC mice (Kras <sup>tm4Tyj</sup> Trp53 <sup>tm1Brn</sup> Tg(Pdx1-cre/<br>Esr1*)#Dam/J | Jackson Laboratories        | 032429                  |
| Mouse: NOD SCID (NOD.Cg-Prkdc <sup>scid</sup> /J)                                            | Jackson Laboratories        | 001303                  |
| Software and algorithms                                                                      |                             |                         |
| Prism                                                                                        | GraphPad                    | v10.4.1                 |
| SlideViewer                                                                                  | 3DHISTECH                   | v2.7                    |
| ImageJ/FIJI                                                                                  | NIH                         | V2.14.0/v1.54f          |
| CODI                                                                                         | ONI                         | N/A                     |
| ZEN                                                                                          | Zeiss                       | v2.3                    |
| Imaris                                                                                       | Bitplane                    | v9                      |
| FlowJo                                                                                       | BD Biosciences              | v10.9.0                 |
| BD FACSDiva™                                                                                 | BD Biosciences              | v9.0                    |
| Other                                                                                        |                             |                         |
| Half-area-96-well microtiter plates                                                          | Greiner BioONE              | Cat #675101             |
| Thincert Cell Culture Insert For 24 Well Plates, 0.4 $\mu m$ pores                           | Greiner                     | Cat #662641             |
| Transwell® membrane cell culture inserts, 75 mm, with 3.0 $\mu$ m pores                      | Sigma                       | Cat #CLS3420            |
| Non-sterile CellTrics™ filters, Mesh filter size 100 μm                                      | Sysmex                      | Cat #04-0042-2318       |
| Microscope Slides                                                                            | Denville Scientific         | Cat #M1023              |
| Superfrost Plus™ Slides                                                                      | VWR                         | Cat #48311-703          |
| Micro cover glass                                                                            | VWR                         | Cat #48382-138          |
| Sodium Citrate Blood Collection Tubes                                                        | Fisher Scientific           | Cat #22-040-046         |
| K2 EDTA Blood Collection Tubes                                                               | Fisher Scientific           | Cat #367863             |
| Sodium Heparin Blood Collection tubes                                                        | BD                          | Cat #366480             |
| C18 reversed-phase 12 cm pulled emitter column                                               | Nikkyo Technologies         | Cat # NTCC-360/75-5-123 |
| SyringeTWO Two-Channel Syringe Pump                                                          | United States Plastic Corp. | Cat #98246              |
| TetraSpeck™ Microspheres, 0.1 μm                                                             | Thermo Fisher               | Cat #T7279              |

### **EXPERIMENTAL MODEL AND STUDY PARTICIPANT DETAILS**

### Cell lines

B16F10 murine melanoma cells (stock #CRL-6475) and 4T1 murine mammary carcinoma cells (stock #CRL-2539) were purchased from the American Type Culture Collection (ATCC). KPC4662 murine PDAC cells were isolated from KPC primary tumors.<sup>54</sup> The B16F10 cells were cultured in DMEM medium, the 4T1 and KPC4662 cells were cultured in RPMI-1640 medium. All media were supplemented with 10% heat-inactivated fetal bovine serum (FBS), 100 U/mL penicillin, and 100 μg/mL streptomycin. FBS was first depleted of EVs by ultracentrifugation at 100,000 xg for 4 h. Patient-derived PDAC organoids were isolated and cultured according to a previously published protocol.<sup>110</sup> All cells were maintained at 37°C in a humidified incubator with 5% CO<sub>2</sub>. Cell cultures were continuously monitored for doubling times and morphology, and they were regularly tested for contamination from mycoplasma using MycoAlert Detection Kit (Lonza, Catalog #: LT07-318). Each culture is passaged less than 20 times.

### **Animals**

C57BL/6J (stock #000664), BALB/cJ (stock #000651), J:NU (stock #007850), mouse mammary tumor virus (MMTV)-Polyoma Virus middle T (PyMT) (FVB/N-Tg(MMTV-PyVT)634Mul/J, stock #002374), *Itgb2* KO (C.129S7(B6)-Itgb2<sup>tm2Bay</sup>/AbhmJ, stock #027003), and NOD SCID (NOD.Cg-Prkdc<sup>scid</sup>/J, stock #001303) mice were purchased from the Jackson Laboratory. The inducible KPC mice (Kras<sup>tm4Tyj</sup> Trp53<sup>tm1Brn</sup> Tg(Pdx1-cre/Esr1\*)#Dam/J, JAX stock #032429) were treated with tamoxifen via lactation on day 0, 1, 2 and 4 after birth, as previously reported.<sup>53</sup> KPC mice carrying the Kras<sup>G12D</sup> mutation in one allele (Kras<sup>Het</sup>) develop pancreatic

**Cell** Article

![](_page_28_Picture_1.jpeg)

intraepithelial neoplasia (PanIN) lesions at 8-10 weeks of age, which progress into localized PDAC at 10-14 weeks and invasive PDAC associated with distant metastasis to several sites including lymph nodes, liver, lungs, diaphragm, and spleen at week 16-20. Homozygous wild type littermate controls (Kras<sup>WT</sup>) do not develop tumors. This model has been previously reported to recapitulate human PDAC development in terms of histopathological features (e.g., immune infiltration), stage progression, metastatic spread, and overall clinical outcome.<sup>53</sup> Mice were housed at 5 animals per cage in vented racks, with a 12-h light-dark cycle and ad libitum access to water and food. Both female and male mice (7-20 weeks of age) were used in these studies and female mice (7-16 weeks of age) were used for breast cancer studies. In some experiments, mice were treated with antiβ<sub>2</sub> antibody, anti-CXCL13 antibody, or isotype control (IgG, all at 10 mg/kg), recombinant mouse CXCL13 (rmCXCL13, 50 μg/kg), or annexin V (5 mg/kg) via the retro-orbital route. Immune cell depletion was achieved by intraperitoneal injection of 10 mg/kg InVivo Mab anti-mouse CSF1R antibody (for IM depletion) and Ly6G/Ly6C antibody (for neutrophil depletion) or their isotype controls 48 and 24 h before the experiment. Platelets were depleted via retro-orbital injection of 2 mg/kg anti-GPlbα antibody (Emfret R300) or its isotype control (Emfret C301) 24 h before the experiment. Anti-coagulation was achieved via treatment with aspirin (50 mg/kg, intra-peritoneal, 24 h and 1 h before), heparin (1000 U/kg, retro-orbital, 30 min before), hirudin (20 mg/kg, intra-peritoneal, 5 min before), eptifibatide (0.5 mg/kg, intra-peritoneal, 24 h and 30 min before) prior to the experiment. Blood platelet and neutrophil concentration was measured via the IDEXX ProCyte Dx by laminar flow impendence and laser flow cytometry, respectively. All procedures were performed in full accordance with the Guidelines for Survival Surgery in Rodents published by the WCMC/MSKCC Animal Resources and Comparative Medicine (ARCM) and regulated by the Institutional Animal Care and Use Committee (IACUC, protocol #709-666A).

### **Human participants**

Fresh human tumor tissues and blood samples were obtained from patients surgically treated at Memorial Sloan Kettering Cancer Center (MSKCC), New York University (NYU) Langone Health (see Table S1 for age, gender, and stage), University of Nebraska Medical Center (UNMC) Tissue Bank through the Rapid Autopsy Program, and from the Cooperative Human Tissue Network (CHTN, RRID: SCR\_004446). All individuals provided informed consent for tissue donation according to protocols approved by the institutional review board of MSKCC (IRB 15-015 and 22-155), UNMC (IRB 091-01), and NYU (IRB s17-00651) and were processed at WCM (IRB 0604008488). The study is compliant with all relevant institutional protocols, ethical and legal regulations regarding research involving human participants. The study does not involve any intervention including clinical trials or randomization into experimental groups.

### **METHOD DETAILS**

### **Tumor inoculation**

To establish subcutaneous melanoma tumors, C57BL/6J mice were inoculated with  $5x10^5$  B16F10 cells resuspended in  $100~\mu$ L of PBS into the right or left flank. Subcutaneous tumors and lungs were collected after 2 weeks (for sEV isolation) or 3-5 weeks (for long-term  $\beta_2$  blockade). To establish mammary tumors, BALB/c or *Itgb2* KO mice were injected into the mammary fat pad with  $5x10^4$  4T1 cells resuspended in  $50~\mu$ L of PBS, and tissues (tumors and lungs) were collected after 4 weeks. For experimental metastasis models, B16F10 ( $1x10^6$  for sEV collection,  $2.5x10^5$  for long-term  $\beta_2$  blockade), KPC4662 ( $1x10^6$ ), or 4T1 ( $1.5x10^5$ ) cells were injected into the tail vein of C57BL6/J mice (B16F10 and KPC4662) or BALB/c mice (4T1). All injected cells were exponentially growing (confluency of 80-90%) at the moment of collection and injection.

### Platelet isolation and aggregometry

Mice were euthanized by CO<sub>2</sub> asphyxiation and blood was isolated by cardiac puncture in syringes containing 3.2% sodium citrate, for a final concentration of 0.32% sodium citrate. Mouse blood was diluted 1:1 with modified Tyrode's-HEPES (MTH) buffer (134 mM NaCl, 0.3 mM NaH<sub>2</sub>PO<sub>4</sub>•2H<sub>2</sub>O, 3 mM KCl, 5 mM HEPES, 5 mM dextrose, 2 mM MgCl<sub>2</sub>) supplemented with 0.02 U/ml apyrase and 0.25 μM PGE<sub>1</sub>. Healthy donor blood was collected in 3.2% sodium citrate tubes. Diluted blood was centrifuged at 200 xg for 10 min at 22°C with no break, platelet rich plasma (PRP) was collected and incubated for 30 min at 30°C. In some experiments, platelets or sEVs were pre-incubated with isotype control, anti-β<sub>2</sub>, anti-GPlbα (R300), or anti-ICAM-1 antibodies at 100 μg/mL for 30 min at 37°C prior to aggregation test. Platelet aggregation was evaluated as previously published.<sup>2,72</sup> PRP was incubated with 30 μg/mL Collagen (as positive control), 20 μg/mL of sEVs, or PBS (Vehicle) in half-area-96-well microtiter plates for 5 min at 37°C under orbital shaking. PRP was diluted 1:4 with ACD buffer (83 mM Na<sub>3</sub>C<sub>6</sub>H<sub>5</sub>O<sub>7</sub>, 111 mM dextrose, 71 mM citric acid), labeled with anti-mouse/human CD61-FITC and CD62-APC antibodies diluted 1:100 in PBS for 30 min at 4°C. Samples were then diluted with 0.1% formal-dehyde in PBS and supplemented with 10<sup>4</sup> CountBright absolute counting beads. Total platelets (CD61<sup>+</sup>) and activated platelets (CD62<sup>+</sup>) were acquired at BD LSRFortessa<sup>TM</sup> or FACSymphony<sup>TM</sup> A5 and BD FACSDiva<sup>TM</sup> software. Platelet suspension was acquired until the count of 500 beads was reached. Platelet aggregation was calculated using the FlowJo software. FVIIa, FXa, and thrombin generation was measured by adding chromogenic substrates of FVIIa (SCP-0248, 0.025 mg/mL), FXa (S-2765, 0.5 mM), or thrombin (S-2238, 6 nM) to PRP after the aggregometry test, followed by 405 nm O.D. absorbance measurement.

![](_page_29_Picture_0.jpeg)

![](_page_29_Picture_1.jpeg)

### **Platelet adhesion assay**

Platelet adhesion to sEVs and thrombus formation was tested via a flow-based system previously described, with some modifications. Briefly, sEVs from normal lungs or B16F10 metastasis-bearing lungs were labeled with PKH67 dye following the manufacturer's instructions. Labeled sEVs were then resuspended at a concentration of 20  $\mu$ g/mL in 0.2 M sodium bicarbonate and adsorbed to the surface of  $\mu$ -Slide IV0.4 (Ibidi) channels overnight at 4°C. Blood was collected from C57BL/6J mice and platelet rich plasma was isolated after 200 xg spin for 10 min at 22°C (no break) and incubated with 1:100 DyLight649-conjugated anti-GPIb $\beta$  antibody for 30 min at room temperature. Plasma containing labeled platelets was then introduced to flow on the sEV-coated surface at 0.05 dyn/cm² for 10 min with the help of a syringe pump. Shear stress was subsequently increased to 1 dyn/cm² for 2 min to remove flowing platelets or thrombi. Platelets and sEVs were fixed with ice-cold 2% PFA and imaged on a Zeiss LMS 880 confocal microscope. Thrombus number and size was measured using Imaris software.

### sEV isolation from tissues, cell lines, and plasma

sEVs from cells and tissues were isolated and characterized as previously reported. <sup>29,111</sup> Mice were anesthetized with 3.5% isoflurane, exsanguinated, and perfused through the right ventricle with 5 mL of PBS. Tissues were dissected and placed in cold PBS until further processing. Patient tissue explants were stored in FBS-free RPMI medium supplemented with penicillin (100 U/ml) and streptomycin (100 μg/ml) at 4°C until processing. Murine and patient tissue explants (lungs, liver, pancreas, melanoma, and mammary tumors) were cut in small pieces of 1-2 mm³ and cultured for 24 h in RPMI supplemented with penicillin (100 U/ml) and streptomycin (100 μg/ml). Cell lines were grown for 3.5-4 days in EV-depleted growth medium before supernatant collection. Conditioned media from tissue or cells were cleared of cells and cellular debris via sequential centrifugation at 500 xg for 10 min and 3,000 xg for 20 min at 10°C. Plasma was isolated by sequential spins at 500 xg for 10 min at 10°C, followed by collection of the top layer and 3,000 xg spin for 20 min at 10°C. The clarified conditioned medium or plasma was centrifuged at 12,000 xg for 20 min at 10°C to remove ectosomes (Beckman Optima XE-100 Ultracentrifuge). To isolate sEVs, the supernatant was ultracentrifuged at 100,000 xg for 70 min at 10°C, and stored in PBS at -80°C. The isolated sEVs were characterized by transmission electron microscopy (TEM), nanoparticle tracking analysis (NTA), and/or western blot of conventional sEV markers (CD9 and syntenin) to confirm their purity and identity. <sup>30</sup>

### **Immunohistochemistry**

Formalin-fixed, paraffin-embedded (FFPE) tissue blocks from patients or mice were sectioned at a thickness of 5 µm using a microtome (Leica RM2125). Slides were deparaffinized in Histo-Clear and rehydrated through a graded series of ethanol. For hematoxylin and eosin (H&E) staining, slides were incubated in Meyer's hematoxylin, blueing solution, and eosin, followed by dehydration through a graded series of ethanol and Histo-Clear. For DAB (3,3'-Diaminobenzidine) staining, antigen retrieval was performed by immersing slides in boiling Antigen Retrieval Buffer for 10 min. Slides were washed twice for 5 min in deionized  $H_2O$  ( $dH_2O$ ). Endogenous peroxidase activity was quenched by incubating slides in 3% H<sub>2</sub>O<sub>2</sub> in 100% methanol, followed by two washes in dH<sub>2</sub>O. Non-specific binding was blocked using 5% BSA and 10% goat serum in PBS in the presence of Avidin block for 1 h. Slides were then washed for 5 min in PBS supplemented with 0.1% Tween-20 (PBS-T) and incubated overnight at 4°C with primary antibodies (anti-endomucin, -MelanA, -actβ<sub>2</sub>, and -CSF1R) diluted 1:100 in PBS supplemented with 5% BSA and Biotin block. After 3 PBS-T washes, sections were incubated with secondary biotinylated antibodies diluted 1:100 for 1 h at room temperature and then washed 3 times in PBS-T. Biotinylated molecules were amplified by incubating the sections with VECTASTAIN® ABC solutions in 5% BSA/PBS for 30 min at room temperature following the manufacturer's instructions. Sections were washed three times for 5 min in PBS-T. Detection was achieved using DAB solution for 2-3 min as per manufacturer's instructions. Slides were then washed for 15 min under running water and then counterstained with Meyer's hematoxylin and blueing solution for 2 min, followed by dehydration through a graded series of ethanol and Histo-Clear. Stained tissue sections were visualized using a 3DHistech Pannoramic MIDI Scanner (Epredia) and images were captured with a 20x/0.8NA objective. Staining intensity and distribution was analyzed via SlideViewer and ImageJ/ FIJI software.

### Lung intravital microscopy

Thrombosis was visualized in live mice via lung window intravital imaging. Briefly, a Window for High Resolution Imaging of the Lung (WHRIL) was implanted into C57BL/6J mice as per previously published protocol.  $^{55,112}$  Mice bearing lung windows were anesthetized using 5% isofluorane, injected retro-orbitally with isotype control or anti- $\beta_2$  antibody (10 mg/kg), and then inverted, placed on the microscope stage, and a fixturing plate was taped to the stage using paper tape. A microscope stage-top heated chamber was placed over the mouse and maintained at physiological temperatures by a forced air heater (WPI Inc., AirTherm ATX), during the course of imaging. Isofluorane was then reduced to a maintenance level of 1-2%. A catheter terminating in a 31-gauge needle was placed retro-orbitally and secured to the stage so as to not move relative to the mouse. Mice were then injected retro-orbitally with 125 mg/kg tetramethylrhodamine (TRITC)-labeled 155 kDa dextran for vasculature visualization and 50  $\mu$ g/kg DyLight649-labeled anti-GPIb $\beta$  platelet-labeling antibody. 10-20 min of time series imaging was performed on a previously described, custom-built, two-laser multiphoton microscope. <sup>113</sup> Images were acquired for 4 min and then mice were injected via the retro-orbital catheter with 5  $\mu$ g of sEVs from normal lungs or B16F10 metastasis-bearing lungs of C57BL/6J resuspended in 50 mg/mL fluorescein-labeled 70 kDa dextran. Four channel images (Blue, Green, Red, and Far Red, as detailed in <sup>113</sup>) were captured in 16 bit using a 25x 1.05 NA

![](_page_30_Picture_0.jpeg)

![](_page_30_Picture_1.jpeg)

objective lens and acquired at  $\sim$ 1 frame per sec with  $\sim$ 20 sec between frames. Two separate excitation sources set to 1020 nm (MaiTai, Spectra Physics) and 1210 nm (Insight, Spectra Physics) were used to simultaneously excite the TRITC-labeled dextran, the Dylight649-labeled anti-GPIbβ antibody, and the FITC-labeled dextran.

### **Immunofluorescence**

Tissues from perfused mice or patient biopsies were fixed in 4% PFA overnight at 4°C and stored in sucrose 30% at 4°C for at least 2 days before being embedded in Optimal Cutting Temperature (O.C.T.) compound. In some experiments, mice were injected with platelet-labeling primary antibody (DyLight649-conjugated anti-GP1bβ, 50 μg/kg) or sEVs (PKH26- or NIR815-labeled, 5-10 μg) before tissue dissection and embedding. Ten-micrometer sections were obtained at a cryostat microtome (Leica CM3050 S), collected on positively charged slides, and stored at -80°C before further processing. Slides were rehydrated in TBS buffer supplemented with 0.025% TritonX-100 (TBST), post-fixed in ice-cold methanol-acetone 1:1 solution, and blocked in PBS supplemented with 5% goat serum, 2.5% BSA, and 0.1% Triton X-100 in PBS for 1 h at room temperature. Sections were incubated with primary antibodies (anti-β<sub>2</sub>, anti-CD163, anti-F4/80, anti-a<sub>x</sub>, anti-SiglecF, anti-CCR2, anti-Ki67, and anti-CSF1R, all 1:100) overnight at 4°C. After 3 washes of 5 min in TBST, secondary antibodies conjugated to AlexaFluor™ 488, 594, 633, or 647 (all 1:250) were applied for 1 h at room temperature. Primary and secondary antibodies were diluted in PBS supplemented with 2.5% goat serum, 1.25% BSA, and 0.05% Triton X-100. Sections were washed 3 times for 5 min in TBST, then incubated in 10 μM Hoechst solution in PBS for nuclear staining, washed once in PBS, and finally mounted with ProLong™ Diamond Antifade Mountant medium. Slides were imaged on a Zeiss LMS 880 with a Zeiss Plan-Apochromat 40x/0.95 or 63x/0.8 oil objective. Images were visualized and quantified using ZEN, ImageJ/FIJI, and Imaris software. At least 4 separate FOVs per section were captured and quantified.

### Flow cytometry of lungs

Perfused murine lungs were dissected to pieces <1 mm<sup>3</sup> and further digested in a Collagenase Dispase solution (8.3 mg/mL Collagenase A, 0.83 mg/mL DNase I, 8.3 mg/mL Dispase II, 4.7 mM NaCl, 1.7 mM KCl, 3.3 mM HEPES, 0.43 mM MgCl<sub>2</sub>, 0.58 mM CaCl<sub>2</sub> in PBS) for 30-60 min at 37°C under agitation. The tissue was washed in washing buffer (2% FBS, 2 mM EDTA in PBS) and spun at 300 xg for 10 min at 4°C. Red blood cells in the pellet were lysed with ACK buffer for 5 min at room temperature. The pellet was washed with washing buffer and passed through 100 μm mesh filters. Washed single cell suspension was blocked for mouse Fc (1:100 dilution) and then incubated with fluorophore-conjugated antibodies at 1:100-1:250 dilution for 30 min at 4°C in the dark. Cells were washed and stained with LIVE/DEAD™ staining solution in PBS according to the manufacturer's instructions. Stained cells were analyzed at the BD FACSymphony A3 and BD FACSDiva™ software after compensation with UltraComp eBeads™. A minimum of 100,000 live events were acquired per sample. Data was analyzed using FlowJo software.

### **Liquid chromatography mass spectrometry**

Five µg of sEVs in PBS were dried and the pellet was resuspended in a solution of 8 M Urea/50 mM Ammonium Bicarbonate/10 mM DTT and incubated for one h at room temperature. After reduction, proteins were alkylated with 30 mM lodoacetamide for 30 min at room temperature in the dark. Urea concentration was diluted to <4 M and samples were incubated with 500 ng Endopeptidase Lys-C for 4 h at room temperature. Urea concentration was further diluted to <2 M, and the samples were incubated with 500 ng Porcine Trypsin for overnight digestion at room temperature. Digestions were halted with trifluoroacetic acid and samples were solid-phase extracted using C18 STAGE tips. 114 30% of each sample was analyzed by LC-MS/MS (Orbitrap Fusion Lumos Tribrid or Q-Exactive-HF mass spectrometer, Thermo Scientific). Peptides were separated on an analytical column (C18 reversed-phase 12 cm pulled emitter column, Nikkyo Technologies, Japan) using a gradient generated at 300 nL/min and increasing from 98% Buffer A/2% Buffer B to 65% Buffer A/35% Buffer B (Buffer A: 1% Acetonitrile/0.1% Formic Acid, Buffer B: 80% Acetonitrile/0.1% Formic Acid) for 90 min. The mass spectrometers were operated in high resolution/high accuracy data-dependent acquisition (DDA) mode. High energy collisional dissociation (HCD) was used for MS/MS.

Proteome Discoverer v.1.4.1.14 and Mascot V. 2.5 or V.2.8 were used to query the data against a human (Uniprot, February 2020, 74,788 sequences) or a mouse database (Uniprot, March 2020, 56,011 sequences) concatenated with either the sequences of Trypsin and Endopeptidase Lys-C in addition to common observed cell culture related contaminants. 115 The following parameters were used in the database search; enzyme: Trypsin/P, maximum missed cleavages sites: 2, precursor mass tolerance: 10 ppm, fragment mass tolerance: 0.02 Da, dynamic modifications: Oxidation (Methionine) and Acetyl (Protein N-terminus), static modifications: Carbamidomethyl (Cysteine). Data were filtered using a Percolator calculated peptide FDR of 1% or better. 116

### dSTORM imaging

sEVs samples were prepared for dSTORM microscopy according to the ONI EV Profiler kit. Briefly, 1-2 μg of sEVs were captured on the chips via the S3 and S4 capture molecules or on 0.1% (w/v) Poly-L-Lysine-coated coverslips. After fixation with 4% PFA, sEVs were incubated with fluorescently labeled primary antibodies against the proteins of interest (integrin  $\beta_2$ , act  $\beta_2$ ,  $\alpha_X$ , and  $\alpha_M$ ) and tetraspanin(s) (CD63, CD81, and/or CD9) for 2 h at room temperature. Antibodies were diluted 1:100 in 0.1% BSA in PBS. Samples were then washed with PBS, post-fixed with PFA 4%, and mounted with BCubed imaging buffer. Images were acquired at the ONI Nanolmager in 3 channels (640 nm, 561 nm, and 488 nm lasers) with a 100x objective (FOV size = 50 μm x 80 μm) and analyzed via CODI software.

![](_page_31_Picture_0.jpeg)

![](_page_31_Picture_1.jpeg)

### **Macrophage isolation and treatment**

Buffy coats from healthy donors were obtained from the New York Blood Center. Twenty mL of whole blood were diluted 1:1 with PBS and layered on 30 mL of Ficoll-Paque Medium and spun in a swing rotor centrifuge at 400 xg at 19°C for 30 min with no break. The upper layer of plasma and platelets was discarded, and the mononuclear cells were collected and washed in 50 mL of PBS. Cells were filtered through a 40 μm mesh filter, resuspended at 12.5x10<sup>6</sup> cells/mL in PBS supplemented with 0.5% BSA and 2 mM EDTA (washing buffer), and mixed 4:1 with CD14 MicroBeads following the manufacturer's instructions. The suspension of PBMCs and beads was incubated 15 min at 4°C under rotation, passed through an LS Column on a MACS Separator, and washed three times with washing buffer. Cells were washed out with 5 mL of buffer and passed through a second column to improve purity. Eluted cells were cultured in differentiation medium (RPMI-1640 supplemented with 10% EV-depleted FCS, 100 U/mL penicillin, 100 μg/mL streptomycin, 10 ng/mL M-CSF, and 1 ng/mL GM-CSF)<sup>117</sup> for a week before being used for experiments.

### scRNA-seg and CITEseg analysis

Perfused lungs from 18-week-old Kras<sup>WT</sup> or Kras<sup>Het</sup> mice were chopped and processed as indicated under the flow cytometry section. Single cells were blocked by incubation in TruStain FcX<sup>TM</sup> PLUS diluted 1:100 in washing buffer for 20 min at 4°C. Immune cells were stained by incubation with anti-mouse APC-conjugated CD45 antibody (1:1000 in Cell staining buffer) for 30 min at 4°C, followed by washing and addition of 3 μM DAPI (4',6-Diamidino-2-Phenylindole, Dilactate). 2.5x10<sup>6</sup> live (DAPI') CD45<sup>+</sup> cells were sorted from each sample through the BD FACSMelody using FACSChours Software. Sorted cells were washed and labeled with TotalSeq-C<sup>TM</sup> Mouse antibody cocktail for 30 min at 4°C following the manufacturer's instructions. Cells were washed 3 times with Cell Staining Buffer, filtered through a 40 μm cell strainer, and resuspended in PBS at a concentration of 800 cells/μL.

Library preparation for Single Cell Immune profiling and CITEseq, sequencing and post-processing of the raw data was performed at the Epigenomics Core at Weill Cornell Medicine as follows. Single-cell RNA-seq libraries were prepared according to 10x Genomics specifications (Chromium NextGem Single Cell 5' with Feature Barcode technology -CG000330- 10x Genomics, Pleasanton, CA, USA). Each cellular suspension (90% viability, 800 cells/µL) was loaded onto to the 10x Genomics Chromium platform to generate Gel Beads-in-Emulsion (GEM), targeting 10,000 single cells per sample. Barcoded and UMI labeled cDNA from polyA mRNA and DNA from CITEseq antibodies were generated simultaneously from the same cells inside the GEM. After 13 cycles of PCR amplification, cDNA, and DNA from CITEseq antibodies were separated by size selection and gene expression libraries and CITEseq libraries generated independently. Quality and quantity of the cDNA and libraries were assessed using an Agilent Bioanalyzer 2100 (Santa Clara, CA). Average cDNA size was 1100 bp, average gene expression library 490 bp, and CITEseq library 213 bp. Libraries were pooled at a 4:1 ratio (gene expression:CITEseq), clustered on an Illumina Novaseq flow cell, and sequenced on a pair end read flow cell 28 cycles on R1 (10x barcode and the UMIs), followed by 10 cycles of I7 Index, 10 cycles of I5 Index, and 98 bases on R2 (transcript/CITEseq tag), obtaining about 250M clusters per sample. Primary processing of sequencing images was done using Illumina's Real Time Analysis software (RTA). 10x Genomics Cell Ranger Single Cell Software suite v6.0.0 (https:// support.10xgenomics.com/single-cell-gene-expression/software/pipelines/latest/what-is-cell-ranger) was used to perform sample demultiplexing, alignment (mm10), filtering, UMI counting, single-cell 5'end gene counting, CITEseq antibody mapping and performing quality control using the manufacturer parameters.

CITE-seq data processing and analysis was performed using the Seurat<sup>118</sup> package from R.<sup>119</sup> After merging sample-level count matrices from RNA and antibody tags (ADT) using the Seurat merge function, cell filtering was performed based on criteria 500 < nFeature\_rna < 4000 and percentage mitochondrial expression < 5%, to remove lower quality and dying cells. We also performed Scrublet<sup>120</sup> analysis and only cells with a Scrublet score smaller than 0.2 were considered as singlets for further analysis.

Quality-filtered RNA data were first normalized and log-transformed. Top 2000 variable features were scaled, and principal component analysis (PCA) was performed following the Seurat guided clustering tutorial (https://satijalab.org/seurat/articles/pbmc3k\_tutorial.html). Similar steps were performed for ADT data, including 'CLR' normalization, scaling and PCA. Harmony<sup>121</sup> integration by sample was also performed and the batch corrected embeddings were used for integrative analysis of RNA and ADT data based on a weighted nearest neighbor (WNN) algorithm<sup>118</sup> as demonstrated in Seurat's WNN Analysis tutorial (https://satijalab.org/seurat/articles/weighted\_nearest\_neighbor\_analysis.html). The weighted nearest neighbor graph combining RNA and ADT assays was used to perform UMAP<sup>122</sup> with 30 nearest neighbors and graph-based clustering (resolution = 0.3), which yielded 20 clusters after removing a low-diversity cluster with only 2 cells. Cells from cluster 8 were extracted for sub-cluster analysis to identify further sub-populations. WNN, UMAP, and clustering was re-performed on these cells to identify 3 subtypes after removing a cluster with low RNA/ADT count. Differential gene expression analysis was performed for the main clusters and subclusters using the Wilcox Rank Sum test from the FindAllMarkers from Seurat.

### μ<mark>Μαρ</mark>

To identify the partners of  $\beta_2$  on sEV surface, 150  $\mu$ g of sEVs isolated from B16F10 metastasis-bearing lungs of C57BL/6J mice (2 week after tail vein injection of  $1x10^6$  cells) were resuspended in 100  $\mu$ L PBS and incubated with 5  $\mu$ g of anti- $\beta_2$  antibody (BioXCell BE0009) or isotype control (BioXCell BE0089), both at 100  $\mu$ g/mL, at 37°C for 30 min. sEVs were then diluted in 3 mL PBS, ultracentrifuged at 100,000 xg for 70 min at 10°C, and supernatant discarded. To identify  $\beta_2$  ligands on the platelet surface, sEVs from B16F10 metastasis-bearing lungs and KPC4662-metastasis bearing were incubated with C57BL/6J-derived platelet-rich

![](_page_32_Picture_0.jpeg)

![](_page_32_Picture_1.jpeg)

plasma at a ratio of 2  $\mu g$  of sEVs per 50  $\mu L$  of plasma and agitated for 5 min at 37°C as previously published 2,72 in the presence of antiβ<sub>2</sub> antibody (BioXCell BE0009) or isotype control (BioXCell BE0089), both at 100 μg/mL. To only isolate platelets and bound sEVs, but not unbound sEVs, platelets were pelleted at 200 xg for 10 min at 22°C. For both sEV and platelet pellets, the pellet was resuspended with 5  $\mu$ g of secondary mouse anti-rat IgG2a antibody conjugated in-house to 8 iridium catalysts/antibody<sup>71</sup> in 100  $\mu$ L PBS at 4° C for 30 min. One μL of 25 mM diazirine-PEG3-biotin in DMSO was then added to this suspension and the suspension irradiated with a 440 nm 100W LED equipped with a 420 nm, 2 mm thick filter at a height of 4.5 centimeters for 5 min. After irradiation, sEVs or platelets were diluted in 3 mL PBS and ultracentrifuged at 100,000 xg for 70 min at 10°C (sEVs) or centrifuged at 200 xg for 10 min at 22°C (platelets). The supernatant was removed, and the sEVs/platelets resuspended in 40 µL ice-cold PBS. After resuspension, 0.2 mL RIPA buffer supplemented with 1% SDS and 10 mM DTT was added and the suspension sonicated in a Bioruptor (15 sec on, 15 sec off, 10 cycles) at 4 °C. The lysate was then heated at 95 °C for 5 min. Iodoacetamide was then added to a final concentration of 15 mM, and the mixture was incubated in the dark for 30 min. DTT was then added to obtain a final concentration of 20 mM to quench remaining iodoacetamide and incubated at room temperature for 15 min. Twenty-five µL of streptavidin beads were then added to the suspended sEV/platelet lysate and the mixture inverted for 4 h at room temperature. Tubes were then centrifuged for 1 min at 100 xg, pelleted on a magnetic rack for 1 min, and supernatant discarded. Beads were then washed 3 times with 1% SDS/PBS, 1M NaCl/PBS, 10% EtOH/PBS, and 50 mM ammonium bicarbonate, with 500 μL volume used for each wash. The beads were then resuspended in 100 μL ammonium bicarbonate, transferred to a fresh tube, pelleted with a magnetic rack, and resuspended in 100  $\mu$ L ammonium bicarbonate containing 0.4  $\mu$ g of MS-grade trypsin. This was then incubated overnight at 37  $^{\circ}$ C, beads pelleted, and the peptide solution evaporated on a speedvac overnight. The dried peptides were finally resuspended in 20 µL of UHPLC-MS grade water supplemented with 0.1% formic acid. 2 μL of this solution was subjected to proteomics analysis, performed on a timsTOF Pro 2 mass spectrometer / nanoElute 1.0 nanoflow UHPLC system. A 1% to 30% gradient was used with a 60-min elution time via direct injection on a 10-cm 1.9 µm particle size PepSep column, with MS analysis done in DDA mode via the instrument's default method settings (DDA standard gradient). Data were then analyzed using PEAKS Studio using default settings against a human FASTA, with Peaks Q as the quantitation mode used for differential expression analysis.

### Single Molecule Force Spectroscopy (SMFS)

All SMFS experiments were collected by JPK-Bruker Nanowizard V with silicon nitride tips (0.1 N/m spring constant, MLCT, Bruker). To functionalize amine groups on the AFM tips, tips were placed on a dish in a vacuum chamber with 20 μL ATPES ((3-aminoproply) triethoxysilane) solution overnight under Argon. Then, acetal-PEG-NHS was attached to the amine functionalized tip by incubation in 0.5 mL chloroform supplemented with 2 mg/mL acetal-PEG-NHS and 30 μL triethylamine for 2 h. The tip was then rinsed 3 times for 5 min with chloroform and dried with Argon gas. Next, the tip was immersed in 1% citric acid in water for 10 min, washed 3 times for 5 min in water, and dried with Argon gas. Lastly, the AFM tip placed on parafilm in a petri dish and immersed in a 100 μL droplet of 1  $\mu$ M ICAM-1, GPIb $\alpha$ , or GFP protein solution. Two  $\mu$ L of a freshly prepared 1 M solution of NaCNBH $_3$  (sodium cyanoborohydride) were added and mixed gently. After incubation for 1 h at room temperature, 5 μL of ethanolamine (1 M, pH 8.0) were added to the droplet on the AFM tip, mixed gently, and incubated for 10 min at room temperature. The functionalized AFM tip was rinsed 3 times for 5 min with PBS and stored at 4°C until further use, and no longer than a week.

The SMFS experiments were conducted in PBS buffer solution at room temperature. The spring constant of the AFM cantilever was calibrated by JPK-Bruker Nanowizard V using the thermal tuning method. Before starting SMFS measurement for each sample, sEVs or recombinant  $\alpha_x \beta_2$  proteins were imaged by AC mode imaging at room temperature in PBS on mica. For AFM images, SCANASYST-FLUID+ (Bruker) with nominal spring constant of 0.7 N/m was used. Images were collected at a speed of 1.5 Hz line rate with an image size of 2 x 2 µm at 512 x 512 pixels resolution. After confirmation of each sEV or recombinant protein sample on a mica by imaging, force curves were acquired at 0.2 nN setpoint and 1.0 µm/sec velocity with 1.0 sec duration time. Force curves of each experiment were collected for each sEV sample with 2 x 2 µm at 16 x 16 pixels resolution. The images were processed with JPK force curve Data Processing software.

### **Co-Immunoprecipitation**

sEVs were isolated from lungs of control or B16F10 metastasis-bearing C57BL/6J mice (2 weeks after tail vein injection of 1x10<sup>6</sup> cells) or Itgb2<sup>-/-</sup> mice. sEVs were lysed in RIPA buffer supplemented with protease/phosphatase inhibitors, followed by 15,000 xg spin for 15 min at 4°C. Twenty μg of lysate were set aside as input, while the remaining 100 μg of lysate were diluted to 0.362 μg/μL of PBS and precleared with protein A/G beads (0.05 μL of bead slurry/μg protein) and isotype control antibody (0.002 μg IgG/μg protein) for 30 min at 4°C with rotation. Beads were pelleted by centrifugation at 1,000 xg for 5 min at 4°C and supernatant was incubated with isotype control (BioXCell BE00089) or functional anti-β<sub>2</sub> antibody (BioXCell BE0009) overnight at 4°C with rotation at a concentration of 0.02 µg antibody/µg protein. sEV-antibody immune complexes were captured by incubation with protein A/G beads (2.5 µL bead slurry/µg antibody) for 4 h at 4°C with rotation. Beads were pelleted by centrifugation at 1,000 xg for 5 min at 4°C and washed in 500 μL PBS supplemented with protease/phosphatase inhibitors by inversion for a total of six washes. At the last wash, the supernatant was removed via a 31G needle insulin syringe and proteins were eluted by boiling the beads in 2x Laemmli sample buffer supplemented with 5% β-mercaptoethanol at 95°C for 10 min, followed by western blot analysis.<sup>111</sup>

![](_page_33_Picture_0.jpeg)

![](_page_33_Picture_1.jpeg)

### QUANTIFICATION AND STATISTICAL ANALYSIS

### Statistical analysis

Statistical analysis was performed with GraphPad Prism. Data are presented as means ± SD unless differently stated in the figure legend. Outliers were identified through Grubbs's test (a = 0.05, GraphPad QuickCalc outlier calculator) and excluded. Data distribution was assessed via D'Agostino and Pearson omnibus normality test. For normally distributed data, unpaired t test (two-tailed) or Pearson correlation test were used to compare two groups, and one-way ANOVA with Tukey or Dunnett test or two-way ANOVA with Bonferroni test or uncorrected Fisher's LSD test were used to compare three or more groups. Survival curves were compared via Mantel-Cox Log-rank test. A *p* value lower than 0.05 was considered significant. \* (*p* < 0.05), \*\* (*p* < 0.01), \*\*\* (*p* < 0.001), or \*\*\*\* (*p* < 0.0001).

![](_page_34_Picture_1.jpeg)

# Supplemental figures

![](_page_34_Figure_3.jpeg)

![](_page_35_Picture_0.jpeg)

![](_page_35_Picture_1.jpeg)

### Figure S1. Lung sEVs from tumor-bearing mice cause systemic thrombosis, related to Figure 1

- (A) Transmission electron microscopy (TEM) of sEVs from tumor cell lines, primary tumor, normal lungs, and metastasis-bearing lungs from C57BL/6J mice with primary B16F10 subcutaneous tumors, MMTV-PyMT mice with spontaneous breast tumors (14 weeks), KPC mice with inducible PDAC tumors (18 weeks), or their controls.
- (B) Levels of D-dimer in the plasma of C57BL/6J mice injected retro-orbitally with 5–10 μg of sEVs from normal C57BL/6J lungs, primary B16F10 tumors, lungs bearing B16F10 metastasis, and lungs from Kras<sup>Het</sup> KPC mice, with or without metastases.
- (C) Platelet count in J:NU mice injected with PBS or with 10 µg of sEVs from normal lungs, PDAC patient organoids, or PDAC organoid metastasis-bearing lungs. (D) TEM images of sEVs from metastasis-bearing lungs, isolated via ultracentrifugation (UC) or size exclusion chromatography (SEC).
- (E and F) Survival curve (E) and platelet count (F) in C57BL/6J mice injected with 10 µg of sEVs from KPC4662 metastasis-bearing lungs or PBS. The same EVs suspension was isolated by either UC or SEC.
- (G) Representative confocal images of tissues from C57BL/6J mice retro-orbitally injected with platelet-labeling antibody (DyLight649-conjugated anti-GPlb $\beta$  antibody, magenta) and 3  $\mu$ g of sEVs from B16F10 metastasis-bearing lungs (PKH26-labeled, green) and stained by IF for the endothelial cell marker CD31 (white). Tissues were collected 10 min after sEV injection.
- (H) DAB staining of endothelial endomucin, a marker of venous post-capillary endothelial cells, in lungs from C57BL/6J mice injected retro-orbitally with 5 μg of sEVs from B16F10 metastasis-bearing lungs or 10 μg of sEVs from non-metastatic lungs of KPC PDAC-bearing mice. A, artery; V, vein; C, clot.
- (I) Representative confocal images of the kinetics of thrombus formation in C57BL/6J mice carrying a lung window for intravital imaging. <sup>55</sup> Mice were injected with TRITC-conjugated 155 kDa dextran (red), DyLight649-conjugated anti-GPlbβ platelet-labeling antibody (white), and, after 4 min of acquisition, 5 μg of sEVs from lungs of control C57BL/6J mice (normal lung sEVs) or mice with B16F10 metastases, resuspended in fluorescein-conjugated 70 kDa dextran (green). Clots were rendered with yellow (seeding clot) or white (growing clot) lines. Dotted arrows indicate direction of blood flow, blue arrows indicate areas of unperfused
- (J-L) Quantification (J and K) and contour plot (L) of flow-cytometry aggregometry test of platelet aggregation and activation induced by sEVs from B16F10 melanoma-bearing lungs. Platelet aggregation and activation were measured based on aggregates formation on the CD61 gate (all platelets) and CD62P exposure, respectively.
- (M–O) Diagram of experimental design (M), representative confocal images (N), and quantification (O) of DyLight649-labeled platelet aggregates (white) formed onto immobilized sEVs from B16F10 metastasis-bearing lungs or normal lungs from C57BL/6J mice.
- Data are represented as mean  $\pm$  SD. Statistical significance was evaluated using one-way ANOVA with Tukey test (B, C, F, J, and K) and two-tailed unpaired t test (O). ns, not significant; \*p < 0.05; \*\*\*p < 0.01; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0

![](_page_36_Picture_0.jpeg)

![](_page_36_Picture_1.jpeg)

![](_page_36_Figure_2.jpeg)

Figure S2. Immune cell depletion does not abrogate sEV-induced thrombosis, related to Figure 1

(A) Representative confocal image of IF of immune cells (CD45, white) in the lungs of C57BL/6J mice injected with 5  $\mu$ g of NIR815-labeled sEVs (green) isolated from B16F10 metastasis-bearing lungs and DyLight649-conjugated anti-GP1b $\beta$  platelet-labeling antibody (magenta).

(B) Flow-cytometry analysis of CD45<sup>+</sup> immune cells within circulating CD61<sup>+</sup> platelet aggregates in the blood of C57BL/6J mice injected with a sub-lethal amount (3 μg) of pro-thrombotic sEVs from B16F10 metastasis-bearing lungs.

(C and D) Survival curves (C) and blood platelet count (D) in C57BL/6J, Rag2 KO, or PAD4 KO mice injected with 5 µg of sEVs from B16F10 metastasis-bearing lungs. Mice were depleted of selected immune cells prior to sEV injection: macrophages (anti-CSF1R antibody), mature T and B cells (Rag2 KO mice), and neutrophils (neutrophil degranulation: PAD4 KO mice; neutrophil depletion: anti-Ly6G/C antibody).

Data are represented as mean ± SD. Statistical significance was evaluated using one-way ANOVA with Tukey test. \*\*\*\*p < 0.0001.

![](_page_37_Figure_2.jpeg)

(A and B) Heatmap (A) and quantification (B) of protein levels from LS-MS of sEVs from tissue explants of control or B16F10 tumor-bearing C57BL/6J mice or MMTV-PyMT control or carrier mice (14 weeks), showing upregulated proteins in the pro-coagulant sEVs, including integrin <sup>b</sup>2. (C) Venn diagram showing numbers of exclusive or common proteins enriched by >1.5-fold in sEVs from (non-)metastatic lungs of mice with melanoma, breast, or pancreatic cancer (as described in A and Figure 2A), compared with normal lung sEVs.

![](_page_38_Picture_0.jpeg)

![](_page_38_Picture_1.jpeg)

<sup>(</sup>D) Gene set enrichment analysis (GSEA) analysis of pathway-associated sets of proteins enriched in sEVs from (non-)metastatic lungs of PDAC-bearing KrasHet mice compared with normal lungs of KrasWT control mice.

<sup>(</sup>E) Western blot of integrin <sup>b</sup><sup>2</sup> and loading control (CD9) in sEVs from B16F10 cells or different tissue sources of melanoma-bearing mice.

<sup>(</sup>F) Quantification of protein levels of TF measured via LS-MS of sEVs from different tissue explants of C57BL/6J mice bearing B16F10 tumors, lung metastases, or controls.

<sup>(</sup>G) Levels of PS on the surface of sEVs from different tissue sources of B16F10 tumor-bearing C57BL/6J mice or controls, measured via exoELISA.<sup>111</sup>

<sup>(</sup>H) Western blot (top) and quantification (bottom) of TF and loading control (syntenin) in sEVs from different tissue sources of melanoma- or PDAC-bearing mice. (I and J) Representative dSTORM images of TF (cyan), integrin <sup>b</sup><sup>2</sup> (magenta), and pan-tetraspanin (CD9/63/81, yellow) (I) and quantification of TF localizations (J) on the surface of sEVs from B16F10 cells or different tissue sources of melanoma- or PDAC-bearing mice.

Data are represented as min to max (B), mean ± SD (F, G, and J), and mean (H). Statistical significance was evaluated using one-way ANOVA with Tukey test. ns, not significant; \**p* < 0.05; \*\**p* < 0.01.

![](_page_39_Figure_2.jpeg)

Figure S4. Blockade of sEV-associated  $\beta_2$  prevents thrombosis, related to Figure 2

(A and B) Quantification (A) and contour plot (B) of platelet aggregates (CD61 = all platelets) after incubation of sEVs from B16F10 metastasis-bearing lung with platelet-rich plasma in the presence of 100  $\mu$ g/mL integrin  $\beta_2$  blocking antibody or isotope control (lgG).

(C-F) Survival curves (C and E) and platelet count (D and F) in C57BL/6J mice injected with 5  $\mu$ g of pro-thrombotic sEVs from B16F10 metastasis-bearing lungs or PBS. In (C) and (D), sEVs were pre-incubated with IgG or anti- $\beta_2$  antibody. In (E) and (F), mice were retro-orbitally injected with IgG or anti- $\beta_2$  antibody 30 min prior to sEV injection.

(G and H) Tumor growth curve (G) and tumor weight at endpoint (H) from ltgb2 wild-type ( $ltgb2^{*\prime}$ ) or KO mice (either  $ltgb2^{*\prime}$  or  $ltgb2^{*\prime}$ ) injected into the mammary fat pad with 4T1 breast cancer cells. At weeks 3–4, all mice bore spontaneous lung metastases.

(I and J) Western blot (I) and quantification (J) of integrin  $\beta_2$ , TF, and loading controls (CD9 and  $\beta$ -actin) in sEVs from lungs of  $ltgb2^{+/+}$ ,  $ltgb2^{+/-}$ , or  $ltgb2^{-/-}$  mice bearing spontaneous 4T1 metastasis.

(K) Complete blood count showing percentage of neutrophils in the blood of C57BL/6J mice at different time points after subcutaneous inoculation of B16F10 cells and receiving IgG or anti- $\beta_2$  antibody as per regime described in Figure 3A.

Data are represented as mean  $\pm$  SD. Statistical significance was evaluated using one-way ANOVA with Tukey test (A, D, F, and H) and two-tailed unpaired t test (J). ns, not significant; \*p < 0.05; \*\*p < 0.01; \*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001; \*\*\*\*p < 0.001;

![](_page_40_Picture_1.jpeg)

![](_page_40_Figure_2.jpeg)

Figure S5. Dissection of the lung PTN, related to Figure 4

(A) Flow-cytometry histogram (top) and quantification (bottom) of the proportion of <sup>b</sup><sup>2</sup> <sup>+</sup> live single cells in the lungs of control or B16F10 lung metastasis-bearing C57BL/6J mice.

![](_page_41_Picture_0.jpeg)

![](_page_41_Picture_1.jpeg)

(B) Cell type annotation and dot plot showing expression of established markers in the cell clusters identified in the scRNA-seq and CITE-seq analysis of lungs from KPC mice. The size of the dot represents the proportion of cells expressing the gene, and the color intensity of the dot represents the average expression level.

(C) Ingenuity Pathway Analysis (IPA) of differentially expressed genes in cell subtypes from lungs of control (KrasWT) or tumor-bearing (KrasHet) KPC mice. Represented pathways have a *<sup>Z</sup>* score >+1.5 or <1.5 in KrasHet versus KrasWT lungs. Orange pathways are enriched in lungs of PDAC-bearing mice. CD4<sup>+</sup> /CD8<sup>+</sup> T cells in the PTN have features typical of activated, non-exhausted effector T cells, such as increased oxidative phosphorylation and decreased immune checkpoint upregulation.<sup>64</sup> We observed downregulation of sumoylation, activation, and pro-inflammatory functions of T-helper 17 (Th17) cells, previously linked to tumor growth,123,124 as well as upregulation of macrophage-stimulating Th1 subtypes. Differentially expressed gene analysis also showed proliferation and differentiation of infiltrating B cells (phosphatidylinositol 3-kinase [PI3K], NK-kB, Rac, and B cell receptor signaling). Moreover, we observed activation of pathways involved in T cell receptor-mediated stimulation, including CD28, T cell receptor, and protein kinase C-theta signaling pathways. No significant changes in NK signaling were observed in the PTN.

- (D) Dot plot of *Itgb2* expression in subclusters of the macrophage population (scRNA-seq cluster #8) in KrasHet lungs.
- (E) Quantification of the major CD45<sup>+</sup> immune cell subtypes in the lungs of control or B16F10 metastasis-bearing C57BL/6J mice, measured by flow cytometry, namely F4/80<sup>+</sup> Ly6C<sup>+</sup> MHC-II<sup>+</sup> monocytes/macrophages, CD11b<sup>+</sup> Ly6G<sup>+</sup> neutrophils, CD11b<sup>+</sup> Ly6GSiglecF<sup>+</sup> eosinophils, CD11bCD3<sup>+</sup> T cells, CD11bCD3CD19<sup>+</sup> B cells, and CD3CD49d<sup>+</sup> NK1.1<sup>+</sup> NK cells.<sup>125</sup>
- (F) Quantification (left) and dot plots (right) of SiglecF IMs and SiglecF+ AMs within the F4/80<sup>+</sup> Ly6CMHC-II<sup>+</sup> macrophage population in the lungs of control or B16F10 metastasis-bearing C57BL/6J mice, measured by flow cytometry.
- (G and H) Quantification of IM numbers and M2-like polarization (CD206 expression) by flow cytometry (G) or IF (H) of F480<sup>+</sup> SiglecFb<sup>2</sup> <sup>+</sup> IMs in lungs from control or B16F10 metastasis-bearing C57BL/6J mice. ADJ, adjacent lung; MET, metastatic nodule.

(I and J) Quantification (I) and contour plot (J) of flow-cytometry analysis of lungs from mice bearing B16F10 metastasis and depleted of IMs (anti-CSF1R antibody, top) or neutrophils (anti-Ly6G/C antibody, bottom). CD45<sup>+</sup> immune phenotyping was done following, in part,<sup>125</sup> and included the following cell subtypes: CD11b<sup>+</sup> Ly6G<sup>+</sup> neutrophils, CD11b<sup>+</sup> Ly6GSiglecF<sup>+</sup> eosinophils, CD3CD49d<sup>+</sup> NK1.1<sup>+</sup> NK cells, CD11bCD3CD19<sup>+</sup> B cells, CD11bCD3<sup>+</sup> T cells, F4/ 80<sup>+</sup> Ly6CSiglecFCD206+/ IMs, and F4/80<sup>+</sup> Ly6CSiglecF<sup>+</sup> AMs.

(K and L) Quantification (K) and representative H&E images (L) of lungs from C57BL/6J mice bearing established B16F10 metastases and receiving IM-depleting anti-CSF1R antibody or isotype control (IgG) as described in Figure 4N.

(M and N) Survival curves (M) and blood platelet count (N) from C57BL/6J mice injected with 5 mg of sEVs from B16F10 metastasis-bearing lungs. sEV donor mice were depleted of selected immune cells before lung sEV collection: IMs (anti-CSF1R antibody), mature T and B cells (Rag2 KO mice), or neutrophils (anti-Ly6G/C antibody).

Data are represented as mean ± SD. Statistical significance was evaluated using two-tailed unpaired t test (A, E, F, G, and K), two-way ANOVA with uncorrected Fisher's LSD test (I), and one-way ANOVA with Tukey test (N). ns, not significant; \**p* < 0.05; \*\**p* < 0.01; \*\*\*\**p* < 0.0001.

![](_page_42_Picture_1.jpeg)

![](_page_42_Figure_2.jpeg)

Figure S6. Resident IMs proliferate in the PTN, related to Figure 5

(A) Heatmap of RNA levels of various markers of IMs and monocyte-derived macrophages in the macrophage cluster (cluster #8) from scRNA-seq and CITE-seq analysis of lungs from Kras<sup>WT</sup> and Kras<sup>Het</sup> KPC mice, indicating preferential enrichment of IM markers.

(B) Flow-cytometry analysis of circulating CD45<sup>+</sup> immune cells in the blood of control (Kras<sup>WT</sup>) or PDAC-bearing (Kras<sup>Het</sup>) KPC mice at 18 weeks of age. Immunophenotyping was done based on the following markers on CD45<sup>+</sup> single live cells<sup>125</sup>: CD11b<sup>+</sup>Ly6G<sup>-</sup>SiglecF<sup>+</sup> eosinophils, CD11b<sup>+</sup>Ly6G<sup>+</sup> neutrophils, CD11b<sup>+</sup>F4/80<sup>+</sup>Ly6C<sup>+</sup>MHC-II<sup>-</sup> monocytes, and CD11b<sup>+</sup>F4/80<sup>+</sup>Ly6C<sup>-</sup>MHC-II<sup>+</sup> macrophages.

(C–E) Representative confocal images (C) and quantification (D and E) of CCR2\*F4/80\* monocytes (top in C and D) and Ki67\*F4/80\* macrophages (C, bottom, and E) in the lungs of Kras<sup>WT</sup> control and Kras<sup>Het</sup> KPC mice.

(F and G) Representative confocal images (F) and quantification (G) of numbers of  $\beta_2$ +F4/80+ macrophages in the lungs of NOD SCID mice treated every 2–3 days for 3 weeks with PBS or 10  $\mu$ g of sEVs from PDAC patient-derived organoids.

Data are represented as mean  $\pm$  SD. Statistical significance was evaluated using two-way ANOVA with Bonferroni test (B) and two-tailed unpaired t test (D, E, and G). ns, not significant; \*p < 0.05; \*\*p < 0.01.

![](_page_43_Figure_2.jpeg)

Figure S7. sEV integrin  $\alpha_X \beta_2$  interacts with platelets, related to Figure 6

(A) Western blot of integrin  $\beta_2$  coIP on sEVs from lungs of  $Itgb2^{-/-}$  mice (negative control), C57BL/6J mice, or C57BL/6J mice bearing B16F10 metastasis. The immunoprecipitate was blotted for known  $\alpha$  partners of  $\beta_2$  ( $\alpha_D$ ,  $\alpha_L$ ,  $\alpha_M$ , and  $\alpha_X$ ) and loading control (syntenin).

![](_page_44_Picture_0.jpeg)

![](_page_44_Picture_1.jpeg)

(B and C) Representative dSTORM images of platelet GPIbβ (magenta), PS (annexin V, cyan), and sEVs (pan-tetraspanin CD9/63/81, yellow) (B) and quantification of PS and sEV localizations (C) on the surface of platelets incubated with vehicle (PBS), collagen (positive control), or sEVs from B16F10 or KPC4662 metastasis-bearing lungs from C57BL/6J mice.

(D–J) Quantification (D, E, G, and I) and contour plot (F, H, and J) of flow-cytometry aggregometry test measuring annexin V binding or CD62P levels on platelets incubated with sEVs from B16F10 or KPC4662 metastasis-bearing lungs. Platelets were fixed with 1% formaldehyde solution (D and F) or treated with 10 U/mL heparin (E and F), 10 µM amiloride (G–J, purple bars), or 10 µM chlorpromazine (G–J, orange bars) for 30 min before the aggregometry test.

(K) Representative dSTORM images and quantification of TF (cyan), FVII (red), FX (magenta), and pan-tetraspanin (CD9/63/81, yellow) localizations on sEVs from lungs of mice bearing B16F10 or KPC4662 metastases.

(L) Diagram of the proposed steps leading to platelet aggregation by sEVs. Briefly, sEV-bound  $\beta_2$  interacts with platelet GPIb to induce platelet activation and PS exposure, which provides a negatively charged surface for the assembly of the TF/FVIIa/FXa complex on sEVs. The prothrombinase complex then activates thrombin and leads to fibrin deposition and clot formation.

(M and N) Quantification of flow cytometry aggregometry test measuring annexin V binding (M) and aggregation (N) of CD61 $^+$  platelets incubated with sEVs from B16F10 metastasis-bearing lungs and anti- $\beta_2$  antibody, anti-TF antibody, or recombinant mouse TFPI protein (100  $\mu$ g/mL).

(O) Functional blockade of  $\beta_2$  ligands, namely GPIb $\alpha$  (R300 antibody, 100  $\mu$ g/mL), ICAM-1 (anti-ICAM-1 antibody, 100  $\mu$ g/mL), PAR4 (BMS986120, 13.3  $\mu$ g/mL), thrombin (heparin, 13.3 U/mL), and/or GPIIb/IIIa (eptifibatide, 6.7  $\mu$ g/mL), on platelets and/or sEVs from B16F10 metastasis-bearing lungs of C57BL/6J mice. sEVs and platelets were co-incubated during the aggregation test and CD61<sup>+</sup> platelet aggregation was analyzed via flow cytometry.

Data are represented as mean  $\pm$  SD (C, D, E, G, I, and O) and min to max (M and N). Statistical significance was evaluated using one-way ANOVA with Tukey test (C, top, M, and N) or Dunnett test (D, E, G, I, and O) and Pearson correlation test (C, bottom). ns, not significant;  $^*p < 0.05$ ;  $^{**}p < 0.01$ ;  $^{***}p < 0.001$ ;  $^{***}p < 0.001$ .