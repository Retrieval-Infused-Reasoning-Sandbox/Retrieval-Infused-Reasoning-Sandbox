# The EMT-activator Zeb1 is a key factor for cell plasticity and promotes metastasis in pancreatic cancer

Brabletz, Thomas

# References

Brabletz, T. To differentiate or not—routes towards metastasis. Nat. Rev. Cancer
 425–436 (2012).

#### Article CAS PubMed Google Scholar

<sup>2.</sup> Kalluri, R. & Weinberg, R. A. The basics of epithelial-mesenchymal transition. *J. Clin. Invest.* **119**, 1420–1428 (2009).

# Article CAS PubMed PubMed Central Google Scholar

<sup>3.</sup> Nieto, M. A., Huang, R. Y.-J., Jackson, R. A. & Thiery, J. P. EMT: 2016. *Cell* **166**, 21–45 (2016).

# Article CAS PubMed Google Scholar

<sup>4.</sup> Brabletz, S. & Brabletz, T. The ZEB/miR-200 feedback loop—a motor of cellular plasticity in development and cancer? *EMBO Rep.* **11**, 670–677 (2010).

# Article CAS PubMed PubMed Central Google Scholar

<sup>5.</sup> Vandewalle, C., Van Roy, F. & Berx, G. The role of the ZEB family of transcription factors in development and disease. *Cell. Mol. Life Sci.* **66**, 773–787 (2009).

# Article CAS PubMed Google Scholar

6. Zhang, P., Sun, Y. & Ma, L. ZEB1: at the crossroads of epithelial-mesenchymal transition, metastasis and therapy resistance. *Cell Cycle* **14**, 481–487 (2015).

# Article CAS PubMed PubMed Central Google Scholar

<sup>7.</sup> Fischer, K. R. et al. Epithelial-to-mesenchymal transition is not required for lung metastasis but contributes to chemoresistance. *Nature* **527**, 472–476 (2015).

## Article CAS PubMed PubMed Central Google Scholar

8. Zheng, X. et al. Epithelial-to-mesenchymal transition is dispensable for metastasis but induces chemoresistance in pancreatic cancer. *Nature* **527**, 525–530 (2015).

# Article CAS PubMed PubMed Central Google Scholar

<sup>9.</sup> Hingorani, S. R. et al. Trp53R172H and KrasG12D cooperate to promote chromosomal instability and widely metastatic pancreatic ductal adenocarcinoma in mice. *Cancer Cell* 7, 469–483 (2005).

# Article CAS PubMed Google Scholar

<sup>10.</sup> Rhim, A. D. et al. EMT and dissemination precede pancreatic tumor formation. *Cell* **148**, 349–361 (2012).

#### Article CAS PubMed PubMed Central Google Scholar

<sup>11.</sup> Higashi, Y. et al. Impairment of T Cell Development in deltaEF1 Mutant Mice. *J. Exp. Med.* **185**, 1467–1480 (1997).

## Article CAS PubMed PubMed Central Google Scholar

- <sup>12.</sup> Brabletz, S. et al. Generation and characterization of mice for conditional inactivation of Zeb1. *Genesis* http://dx.doi.org/10.1002/dvg.23024 (2017).
- 13. Martinelli, P. et al. GATA6 regulates EMT and tumour dissemination, and is a marker of response to adjuvant chemotherapy in pancreatic cancer. *Gut* <a href="http://dx.doi.org/10.1136/gutjnl-2015-311256">http://dx.doi.org/10.1136/gutjnl-2015-311256</a> (2016).
- <sup>14.</sup> Laklai, H. et al. Genotype tunes pancreatic ductal adenocarcinoma tissue tension to induce matricellular fibrosis and tumor progression. *Nat. Med.* **22**, 497–505 (2016).

#### Article CAS PubMed PubMed Central Google Scholar

<sup>15.</sup> Erkan, M. et al. The activated stroma index is a novel and independent prognostic marker in pancreatic ductal adenocarcinoma. *Clin. Gastroenterol. Hepatol.* **6**, 1155–1161 (2008).

# Article PubMed Google Scholar

<sup>16.</sup> Özdemir, B. C. et al. Depletion of carcinoma-associated fibroblasts and fibrosis induces immunosuppression and accelerates pancreas cancer with reduced survival. *Cancer Cell* **25**, 719–734 (2014).

#### Article PubMed PubMed Central CAS Google Scholar

<sup>17.</sup> Rhim, A. D. et al. Stromal elements act to restrain, rather than support, pancreatic ductal adenocarcinoma. *Cancer Cell* **25**, 735–747 (2014).

# Article CAS PubMed PubMed Central Google Scholar

<sup>18.</sup> Tsai, J. H., Donaher, J. L., Murphy, D. A., Chau, S. & Yang, J. Spatiotemporal regulation of epithelial-mesenchymal transition is essential for squamous cell carcinoma metastasis. *Cancer Cell* **22**, 725–736 (2012).

# Article CAS PubMed PubMed Central Google Scholar

<sup>19.</sup> Ocaña, O. H. et al. Metastatic colonization requires the repression of the epithelial-mesenchymal transition inducer Prrx1. *Cancer Cell* **22**, 709–724 (2012).

#### Article CAS PubMed Google Scholar

<sup>20.</sup> Korpal, M. et al. Direct targeting of Sec23a by miR-200s influences cancer cell secretome and promotes metastatic colonization. *Nat. Med.* **17**, 1101–1108 (2011).

#### Article CAS PubMed PubMed Central Google Scholar

<sup>21.</sup> Raj, D., Aicher, A. & Heeschen, C. Concise review: stem cells in pancreatic cancer: from concept to translation. *Stem Cells* **33**, 2893–2902 (2015).

#### Article PubMed Google Scholar

<sup>22.</sup> Vannier, C., Mock, K., Brabletz, T. & Driever, W. Zeb1 regulates E-cadherin and Epcam (epithelial cell adhesion molecule) expression to control cell behavior in early zebrafish development. *J. Biol. Chem.* **288**, 18643–18659 (2013).

# Article CAS PubMed PubMed Central Google Scholar

<sup>23.</sup> Dosch, J. S., Ziemke, E. K., Shettigar, A., Rehemtulla, A. & Sebolt-Leopold, J. S. Cancer stem cell marker phenotypes are reversible and functionally homogeneous in a preclinical model of pancreatic cancer. *Cancer Res.* **75**, 4582–4592 (2015).

# Article CAS PubMed PubMed Central Google Scholar

<sup>24.</sup> Wellner, U. et al. The EMT-activator ZEB1 promotes tumorigenicity by repressing stemness-inhibiting microRNAs. *Nat. Cell Biol.* **11**, 1487–1495 (2009).

# Article CAS PubMed Google Scholar

 $^{25}\cdot$  Herreros-Villanueva, M. et al. SOX2 promotes dedifferentiation and imparts stem

# Article CAS PubMed PubMed Central Google Scholar

<sup>26.</sup> Sanada, Y. et al. Histopathologic evaluation of stepwise progression of pancreatic carcinoma with immunohistochemical analysis of gastric epithelial transcription factor SOX2: comparison of expression patterns between invasive components and cancerous or nonneoplastic intraductal components. *Pancreas* **32**, 164–170 (2006).

#### Article CAS PubMed Google Scholar

<sup>27.</sup> Singh, S. K. et al. Antithetical NFATc1–Sox2 and p53–miR200 signaling networks govern pancreatic cancer cell plasticity. *EMBO J.* **34**, 517–530 (2015).

# Article CAS PubMed PubMed Central Google Scholar

<sup>28</sup>. Muller, P. A. J. & Vousden, K. H. Mutant p53 in cancer: new functions and therapeutic opportunities. *Cancer Cell* **25**, 304–317 (2014).

#### Article CAS PubMed PubMed Central Google Scholar

<sup>29.</sup> Rivlin, N., Koifman, G. & Rotter, V. p53 orchestrates between normal differentiation and cancer. *Semin. Cancer Biol.* **32**, 10–17 (2015).

# Article CAS PubMed Google Scholar

<sup>30.</sup> Morton, J. P. et al. Mutant p53 drives metastasis and overcomes growth arrest/senescence in pancreatic cancer. *Proc. Natl Acad. Sci. USA* **107**, 246–251 (2010).

## Article CAS PubMed Google Scholar

<sup>31.</sup> Lehmann, W. et al. ZEB1 turns into a transcriptional activator by interacting with YAP1 in aggressive cancer types. *Nat. Commun.* 7, 10498 (2016).

# Article CAS PubMed PubMed Central Google Scholar

<sup>32.</sup> Mock, K. et al. The EMT-activator ZEB1 induces bone metastasis associated genes including BMP-inhibitors. *Oncotarget* **6**, 14399–14412 (2015).

#### PubMed PubMed Central Google Scholar

33. Brabletz, S. et al. The ZEB1/miR-200 feedback loop controls Notch signalling in cancer cells. *EMBO J.* **30**, 770–782 (2011).

#### Article CAS PubMed PubMed Central Google Scholar

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

<sup>34.</sup> Singh, A. et al. A gene expression signature associated with "K-Ras addiction" reveals regulators of EMT and tumor cell survival. *Cancer Cell* **15**, 489–500 (2009).

#### Article CAS PubMed PubMed Central Google Scholar

<sup>35.</sup> Nakamura, T., Fidler, I. J. & Coombes, K. R. Gene expression profile of metastatic human pancreatic cancer cells depends on the organ microenvironment. *Cancer Res.* **67**, 139–148 (2007).

#### Article CAS PubMed Google Scholar

<sup>36.</sup> Collisson, E. A. et al. Subtypes of pancreatic ductal adenocarcinoma and their differing responses to therapy. *Nat. Med.* **17**, 500–503 (2011).

## Article CAS PubMed PubMed Central Google Scholar

<sup>37.</sup> Weissmueller, S. et al. Mutant p53 drives pancreatic cancer metastasis through cell-autonomous PDGF receptor  $\beta$  signaling. *Cell* **157**, 382–394 (2014).

# Article CAS PubMed PubMed Central Google Scholar

<sup>38.</sup> Diepenbruck, M. & Christofori, G. Epithelial—mesenchymal transition (EMT) and metastasis: yes, no, maybe? *Curr. Opin. Cell Biol.* **43**, 7–13 (2016).

#### Article CAS PubMed Google Scholar

<sup>39.</sup> Ye, X. & Weinberg, R. A. Epithelial—mesenchymal plasticity: a central regulator of cancer progression. *Trends Cell Biol.* **25**, 675–686 (2015).

# Article CAS PubMed PubMed Central Google Scholar

<sup>40.</sup> Bellomo, C., Caja, L. & Moustakas, A. Transforming growth factor [beta] as regulator of cancer stemness and metastasis. *Br. J. Cancer* **115**, 761–769 (2016).

# Article CAS PubMed PubMed Central Google Scholar

<sup>41.</sup> Korpal, M. & Kang, Y. Targeting the transforming growth factor-β signalling pathway in metastatic cancer. *Eur. J. Cancer* **46**, 1232–1240 (2010).

# Article CAS PubMed Google Scholar

<sup>42.</sup> Lehuédé, C., Dupuy, F., Rabinovitch, R., Jones, R. G. & Siegel, P. M. Metabolic plasticity as a determinant of tumor growth and metastasis. *Cancer Res.* **76**, 5201–5208 (2016).

#### Article PubMed CAS Google Scholar

<sup>43.</sup> Nieto, M. A. Epithelial plasticity: a common theme in embryonic and cancer cells. *Science* **342**, 1234850 (2013).

#### Article PubMed CAS Google Scholar

<sup>44.</sup> Brabletz, T. et al. Variable beta-catenin expression in colorectal cancer indicates a tumor progression driven by the tumor environment. *Proc. Natl Acad. Sci. USA* **98**, 10356–10361 (2001).

#### Article CAS PubMed PubMed Central Google Scholar

<sup>45.</sup> Chaffer, C. L. et al. Normal and neoplastic nonstem cells can spontaneously convert to a stem-like state. *Proc. Natl Acad. Sci. USA* **108**, 7950–7955 (2011).

#### Article CAS PubMed PubMed Central Google Scholar

46. Puisieux, A., Brabletz, T. & Caramel, J. Oncogenic roles of EMT-inducing transcription factors. *Nat. Cell Biol.* **16**, 488–494 (2014).

# Article CAS PubMed Google Scholar

47. Chaffer, C. L. et al. Poised chromatin at the ZEB1 promoter enables breast cancer cell plasticity and enhances tumorigenicity. *Cell* **154**, 61–74 (2013).

#### Article CAS PubMed PubMed Central Google Scholar

<sup>48.</sup> Gruber, R. et al. YAP1 and TAZ control pancreatic cancer initiation in mice by direct up-regulation of JAK–STAT3 signaling. *Gastroenterology* **151**, 526–539 (2016).

#### Article CAS PubMed Google Scholar

<sup>49.</sup> Zhang, W. et al. Downstream of mutant KRAS, the transcription regulator YAP Is essential for neoplastic progression to pancreatic ductal adenocarcinoma. *Sci. Signal.* 7, ra42-ra42 (2014).

#### Google Scholar

<sup>50.</sup> Moffitt, R. A. et al. Virtual microdissection identifies distinct tumor- and stromaspecific subtypes of pancreatic ductal adenocarcinoma. *Nat. Genet.* **47**, 1168–1178 (2015).

# Article CAS PubMed PubMed Central Google Scholar

<sup>51.</sup> Galvan, J. A. et al. Expression of E-cadherin repressors SNAIL, ZEB1 and ZEB2 by tumour and stromal cells influences tumour-budding phenotype and suggests heterogeneity of stromal cells in pancreatic cancer. *Br. J. Cancer* **112**, 1944–1950 (2015).

#### Article CAS PubMed PubMed Central Google Scholar

<sup>52.</sup> Bronsert, P. et al. Prognostic significance of Zinc finger E-box binding homeobox 1 (ZEB1) expression in cancer cells and cancer-associated fibroblasts in pancreatic head cancer. *Surgery* **156**, 97–108 (2014).

# Article PubMed Google Scholar

53. Singh, A. & Settleman, J. EMT, cancer stem cells and drug resistance: an emerging axis of evil in the war on cancer. *Oncogene* **29**, 4741–4751 (2010).

#### Article CAS PubMed PubMed Central Google Scholar

<sup>54.</sup> Eser, S., Schnieke, A., Schneider, G. & Saur, D. Oncogenic KRAS signalling in pancreatic cancer. *Br. J. Cancer* **111**, 817–822 (2014).

# Article CAS PubMed PubMed Central Google Scholar

<sup>55.</sup> Ni, T. et al. Snail1-dependent p53 repression regulates expansion and activity of tumour-initiating cells in breast cancer. *Nat. Cell Biol.* **18**, 1221–1232 (2016).

# Article CAS PubMed PubMed Central Google Scholar

 $^{56}$ . Turajlic, S. & Swanton, C. Metastasis as an evolutionary process. *Science* **352**,  $^{169-175}$  (2016).

#### Article CAS PubMed Google Scholar

<sup>57.</sup> Caramel, J. et al. A switch in the expression of embryonic EMT-inducers drives the development of malignant melanoma. *Cancer Cell* **24**, 466–480 (2013).

#### Article CAS PubMed Google Scholar

<sup>58.</sup> Denecker, G. et al. Identification of a ZEB2-MITF-ZEB1 transcriptional network that controls melanogenesis and melanoma progression. *Cell Death Differ*. **21**, 1250–1261 (2014).

#### Article CAS PubMed PubMed Central Google Scholar

59. Ye, X. et al. Distinct EMT programs control normal mammary stem cells and tumour-initiating cells. *Nature* 525, 256–260 (2015)

......................................

#### Article CAS PubMed PubMed Central Google Scholar

60. Tiwari, N. et al. Sox4 is a master regulator of epithelial-mesenchymal transition by controlling Ezh2 expression and epigenetic reprogramming. *Cancer Cell* **23**, 768–783 (2013).

#### Article CAS PubMed Google Scholar

61. Tran, H. D. et al. Transient SNAIL1 expression is necessary for metastatic competence in breast cancer. *Cancer Res.* **74**, 6330–6340 (2014).

# Article CAS PubMed PubMed Central Google Scholar

62. Olive, K. P. et al. Mutant p53 gain of function in two mouse models of Li-Fraumeni syndrome. *Cell* **119**, 847–860 (2004).

#### Article CAS PubMed Google Scholar

63. Jackson, E. L. et al. Analysis of lung tumor initiation and progression using conditional expression of oncogenic K-ras. *Genes Dev.* **15**, 3243–3248 (2001).

#### Article CAS PubMed PubMed Central Google Scholar

64. Hingorani, S. R. et al. Preinvasive and invasive ductal pancreatic cancer and its early detection in the mouse. *Cancer Cell* **4**, 437–450 (2003).

# Article CAS PubMed Google Scholar

65. Chan, I. T. et al. Conditional expression of oncogenic K-ras from its endogenous promoter induces a myeloproliferative disease. *J. Clin. Invest.* **113**, 528–538 (2004).

#### Article CAS PubMed PubMed Central Google Scholar

66. Novak, A., Guo, C., Yang, W., Nagy, A. & Lobe, C. G. Z/EG, a double reporter mouse line that expresses enhanced green fluorescent protein upon Cre-mediated excision. *Genesis* **28**, 147–155 (2000).

#### Article CAS PubMed Google Scholar

67. Murray, S. A., Carver, E. A. & Gridley, T. Generation of a Snail1 (Snai1) conditional null allele. *Genesis* **44**, 7–11 (2006).

# Article CAS PubMed Google Scholar

68 \_ . . . . . . . . . . . . . . . . . .

Meidhot, S. et al. ZEB1-associated drug resistance in cancer cells is reversed by the class I HDAC inhibitor mocetinostat. *EMBO Mol. Med.* 7, 831–847 (2015).

#### Article CAS PubMed PubMed Central Google Scholar

69. Dunning, M. J., Smith, M. L., Ritchie, M. E. & Tavare, S. beadarray: R classes and methods for Illumina bead-based data. *Bioinformatics* **23**, 2183–2184 (2007).

#### Article CAS PubMed Google Scholar

<sup>70.</sup> Johnson, W. E., Li, C. & Rabinovic, A. Adjusting batch effects in microarray expression data using empirical Bayes methods. *Biostatistics* **8**, 118–127 (2007).

Article PubMed Google Scholar

Download references

# Acknowledgements

We thank B. Schlund, E. Bauer and J. Pfannstiel, as well as U. Appelt and M. Mroz (Core Unit Cell Sorting and Immunomonitoring, FAU Erlangen, Germany) for technical assistance and R. Eccles for critical reading of the manuscript. We are grateful to D. Saur (Department of Internal Medicine, TU Munich, Germany) for providing the KPCS cell lines. We thank J. C. Wu, from Stanford University, for the MSCV-LUC\_EF1-GFP-T2A-Puro plasmid. This work was supported by grants to T.B., S.B., M.B. and M.P.S. from the German Research Foundation (SFB850/A4, B2, Z1 and DFG BR 1399/9-1, DFG 1399/10-1, DFG BR4145/1-1) and from the German Consortium for Translational Cancer Research (DKTK).

# **Author information**

**Author notes** 

<sup>1.</sup> Marc P. Stemmler and Thomas Brabletz: These authors jointly supervised this work.

#### **Authors and Affiliations**

Department of Experimental Medicine 1, Nikolaus-Fiebiger-Center for Molecular Medicine, FAU University Erlangen-Nürnberg, Glückstrasse 6, 91054 Erlangen, Germany

Angela M. Krebs, María Lasierra Losada, Simone Brabletz, Marc P.

Stommler & Thomas Probletz

<sup>2.</sup> University of Freiburg, Faculty of Biology, Schaenzlestrasse 1, 79104 Freiburg, Germany

Angela M. Krebs

- 3. German Cancer Consortium (DKTK), 79106 Freiburg, Germany
  Angela M. Krebs, Melanie Boerries, Hauke Busch, Wilfried Reichardt & Peter Bronsert
- 4. German Cancer Research Center (DKFZ), 69121 Heidelberg, Germany Angela M. Krebs, Melanie Boerries, Hauke Busch, Wilfried Reichardt & Peter Bronsert
- 5. Department of General and Visceral Surgery, University of Freiburg Medical Center, Hugstetter Strasse 55, 79106 Freiburg, Germany

Julia Mitschke & Otto Schmalhofer

6. Systems Biology of the Cellular Microenvironment Group, Institute of Molecular Medicine and Cell Research (IMMZ), Albert-Ludwigs-University Freiburg, Stefan-Meier-Strasse 17, 79106 Freiburg, Germany

Melanie Boerries & Hauke Busch

7. Department of Internal Medicine 5, Hematology and Oncology, Universitätsklinikum, FAU University Erlangen-Nürnberg, Ulmenweg 18, 91054 Erlangen, Germany

Martin Boettcher & Dimitrios Mougiakakos

8. Department of Radiology Medical Physics, University Medical Center, Freiburg, Breisacher Strasse 60a, 79106 Freiburg, Germany

Wilfried Reichardt

9. Institute of Pathology and Comprehensive Cancer Center, University Medical Center, Freiburg, Breisacher Strasse 115a, 79106 Freiburg, Germany

**Peter Bronsert** 

<sup>10.</sup> Edinburgh Cancer Research Centre, Institute of Genetics & Molecular Medicine, University of Edinburgh, Crewe Road South, Edinburgh EH4 2XR, UK Valerie G. Brunton

<sup>11.</sup> Department of Surgery, Universitätsklinikum, FAU University Erlangen-Nürnberg, Ulmenweg 18, 91054 Erlangen, Germany

Christian Pilarsky

<sup>12.</sup> Department Biology, Chair of Genetics, Nikolaus-Fiebiger-Center for Molecular Medicine, FAU University Erlangen-Nürnberg, Glückstrasse 6, 91054 Erlangen, Germany

Thomas H. Winkler

#### **Authors**

- <sup>1.</sup> Angela M. Krebs
- <sup>2.</sup> Julia Mitschke
- 3. María Lasierra Losada
- 4. Otto Schmalhofer
- 5. Melanie Boerries
- 6. Hauke Busch
- 7. Martin Boettcher
- 8. Dimitrios Mougiakakos
- 9. Wilfried Reichardt
- <sup>10</sup>. Peter Bronsert
- <sup>11.</sup> Valerie G. Brunton
- <sup>12.</sup> Christian Pilarsky
- <sup>13.</sup> Thomas H. Winkler
- <sup>14.</sup> Simone Brabletz
- <sup>15.</sup> Marc P. Stemmler
- <sup>16</sup>. Thomas Brabletz

#### **Contributions**

A.M.K. planned and carried out experiments and wrote the manuscript. J.M. carried out mouse experiments. M.L.L. carried out drug studies. O.S. generated the floxed Zeb1 allele. M.B. and H.B. carried out bioinformatics analyses. M.B. and D.M. carried out metabolic tests. W.R. carried out MRI analyses. P.B. carried out histological analyses. V.G.B. established mouse models. C.P. generated cell lines. T.H.W. carried out mouse experiments. S.B. generated the floxed Zeb1 allele, and planned and carried out experiments. M.P.S. generated the floxed Zeb1 allele, planned and carried out mouse experiments, was involved in coordination and wrote the manuscript. T.B. planned and coordinated the project, analysed data and wrote the manuscript. M.P.S. and T.B.

contributed equally and share senior authorship.

# **Corresponding authors**

Correspondence to Marc P. Stemmler or Thomas Brabletz.

# **Ethics declarations**

## **Competing interests**

The authors declare no competing financial interests.

# **Integrated supplementary information**

# <u>Supplementary Figure 1 Characterisation of KPC,</u> heterozygously and homozygously *Zeb1* depleted KPC tumours.

(a) Representative Zeb1-immunolabeling of a GFP lineage-traced primary tumour showing Zeb1/GFP double-positive tumour cells (arrows). n = 5 independent tumors. Scale bar, 50 µm. (b) Representative consecutive sections of HE and indicated immunohistochemical stainings of four Zeb1 expressing KPC tumours demonstrating the heterogeneity in phenotype, grading and marker expression. A representative differentiated Zeb1-negative KPCZ tumour is shown for comparison. Arrows indicate Zeb1 positive tumour cells in the differentiated KPC tumour. n = 15 KPC, 13 KPCZ independent tumours. Scale bar, 100 µm. (c) Tumour-free survival of KPC mice vs. KPC mice with a heterozygous deletion of Zeb1 (KPCz) (n = 15 KPC, 16 KPCz independent tumours); log-rank (Mantel-Cox) test); tumour volume (o = start of MRI measurements, n = 12 KPC, 14 KPCz independent tumours); error bars show mean  $\pm$ S.E.M.; multiple t-tests with correction for multiple comparison using the Holm-Sidak method; grading, local invasion and relative ECM deposition of the respective tumours (n = 31 KPC, 17 KPCz; Mann-Whitney test (two-tailed); percentage of metastasized tumours (n = 35 KPC, 17 KPCz independent tumours; Chi-square test (two-tailed); n.s. = not significant.

# <u>Supplementary Figure 2 Characterisation of KPC vs. KPCZ</u> tumours.

Representative images of immunohistochemical and histological stainings of KPC and KPCZ tumours and quantifications of the indicated markers are given. Asterisks label Zeb1-expressing stroma cells in KPCZ tumours. Specific blue MTS staining labels

collagen fibres. Scale bars, 100  $\mu$ m, for lower left image 50  $\mu$ m. n = 48 KPC, 29 KPCZ independent tumours for Zeb1 and MTS; n = 15 independent tumours for KPC, 13 independent tumours for KPCZ for all other markers, error bars show mean  $\pm$  S.D.; \*\*\*\*p < 0.0001, n.s. = not significant, Chi-square test (two-tailed) for Zeb1, E-cadherin and Sox2, unpaired Student's t-test (two-tailed) for Ki67 and Casp3 (with Welch's correction), Mann-Whitney test (two-tailed) for ECM and CD31.

# <u>Supplementary Figure 3 Characterisation of differentiaton</u> markers in KPC vs. KPCZ tumours.

(a) Representative images of positive and negative immunohistochemical stainings and statistical analysis for the indicated EMT-TFs. Scale bar, 150  $\mu$ m. n = 14 independent tumours for KPC, 13 independent tumours for KPCZ, Chi-square test (two-tailed); n.s. = not significant. (b) Representative images of immunohistochemical stainings and statistical analysis for expression of Gata6. Scale bar, 150  $\mu$ m. n = 14 independent tumours for KPC, 13 independent tumours for KPCZ; error bars show mean  $\pm$  S.D.; Mann-Whitney test (two-tailed), \*\*\*p < 0.001. (c) Representative images of differentiated KPCZ and undifferentiated KPC primary tumours (PT) and corresponding metastases (Met) with the same phenotype. Immunohistochemical labelling of Zeb1 expressing tumour cells in the KPC PT and Met (arrows). L = liver or lung tissue. n = 19 KPC, 4 KPCZ independent tumours and corresponding metastases. Scale bar, 100  $\mu$ m.

# <u>Supplementary Figure 4 Characterisation of KPC vs. KPCZ</u> tumour derived cell lines.

(a) Bright field image of primary cell lines from KPC and KPCZ tumours as well as HE stainings of the respective tumours after grafting in syngeneic mice and of the respective primary tumours are shown. Scale bars, 100  $\mu$ m for bright field, 75  $\mu$ m for HE stainings. (b) MTT viability assay for the isolated tumour cell lines after treatment with the indicated doses of gemcitabine and erlotinib. The calculated IC50 values for gemcitabine are shown. n = 3 biologically independent experiments, error bars show mean  $\pm$  S.E.M. (c) Tumour onset after subcutaneous injection of 1 × 10<sup>5</sup> KPC and KPCZ cells into syngeneic mice. n = 4 mice per cell line, error bars show mean  $\pm$  S.E.M. (d) Tumour grading, grading at invasive regions and relative ECM deposition of one representative tumour/cell line analysed in c) (n = 6 tumours for KPC, n = 5 tumours for KPCZ); error bars show mean  $\pm$  S.D.;\*p < 0.05, \*\*p < 0.01, Mann-Whitney test (two-tailed).

# <u>Supplementary Figure 5 Depletion of Zeb1 affects tumour promoting capacities.</u>

(a) Representative images of one visual field (n = 6 fields/cell line) showing GFP + cells/cell clusters in the lungs (green dots) 2 h after i.v. injection of KPC and KPCZ tumour cells and control lungs. Scale bar, 500  $\mu$ m. (b) No. of tumours after subcutaneous injection of the indicated cell numbers for the KPC and KPCZ tumour cell lines and calculated fraction of tumourigenic cells. inf = infinite, Chi-square test. (c) Representative images showing spheres of KPC and KPCZ tumour cells. Scale bar, 500  $\mu$ m and 50  $\mu$ m for higher magnifications. (d) Percentage of cells in KPC and KPCZ lines positive for the indicated markers or marker combinations; n = 2 biologically independent experiments, error bars show  $\pm$  S.D. Source data see Supplementary Table 5, Statistics Source Data. Relative mRNA expression levels (qRT-PCR) of indicated genes, mRNA levels of KPC661 was set to 1; n = 3 biologically independent experiments, Mann-Whitney test (two-tailed), \*p < 0.05, \*\*p < 0.01, error bars show mean  $\pm$  S.E.M.

# <u>Supplementary Figure 6 Depletion of Zeb1 reduces early PanIN</u> lesions.

(a) Consecutive sections showing representative HE and PAS stainings of precancerous PanIN lesions in the pancreas of two different 6 month old KC and of one KCZ mice. Specific dark blue PAS staining indicates the mucin-rich PanIN lesions. Scale bars, 2.5 mm and 150  $\mu$ m for higher magnifications. Quantification of the PanIN area (% of pancreas area). n = 12 KC and 7 KCZ independent mice, error bars show mean  $\pm$  S.D.; \*\*p < 0.01, unpaired Student's t-test (two tailed) with Welch's correction. (b) Gene set enrichment analyses (GSEA) of transcriptome data from KPCZ vs. KPC cells reveals reduction of gene signatures associated with cancer mesenchymal transition and Zeb1 targets in KPCZ vs. KPC cell lines. NES = normalized enrichment score; FDR = false discovery rate.

# <u>Supplementary Figure 7 Depletion of Zeb1 reduces tumour cell</u> plasticity.

(a) Relative mRNA expression levels (qRT-PCR) of indicated genes in KPC and KPCZ cell lines treated for different times with TGF $\beta$  (time points: 0, 6 h, 1, 3, 7, 14, 21 days). mRNA levels of cell line 661 at day 0 were set to 1. n = 3 biologically independent experiments, error bars show mean  $\pm$  S.E.M. Statistical analysis is shown for the comparison of TGF $\beta$  treated to untreated samples (grey bars) of each individual cell line \*p < 0.05, \*\*p < 0.01, \*\*\*p < 0.001, \*\*\*\*p < 0.0001, unpaired Student's t-test (one-tailed) Source data see Supplementary Table 5, Statistics Source Data. (b) Table showing log2FC in mRNA expression levels (microarray) of genes previously determined as common ZEB1/YAP targets in KPC and KPCZ cell lines upon TGF $\beta$ 

treatment for 14 days. (cut-off: adj. p-value < 0.05 and  $\log_2 FC > 0.5$ ). (c) Representative images of consecutive sections of immunohistochemistry for Ck19 and Zeb1 comparing the plasticity of Zeb1 expression in central and invasive tumour regions. Tumours derived from one KPC and one KPCZ cell line are shown. Asterisks label Zeb1 expression in stroma cells, arrows indicate Zeb1 expression in tumour cells at the invasive front. Ck19 expression is shown to identify cancer cells. n = 15 KPC, 13 KPCZ independent tumours, Scale bars, 50  $\mu$ m and 150  $\mu$ m for higher magnifications.

# About this article

![](_page_14_Picture_2.jpeg)

#### Cite this article

Krebs, A., Mitschke, J., Lasierra Losada, M. *et al.* The EMT-activator Zeb1 is a key factor for cell plasticity and promotes metastasis in pancreatic cancer. *Nat Cell Biol* **19**, 518–529 (2017). https://doi.org/10.1038/ncb3513

#### Download citation

• Received: 30 September 2016

\* Accepted: 16 March 2017

• Published: 17 April 2017