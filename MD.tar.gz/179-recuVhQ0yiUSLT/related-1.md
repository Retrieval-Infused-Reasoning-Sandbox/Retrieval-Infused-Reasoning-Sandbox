## **Epithelial-mesenchymal transition**

Contributors to Wikimedia projects

From Wikipedia, the free encyclopedia

| Epithelial-mesenchymal transition  Details |                |  |
|--------------------------------------------|----------------|--|
|                                            |                |  |
| Identifiers                                |                |  |
| <u>MeSH</u>                                | <u>Do58750</u> |  |
| Anatomical terminology                     |                |  |
| [edit on Wikidata]                         |                |  |

The **epithelial**—**mesenchymal transition** (**EMT**) is a process by which <u>epithelial</u> cells lose their <u>cell polarity</u> and cell—cell adhesion, and gain migratory and invasive properties to become <u>mesenchymal stem cells</u>; these are <u>multipotent stromal cells</u> that can differentiate into a variety of cell types. EMT is essential for numerous developmental processes including <u>mesoderm</u> formation and <u>neural tube</u> formation. EMT has also been shown to occur in <u>wound healing</u>, in organ <u>fibrosis</u> and in the initiation of <u>metastasis</u> in cancer progression.

![](_page_0_Picture_5.jpeg)

![](_page_1_Picture_0.jpeg)

Human embryo—length, 2 mm. Dorsal view, with the amnion laid open. X 30.

Epithelial—mesenchymal transition was first recognized as a feature of embryogenesis by Betty Hay in the 1980s. EMT, and its reverse process, MET (mesenchymal-epithelial transition) are critical for development of many tissues and organs in the developing embryo, and numerous embryonic events such as gastrulation, neural crest formation, heart valve formation, secondary palate development, and myogenesis. Epithelial and mesenchymal cells differ in phenotype as well as function, though both share inherent plasticity. Epithelial cells are closely connected to each other by tight junctions, gap junctions and adherens junctions, have an apico-basal polarity, polarization of the actin cytoskeleton and are bound by a basal lamina at their basal surface. Mesenchymal cells, on the other hand, lack this polarization, have a spindle-shaped morphology and interact with each other only through focal points. Epithelial cells express high levels of E-cadherin, whereas mesenchymal cells express those of N-cadherin, fibronectin and vimentin. Thus, EMT entails profound morphological and phenotypic changes to a cell.

Based on the biological context, EMT has been categorized into 3 types: developmental (Type I), fibrosis and wound healing (Type II), and cancer (Type III).

| Marker               | Epithelial or Mesenchymal        |
|----------------------|----------------------------------|
| E-cadherin           | Epithelial                       |
| N-cadherin           |                                  |
| Fibronectin          | Mesenchymal                      |
| Vimentin             |                                  |
| Transcription Factor | <b>Epithelial or Mesenchymal</b> |
| SNAI1/SNAI2          |                                  |
| ZEB1/2               |                                  |
|                      |                                  |
| E47                  |                                  |
| E47<br>ZLF8          |                                  |
|                      | Promotes mesenchymal             |

| Goosecoid         |                                  |
|-------------------|----------------------------------|
| E2.2/TCF4         |                                  |
| SIX1              |                                  |
| FOXC2             |                                  |
| GRHL2             | Promotes epithelial              |
| ELF3/5            |                                  |
| Signaling Pathway | <b>Epithelial or Mesenchymal</b> |
| TGF-β             | Promotes mesenchymal             |
| FGF               |                                  |
| HGF               |                                  |
| Wnt/β-catenin     |                                  |
| Notch             |                                  |
| Hypoxia           |                                  |
| Ras-MAPK          |                                  |
|                   |                                  |

Key inducers of the epithelial to mesenchymal transition process.

![](_page_2_Figure_2.jpeg)

Epithelial to mesenchymal cell transition – loss of cell adhesion leads to constriction and extrusion of newly mesenchymal cell.

Loss of E-cadherin is considered to be a fundamental event in EMT. Many transcription

factors (TFs) that can repress E-cadherin directly or indirectly can be considered as EMT-TF (EMT inducing TFs). SNAI1/Snail 1, SNAI2/Snail 2 (also known as Slug), ZEB1, ZEB2, TCF3 and KLF8 (Kruppel-like factor 8) can bind to the E-cadherin promoter and repress its transcription, whereas factors such as Twist, Goosecoid, TCF4 (also known as E2.2), homeobox protein SIX1 and FOXC2 (fork-head box protein C2) repress E-cadherin indirectly. SNAIL and ZEB factors bind to E-box consensus sequences on the promoter region, while KLF8 binds to promoter through GT boxes. These EMT-TFs not only directly repress E-cadherin, but also repress transcriptionally other junctional proteins, including claudins and desmosomes, thus facilitating EMT. On the other hand, transcription factors such as grainyhead-like protein 2 homologue (GRHL2), and ETS-related transcription factors ELF3 and ELF5 are downregulated during EMT and are found to actively drive MET when overexpressed in mesenchymal cells. Since EMT in cancer progression recaptures EMT in developmental programs, many of the EMT-TFs are involved in promoting metastatic events.

Several signaling pathways (TGF-β, FGF, EGF, HGF, Wnt/beta-catenin and Notch) and hypoxia may induce EMT. In particular, Ras-MAPK has been shown to activate Snail and Slug. Slug triggers the steps of desmosomal disruption, cell spreading, and partial separation at cell–cell borders, which comprise the first and necessary phase of the EMT process. On the other hand, Slug cannot trigger the second phase, which includes the induction of cell motility, repression of the cytokeratin expression, and activation of vimentin expression. Snail and Slug are known to regulate the expression of p63 isoforms, another transcription factor that is required for proper development of epithelial structures. The altered expression of p63 isoforms reduced cell–cell adhesion and increased the migratory properties of cancer cells. The p63 factor is involved in inhibiting EMT and reduction of certain p63 isoforms may be important in the development of epithelial cancers. Some of them are known to regulate the expression of cytokeratins. The phosphatidylinositol 3' kinase (PI3K)/AKT axis, Hedgehog signaling pathway, nuclear factor-kappaB and Activating Transcription Factor 2 have also been implicated to be involved in EMT.

Wnt signaling pathway regulates EMT in gastrulation, cardiac valve formation and cancer. Activation of Wnt pathway in breast cancer cells induces the EMT regulator SNAIL and upregulates the mesenchymal marker, vimentin. Also, active Wnt/beta-catenin pathway correlates with poor prognosis in breast cancer patients in the clinic. Similarly, TGF- $\beta$  activates the expression of SNAIL and ZEB to regulate EMT in heart development, palatogenesis, and cancer. The breast cancer bone metastasis has activated TGF- $\beta$  signaling, which contributes to the formation of these lesions. However, on the other hand, p53, a well-known tumor suppressor, represses EMT by activating the

expression of various <u>microkinas</u> – mik-200 and mik-34 that inhibit the production of protein ZEB and SNAIL, and thus maintain the epithelial phenotype.

## In development and wound healing

#### [edit]

After the initial stage of embryogenesis, the implantation of the embryo and the initiation of placenta formation are associated with EMT. The trophoectoderm cells undergo EMT to facilitate the invasion of endometrium and appropriate placenta placement, thus enabling nutrient and gas exchange to the embryo. Later in embryogenesis, during gastrulation, EMT allows the cells to ingress in a specific area of the embryo – the primitive streak in amniotes, and the ventral furrow in Drosophila. The cells in this tissue express E-cadherin and apical-basal polarity. Since gastrulation is a very rapid process, E-cadherin is repressed transcriptionally by Twist and SNAI1 (commonly called *Snail*), and at the protein level by P38 interacting protein. The primitive streak, through invagination, further generates mesoendoderm, which separates to form a mesoderm and an endoderm, again through EMT. Mesenchymal cells from the primitive streak participate also in the formation of many epithelial mesodermal organs, such as notochord as well as somites, through the reverse of EMT, i.e. mesenchymal-epithelial transition. Amphioxus forms an epithelial neural tube and dorsal notochord but does not have the EMT potential of the primitive streak. In higher chordates, the mesenchyme originates out of the primitive streak migrates anteriorly to form the somites and participate with neural crest mesenchyme in formation of the heart mesoderm.

In vertebrates, <u>epithelium</u> and <u>mesenchyme</u> are the basic tissue phenotypes. During embryonic development, migratory <u>neural crest</u> cells are generated by EMT involving the epithelial cells of the neuroectoderm. As a result, these cells dissociate from neural folds, gain motility, and disseminate to various parts of the embryo, where they differentiate to many other cell types. Also, craniofacial crest mesenchyme that forms the connective tissue forming the head and face, is formed by <u>neural tube</u> epithelium by EMT. EMT takes place during the construction of the vertebral column out of the <u>extracellular matrix</u>, which is to be synthesized by <u>fibroblasts</u> and <u>osteoblasts</u> that encircle the neural tube. The major source of these cells are <u>sclerotome</u> and <u>somite</u> mesenchyme as well as <u>primitive streak</u>. Mesenchymal morphology allows the cells to travel to specific targets in the embryo, where they differentiate and/or induce differentiation of other cells.

During wound healing, keratinocytes at the border of the wound undergo EMT and undergo re-epithelialization or MET when the wound is closed. Snail2 expression at the migratory front influences this state, as its overexpression accelerates wound healing.

Similarly, in each menstrual cycle, the ovarian surface epithelium undergoes EMT during post-ovulatory wound healing.

Initiation of <u>metastasis</u> requires invasion, which is enabled by EMT. Carcinoma cells in a primary tumor lose cell-cell adhesion mediated by E-cadherin repression and break through the basement membrane with increased invasive properties, and enter the bloodstream through <u>intravasation</u>. Later, when these <u>circulating tumor cells</u> (CTCs) exit the bloodstream to form <u>micro-metastases</u>, they undergo MET for clonal outgrowth at these metastatic sites. Thus, EMT and MET form the initiation and completion of the invasion-metastasis cascade. At this new metastatic site, the tumor may undergo other processes to optimize growth. For example, EMT has been associated with <u>PD-L1</u> expression, particularly in lung cancer. Increased levels of PD-L1 suppresses the immune system which allows the cancer to spread more easily.

EMT confers resistance to <u>oncogene</u>-induced premature <u>senescence</u>. Twist1 and Twist2, as well as <u>ZEB1</u> protects human cells and mouse embryonic fibroblasts from senescence. Similarly, TGF- $\beta$  can promote tumor invasion and evasion of immune surveillance at advanced stages. When TGF- $\beta$  acts on activated Ras-expressing mammary epithelial cells, EMT is favored and apoptosis is inhibited. This effect can be reversed by inducers of epithelial differentiation, such as GATA-3.

EMT has been shown to be induced by <u>androgen deprivation therapy</u> in metastatic <u>prostate cancer</u>. Activation of EMT programs via inhibition of the androgen axis provides a mechanism by which tumor cells can adapt to promote disease recurrence and progression. <u>Brachyury, Axl, MEK</u>, and <u>Aurora kinase A</u> are molecular drivers of these programs, and inhibitors are currently in clinical trials to determine therapeutic applications. Oncogenic <u>PKC-iota</u> can promote melanoma cell invasion by activating Vimentin during EMT. PKC-iota inhibition or knockdown resulted an increase E-cadherin and RhoA levels while decreasing total Vimentin, phosphorylated Vimentin (S39) and Par6 in metastatic melanoma cells. These results suggested that PKC-1 is involved in signaling pathways which upregulate EMT in melanoma.

EMT has been indicated to be involved in acquiring drug resistance. Gain of EMT markers was found to be associated with the resistance of ovarian carcinoma epithelial cell lines to paclitaxel. Similarly, SNAIL also confers resistance to paclitaxel, adriamycin and radiotherapy by inhibiting p53-mediated apoptosis. Furthermore, inflammation, that has been associated with the progression of cancer and fibrosis, was recently shown to be related to cancer through inflammation-induced EMT. Consequently, EMT enables cells to gain a migratory phenotype, as well as induce multiple immunosuppression, drug resistance, evasion of apoptosis mechanisms.

Some evidence suggests that cells that undergo EMT gain stem cell-like properties, thus giving rise to <a href="Cancer Stem Cells">Cancer Stem Cells</a> (CSCs). Upon transfection by activated Ras, a subpopulation of cells exhibiting the putative stem cell markers CD44high/CD24low increases with the concomitant induction of EMT. Also, ZEB1 is capable of conferring stem cell-like properties, thus strengthening the relationship between EMT and stemness. Thus, EMT may present increased danger to cancer patients, as EMT not only enables the carcinoma cells to enter the bloodstream, but also endows them with properties of stemness which increases tumorigenic and proliferative potential.

However, recent studies have further shifted the primary effects of EMT away from invasion and metastasis, toward resistance to chemotherapeutic agents. Research on breast cancer and pancreatic cancer both demonstrated no difference in cells' metastatic potential upon acquisition of EMT. These are in agreement with another study showing that the EMT transcription factor TWIST actually requires intact <u>adherens junctions</u> in order to mediate local invasion in breast cancer. The effects of EMT and its relationship to invasion and metastasis may therefore be highly context specific.

In <u>urothelial</u> carcinoma cell lines overexpression of <u>HDAC5</u> inhibits long-term proliferation but can promote epithelial-to-mesenchymal transition (EMT).

#### **Platelets in cancer EMT**

[edit]

![](_page_6_Picture_5.jpeg)

Cancer cells enter the bloodstream after undergoing EMT induced by TGF-β released from platelets. Once in the bloodstream, metastatic cancer cells recruit platelets for use

as a physical barrier that helps protect these cells from elimination by immune cells. The metastatic cancer cell can use the attached platelets to adhere to P-selectin expressed by activated endothelial cells lining the blood vessel walls. Following adhesion to the endothelium, the metastatic cancer cell exits the bloodstream at the secondary site to begin formation of a new tumor.

Platelets in the blood have the ability to initiate the induction of EMT in cancer cells. When platelets are recruited to a site in the blood vessel they can release a variety of growth factors (PDGF, VEGF, Angiopoietin-1) and cytokines including the EMT inducer TGF-β. The release of TGF-β by platelets in blood vessels near primary tumors enhances invasiveness and promotes metastasis of cancer cells in the tumor. Studies looking at defective platelets and reduced platelet counts in mouse models have shown that impaired platelet function is associated with decreased metastatic formation. In humans, platelet counts and thrombocytosis within the upper end of the normal range have been associated with advanced, often metastatic, stage cancer in cervical cancer, ovarian cancer, gastric cancer, and esophageal cancer. Although a great deal of research has been applied to studying interactions between tumor cells and platelets, a cancer therapy targeting this interaction has not yet been established. This may be in part due to the redundancy of prothrombotic pathways which would require the use of multiple therapeutic approaches in order to prevent pro-metastatic events via EMT induction in cancer cells by activated platelets.

To improve the chances for the development of a cancer metastasis, a cancer cell must avoid detection and targeting by the immune system once it enters the bloodstream. Activated platelets have the ability to bind glycoproteins and glycolipids (P-selectin ligands such as PSGL-1) on the surface of cancer cells to form a physical barrier that protects the cancer cell from natural killer cell-mediated lysis in the bloodstream. Furthermore, activated platelets promote the adhesion of cancer cells to activated endothelial cells lining blood vessels using adhesion molecules present on platelets. P-selectin ligands on the surface of cancer cells remain to be elucidated and may serve as potential biomarkers for disease progression in cancer.

## Therapeutics targeting cancer EMT

#### [edit]

Many studies have proposed that induction of EMT is the primary mechanism by which epithelial cancer cells acquire malignant phenotypes that promote metastasis. <a href="Drug development">Drug development</a> targeting the activation of EMT in cancer cells has thus become an aim of pharmaceutical companies.

#### Small molecule inhibitors

#### [edit]

Small molecules that are able to inhibit TGF-β induced EMT are under development. Silmitasertib (CX-4945) is a small molecule inhibitor of protein kinase CK2, which has been supported to be linked with TGF-β induced EMT, and is currently in clinical trials for cholangiocarcinoma (bile duct cancer), as well as in preclinical development for hematological and lymphoid malignancies. In January 2017, Silmitasertib was granted orphan drug status by the U.S. Food and Drug Administration for cholangiocarcinoma and is currently in phase II study. Silmitasertib is being developed by Senhwa Biosciences. Another small molecule inhibitor Galunisertib (LY2157299) is a potent TGF-β type I receptor kinase inhibitor that was demonstrated to reduce the size, the growth rate of tumors, and the tumor forming potential in triple negative breast cancer cell lines using mouse xenografts. Galunisertib is currently being developed by Lilly Oncology and is in phase I/II clinical trials for hepatocellular carcinoma, unresectable pancreatic cancer, and malignant glioma. Small molecule inhibitors of EMT are suggested to not act as a replacement for traditional chemotherapeutic agents but are likely to display the greatest efficacy in treating cancers when used in conjunction with them.

Antagomirs and microRNA mimics have gained interest as a potential source of therapeutics to target EMT induced metastasis in cancer as well as treating many other diseases. Antagomirs were first developed to target miR-122, a microRNA that was abundant and specific to the liver, and this discovery has led to the development of other antagomirs that can pair with specific microRNAs present in the tumor microenvironment or in the cancer cells. A microRNA mimic to miR-655 was found to suppress EMT through the targeting of EMT inducing transcription factor ZEB1 and TGF-β receptor 2 in a pancreatic cancer cell line. Overexpression of the miR-655 mimic in the Panc1 cancer cell line upregulated the expression of E-cadherin and suppressed the migration and invasion of mesenchymal-like cancer cells. The use of microRNA mimics to suppress EMT has expanded to other cancer cell lines and holds potential for clinical drug development. However, microRNA mimics and antagomirs suffer from a lack of stability in vivo and lack an accurate delivery system to target these molecules to the tumor cells or tissue for treatment. Improvements to antagomir and microRNA mimic stability through chemical modifications such as locked nucleic acid (LNA) oligonucleotides or peptide nucleic acids (PNA) can prevent the fast clearing of these small molecules by RNases. Delivery of antagomirs and microRNA mimics into cells by enclosing these molecules in liposome-nanoparticles has generated interest however

liposome structures suffer from their own drawbacks that will need to be overcome for their effective use as a drug delivery mechanism. These drawbacks of liposomenanoparticles include nonspecific uptake by cells and induction of immune responses. The role that microRNAs play in cancer development and metastasis is under much scientific investigation and it is yet to be demonstrated whether microRNA mimics or antagomirs may serve as standard clinical treatments to suppress EMT or oncogenic microRNAs in cancers.

# Generation of endocrine progenitor cells from pancreatic islets

#### [edit]

Similar to generation of Cancer Stem Cells, EMT was demonstrated to generate endocrine progenitor cells from human pancreatic islets. Initially, the <u>human islet-derived progenitor cells</u> (hIPCs) were proposed to be better precursors since  $\beta$ -cell progeny in these hIPCs inherit <u>epigenetic</u> marks that define an active insulin promoter region. However, later, another set of experiments suggested that labelled  $\beta$ -cells dedifferentiate to a mesenchymal-like phenotype *in vitro*, but fail to proliferate; thus initiating a debate in 2007.

Since these studies in human islets lacked lineage-tracing analysis, these findings from irreversibly tagged beta cells in mice were extrapolated to human islets. Thus, using a dual lentiviral and genetic lineage tracing system to label  $\beta$ -cells, it was convincingly demonstrated that adult human islet  $\beta$ -cells undergo EMT and proliferate *in vitro*. Also, these findings were confirmed in human fetal pancreatic insulin-producing cells, and the mesenchymal cells derived from pancreatic islets can undergo the reverse of EMT – MET – to generate islet-like cell aggregates. Thus, the concept of generating progenitors from insulin-producing cells by EMT or generation of Cancer Stem Cells during EMT in cancer may have potential for replacement therapy in diabetes, and call for drugs targeting inhibition of EMT in cancer.

### Partial EMT or a hybrid E/M phenotype

#### [edit]

Not all cells undergo a complete EMT, i.e. losing their cell-cell adhesion and gaining solitary migration characteristics. Instead, most cells undergo partial EMT, a state in which they retain some epithelial traits such as cell-cell adhesion or apico-basal polarity, and gain migratory traits, thus cells in this hybrid epithelial/mesenchymal (E/M)

phenotype are endowed with special properties such as collective cell migration. Single-cell tracking contributes to enabling the visualization of morphological transitions during EMT, the discernment of cell migration phenotypes, and the correlation of the heritability of these traits among sister cells. Two mathematical models have been proposed, attempting to explain the emergence of this hybrid E/M phenotype, and its highly likely that different cell lines adopt different hybrid state(s), as shown by experiments in MCF10A, HMLE and H1975 cell lines. Although a hybrid E/M state has been referred to as 'metastable' or transient, recent experiments in H1975 cells suggest that this state can be stably maintained by cells.

- Collective cell migration
- \* Collective-amoeboid transition
- Mesenchymal-epithelial transition
- c-Met inhibitors
- Vasculogenic Mimicry
- <sup>1.</sup> Kong D, Li Y, Wang Z, Sarkar FH (February 2011). <u>"Cancer Stem Cells and Epithelial-to-Mesenchymal Transition (EMT)-Phenotypic Cells: Are They Cousins or Twins?"</u>. Cancers. **3** (1): 716–29. <u>doi:10.3390/cancers30100716</u>. <u>PMC 3106306</u>. PMID 21643534.
- Lamouille S, Xu J, Derynck R (March 2014). "Molecular mechanisms of epithelial-mesenchymal transition". Nature Reviews. Molecular Cell Biology. 15
   (3): 178–96. doi:10.1038/nrm3758. PMC 4240281. PMID 24556840.
- <sup>3.</sup> Thiery JP, Acloque H, Huang RY, Nieto MA (November 2009). <u>"Epithelial-mesenchymal transitions in development and disease"</u>. Cell. **139** (5): 871–90. doi:10.1016/j.cell.2009.11.007. <u>PMID</u> 19945376. <u>S2CID</u> 10874320.
- 4. Thiery JP, Sleeman JP (February 2006). "Complex networks orchestrate epithelial-mesenchymal transitions". Nature Reviews. Molecular Cell Biology. 7 (2): 131–42. doi:10.1038/nrm1835. PMID 16493418. S2CID 8435009.
- 5. Francou A, Anderson KV (2020). <u>"The Epithelial-to-Mesenchymal Transition in Development and Cancer"</u>. Annual Review of Cancer Biology. **4**: 197–220. doi:10.1146/annurev-cancerbio-030518-055425. PMC 8189433. PMID 34113749.
- 6. Phua YL, Martel N, Pennisi DJ, Little MH, Wilkinson L (April 2013). "Distinct sites of renal fibrosis in Crim1 mutant mice arise from multiple cellular origins". The Journal of Pathology. 229 (5): 685–96. doi:10.1002/path.4155. PMID 23224993. S2CID 22837861.
- 7. ^ Kalluri R, Weinberg RA (June 2009). <u>"The basics of epithelial-mesenchymal transition"</u>. The Journal of Clinical Investigation. 119 (6): 1420–8.
  <u>doi:10.1172/JCI39104</u>. <u>PMC 2689101</u>. <u>PMID 19487818</u>.
- 8. Sciacovelli M, Frezza C (October 2017). "Metabolic reprogramming and

- <u>epithelial-to-mesenchymal transition in cancer</u>". The FEBS Journal. **284** (19): 3132–3144. doi:10.1111/febs.14090. PMC 6049610. PMID 28444969.
- 9. Li L, Li W (June 2015). "Epithelial-mesenchymal transition in human cancer: comprehensive reprogramming of metabolism, epigenetics, and differentiation". Pharmacology & Therapeutics. 150: 33–46. doi:10.1016/j.pharmthera.2015.01.004. PMID 25595324.
- <sup>10.</sup> Peinado H, Olmeda D, Cano A (2007). "Snail, Zeb and bHLH factors in tumour progression: an alliance against the epithelial phenotype?". Nature Reviews Cancer. 7 (6): 415–428. doi:10.1038/nrc2131. hdl:10261/81769. PMID 17508028. S2CID 25162191.
- <sup>11.</sup> Yang J, Weinberg RA (2008). <u>"Epithelial-mesenchymal transition: at the crossroads of development and tumor metastasis"</u>. Dev Cell. **14** (6): 818–829. doi:10.1016/j.devcel.2008.05.009. PMID 18539112.
- <sup>12.</sup> De Craene B, Berx G (2013). "Regulatory networks defining EMT during cancer initiation and progression". Nature Reviews Cancer. **13** (2): 97–110. doi:10.1038/nrc3447. PMID 23344542. S2CID 13619676.
- 13. Chakrabarti R, Hwang J, Andres Blanco M, Wei Y, Lukačišin M, Romano RA, Smalley K, Liu S, Yang Q, Ibrahim T, Mercatali L, Amadori D, Haffty BG, Sinha S, Kang Y (2012). "Elf5 inhibits the epithelial-mesenchymal transition in mammary gland development and breast cancer metastasis by transcriptionally repressing Snail2". Nat Cell Biol. 14 (11): 1212–1222. doi:10.1038/ncb2607. PMC 3500637. PMID 23086238.
- 14. ^ Nouri M, Ratther E, Stylianou N, Nelson CC, Hollier BG, Williams ED (2014).
  "Androgen-targeted therapy-induced epithelial mesenchymal plasticity and neuroendocrine transdifferentiation in prostate cancer: an opportunity for intervention". Front Oncol. 4: 370. doi:10.3389/fonc.2014.00370. PMC 4274903.
  PMID 25566507.
- <sup>15.</sup> Puisieux A, Brabletz T, Caramel J (June 2014). "Oncogenic roles of EMT-inducing transcription factors". Nature Cell Biology. **16** (6): 488–94. doi:10.1038/ncb2976. PMID 24875735. S2CID 5226347.
- 16. Zhang L, Huang G, Li X, Zhang Y, Jiang Y, Shen J, et al. (March 2013). "Hypoxia induces epithelial-mesenchymal transition via activation of SNAI1 by hypoxia-inducible factor -1α in hepatocellular carcinoma". BMC Cancer. 13 108. doi:10.1186/1471-2407-13-108. PMC 3614870. PMID 23496980.
- <sup>17.</sup> <u>"Epithelial-Mesenchymal Transition | GeneTex"</u>. www.genetex.com. Retrieved 28 October 2019.
- 18. Horiguchi K, Shirakihara T, Nakano A, Imamura T, Miyazono K, Saitoh M (January 2009). "Role of Ras signaling in the induction of snail by transforming growth factor-beta". The Journal of Biological Chemistry. **284** (1): 245–53. doi:10.1074/jbc.m804777200. PMID 19010789.

10 01 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0

- Specification and morphogenetic movement at the primitive streak".

  Developmental Cell. 1 (1): 37–49. doi:10.1016/s1534-5807(01)00017-x.

  PMID 11703922.
- 20. Lu Z, Ghosh S, Wang Z, Hunter T (December 2003). "Downregulation of caveolin-1 function by EGF leads to the loss of E-cadherin, increased transcriptional activity of beta-catenin, and enhanced tumor cell invasion". Cancer Cell. 4 (6): 499–515. doi:10.1016/s1535-6108(03)00304-0. PMID 14706341.
- <sup>21.</sup> Savagner P, Yamada KM, Thiery JP (June 1997). <u>"The zinc-finger protein slug causes desmosome dissociation, an initial and necessary step for growth factor-induced epithelial-mesenchymal transition"</u>. The Journal of Cell Biology. **137** (6): 1403–19. <u>doi:10.1083/jcb.137.6.1403</u>. <u>PMC 2132541</u>. <u>PMID 9182671</u>.
- <sup>22.</sup> Boyer B, Tucker GC, Vallés AM, Franke WW, Thiery JP (October 1989).

  "Rearrangements of desmosomal and cytoskeletal proteins during the transition from epithelial to fibroblastoid organization in cultured rat bladder carcinoma cells". The Journal of Cell Biology. 109 (4 Pt 1): 1495–509.

  doi:10.1083/jcb.109.4.1495. PMC 2115780. PMID 2677020.
- 23. Herfs M, Hubert P, Suarez-Carmona M, Reschner A, Saussez S, Berx G, et al. (April 2010). "Regulation of p63 isoforms by snail and slug transcription factors in human squamous cell carcinoma". The American Journal of Pathology. 176 (4): 1941–9. doi:10.2353/ajpath.2010.090804. PMC 2843482. PMID 20150431.
- <sup>24.</sup> Lindsay J, McDade SS, Pickard A, McCloskey KD, McCance DJ (February 2011).

  "Role of DeltaNp63gamma in epithelial to mesenchymal transition". The Journal of Biological Chemistry. **286** (5): 3915–24. doi:10.1074/jbc.M110.162511.

  PMC 3030392. PMID 21127042.
- <sup>25.</sup> Boldrup L, Coates PJ, Gu X, Nylander K (December 2007). "DeltaNp63 isoforms regulate CD44 and keratins 4, 6, 14 and 19 in squamous cell carcinoma of head and neck". The Journal of Pathology. **213** (4): 384–91. doi:10.1002/path.2237. PMID 17935121. S2CID 21891189.
- <sup>26.</sup> Larue L, Bellacosa A (November 2005). "Epithelial-mesenchymal transition in development and cancer: role of phosphatidylinositol 3' kinase/AKT pathways". Oncogene. **24** (50): 7443–54. doi:10.1038/sj.onc.1209091. PMID 16288291. S2CID 22198937.
- <sup>27.</sup> Vlahopoulos SA, Logotheti S, Mikas D, Giarika A, Gorgoulis V, Zoumpourlis V (April 2008). "The role of ATF-2 in oncogenesis". BioEssays. **30** (4): 314–27. doi:10.1002/bies.20734. PMID 18348191. S2CID 678541.
- <sup>28.</sup> Huber MA, Beug H, Wirth T (December 2004). "Epithelial-mesenchymal transition: NF-kappaB takes center stage". Cell Cycle. **3** (12): 1477–80. doi:10.4161/cc.3.12.1280. PMID 15539952.
- 29: Vatab V Vatab M (Contember 2009) "Hadaabaa signaling spithalial to

- mesenchymal transition and miRNA (review)". International Journal of Molecular Medicine. **22** (3): 271–5. PMID 18698484.
- 30. ^ Micalizzi DS; Farabaugh SM; Ford HL (2010). <u>"Epithelial-Mesenchymal Transition in Cancer: Parallels between Normal Development and Tumor Progression"</u>. J Mammary Gland Biol Neoplasia. **15** (2): 117–134. doi:10.1007/s10911-010-9178-9. PMC 2886089. PMID 20490631.
- 31. Kang Y, He W, Tulley S, Gupta GP, Serganova I, Chen CR, Manova-Todorova K, Blasberg R, Gerald WL, Massagué J (2005). "Breast cancer bone metastasis mediated by the Smad tumor suppressor pathway". PNAS. 102 (39): 13909–14. Bibcode: 2005PNAS..10213909K. doi:10.1073/pnas.0506517102. PMC 1236573. PMID 16172383.
- 32. Chang C, Chao C, Xia W, Yang J, Xiong Y, Li C, Yu W, Rehman SK, Hsu JL, Lee H, Liu M, Chen C, Yu D, Hung M (2011). "p53 regulates epithelial-mesenchymal transition (EMT) and stem cell properties through modulating miRNAs". Nat Cell Biol. 13 (3): 317–323. doi:10.1038/ncb2173. PMC 3075845. PMID 21336307.
- 33. Lim R, Thiery JP (2012). "Epithelial-mesenchymal transitions: insights from development". Development. 139 (19): 3471–3486. doi:10.1242/dev.071209. PMID 22949611.
- 34. ^ Hay ED (2005). <u>"The mesenchymal cell, its role in the embryo, and the remarkable signaling mechanisms that create it"</u>. Dev. Dyn. **233** (3): 706–20. doi:10.1002/dvdy.20345. <u>PMID 15937929</u>. <u>S2CID 22368548</u>.
- 35. Kerosuo L, Bronner-Fraser M (2012). "What is bad in cancer is good in the embryo: Importance of EMT in neural crest development". Seminars in Cell and Developmental Biology. 23 (3): 320–332. doi:10.1016/j.semcdb.2012.03.010. PMC 3345076. PMID 22430756.
- 36. Ahmed N, Maines-Bandiera S, Quinn MA, Unger WG, Dedhar S, Auersperg N (2006). "Molecular pathways regulating EGF-induced epithelio- mesenchymal transition in human ovarian surface epithelium". Am J Physiol Cell Physiol. 290 (6): C1532 C1542. doi:10.1152/ajpcell.00478.2005. PMID 16394028. S2CID 35196500.
- <sup>37.</sup> Hanahan D, Weinberg RA (January 2000). <u>"The hallmarks of cancer"</u>. Cell. **100** (1): 57–70. <u>doi:10.1016/s0092-8674(00)81683-9</u>. <u>PMID</u> <u>10647931</u>. <u>S2CID</u> <u>1478778</u>.
- 38. Hanahan D, Weinberg RA (March 2011). <u>"Hallmarks of cancer: the next generation"</u>. Cell. **144** (5): 646–74. <u>doi:10.1016/j.cell.2011.02.013</u>. <u>PMID 21376230</u>.
- <sup>39.</sup> Chaffer CL, Weinberg RA (March 2011). "A perspective on cancer cell metastasis". Science. **331** (6024): 1559–64. <u>Bibcode</u>: <u>2011Sci...331.1559C</u>. doi:10.1126/science.1203543. PMID 21436443. S2CID 10550070.
- 40. Ve X Weinhera RA (November 2015) "Enithelial-Mesenchumal Plasticitu: A

2012, 110111001 y 222 (21000111001 2020). <u>2ptitotiat 212001101ty</u>liat 2 taottotiy. 22

- <u>Central Regulator of Cancer Progression"</u>. Trends in Cell Biology. **25** (11): 675–686. doi:10.1016/j.tcb.2015.07.012. PMC 4628843. PMID 26437589.
- <sup>41.</sup> Massague J (2008). <u>"TGFβ in cancer"</u>. Cell. **134** (2): 215–229. doi:10.1016/j.cell.2008.07.001. PMC 3512574. PMID 18662538.
- 42. Chu IM, Lai WC, Aprelikova O, El Touny LH, Kouros-Mehr H, Green JE (2013).
   "Expression of GATA3 in MDA-MB-231 triple-negative breast cancer cells induces a growth inhibitory response to TGFβ". PLOS ONE. 8 (4) e61125.
   Bibcode: 2013PLoSO...861125C. doi:10.1371/journal.pone.0061125. PMC 3620110.
   PMID 23577196.
- 43. Ratnayake WS, Apostolatos AH, Ostrov DA, Acevedo-Duncan M (2017). "Two novel atypical PKC inhibitors; ACPD and DNDA effectively mitigate cell proliferation and epithelial to mesenchymal transition of metastatic melanoma while inducing apoptosis". Int. J. Oncol. 51 (5): 1370–1382. doi:10.3892/ijo.2017.4131. PMC 5642393. PMID 29048609.
- 44. Ratnayake WS, Apostolatos CA, Apostolatos AH, Schutte RJ, Huynh MA, Ostrov DA, Acevedo-Duncan M (2018). "Oncogenic PKC-ι activates Vimentin during epithelial-mesenchymal transition in melanoma; a study based on PKC-ι and PKC-ζ specific inhibitors". Cell Adhes. Migr. 12 (5): 447–463. doi:10.1080/19336918.2018.1471323. PMC 6363030. PMID 29781749.
- 45. Kajiyama H, Shibata K, Terauchi M, Yamashita M, Ino K, Nawa A, Kikkawa F (August 2007). "Chemoresistance to paclitaxel induces epithelial-mesenchymal transition and enhances metastatic potential for epithelial ovarian carcinoma cells". International Journal of Oncology. 31 (2): 277–83. doi:10.3892/ijo.31.2.277. PMID 17611683.
- 46. Ricciardi M, Zanotto M, Malpeli G, Bassi G, Perbellini O, Chilosi M, et al. (March 2015). "Epithelial-to-mesenchymal transition (EMT) induced by inflammatory priming elicits mesenchymal stromal cell-like immune-modulatory properties in cancer cells". British Journal of Cancer. 112 (6): 1067–75. doi:10.1038/bjc.2015.29. PMC 4366889. PMID 25668006.
- 47. Mani SA, Guo W, Liao MJ, Eaton EN, Ayyanan A, Zhou AY, Brooks M, Reinhard F, Zhang CC, Shipitsin M, Campbell LL, Polyak K, Brisken C, Yang J, Weinberg RA (2008). "The epithelial-mesenchymal transition generates cells with properties of stem cells". Cell. 133 (4): 704–15. doi:10.1016/j.cell.2008.03.027. PMC 2728032. PMID 18485877.
- 48. Singh A, Settleman J (2010). <u>"EMT, cancer stem cells and drug resistance: an emerging axis of evil in the war on cancer"</u>. Oncogene. **29** (34): 4741–4751. doi:10.1038/onc.2010.215. PMC 3176718. PMID 20531305.
- <sup>49.</sup> Fischer KR, Durrans A, Lee S, Sheng J, Li F, Wong ST, et al. (November 2015). "Epithelial-to-mesenchymal transition is not required for lung metastasis but contributes to chemoresistance". Nature. **527** (7579): 472–6.

Pile de constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de la constituir de l

<u>Bibcode</u>: <u>2015Natur.527..472F</u>. <u>doi:10.1038/nature15748</u>. <u>PMC 4662610</u>. <u>PMID 26560033</u>.

- 50. Zheng X, Carstens JL, Kim J, Scheible M, Kaye J, Sugimoto H, et al. (November 2015). "Epithelial-to-mesenchymal transition is dispensable for metastasis but induces chemoresistance in pancreatic cancer". Nature. 527 (7579): 525–530. Bibcode:2015Natur.527..525Z. doi:10.1038/nature16064. PMC 4849281. PMID 26560028.
- 51. ^ Shamir ER, Pappalardo E, Jorgens DM, Coutinho K, Tsai WT, Aziz K, et al. (March 2014). "Twist1-induced dissemination preserves epithelial identity and requires E-cadherin". The Journal of Cell Biology. 204 (5): 839–56. doi:10.1083/jcb.201306088. PMC 3941052. PMID 24590176.
- <sup>52.</sup> Jaguva Vasudevan AA, Hoffmann MJ, Beck ML, Poschmann G, Petzsch P, Wiek C, et al. (April 2019). "HDAC5 Expression in Urothelial Carcinoma Cell Lines Inhibits Long-Term Proliferation but Can Promote Epithelial-to-Mesenchymal Transition". International Journal of Molecular Sciences. 20 (9): 2135. doi:10.3390/ijms20092135. PMC 6539474. PMID 31052182.
- 53. Kepner N, Lipton A (February 1981). "A mitogenic factor for transformed fibroblasts from human platelets". Cancer Research. 41 (2): 430–2.

  PMID 6256066.
- 54. Möhle R, Green D, Moore MA, Nachman RL, Rafii S (January 1997). "Constitutive production and thrombin-induced release of vascular endothelial growth factor by human megakaryocytes and platelets". Proceedings of the National Academy of Sciences of the United States of America. 94 (2): 663–8.

  Bibcode:1997PNAS...94..663M. doi:10.1073/pnas.94.2.663. PMC 19570.

  PMID 9012841.
- <sup>55.</sup> Li JJ, Huang YQ, Basch R, Karpatkin S (February 2001). "Thrombin induces the release of angiopoietin-1 from platelets". Thrombosis and Haemostasis. **85** (2): 204–6. doi:10.1055/s-0037-1615677. PMID 11246533. S2CID 33522255.
- <sup>56.</sup> Assoian RK, Komoriya A, Meyers CA, Miller DM, Sporn MB (June 1983).

  "Transforming growth factor-beta in human platelets. Identification of a major storage site, purification, and characterization". The Journal of Biological Chemistry. 258 (11): 7155–60. doi:10.1016/S0021-9258(18)32345-7.

  PMID 6602130.
- 57. Oft M, Heider KH, Beug H (November 1998). "TGFbeta signaling is necessary for carcinoma cell invasiveness and metastasis". Current Biology. 8 (23): 1243–52. Bibcode:1998CBio....8.1243O. doi:10.1016/s0960-9822(07)00533-7. PMID 9822576. S2CID 18536979.
- 58. Bakewell SJ, Nestor P, Prasad S, Tomasson MH, Dowland N, Mehrotra M, et al. (November 2003). "Platelet and osteoclast beta3 integrins are critical for bone metastasis". Proceedings of the National Academy of Sciences of the United States

- of America. **100** (24): 14205–10. <u>Bibcode</u>: <u>2003PNAS..10014205B</u>. doi:10.1073/pnas.2234372100. PMC 283570. PMID 14612570.
- <sup>59.</sup> Camerer E, Qazi AA, Duong DN, Cornelissen I, Advincula R, Coughlin SR (July 2004). "Platelets, protease-activated receptors, and fibrinogen in hematogenous metastasis". Blood. **104** (2): 397–401. doi:10.1182/blood-2004-02-0434. PMID 15031212.
- 60. Hernandez E, Lavine M, Dunton CJ, Gracely E, Parker J (June 1992). "Poor prognosis associated with thrombocytosis in patients with cervical cancer". Cancer. 69 (12): 2975–7. doi:10.1002/1097-0142(19920615)69:12<2975::aid-cncr2820691218>3.0.co;2-a. PMID 1591690.
- 61. Zeimet AG, Marth C, Müller-Holzner E, Daxenbichler G, Dapunt O (February 1994). "Significance of thrombocytosis in patients with epithelial ovarian cancer". American Journal of Obstetrics and Gynecology. 170 (2): 549–54. doi:10.1016/s0002-9378(94)70225-x. PMID 8116711.
- 62. Ikeda M, Furukawa H, Imamura H, Shimizu J, Ishida H, Masutani S, et al. (April 2002). "Poor prognosis associated with thrombocytosis in patients with gastric cancer". Annals of Surgical Oncology. **9** (3): 287–91. doi:10.1245/aso.2002.9.3.287. PMID 11923136.
- 63. Shimada H, Oohira G, Okazumi S, Matsubara H, Nabeya Y, Hayashi H, et al. (May 2004). "Thrombocytosis associated with poor prognosis in patients with esophageal carcinoma". Journal of the American College of Surgeons. 198 (5): 737–41. doi:10.1016/j.jamcollsurg.2004.01.022. PMID 15110807.
- 64. ^ Erpenbeck L, Schön MP (April 2010). "Deadly allies: the fatal interplay between platelets and metastasizing cancer cells". Blood. 115 (17): 3427–36. doi:10.1182/blood-2009-10-247296. PMC 2867258. PMID 20194899.
- 65. Palumbo JS, Talmage KE, Massari JV, La Jeunesse CM, Flick MJ, Kombrinck KW, et al. (January 2005). "Platelets and fibrin(ogen) increase metastatic potential by impeding natural killer cell-mediated elimination of tumor cells". Blood. 105 (1): 178–85. doi:10.1182/blood-2004-06-2272. PMID 15367435. S2CID 279285.
- 66. Gay LJ, Felding-Habermann B (February 2011). "Contribution of platelets to tumour metastasis". Nature Reviews. Cancer. 11 (2): 123–34. doi:10.1038/nrc3004. PMC 6894505. PMID 21258396.
- 67. Thiery JP (June 2002). "Epithelial-mesenchymal transitions in tumour progression". Nature Reviews. Cancer. **2** (6): 442–54. doi:10.1038/nrc822. PMID 12189386. S2CID 5236443.
- 68. ^ Yingling JM, Blanchard KL, Sawyer JS (December 2004). "Development of TGF-beta signalling inhibitors for cancer therapy". Nature Reviews. Drug Discovery. 3 (12): 1011–22. doi:10.1038/nrd1580. PMID 15573100. S2CID 42237691.

- <sup>69.</sup> Zou J, Luo H, Zeng Q, Dong Z, Wu D, Liu L (June 2011). "Protein kinase CK2a is overexpressed in colorectal cancer and modulates cell proliferation and invasion via regulating EMT-related genes". Journal of Translational Medicine. **9** 97. doi:10.1186/1479-5876-9-97. PMC 3132712. PMID 21702981.
- 70. Gowda C, Sachdev M, Muthusami S, Kapadia M, Petrovic-Dovat L, Hartman M, et al. (2017). "Casein Kinase II (CK2) as a Therapeutic Target for Hematological Malignancies". Current Pharmaceutical Design. 23 (1): 95–107. doi:10.2174/1381612822666161006154311. PMID 27719640.
- <sup>71.</sup> "CX-4945 Granted Orphan Drug Designation". Oncology Times. **39** (5): 23. 10 March 2017. doi:10.1097/01.cot.0000514203.35081.69. ISSN 0276-2234.
- 72. Bhola NE, Balko JM, Dugger TC, Kuba MG, Sánchez V, Sanders M, et al. (March 2013). "TGF-β inhibition enhances chemotherapy action against triple-negative breast cancer". The Journal of Clinical Investigation. 123 (3): 1348–58. doi:10.1172/JCI65416. PMC 3582135. PMID 23391723.
- 73. ^ Kothari AN, Mi Z, Zapf M, Kuo PC (15 October 2014). "Novel clinical therapeutics targeting the epithelial to mesenchymal transition". Clinical and Translational Medicine. 3 e35: 35. doi:10.1186/s40169-014-0035-0.
  PMC 4198571. PMID 25343018.
- <sup>74.</sup> ^ Rupaimoole R, Slack FJ (March 2017). "MicroRNA therapeutics: towards a new era for the management of cancer and other diseases". Nature Reviews. Drug Discovery. 16 (3): 203–222. <a href="doi:10.1038/nrd.2016.246">doi:10.1038/nrd.2016.246</a>. <a href="PMID">PMID 28209991</a>. <a href="S2CID 22956490">S2CID 22956490</a>.
- 75. Krützfeldt J, Rajewsky N, Braich R, Rajeev KG, Tuschl T, Manoharan M, Stoffel M (December 2005). "Silencing of microRNAs in vivo with 'antagomirs'". Nature. 438 (7068): 685–9. <u>Bibcode</u>:2005Natur.438..685K. <u>doi:10.1038/nature04303</u>. <u>PMID 16258535</u>. <u>S2CID 4414240</u>.
- 76. Harazono Y, Muramatsu T, Endo H, Uzawa N, Kawano T, Harada K, et al. (14 May 2013). "miR-655 Is an EMT-suppressive microRNA targeting ZEB1 and TGFBR2". PLOS ONE. 8 (5) e62757. Bibcode: 2013PLoSO...862757H. doi:10.1371/journal.pone.0062757. PMC 3653886. PMID 23690952.
- 77. ^ Rothschild SI (4 March 2014). "microRNA therapies in cancer". Molecular and Cellular Therapies. 2: 7. doi:10.1186/2052-8426-2-7. PMC 4452061.
  PMID 26056576.
- <sup>78.</sup> Lv H, Zhang S, Wang B, Cui S, Yan J (August 2006). "Toxicity of cationic lipids and cationic polymers in gene delivery". Journal of Controlled Release. **114** (1): 100–9. doi:10.1016/j.jconrel.2006.04.014. PMID 16831482.
- <sup>79.</sup> Gershengorn MC, Hardikar AA, Wei C, et al. (2004). <u>"Epithelial-to-mesenchymal transition generates proliferative human islet precursor cells"</u>. Science. **306** (5705): 2261–2264. <u>Bibcode</u>: 2004Sci...306.2261G. <u>doi:10.1126/science.1101968</u>. PMID 15564314. S2CID 22304970.

- O. Gershengorn MC, Geras-Raaka E, Hardikar AA, et al. (2005). "Are better islet cell precursors generated by epithelial-to-mesenchymal transition?". Cell Cycle. 4

  (3): 380–382. doi:10.4161/cc.4.3.1538. PMID 15711124.
- 81. Atouf F, Park CH, Pechhold K, et al. (2007). "No evidence for mouse pancreatic beta-cell epithelial-mesenchymal transition in vitro". Diabetes. **56** (3): 699–702. doi:10.2337/db06-1446. PMID 17327438.
- 82. Chase LG, Ulloa-Montoya F, Kidder BL, et al. (2007). "Islet-derived fibroblast-like cells are not derived via epithelial-mesenchymal transition from Pdx-1 or insulin-positive cells". Diabetes. **56** (1): 3–7. doi:10.2337/db06-1165.

  PMID 17110468.
- 83. Morton RA, Geras-Raaka E, Wilson LM, et al. (2007). "Endocrine precursor cells from mouse islets are not generated by epithelial-to-mesenchymal transition of mature beta cells". Mol Cell Endocrinol. 270 (1–2): 87–93. doi:10.1016/j.mce.2007.02.005. PMC 1987709. PMID 17363142.
- 84. Russ HA, Bar Y, Ravassard P, et al. (2008). <u>"In vitro proliferation of cells derived from adult human beta-cells revealed by cell-lineage tracing"</u>. Diabetes. **57** (6): 1575–1583. <u>doi:10.2337/db07-1283</u>. <u>PMID 18316362</u>.
- 85. Russ HA, Ravassard P, Kerr-Conte J, et al. (2009). "Epithelial-mesenchymal transition in cells expanded in vitro from lineage-traced adult human pancreatic beta cells". PLOS ONE. 4 (7) e6417. Bibcode:2009PLoSO...4.6417R. doi:10.1371/journal.pone.0006417. PMC 2712769. PMID 19641613.
- 86. ^ Joglekar MV, Joglekar VM, Joglekar SV, et al. (2009). <u>"Human fetal pancreatic insulin-producing cells proliferate in vitro"</u>. J Endocrinol. **201** (1): 27–36. <u>doi:10.1677/joe-08-0497</u>. <u>PMID 19171567</u>.
- 87. Jolly MK, Boareto M, Huang B, Jia D, Lu M, Ben-Jacob E, et al. (1 January 2015).

  "Implications of the Hybrid Epithelial/Mesenchymal Phenotype in Metastasis".

  Frontiers in Oncology. 5: 155. arXiv:1505.07494. Bibcode:2015arXiv150507494J.