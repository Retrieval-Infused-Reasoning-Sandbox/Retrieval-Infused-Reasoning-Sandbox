International Journal of Modern Physics A Vol. 28, Nos. 22 & 23 (2013) 1340015 [\(29](#page-26-0) pages) c World Scientific Publishing Company DOI: [10.1142/S0217751X13400150](http://dx.doi.org/10.1142/S0217751X13400150)

![](_page_0_Picture_2.jpeg)

# AN INTRODUCTION TO WELL-POSEDNESS AND FREE-EVOLUTION<sup>∗</sup>

## DAVID HILDITCH

Theoretical Physics Institute, University of Jena, 07743 Jena, Germany [david.hilditch@uni-jena.de](mailto:david.hilditch@uni-jena.de)

> Received 14 May 2013 Revised 15 August 2013 Accepted 16 August 2013 Published 12 September 2013

These lecture notes accompany two classes given at the NRHEP2 school. In the first lecture I introduce the basic concepts used for analyzing well-posedness, that is the existence of a unique solution depending continuously on given data, of evolution partial differential equations. I show how strong hyperbolicity guarantees well-posedness of the initial value problem. Symmetric hyperbolic systems are shown to render the initial boundary value problem well-posed with maximally dissipative boundary conditions. I discuss the Laplace–Fourier method for analyzing the initial boundary value problem. Finally, I state how these notions extend to systems that are first-order in time and second-order in space. In the second lecture I discuss the effect that the gauge freedom of electromagnetism has on the PDE status of the initial value problem. I focus on gauge choices, strong-hyperbolicity and the construction of constraint preserving boundary conditions. I show that strongly hyperbolic pure gauges can be used to build strongly hyperbolic formulations. I examine which of these formulations is additionally symmetric hyperbolic and finally demonstrate that the system can be made boundary stable.

Keywords: Initial value problem; initial boundary value problem; strong hyperbolicity; symmetric hyperbolicity; Laplace–Fourier method; Maxwell equations; gauge freedom.

PACS numbers: 04.20.Ex, 04.25.D−, 04.40.Nr, 41.20.−q

## 1. Well-Posedness of Evolution Partial Differential Equations

## 1.1. Introduction

In recent years there have been a slew of textbooks,[1,](#page-26-1)[2](#page-26-2) review articles,[3–](#page-26-3)[8](#page-26-4) and lecture notes[9–](#page-26-5)[11](#page-27-0) designed either as an introduction to numerical relativity, or as a convenient place to understand the state-of-the-art of the field, not to mention classic

<sup>∗</sup>This article contains supplementary data available on the journal website, namely mathematica notebooks Maxwell Strong.nb, Maxwell Symmetric.nb and Maxwell LF.nb in which the calculations presented in the second lecture are performed.

texts on time evolution problems.[12](#page-27-1)[,13](#page-27-2) These resources already serve their purpose beautifully. So, happy as I was to be asked to teach introductory material and provide written lecture notes, the obvious question is; does the world need another set of introductory notes to hyperbolic systems? I have tried to come to a solution that presents the heart-and-soul of the topic as concisely as possible. In this class I will review concepts in the analysis of time-evolution partial differential equations, PDEs, proving results only sparsely. The main aim is to collect together, in the form of a tool-box, the necessary weapons for treating a given system of PDEs. I hope that where I have shamelessly copied, the authors of existing texts will accept my imitation as flattery. In the second lecture I treat electromagnetism as a model for general relativity, and apply each of the tools to demonstrate how they are used in practice. I expect that this application will be enlightening. I highlight the effect of gauge freedom on the PDEs analysis, for a large family of gauges. To my knowledge such a treatment has not appeared elsewhere, although free-evolution formulations of electromagnetism have of course been studied in the literature.[14](#page-27-3)[–21](#page-27-4)

In physics and applied mathematics we are frequently presented with systems of PDEs. Well-posedness is a fundamental property of a PDE problem. It is the requirement that there be a unique solution that depends continuously, in some norm, on given data for the problem. Without it, one has simply not built a reasonable mathematical abstraction of the physical problem at hand. The model is without predictive power, because small changes in the given data might result in either arbitrarily large changes in the outcome or that there is no solution at all. If we are given a complicated system, like the field equations of general relativity, we will probably have to find solutions numerically. But if the formulation as a PDE problem is ill-posed, no numerical approach can be successful! After all, how can one construct an approximation scheme that converges to the continuum solution if the solution does not exist? Therefore, one might find it surprising that research in numerical relativity has been performed with problems that are illposed. Spontaneously on hearing that such versions of general relativity exist, you might think that this sounds a bit like a way of saying that the theory is broken, or somehow deficient. That impression is wrong. The answer is that for theories with gauge freedom, the precise formulation of the field equations as a system of PDEs affects well-posedness. And it took time for this fact to be recognized in the context of numerical relativity. In the second lecture we will carefully investigate this for electromagnetism.

The most crude way of classifying a PDE is into one of the three classes, Elliptic, Parabolic or Hyperbolic, names originally inspired by the conic-sections. The class of a PDE determines what type of data has any chance of producing a well-posed problem. From the intuitive point of view of the physicist, one might summarize their character as follows:

• Elliptic PDEs have no intrinsic notion of time, and often arise as the steadystate, or end-state solutions of dynamical evolution, for example in electrostatics. The solutions to well-posed Elliptic problems are typically "as smooth as the coefficients allow." The prototype of a well-posed elliptic problem is the boundary value problem for the Laplace equation.

- Parabolic PDEs describe diffusive processes. They have an intrinsic notion of time, but signals travel at infinite speed. Even nonsmooth initial data immediately become smooth as they evolve. The prototype of a well-posed parabolic problem is the initial value problem for the heat equation.
- Hyperbolic PDEs are the best. They describe processes which are in some sense causal; there is an intrinsic notion of time, and crucially signals travel with finite speed. Discontinuities in initial data for a hyperbolic PDE will often be propagated, or may even form from smooth initial data. The prototype of a well-posed hyperbolic problem is the initial value problem for the wave equation.

Notice that all of the prototype well-posed problems specify both a simple PDE, the type of data, and the domain that is appropriate. One can also concoct PDEs of mixed character, so this classification is certainly not complete. Numerical relativists have to face all three, and occasionally mixed classes. But in this lecture we will focus exclusively on hyperbolic problems and well-posedness of the initial, and initial boundary value problems.

## <span id="page-2-2"></span>1.2. Strong hyperbolicity

The initial value problem. Consider a system of PDEs, which can be written,

<span id="page-2-0"></span>
$$\partial_t u = A^p \partial_p u + Bu \,, \tag{1}$$

with state vector u. Here I employ the summation convention, denote ∂<sup>i</sup> ≡ ∂x<sup>i</sup> and assume that i = 1, 2, 3. The highest derivative terms are called the principal part. I will sometimes refer to A<sup>p</sup> as the principal matrix, although it is really a shorthand for three matrices, since I am assuming that we have three spatial dimensions. The remaining terms on the right-hand side of [\(1\)](#page-2-0) are called nonprincipal. In this lecture, we will assume that the matrices A<sup>p</sup> and B are constant in both time and space. We therefore call it a linear , constant coefficient system. The initial value, or Cauchy problem, is the following: specify data u(0, x<sup>i</sup> ) = f(x i ) at time t = 0, with spatial coordinates x i . What is the solution u(t, x<sup>i</sup> ) at later times? In other words data is specified everywhere in space; the domain of the solution is in this sense unbounded. Naturally many PDEs of interest are not linear or do not have constant coefficients. That said, local properties of more complicated systems are determined by the behavior of the system in linear approximation, which justifies the restriction.

Well-posedness. If there exist constants K and α, such that for all initial data we have the estimate

<span id="page-2-1"></span>
$$||u(t,\cdot)|| \le Ke^{\alpha t}||f||, \qquad (2)$$

with the  $L_2$  norm,

$$||g||^2 = \int_{\mathbb{R}^3} g^{\dagger} g \, dx \, dy \, dz,$$
 (3)

then the initial value problem for (1) is called well-posed. Notice that we restrict to initial data that are bounded in  $L_2$ .

**Strong hyperbolicity.** Given an arbitrary unit spatial vector  $s^i$ , we say that the matrix

$$P^s \equiv A^s = A^p s_p \,, \tag{4}$$

is the principal symbol of the system. The system (1) is called weakly hyperbolic if for every unit spatial vector  $s^i$ , the principal symbol has real eigenvalues. If furthermore for every unit spatial vector  $s^i$ , the principal symbol has a complete set of eigenvectors and there exists a constant K, independent of  $s^i$ , such that

<span id="page-3-0"></span>
$$|T_s| + |T_s^{-1}| \le K$$
, (5)

where  $T_s$  is formed with the eigenvectors of  $P^s$  as columns, and we have the usual definition of the matrix norm  $|\cdot|$ , the system is called strongly hyperbolic. If a system is strongly hyperbolic and the multiplicity of the eigenvalues does not depend on  $s^i$  we say that it is strongly hyperbolic of constant multiplicity. Notice that if the eigenvectors of the principal symbol depend continuously on  $s^i$  then the second condition (5) is automatically satisfied, because  $s^i$  varies over a compact set. In most applications we will have continuous dependence, and so checking for strong hyperbolicity amounts to doing a little linear algebra.

Characteristic variables. The components of the vector  $v = T_s^{-1}u$  are called the characteristic variables in the  $s^i$  direction. Up to nonprincipal terms and derivatives transverse to the  $s^i$  direction the characteristic variables satisfy advection equations with speeds equal to the eigenvalues of the principal symbol. For this reason we will sometimes call the eigenvalues the speeds of the system. To see this consider

$$\partial_t v = \Lambda_s \partial_s v + (T_s^{-1} A^A T_s) \partial_A v + (T_s^{-1} B T_s) v.$$
 (6)

Here  $\Lambda_s$  has the eigenvalues of the principal symbol on the diagonal. We denote longitudinal derivatives  $s^i \partial_i = \partial_s$ , and transverse derivatives  $(\delta^i{}_j - s^j s_i) \partial_j$  by an upper case Latin index A.

Well-posed  $\iff$  strongly hyperbolic. The main result for the initial value problem for (1) is that it is well-posed if and only if the system is strongly hyperbolic. We will need to Fourier transform in space, and use the convention

$$\tilde{f}(\omega^i) = \frac{1}{(2\pi)^{3/2}} \int_{\mathbf{R}^3} e^{i\omega_j x^j} f(x^i) dx \, dy \, dz \,.$$
 (7)

The time derivative of the variables after Fourier transform is

$$\partial_t \tilde{u} = i\omega P^s \tilde{u} + B\tilde{u} \,, \tag{8}$$

where we write  $\omega_i = |\omega| s_i = \omega s_i$ . So in Fourier space the general solution is

$$\tilde{u}(t,\omega^i) = e^{(i\omega P^s + B)t} \tilde{f}(\omega^i). \tag{9}$$

Assume that the system is strongly hyperbolic. The key to the proof of well-posedness is the use of a symmetrizer. We define the Hermitian, positive definite symmetrizer  $H_s$  by

<span id="page-4-1"></span>
$$H_s = T_s^{-\dagger} T_s^{-1} \,,$$
 (10)

which satisfies the crucial property,

<span id="page-4-0"></span>
$$i\omega H_s P^s + (i\omega H_s P^s)^{\dagger} = 0. (11)$$

Note that our choice for the definition of  $H_s$  is not the most general that yields (11); instead we could have chosen  $H_s = T_s^{-\dagger} C_s T_s^{-1}$ , with  $C_s$  Hermitian, positive definite and commuting with  $\Lambda_s$ . We do not require the most general  $H_s$  here, and so we proceed with this restriction. Define the norm  $||\cdot||_H$  by

$$||g(\cdot)||_H^2 = \int_{\mathbf{R}^3} \tilde{g}^{\dagger} H_s \tilde{g} \, d\omega^x \, d\omega^y \, d\omega^z \,. \tag{12}$$

Computing the time derivative of the norm  $||\cdot||_H$ , a couple of lines gives the inequality,

$$\partial_t ||u(t,\cdot)||_H^2 \le 2|B|e^{2|B|t}||f(\cdot)||_H^2,$$
 (13)

and by integrating we have the well-posedness estimate, in the new norm  $||\cdot||_H$ ,

$$||u(t,\cdot)||_H \le e^{|B|t}||f(\cdot)||_H.$$
 (14)

But we want to obtain estimates in the  $L_2$ -norm. Fortunately, with Parseval's relation  $||g(\cdot)|| = ||\tilde{g}(\cdot)||$ , one can show that we have

$$K^{-2}||u(t,\cdot)||^2 \le ||u(t,\cdot)||_H^2, \quad ||f||_H^2 \le K^2||f||^2,$$
 (15)

from which well-posedness in  $L_2$  follows. Now assume that the system is well-posed, and consider once again the system in Fourier space. Suppose that at least one of the eigenvalues  $\lambda$  of the principal symbol is not real. Then the magnitude of the eigensolution associated with this eigenvalue grows like  $e^{\omega \operatorname{Im} \lambda t}$ , in contradiction with the estimate (2) in Fourier space. Suppose that the eigenvalues are real but that the principal symbol is missing one eigenvector of eigenvalue  $\lambda$ , say, and assume that B=0. The associated eigensolution is of the form

$$e^{i\omega\lambda t}[\mathbf{1} + i\omega\lambda t(P^s - \lambda\mathbf{1})]v$$
, (16)

where v here is the generalized eigenvector of  $P^s$ . Evidently this solution grows in a frequency dependent manner and, again in contradiction with our starting point, cannot be bounded with an estimate like (2). If there are more missing

eigenvectors associated with  $\lambda$ , the order of the polynomial in  $\omega$  increases for the other eigensolutions. Considering  $B \neq 0$  does not prevent the frequency dependent growth. Finally there is the possibility that the principal symbol is diagonalizable and has real eigenvalues but that the estimate (5) fails. As shown in Theorem 2.4.1 of Ref. 12, this inequality is guaranteed by application of the Kreiss matrix theorem.<sup>22</sup>

Variable coefficient and nonlinear problems. In applications, we are almost never faced with linear constant coefficient problems. Given a linear problem of the form (1) but now with smooth variable coefficients, then provided that the most general symmetrizer  $H_s$ , described after Eq. (10), can be constructed so that it is a smooth function of the direction  $s^i$  and the coordinates t,  $x^i$  then the well-posedness results carry over. So we can proceed by working in the frozen coefficient approximation, i.e. working at an arbitrary point and ignoring derivatives of, or variation in the coefficients.<sup>5</sup> For nonlinear problems the approach is to linearize at a given, possibly arbitrary, solution, and from there work in the frozen coefficient approximation. The price we pay is that well-posedness results become only local in time. To say something about long-term existence of solutions much more sophisticated methods are needed.

### 1.3. Symmetric hyperbolicity

The initial boundary value problem. Consider now the PDE system similar to what we had before (1),

<span id="page-5-1"></span>
$$\partial_t u = A^p \partial_p u + F(t, x^i) \,, \tag{17}$$

again with constant matrices  $A^p$ , but now rather than considering solutions on  $\mathbb{R}^3$ , let us consider trying to find solutions on the half-space  $x^1 = x \geq 0$  so that we have a boundary. We could have treated the nonprincipal forcing term Bu like this in the system we had before (1), but would not have found such a nice representation of the exponential growth caused by nonprincipal terms. In other words, one can think of the forcing term as being just F = Bu like in the previous section. We specify initial data  $u(0, x^i) = f(x^i)$  on the domain, and boundary conditions  $Lu(t, x^i) = g(t, x^A)$ , where the index A here denotes that the data depends only on  $x^2 = y$  and  $x^3 = z$ , with L some matrix whose form we will discuss shortly.

Strong well-posedness. Let  $||\cdot||_{\Sigma}$  denote the  $L_2$  norm on the half-space, and  $||\cdot||_{\partial\Sigma}$  denote the  $L_2$  norm in the boundary plane x=0. If there exists a constant  $K_T$  for every T, independent of the given data and forcing terms, such that for every  $0 \le t \le T$ , we have the estimate

<span id="page-5-0"></span>
$$||u(t,\cdot)||_{\Sigma}^{2} + \int_{0}^{t} ||u(t',\cdot)||_{\partial\Sigma}^{2} dt'$$

$$\leq K_{T}^{2} \left[ ||f||_{\Sigma}^{2} + \int_{0}^{t} \left( ||F(t',\cdot)||_{\Sigma}^{2} + ||g(t',\cdot)||_{\partial\Sigma}^{2} \right) dt' \right], \tag{18}$$

then we call the problem strongly well-posed. Essentially this means that we can bound the solution in the bulk, and restrict the boundary by the initial data, plus growth caused by either nonprincipal terms or boundary data. One sometimes<sup>13</sup> sees this definition given without the second term on the left-hand side. We will briefly discuss both variants below. Although these two possibilities are sometimes named the same way, they are distinct notions.

Symmetric hyperbolicity. If there exists a Hermitian positive definite symmetrizer H such that  $HA^ps_p$  is Hermitian for every unit spatial vector  $s^p$ , then we say that the system is symmetric hyperbolic. Comparing the symmetrizer H with the similar object  $H_s$  in the proof of well-posedness of the initial value problem for strongly hyperbolic systems, we see the difference is that for symmetric hyperbolic systems the symmetrizer may not depend on  $s^p$ . So every symmetric hyperbolic system is strongly hyperbolic, but not vice-versa.

Maximally dissipative boundary conditions. Since every symmetric hyperbolic system is strongly hyperbolic, there is a matrix  $T_x$  such that

<span id="page-6-1"></span>
$$T_x^{-1} P^x T_x = \Lambda_x = \begin{pmatrix} \Lambda_x^{\mathrm{I}} & 0\\ 0 & \Lambda_x^{\mathrm{II}} \end{pmatrix}, \tag{19}$$

where we assume that  $\Lambda_{\rm I} > 0$  and  $\Lambda_{\rm II} < 0$ . This last assumption is sometimes not met, in which case the boundary is called characteristic in those characteristic variables with vanishing speed at the boundary. Characteristic boundaries complicate the analysis considerably, in fact preventing one from showing strong well-posedness with the type of boundary conditions that follow. I will not discuss such boundaries further; more information can be found elsewhere.<sup>5,23–26</sup> Partitioning the characteristic variables in the x-direction v in the same way we write  $v = (v_{\rm I}, v_{\rm II})^{\dagger}$ . We therefore have the condition

$$u^{\dagger} H A^{x} u = v_{\mathrm{I}}^{\dagger} H^{\mathrm{I}} \Lambda_{x}^{\mathrm{I}} v_{\mathrm{I}} + v_{\mathrm{II}}^{\dagger} H^{\mathrm{II}} \Lambda_{x}^{\mathrm{II}} v_{\mathrm{II}} \ge \gamma v_{\mathrm{I}}^{\dagger} H^{\mathrm{I}} v_{\mathrm{I}} + v_{\mathrm{II}}^{\dagger} H^{\mathrm{II}} \Lambda_{x}^{\mathrm{II}} v_{\mathrm{II}}, \qquad (20)$$

for some  $\gamma > 0$ , and we write

$$T_x^{\dagger} H T_x = \begin{pmatrix} H^{\mathrm{I}} & 0\\ 0 & H^{\mathrm{II}} \end{pmatrix},\tag{21}$$

with  $\delta^{-1}I \leq H^{\rm I}$ ,  $H^{\rm II} \leq \delta I$  for some  $\delta > 0$ . This block diagonal form is necessary because  $HA^x$  is symmetric. We restrict from Lu = g to consider boundary conditions of the form

<span id="page-6-2"></span>
$$v_{\text{II}} \stackrel{.}{=} \kappa v_{\text{I}} + g$$
, (22)

where  $\hat{=}$  denotes equality in the boundary. We assume that

<span id="page-6-0"></span>
$$H^{\mathrm{I}}\Lambda_{x}^{\mathrm{I}} + \kappa^{\dagger}H^{\mathrm{II}}\Lambda_{x}^{\mathrm{II}}\kappa \ge 0, \qquad (23)$$

which is automatically true if  $\kappa$  is sufficiently small.

Strong well-posedness of symmetric hyperbolic systems with maximally dissipative boundary conditions. Consider the time derivative of the energy E<sup>2</sup> = R Σ ǫ dV with ǫ = u †Hu, which, using integration by parts, gives

$$\partial_t E^2 = \int_{\Sigma} (u^{\dagger} H F + F^{\dagger} H u) dx \, dy \, dz - \int_{\partial \Sigma} u^{\dagger} H A^x u \, dy \, dz \,, \tag{24}$$

if we choose boundary conditions satisfying the condition [\(23\)](#page-6-0), where the inequality does not hold strictly, then we have

$$\partial_t E^2 = \int_{\Sigma} (u^{\dagger} H F + F^{\dagger} H u) dx \, dy \, dz$$

$$- \int_{\partial \Sigma} v_{\rm I}^{\dagger} \left[ H^{\rm I} \Lambda_x^{\rm I} + \kappa^{\dagger} H^{\rm II} \Lambda_x^{\rm II} \kappa \right] v_{\rm I} \, dy \, dz + c_1 \int_{\partial \Sigma} (g^{\dagger} H g) dy \, dz$$

$$\leq \int_{\Sigma} (u^{\dagger} H F + F^{\dagger} H u) dx \, dy \, dz + c_1 \int_{\partial \Sigma} (g^{\dagger} H g) dy \, dz \,, \tag{25}$$

for some positive c1, from which the estimate [\(18\)](#page-5-0) without the boundary term on the left-hand side follows. Otherwise, if the boundary conditions satisfy [\(23\)](#page-6-0), but with the inequality strict, then playing with some inequalities, we have

$$\partial_t E^2 + c_1 \int_{\partial \Sigma} (u^{\dagger} H u) dy \, dz$$

$$\leq \int_{\Sigma} (u^{\dagger} H F + F^{\dagger} H u) dx \, dy \, dz + c_2 \int_{\partial \Sigma} (g^{\dagger} H g) dy \, dz \,, \tag{26}$$

for some c1, c<sup>2</sup> > 0, from which strong well-posedness follows.

Discussion. Using symmetric hyperbolicity to demonstrate well-posedness, sometimes called the energy method, is typically easier to approach than the method that follows, and so should be used whenever possible. The energy method is fantastically powerful, and, when it applies, can be used to estimate long-term behavior of solutions to variable coefficient and nonlinear problems. Although it is not easy to construct examples of PDEs that are strongly but not symmetric hyperbolic in general relativity that is very often the case. In which case, our only hope is the Laplace–Fourier method. If the PDE system is strongly, but not symmetric hyperbolic, then maximally dissipative boundary conditions do not guarantee wellposedness.[27](#page-27-8)

## 1.4. The Laplace Fourier method

The initial boundary value problem. Consider once again an evolution system of the form [\(17\)](#page-5-1),

<span id="page-7-0"></span>
$$\partial_t u = A^p \partial_p u + F(t, x^i) \,, \tag{27}$$

on the half-space  $x \geq 0$ . We assume immediately that the system is strongly hyperbolic with nonvanishing speeds. Characteristic boundaries, that is, boundaries at which the speeds vanish, can also be treated. In contrast to the previous case, we choose vanishing initial data  $u(0,x^i)=0$ , but maintain inhomogeneous boundary conditions of the form  $Lu(t,x^i) = g(t,x^A)$  as before. We take the notation of the previous section. We say the system is strongly well-posed in the generalized sense if there exists a constant  $K_T$  for every T, independent of the data and forcing terms, such that for every  $0 \leq t \leq T$ , we have the estimate

$$\int_{0}^{t} ||u(t',\cdot)||_{\Sigma}^{2} dt' + \int_{0}^{t} ||u(t',\cdot)||_{\partial\Sigma}^{2} dt'$$

$$\leq K_{T}^{2} \int_{0}^{t} (||F(t',\cdot)||_{\Sigma}^{2} + ||g(t',\cdot)||_{\partial\Sigma}^{2}) dt', \tag{28}$$

for all boundary data g. The terminology in the generalized sense means that we have restricted to trivial initial data, and that we have an estimate on the integral in time of the solution on the left-hand side of the inequality.

Laplace–Fourier Transform. Taking the system (27) and Fourier transforming in the y and z directions results in a one-dimensional initial boundary value problem for every  $\omega^A$ , for which we need some representation of the solutions. To achieve this we furthermore Laplace transform in time. The total transformation is

$$\hat{u}(s, x, \omega^{A}) = \frac{1}{2\pi} \int_{0}^{\infty} \int_{\mathbf{R}^{2}} e^{-st + i\omega_{A}x^{A}} u(t, x, x^{A}) dy dz dt, \qquad (29)$$

with  $s = \eta + i\xi$  and  $\eta > 0$ . The inverse transform requires the contour integral, along the line  $s = \eta + i\xi$  with  $\eta > 0$  fixed,

$$u(t, x^{i}) = \frac{1}{(2\pi)^{2}} \oint_{-\infty}^{\infty} \int_{\mathbf{R}^{2}} e^{st - i\omega_{A}x^{A}} \hat{u}(s, x, \omega^{A}) dy dz d\xi,$$
 (30)

which fortunately we never have to compute explicitly, because we have Parseval's relation, which in this context states that

$$\int_0^\infty \int_{\mathbf{R}^2} e^{-2\eta t} |u(t, x, x^A)|^2 \, dy \, dz \, dt = \frac{1}{2\pi} \int_{-\infty}^\infty \int_{\mathbf{R}^2} |\hat{u}(s, x, \omega^A)|^2 \, d\omega^y \, d\omega^z \, dt \,. \tag{31}$$

Under this transformation we can rewrite the equations of motion as an ODE system

<span id="page-8-0"></span>
$$\partial_x \hat{u} = M\hat{u} + \hat{G}, \tag{32}$$

with symbol and sources

$$M = (A^x)^{-1} (s\mathbf{1} - i\omega A^{\hat{\omega}}), \quad \hat{G} = (A^x)^{-1} \hat{F},$$
 (33)

where we write  $\omega^A = |\omega|\hat{\omega}^A = \omega\hat{\omega}^A$ , and for later convenience define  $k = \sqrt{|s|^2 + \omega^2}$ , and the normalized frequencies s' = s/k and  $\omega' = \omega/k$ .

General  $L_2$  solution to the homogeneous problem. Start by considering the ODE system without forcing terms  $\hat{F}$ . Because the system is strongly hyperbolic we can assume without loss of generality that  $A^x$  has already been rotated to diagonal form  $\Lambda_x$ . Assuming that the negative block of the partition (19),  $\Lambda_x^{\text{II}} < 0$  has dimensions  $(d \times d)$ , it follows<sup>28</sup> that M must have d eigenvalues with negative real part  $\kappa_i$  for  $i = 1 \dots d$ . Therefore, the general  $L_2$  solution of (32) with vanishing  $\hat{F}$  is of the form

$$\hat{u}(s, x, \omega^A) = \sum_{i}^{d} \sigma_i e^{\kappa_i x} \Phi(x) v_i, \qquad (34)$$

with  $v_i$  the eigenvector or generalized eigenvector associated with  $\kappa_i$ , and  $\Phi(x)$  the appropriate polynomial to make that whole sum a sum over the eigensolutions of the ODE. Unfortunately, strong hyperbolicity does not tell us anything special about the eigenvectors of M, so we cannot assume that M is diagonalizable, and therefore we must allow for this polynomial ansatz in the solution. The complex coefficients  $\sigma_i$  are to be solved for by plugging the general solution into the boundary conditions.

Boundary conditions and boundary stability. As for symmetric hyperbolic systems, we consider here boundary conditions of the form (22), so that under Laplace–Fourier transform they become

$$\hat{u}^{\mathrm{II}} = \kappa \hat{u}^{\mathrm{I}} + \hat{g} \,, \tag{35}$$

where now we do not need the rotation to characteristic variables because we have absorbed it into the definition of u. Plugging the general solution into the boundary conditions gives a set of linear equations for  $\underline{\sigma} = (\sigma_i)$ ,

$$S(s,\omega)\underline{\sigma} = \hat{g}(s,\omega), \qquad (36)$$

for the coefficients  $\sigma_i$ . If this system of equations can be solved such that there exists a  $\delta > 0$  with

$$|\hat{u}(s,0,\omega^A)| < \delta |\hat{g}(s,\omega^A)|, \qquad (37)$$

for every s and  $\omega$  with  $\eta \geq 0$  then the system is called boundary stable.

Kreiss's symmetrizer theorem. Boundary stability is a necessary condition for strong well-posedness in the generalized sense. But furthermore a key theorem shows that under certain conditions boundary stability is also sufficient. The theorem says that if the system (27) is either symmetric hyperbolic, or strongly hyperbolic of constant multiplicity, and boundary stable, then there exists a family of matrices that we will denote as  $H(s', \hat{\omega}^A) \equiv H(s', \hat{\omega})$  with smooth dependence on s' and  $\hat{\omega}^A$ ,  $^{28-30}$  such that

(i)  $H(s', \hat{\omega})A^x$  is Hermitian for all s', and  $\hat{\omega}^A$ ,

(ii) if y and h are vectors satisfying the boundary conditions [\(22\)](#page-6-2), i.e. yII ˆ= κyI+h, then

$$y^{\dagger}H(s',\hat{\omega})A^{x}y \ge \delta_{1}|y|^{2} - C|h|^{2},$$
 (38)

where here δ<sup>1</sup> and C are positive constants independent of s ′ , ˆω <sup>A</sup>, y and h.

(iii) There exists a constant δ<sup>2</sup> such that

$$H(s'\mathbf{1} - i\omega'A^{\hat{\omega}}) + (s'\mathbf{1} - i\omega'A^{\hat{\omega}})^{\dagger}H^{\dagger} \ge \delta_2 \operatorname{Re}(s')\mathbf{1}.$$
(39)

To see how this symmetrizer H can be used to show strong well-posedness in the generalized sense we follow the discussion of Kreiss and Lorenz.[12](#page-27-1) Suppose that S is already constructed. Multiplying the Laplace–Fourier transformed equations of motion by H and taking the inner product with ˆu gives

<span id="page-10-0"></span>
$$-\frac{1}{k} \int_0^\infty (\hat{u}^\dagger H A^x \partial_x \hat{u}) dx + \int_0^\infty \hat{u}^\dagger H (s' \mathbf{1} - i\omega' A^{\hat{\omega}}) \hat{u} dx = \frac{1}{k} \int_0^\infty (\hat{u}^\dagger H \hat{F}) dx.$$
 (40)

We use properties (i) and (ii) of the theorem and obtain

$$2\int_0^\infty (\hat{u}^\dagger H A^x \partial_x \hat{u}) dx \ge \delta_1 |\hat{u}(s, 0, \omega)|^2 - C|\hat{g}(s, \omega)|^2.$$
(41)

Taking the real part of [\(40\)](#page-10-0), multiplying by 2k and using property (iii) of H gives the estimate

$$\delta_{1}|\hat{u}(s,0,\omega)|^{2} + \delta_{2}\eta \int_{0}^{\infty} |\hat{u}(s,0,\omega)|^{2} dx 
\leq c_{1} \left( \int_{0}^{\infty} |\hat{u}(s,x,\omega)|^{2} dx \right)^{1/2} \left( \int_{0}^{\infty} |\hat{F}(s,x,\omega)|^{2} dx \right)^{1/2} + C|\hat{g}(s,\omega)|^{2}, \quad (42)$$

with some positive c1. Inverting the Laplace–Fourier transform and using Parseval's relation gives strong well-posedness in the generalized sense. So the symmetrizer H helps even if forcing terms F are present. If we want to consider variable coefficient and nonlinear problems, similar comments apply to the Laplace–Fourier method as those at the end of the strong hyperbolicity, Subsec. [1.2.](#page-2-2)

## 1.5. Second-order systems

First-order in time, second-order in space evolution systems. Very often in physics applications we are not given first-order PDE systems like [\(1\)](#page-2-0), but rather equations that are first-order in time and second-order in space, like the wave equation,

$$\partial_t \phi = \pi \,, \quad \partial_t \pi = \Delta \phi \,.$$
 (43)

Equations of motion from a Hamiltonian fall out this way naturally. To analyze well-posedness of such equations we could reduce them to first-order by introducing new variables d<sup>i</sup> = ∂iφ and rewriting everything as a first-order system to which the results we have been discussing apply. The difficulty here is that the introduction of these reduction variables creates constraints  $d_i - \partial_i \phi = 0$ , and there is a freedom in how they can be used to make the reduction to first-order. Fortunately, it is not necessary to take care of these subtleties, because conditions under which "good" reductions exist have been analyzed in the literature.<sup>18</sup> Recently, these calculations have been extended to treat high-order systems of hyperbolic equations.<sup>31</sup> So consider the second-order in space evolution system,

<span id="page-11-0"></span>
$$\partial_t v = A_1^i \partial_i v + A_1 v + A_2 w + F_v ,$$
  

$$\partial_t w = B_1^{ij} \partial_i \partial_j v + B_1^i \partial_i v + B_2^i \partial_i w + B_2 w + F_w ,$$
(44)

as in the first-order case assume that the coefficient matrices are constant. We call the matrix

$$A^{p}{}_{i}{}^{j} = \begin{pmatrix} A^{j}_{1} \delta^{p}{}_{i} & A_{2} \delta^{p}{}_{i} \\ B^{pj}_{1} & B^{p}_{2} \end{pmatrix}, \tag{45}$$

the principal part matrix of the system. The indices i, j, p run over all spatial directions. The index i labels blocks of rows, and j blocks of columns.

Strong hyperbolicity and characteristic variables. Given an arbitrary unit spatial vector  $s^i$ , we call the matrix,

$$P^{s} = S^{i} A^{p}{}_{i}{}^{j} S_{j} s_{p} = \begin{pmatrix} A^{j}{}_{1} s_{j} & A_{2} \\ B^{j}{}_{1} s_{p} s_{j} & B^{p}{}_{2} s_{p} \end{pmatrix}, \tag{46}$$

with the abbreviation

$$S_i = \begin{pmatrix} s_i & 0 \\ 0 & 1 \end{pmatrix}, \tag{47}$$

the principal symbol of the system. If for every unit spatial vector the eigenvalues of the principal symbol are real, we call the system weakly hyperbolic. If furthermore, for every unit spatial vector  $s^i$  the principal symbol has a complete set of eigenvectors such that there exists a constant K independent of  $s^i$ , such that

$$|T_s| + |T_s^{-1}| \le K, (48)$$

where  $T_s$  is formed with the eigenvectors of  $P^s$  as columns, the system is called strongly hyperbolic. This condition is equivalent to well-posedness of the initial value problem, where now the norm contains first spatial derivatives of v,  $\partial_i v$ . It is also equivalent, at least in three spatial dimensions, to the existence of a strongly hyperbolic first-order reduction<sup>18</sup> and likewise a strongly hyperbolic pseudo-differential reduction.<sup>32,33</sup> I do not know of a place where this equivalence has been shown in higher spatial dimensions in physical space, but the result holds for pseudo-differential reductions in arbitrary spatial dimensions. The characteristic variables of the second-order in space system are defined to be the components of

$$u = T_s^{-1} \begin{pmatrix} \partial_s v \\ w \end{pmatrix}. \tag{49}$$

Strong hyperbolicity implies the existence of a complete set of characteristic variables just like in the first-order case.

**Symmetric hyperbolicity.** We call a symmetric matrix  $H^{ij}$ , independent of  $s^i$ , such that

<span id="page-12-0"></span>
$$S_i H^{ij} A^p{}_j{}^k s_p S_k = (S_i H^{ij} A^p{}_j{}^k s_p S_k)^{\dagger} , \qquad (50)$$

for every spatial vector  $s^i$ , a candidate symmetrizer. A positive definite candidate symmetrizer is called a symmetrizer. A system with a symmetrizer is called symmetric hyperbolic. The symmetrizer can be used to define a conserved energy, at least up to nonprincipal terms. Slightly abusing notation, the energy density is

$$\epsilon = (\partial_i v, w) H^{ij} (\partial_j v, w)^{\dagger}$$

$$= \partial_i v^{\dagger} H^{ij}_{vv} \partial_j v + \partial_i v^{\dagger} H^i_{vw} w + w H^{j\dagger}_{vw} \partial_j v^{\dagger} + w^{\dagger} H_{ww} w.$$
(51)

In simple cases, say for the wave equation, this "PDEs energy" may correspond to a true physical energy.  $^{34,35}$  In general a Hamiltonian for the system (44) guarantees a candidate symmetrizer, but *not* a symmetrizer. This definition of symmetric hyperbolicity for second-order in space systems is equivalent to the existence of a first-order reduction of (44) that is symmetric hyperbolic according to the definition for first-order systems. Maximally dissipative boundary conditions can be defined for second-order in space systems in a similar way to first-order systems, and can again be used to guarantee estimates of the solution including boundary data.

The Laplace–Fourier method. The Laplace–Fourier method applies to the second-order in space system (44) straightforwardly.<sup>5,36,37</sup> For brevity let us assume that there are as many v's as w's, and that  $A_2$  is invertible. Under this assumption, and that of trivial initial data, grouping all of the nonprincipal terms together, we can Laplace–Fourier transform and arrive at

$$s^{2}\hat{v} = A^{xx}\partial_{x}\partial_{x}\hat{v} + 2i\omega A^{x\hat{\omega}}\partial_{x}\hat{v} - \omega^{2}A^{\hat{\omega}\hat{\omega}}\hat{v} + sB^{x}\partial_{x}\hat{v} + i\omega B^{\hat{\omega}}\hat{v} + \hat{F}, \qquad (52)$$

with the shorthands

$$A^{ij} = A_2 B_1^{ij} - A_2 B_2^{(i} A_2^{-1} A_1^{j)}, \quad B^i = A_1^i + A_2 B_2^i A_2^{-1},$$
 (53)

with  $A^{ij}$  symmetric in i and j. Assuming that the system is strongly hyperbolic with nonvanishing speeds, we can introduce the reduction variables  $D\hat{v} = k^{-1}\partial_x\hat{v}$ , and manipulate the second-order ODE system to end up with

$$\partial_x \hat{u} = M\hat{u} + \hat{G}, \tag{54}$$

with the symbol

$$M(s, \omega^A) = k \begin{pmatrix} 0 & \mathbf{1} \\ A & B \end{pmatrix}, \tag{55}$$

with the lower two blocks given by

$$A = (A^{xx})^{-1} \left[ s'^2 \mathbf{1} + \omega'^2 A^{\hat{\omega}\hat{\omega}} \right], \quad B = (A^{xx})^{-1} \left[ s' B^x + 2i\omega' A^{x\hat{\omega}} \right].$$
 (56)

![](_page_13_Picture_2.jpeg)

Fig. 1. A schematic summary of the different levels of hyperbolicity. Every strongly hyperbolic system is weakly hyperbolic. Every symmetric hyperbolic system is strongly hyperbolic, and furthermore there is an intersection between systems that are strongly hyperbolic of constant multiplicity and symmetric hyperbolic, although the notions are not coincident.

<span id="page-13-0"></span>This type of reduction is called a pseudo-differential reduction to first order. We can construct the general solution to the ODE and consider boundary stability as before. Ultimately the norms that we use to estimate solutions will again contain first spatial derivatives of v.

## 1.6. Summary

I have given the definitions of well-posedness and hyperbolicity for initial and initial boundary value problems for first-order systems. The relationship between the various definitions are summarized in Fig. [1.](#page-13-0) I sketched how these definitions are extended to first-order in time, second-order in space systems. Obviously the description here is superficial, and I therefore recommend that you take a look at the books and review articles cited throughout. In the next class, we will see how these methods are applied to electromagnetism as a free-evolution system. From the point of view of hyperbolicity analysis, electromagnetism is a very satisfactory model for general relativity since it has both constraints and gauge freedom.

## 2. Free Evolution Formulations of Electromagnetism

## 2.1. Introduction

In the first lecture, we saw several notions of hyperbolicity, and that they are useful in different contexts. The moral of the story was threefold:

- (i) Strong hyperbolicity is good enough for the initial value problem, and is easy to check there is no good excuse not to bother!
- (ii) Symmetric hyperbolicity, or the energy method, is good for the IBVP, and is the preferred approach whenever it applies because it is simple to apply.
- (iii) The Laplace–Fourier method can be used to analyze well-posedness of the IBVP for PDEs that are strongly hyperbolic of constant multiplicity. If the system is only strongly hyperbolic then more work is needed to make definite statements because the theory is not complete. The Laplace–Fourier method applies to a larger class of boundary conditions than those that can be treated with the energy method, but the algebraic manipulation required is usually more involved.

In this class we will apply these notions to Maxwell's theory of electromagnetism, and will see that new complications arise. I want you to think of Maxwell as a model for general relativity; qualitatively nearly all of the same features are present. But the lower valence of the tensor fields make the whole thing easier to treat in a short time. I have prepared a number of mathematica notebooks to accompany the lecture, so that you can see how all of the various steps can be made in practice. The qualitative difference between the Maxwell equations and those of the previous lecture is gauge freedom. We therefore have to work a little before we can apply those notions. Dirac's theory of constrained Hamiltonian systems<sup>38</sup> tells us that there is a relationship between the gauge freedom and the constraints of the theory, but we will not use that deeply here. Instead I want to go through the various features of Maxwell, but impress upon you now that the structure we will discover in the equations of motion falls out because of the Hamiltonian form of the theory. In Helvi Witek's lectures<sup>39</sup> one popular formulation, called BSSNOK<sup>40–42</sup> is described in a form quite similar to what we will have for electromagnetism, but with dimension as a parameter.

### 2.2. The vacuum Maxwell equations

### 2.2.1. Hamiltonian and equations of motion

Let us start with the Hamiltonian for electromagnetism, in curved space, which is given by

<span id="page-14-0"></span>
$$H = \int_{\Omega} \frac{1}{2} \left[ (D \times A)_i (D \times A)^i + E_i E^i \right] - \Phi D^i E_i \, dV \,. \tag{57}$$

We have canonical positions  $A_i$ , and momenta  $\tilde{\pi}^i = -\sqrt{\gamma}E^i$ , and define the curl by

$$(D \times A)^i = \epsilon^{ijk} D_j A_k \,, \tag{58}$$

with  $\epsilon^{ijk}$  the Levi-Civita tensor. From this and Hamilton's equations, we obtain the equations of motion

<span id="page-14-1"></span>
$$\partial_t A_i = -\alpha E_i - D_i \Phi + \mathcal{L}_\beta A_i ,$$
  

$$\partial_t E^i = (D \times \alpha [D \times A])^i + \alpha K E^i + \mathcal{L}_\beta E^i ,$$
(59)

where for personal preference I work with the electric field  $E_i$  rather than the canonical momentum  $\tilde{\pi}^i$ . Here I am using the standard notation for the lapse function  $\alpha$ , the shift vector  $\beta^i$ , spatial metric  $\gamma_{ij}$ , extrinsic curvature  $K_{ij}$  and the volume element dV. I write the covariant derivative compatible with  $\gamma_{ij}$  as  $D_i$ . The lapse measures elapsed proper time between neighboring time slices. The shift describes how spatial coordinates are translated across times slices, and the extrinsic curvature is just the second fundamental form of the spatial slice as embedded in the space–time. If you have not met these quantities before, you can just ignore them by setting

$$\alpha = 1, \quad \beta^i = 0, \quad \gamma_{ij} = \delta_{ij}, \quad K_{ij} = 0,$$
 (60)

recovering at least a subset of the equations that you are used to from electro-dynamics.<sup>43</sup> The 3+1 decomposition of space—time is described beautifully elsewhere.<sup>10</sup> Note that, as in other sources<sup>20</sup> we could choose to work with the magnetic field  $B^i = (D \times A)^i$ , but will not do so, because we do not want to lose the analogy between relativity and electromagnetism. Formulations similar to that which we consider here have also been examined<sup>14,18</sup> in the literature.

#### 2.2.2. Constraints

Of course, we have the constraint that the divergence of the electric field vanishes,

$$M = -D_i \tilde{\pi}^i = D_i E^i = 0, \qquad (61)$$

which is obtained from the Hamiltonian (57) by varying with respect to the Lagrange multiplier  $\Phi$ , which we will call the gauge field. We call this restriction the momentum constraint. Computing the time derivative using the equations of motion (59) of the momentum constraint reveals

<span id="page-15-0"></span>
$$\partial_t M = \alpha K M + \mathcal{L}_\beta M \,. \tag{62}$$

Notice that the right hand contains only terms multiplied by the constraint, or its spatial derivative. So if we start with constraint satisfying initial data, then the constraints will remain satisfied in the time development of the data. This fact is expressed in different ways in the literature. It is sometimes said that the constraints propagate. Anyway, for numerical applications this means that all we need do is specify initial data satisfying the constraint, and then integrate up the equations of motion in time. This approach is called *free-evolution*. It is the main approach for treating the field equations of general relativity numerically. This is how we arrive at an evolution equations that we can treat with the methods of the last lecture. A few comments are in order:

(i) In applications using the free-evolution approach, constraint violation is inevitable because of numerical error. The best we can hope for is that as we throw more resolution at the problem we can make the errors arbitrarily small, in which case the numerical analyst might consider it solved. If sufficient computational power for a desired error is actually at their disposal the computational physicist will also consider it solved.

- (ii) In the free-evolution approach one must analyze the PDE properties of the system without assuming that the constraints are satisfied. This is exactly because due to numerical error we are really computing in the larger phase space which includes violations. For an introduction to solving the constraints of general relativity, see Hirotada Okawa's lectures later in the school.[44](#page-27-25) It is sometimes hard, or we are too lazy, to solve the constraints in the initial data. Although this is in principle wrong, if one can be confident that the violation is not the leading source of error in the numerical calculation, it may be well justified.
- (iii) A rather different approach is to resolve the constraints after every timestep, which is called constrained-evolution. With this method one expects to arrive at a mixed elliptic-hyperbolic problem, which cannot be treated with the methods discussed in the last lecture.

## 2.2.3. Gauge freedom and the pure gauge system

The equations of motion [\(59\)](#page-14-1) are invariant under the transformation

$$A_i \to A_i - D_i \psi \,, \tag{63}$$

with some arbitrary scalar function ψ. Suppose that we are given constraint satisfying initial data. What is the difference of in the time development with and without applying a gauge transformation to the initial data? It is easy to see that the pure gauge field ψ evolves according to

<span id="page-16-1"></span>
$$\partial_t \psi = \Delta[\Phi] + \mathcal{L}_\beta \psi \,, \tag{64}$$

where ∆[Φ] denotes the difference in Φ induced by the gauge change in the initial data.

It still would not quite be proper to start our well-posedness analysis, because the Hamiltonian does not determine the field Φ. And we cannot very well analyze a set of equations if we do not know what they are. So for this we need a gauge choice, by which we mean a choice of Φ. We will consider an equation of motion of the form

<span id="page-16-0"></span>
$$\partial_t \Phi = -\mu \alpha^2 \partial^i A_i + \mathcal{L}_\beta \Phi \,, \tag{65}$$

for Φ, with µ a scalar field that does not depend on any of the Maxwell fields. I am making this restriction so that the field equations remain linear. We write ∂ <sup>i</sup>A<sup>i</sup> = γ ij∂iA<sup>j</sup> . Note that choosing the partial derivative in the divergence here is intentional. If we took the covariant derivative then once we considered the system coupled to general relativity the resulting terms would not be minimally coupled. In principle we could just choose the gauge field as an a priori function, or indeed require that it satisfy an elliptic equation. But we will restrict ourselves exclusively to evolution gauges of the form [\(65\)](#page-16-0).

With this choice, how will ∆[Φ], the induced change from a gauge transformation in the initial data, evolve in time? Computing the time derivative of the difference of the two Φ's reveals

<span id="page-17-0"></span>
$$\partial_t \Delta[\Phi] = -\mu \alpha^2 \partial^i \partial_i \psi + \mathcal{L}_\beta \Delta[\Phi] \,. \tag{66}$$

Interestingly we have arrived at a closed subsystem [\(64\)](#page-16-1), [\(66\)](#page-17-0) for the evolution of the change in gauge, which we call the pure gauge system. The obvious question is now: what is the relationship, if any, between hyperbolicity of this pure gauge system and the Maxwell equations under the choice [\(65\)](#page-16-0)? We are nearly ready to try and tackle that problem, but one complication remains to be dealt with first.

## 2.2.4. Expanded phase space

The next step in the construction of our free-evolution formulation is to expand the phase space with another variable, which we call Z. The new variable is constrained to vanish on physical solutions. It needs an equation of motion, for which we choose

<span id="page-17-1"></span>
$$\partial_t Z = \alpha D^i E_i - \alpha \kappa Z + \mathcal{L}_\beta Z \,, \tag{67}$$

with κ some constant parametrizing the constraint damping, [45–](#page-27-26)[48](#page-28-0) which I do not have time to discuss further. So you can see that if both the constraints Z and the M are initially satisfied then Z will stay satisfied, provided that the inclusion of the new constraint does not break the momentum constraint. If we wanted to, here we could have chosen any amount of the momentum constraint on the right-hand side of this equation of motion. Instead I have made a choice, the first term, that will turn out to be convenient later.

Given that we want to find solutions of the Maxwell equations, this initially seems a bit strange. Why would we want to expand the solution space with more freedom to be wrong? The answer is that the PDE properties of the problem we want to solve are affected by this expansion, and typically favorably. It is imperative that we solve well-posed problems, so we are forced to consider the expansion. If we were to insist on the whole set of equations of motion, including those for the gauge choice [\(65\)](#page-16-0) as coming from a Hamiltonian, you can think, roughly speaking, of the new constraint Z as the canonical momentum of the gauge field Φ. In text books you normally see that type of construction only for the Lorenz gauge µ = 1, often in the context of quantum electrodynamics. The equivalent type of construction can be made for general relativity,[34,](#page-27-15)[49–](#page-28-1)[51](#page-28-2) but from the point of view of the physical system there is no reason to restrict the equations of motion in this way. Only physical quantities need to satisfy Hamilton's equations.

## 2.2.5. Fully expanded equations of motion

The last step is to choose how the new constraint is to be coupled. For this we are free to make parametrized additions of Z or its derivative to the other equations of motion. As in [\(67\)](#page-17-1), I will make a convenient choice now. The full equations of motion are then taken to be

<span id="page-18-1"></span>
$$\partial_t A_i = -\alpha E_i - D_i \Phi + \mathcal{L}_\beta A_i ,$$

$$\partial_t E^i = (D \times \alpha [D \times A])^i + \alpha D^i Z + \alpha K E^i + \mathcal{L}_\beta E^i ,$$

$$\partial_t \Phi = -\mu \alpha^2 [\partial^i A_i + Z] + \mathcal{L}_\beta \Phi ,$$

$$\partial_t Z = \alpha D_i E^i - \alpha \kappa Z + \mathcal{L}_\beta Z .$$
(68)

You should think about the consequences of making different choices after we see how the well-posedness analysis of the next section is. The system is subject to constraints

$$Z = 0, \quad M = D^i E_i = 0.$$
 (69)

The constraint subsystem is still closed. Computing the time derivative of the momentum constraint, which is altered from [\(62\)](#page-15-0), reveals

<span id="page-18-0"></span>
$$\partial_t M = \alpha D^i D_i Z + D^i \alpha D_i Z + \alpha K M + \mathcal{L}_{\beta} M.$$
 (70)

As we hoped when introducing the new constraint, the momentum constraint is not broken by Z. Assuming uniqueness of solutions to the subsystem, if the constraints are initially satisfied then they will remain so as the solution develops in time, so a free-evolution approach is justified. As in the case of the pure gauge system, one might wonder how, if at all, hyperbolicity of the closed constraint subsystem is inherited by the full equations of motion. We will consider these questions in the next section. Finally we have arrived at the formulation of the Maxwell equations that we will analyze with the methods of the last lecture. The obvious difference between our version of the Maxwell equations is that in general the given background lapse, shift, spatial metric and extrinsic curvature are constant in space and time. As discussed in the first class, we will side-track the issue by working in a neighborhood of an arbitrary point so that to a good approximation these coefficients are constant, and so we can ignore them. This is called the frozen coefficient approximation. Comparing with [\(44\)](#page-11-0), we see that the "v" variables are A<sup>i</sup> and Φ, whilst the "w" variables are E<sup>i</sup> and Z. Notice that if we want to keep the shape of [\(44\)](#page-11-0), we are not free to add derivatives of the momentum constraint to E<sup>i</sup> 's equation of motion. If we were to do so, we would have to start thinking in terms of a mixed hyperbolic–parabolic system.

## 2.3. Well-posedness analysis

## 2.3.1. Strong hyperbolicity

We work in the frozen coefficient approximation and discard nonprincipal terms. We need to consider the principal symbol for an arbitrary unit vector s i . To make the analysis tidier we use this unit vector to 2+1 decompose the vector quantities of electromagnetism, writing

$$\partial_s A_i = s_i [\partial_s^2 \psi] - s_i Z + \perp_i^A [\partial_s A_A], \quad E_i = s_i E_s + \perp_i^A E_A, \tag{71}$$

where we have defined the projection operator

$$\perp_j^i = \delta^i{}_j - s^i s_j \,, \tag{72}$$

and use upper case Latin indices A, B, C to denote projected objects. In the frozen coefficient approximation all derivatives of background quantities, including  $s^i$  vanish. Choosing to use the new variable  $[\partial_s^2\psi]=\partial_sA_s+Z$  may not initially seem natural, but the reason, which you can easily guess from the name, will rapidly become clear. The principal symbol splits into three decomposed blocks that can be read off from

<span id="page-19-0"></span>
$$\partial_t [\partial_s^2 \psi] \simeq -\partial_s [\partial_s \Phi] + \beta^s \partial_s [\partial_s^2 \psi] , \quad \partial_t [\partial_s \Phi] \simeq -\mu \alpha^2 \partial_s [\partial_s^2 \psi] + \beta^s \partial_s [\partial_s \Phi] , \quad (73)$$

should naturally be compared with the principal symbol of the pure gauge system. The remaining "scalar" equations are

<span id="page-19-1"></span>
$$\partial_t Z \simeq \alpha \partial_s E_s + \beta^s \partial_s Z$$
,  $\partial_t E_s \simeq \alpha \partial_s Z + \beta^s \partial_s E_s$ , (74)

which should be compared with the principal symbol of the constraint subsystem, and finally,

<span id="page-19-2"></span>
$$\partial_t [\partial_s A_A] \simeq -\alpha \partial_s E_A + \beta^s \partial_s [\partial_s A_A], \quad \partial_t E_A \simeq -\alpha \partial_s [\partial_s A_A] + \beta^s \partial_s E_A, \quad (75)$$

which is decoupled from both the "gauge" and "constraint" variables of the first two blocks. So very happily we find that both the pure gauge and constraint principal symbols, which can be read off from the pairs (64), (66) and (67), (70) are inherited by the formulation. This is not a coincidence and can be shown for a large class of constrained Hamiltonian systems. <sup>52</sup> These type of questions have also been studied for systems with constraints without requiring gauge freedom. <sup>16,17</sup> If we had chosen to add the constraints to the evolution equations differently, we could have ended up with the "constraint" variables on the right-hand sides of (73). But you should convince yourself that we could not have a formulation with the "gauge" variables on the right-hand sides of either (74) or (75). The principal symbol of each block is

$$P_{\mathcal{G}}^{s} = \begin{pmatrix} \beta^{s} & -1 \\ -\mu\alpha^{2} & \beta^{s} \end{pmatrix}, \quad P_{\mathcal{C}}^{s} = \begin{pmatrix} \beta^{s} & \alpha \\ \alpha & \beta^{s} \end{pmatrix}, \quad P_{\mathcal{P}}^{s} = \begin{pmatrix} \beta^{s} & -\alpha \\ -\alpha & \beta^{s} \end{pmatrix}, \tag{76}$$

respectively. The pure gauge block has eigenvalues  $\lambda_{\pm\mu} = \beta^s \pm \sqrt{\mu}\alpha$ . We assume that  $\alpha > 0$ , so the only requirement for weak hyperbolicity is that  $\mu \geq 0$ . With this restriction, the block is diagonalizable if  $\mu > 0$ . The other two blocks both have eigenvalues  $\lambda_{\pm} = \beta^s \pm \alpha$ , corresponding to the speed of light in the  $s^i$  direction, and are furthermore diagonalizable. The eigenvectors of each block are

$$\left(\pm 1, \sqrt{\mu}\alpha\right)^T, \quad \left(\pm 1, 1\right)^T, \quad \left(\pm 1, 1\right)^T, \tag{77}$$

respectively, and have characteristic variables

$$[\partial_s \Phi] \pm [\partial_s^2 \psi], \quad E_s \pm Z, \quad E_A \pm [\partial_s A_A],$$
 (78)

with speeds  $\lambda_{\pm\mu}$ ,  $\lambda_{\pm}$  and  $\lambda_{\pm}$ . These calculations are performed in the mathematica notebook Maxwell\_Strong.nb which accompanies the lecture.

### 2.3.2. Symmetric hyperbolicity

In this section, we will try to see which of family of the gauge conditions (65) result in a PDE system that is symmetric hyperbolic. The answer is "every gauge that is strongly hyperbolic." Therefore, before we start I want to give a word of warning; this result is a special feature of these formulations of the Maxwell equations, and does not necessarily carry over to other theories that we are interested in. In particular it is not true for relativity, as can be seen for popular gauge choices in numerical relativity.<sup>34</sup> More generally, suppose that we have a gauge choice for which the pure gauge subsystem is either strongly or symmetric hyperbolic. It has not been shown that there is necessarily a free-evolution formulation that is symmetric hyperbolic with that gauge. One might take the view that strongly, but not symmetric hyperbolic formulations are objectively worse than those that are symmetric hyperbolic. But sometimes in applications the choice that "works" might be the mathematically weaker one; so we cannot always just choose the symmetric hyperbolic system. This can be problematic because, as we have seen, establishing well-posedness of the initial boundary problem is tricky for generic systems that are only strongly hyperbolic, because there may be no applicable theory. With a bigger gauge freedom, it could even be that the choice of pure gauge that is useful is not symmetric hyperbolic, and then of course the expectation is that we cannot use that gauge to build a strongly hyperbolic formulation. These are the types of problems that can happen for the Einstein equations.

So that I can work with the same set of equations in this section and the next, I start by writing the principal part of the system (68) in fully second-order form,

$$\partial_0^2 \Phi \simeq \mu \gamma^{ij} \partial_i \partial_j \Phi \,, \quad \partial_0^2 A_i \simeq \gamma^{jk} \partial_j \partial_k A_i + \left(\frac{1}{\mu} - 1\right) \partial_0 \partial_i \Phi \,,$$
 (79)

where we have defined  $\partial_0 = (\partial_t - \beta^i \partial_i)/\alpha$ . Notice that if we take the Lorenz gauge,  $\mu = 1$ , each variable satisfies a decoupled wave equation. This change of variables does not affect the PDE properties of the system. Why not? From this one writes the principal part matrix as

$$A^{p}{}_{ik}{}^{jl} = \begin{pmatrix} 0 & 0 & \delta^{p}{}_{i} & 0 \\ 0 & 0 & 0 & \delta^{p}{}_{i}\delta^{l}{}_{k} \\ \mu\gamma^{pj} & 0 & 0 & 0 \\ 0 & \gamma^{pj}\delta^{l}{}_{k} & \left(\frac{1}{\mu} - 1\right)\delta^{p}{}_{k} & 0 \end{pmatrix}, \tag{80}$$

where here we have picked up indices from the fields in the principal part matrix, but this is completely compatible with the way we defined the principal part matrix for second-order in space systems. We make an ansatz for an energy density  $\epsilon$  with

$$\epsilon = u_{jm}^{\dagger} H^{ijkm} u_{ik}, \quad u_{ik} = (\partial_i \Phi, \partial_i A_k, \partial_0 \Phi, \partial_0 A_k)^{\dagger},$$
(81)

and a parametrized ansatz for  $H^{ijkm}$ ,

$$H^{ijkm} = \begin{pmatrix} h^1_{11} \gamma^{ij} & 0 & 0 & h^1_{14} \gamma^{ik} \\ 0 & h^1_{22} \gamma^{ij} \gamma^{km} + 2 h^2_{22} \gamma^{k(i} \gamma^{j)m} + 2 a^1_{22} \gamma^{k[i} \gamma^{j]m} & h^1_{23} \gamma^{im} & 0 \\ 0 & h^1_{23} \gamma^{jk} & h^1_{33} & 0 \\ h^1_{14} \gamma^{jm} & 0 & 0 & h^1_{44} \gamma^{km} \end{pmatrix}. \tag{82}$$

Imposing conservation of the energy, or in other words Hermiticity of,

$$S_i H^{ijmn} A^p_{jm}{}^{kl} s_p S_k$$

$$= \begin{pmatrix} 0 & h_{14}^1 s^l & h_{11}^1 + h_{14}^1 \left(\frac{1}{\mu} - 1\right) & 0 \\ h_{23}^1 \mu s^n & 0 & 0 & h_{22}^1 \gamma^{ln} + 2h_{22}^2 s^l s^n \\ h_{33}^1 \mu & 0 & 0 & h_{23}^1 s^l \\ 0 & h_{44}^1 \gamma^{ln} & \frac{1}{\mu} \left(h_{44}^1 (1 - \mu) + h_{14}^1 \mu\right) s^n & 0 \end{pmatrix}, \quad (83)$$

for every spatial vector  $s^i$ , see the last lecture (50), gives the conditions,

$$h_{14}^1 = h_{23}^1, \quad h_{33}^1 = h_{11}^1, \quad h_{22}^2 = 0, \quad h_{44}^1 = h_{22}^2,$$
 (84)

for  $\mu = 1$ , and otherwise,

$$h_{14}^{1} = h_{23}^{1}\mu, \quad h_{33}^{1} = \frac{h_{11}^{1} + (1 - \mu)h_{23}^{1}}{\mu},$$

$$h_{22}^{1} = h_{23}^{1}\mu, \quad h_{22}^{2} = 0, \quad h_{44}^{1} = h_{23}^{1}\mu,$$
(85)

with which we have a candidate symmetrizer. The last part of the calculation is to choose the remaining parameters so that the candidate symmetrizer is positive definite. With the Lorenz gauge  $\mu=1$  the choice

$$h_{11}^1 = 1, \quad h_{23}^1 = 0, \quad h_{22}^1 = 1, \quad a_{22}^1 = 0, \quad h_{22}^1 = 0,$$
 (86)

does the trick. Other choices work just as well. In the generic case the candidate is positive with  $a_{22}^1=0$  and  $h_{23}^1<\frac{1}{2+\mu}$ .

Having shown symmetric hyperbolicity we could write down Maximally dissipative boundary conditions that render the IBVP well-posed. As we will see in the next section, these boundary conditions would still not be satisfactory. There are numerical methods, called summation by parts methods, reviewed in detail elsewhere,<sup>5</sup> that can use the conserved energy to guarantee stability in numerical

![](_page_22_Picture_2.jpeg)

Fig. 2. Besides being well-posed, the boundary conditions at x = 0 should be constraint preserving, otherwise everything in their causal future will not solve field equations. In this context causal future means "what can be affected by improper boundary conditions." In our formulation [\(68\)](#page-18-1) constraint violation propagates at the speed of light, but one could equally well construct systems in which constraint violation propagates faster. In numerical applications error can travel faster than the maximum speed present. Care is needed in interpreting the affected region.

<span id="page-22-0"></span>approximation. These calculations are performed, following,[34](#page-27-15) in the mathematica notebook Maxwell Symmetric.nb with the package xTensor for abstract tensor computer algebra,[53](#page-28-4) albeit in a trivial way.

## 2.3.3. Application of the Laplace–Fourier method

Electromagnetism has a crucial complication that was not present in the examples that we considered with the IBVP in the last lecture. The presence of constraints complicates the analysis of the IBVP. If the formulation is symmetric hyperbolic, we can use maximally dissipative boundary conditions to guarantee well-posedness, but such boundary conditions will in general not be compatible with the constraints. In other words, their use will pump constraint violation into the domain from the boundary, as shown in Fig. [2,](#page-22-0) rendering the solution to the IBVP unphysical. With this in mind we require three properties[54–](#page-28-5)[56](#page-28-6) of our boundary conditions:

- (i) Well-posedness, which, with all that has been said already we need not comment on here.
- (ii) Constraint preservation. We are interested in computing solutions to the Maxwell equations, so the boundary conditions had better respect the constraints. In numerical approximation, it is okay for the boundary conditions to cause violation of the constraints, provided that the violation converges away with resolution. This is only possible if the underlying continuum boundary conditions are constraint preserving.

(iii) Radiation control. The boundary conditions should also control the incoming physical radiation in a way that is appropriate to the problem at hand. In general relativity, we are typically modeling asymptotically flat space–times, so this really means no incoming gravitational waves. But in electromagnetism we might be interested in the response of the field to an incoming wave.

In the context of numerical relativity, we consider the initial boundary value problem because computers have only finite memory, and so modeling the entire physical domain accurately is difficult. One possible way to simulate the entire region of interest which is currently under investigation is to use "hyperboloidal" slices, which are spacelike, but which terminate at future null infinity. <sup>57–63</sup> Another would be to use methods called cauchy-characteristic-matching, or cauchy-characteristic-extraction, in which a code that solves the field equations in the form we have been considering communicates data to another code that solves the equations in null coordinates all of the way out to null infinity. <sup>64–67</sup> Nevertheless, the current standard in numerical relativity is to truncate the domain at some large radius. The communication needed in the cauchy-characteristic procedure is also expected to require an understanding of the initial boundary value problem, as is the use of hyperboloidal slices if such data are evolved with a formulation that has superluminal speeds.

For the Laplace-Fourier analysis we work in the spatial half plane  $x \geq 0$ . We fix,

$$\alpha = 1, \quad \beta^x = 0, \quad \beta^y = 0, \quad \beta^z = 0,$$
 (87)

and assume that  $\gamma_{ij}$  is just the identity. The only one of these assumptions that is not justified is that  $\beta^x = 0,^{56}$  which can also be dealt with, 68 but which makes the algebra much more complicated and does not help to illustrate how the method is to be applied. Performing the Laplace–Fourier transform, and eliminating  $E_i$  and Z gives a set of second-order ODEs

$$s^{2}\hat{\Phi} = \mu[\partial_{x}^{2} - \omega^{2}]\hat{\Phi},$$

$$s^{2}\hat{A}_{x} = [\partial_{x}^{2} - \omega^{2}]\hat{A}_{x} + \left(\frac{1}{\mu} - 1\right)s\partial_{x}\hat{\Phi},$$

$$s^{2}\hat{A}_{\hat{\omega}} = [\partial_{x}^{2} - \omega^{2}]\hat{A}_{\hat{\omega}} + \left(\frac{1}{\mu} - 1\right)i\omega s\hat{\Phi},$$

$$(88)$$

$$s^{2}\hat{A}_{\hat{\nu}} = [\partial_{x}^{2} - \omega^{2}]\hat{A}_{\hat{\nu}},$$

where the vector  $\hat{A}_i$  has been decomposed according to

$$\hat{A}_i = \hat{x}_i \hat{A}_{\hat{x}} + \hat{\omega}_i \hat{A}_{\hat{\omega}} + \hat{\nu}_i \hat{A}_{\hat{\nu}} , \qquad (89)$$

with  $\hat{x}^i$ , a unit vector in the x-direction,  $\hat{\omega}^i$  a unit vector in the  $\omega^i$  direction, and  $\hat{\nu}^i$  a unit vector orthogonal to both  $\hat{x}^i$  and  $\hat{\omega}^i$ . Exactly as described in the first lecture, we reduce the system to a set of first-order ODEs by introducing the

pseudo-differential reduction variables,

$$D\hat{\Phi} = \frac{\partial_x \hat{\Phi}}{\kappa} \,, \quad D\hat{A}_x = \frac{\partial_x \hat{A}_x}{\kappa} \,, \quad D\hat{A}_{\hat{\omega}} = \frac{\partial_x \hat{A}_{\hat{\omega}}}{\kappa} \,, \quad D\hat{A}_{\hat{\nu}} = \frac{\partial_x \hat{A}_{\hat{\nu}}}{\kappa} \,, \tag{90}$$

where  $\omega = \sqrt{\omega^i \omega_i}$ , and we define  $\kappa = \sqrt{|s|^2 + \omega^2}$ . We will also use the shorthands

$$s' = \kappa^{-1} s , \qquad \omega' = \kappa^{-1} \omega ,$$

$$\tau_{\pm} = \pm \kappa \sqrt{s'^{2} + \omega'^{2}} , \qquad \tau'_{\pm} = \kappa^{-1} \tau_{\pm} ,$$

$$\tau_{\pm \mu} = \pm \kappa \sqrt{\frac{s'^{2}}{\mu} + \omega'^{2}} , \qquad \tau'_{\pm \mu} = \kappa^{-1} \tau_{\pm \mu} .$$
(91)

The first-order ODE system is

$$\partial_{x}\hat{\Phi} = \kappa D\hat{\Phi}, \qquad \partial_{x}D\hat{\Phi} = -\kappa \tau'_{+\mu}\tau'_{-\mu}\hat{\Phi},$$

$$\partial_{x}\hat{A}_{x} = \kappa D\hat{A}_{x}, \quad \partial_{x}D\hat{A}_{x} = -\kappa \tau'_{+}\tau'_{-}\hat{A}_{x} + \kappa \left(1 - \frac{1}{\mu}\right)s'D\hat{\Phi},$$

$$\partial_{x}\hat{A}_{\hat{\omega}} = \kappa D\hat{A}_{\hat{\omega}}, \quad \partial_{x}D\hat{A}_{\hat{\omega}} = -\kappa \tau'_{+}\tau'_{-}\hat{A}_{\hat{\omega}} + i\omega'\kappa \left(1 - \frac{1}{\mu}\right)s'\hat{\Phi},$$

$$\partial_{x}\hat{A}_{\hat{\nu}} = \kappa D\hat{A}_{\hat{\nu}}, \quad \partial_{x}D\hat{A}_{\hat{\nu}} = -\kappa \tau'_{-}\tau'_{-}\hat{A}_{\hat{\nu}},$$

$$\partial_{x}D\hat{A}_{\hat{\nu}} = \kappa D\hat{A}_{\hat{\nu}}, \quad \partial_{x}D\hat{A}_{\hat{\nu}} = -\kappa \tau'_{-}\tau'_{-}\hat{A}_{\hat{\nu}},$$
(92)

which is obviously of the form  $\partial_x \hat{u} = M\hat{u}$ . Since in this case M is always diagonalizable, the general  $L_2$  solution to this system at the boundary x = 0 is formed by a sum over the eigenvectors of M whose eigenvector has negative real part. It is

$$\hat{\Phi} = \sigma_{\Phi} , \qquad \qquad D\hat{\Phi} = \tau'_{-\mu}\sigma_{\Phi} ,$$

$$\hat{A}_{x} = -\frac{\sigma_{Z}}{\tau'_{-}} - \frac{\tau'_{-\mu}\sigma_{\Phi}}{s'} - \frac{i\omega'\sigma_{A_{\hat{\omega}}}}{\tau'_{-}} , \qquad D\hat{A}_{x} = -\sigma_{Z} - \frac{\tau'_{-\mu}\sigma_{\Phi}}{s'} - i\omega'\sigma_{A_{\hat{\omega}}} ,$$

$$\hat{A}_{\hat{\omega}} = \sigma_{A_{\hat{\omega}}} - \frac{i\omega'\sigma_{\Phi}}{s'} , \qquad \qquad D\hat{A}_{\hat{\omega}} = \tau'_{-}\sigma_{A_{\hat{\omega}}} - \frac{i\omega'\tau'_{-\mu}\sigma_{\Phi}}{s'} ,$$

$$\hat{A}_{\hat{\nu}} = \sigma_{A_{\hat{\nu}}} , \qquad \qquad D\hat{A}_{\hat{\nu}} = \tau'_{-}\sigma_{A_{\hat{\nu}}} ,$$

$$(93)$$

with  $\sigma_{\Phi}$ ,  $\sigma_{Z}$ ,  $\sigma_{A_{\tilde{\omega}}}$ ,  $\sigma_{A_{\tilde{\nu}}}$  complex constants to be determined by substituting into boundary conditions, which are yet to be specified. Notice that I have carefully constructed the solution so that it is a sum of a gauge  $\sigma_{\Phi}$ , constraint violating  $\sigma_{Z}$  and physical  $\sigma_{A_{\tilde{\omega}}}$ ,  $\sigma_{A_{\tilde{\nu}}}$  part. It has not been shown that this works for any constrained Hamiltonian system, but using that of Ref. 52, I expect that this can be done. In any case for general relativity, you *can* write the general solution like this.<sup>68</sup> Since in the principal part, the gauge field  $\Phi$  and the constraint Z satisfy wave equations, the obvious choice is something like a Sommerfeld condition,

$$[\partial_t - \sqrt{\mu}\partial_x]^2 \Phi = \partial_t g_\Phi , \quad [\partial_t - \partial_x] Z = \partial_t g_Z , \tag{94}$$

on each, which should absorb outgoing waves without causing large reflections. In applications we would of course choose g<sup>Z</sup> = 0, so that the incoming characteristic variable of the constraint subsystem vanishes. But here we choose an arbitrary function to show that boundary stability can be obtained even with nontrivial data for the constraints. With constraint preservation out of the way, we have to think about good physical boundary conditions. The electric and magnetic fields are gauge invariant, and unambiguously represent the Maxwell field strength, so we choose

$$[\partial_t - \partial_x] (\partial_t A_A + \partial_A \Phi - \partial_x A_A + \partial_A A_x) = \partial_t g_A.$$
 (95)

I leave it as an exercise for you to convince yourself that this is really a boundary condition on some combination of the electric and magnetic fields, actually φ<sup>0</sup> in the terminology of Teukolsky.[69](#page-28-12) Laplace–Fourier transforming the boundary conditions and substituting the general solution into them, we can solve for the constants σΦ, σZ, σAω<sup>ˆ</sup> , σAν<sup>ˆ</sup> and obtain the solution

$$\hat{\Phi} = \frac{s'\hat{g}_{\Phi}}{\left(s' + \sqrt{s'^{2} + \mu\omega'^{2}}\right)^{2}}, \quad D\hat{\Phi} = -\frac{\sqrt{s'^{2} + \mu\omega'^{2}}s'\hat{g}_{\Phi}}{\sqrt{\mu}\left(s' + \sqrt{s'^{2} + \mu\omega'^{2}}\right)^{2}},$$

$$\hat{A}_{x} = \frac{i\omega'\hat{g}_{\hat{\omega}}}{\left(s' + \sqrt{s'^{2} + \omega'^{2}}\right)^{2}} + \frac{\hat{g}_{Z}}{s' + \sqrt{s'^{2} + \omega'^{2}}} + \frac{\sqrt{s'^{2} + \mu\omega'^{2}}}{\sqrt{\mu}\left(s' + \sqrt{s'^{2} + \mu\omega'^{2}}\right)^{2}},$$

$$D\hat{A}_{x} = -\frac{i\omega'\sqrt{s'^{2} + \omega'^{2}}\hat{g}_{\hat{\omega}}}{\left(s' + \sqrt{s'^{2} + \omega'^{2}}\right)^{2}} - \frac{\sqrt{s'^{2} + \omega'^{2}}\hat{g}_{Z}}{s' + \sqrt{s'^{2} + \omega'^{2}}} - \frac{\left(s'^{2} + \mu\omega'^{2}\right)\hat{g}_{\Phi}}{\mu\left(s' + \sqrt{s'^{2} + \mu\omega'^{2}}\right)^{2}},$$

$$\hat{A}_{\hat{\omega}} = \frac{\sqrt{s'^{2} + \omega'^{2}}\hat{g}_{\hat{\omega}}}{\left(s' + \sqrt{s'^{2} + \omega'^{2}}\right)^{2}} - \frac{i\omega'\hat{g}_{Z}}{\left(s' + \sqrt{s'^{2} + \omega'^{2}}\right)^{2}} - \frac{i\omega'\hat{g}_{\Phi}}{\left(s' + \sqrt{s'^{2} + \mu\omega'^{2}}\right)^{2}},$$

$$D\hat{A}_{\hat{\omega}} = -\frac{\left(s'^{2} + \omega'^{2}\right)\hat{g}_{\hat{\omega}}}{\left(s' + \sqrt{s'^{2} + \omega'^{2}}\right)^{2}} + \frac{i\omega'\sqrt{s'^{2} + \omega'^{2}}\hat{g}_{Z}}{\left(s' + \sqrt{s'^{2} + \omega'^{2}}\right)^{2}} + \frac{i\omega'\sqrt{s'^{2} + \mu\omega'^{2}}\hat{g}_{\Phi}}{\sqrt{\mu}\left(s' + \sqrt{s'^{2} + \mu\omega'^{2}}\right)^{2}},$$

$$\hat{A}_{\hat{\nu}} = \frac{s'\hat{g}_{\hat{\nu}}}{\left(s' + \sqrt{s'^{2} + \omega'^{2}}\right)^{2}}, \quad D\hat{A}_{\hat{\nu}} = -\frac{s'\sqrt{s'^{2} + \omega'^{2}}\hat{g}_{\hat{\nu}}}{\left(s' + \sqrt{s'^{2} + \omega'^{2}}\right)^{2}},$$

at the boundary x = 0, where now I have abandoned most of the shorthands so that you can see how it really looks. All that remains is to show that each of the variables is bounded in s and ω, which I leave as an exercise, but point you towards Ref. [36](#page-27-17) which shows the necessary estimates on all of the terms present here. The essential point is that we do not have to worry about the numerators in any of the fractions, because they are obviously bounded, and since the real part of s ′ is positive, terms like s ′ + √ s ′ <sup>2</sup> + ω′ <sup>2</sup> appearing in the denominators are bounded away from zero. Recalling that by construction σ<sup>Z</sup> corresponds directly to constraint violation, and noting that

$$\sigma_Z = \frac{s'\hat{g}_Z}{s' + \sqrt{s'^2 + \omega'^2}},\tag{97}$$

it is clear that the constraint preserving boundary conditions work when  $g_Z=0$  is chosen.

These calculations are largely performed in the mathematica notebook Maxwell\_LF.nb which accompanies the lecture. With the Lorenz gauge,  $\mu=1$ , well-posedness can be shown for constraint preserving boundary conditions using the energy method<sup>70,71</sup> with a special choice of symmetrizer, or alternatively with the Kreiss-Winicour cascade approach.<sup>36</sup> To my knowledge this is the first time that boundary stability has been demonstrated for arbitrary hyperbolic gauge conditions inside the family (65).

### 2.4. Summary

In this lecture we looked at different formulations of electromagnetism suitable for free-evolution. We saw that for every strongly hyperbolic pure gauge, we could build a formulation which was itself strongly hyperbolic. We saw furthermore that system is symmetric hyperbolic for all of these gauge choices. Working then in the high-frequency frozen coefficient approximation, we used the Laplace–Fourier method to investigate boundary stability with constraint preserving boundary conditions. Some parts of the calculations were not very explicitly presented. To understand the ins-and-outs I recommend that you study the mathematica notebooks in tandem with the lecture notes. They are available at the school's website. Some of the calculations presented in this lecture used the mathematica package  $xTensor^{53}$  for abstract tensor calculations.

### Acknowledgments

I thank the organizers of the NRHEP2 school for giving me the rewarding opportunity to present these lectures. I have benefited greatly from discussions with Bernd Brügmann, Ronny Richter, Milton Ruiz and Andreas Weyhausen. I am especially grateful to Olivier Sarbach for carefully reading the lecture notes and offering very helpful criticism. I am supported by the DFG grant SFB/Transregio 7.

### <span id="page-26-1"></span><span id="page-26-0"></span>References

- T. Baumgarte and S. Shapiro, Numerical Relativity: Solving Einstein's Equations on the Computer (Cambridge University Press, Cambridge, 2010).
- <span id="page-26-2"></span> M. Alcubierre, Introduction to 3 + 1 Numerical Relativity (Oxford University Press, USA, 2008).
- <span id="page-26-3"></span>3. U. Sperhake, Numerical relativity in higher dimensions, arXiv:1301.3772.
- <span id="page-26-6"></span>4. H. P. Pfeiffer, Class. Quantum Grav. 29, 124004 (2012).
- 5. O. Sarbach and M. Tiglio, *Living Rev. Rel.* **15**, 9 (2012).
- 6. I. Hinder, Class. Quantum Grav. 27, 114004 (2010).
- <span id="page-26-4"></span>U. Sperhake, Lect. Notes Phys. 769, 125 (2009).
- <span id="page-26-5"></span>8. P. Grandclément and J. Novak, Living Rev. Rel. 12, 1 (2009).
- <span id="page-26-7"></span>9. E. Gourgoulhon, An introduction to the theory of rotating relativistic stars, arXiv:1003.5015.
- E. Gourgoulhon, 3 + 1 formalism and bases of numerical relativity, arXiv:gr-qc/0703035.

- <span id="page-27-0"></span>11. F. Pretorius, Binary black hole coalescence, in *Physics of Relativistic Objects in Compact Binaries: From Birth to Coalescence*, Vol. 359, ed. W. B. Burton (Springer, Netherlands, 2009), pp. 305–369.
- <span id="page-27-1"></span> H.-O. Kreiss and J. Lorenz, Initial-Boundary Value Problems and the Navier-Stokes Equations (Academic Press, New York, 1989).
- <span id="page-27-2"></span> B. Gustafsson, H.-O. Kreiss and J. Oliger, Time Dependent Problems and Difference Methods (Wiley, New York, 1995).
- <span id="page-27-3"></span> A. M. Knapp, E. J. Walker and T. W. Baumgarte, Phys. Rev. D 65, 064031 (2002), arXiv:gr-qc/0201051.
- L. Lindblom, M. A. Scheel, L. E. Kidder, H. P. Pfeiffer, D. Shoemaker and S. A. Teukolsky, Phys. Rev. D 69, 124025 (2004).
- <span id="page-27-28"></span><span id="page-27-27"></span>16. O. A. Reula, J. Hyperbol. Diff. Equat. 1, 251 (2004).
- <span id="page-27-11"></span>17. C. Gundlach and J. M. Martin-Garcia, Phys. Rev. D 70, 044031 (2004).
- 18. C. Gundlach and J. M. Martín-García, Class. Quantum Grav. 23, S387 (2006).
- <span id="page-27-24"></span>19. O. Reula and O. Sarbach, J. Hyperbol. Diff. Equat. 2, 397 (2005).
- <span id="page-27-4"></span>20. M. Alcubierre, J. C. Degollado and M. Salgado, Phys. Rev. D 80, 104022 (2009).
- <span id="page-27-5"></span> H. P. Pfeiffer and A. I. MacFadyen, Hyperbolicity of force-free electrodynamics, arXiv:1307.7782.
- <span id="page-27-6"></span>22. H.-O. Kreiss, Math. Scand. 7, 71 (1959).
- 23. A. Majda and S. Osher, Commun. Pure Appl. Math. 28, 607 (1975).
- 24. P. D. Lax and R. S. Phillips, Commun. Pure Appl. Math. 13, 427 (1960).
- <span id="page-27-7"></span>25. J. Rauch, Trans. Am. Math. Soc. 291, 167 (1985).
- <span id="page-27-8"></span>26. P. Secchi, Diff. Int. Eq. 9, 671 (1996).
- <span id="page-27-9"></span>27. G. Calabrese and O. Sarbach, J. Math. Phys. 44, 3888 (2003).
- 28. H.-O. Kreiss, Commun. Pure Appl. Math. 23, 277 (1970).
- <span id="page-27-10"></span>29. M. S. Agranovich, Funct. Anal. Appl. 6, 85 (1972).
- <span id="page-27-12"></span>30. G. Métivier, Bull. London Math. Soc. 32, 689 (2000).
- 31. D. Hilditch and R. Richter, Hyperbolicity of high order systems of evolution equations, in preparation.
- <span id="page-27-13"></span>32. M. E. Taylor (ed.), *Pseudodifferential Operators* (Princeton University Press, Princeton, 1981).
- <span id="page-27-15"></span><span id="page-27-14"></span>33. G. Nagy, O. E. Ortiz and O. A. Reula, *Phys. Rev. D* 70, 044012 (2004).
- <span id="page-27-16"></span>D. Hilditch and R. Richter, Phys. Rev. D 86, 123017 (2012).
- <span id="page-27-17"></span>R. Richter and D. Hilditch, J. Phys. Conf. Ser. 314, 012102 (2011).
- <span id="page-27-18"></span>36. H.-O. Kreiss and J. Winicour, Class. Quantum Grav. 23, S405 (2006).
- 37. H.-O. Kreiss, O. E. Ortiz and N. A. Petersson, Initial-boundary value problems for second order systems of partial differential equations, arXiv:1012.1065.
- <span id="page-27-19"></span> P. A. M. Dirac, Lectures on Quantum Mechanics, Belfer Graduate School of Science Monographs Series, Vol. 2 (Belfer Graduate School of Science, New York, 1964).
- <span id="page-27-21"></span><span id="page-27-20"></span>39. H. Witek, Int. J. Mod. Phys. A 28, 1340017 (2013).
- 40. T. W. Baumgarte and S. L. Shapiro, *Phys. Rev. D* 59, 024007 (1998).
- <span id="page-27-22"></span>41. M. Shibata and T. Nakamura, Phys. Rev. D 52, 5428 (1995).
- <span id="page-27-23"></span>42. T. Nakamura, K.-I. Oohara and Y. Kojima, Prog. Theor. Phys. Suppl. 90, 1 (1987).
- <span id="page-27-25"></span>43. J. D. Jackson, Classical Electrodynamics, 3rd edn. (Wiley, New York, 1999).
- <span id="page-27-26"></span>44. H. Okawa, Int. J. Mod. Phys. A 28, 1340016 (2013).
- 45. A. Weyhausen, S. Bernuzzi and D. Hilditch, Phys. Rev. D 85, 024038 (2012).
- 46. R. Owen, Phys. Rev. D 76, 044019 (2007).
- C. Gundlach, J. M. Martin-Garcia, G. Calabrese and I. Hinder, Class. Quantum Grav. 22, 3767 (2005).

- <span id="page-28-1"></span><span id="page-28-0"></span>48. O. Brodbeck, S. Frittelli, P. Hübner and O. A. Reula, J. Math. Phys. 40, 909 (1999).
- 49. J. D. Brown, Phys. Rev. D 84, 084014 (2011).
- <span id="page-28-2"></span>50. C. Bona, C. Bona-Casas and C. Palenzuela, Phys. Rev. D 82, 124010 (2010).
- <span id="page-28-3"></span>51. J. D. Brown, Strongly hyperbolic extensions of the ADM Hamiltonian, arXiv:0803.0334.
- 52. D. Hilditch and R. Richter, Hyperbolicity of physical theories with application to general relativity, arXiv:1303.4783.
- <span id="page-28-5"></span><span id="page-28-4"></span>53. J. M. Martin-Garcia, xAct: Tensor computer algebra, http://www.xact.es/.
- 54. J. M. Stewart, Class. Quantum Grav. 15, 2865 (1998).
- <span id="page-28-6"></span>55. O. Rinne, Class. Quantum Grav. 23, 6275 (2006).
- <span id="page-28-7"></span>56. M. Ruiz, O. Rinne and O. Sarbach, Class. Quantum Grav. 24, 6349 (2007).
- O. Rinne and V. Moncrief, Class. Quantum Grav. 30, 095009 (2013).
- 58. S. Bernuzzi, A. Nagar and A. Zenginoglu, Phys. Rev. D 84, 084026 (2011).
- 59. O. Rinne, Class. Quantum Grav. 27, 035014 (2010).
- 60. A. Zenginoglu, Class. Quantum Grav. 25, 195025 (2008).
- 61. A. Zenginoğlu and S. Husa, Class. Quantum Grav. 25, 19 (2008).
- <span id="page-28-8"></span>62. G. Calabrese, C. Gundlach and D. Hilditch, Class. Quantum Grav. 23, 4829 (2006).
- <span id="page-28-9"></span>63. J. Frauendiener, *Living Rev. Rel.* **7**, 1 (2004).
- 64. J. Winicour, *Living Rev. Rel.* 1, 5 (1998).
- C. Reisswig, N. T. Bishop, D. Pollney and B. Szilagyi, *Phys. Rev. Lett.* 103, 221101 (2009).
- C. Reisswig, N. T. Bishop, D. Pollney and B. Szilagyi, Class. Quantum Grav. 27, 075014 (2010).
- <span id="page-28-11"></span><span id="page-28-10"></span>67. C. Reisswig, N. T. Bishop and D. Pollney, Gen. Relativ. Gravit. 45, 1069 (2013).
- 68. D. Hilditch and M. Ruiz, The initial boundary value problem of the Z4c formulation of general relativity, in preparation.
- <span id="page-28-13"></span><span id="page-28-12"></span>69. S. A. Teukolsky, Astrophys. J. 185, 635 (1973).
- H.-O. Kreiss, O. Reula, O. Sarbach and J. Winicour, Class. Quantum Grav. 24, 5973 (2007).
- <span id="page-28-14"></span> H.-O. Kreiss, O. Reula, O. Sarbach and J. Winicour, Commun. Math. Phys. 289, 1099 (2009).
- <span id="page-28-15"></span>72. NR/HEP2: Spring School, http://blackholes.ist.utl.pt/nrhep2/?