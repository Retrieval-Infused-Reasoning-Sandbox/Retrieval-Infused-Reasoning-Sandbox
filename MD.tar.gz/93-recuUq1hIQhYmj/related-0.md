# Stability of a Two-Phase Stokes Problem with Surface Tension

Jae Ho Choi

Department of Mathematics, University of Pennsylvania, Philadelphia, PA 19104 ORCID: https://orcid.org/0009-0003-8968-863X E-mail address: choijh11@sas.upenn.edu

#### Abstract

In this work, we study the well-posedness of a system of partial differential equations that model the dynamics of a two-dimensional Stokes bubble immersed in two-dimensional ambient Stokes fluid of the same viscosity that extends to infinity under the effect of surface tension. We assume that the two fluids are immiscible and incompressible and that there is no interfacial jump in the fluid velocity. For this PDE system, a circular fluid bubble is a steady-state solution. Given an initial contour for the fluid bubble which is sufficiently close to a circle, we show that there exists a unique, global-in-time solution. This unique solution decays to a circle exponentially fast, which means that circular fluid bubbles are stable steady-state solutions. We also obtain a result concerning the regularity of the unique solution, that although the initial perturbation around a circular contour is assumed to be of low regularity, any later perturbation becomes real analytic, hence smooth.

Keywords— free boundary problem, stability of solutions, spectral decomposition, equal arclength parametrization, Muskat problem, Peskin problem, fluid structure interaction

# Contents

| 1 | Introduction                                     | 4  |
|---|--------------------------------------------------|----|
| 2 | Preliminary Work                                 | 7  |
| 3 | Statement of the Main Theorem                    | 10 |
| 4 | The Interfacial Fluid Velocity                   | 11 |
| 5 | Steady-State Solutions                           | 15 |
| 6 | The Principal Linear Operator for the θ Equation | 15 |
| 7 | Derivation of an a priori Estimate               | 23 |
| 8 | Estimating Ne                                    | 27 |
| 9 | Estimating U1                                    | 29 |
|   | 10 Estimating U≥2                                | 31 |
|   | 11 Estimating (U≥2)α                             | 42 |
|   | 12 Proof of the Main Theorem                     | 44 |
|   | 13 Uniqueness                                    | 50 |
|   | 14 Acknowledgements                              | 51 |

# <span id="page-3-0"></span>1 Introduction

### 1.1 Relevant Literature

In this work, we study well-posedness of a PDE system for the dynamics of a two-dimensional fluid bubble immersed in two-dimensional ambient fluid of the same viscosity that extends to infinity under the effect of surface tension. The two fluids are immiscible and incompressible and there is no interfacial jump in the fluid velocity. The fluids are driven internally by the Stokes equation and interact with one another via surface tension around their interface. From now on, we will refer to this system as a two-phase Stokes problem with surface tension. Stokes problems are sometimes called quasi-stationary approximations of the Navier-Stokes problem because the Stokes equation, which is blind to inertial effects due to fluid motion, is being employed to describe the motion of slow yet non-stationary fluids.

The Navier-Stokes problem with surface tension has attracted mathematicians' attention since the 1980s, starting with the one-phase problem in which an isolated liquid is driven by capillary forces acting on its boundary. The one-phase problem was pioneered in a series of papers by Solonnikov [\[1](#page-50-1)[–7\]](#page-50-2) and by Mogilevskii and Solonnikov [\[8\]](#page-50-3), in which short-time existence for arbitrary data and long-time existence for small data were established in H¨older and anisotropic Sobolev-Slobodetskii spaces. Since then, well-posedness for the one-phase problem has been established in a multitude of settings, such as the case in which the fluid domain is either bounded, a perturbed infinite layer, or a perturbed half-space [\[9](#page-50-4)[–11\]](#page-50-5); and the case in which an infinite viscous incompressible fluid layer is bounded below and above by a solid surface and a free surface, respectively, experiencing surface tension and gravity [\[12](#page-50-6)[–16\]](#page-50-7).

The two-phase problem gained traction in the 1990s. The first well-posedness results were established by Denisova [\[17](#page-50-8), [18](#page-50-9)] and Denisova and Solonnikov [\[19](#page-50-10), [20](#page-50-11)]. Since then, well-posedness for the two-phase problem has been established in a number of settings, such as the case in which the system is driven by thermo-capillary convection in bounded domains [\[21\]](#page-51-0); and the case in which the free boundary is given as the graph of a function on a hyperplane [\[22](#page-51-1)[–24](#page-51-2)], sometimes with gravity [\[22,](#page-51-1) [24\]](#page-51-2).

As for the quasi-stationary approximation of the Navier-Stokes problem, the first well-posedness results for one-phase Stokes flow were established by G¨unther and Prokert [\[25\]](#page-51-3) and Prokert [\[26\]](#page-51-4). A handful of results concerning the regularity of solutions exist. Escher and Prokert [\[27](#page-51-5)] obtained joint spatial and temporal analyticity of the moving boundary for one-phase Stokes flow with surface tension. G¨unther and Prokert [\[25](#page-51-3)] proved short-time existence and uniqueness of a solution for one-phase Stokes flow with a free boundary driven by surface tension in Sobolev spaces of sufficiently high order. Friedman and Reitich [\[28](#page-51-6)] proved joint analyticity of solution for three-dimensional one-phase Stokes flow.

In this work, instantaneous analyticity is established for the unique global-in-time solution of the twophase Stokes flow. One of the distinguishing aspects of this work is the analytical framework used to establish well-posedness of the two-phase Stokes problem with surface tension. A large number of aforementioned studies make use of the so-called direct mapping method, where the original physically motivated free boundary problem is transformed into an abstract PDE problem on a fixed manifold.

### 1.2 Connections to Muskat and Peskin Problems

In oil fields, water is sometimes injected as an emulsifier to reduce the viscosity of crude oil to facilitate its extraction. As our two-phase Stokes problem is driven by surface tension and characterized by a low Reynolds number, it can serve as a rudimentary model to study the behavior of an oil droplet inside water. However, the Muskat model is a more refined and established model in this setting [\[29,](#page-51-7) [30\]](#page-51-8).

Having its roots in petrochemical engineering, the Muskat model is a PDE system describing the dynamics of incompressible fluids of different nature (e.g., oil and water) permeating porous media (e.g., tar sands) under gravity. The fluids' motions are governed by a momentum equation called Darcy's law.

Also closely related to our system is the Peskin model, which is a fluid-structure interaction (FSI) model describing the dynamics of a one-dimensional closed elastic string immersed in two-dimensional Stokes fluid. Originally, it emerged as a model for blood flow through heart valves [\[31](#page-51-9)]. Being one of the simplest FSI models, it has since been used for other kinds of physical modelling and for building numerical algorithms.

Both the Muskat and Peskin problems have interesting connections to our two-phase Stokes problem with surface tension, which will be explained in depth in Sections [1.2.1](#page-4-0) and [1.2.2.](#page-4-1)

#### <span id="page-4-0"></span>1.2.1 Spectral Decomposition of Linearized Operator

Recently, there has been a flurry of mathematical activity on the Muskat model studying its well-posedness. During this process, a multitude of techniques have been devised and employed. Of particular interest to our Stokes problem is spectral decomposition of the linearized operator, which has been applied by Gancedo, García-Juárez, Patel, and Strain to establish global regularity of a two-dimensional Muskat bubble which is unstable under gravity [29]. This technique has also been employed to show global-in-time well-posedness of the Peskin model [32]. The main idea behind this technique is to linearize the dynamics equation of interest around a steady state solution, which separates the equation into a linear part, which in principle is Fourier analytically a well-behaved operator, and the remainder part, which is "small" in some appropriate sense that depends on a clever selection of the solution space. This linearization is valid only for a small neighborhood around the steady state. For example, the dynamics equation considered by Gancedo, García-Juárez, Patel, and Strain is written in the form

<span id="page-4-2"></span>
$$\partial_t g + (-\Delta)^{1/2} g = \mathfrak{R},\tag{1.1}$$

where  $\Re$  denotes the part of the equation consisting of terms that are superlinear in g. We note that the principal linear part,  $(-\Delta)^{1/2}g$ , is the Hilbert transform acting on the spatial derivative of g. In the Fourier space, this equation becomes

<span id="page-4-3"></span>
$$\partial_t \hat{g}(k) = -|k| \, \hat{g}(k) + \hat{\Re}(k),$$

which clearly reveals that the principal linear part is diagonalized. This explains why the technique is often called spectral decomposition of the linearized operator.

The family of Banach spaces used by Gancedo, García-Juárez, Patel, and Strain that witness the remainder part  $\Re$  to be "small" are

$$\dot{\mathcal{F}}_{\nu(t)}^{s,1} = \left\{ f : \mathbb{T} \to \mathbb{R} \mid \sum_{k \neq 0} e^{\nu(t)|k|} |k|^s \left| \hat{f}(k) \right| < \infty \right\}, \tag{1.2}$$

where  $\nu(t) = \frac{t}{1+t}\nu_0$  for some  $\nu_0 > 0$ . The first superscript,  $s \ge 0$ , measures the regularity of functions in the space. The second superscript, 1, is simply to indicate that the  $l^1$  norm is taken with respect to the wave number k.

Given a sufficiently small initial datum of low regularity describing the initial perturbation of the interface from a circle, which is a steady-state solution, we used spectral decomposition of the linearized operator to establish global-in-time existence and uniqueness of a two-dimensional bubble that satisfies the initial datum and our Stokes problem. The dynamics equation for our Stokes problem is written in the form (1.1), as in the Muskat model studied by Gancedo, García-Juárez, Patel, and Strain. The Peskin model, which bears much similarity with ours, can also be written in that form [31].

The time-dependent exponential weight in the norm associated with (1.2) leads to the remarkable property that even though the initial perturbation from a circle is of low regularity, it becomes instantaneously analytic.

#### <span id="page-4-1"></span>1.2.2 Parametrization

The mathematical formulation of the Peskin model is similar to that of ours. However, unlike our model, the Peskin model is driven by the elasticity of the string, which obeys the following general law of elasticity:

<span id="page-4-4"></span>
$$\partial_{\theta} \left( T(|\partial_{\theta} \mathbf{X}|) \cdot \frac{\partial_{\theta} \mathbf{X}}{|\partial_{\theta} \mathbf{X}|} \right) \cdot |\partial_{\theta} \mathbf{X}|^{-1} . \tag{1.3}$$

If we let  $T(\alpha) = \alpha$ , then this law reduces to Hooke's law, which is commonly adopted for the analytical study of well-posedness for the Peskin problem. This difference in the mathematical nature of the driving force begets an important analytical consequence.

In the Peskin model, the closed elastic string is parametrized using the Lagrangian coordinate. As the elastic force is critically dependent on this parametrization of the string, it is impossible to choose an arbitrary parametrization to aid in the analysis without fundamentally altering the physical system. This is a major point of difference for the Peskin model from both the Muskat model and our PDE model. In the Muskat model, the normal velocity at the free boundary is well-defined, while the tangential velocity is ill-defined. As the dynamics of the boundary are completely determined by the normal velocity, one can take advantage of the degree of freedom "in the tangential direction" and choose a parametrization that yields nicely to one's analytical framework. In our PDE model, the sole force driving the system is surface tension, which depends exclusively on the geometry of the interface. Therefore, one can employ a convenient parametrization for the interface without affecting its actual dynamics.

To prove our results, we deploy a particular parametrization [\[33](#page-51-11)] of the fluids' interface that yields nicely to spectral decomposition of the linearized operator. This parametrization is unusual in the sense that the boundary of the fluid bubble is parametrized by the direction of its tangent vector and the length of the boundary. We adopt a certain frame in this parametrization that gives way to our analytical framework, in which the tangent vector is independent of the spatial variable and depends only on time. The same parametrization and change of frame had also been used for a Muskat problem [\[29](#page-51-7)].

Originally, this particular frame emerged out of a strictly numerical context. Hou, Lowengrub, and Shelley devised it to improve numerical simulation of the motion of the free boundary driven by surface tension between two-dimensional, irrotational, incompressible fluids. Using their novel numerical scheme in which the tangent vector's lack of dependence on the spatial variable removed numerical stiffness, they computed flows that had been unobtainable, such as the motion of the Hele-Shaw interface moving under the competing effects of gravity and surface tension, and discovered new singularity formations, such as the roll-up and collision of vortex sheets with surface tension in two-dimensional Euler flow.

It is possible to cast our Stokes problem as a Peskin model whose force satisfies the general law of elasticity in [\(1.3\)](#page-4-4) with T (α) = 1. The most general setting in which well-posedness has been established for the Peskin problem is when T (α) > 0 and T ′ (α) > 0, which means that our Stokes problem corresponds to a degenerate case for which no well-posedness results are available. This suggests that none of the techniques that have been successful in establishing well-posedness of the Peskin model can be used for our Stokes problem, which sheds some light on the strength of our analytical framework.

#### 1.2.3 Problem Formulation

Let Γ be a time-dependent simple closed curve in R 2 that represents the interface between two immiscible fluids. Then the model is given by

$$\mu \Delta \boldsymbol{u} - \nabla p = \boldsymbol{0} \quad \text{on } \mathbb{R}^2 \setminus \Gamma, \tag{1.4}$$

$$\nabla \cdot \boldsymbol{u} = 0 \quad \text{on } \mathbb{R}^2 \setminus \Gamma, \tag{1.5}$$

<span id="page-5-1"></span><span id="page-5-0"></span>
$$[\boldsymbol{u}] = \boldsymbol{0},\tag{1.6}$$

$$[\Sigma(\boldsymbol{u}, p)\boldsymbol{n}] = -\gamma \kappa \boldsymbol{n},\tag{1.7}$$

where u and p denote the fluid velocity and the fluid pressure, respectively; µ is the fluid viscosity, which is a constant within each fluid but may differ across the two fluids; Σ(u, p) represents the stress tensor for a Newtonian fluid of viscosity µ; n is the outward-pointing unit normal vector to the interface Γ; γ is the surface tension coefficient which is a constant; κ is the signed curvature of the interface; and the notation [·] denotes the value of the variable · on the boundary as approached from the interior fluid in the normal direction minus the value on the boundary as approached from the exterior fluid in the normal direction. We assume that the two fluids share the same viscosity µ, which we normalize to 1.

In words, this model says that the interior and exterior fluids are incompressible Stokes fluids with no interfacial jump in the fluid velocity and that they are driven by a stress imbalance along the interface given by −γκn. The observation that the interfacial force depends exclusively on the geometry of the interface via curvature κ is important, because it allows us to introduce a convenient parametrization for the interface without affecting the physical dynamics of the system.

In this model, there are two unknown variables to solve for: the two-dimensional fluid velocity u and the scalar pressure p. In this work, we study well-posedness of this model in terms of the fluid velocity by imposing on the fluid velocity a single-layer potential satisfying the specified model. Using this ansatz reduces the original problem to that of well-posedness for the PDE system for the interface dynamics. The latter is summarized in the main theorem of this work in Section [3.](#page-9-0) Throughout this work, we may suppress certain expressions' dependence on time t for readability.

## <span id="page-6-0"></span>2 Preliminary Work

#### 2.1 Key Function Spaces

For any  $2\pi$ -periodic function f, its Fourier coefficient is defined as

$$\mathcal{F}(f)(k) = \frac{1}{2\pi} \int_{-\pi}^{\pi} f(\alpha) e^{-ik\alpha} d\alpha.$$

We may sometimes write  $\hat{f}(k)$  to denote the Fourier coefficient of f with no intended difference in meaning. We use families of Banach spaces  $\mathcal{F}^{0,1}_{\nu}$  and  $\dot{\mathcal{F}}^{s,1}_{\nu}$ ,  $s \geq 0$ , equipped respectively with norms

$$||f||_{\mathcal{F}_{\nu}^{0,1}} = \sum_{k \in \mathbb{Z}} e^{\nu(t)|k|} |\hat{f}(k)|,$$

$$||f||_{\dot{\mathcal{F}}_{\nu}^{s,1}} = \sum_{k \neq 0} e^{\nu(t)|k|} |k|^{s} |\hat{f}(k)|,$$

where

<span id="page-6-3"></span><span id="page-6-1"></span>
$$\nu(t) = \frac{t}{1+t}\nu_0. \tag{2.1}$$

Observe that if  $\nu_0 > 0$ , then  $0 < \nu'(t) \le \nu_0$ . We also use Banach spaces  $\mathcal{F}^{0,1}$  and  $\dot{\mathcal{F}}^{s,1}$ ,  $s \ge 0$ , equipped respectively with norms

$$||f||_{\mathcal{F}^{0,1}} = \sum_{k \in \mathbb{Z}} |\hat{f}(k)|, \qquad (2.2)$$

$$||f||_{\dot{\mathcal{F}}^{s,1}} = \sum_{k \neq 0} |k|^s |\hat{f}(k)|.$$

The space  $\mathcal{F}^{0,1}$  equipped with the norm in (2.2) is the classical Wiener algebra, i.e., the space of absolutely convergent Fourier series.

<span id="page-6-4"></span>**Proposition 1.** (Embeddings.) For  $0 < s_1 \le s_2$ ,

$$||f||_{\dot{\mathcal{F}}^{s_1,1}_{\nu}} \le ||f||_{\dot{\mathcal{F}}^{s_2,1}_{\nu}}.$$

<span id="page-6-2"></span>**Proposition 2.** (Estimates.) Let n > 1. Then

$$||f_1 f_2 \cdots f_n||_{\mathcal{F}^{0,1}} \le \prod_{k=1}^n ||f_k||_{\mathcal{F}^{0,1}}.$$

For s > 0,

$$||f_1 f_2 \cdots f_n||_{\dot{\mathcal{F}}_{\nu}^{s,1}} \le b(n,s) \sum_{j=1}^n ||f_j||_{\dot{\mathcal{F}}_{\nu}^{s,1}} \prod_{k=1,k\neq j}^n ||f_k||_{\mathcal{F}_{\nu}^{0,1}},$$

where

$$b(n,s) = \begin{cases} 1 & 0 \le s \le 1, \\ n^{s-1} & s > 1. \end{cases}$$

Moreover,

$$||f_1 f_2||_{\dot{\mathcal{F}}_{o}^{0,1}} \le ||f_1||_{\dot{\mathcal{F}}_{o}^{0,1}} ||f_2||_{\mathcal{F}_{o}^{0,1}} + ||f_1||_{\mathcal{F}_{o}^{0,1}} ||f_2||_{\dot{\mathcal{F}}_{o}^{0,1}}.$$

*Remark.* The first two estimates in Proposition 2 hold with  $\mathcal{F}_{\nu}^{0,1}$  and  $\dot{\mathcal{F}}_{\nu}^{s,1}$  replaced by  $\mathcal{F}^{0,1}$  and  $\dot{\mathcal{F}}^{s,1}$ , respectively. For proof of Proposition 2, see Lemma 5.1 of [29].

For the following frequently used operator

$$\mathcal{M}(f)(\alpha) = \int_0^\alpha f(\eta)d\eta - \frac{\alpha}{2\pi} \int_{-\pi}^{\pi} f(\eta)d\eta, \tag{2.3}$$

we note that

<span id="page-7-4"></span>
$$\mathcal{F}(\mathcal{M}(f))(k) = \begin{cases} -\frac{i}{k}\hat{f}(k) & k \neq 0\\ \sum_{j\neq 0}\frac{i}{j}\hat{f}(j) & k = 0. \end{cases}$$
 (2.4)

For  $N \geq 0$ , we define high frequency cut-off operators  $\mathcal{J}_N$  and  $\mathcal{J}_N^1$  as

<span id="page-7-7"></span><span id="page-7-5"></span>
$$\mathcal{F}(\mathcal{J}_N f)(k) = 1_{|k| < N} \mathcal{F}(f)(k), \tag{2.5}$$

<span id="page-7-6"></span>
$$\mathcal{F}(\mathcal{J}_N^1 f)(k) = 1_{|k| \neq 1} 1_{|k| \leq N} \mathcal{F}(f)(k). \tag{2.6}$$

#### 2.2 Boundary Integral Formulation

For the fluid velocity, let us adopt the single-layer potential

$$u_j(\boldsymbol{x}) = \frac{1}{4\pi} \int_{\Gamma} \sum_{i=1}^{2} (-\gamma \kappa(s) \boldsymbol{n}(s))_i G_{ij}(\boldsymbol{x} - \boldsymbol{y}(s)) ds, \quad \boldsymbol{x} \in \mathbb{R}^2,$$
(2.7)

where  $\boldsymbol{u}(\boldsymbol{x}) = (u_1(\boldsymbol{x}), u_2(\boldsymbol{x}))$  and  $G = (G_{ij})$  given by

<span id="page-7-2"></span>
$$G_{ij}(\boldsymbol{w}) = -\delta_{ij} \log |\boldsymbol{w}| + \frac{w_i w_j}{|\boldsymbol{w}|^2}$$

is the Green's function for two-dimensional unbounded incompressible Stokes flow [34]. The fluid velocity in our model does not suffer from the Stokes' paradox because the force density  $-\gamma \kappa n$  along the interface integrates to 0. The single-layer potential ensures that the fluid velocity satisfies equations (1.4) through (1.7).

#### 2.3 Interface Parametrization

We note that the interface's shape is determined entirely by its normal velocity; the tangential velocity can only alter the frame of parametrization. This means that the tangential velocity can be entered into the equations without affecting the interface's shape. We first parametrize the interface  $z(\alpha,t)$ , where  $\alpha \in [-\pi,\pi)$ . Let us define a tangential angle variable  $\theta$  by writing the tangent vector  $z_{\alpha}(\alpha,t)$  in complex variable notation

<span id="page-7-0"></span>
$$z_{\alpha}(\alpha, t) = |z_{\alpha}(\alpha, t)| e^{i(\alpha + \theta(\alpha, t))}. \tag{2.8}$$

We can write

$$z_t(\alpha, t) = -U(\alpha, t)\boldsymbol{n}(\alpha, t) + T(\alpha, t)\boldsymbol{\tau}(\alpha, t), \tag{2.9}$$

which in complex variable notation becomes

$$z_t(\alpha, t) = U(\alpha, t)ie^{i(\alpha + \theta(\alpha, t))} + T(\alpha, t)e^{i(\alpha + \theta(\alpha, t))}, \tag{2.10}$$

keeping in mind that in complex variable notation

<span id="page-7-3"></span><span id="page-7-1"></span>
$$\boldsymbol{\tau}(\alpha, t) = e^{i(\alpha + \theta(\alpha, t))},$$

$$\boldsymbol{n}(\alpha, t) = -ie^{i(\alpha + \theta(\alpha, t))}.$$

After differentiating [\(2.8\)](#page-7-0) with respect to t and then differentiating [\(2.10\)](#page-7-1) with respect to α, we equate their real and imaginary parts to derive evolution equations for the interface in terms of θ and |zα(α, t)|:

$$|z_{\alpha}(\alpha,t)|_{t} = -U(\alpha,t) - U(\alpha,t)\theta_{\alpha}(\alpha,t) + T_{\alpha}(\alpha,t), \tag{2.11}$$

$$\theta_t(\alpha, t) = \frac{1}{|z_{\alpha}(\alpha, t)|} \left( U_{\alpha}(\alpha, t) + T(\alpha, t) + T(\alpha, t) \theta_{\alpha}(\alpha, t) \right). \tag{2.12}$$

A particularly useful frame of parametrization can be chosen by requiring that the tangential speed T (α, t) be of the form

<span id="page-8-6"></span>
$$T(\alpha, t) = \int_0^{\alpha} (1 + \theta_{\eta}(\eta, t)) U(\eta, t) d\eta - \frac{\alpha}{2\pi} \int_{-\pi}^{\pi} (1 + \theta_{\eta}(\eta, t)) U(\eta, t) d\eta + T(0, t), \tag{2.13}$$

where T (0, t) is a number that depends on t, which allows for a frame change. This frame of parametrization ensures that |zα(α, t)| is independent of α, i.e.,

<span id="page-8-1"></span><span id="page-8-0"></span>
$$|z_{\alpha}(\alpha,t)| = \frac{1}{2\pi} \int_{-\pi}^{\pi} |z_{\alpha}(\eta,t)| d\eta = \frac{L(t)}{2\pi},$$

where L(t) is the length of the interface at time t. Using this tangential speed formula, [\(2.11\)](#page-8-0) and [\(2.12\)](#page-8-1) can be rewritten as

<span id="page-8-5"></span><span id="page-8-2"></span>
$$L_t(t) = -\int_{-\pi}^{\pi} (1 + \theta_{\alpha}(\alpha))U(\alpha)d\alpha$$
 (2.14)

$$\theta_t(\alpha, t) = \frac{2\pi}{L(t)} U_\alpha(\alpha) + \frac{2\pi}{L(t)} T(\alpha) (1 + \theta_\alpha(\alpha)). \tag{2.15}$$

The use of this particular frame of parametrization for a fluid interface was pioneered by [\[33\]](#page-51-11) in the context of removing numerical stiffness in implementing interfacial flows with surface tension. From now on, we will refer to it as Hou-Lowengrub-Shelley (HLS) parametrization.

### 2.4 The Interface Length L(t)

We can derive an analytical expression for L(t) from the incompressibility of the internal fluid. In fact, this analytical expression and [\(2.14\)](#page-8-2) are equivalent provided that L(t) > 0 for all time t. This fact follows from the proposition below, whose proof can be garnered from [\[29](#page-51-7)].

Proposition 3. Let V<sup>0</sup> = πR<sup>2</sup> be the initial volume of the internal fluid. For any t ≥ 0 such that L(t) > 0,

$$\left(\frac{L(t)}{2\pi}\right)^{2} = R^{2} \left(1 + \frac{1}{2\pi} Im \int_{-\pi}^{\pi} \int_{0}^{\alpha} e^{i(\alpha - \eta)} \sum_{n \ge 1} \frac{i^{n}}{n!} (\theta(\alpha) - \theta(\eta))^{n} d\eta d\alpha\right)^{-1}$$
(2.16)

implies

<span id="page-8-4"></span><span id="page-8-3"></span>
$$L_t(t) = -\int_{-\pi}^{\pi} (1 + \theta_{\alpha}(\alpha)) U(\alpha) d\alpha.$$

Remark. That V<sup>0</sup> = πR<sup>2</sup> is not to say that the internal fluid is initially a circle of radius R.

To derive [\(2.16\)](#page-8-3) from the incompressibility condition on the internal fluid, let D be the region enclosed by the fluid boundary Γ. Then the volume of the region D is given by

$$V = \int_{\mathcal{D}} dx \wedge dy = \frac{1}{2} \int_{-\pi}^{\pi} (-z_2(\alpha), z_1(\alpha)) \cdot z_{\alpha}(\alpha) d\alpha, \qquad (2.17)$$

where ∧ in [\(2.17\)](#page-8-4) is the wedge product of differential forms. In complex variable notation,

$$V = \frac{1}{2} \int_{-\pi}^{\pi} \operatorname{Im} \left( \overline{z(\alpha)} z_{\alpha}(\alpha) \right) d\alpha = \frac{1}{2} \operatorname{Im} \int_{-\pi}^{\pi} \overline{z(\alpha)} z_{\alpha}(\alpha) d\alpha.$$

Using that

$$\begin{split} z_{\alpha}(\alpha) &= \frac{L(t)}{2\pi} e^{i(\alpha + \theta(\alpha))} \\ z(\alpha) &= z(0) + \int_{0}^{\alpha} z_{\eta}(\eta) d\eta, \end{split}$$

we can write

$$V = \pi \left(\frac{L(t)}{2\pi}\right)^2 \left(1 + \frac{1}{2\pi} \operatorname{Im} \int_{-\pi}^{\pi} \int_{0}^{\alpha} e^{i(\alpha - \eta)} \sum_{n=1}^{\infty} \frac{i^n}{n!} (\theta(\alpha) - \theta(\eta))^n d\eta d\alpha\right).$$

Since the internal fluid is incompressible,  $V_0 = \pi R^2 = V$ , which implies

$$\left(\frac{L(t)}{2\pi}\right)^2 = R^2 \bigg(1 + \frac{1}{2\pi} \mathrm{Im} \int_{-\pi}^{\pi} \int_{0}^{\alpha} e^{i(\alpha - \eta)} \sum_{n=1}^{\infty} \frac{i^n}{n!} (\theta(\alpha) - \theta(\eta))^n d\eta d\alpha \bigg)^{-1}.$$

Remark. The interior fluid's incompressibility combined with the isoperimetric inequality ensures that L(t) > 0 is satisfied for all  $t \ge 0$ .

#### 2.5 The Circular Interface under HLS Parametrization

<span id="page-9-1"></span>The proposition below characterizes the circular interface under HLS parametrization.

**Proposition 4.** Let R > 0. The interface at time t is a circle of radius R if and only if

$$(\theta(\alpha, t), L(t)) = (\hat{\theta}(0, t), 2\pi R),$$

where the parametrization is HLS.

*Proof.* First, we check that  $(\theta(\alpha, t), L(t)) = (\hat{\theta}(0, t), 2\pi R)$  is a circle of radius R for a fixed t. It suffices to show that the curve has a constant curvature  $\left|\frac{d^2z}{ds^2}\right|$  of 1/R. Observe that

$$\frac{d^2z}{ds^2} = \frac{d}{d\alpha} \left( \frac{dz}{d\alpha} \cdot \frac{d\alpha}{ds} \right) \frac{d\alpha}{ds} = \frac{d^2z}{d\alpha^2} \cdot |z_{\alpha}(\alpha, t)|^{-2} = \frac{ie^{i(\alpha + \hat{\theta}(0, t))}}{R}.$$

Since  $\hat{\theta}(0,t)$  is a real number,

$$\left| \frac{d^2z}{ds^2} \right| = \frac{1}{R},$$

as needed. To prove the converse, suppose that the interface at time t is a circle of radius R. Then  $L(t) = 2\pi R$ . That  $\left|\frac{d^2z}{ds^2}\right| = \frac{1}{R}$  implies that  $|1 + \theta_{\alpha}(\alpha, t)| = 1$ . Due to the periodicity of  $\theta$ , we have  $\theta_{\alpha}(\alpha, t) = 0$ , i.e.,  $\theta(\alpha, t)$  depends only on time t. Then  $\hat{\theta}(0, t) = \theta(\alpha, t)$ , as needed.

### <span id="page-9-0"></span>3 Statement of the Main Theorem

To study the simple two-dimensional model given by (1.4) through (1.7), we have adopted the single-layer potential form (2.7) for the fluid velocity. To completely describe the dynamics of the fluid velocity, it is therefore sufficient to study the dynamics of the interface itself. To that end, we have taken the HLS parametrization of the interface to obtain a pair of dynamics equations, (2.14) and (2.15), for the interface. We have then reformulated the dynamics equation (2.14) for the length of the interface into (2.16).

The main theorem of our work is that the equations (2.16) and (2.15) for the dynamics of the interface have a unique solution that is global in time, provided that the initial datum is sufficiently small as measured by the norm of  $\dot{\mathcal{F}}^{1,1}$ . The unique solution also decays exponentially in time in the norm of  $\dot{\mathcal{F}}^{1,1}_{\nu}$ , where  $\nu$  is given in (2.1) and  $\nu_0 > 0$  is dependent on the initial datum. In view of Proposition 4, this implies that the initial interface decays exponentially to a circular shape.

<span id="page-10-1"></span>**Theorem 5.** Fix  $\gamma > 0$ . If the initial datum  $\theta^0 \in \dot{\mathcal{F}}^{1,1}$  such that  $|\mathcal{F}(\theta^0)(0)|$  and  $||\theta^0||_{\dot{\mathcal{F}}^{1,1}}$  are sufficiently small, then for any  $T \in (0,\infty)$  there exists a unique solution

$$\theta(\alpha, t) \in C([0, T]; \dot{\mathcal{F}}_{\nu}^{1, 1}) \cap L^{1}([0, T]; \dot{\mathcal{F}}_{\nu}^{2, 1})$$

to the equations (2.16) and (2.15), where  $\nu$  is given in (2.1) and  $\nu_0 > 0$  is dependent on  $\theta^0$ . The solution becomes instantaneously analytic. In particular, for any  $t \in [0,T]$ 

$$\|\theta(t)\|_{\dot{\mathcal{F}}_{\nu}^{1,1}} + \left(\Lambda(\|\theta^{0}\|_{\dot{\mathcal{F}}^{1,1}}) - \nu_{0}\right) \int_{0}^{t} \|\theta(\tau)\|_{\dot{\mathcal{F}}_{\nu}^{2,1}} d\tau \leq \|\theta^{0}\|_{\dot{\mathcal{F}}^{1,1}},$$

where  $\Lambda(\|\theta^0\|_{\dot{\pi}^{1,1}})$  is given in (12.8). Moreover,  $\|\theta(t)\|_{\dot{\mathcal{F}}^{1,1}}$  decays exponentially in time.

Remark. The assumption that the initial datum be "sufficiently small" can be made explicit in the sense that for any  $\gamma > 0$ , one can explicitly derive an upper bound on the magnitudes of  $|\mathcal{F}(\theta^0)(0)|$  and  $||\theta^0||_{\dot{\mathcal{F}}^{1,1}}$ .

### <span id="page-10-0"></span>4 The Interfacial Fluid Velocity

### 4.1 Formulation in Complex Variable Notation

We set out to rewrite (2.7) in complex variable notation. The signed curvature  $\kappa$  that appears in the single-layer potential is defined by, in vector notation,

$$\tau'(s) = -\kappa(s)\boldsymbol{n}(s),$$

where s denotes arclength parametrization. Letting  $\tau = (\tau_1, \tau_2)$  and  $z = (z_1, z_2)$ , we use the Jacobian between arclength parametrization and HLS parametrization to obtain

$$\tau_i'(s) = \frac{d\tau_i}{ds} = \frac{d}{ds} \left(\frac{dz_i}{ds}\right) = \frac{d}{d\beta} \left(\frac{dz_i}{d\beta}\frac{d\beta}{ds}\right) \frac{d\beta}{ds} = \frac{d^2z_i}{d\beta^2} |z_\beta(\beta, t)|^{-2},$$

which yields, in vector notation,

$$u_j(\boldsymbol{x}) = \frac{2\pi}{L(t)} \frac{\gamma}{4\pi} \int_{-\pi}^{\pi} z''(\beta) \cdot G_{\cdot j}(\boldsymbol{x} - z(\beta)) d\beta,$$

where

$$G_{\cdot j}(x - z(\beta)) = (G_{1j}(x - z(\beta)), G_{2j}(x - z(\beta))).$$

Let  $\mathbf{x} = z(\alpha) \in \Gamma$ . To rewrite the current expression for  $u_j(\mathbf{x}) = u_j(z(\alpha))$  in complex variable notation, we note that in complex variable notation,

$$G_{.j}(z(\alpha) - z(\beta)) = G_{1j}(z(\alpha) - z(\beta)) + iG_{2j}(z(\alpha) - z(\beta)),$$
$$z'(\beta) = \frac{L(t)}{2\pi} e^{i(\beta + \theta(\beta))}.$$

We apply integration by parts to obtain

$$u_{j}(z(\alpha)) = -\frac{2\pi}{L(t)} \frac{\gamma}{4\pi} \int_{-\pi}^{\pi} \operatorname{Re}\left(\overline{z'(\beta)} \frac{d}{d\beta} \left(G_{\cdot j}(z(\alpha) - z(\beta))\right)\right) d\beta,$$

where  $\overline{z'(\beta)}$  denotes the complex conjugate of  $z'(\beta)$  and

$$\operatorname{Re}\left(\overline{z'(\beta)}\frac{d}{d\beta}\left(G_{\cdot j}(z(\alpha)-z(\beta))\right)\right) = \frac{L(t)}{2\pi}\left(\cos(\beta+\theta(\beta))\frac{d}{d\beta}\left(G_{1j}(z(\alpha)-z(\beta))\right)\right) + \sin(\beta+\theta(\beta))\frac{d}{d\beta}\left(G_{2j}(z(\alpha)-z(\beta))\right).$$

Hence.

$$u_{j}(z(\alpha)) = -\frac{\gamma}{4\pi} \int_{-\pi}^{\pi} \cos(\beta + \theta(\beta)) \frac{d}{d\beta} \left( G_{1j}(z(\alpha) - z(\beta)) \right) + \sin(\beta + \theta(\beta)) \frac{d}{d\beta} \left( G_{2j}(z(\alpha) - z(\beta)) \right) d\beta.$$

By changing the variable of integration from  $\beta$  to  $\beta' = \alpha - \beta$  and rewriting the sine and cosine in complex variable notation, we obtain

$$u_{j}(z(\alpha))$$

$$= \frac{\gamma}{4\pi} \int_{-\pi}^{\pi} \frac{1}{2} \left( e^{i(\alpha - \beta + \theta(\alpha - \beta))} + e^{-i(\alpha - \beta + \theta(\alpha - \beta))} \right)$$

$$\cdot \frac{d}{d\beta} \left( G_{1j}(z(\alpha) - z(\alpha - \beta)) \right)$$

$$+ \frac{1}{2i} \left( e^{i(\alpha - \beta + \theta(\alpha - \beta))} - e^{-i(\alpha - \beta + \theta(\alpha - \beta))} \right) \frac{d}{d\beta} \left( G_{2j}(z(\alpha) - z(\alpha - \beta)) \right) d\beta. \tag{4.2}$$

#### 4.2 The Normal Speed U

To obtain the normal speed in complex variable notation, we take the dot product of (2.9) and -n to get

<span id="page-11-1"></span><span id="page-11-0"></span>
$$U = \boldsymbol{u} \cdot (-\boldsymbol{n}),$$

which can be rewritten in complex variable notation as

$$U(\alpha) = \operatorname{Re}\left((u_1(\alpha) - iu_2(\alpha))ie^{i(\alpha + \theta(\alpha))}\right).$$

To obtain an analytical expression for  $U(\alpha)$  in complex variable notation, we first simplify (4.1) and (4.2). We note that

$$G_{11}(z(\alpha) - z(\alpha - \beta)) = -\log|z(\alpha) - z(\alpha - \beta)| + \frac{(z_1(\alpha) - z_1(\alpha - \beta))^2}{|z(\alpha) - z(\alpha - \beta)|^2},$$

$$G_{12}(z(\alpha) - z(\alpha - \beta)) = \frac{(z_1(\alpha) - z_1(\alpha - \beta))(z_2(\alpha) - z_2(\alpha - \beta))}{|z(\alpha) - z(\alpha - \beta)|^2},$$

$$G_{21}(z(\alpha) - z(\alpha - \beta)) = \frac{(z_1(\alpha) - z_1(\alpha - \beta))(z_2(\alpha) - z_2(\alpha - \beta))}{|z(\alpha) - z(\alpha - \beta)|^2},$$

$$G_{22}(z(\alpha) - z(\alpha - \beta)) = -\log|z(\alpha) - z(\alpha - \beta)| + \frac{(z_2(\alpha) - z_2(\alpha - \beta))^2}{|z(\alpha) - z(\alpha - \beta)|^2}.$$

Letting

$$w(\alpha, \beta) = \int_0^1 e^{i(\alpha + (s-1)\beta + \theta(\alpha + (s-1)\beta))} ds,$$

we can write

$$z(\alpha) - z(\alpha - \beta) = \beta \int_0^1 z_\alpha(\alpha + (s - 1)\beta) ds = \frac{\beta L(t)}{2\pi} w(\alpha, \beta).$$

Denoting the complex conjugate of w by  $\overline{w}$ , we then obtain

$$\frac{\partial}{\partial \beta} \left( -\log|z(\alpha) - z(\alpha - \beta)| \right) = -\frac{1}{\beta} - \frac{w_{\beta}}{2w} - \frac{\overline{w}_{\beta}}{2\overline{w}}.$$

Moreover,

$$\frac{\partial}{\partial \beta} \left( \frac{(z_1(\alpha) - z_1(\alpha - \beta))^2}{|z(\alpha) - z(\alpha - \beta)|^2} \right) \\
= \frac{1}{2} \cdot \left( \frac{1}{\overline{w}} + \frac{1}{w} \right) (w_\beta + \overline{w}_\beta) - \frac{1}{4} \cdot \left( \frac{1}{\overline{w}} + \frac{1}{w} \right)^2 (w_\beta \overline{w} + w \overline{w}_\beta).$$

Similarly,

$$\begin{split} & \frac{\partial}{\partial \beta} \left( \frac{(z_2(\alpha) - z_2(\alpha - \beta))^2}{|z(\alpha) - z(\alpha - \beta)|^2} \right) \\ & = -\frac{1}{2} \left( \frac{1}{\overline{w}} - \frac{1}{w} \right) (w_\beta - \overline{w}_\beta) + \frac{1}{4} \left( \frac{1}{\overline{w}} - \frac{1}{w} \right)^2 (w_\beta \overline{w} + w \overline{w}_\beta). \end{split}$$

Lastly,

$$\begin{split} &\frac{\partial}{\partial \beta} \left( \frac{(z_1(\alpha) - z_1(\alpha - \beta))(z_2(\alpha) - z_2(\alpha - \beta))}{|z(\alpha) - z(\alpha - \beta)|^2} \right) \\ = &\frac{1}{2i} \left( \frac{w_\beta}{\overline{w}} - \frac{\overline{w}_\beta}{w} \right) - \frac{1}{4i} \left( \frac{w}{\overline{w}} - \frac{\overline{w}}{w} \right) \left( \frac{w_\beta}{w} + \frac{\overline{w}_\beta}{\overline{w}} \right). \end{split}$$

Hence,

$$\frac{\partial}{\partial \beta} \left( G_{11}(z(\alpha) - z(\alpha - \beta)) \right) 
= -\frac{1}{\beta} - \frac{w_{\beta}}{2w} - \frac{\overline{w}_{\beta}}{2\overline{w}} + \frac{1}{2} \left( \frac{1}{\overline{w}} + \frac{1}{w} \right) (w_{\beta} + \overline{w}_{\beta}) - \frac{1}{4} \left( \frac{1}{\overline{w}} + \frac{1}{w} \right)^{2} (w_{\beta}\overline{w} + w\overline{w}_{\beta}), 
\frac{\partial}{\partial \beta} \left( G_{22}(z(\alpha) - z(\alpha - \beta)) \right) 
= -\frac{1}{\beta} - \frac{w_{\beta}}{2w} - \frac{\overline{w}_{\beta}}{2\overline{w}} - \frac{1}{2} \left( \frac{1}{\overline{w}} - \frac{1}{w} \right) (w_{\beta} - \overline{w}_{\beta}) + \frac{1}{4} \left( \frac{1}{\overline{w}} - \frac{1}{w} \right)^{2} (w_{\beta}\overline{w} + w\overline{w}_{\beta}),$$

and

$$\frac{\partial}{\partial \beta} \left( G_{12}(z(\alpha) - z(\alpha - \beta)) \right) = \frac{\partial}{\partial \beta} \left( G_{21}(z(\alpha) - z(\alpha - \beta)) \right)$$
$$= \frac{1}{2i} \left( \frac{w_{\beta}}{\overline{w}} - \frac{\overline{w}_{\beta}}{w} \right) - \frac{1}{4i} \left( \frac{w}{\overline{w}} - \frac{\overline{w}}{w} \right) \left( \frac{w_{\beta}}{w} + \frac{\overline{w}_{\beta}}{\overline{w}} \right).$$

For notational convenience, let us write

$$w = C_1 + L_1 + N_1,$$
  
 $w^{-1} = C_2 + L_2 + N_2,$   
 $w_{\beta} = C_{\beta} + L_{\beta} + N_{\beta},$ 

where  $C_1$ ,  $L_1$ , and  $N_1$  are the parts of w which are constant, linear, and superlinear in the variable  $\phi = \theta - \hat{\theta}(0)$ , respectively;  $C_2$ ,  $L_2$ , and  $N_2$  are the parts of  $w^{-1}$  which are constant, linear, and superlinear in  $\phi$ , respectively; lastly,  $C_{\beta}$ ,  $L_{\beta}$ , and  $N_{\beta}$  are the parts of  $w_{\beta}$  which are constant, linear, and superlinear in  $\phi$ . Similarly, let us write

$$\frac{\partial}{\partial \beta} \left( G_{11}(z(\alpha) - z(\alpha - \beta)) \right) = C_{11} + L_{11} + N_{11},$$

$$\frac{\partial}{\partial \beta} \left( G_{12}(z(\alpha) - z(\alpha - \beta)) \right) = \frac{\partial}{\partial \beta} \left( G_{21}(z(\alpha) - z(\alpha - \beta)) \right) = C_{12} + L_{12} + N_{12},$$

$$\frac{\partial}{\partial \beta} \left( G_{22}(z(\alpha) - z(\alpha - \beta)) \right) = C_{22} + L_{22} + N_{22},$$

where  $C_{11}$ ,  $L_{11}$ , and  $N_{11}$  are the parts of  $\frac{\partial}{\partial \beta} \left( G_{11}(z(\alpha) - z(\alpha - \beta)) \right)$  which are constant, linear, and superlinear in  $\phi$ ;  $C_{12}$ ,  $L_{12}$ , and  $N_{12}$  are the parts of  $\frac{\partial}{\partial \beta} \left( G_{12}(z(\alpha) - z(\alpha - \beta)) \right)$  which are constant, linear, and superlinear in  $\phi$ ; lastly,  $C_{22}$ ,  $L_{22}$ , and  $N_{22}$  are the parts of  $\frac{\partial}{\partial \beta} \left( G_{22}(z(\alpha) - z(\alpha - \beta)) \right)$  which are constant, linear, and superlinear in  $\phi$ . Using these expressions, we can write

$$u_{1}(z(\alpha)) - iu_{2}(z(\alpha))$$

$$= \frac{\gamma}{4\pi} \int_{-\pi}^{\pi} \frac{e^{i\hat{\theta}(0)}e^{i(\alpha-\beta)}}{2} \left(1 + i\phi(\alpha-\beta) + \sum_{n=2}^{\infty} \frac{(i\phi(\alpha-\beta))^{n}}{n!}\right)$$

$$\cdot \left( (C_{11} + L_{11} + N_{11}) - (C_{22} + L_{22} + N_{22}) - 2i(C_{12} + L_{12} + N_{12}) \right)$$

$$+ \frac{e^{-i\hat{\theta}(0)}e^{-i(\alpha-\beta)}}{2} \left(1 - i\phi(\alpha-\beta) + \sum_{n=2}^{\infty} \frac{(-i\phi(\alpha-\beta))^{n}}{n!}\right)$$

$$\cdot \left( (C_{11} + L_{11} + N_{11}) + (C_{22} + L_{22} + N_{22}) \right) d\beta.$$

$$(4.3)$$

Let

<span id="page-13-1"></span>
$$u_1(\alpha) - iu_2(\alpha) = \mathfrak{C}(\alpha) + \mathfrak{L}(\alpha) + \mathfrak{N}(\alpha),$$

where  $\mathfrak{C}$ ,  $\mathfrak{L}$ , and  $\mathfrak{N}$  are the parts of  $u_1 - iu_2$  which are constant, linear, and superlinear in  $\phi$ , respectively. In particular,  $\mathfrak{C}(\alpha) = 0$ . Let  $U = U_0 + U_1 + U_{\geq 2}$ , where  $U_0$ ,  $U_1$ , and  $U_{\geq 2}$  are the parts of U which are constant, linear, and superlinear in  $\phi$ , respectively. Then

<span id="page-13-3"></span><span id="page-13-2"></span><span id="page-13-0"></span>
$$U_0(\alpha) = \operatorname{Re}\left(ie^{i\alpha}e^{i\hat{\theta}(0)}\mathfrak{C}(\alpha)\right) = 0. \tag{4.4}$$

To find expressions for  $U_1$  and  $U_{\geq 2}$ , we first rewrite

$$U(\alpha) = \operatorname{Re}\left(ie^{i\alpha}e^{i\hat{\theta}(0)}\mathfrak{L}(\alpha)\right) + \operatorname{Re}\left(ie^{i\alpha}e^{i\hat{\theta}(0)}\left(\mathfrak{L}(\alpha)(e^{i\phi(\alpha)} - 1) + \mathfrak{N}(\alpha)e^{i\phi(\alpha)}\right)\right).$$

Then it is clear that

$$U_1(\alpha) = \operatorname{Re}\left(ie^{i\alpha}e^{i\hat{\theta}(0)}\mathfrak{L}(\alpha)\right),\tag{4.5}$$

$$U_{\geq 2}(\alpha) = \operatorname{Re}\left(ie^{i\alpha}e^{i\hat{\theta}(0)}\left(\mathfrak{L}(\alpha)(e^{i\phi(\alpha)} - 1) + \mathfrak{N}(\alpha)e^{i\phi(\alpha)}\right)\right). \tag{4.6}$$

#### 4.3 The Tangential Speed T

Let us rewrite the right hand side of (2.15) as

$$\frac{2\pi}{L(t)} \left( U_{\alpha}(\alpha) + T(\alpha)(1 + \phi_{\alpha}(\alpha)) \right) = \mathcal{C}(\alpha) + \mathcal{L}(\alpha) + \mathcal{N}(\alpha),$$

where C,  $\mathcal{L}$ , and  $\mathcal{N}$  are the parts of the right hand side of the evolution equation for  $\theta$  which are constant, linear, and superlinear in the variable  $\phi = \theta - \hat{\theta}(0)$ , respectively. We will completely determine the frame of parametrization by specifying the analytical expression for  $T(\alpha)$  such that C = 0. To begin, let us rewrite the right hand side of (2.13) as

$$\int_0^{\alpha} (1 + \phi_{\alpha}(\eta)) U(\eta) d\eta - \frac{\alpha}{2\pi} \int_{-\pi}^{\pi} (1 + \phi_{\alpha}(\eta)) U(\eta) d\eta + T(0)$$
  
=  $T_0(\alpha) + T_1(\alpha) + T_{\geq 2}(\alpha)$ ,

where T0, T1, and T≥<sup>2</sup> are the parts of T which are constant, linear, and superlinear in φ, respectively. We note that

<span id="page-14-2"></span>
$$T_{0}(\alpha) = \int_{0}^{\alpha} U_{0}(\eta) d\eta - \frac{\alpha}{2\pi} \int_{-\pi}^{\pi} U_{0}(\eta) d\eta + T(0) = T(0),$$

$$T_{1}(\alpha) = \int_{0}^{\alpha} U_{1}(\eta) d\eta + \int_{0}^{\alpha} \phi_{\alpha}(\eta) U_{0}(\eta) d\eta$$

$$- \frac{\alpha}{2\pi} \int_{-\pi}^{\pi} U_{1}(\eta) d\eta - \frac{\alpha}{2\pi} \int_{-\pi}^{\pi} \phi_{\alpha}(\eta) U_{0}(\eta) d\eta,$$

$$T_{\geq 2}(\alpha) = \int_{0}^{\alpha} U_{\geq 2}(\eta) d\eta + \int_{0}^{\alpha} \phi_{\alpha}(\eta) U_{\geq 1}(\eta) d\eta$$

$$- \frac{\alpha}{2\pi} \int_{-\pi}^{\pi} U_{\geq 2}(\eta) d\eta - \frac{\alpha}{2\pi} \int_{-\pi}^{\pi} \phi_{\alpha}(\eta) U_{\geq 1}(\eta) d\eta,$$

$$(4.7)$$

where we define U≥<sup>1</sup> = U<sup>1</sup> + U≥2. Let T (0) = 0. Then using [\(4.4\)](#page-13-0), we obtain

$$C(\alpha) = \frac{2\pi}{L(t)} \left( (U_0)_{\alpha}(\alpha) + T_0(\alpha) \right) = \frac{2\pi}{L(t)} T_0(\alpha) = \frac{2\pi}{L(t)} T(0) = 0.$$

## <span id="page-14-0"></span>5 Steady-State Solutions

We know from Proposition [4](#page-9-1) that (θ(α, t), L(t)) = (ˆθ(0, t), 2πR) corresponds to a circle of radius R. The circular interface becomes a solution to [\(2.14\)](#page-8-2) and [\(2.15\)](#page-8-5) if ˆθ(0, t) is constant in time. In this case, the interface is stationary. The following proposition summarizes the existence of steady-state solutions to [\(2.14\)](#page-8-2) and [\(2.15\)](#page-8-5).

Proposition 6. For any constant c, the circle defined by

$$(\theta(\alpha, t), L(t)) = (c, 2\pi R)$$

is a time-independent solution of [\(2.14\)](#page-8-2) and [\(2.15\)](#page-8-5) in which T (α, t) is given by [\(2.13\)](#page-8-6) and U(α, t) is given by

$$U(\alpha,t) = Re\left( (u_1(\alpha,t) - iu_2(\alpha,t))ie^{i(\alpha+\theta(\alpha,t))} \right)$$

with u1(α, t) − iu2(α, t) given by [\(4.3\)](#page-13-1).

Proof. Let (θ(α, t), L(t)) = (ˆθ(0, t), 2πR) be a circle of radius R such that ˆθ(0, t) = c for some constant c. Since U(α, t) = T (α, t) = 0, the right hand sides of [\(2.14\)](#page-8-2) and [\(2.15\)](#page-8-5) vanish. Since (θt(α, t), Lt(t)) = (0, 0), [\(2.14\)](#page-8-2) and [\(2.15\)](#page-8-5) are indeed satisfied by (θ(α, t), L(t)) = (c, 2πR).

# <span id="page-14-1"></span>6 The Principal Linear Operator for the θ Equation

Let us explicitly calculate the operator L. We note that

$$\mathcal{L}(\alpha) = \frac{2\pi}{L(t)} \left( (U_1)_{\alpha}(\alpha) + T_0(\alpha)\phi_{\alpha}(\alpha) + T_1(\alpha) \right) = \frac{2\pi}{L(t)} \left( (U_1)_{\alpha}(\alpha) + T_1(\alpha) \right)$$

by [\(4.7\)](#page-14-2). By [\(4.4\)](#page-13-0),

$$\begin{split} T_1(\alpha) &= \int_0^\alpha U_1(\eta) d\eta + \int_0^\alpha \phi_\alpha(\eta) U_0(\eta) d\eta \\ &- \frac{\alpha}{2\pi} \int_{-\pi}^\pi U_1(\eta) d\eta - \frac{\alpha}{2\pi} \int_{-\pi}^\pi \phi_\alpha(\eta) U_0(\eta) d\eta \\ &= \int_0^\alpha U_1(\eta) d\eta - \frac{\alpha}{2\pi} \int_{-\pi}^\pi U_1(\eta) d\eta. \end{split}$$

Using [\(2.3\)](#page-7-4), we can write

<span id="page-15-2"></span><span id="page-15-1"></span>
$$\mathcal{L}(\alpha) = \frac{2\pi}{L(t)} \left( (U_1)_{\alpha}(\alpha) + \mathcal{M}(U_1)(\alpha) \right). \tag{6.1}$$

### 6.1 The Fourier Modes of L

In this Section, we verify that L is the Hilbert transform acting on the spatial derivative of θ, up to the ±1 Fourier modes, by checking that its Fourier multiplier is |k| for |k| > 1. To that end, we will calculate F(L)(k), the kth Fourier mode of L(α), for all k ∈ Z \ {0}. Using [\(2.4\)](#page-7-5), we obtain that for k 6= 0,

<span id="page-15-0"></span>
$$\mathcal{F}(\mathcal{L})(k) = \frac{2\pi}{L(t)} \left( \mathcal{F}((U_1)_\alpha)(k) - \frac{i}{k} \mathcal{F}(U_1)(k) \right). \tag{6.2}$$

First, we set out to find the expressions for U<sup>1</sup> and (U1)α. From [\(4.5\)](#page-13-2), we obtain

$$U_1(\alpha) = \operatorname{Re}\left(ie^{i\alpha}e^{i\hat{\theta}(0)}\right)\operatorname{Re}\mathfrak{L}(\alpha) - \operatorname{Im}\left(ie^{i\alpha}e^{i\hat{\theta}(0)}\right)\operatorname{Im}\mathfrak{L}(\alpha).$$

We note that

$$U_{1}(\alpha) = \frac{\gamma}{4\pi} \int_{-\pi}^{\pi} \left( \int_{-\pi}^{\pi} \left( \frac{-i\beta s}{4\pi} \int_{-\pi}^{\pi} \left( \frac{-(-i+(i+\beta)e^{i\beta})(-1-2e^{i\beta}+e^{2i\beta})}{4(-1+e^{i\beta})^{2}} \right) \right) ds \cdot \frac{-(-i+(i+\beta)e^{i\beta})(-1-2e^{i\beta}+e^{2i\beta})}{4(-1+e^{i\beta})^{2}}$$

$$+ \int_{0}^{1} e^{i\beta s} \phi(\alpha+\beta(-1+s))ds \cdot \frac{e^{-i\beta}(-1+2e^{i\beta}+e^{2i\beta})(\beta+i(-1+e^{i\beta}))}{4(-1+e^{i\beta})^{2}}$$

$$+ \int_{0}^{1} e^{-i\beta s} (-1+s)\phi(\alpha+\beta(-1+s))ds \cdot \frac{-(-1+e^{i\beta})\beta(-1-2e^{i\beta}+e^{2i\beta})}{4(-1+e^{i\beta})^{2}}$$

$$+ \int_{0}^{1} e^{i\beta s} (-1+s)\phi(\alpha+\beta(-1+s))ds \cdot \frac{-(-1+e^{i\beta})i\beta(-1-2e^{i\beta}+e^{2i\beta})}{4(-1+e^{i\beta})^{2}}$$

$$+ \int_{0}^{1} e^{i\beta s} (-1+s)\phi'(\alpha+\beta(-1+s))ds \cdot \frac{e^{-i\beta}(-1+e^{i\beta})i\beta(-1+2e^{i\beta}+e^{2i\beta})}{4(-1+e^{i\beta})^{2}}$$

$$+ \phi(\alpha-\beta) \cdot \frac{e^{-i\beta}(-1+e^{i\beta})(-i)(1+e^{i\beta}+e^{2i\beta}+e^{3i\beta})}{4(-1+e^{i\beta})^{2}} d\beta.$$

$$(6.3)$$

We obtain the expression for (U1)<sup>α</sup> by differentiating [\(6.3\)](#page-15-0) with respect to α. Now, taking the Fourier modes of U<sup>1</sup> and (U1)<sup>α</sup> and plugging them into [\(6.2\)](#page-15-1), we obtain that for k /∈ {0, ±1},

$$\begin{split} \mathcal{F}(\mathcal{L})(k) &= \frac{2\pi}{L(t)} \frac{\gamma}{4\pi} \mathcal{F}(\phi)(k) \bigg( \\ &\int_{-\pi}^{\pi} \frac{(i - (i + \beta)e^{i\beta})(-1 - 2e^{i\beta} + e^{2i\beta})}{4(-1 + e^{i\beta})^2} \frac{e^{-i\beta} - e^{-i\beta k}}{\beta} d\beta \bigg( \frac{k}{k - 1} + \frac{1}{k(1 - k)} \bigg) \\ &+ \int_{-\pi}^{\pi} \frac{e^{-i\beta}(-1 + 2e^{i\beta} + e^{2i\beta})(\beta + i(-1 + e^{i\beta}))}{4(-1 + e^{i\beta})^2} \frac{e^{i\beta} - e^{-i\beta k}}{\beta} d\beta \bigg( \frac{k}{1 + k} - \frac{1}{k(1 + k)} \bigg) \\ &+ \int_{-\pi}^{\pi} \frac{-i(-1 - 2e^{i\beta} + e^{2i\beta})}{4(-1 + e^{i\beta})} \frac{e^{-i\beta(1 + k)}(e^{i\beta k} - e^{i\beta})}{\beta} d\beta \bigg( \frac{-k^2}{(-1 + k)^2} + \frac{1}{(-1 + k)^2} \bigg) \\ &+ \int_{-\pi}^{\pi} \frac{-i(-1 - 2e^{i\beta} + e^{2i\beta})e^{-i\beta k}}{4(-1 + e^{i\beta})} d\beta \bigg( \frac{ik^2}{-1 + k} - \frac{i}{-1 + k} \bigg) \\ &+ \int_{-\pi}^{\pi} \frac{e^{-i\beta}i(-1 + 2e^{i\beta} + e^{2i\beta})}{4(-1 + e^{i\beta})} \frac{e^{-i\beta k}(-1 + e^{i\beta(1 + k)})}{\beta} d\beta \bigg( \frac{-k^2}{(1 + k)^2} + \frac{1}{(1 + k)^2} \bigg) \end{split}$$

$$\begin{split} &+ \int_{-\pi}^{\pi} \frac{e^{-i\beta}(-1 + 2e^{i\beta} + e^{2i\beta})e^{-i\beta k}}{4(-1 + e^{i\beta})} d\beta \left(\frac{-k^2}{1 + k} + \frac{1}{1 + k}\right) \\ &+ \int_{-\pi}^{\pi} \frac{1 + 2e^{i\beta} - e^{2i\beta}}{4(-1 + e^{i\beta})} \frac{e^{-i\beta(1 + k)}(e^{i\beta k} - e^{i\beta})}{\beta} d\beta \left(\frac{ik}{(-1 + k)^2} - \frac{i}{k(-1 + k)^2}\right) \\ &+ \int_{-\pi}^{\pi} \frac{(1 + 2e^{i\beta} - e^{2i\beta})e^{-i\beta k}}{4(-1 + e^{i\beta})} d\beta \left(\frac{k}{-1 + k} - \frac{1}{k(-1 + k)}\right) \\ &+ \int_{-\pi}^{\pi} \frac{-e^{-i\beta}(-1 + 2e^{i\beta} + e^{2i\beta})}{4(-1 + e^{i\beta})} \frac{e^{-i\beta k}(-1 + e^{i\beta(1 + k)})}{\beta} d\beta \left(\frac{ik}{(1 + k)^2} - \frac{i}{k(1 + k)^2}\right) \\ &+ \int_{-\pi}^{\pi} \frac{-e^{-i\beta}(-1 + 2e^{i\beta} + e^{2i\beta})e^{-i\beta k}}{4(-1 + e^{i\beta})} d\beta \left(\frac{k}{1 + k} - \frac{1}{k(1 + k)}\right) \\ &+ \int_{-\pi}^{\pi} \frac{-e^{-i\beta}i(1 + e^{i\beta} + e^{2i\beta} + e^{3i\beta})e^{-ik\beta}}{4(-1 + e^{i\beta})} d\beta \left(ik - \frac{i}{k}\right). \end{split}$$

For k /∈ {0, ±1}, we define

<span id="page-16-0"></span>
$$J_{1}(k) = \int_{-\pi}^{\pi} \frac{(i - (i + \beta)e^{i\beta})(-1 - 2e^{i\beta} + e^{2i\beta})}{4(-1 + e^{i\beta})^{2}} e^{-i\beta} - e^{-i\beta k} d\beta \left(\frac{k}{k - 1} + \frac{1}{k(1 - k)}\right)$$

$$+ \int_{-\pi}^{\pi} \frac{e^{-i\beta}(-1 + 2e^{i\beta} + e^{2i\beta})(\beta + i(-1 + e^{i\beta}))}{4(-1 + e^{i\beta})^{2}} \frac{e^{i\beta} - e^{-i\beta k}}{\beta} d\beta$$

$$\cdot \left(\frac{k}{1 + k} - \frac{1}{k(1 + k)}\right)$$

$$+ \int_{-\pi}^{\pi} \frac{-i(-1 - 2e^{i\beta} + e^{2i\beta})}{4(-1 + e^{i\beta})} \frac{e^{-i\beta(1 + k)}(e^{i\beta k} - e^{i\beta})}{\beta} d\beta$$

$$\cdot \left(\frac{-k^{2}}{(-1 + k)^{2}} + \frac{1}{(-1 + k)^{2}}\right)$$

$$+ \int_{-\pi}^{\pi} \frac{-i(-1 - 2e^{i\beta} + e^{2i\beta})e^{-i\beta k}}{4(-1 + e^{i\beta})} d\beta \left(\frac{ik^{2}}{-1 + k} - \frac{i}{-1 + k}\right)$$

$$+ \int_{-\pi}^{\pi} \frac{e^{-i\beta}(-1 + 2e^{i\beta} + e^{2i\beta})e^{-i\beta k}}{4(-1 + e^{i\beta})} d\beta \left(\frac{-k^{2}}{1 + k} + \frac{1}{1 + k}\right)$$

$$+ \int_{-\pi}^{\pi} \frac{e^{-i\beta}(-1 + 2e^{i\beta} + e^{2i\beta})e^{-i\beta k}}{4(-1 + e^{i\beta})} d\beta \left(\frac{-k^{2}}{1 + k} + \frac{1}{1 + k}\right)$$

$$+ \int_{-\pi}^{\pi} \frac{1 + 2e^{i\beta} - e^{2i\beta}}{4(-1 + e^{i\beta})} \frac{e^{-i\beta(1 + k)}(e^{i\beta k} - e^{i\beta})}{\beta} d\beta \left(\frac{ik}{(-1 + k)^{2}} - \frac{i}{k(-1 + k)^{2}}\right)$$

$$+ \int_{-\pi}^{\pi} \frac{(1 + 2e^{i\beta} - e^{2i\beta})e^{-i\beta k}}{4(-1 + e^{i\beta})} d\beta \left(\frac{k}{-1 + k} - \frac{1}{k(-1 + k)}\right)$$

$$+ \int_{-\pi}^{\pi} \frac{e^{-i\beta}(-1 + 2e^{i\beta} + e^{2i\beta})}{4(-1 + e^{i\beta})} e^{-i\beta k}(-1 + e^{i\beta(1 + k)})$$

$$\beta$$

$$\cdot \left(\frac{ik}{(1 + k)^{2}} - \frac{i}{k(1 + k)^{2}}\right)$$

$$+ \int_{-\pi}^{\pi} \frac{e^{-i\beta}(-1 + 2e^{i\beta} + e^{2i\beta})e^{-i\beta k}}{4(-1 + e^{i\beta})} d\beta \left(\frac{k}{1 + k} - \frac{1}{k(1 + k)}\right)$$

and

$$J_2(k) = \int_{-\pi}^{\pi} \frac{-e^{-i\beta}i(1 + e^{i\beta} + e^{2i\beta} + e^{3i\beta})e^{-ik\beta}}{4(-1 + e^{i\beta})}d\beta \left(ik - \frac{i}{k}\right).$$

Then for |k| > 1 we can write the kth Fourier mode of L as

<span id="page-17-3"></span><span id="page-17-0"></span>
$$\mathcal{F}(\mathcal{L})(k) = \frac{2\pi}{L(t)} \frac{\gamma}{4\pi} \mathcal{F}(\phi)(k) \left( J_1(k) + J_2(k) \right). \tag{6.5}$$

Since [\(6.1\)](#page-15-2) is real, for k ∈ Z +,

$$\mathcal{F}(\mathcal{L})(-k) = \frac{1}{2\pi} \int_{-\pi}^{\pi} \mathcal{L}(\alpha) e^{ik\alpha} d\alpha = \frac{1}{2\pi} \int_{-\pi}^{\pi} \mathcal{L}(\alpha) e^{-ik\alpha} d\alpha = \overline{\mathcal{F}(\mathcal{L})(k)}.$$
 (6.6)

Hence, it suffices to compute F(L)(k) only for k > 1.

#### <span id="page-17-2"></span>6.1.1 Computing J2(k)

For J2(k), it suffices to calculate the integral

$$ik \int_{-\pi}^{\pi} \frac{-e^{-i\beta}i(1+e^{i\beta}+e^{2i\beta}+e^{3i\beta})e^{-ik\beta}}{4(-1+e^{i\beta})} d\beta.$$

Using that

$$\frac{1}{-1 + re^{i\beta}} = -\frac{1}{1 - re^{i\beta}} = -\sum_{n=0}^{\infty} (re^{i\beta})^n,$$

we obtain

$$ik \int_{-\pi}^{\pi} \frac{-e^{-i\beta}i(1 + e^{i\beta} + e^{2i\beta} + e^{3i\beta})e^{-ik\beta}}{4(-1 + e^{i\beta})} d\beta$$

$$= -\frac{k}{4} \lim_{\epsilon \to 0^{+}} \lim_{r \to 1^{-}} \sum_{n=0}^{\infty} r^{n} \int_{\substack{[-\pi,\pi] \\ (-\epsilon,\epsilon)}} e^{-i\beta(k+1)} (1 + e^{i\beta} + e^{2i\beta} + e^{3i\beta})e^{i\beta n} d\beta.$$

To calculate the outer integral, we note that

$$\int_{-\pi}^{\pi} e^{-i\beta(k+1)} (1 + e^{i\beta} + e^{2i\beta} + e^{3i\beta}) e^{i\beta n} d\beta = \begin{cases} 0 & \text{if } n \notin \{k+1, k, k-1, k-2\}, \\ 2\pi & \text{otherwise.} \end{cases}$$

A similar calculation shows that

$$-\frac{k}{4} \lim_{\epsilon \to 0^+} \lim_{r \to 1^-} \sum_{n=0}^{\infty} r^n \int_{\epsilon}^{-\epsilon} e^{-i\beta(k+1)} (1 + e^{i\beta} + e^{2i\beta} + e^{3i\beta}) e^{i\beta n} d\beta = k\pi.$$

Therefore,

<span id="page-17-1"></span>
$$J_2(k) = \begin{cases} \pi \left( k - \frac{1}{k} \right) & \text{if } k < -1, \\ -\pi \left( k - \frac{1}{k} \right) & \text{if } k > 1. \end{cases}$$

$$(6.7)$$

#### <span id="page-18-1"></span>6.1.2 Computing $J_1(k)$

In view of (6.6), we assume that k > 1. In this Section, we adopt the notational convention that any summation  $\sum$  in which the upper bound is strictly less than the lower bound is defined to be 0. For example, if k = 2, then (6.9) vanishes. To begin, we simplify the first two integrals in (6.4). The first integral can be written as

$$\begin{split} & \int_{-\pi}^{\pi} \frac{(i - (i + \beta)e^{i\beta})(-1 - 2e^{i\beta} + e^{2i\beta})}{4(-1 + e^{i\beta})^2} \frac{e^{-i\beta} - e^{-i\beta k}}{\beta} d\beta \\ &= \int_{-\pi}^{\pi} \frac{-i(-1 - 2e^{i\beta} + e^{2i\beta})}{4(-1 + e^{i\beta})} \frac{e^{-i\beta} - e^{-i\beta k}}{\beta} d\beta \\ &+ \int_{-\pi}^{\pi} \frac{-\beta e^{i\beta}(-1 - 2e^{i\beta} + e^{2i\beta})}{4(-1 + e^{i\beta})^2} \frac{e^{-i\beta} - e^{-i\beta k}}{\beta} d\beta, \end{split}$$

while the second integral can be written as

$$\begin{split} & \int_{-\pi}^{\pi} \frac{e^{-i\beta}(-1 + 2e^{i\beta} + e^{2i\beta})(\beta + i(-1 + e^{i\beta}))}{4(-1 + e^{i\beta})^2} \frac{e^{i\beta} - e^{-i\beta k}}{\beta} d\beta \\ &= \int_{-\pi}^{\pi} \frac{e^{-i\beta}(-1 + 2e^{i\beta} + e^{2i\beta})\beta}{4(-1 + e^{i\beta})^2} \frac{e^{i\beta} - e^{-i\beta k}}{\beta} d\beta \\ &+ \int_{-\pi}^{\pi} \frac{(-1 + 2e^{i\beta} + e^{2i\beta})i}{4(-1 + e^{i\beta})} \frac{1 - e^{-i\beta(k+1)}}{\beta} d\beta. \end{split}$$

For ease of notation, let us define

$$g_{2}(k) = \int_{-\pi}^{\pi} \frac{-\beta e^{i\beta}(-1 - 2e^{i\beta} + e^{2i\beta})}{4(-1 + e^{i\beta})^{2}} \frac{e^{-i\beta} - e^{-i\beta k}}{\beta} d\beta,$$

$$g_{3}(k) = \int_{-\pi}^{\pi} \frac{e^{-i\beta}(-1 + 2e^{i\beta} + e^{2i\beta})\beta}{4(-1 + e^{i\beta})^{2}} \frac{e^{i\beta} - e^{-i\beta k}}{\beta} d\beta,$$

$$g_{5}(k) = \int_{-\pi}^{\pi} \frac{-i(-1 - 2e^{i\beta} + e^{2i\beta})e^{-i\beta k}}{4(-1 + e^{i\beta})} d\beta,$$

$$g_{6}(k) = \int_{-\pi}^{\pi} \frac{e^{-i\beta}(-1 + 2e^{i\beta} + e^{2i\beta})e^{-i\beta k}}{4(-1 + e^{i\beta})} d\beta,$$

$$g_{7}(k) = \int_{-\pi}^{\pi} \frac{(1 + 2e^{i\beta} - e^{2i\beta})e^{-i\beta k}}{4(-1 + e^{i\beta})} d\beta,$$

$$g_{8}(k) = \int_{-\pi}^{\pi} \frac{-e^{-i\beta}(-1 + 2e^{i\beta} + e^{2i\beta})e^{-i\beta k}}{4(-1 + e^{i\beta})} d\beta.$$

Then we can rewrite

$$J_1(k) = \frac{k+1}{k} g_2(k) + \frac{k-1}{k} g_3(k) + i(k+1)g_5(k) + (1-k)g_6(k) + \frac{k+1}{k} g_7(k) + \frac{k-1}{k} g_8(k).$$

$$(6.8)$$

Let us first compute  $g_2(k)$ . Using that

<span id="page-18-0"></span>
$$1 - e^{-i\beta(k-1)} = i\beta(k-1) \int_0^1 e^{-i\beta(k-1)s} ds$$
$$\frac{1}{(-1 + re^{i\beta})^2} = \sum_{n=0}^\infty (1+n)(re^{i\beta})^n,$$

we obtain

$$\begin{split} g_2(k) = & \frac{i(k-1)}{4} \\ & \cdot \lim_{\epsilon \to 0^+} \lim_{r \to 1^-} \sum_{n=0}^{\infty} (1+n) r^n \int_0^1 \int_{\substack{[-\pi,\pi] \\ (-\epsilon,\epsilon)}} (1+2e^{i\beta} - e^{2i\beta}) \beta e^{-i\beta(k-1)s} e^{i\beta n} d\beta ds. \end{split}$$

To simplify this expression, we first calculate the integral

$$\begin{split} &\int_{-\pi}^{\pi} (1 + 2e^{i\beta} - e^{2i\beta})\beta e^{-i\beta(k-1)s} e^{i\beta n} d\beta \\ = &\frac{e^{-i\pi(n+s(1-k))}}{(n+s(1-k))^2} \bigg( -1 - i\pi(n+s(1-k)) \bigg) \\ &+ \frac{e^{i\pi(n+s(1-k))}}{(n+s(1-k))^2} \bigg( 1 - i\pi(n+s(1-k)) \bigg) \\ &+ \frac{2e^{-i\pi(1+n+s(1-k))}}{(1+n+s(1-k))^2} \bigg( -1 - i\pi(1+n+s(1-k)) \bigg) \\ &+ \frac{2e^{i\pi(1+n+s(1-k))}}{(1+n+s(1-k))^2} \bigg( 1 - i\pi(1+n+s(1-k)) \bigg) \\ &+ \frac{e^{-i\pi(2+n+s(1-k))}}{(2+n+s(1-k))^2} \bigg( 1 + i\pi(2+n+s(1-k)) \bigg) \\ &+ \frac{e^{i\pi(2+n+s(1-k))}}{(2+n+s(1-k))^2} \bigg( -1 + i\pi(2+n+s(1-k)) \bigg). \end{split}$$

For t ∈ {1, 2}, we note that

$$\int_{0}^{1} \frac{e^{i\pi(n+s(1-k))}}{(n+s(1-k))^{2}} (1-i\pi(n+s(1-k))) ds = \frac{1}{k-1} \int_{n-(k-1)}^{n} \frac{e^{i\pi s}(1-i\pi s)}{s^{2}} ds,$$

$$\int_{0}^{1} \frac{e^{i\pi(t+n+s(1-k))}}{(t+n+s(1-k))^{2}} (1-i\pi(t+n+s(1-k))) ds$$

$$= \frac{1}{k-1} \int_{t+n-(k-1)}^{t+n} \frac{e^{i\pi s}(1-i\pi s)}{s^{2}} ds.$$

Then

<span id="page-19-1"></span><span id="page-19-0"></span>
$$\frac{i(k-1)}{4} \sum_{n=0}^{\infty} (1+n)r^n \int_{-\pi}^{1} \int_{-\pi}^{\pi} (1+2e^{i\beta} - e^{2i\beta})\beta e^{-i\beta(k-1)s} e^{i\beta n} d\beta ds$$

$$= \frac{1}{4} \left( \sum_{n=0}^{k-1} (1+n)r^n \int_{-\pi}^{\pi} e^{i\beta n} (1-e^{-i\beta(k-1)}) d\beta \right)$$

$$+ \sum_{n=0}^{k-2} (1+n)r^n \int_{-\pi}^{\pi} 2e^{i\beta} e^{i\beta n} (1-e^{-i\beta(k-1)}) d\beta$$

$$+ \sum_{n=0}^{k-3} (1+n)r^n \int_{-\pi}^{\pi} -e^{2i\beta} e^{i\beta n} (1-e^{-i\beta(k-1)}) d\beta$$

$$+ \frac{1}{4} \left( \sum_{n=k}^{\infty} (1+n)r^n \int_{-\infty}^{\infty} i \left( \frac{e^{i\pi s} (1-i\pi s)}{s^2} - \frac{e^{-i\pi s} (1+i\pi s)}{s^2} \right) \right)$$

$$\cdot 1_{[n-(k-1),n]}(s) ds$$
(6.10)

<span id="page-20-1"></span><span id="page-20-0"></span>
$$+\sum_{n=k-1}^{\infty} (1+n)r^{n} \cdot 2 \int_{-\infty}^{\infty} i \left( \frac{e^{i\pi s}(1-i\pi s)}{s^{2}} - \frac{e^{-i\pi s}(1+i\pi s)}{s^{2}} \right)$$

$$\cdot 1_{[1+n-(k-1),1+n]}(s)ds$$

$$+\sum_{n=k-2}^{\infty} (1+n)r^{n}(-1)$$

$$\cdot \int_{-\infty}^{\infty} i \left( \frac{e^{i\pi s}(1-i\pi s)}{s^{2}} - \frac{e^{-i\pi s}(1+i\pi s)}{s^{2}} \right) 1_{[2+n-(k-1),2+n]}(s)ds \right).$$
(6.11)

We will further simplify the terms in (6.10), (6.11), and (6.12). The term in (6.10) becomes

$$\int_{-\infty}^{\infty} i \left( \frac{e^{i\pi s} (1 - i\pi s)}{s^2} - \frac{e^{-i\pi s} (1 + i\pi s)}{s^2} \right) \sum_{n=k}^{\infty} (1 + n) r^n 1_{[n-(k-1),n]}(s) ds$$

$$= \sum_{j=1}^{k-2} \int_{j}^{1+j} i \left( \frac{e^{i\pi s} (1 - i\pi s)}{s^2} - \frac{e^{-i\pi s} (1 + i\pi s)}{s^2} \right) \sum_{n=k}^{k+j-1} (1 + n) r^n ds$$

$$+ \sum_{j=1}^{\infty} \int_{k+j-2}^{k+j-1} i \left( \frac{e^{i\pi s} (1 - i\pi s)}{s^2} - \frac{e^{-i\pi s} (1 + i\pi s)}{s^2} \right) \sum_{n=k+(j-1)}^{2k-2+(j-1)} (1 + n) r^n ds.$$

Next, the term in (6.11) becomes

$$2\int_{-\infty}^{\infty} i \left( \frac{e^{i\pi s} (1 - i\pi s)}{s^2} - \frac{e^{-i\pi s} (1 + i\pi s)}{s^2} \right) \sum_{n=k-1}^{\infty} (1 + n) r^n 1_{[1+n-(k-1),1+n]}(s) ds$$

$$= \sum_{j=1}^{k-2} 2 \int_{j}^{1+j} i \left( \frac{e^{i\pi s} (1 - i\pi s)}{s^2} - \frac{e^{-i\pi s} (1 + i\pi s)}{s^2} \right) \sum_{n=k-1}^{k+j-2} (1 + n) r^n ds$$

$$+ 2 \sum_{j=1}^{\infty} \int_{k+j-2}^{k+j-1} i \left( \frac{e^{i\pi s} (1 - i\pi s)}{s^2} - \frac{e^{-i\pi s} (1 + i\pi s)}{s^2} \right) \sum_{n=k-1+(j-1)}^{2k-3+(j-1)} (1 + n) r^n ds.$$

Lastly, the term in (6.12) becomes

$$-\int_{-\infty}^{\infty} i \left( \frac{e^{i\pi s} (1 - i\pi s)}{s^2} - \frac{e^{-i\pi s} (1 + i\pi s)}{s^2} \right) \sum_{n=k-2}^{\infty} (1 + n) r^n 1_{[2+n-(k-1),2+n]}(s) ds$$

$$= -\sum_{j=1}^{k-2} \int_{j}^{1+j} i \left( \frac{e^{i\pi s} (1 - i\pi s)}{s^2} - \frac{e^{-i\pi s} (1 + i\pi s)}{s^2} \right) \sum_{n=k-2}^{k+j-3} (1 + n) r^n ds$$

$$-\sum_{j=1}^{\infty} \int_{k+j-2}^{k+j-1} i \left( \frac{e^{i\pi s} (1 - i\pi s)}{s^2} - \frac{e^{-i\pi s} (1 + i\pi s)}{s^2} \right) \sum_{n=k-2+(j-1)}^{2k-4+(j-1)} (1 + n) r^n ds.$$

Using that

$$\begin{split} &\frac{1}{4} \bigg( \sum_{n=0}^{k-1} (1+n) \int_{-\pi}^{\pi} e^{i\beta n} (1-e^{-i\beta(k-1)}) d\beta \\ &+ \sum_{n=0}^{k-2} (1+n) \int_{-\pi}^{\pi} 2e^{i\beta} e^{i\beta n} (1-e^{-i\beta(k-1)}) d\beta \\ &+ \sum_{n=0}^{k-3} (1+n) \int_{-\pi}^{\pi} -e^{2i\beta} e^{i\beta n} (1-e^{-i\beta(k-1)}) d\beta \bigg) = \frac{\pi}{2} - \pi k, \end{split}$$

we obtain

$$\begin{split} &\lim_{\epsilon \to 0^+} \lim_{r \to 1^-} \frac{i(k-1)}{4} \sum_{n=0}^{\infty} (1+n) r^n \int_0^1 \int_{-\pi}^{\pi} (1+2e^{i\beta}-e^{2i\beta}) \beta e^{-i\beta(k-1)s} e^{i\beta n} d\beta ds \\ &= \frac{1}{4} \bigg( (2k+1) \sum_{j=1}^{k-2} j \int_j^{1+j} i \bigg( \frac{e^{i\pi s} (1-i\pi s)}{s^2} - \frac{e^{-i\pi s} (1+i\pi s)}{s^2} \bigg) ds \\ &+ \sum_{j=1}^{k-2} j^2 \int_j^{1+j} i \bigg( \frac{e^{i\pi s} (1-i\pi s)}{s^2} - \frac{e^{-i\pi s} (1+i\pi s)}{s^2} \bigg) ds \\ &+ (-1+k) (-2+3k) \sum_{j=1}^{\infty} \int_{k+j-2}^{k+j-1} i \bigg( \frac{e^{i\pi s} (1-i\pi s)}{s^2} - \frac{e^{-i\pi s} (1+i\pi s)}{s^2} \bigg) ds \\ &+ 2 (-1+k) \sum_{j=1}^{\infty} j \int_{k+j-2}^{k+j-1} i \bigg( \frac{e^{i\pi s} (1-i\pi s)}{s^2} - \frac{e^{-i\pi s} (1+i\pi s)}{s^2} \bigg) ds \bigg) \\ &+ \frac{\pi}{2} - \pi k. \end{split}$$

Using similar calculations, we obtain

$$\lim_{\epsilon \to 0^+} \lim_{r \to 1^-} \frac{i(k-1)}{4} \sum_{n=0}^{\infty} (1+n)r^n \int_0^1 \int_{\epsilon}^{-\epsilon} (1+2e^{i\beta} - e^{2i\beta})\beta e^{-i\beta(k-1)s} e^{i\beta n} d\beta ds$$

$$= \frac{\pi}{2}(k-1).$$

Therefore,

$$g_{2}(k) = -\frac{\pi}{2}k + \frac{1}{4}\left((2k+1)\sum_{j=1}^{k-2}j\int_{j}^{1+j}i\left(\frac{e^{i\pi s}(1-i\pi s)}{s^{2}} - \frac{e^{-i\pi s}(1+i\pi s)}{s^{2}}\right)ds + \sum_{j=1}^{k-2}j^{2}\int_{j}^{1+j}i\left(\frac{e^{i\pi s}(1-i\pi s)}{s^{2}} - \frac{e^{-i\pi s}(1+i\pi s)}{s^{2}}\right)ds + (-1+k)(-2+3k)\sum_{j=1}^{\infty}\int_{k+j-2}^{k+j-1}i\left(\frac{e^{i\pi s}(1-i\pi s)}{s^{2}} - \frac{e^{-i\pi s}(1+i\pi s)}{s^{2}}\right)ds + 2(-1+k)\sum_{j=1}^{\infty}j\int_{k+j-2}^{k+j-1}i\left(\frac{e^{i\pi s}(1-i\pi s)}{s^{2}} - \frac{e^{-i\pi s}(1+i\pi s)}{s^{2}}\right)ds\right).$$

To simplify the expression for  $g_2(k)$ , we note that for  $j \neq \{-1, 0\}$ ,

$$\int_{j}^{j+1} i \left( \frac{e^{i\pi s} (1 - i\pi s)}{s^{2}} - \frac{e^{-i\pi s} (1 + i\pi s)}{s^{2}} \right) ds = 0.$$

Then  $g_2(k) = -\frac{\pi}{2}k$ . Similarly, we can calculate that

$$g_3(k) = -\frac{\pi}{2}k, \quad g_5(k) = -\frac{i\pi}{2}, \quad g_6(k) = -\frac{\pi}{2}, \quad g_7(k) = -\frac{\pi}{2}, \quad g_8(k) = \frac{\pi}{2}$$

Plugging these values into (6.8), we obtain

<span id="page-21-0"></span>
$$J_1(k) = -\frac{\pi}{l_0}$$

Using (6.6) and (6.7), we deduce that

$$J_1(k) = \begin{cases} -\frac{\pi}{k} & k > 1, \\ \frac{\pi}{k} & k < -1. \end{cases}$$
 (6.13)

### 6.2 Summary

Plugging the results of Sections [6.1.1](#page-17-2) and [6.1.2](#page-18-1) into [\(6.5\)](#page-17-3), we obtain that for k > 1,

$$\mathcal{F}(\mathcal{L})(k) = -\frac{2\pi}{L(t)} \frac{\gamma}{4\pi} \mathcal{F}(\phi)(k) \pi k = -\frac{2\pi}{L(t)} \frac{\gamma}{4\pi} \mathcal{F}(\phi)(k) \pi |k|.$$

Since for k > 1

$$\mathcal{F}(\mathcal{L})(-k) = \overline{\mathcal{F}(\mathcal{L})(k)} = -\frac{2\pi}{L(t)} \frac{\gamma}{4\pi} \overline{\mathcal{F}(\phi)(k)} \pi k = -\frac{2\pi}{L(t)} \frac{\gamma}{4\pi} \mathcal{F}(\phi)(-k) \pi \left| k \right|,$$

we conclude that for |k| > 1,

$$\mathcal{F}(\mathcal{L})(k) = -\frac{2\pi}{L(t)} \frac{\gamma}{4\pi} \mathcal{F}(\phi)(k)\pi |k|.$$

To calculate F(L)(k) for |k| = 1, we note that for k ∈ Z,

$$\mathcal{F}((U_1)_{\alpha})(k) = ik\mathcal{F}(U_1)(k).$$

Then [\(6.2\)](#page-15-1) can be written as

$$\mathcal{F}(\mathcal{L})(k) = \frac{2\pi}{L(t)} \left( ik \mathcal{F}(U_1)(k) - \frac{i}{k} \mathcal{F}(U_1)(k) \right),$$

where k 6= 0. Hence, F(L)(±1) = 0. This presents a technical challenge in dealing with the term in the evolution equation for θ that induces an exponential decay in time of the initial perturbation of the interface. This challenge can be resolved by observing that the identity

<span id="page-22-2"></span>
$$\int_{-\pi}^{\pi} z_{\alpha}(\alpha, t) d\alpha = 0 \tag{6.14}$$

provides a means to control the ±1 Fourier modes of L using the other nonzero Fourier modes.

# <span id="page-22-0"></span>7 Derivation of an a priori Estimate

Before embarking on the derivation of a key a priori estimate for φ = θ − ˆθ(0), we first derive tight bounds around L(t), which remains valid as long as kφ(t)kF0,<sup>1</sup> is sufficiently small for all t ≥ 0.

<span id="page-22-1"></span>Proposition 7. If kφ(t)kF0,<sup>1</sup> is sufficiently small for all t ≥ 0, then

$$\frac{R^2}{1 + \frac{\pi}{2} (e^{2\|\phi(t)\|_{\mathcal{F}^{0,1}}} - 1)} \le \left(\frac{L(t)}{2\pi}\right)^2 \le \frac{R^2}{1 - \frac{\pi}{2} (e^{2\|\phi(t)\|_{\mathcal{F}^{0,1}}} - 1)}.$$

Proof. Using integration by parts, we obtain

$$\mathcal{F}\left(\int_0^\alpha e^{-i\eta}(\phi(\alpha) - \phi(\eta))^n d\eta\right)(-1) = i\mathcal{F}((\phi(\pi) - \phi(\eta))^n)(1).$$

Then

$$\int_{-\pi}^{\pi} \int_{0}^{\alpha} e^{i(\alpha-\eta)} \sum_{n\geq 1} \frac{i^{n}}{n!} (\phi(\alpha) - \phi(\eta))^{n} d\eta d\alpha = 2\pi i \sum_{n\geq 1} \frac{i^{n}}{n!} \mathcal{F}((\phi(\pi) - \phi(\eta))^{n})(1).$$

Hence,

$$\operatorname{Im}\left(\int_{-\pi}^{\pi} \int_{0}^{\alpha} e^{i(\alpha-\eta)} \sum_{n\geq 1} \frac{i^{n}}{n!} (\phi(\alpha) - \phi(\eta))^{n} d\eta d\alpha\right)$$
$$= \pi \left(\sum_{n\geq 1} \frac{i^{n}}{n!} \mathcal{F}((\phi(\pi) - \phi(\eta))^{n})(1) + \sum_{n\geq 1} \frac{(-i)^{n}}{n!} \overline{\mathcal{F}((\phi(\pi) - \phi(\eta))^{n})(1)}\right).$$

It follows that

$$\left| \operatorname{Im} \left( \int_{-\pi}^{\pi} \int_{0}^{\alpha} e^{i(\alpha - \eta)} \sum_{n \ge 1} \frac{i^{n}}{n!} (\phi(\alpha) - \phi(\eta))^{n} d\eta d\alpha \right) \right| \le 2\pi \sum_{n \ge 1} \frac{\|(\phi(\pi) - \phi(\cdot))^{n}\|_{\mathcal{F}^{0,1}}}{n!}.$$

By Proposition 2,

$$\|(\phi(\pi) - \phi(\cdot))^n\|_{\mathcal{F}^{0,1}} \le \|\phi(\pi) - \phi(\cdot)\|_{\mathcal{F}^{0,1}}^n$$

Then

$$\left| \operatorname{Im} \left( \int_{-\pi}^{\pi} \int_{0}^{\alpha} e^{i(\alpha - \eta)} \sum_{n \geq 1} \frac{i^{n}}{n!} (\phi(\alpha) - \phi(\eta))^{n} d\eta d\alpha \right) \right| \leq 2\pi (e^{\phi(\pi)} e^{\|\phi\|_{\mathcal{F}^{0,1}}} - 1).$$

Since

$$|\phi(\pi)| \le \sum_{k \in \mathbb{Z}} |\hat{\phi}(k)| = ||\phi||_{\mathcal{F}^{0,1}},$$

we obtain

$$\left|\operatorname{Im} \left( \int_{-\pi}^{\pi} \int_{0}^{\alpha} e^{i(\alpha - \eta)} \sum_{n \geq 1} \frac{i^{n}}{n!} (\phi(\alpha) - \phi(\eta))^{n} d\eta d\alpha \right) \right| \leq \pi^{2} (e^{2\|\phi\|_{\mathcal{F}^{0,1}}} - 1).$$

This estimate shows that

$$\frac{R^2}{1 + \frac{\pi}{2}(e^{2\|\phi\|_{\mathcal{F}^{0,1}}} - 1)} \le \left(\frac{L(t)}{2\pi}\right)^2 \le \frac{R^2}{1 - \frac{\pi}{2}(e^{2\|\phi\|_{\mathcal{F}^{0,1}}} - 1)},$$

as needed.

Using Proposition 7, we can also prove the following useful estimate.

<span id="page-23-0"></span>**Proposition 8.** For sufficiently small  $\|\phi\|_{\mathcal{F}^{0,1}}$ ,

$$\left| R \frac{2\pi}{L(t)} - 1 \right| \le 1 - \sqrt{1 - \frac{\pi}{2} (e^{2\|\phi\|_{\mathcal{F}^{0,1}}} - 1)}.$$

*Proof.* From Proposition 7, we obtain

$$\sqrt{1-\frac{\pi}{2}(e^{2\|\phi\|_{\mathcal{F}^{0,1}}}-1)}-1 \leq \frac{2\pi R}{L(t)}-1 \leq \sqrt{1+\frac{\pi}{2}(e^{2\|\phi\|_{\mathcal{F}^{0,1}}}-1)}-1.$$

Then

$$\begin{split} \left| \frac{2\pi R}{L(t)} - 1 \right| &\leq \max \left\{ \left| \sqrt{1 - \frac{\pi}{2} (e^{2\|\phi\|_{\mathcal{F}^{0,1}}} - 1)} - 1 \right|, \left| \sqrt{1 + \frac{\pi}{2} (e^{2\|\phi\|_{\mathcal{F}^{0,1}}} - 1)} - 1 \right| \right\} \\ &= 1 - \sqrt{1 - \frac{\pi}{2} (e^{2\|\phi\|_{\mathcal{F}^{0,1}}} - 1)}, \end{split}$$

as needed.

Now, we derive a key a priori estimate for  $\phi$ . In Section 6, we have shown that

$$\mathcal{F}(\mathcal{L})(k) = \begin{cases} 0 & \text{if } |k| = 1, \\ \frac{2\pi}{L(t)} \frac{\gamma}{4\pi} \mathcal{F}(\phi)(k) (J_1(k) + J_2(k)) & \text{if } |k| > 1, \end{cases}$$

where  $J_1$  and  $J_2$  are given in (6.13) and (6.7). Let

$$\widetilde{\mathcal{L}}(\alpha) = \frac{L(t)}{2\pi} \mathcal{L}(\alpha), \quad \widetilde{\mathcal{N}}(\alpha) = \frac{L(t)}{2\pi} \mathcal{N}(\alpha).$$

Then for  $|k| \geq 1$ ,

$$\frac{\partial}{\partial t} \mathcal{F}(\phi)(k) = \begin{cases} \frac{2\pi}{L(t)} \mathcal{F}(\widetilde{\mathcal{N}})(k) & \text{if } |k| = 1, \\ \frac{2\pi}{L(t)} \frac{\gamma}{4\pi} \mathcal{F}(\phi)(k)(J_1(k) + J_2(k)) + \frac{2\pi}{L(t)} \mathcal{F}(\widetilde{\mathcal{N}})(k) & \text{if } |k| > 1. \end{cases}$$

For convenience of notation, define  $J_1(k) = J_2(k) = 0$  for |k| = 1 so that for  $k \in \mathbb{Z} \setminus \{0\}$ ,

$$\frac{\partial}{\partial t}\mathcal{F}(\phi)(k) = \frac{2\pi}{L(t)}\frac{\gamma}{4\pi}\mathcal{F}(\phi)(k)(J_1(k) + J_2(k)) + \frac{2\pi}{L(t)}\mathcal{F}(\widetilde{\mathcal{N}})(k). \tag{7.1}$$

We observe that the principal linear term has a time-dependent coefficient. This dependence occurs, however, only via L(t). We choose an initial circular interface of radius R to perturb around and make the principal linear term independent of time by replacing L(t) with  $2\pi R$  and keeping an error term. That is, we rewrite (7.1) as

$$\frac{\partial}{\partial t} \mathcal{F}(\phi)(k) = \frac{1}{R} \frac{\gamma}{4\pi} \mathcal{F}(\phi)(k) (J_1(k) + J_2(k)) + \frac{2\pi}{L(t)} \mathcal{F}(\widetilde{\mathcal{N}})(k) 
+ \frac{\gamma}{4\pi} \mathcal{F}(\phi)(k) (J_1(k) + J_2(k)) \left( -\frac{1}{R} + \frac{2\pi}{L(t)} \right).$$
(7.2)

We note that for k > 0,

<span id="page-24-1"></span><span id="page-24-0"></span>
$$\left|\hat{\phi}(-k)\right| = \left|\overline{\hat{\phi}(k)}\right| = \left|\hat{\phi}(k)\right| \tag{7.3}$$

since  $\phi$  is real-valued. Then for s > 0,

$$\|\phi\|_{\dot{\mathcal{F}}^{s,1}_{\nu}} = \sum_{k \neq 0} e^{\nu(t)|k|} |k|^{s} \left| \hat{\phi}(k) \right| = 2 \sum_{k \geq 1} e^{\nu(t)k} k^{s} \left| \hat{\phi}(k) \right|.$$

Differentiating this equation with respect to t, we obtain

$$\frac{d}{dt} \|\phi\|_{\dot{\mathcal{F}}^{s,1}_{\nu}} = 2 \sum_{k \geq 1} e^{\nu(t)k} \nu'(t) k^{s+1} \left| \hat{\phi}(k) \right| + 2 \sum_{k \geq 1} e^{\nu(t)k} k^{s} \frac{\hat{\phi}(k) \overline{\frac{\partial}{\partial t}} \hat{\phi}(k)}{2 \left| \hat{\phi}(k) \right|}.$$

Let us simplify the second term. Using (7.2) and that  $J_1$  and  $J_2$  are real for  $k \geq 1$ , we obtain

$$\hat{\phi}(k)\frac{\partial}{\partial t}\hat{\phi}(k) + \overline{\hat{\phi}(k)}\frac{\partial}{\partial t}\hat{\phi}(k)$$

$$= \frac{1}{R}\frac{\gamma}{4\pi}(J_1 + J_2)(k)\left|\hat{\phi}(k)\right|^2 + \frac{2\pi}{L(t)}\overline{\mathcal{F}(\widetilde{\mathcal{N}})(k)}\hat{\phi}(k)$$

$$+ \frac{\gamma}{4\pi}(J_1 + J_2)(k)\left(-\frac{1}{R} + \frac{2\pi}{L(t)}\right)\left|\hat{\phi}(k)\right|^2$$

$$+ \frac{1}{R}\frac{\gamma}{4\pi}(J_1 + J_2)(k)\left|\hat{\phi}(k)\right|^2 + \frac{2\pi}{L(t)}\mathcal{F}(\widetilde{\mathcal{N}})(k)\overline{\hat{\phi}(k)}$$

$$+ \frac{\gamma}{4\pi}(J_1 + J_2)(k)\left(-\frac{1}{R} + \frac{2\pi}{L(t)}\right)\left|\hat{\phi}(k)\right|^2.$$

Then

$$2\sum_{k\geq 1} e^{\nu(t)k} k^{s} \frac{\hat{\phi}(k) \frac{\partial}{\partial t} \hat{\phi}(k) + \hat{\phi}(k) \frac{\partial}{\partial t} \hat{\phi}(k)}{2 \left| \hat{\phi}(k) \right|}$$

$$= \frac{2}{R} \frac{\gamma}{4\pi} \sum_{k\geq 1} e^{\nu(t)k} k^{s} (J_{1} + J_{2})(k) \left| \hat{\phi}(k) \right|$$

$$+ \frac{2\pi}{L(t)} \sum_{k\geq 1} e^{\nu(t)k} k^{s} \frac{\mathcal{F}(\widetilde{\mathcal{N}})(k) \overline{\hat{\theta}(k)} + \overline{\mathcal{F}(\widetilde{\mathcal{N}})(k)} \hat{\phi}(k)}{\left| \hat{\phi}(k) \right|}$$

$$+ 2 \frac{\gamma}{4\pi} \left( -\frac{1}{R} + \frac{2\pi}{L(t)} \right) \sum_{k\geq 1} e^{\nu(t)k} k^{s} (J_{1} + J_{2})(k) \left| \hat{\phi}(k) \right|.$$

Therefore,

$$\frac{d}{dt} \|\phi\|_{\dot{\mathcal{F}}^{s,1}_{\nu}} = 2 \sum_{k \ge 1} e^{\nu(t)k} \nu'(t) k^{s+1} \left| \hat{\phi}(k) \right| + \frac{2}{R} \frac{\gamma}{4\pi} \sum_{k \ge 1} e^{\nu(t)k} k^{s} (J_1 + J_2)(k) \left| \hat{\phi}(k) \right| \tag{7.4}$$

<span id="page-25-1"></span>
$$+\frac{2\pi}{L(t)}\sum_{k\geq 1}e^{\nu(t)k}k^{s}\frac{\mathcal{F}(\widetilde{\mathcal{N}})(k)\hat{\phi}(k)}{\left|\hat{\phi}(k)\right|} + \overline{\mathcal{F}(\widetilde{\mathcal{N}})(k)}\hat{\phi}(k)$$

$$(7.5)$$

$$+2\frac{\gamma}{4\pi} \left( -\frac{1}{R} + \frac{2\pi}{L(t)} \right) \sum_{k>1} e^{\nu(t)k} k^s (J_1 + J_2)(k) \left| \hat{\phi}(k) \right|. \tag{7.6}$$

First, let us estimate (7.6). Using Proposition 8, we obtain

<span id="page-25-2"></span><span id="page-25-0"></span>
$$\left| 2 \frac{\gamma}{4\pi} \left( -\frac{1}{R} + \frac{2\pi}{L(t)} \right) \sum_{k \ge 1} e^{\nu(t)k} k^{s} (J_{1} + J_{2})(k) \left| \hat{\phi}(k) \right| \right| \\
\le 2\pi \frac{\gamma}{4\pi} \frac{1}{R} A \|\phi\|_{\mathcal{F}^{0,1}} \sum_{k \ge 2} e^{\nu(t)k} k^{s+1} \left| \hat{\phi}(k) \right|, \tag{7.7}$$

where

<span id="page-25-5"></span><span id="page-25-4"></span><span id="page-25-3"></span>
$$A = A(\|\phi\|_{\mathcal{F}^{0,1}}) = \frac{1 - \sqrt{1 - \frac{\pi}{2}(e^{2\|\phi\|_{\mathcal{F}^{0,1}} - 1)}}}{\|\phi\|_{\mathcal{F}^{0,1}}}.$$

Next, let us estimate (7.4) and (7.5). First, we note that

$$2\sum_{k\geq 1} e^{\nu(t)k} \nu'(t) k^{s+1} \left| \hat{\phi}(k) \right| + \frac{2}{R} \frac{\gamma}{4\pi} \sum_{k\geq 1} e^{\nu(t)k} k^{s} (J_{1} + J_{2})(k) \left| \hat{\phi}(k) \right|$$

$$+ \frac{2\pi}{L(t)} \sum_{k\geq 1} e^{\nu(t)k} k^{s} \frac{\mathcal{F}(\widetilde{\mathcal{N}})(k) \overline{\hat{\phi}(k)} + \overline{\mathcal{F}(\widetilde{\mathcal{N}})(k)} \hat{\phi}(k)}{\left| \hat{\phi}(k) \right|}$$

$$\leq \nu'(t) \|\phi\|_{\dot{\mathcal{F}}_{\nu}^{s+1,1}} - \pi \frac{2}{R} \frac{\gamma}{4\pi} \sum_{k\geq 2} e^{\nu(t)k} k^{s+1} \left| \hat{\phi}(k) \right| + \frac{2\pi}{L(t)} \|\widetilde{\mathcal{N}}\|_{\dot{\mathcal{F}}_{\nu}^{s,1}}.$$

$$(7.8)$$

Plugging (7.7) and (7.8) into (7.4), we obtain

$$\frac{d}{dt} \|\phi\|_{\dot{\mathcal{F}}_{\nu}^{s,1}} \leq \nu'(t) \|\phi\|_{\dot{\mathcal{F}}_{\nu}^{s+1,1}} - \pi \frac{2}{R} \frac{\gamma}{4\pi} \sum_{k \geq 2} e^{\nu(t)k} k^{s+1} \left| \hat{\phi}(k) \right| + \frac{2\pi}{L(t)} \|\widetilde{\mathcal{N}}\|_{\dot{\mathcal{F}}_{\nu}^{s,1}} \\
+ 2 \frac{\gamma}{4\pi} \frac{1}{R} A \|\phi\|_{\mathcal{F}^{0,1}} \sum_{k \geq 2} e^{\nu(t)k} k^{s+1} \left| \hat{\phi}(k) \right|.$$
(7.9)

With the minus sign in the front, the second term in (7.9) is associated with dissipation of the initial interfacial perturbation. It is clear that the  $\pm 1$  Fourier modes of  $\phi$  play no part in the dissipation. This presents a technical difficulty, because the norm of the function space that we intend to use involves all nonzero Fourier modes of  $\phi$ . To resolve this issue, we note that (6.14) and  $\hat{\phi}(0) = 0$  imply

$$0 = \int_{-\pi}^{\pi} e^{i(\alpha + \hat{\phi}(1)e^{i\alpha} + \hat{\phi}(-1)e^{-i\alpha} + \sum_{|k| > 1} \hat{\phi}(k)e^{ik\alpha})} d\alpha.$$

This identity provides an implicit relation between the  $\pm 1$  Fourier modes and the other nonzero Fourier modes of  $\phi$ , which allows us to control the former in terms of the latter. This observation is summarized in Proposition 4.1 of [29]. In particular, if  $\|\phi\|_{\mathcal{F}^{0,1}} \in (0, \frac{1}{2} \log \frac{5}{4})$ , then for all  $r \in (\|\phi\|_{\mathcal{F}^{0,1}}, \frac{1}{2} \log \frac{5}{4})$ ,

$$\left| \hat{\phi}(1) \right| + \left| \hat{\phi}(-1) \right| \le C_I(r) r \sum_{|k| > 2} \left| \hat{\phi}(k) \right|.$$

Then

$$-\sum_{k\geq 2} e^{\nu(t)k} k^{s+1} \left| \hat{\phi}(k) \right| \leq -\frac{1}{2 \left( C_I(\|\phi\|_{\mathcal{F}^{0,1}}) \|\phi\|_{\mathcal{F}^{0,1}} + 1 \right)} \|\phi\|_{\dot{\mathcal{F}}^{s+1,1}_{\nu}}.$$

Using this estimate and Propositions 1 and 7, we obtain

$$\frac{d}{dt} \|\phi\|_{\dot{\mathcal{F}}_{\nu}^{s,1}}$$

$$\leq \left(\nu'(t) - \frac{1}{2\left(C_{I}(\|\phi\|_{\mathcal{F}^{0,1}}) \|\phi\|_{\mathcal{F}^{0,1}} + 1\right)} \pi \frac{2}{R} \frac{\gamma}{4\pi} + \frac{\gamma}{4\pi} \frac{1}{R} A \|\phi\|_{\mathcal{F}^{0,1}}\right) \|\phi\|_{\dot{\mathcal{F}}_{\nu}^{s+1,1}}$$

$$+ \frac{1}{R} \frac{1}{A_{1}} \|\widetilde{\mathcal{N}}\|_{\dot{\mathcal{F}}_{\nu}^{s,1}},$$
(7.10)

where

<span id="page-26-4"></span><span id="page-26-2"></span>
$$A_1 = \frac{1}{\sqrt{1 + \frac{\pi}{2} (e^{2\|\phi\|_{\mathcal{F}^{0,1}} - 1)}}}.$$

# <span id="page-26-0"></span>8 Estimating $\widetilde{\mathcal{N}}$

In Section 7, we derived an a priori estimate containing the  $\dot{\mathcal{F}}_{\nu}^{s,1}$  norm of  $\widetilde{\mathcal{N}}$ , where

$$\widetilde{\mathcal{N}}(\alpha) = (U_{\geq 2})_{\alpha}(\alpha) + T_{\geq 2}(\alpha)(1 + \phi_{\alpha}(\alpha)) + T_{1}(\alpha)\phi_{\alpha}(\alpha). \tag{8.1}$$

We derive an estimate for each of the three terms separately. In Sections 8.1 and 8.2, we will derive bounds for the second and third terms which depend on the  $\dot{\mathcal{F}}_{\nu}^{s,1}$  and  $\mathcal{F}_{\nu}^{0,1}$  norms of  $U_1$  and  $U_{\geq 2}$ . In Sections 9 and 10, respectively, we will derive bounds for these norms in terms of the corresponding norms of  $\phi$ . We will estimate the first term in (8.1) in Section 11.

## <span id="page-26-1"></span>8.1 Estimating $T_{\geq 2}(\alpha)(1+\phi_{\alpha}(\alpha))$

<span id="page-26-3"></span>We prove the following estimates.

Lemma 9. For  $s \geq 1$ ,

$$\begin{split} & \|T_{\geq 2}(1+\phi_{\alpha})\|_{\dot{\mathcal{F}}_{\nu}^{s,1}} \\ & \leq \left(1+b(2,s)\|\phi\|_{\dot{\mathcal{F}}_{\nu}^{1,1}}\right) \\ & \cdot \left(\|U_{\geq 2}\|_{\dot{\mathcal{F}}_{\nu}^{s-1,1}} + b(2,s-1)\left(\|\phi\|_{\dot{\mathcal{F}}_{\nu}^{s,1}} \|U_{\geq 1}\|_{\mathcal{F}_{\nu}^{0,1}} + \|U_{\geq 1}\|_{\dot{\mathcal{F}}_{\nu}^{s-1,1}} \|\phi\|_{\dot{\mathcal{F}}_{\nu}^{1,1}}\right)\right) \\ & + b(2,s)\|\phi\|_{\dot{\mathcal{F}}_{\nu}^{s+1,1}} \left(2\|U_{\geq 2}\|_{\dot{\mathcal{F}}_{\nu}^{0,1}} + 2\left(\|\phi\|_{\dot{\mathcal{F}}_{\nu}^{1,1}} \|U_{\geq 1}\|_{\mathcal{F}_{\nu}^{0,1}} + \|\phi\|_{\mathcal{F}_{\nu}^{1,1}} \|U_{\geq 1}\|_{\dot{\mathcal{F}}_{\nu}^{0,1}}\right)\right). \end{split}$$

For  $0 \le s < 1$ ,

$$\begin{split} & \|T_{\geq 2}(1+\phi_{\alpha})\|_{\dot{\mathcal{F}}^{s,1}_{\nu}} \\ & \leq \left(1+b(2,s) \|\phi\|_{\dot{\mathcal{F}}^{1,1}_{\nu}}\right) \\ & \cdot \left(\|U_{\geq 2}\|_{\dot{\mathcal{F}}^{0,1}_{\nu}} + b(2,s) \left(\|\phi\|_{\dot{\mathcal{F}}^{1,1}_{\nu}} \|U_{\geq 1}\|_{\mathcal{F}^{0,1}_{\nu}} + \|\phi\|_{\dot{\mathcal{F}}^{1,1}_{\nu}} \|U_{\geq 1}\|_{\dot{\mathcal{F}}^{0,1}_{\nu}}\right)\right) \\ & + b(2,s) \|\phi\|_{\dot{\mathcal{F}}^{s+1,1}_{\nu}} \left(2 \|U_{\geq 2}\|_{\dot{\mathcal{F}}^{0,1}_{\nu}} + 2 \left(\|\phi\|_{\dot{\mathcal{F}}^{1,1}_{\nu}} \|U_{\geq 1}\|_{\mathcal{F}^{0,1}_{\nu}} + \|\phi\|_{\mathcal{F}^{1,1}_{\nu}} \|U_{\geq 1}\|_{\dot{\mathcal{F}}^{0,1}_{\nu}}\right)\right). \end{split}$$

*Proof.* Using Proposition 2, we obtain that for  $s \geq 0$ ,

$$\begin{split} & \|T_{\geq 2}(1+\phi_{\alpha})\|_{\dot{\mathcal{F}}^{s,1}_{\nu}} \\ & \leq \|T_{\geq 2}\|_{\dot{\mathcal{F}}^{s,1}_{\nu}} + b(2,s) \bigg( \|T_{\geq 2}\|_{\dot{\mathcal{F}}^{s,1}_{\nu}} \, \|\phi\|_{\dot{\mathcal{F}}^{1,1}_{\nu}} + \|\phi\|_{\dot{\mathcal{F}}^{s+1,1}_{\nu}} \, \|T_{\geq 2}\|_{\mathcal{F}^{0,1}_{\nu}} \bigg). \end{split}$$

It remains to estimate  $||T_{\geq 2}||_{\dot{\mathcal{F}}^{s,1}_{:}}$  and  $||T_{\geq 2}||_{\mathcal{F}^{0,1}_{:}}$  in terms of  $U_1$  and  $U_{\geq 2}$ . Since

$$T_{\geq 2}(\alpha) = \mathcal{M}(U_{\geq 2})(\alpha) + \mathcal{M}(\phi_{\alpha}U_{\geq 1})(\alpha),$$

using Proposition 2 we obtain that for  $s \geq 1$ ,

$$||T_{\geq 2}||_{\dot{\mathcal{F}}_{\nu}^{s,1}} \leq ||U_{\geq 2}||_{\dot{\mathcal{F}}_{\nu}^{s-1,1}} + b(2,s-1)(||\phi||_{\dot{\mathcal{F}}_{\nu}^{s,1}} ||U_{\geq 1}||_{\mathcal{F}_{\nu}^{0,1}} + ||U_{\geq 1}||_{\dot{\mathcal{F}}_{\nu}^{s-1,1}} ||\phi||_{\dot{\mathcal{F}}_{\nu}^{1,1}}).$$

Applying Proposition 2 to

$$||T_{\geq 2}||_{\mathcal{F}^{0,1}} \leq 2||U_{\geq 2}||_{\dot{\mathcal{F}}^{0,1}} + 2||\phi_{\alpha}U_{\geq 1}||_{\dot{\mathcal{F}}^{0,1}},$$

we obtain

$$||T_{\geq 2}||_{\mathcal{F}_{\nu}^{0,1}} \leq 2 ||U_{\geq 2}||_{\dot{\mathcal{F}}_{\nu}^{0,1}} + 2(||\phi||_{\dot{\mathcal{F}}_{\nu}^{1,1}} ||U_{\geq 1}||_{\mathcal{F}_{\nu}^{0,1}} + ||\phi||_{\mathcal{F}_{\nu}^{1,1}} ||U_{\geq 1}||_{\dot{\mathcal{F}}_{\nu}^{0,1}}).$$

In the case of  $0 \le s < 1$ , applying Proposition 2 to

$$||T_{\geq 2}||_{\dot{\mathcal{T}}^{s,1}} \le ||U_{\geq 2}||_{\dot{\mathcal{T}}^{0,1}} + ||\phi_{\alpha}U_{\geq 1}||_{\dot{\mathcal{T}}^{0,1}},$$

we obtain

$$\|T_{\geq 2}\|_{\dot{\mathcal{F}}_{\nu}^{s,1}} \leq \|U_{\geq 2}\|_{\dot{\mathcal{F}}_{\nu}^{0,1}} + b(2,s) \bigg( \|\phi\|_{\dot{\mathcal{F}}_{\nu}^{1,1}} \, \|U_{\geq 1}\|_{\mathcal{F}_{\nu}^{0,1}} + \|\phi\|_{\dot{\mathcal{F}}_{\nu}^{1,1}} \, \|U_{\geq 1}\|_{\dot{\mathcal{F}}_{\nu}^{0,1}} \bigg).$$

#### <span id="page-27-0"></span>8.2 Estimating $T_1(\alpha)\phi_{\alpha}(\alpha)$

<span id="page-27-1"></span>We prove the following estimates.

**Lemma 10.** For  $s \ge 1$ ,

$$||T_1\phi_\alpha||_{\dot{\mathcal{F}}^{s,1}} \le b(2,s) ||\phi||_{\dot{\mathcal{F}}^{1,1}} ||U_1||_{\dot{\mathcal{F}}^{s-1,1}} + b(2,s) ||\phi||_{\dot{\mathcal{F}}^{s+1,1}} 2 ||U_1||_{\dot{\mathcal{F}}^{0,1}}.$$

For  $0 \le s < 1$ ,

$$||T_1\phi_\alpha||_{\dot{\mathcal{F}}^{s,1}_{u}} \le b(2,s) ||\phi||_{\dot{\mathcal{F}}^{1,1}_{u}} ||U_1||_{\dot{\mathcal{F}}^{0,1}_{u}} + b(2,s) ||\phi||_{\dot{\mathcal{F}}^{s+1,1}_{u}} 2 ||U_1||_{\dot{\mathcal{F}}^{0,1}_{u}}.$$

*Proof.* Using Proposition 2, we obtain that for  $s \geq 0$ ,

$$||T_1\phi_\alpha||_{\dot{\mathcal{F}}^{s,1}_\nu} \le b(2,s) \left( ||T_1||_{\dot{\mathcal{F}}^{s,1}_\nu} ||\phi||_{\dot{\mathcal{F}}^{1,1}_\nu} + ||\phi||_{\dot{\mathcal{F}}^{s+1,1}_\nu} ||T_1||_{\mathcal{F}^{0,1}_\nu} \right).$$

It remains to estimate  $||T_1||_{\dot{\mathcal{F}}^{s,1}_{\nu}}$  and  $||T_1||_{\mathcal{F}^{0,1}_{\nu}}$  in terms of  $U_1$  and  $U_{\geq 2}$ . Recalling that  $T_1(\alpha) = \mathcal{M}(U_1)(\alpha)$ , we obtain that for  $s \geq 1$ ,  $||T_1||_{\dot{\mathcal{F}}^{s,1}_{\nu}} = ||U_1||_{\dot{\mathcal{F}}^{s-1,1}_{\nu}}$ . Moreover,  $||T_1||_{\mathcal{F}^{0,1}_{\nu}} \leq 2 ||U_1||_{\dot{\mathcal{F}}^{0,1}_{\nu}}$ . In the case of  $0 \leq s < 1$ ,  $||T_1||_{\dot{\mathcal{F}}^{s,1}_{\nu}} \leq ||U_1||_{\dot{\mathcal{F}}^{0,1}_{\nu}}$ .

### <span id="page-28-0"></span>9 Estimating $U_1$

To estimate the  $\dot{\mathcal{F}}_{\nu}^{s,1}$  and  $\mathcal{F}_{\nu}^{0,1}$  norms of  $U_1$ , we first estimate the Fourier modes of  $U_1$ .

### <span id="page-28-2"></span>9.1 Estimating Fourier Modes of $U_1$

For any norm  $\|\cdot\|$ , we can estimate (4.5) as

<span id="page-28-1"></span>
$$||U_1|| \le ||ie^{i\alpha}e^{i\hat{\theta}(0)}\mathfrak{L}(\alpha)||. \tag{9.1}$$

To estimate the  $\dot{\mathcal{F}}_{\nu}^{s,1}$  and  $\mathcal{F}_{\nu}^{0,1}$  norms of the right hand side of (9.1), we write

$$ie^{i\alpha}e^{i\hat{\theta}(0)}\mathfrak{L}(\alpha) = \sum_{j=1}^{7} \frac{\gamma}{4\pi} \int_{-\pi}^{\pi} E_j(\alpha,\beta)d\beta,$$

where

$$\begin{split} E_1(\alpha,\beta) &= \frac{-e^{i\beta}(-1+e^{i\beta})(i(-1+e^{i\beta})+\beta(1+e^{i\beta}))}{2(-1+e^{i\beta})^2} \\ & \cdot \int_0^1 e^{-i\beta s} \phi(\alpha+\beta(-1+s)) ds, \\ E_2(\alpha,\beta) &= \frac{i(-1-2i\beta+e^{2i\beta})}{2(-1+e^{i\beta})^2} \int_0^1 e^{i\beta s} \phi(\alpha+\beta(-1+s)) ds, \\ E_3(\alpha,\beta) &= \frac{-(-1+e^{i\beta})\beta e^{i\beta}(-1+e^{i\beta})}{2(-1+e^{i\beta})^2} \\ & \cdot \int_0^1 e^{-i\beta s}(-1+s)\phi(\alpha+\beta(-1+s)) ds, \\ E_4(\alpha,\beta) &= \frac{-(-1+e^{i\beta})\beta(1+e^{i\beta})}{2(-1+e^{i\beta})^2} \int_0^1 e^{i\beta s}(-1+s)\phi(\alpha+\beta(-1+s)) ds, \\ E_5(\alpha,\beta) &= \frac{-(-1+e^{i\beta})i\beta e^{i\beta}(-1+e^{i\beta})}{2(-1+e^{i\beta})^2} \\ & \cdot \int_0^1 e^{-i\beta s}(-1+s)\phi'(\alpha+\beta(-1+s)) ds, \\ E_6(\alpha,\beta) &= \frac{-(-1+e^{i\beta})i(-\beta)(1+e^{i\beta})}{2(-1+e^{i\beta})^2} \\ & \cdot \int_0^1 e^{i\beta s}(-1+s)\phi'(\alpha+\beta(-1+s)) ds, \\ E_7(\alpha,\beta) &= \frac{-(-1+e^{i\beta})i(-1+2e^{i\beta}+e^{2i\beta})}{2(-1+e^{i\beta})^2} \phi(\alpha-\beta). \end{split}$$

First, we calculate the Fourier modes of  $E_1(\alpha, \beta)$ :

$$\mathcal{F}(E_1)(k,\beta) = \frac{-e^{i\beta}(i(-1+e^{i\beta})+\beta(1+e^{i\beta}))}{2(-1+e^{i\beta})} \cdot \int_0^1 e^{-i\beta s} e^{ik\beta(-1+s)} ds \cdot \mathcal{F}(\phi)(k).$$

Since

$$\begin{split} &\left|\frac{\gamma}{4\pi}\int_{-\pi}^{\pi}\frac{-e^{i\beta}}{2(-1+e^{i\beta})}(i(-1+e^{i\beta})+\beta(1+e^{i\beta}))\int_{0}^{1}e^{-i\beta s}e^{ik\beta(-1+s)}dsd\beta\right| \\ \leq &\frac{\gamma}{4\pi}\bigg(2\pi+\frac{1}{2}\sqrt{1+\frac{\pi^{2}}{4}}\cdot\frac{1}{2}\pi^{2}\bigg), \end{split}$$

we obtain

$$\left| \frac{\gamma}{4\pi} \int_{-\pi}^{\pi} \mathcal{F}(E_1)(k,\beta) d\beta \right| \leq \frac{\gamma}{4\pi} \left( 2\pi + \frac{\pi^2}{4} \sqrt{1 + \frac{\pi^2}{4}} \right) |\mathcal{F}(\phi)(k)|.$$

Similarly, we obtain

$$\left| \frac{\gamma}{4\pi} \int_{-\pi}^{\pi} \mathcal{F}(E_{2})(k,\beta) d\beta \right| \leq \left( \frac{\gamma}{4\pi} \left( \frac{1}{2} \sqrt{1 + \frac{\pi^{2}}{4} \cdot 2\pi + \pi^{2}} \right) + \frac{\gamma}{4\pi} \left( 2 \cdot \frac{\pi}{2} \cdot \frac{1}{2} \sqrt{1 + \frac{\pi^{2}}{4} \cdot 2\pi + \pi^{2}} \right) \right) |\mathcal{F}(\phi)(k)|,$$

$$\left| \frac{\gamma}{4\pi} \int_{-\pi}^{\pi} \mathcal{F}(E_{3})(k,\beta) d\beta \right| \leq \frac{\gamma}{4\pi} \cdot \frac{\pi^{2}}{2} |\mathcal{F}(\phi)(k)|,$$

$$\left| \frac{\gamma}{4\pi} \int_{-\pi}^{\pi} \mathcal{F}(E_{4})(k,\beta) d\beta \right| \leq \frac{\gamma}{4\pi} \left( \frac{1}{2} \sqrt{1 + \frac{\pi^{2}}{4} \cdot \pi^{2} + 2\pi} \right) |\mathcal{F}(\phi)(k)|,$$

$$\left| \frac{\gamma}{4\pi} \int_{-\pi}^{\pi} \mathcal{F}(E_{5})(k,\beta) d\beta \right| \leq \frac{\gamma}{4\pi} \cdot \frac{\pi^{2}}{2} |k| \cdot |\mathcal{F}(\phi)(k)|,$$

$$\left| \frac{\gamma}{4\pi} \int_{-\pi}^{\pi} \mathcal{F}(E_{6})(k,\beta) d\beta \right| \leq \frac{\gamma}{4\pi} \left( \frac{1}{2} \sqrt{1 + \frac{\pi^{2}}{4} \cdot \pi^{2} + 2\pi} \right) |k| |\mathcal{F}(\phi)(k)|,$$

$$\left| \frac{\gamma}{4\pi} \int_{-\pi}^{\pi} \mathcal{F}(E_{7})(k,\beta) d\beta \right| \leq \frac{\gamma}{4\pi} \left( \frac{1}{2} \sqrt{1 + \frac{\pi^{2}}{4} \cdot \pi^{2} + 2\pi} \right) |k| |\mathcal{F}(\phi)(k)|,$$

### <span id="page-29-0"></span>9.2 Estimating $||U_1||_{\mathcal{F}^{0,1}_n}$

In Section 9.1, we observed that

$$||U_1||_{\mathcal{F}_{\nu}^{0,1}} \le \sum_{j=1}^{7} \left\| \frac{\gamma}{4\pi} \int_{-\pi}^{\pi} E_j(\alpha, \beta) d\beta \right\|_{\mathcal{F}_{\nu}^{0,1}}.$$

Since

$$\begin{split} \left\| \frac{\gamma}{4\pi} \int_{-\pi}^{\pi} E_{1}(\alpha,\beta) d\beta \right\|_{\mathcal{F}_{\nu}^{0,1}} &\leq \frac{\gamma}{4\pi} \left( 2\pi + \frac{\pi^{2}}{4} \sqrt{1 + \frac{\pi^{2}}{4}} \right) \|\phi\|_{\mathcal{F}_{\nu}^{0,1}}, \\ \left\| \frac{\gamma}{4\pi} \int_{-\pi}^{\pi} E_{2}(\alpha,\beta) d\beta \right\|_{\mathcal{F}_{\nu}^{0,1}} &\leq \left( \frac{\gamma}{4\pi} \left( \frac{1}{2} \sqrt{1 + \frac{\pi^{2}}{4}} \cdot 2\pi + \pi^{2} \right) \right) \\ &\quad + \frac{\gamma}{4\pi} \left( 2 \cdot \frac{\pi}{2} \cdot \frac{1}{2} \sqrt{1 + \frac{\pi^{2}}{4}} \cdot 2\pi + \pi^{2} \right) \right) \|\phi\|_{\mathcal{F}_{\nu}^{0,1}}, \\ \left\| \frac{\gamma}{4\pi} \int_{-\pi}^{\pi} E_{3}(\alpha,\beta) d\beta \right\|_{\mathcal{F}_{\nu}^{0,1}} &\leq \frac{\gamma}{4\pi} \cdot \frac{\pi^{2}}{2} \|\phi\|_{\mathcal{F}_{\nu}^{0,1}}, \\ \left\| \frac{\gamma}{4\pi} \int_{-\pi}^{\pi} E_{4}(\alpha,\beta) d\beta \right\|_{\mathcal{F}_{\nu}^{0,1}} &\leq \frac{\gamma}{4\pi} \left( \frac{1}{2} \sqrt{1 + \frac{\pi^{2}}{4}} \cdot \pi^{2} + 2\pi \right) \|\phi\|_{\mathcal{F}_{\nu}^{0,1}}, \\ \left\| \frac{\gamma}{4\pi} \int_{-\pi}^{\pi} E_{5}(\alpha,\beta) d\beta \right\|_{\mathcal{F}_{\nu}^{0,1}} &\leq \frac{\gamma}{4\pi} \left( \frac{1}{2} \sqrt{1 + \frac{\pi^{2}}{4}} \cdot \pi^{2} + 2\pi \right) \|\phi\|_{\mathcal{F}_{\nu}^{1,1}}, \\ \left\| \frac{\gamma}{4\pi} \int_{-\pi}^{\pi} E_{6}(\alpha,\beta) d\beta \right\|_{\mathcal{F}_{\nu}^{0,1}} &\leq \frac{\gamma}{4\pi} \left( \frac{1}{2} \sqrt{1 + \frac{\pi^{2}}{4}} \cdot \pi^{2} + 2\pi \right) \|\phi\|_{\mathcal{F}_{\nu}^{1,1}}, \\ \left\| \frac{\gamma}{4\pi} \int_{-\pi}^{\pi} E_{7}(\alpha,\beta) d\beta \right\|_{\mathcal{F}_{\nu}^{0,1}} &\leq \frac{\gamma}{4\pi} \left( \frac{1}{2} \sqrt{1 + \frac{\pi^{2}}{4}} \cdot \frac{3}{2} \cdot 2\pi + \frac{1}{2} \cdot 4 \cdot 5 \right) \|\phi\|_{\mathcal{F}_{\nu}^{0,1}}, \end{split}$$

we obtain

$$||U_1||_{\mathcal{F}_{\nu}^{0,1}} \leq H_3 ||\phi||_{\mathcal{F}_{\nu}^{0,1}} + H_4 ||\phi||_{\mathcal{F}_{\nu}^{1,1}},$$

where  $H_3$  and  $H_4$  are constants.

## 9.3 Estimating $||U_1||_{\dot{\mathcal{F}}^{s,1}_{u}}$

In Section 9.1, we observed that

$$||U_1||_{\dot{\mathcal{F}}^{s,1}_{\nu}} \leq \sum_{j=1}^{7} \left\| \frac{\gamma}{4\pi} \int_{-\pi}^{\pi} E_j(\alpha,\beta) d\beta \right\|_{\dot{\mathcal{F}}^{s,1}_{\nu}}.$$

Since

$$\begin{split} \left\| \frac{\gamma}{4\pi} \int_{-\pi}^{\pi} E_{1}(\alpha,\beta) d\beta \right\|_{\dot{\mathcal{F}}_{\nu}^{s,1}} &\leq \frac{\gamma}{4\pi} \left( 2\pi + \frac{\pi^{2}}{4} \sqrt{1 + \frac{\pi^{2}}{4}} \right) \|\phi\|_{\dot{\mathcal{F}}_{\nu}^{s,1}} \,, \\ \left\| \frac{\gamma}{4\pi} \int_{-\pi}^{\pi} E_{2}(\alpha,\beta) d\beta \right\|_{\dot{\mathcal{F}}_{\nu}^{s,1}} &\leq \left( \frac{\gamma}{4\pi} \left( \frac{1}{2} \sqrt{1 + \frac{\pi^{2}}{4}} \cdot 2\pi + \pi^{2} \right) \right) \\ &\quad + \frac{\gamma}{4\pi} \left( 2 \cdot \frac{\pi}{2} \cdot \frac{1}{2} \sqrt{1 + \frac{\pi^{2}}{4}} \cdot 2\pi + \pi^{2} \right) \right) \|\phi\|_{\dot{\mathcal{F}}_{\nu}^{s,1}} \,, \\ \left\| \frac{\gamma}{4\pi} \int_{-\pi}^{\pi} E_{3}(\alpha,\beta) d\beta \right\|_{\dot{\mathcal{F}}_{\nu}^{s,1}} &\leq \frac{\gamma}{4\pi} \left( \frac{1}{2} \sqrt{1 + \frac{\pi^{2}}{4}} \cdot \pi^{2} + 2\pi \right) \|\phi\|_{\dot{\mathcal{F}}_{\nu}^{s,1}} \,, \\ \left\| \frac{\gamma}{4\pi} \int_{-\pi}^{\pi} E_{4}(\alpha,\beta) d\beta \right\|_{\dot{\mathcal{F}}_{\nu}^{s,1}} &\leq \frac{\gamma}{4\pi} \left( \frac{1}{2} \sqrt{1 + \frac{\pi^{2}}{4}} \cdot \pi^{2} + 2\pi \right) \|\phi\|_{\dot{\mathcal{F}}_{\nu}^{s,1}} \,, \\ \left\| \frac{\gamma}{4\pi} \int_{-\pi}^{\pi} E_{5}(\alpha,\beta) d\beta \right\|_{\dot{\mathcal{F}}_{\nu}^{s,1}} &\leq \frac{\gamma}{4\pi} \left( \frac{1}{2} \sqrt{1 + \frac{\pi^{2}}{4}} \cdot \pi^{2} + 2\pi \right) \|\phi\|_{\dot{\mathcal{F}}_{\nu}^{s+1,1}} \,, \\ \left\| \frac{\gamma}{4\pi} \int_{-\pi}^{\pi} E_{6}(\alpha,\beta) d\beta \right\|_{\dot{\mathcal{F}}_{\nu}^{s,1}} &\leq \frac{\gamma}{4\pi} \left( \frac{1}{2} \sqrt{1 + \frac{\pi^{2}}{4}} \cdot \pi^{2} + 2\pi \right) \|\phi\|_{\dot{\mathcal{F}}_{\nu}^{s+1,1}} \,, \\ \left\| \frac{\gamma}{4\pi} \int_{-\pi}^{\pi} E_{7}(\alpha,\beta) d\beta \right\|_{\dot{\mathcal{F}}_{\nu}^{s,1}} &\leq \frac{\gamma}{4\pi} \left( \frac{1}{2} \sqrt{1 + \frac{\pi^{2}}{4}} \cdot \frac{3}{2} \cdot 2\pi + \frac{1}{2} \cdot 4 \cdot 5 \right) \|\phi\|_{\dot{\mathcal{F}}_{\nu}^{s,1}} \,, \end{split}$$

we obtain

<span id="page-30-1"></span>
$$||U_1||_{\dot{\mathcal{F}}^{s,1}_{\nu}} \le H_1 ||\phi||_{\dot{\mathcal{F}}^{s,1}_{\nu}} + H_2 ||\phi||_{\dot{\mathcal{F}}^{s+1,1}_{\nu}},$$

where  $H_1$  and  $H_2$  are constants.

# <span id="page-30-0"></span>10 Estimating $U_{>2}$

For any norm  $\|\cdot\|$ , we can estimate (4.6) as

<span id="page-30-2"></span>
$$||U_{\geq 2}|| \leq \left| \left| i e^{i\alpha} e^{i\hat{\theta}(0)} \left( e^{i\phi(\alpha)} (\mathfrak{L}(\alpha) + \mathfrak{N}(\alpha)) - \mathfrak{L}(\alpha) \right) \right| \right|. \tag{10.1}$$

To estimate the  $\dot{\mathcal{F}}_{\nu}^{s,1}$  and  $\mathcal{F}_{\nu}^{0,1}$  norms of the right hand side of (10.1), we first note that

$$ie^{i\alpha}e^{i\hat{\theta}(0)}\left(e^{i\phi(\alpha)}(\mathfrak{L}(\alpha)+\mathfrak{N}(\alpha))-\mathfrak{L}(\alpha)\right) = \frac{\gamma}{4\pi}\int_{-\pi}^{\pi}B(\alpha,\beta)d\beta,\tag{10.2}$$

where 
$$B(\alpha, \beta) = \sum_{j=1}^{8} \widetilde{B_j}(\alpha, \beta) + \widetilde{B_{13}}(\alpha, \beta)$$
, in which

$$\begin{split} \widetilde{B_1}(\alpha,\beta) &= -\sum_{j_1+j_2+n\geq 1} \frac{-i\beta e^{2i\beta}}{1-e^{i\beta}} \frac{(-1)^{j_1+j_1i_1j_1+j_2+j_3}}{2j_1!j_2!j_3!} \phi(\alpha-\beta)^{j_1}\phi(\alpha)^{j_2} \\ & \cdot \int_0^1 e^{-i\beta s}\phi(\alpha+\beta(-1+s))^{j_3}(-1+s)ds \\ & \cdot \left(\sum_{m=1}^\infty \frac{i\beta}{1-e^{i\beta}} \int_0^1 e^{-i(s-1)\beta} \frac{(-i\phi(\alpha+(s-1)\beta))^m}{m!} ds\right)^n \\ & - \sum_{j_1+j_2+j_3\geq 1} \frac{-i\beta e^{2i\beta}}{1-e^{i\beta}} \frac{(-1)^{j_1+j_3}j_1+j_2+j_3}}{1-e^{i\beta}} \phi(\alpha-\beta)^{j_3}(\alpha-\beta)^{j_4}\phi(\alpha)^{j_2} \\ & \cdot \int_0^1 e^{-i\beta s}\phi(\alpha+\beta(-1+s))^{j_3}(-1+s)ds \\ & \cdot \left(\sum_{m=1}^\infty \frac{i\beta}{1-e^{i\beta}} \cdot \frac{1}{2} \int_0^1 e^{-i(s-1)\beta} \frac{(-i\phi(\alpha+(s-1)\beta))^m}{m!} ds\right)^n \\ & - \frac{-i\beta e^{2i\beta}}{1-e^{i\beta}} \cdot \frac{1}{2} \int_0^1 e^{-i(s-1)\beta} \frac{(-i\phi(\alpha+(s-1)\beta))^m}{m!} ds \\ & \cdot \sum_{m=2} \frac{i\beta}{1-e^{i\beta}} \int_0^1 e^{-i(s-1)\beta} \frac{(-i\phi(\alpha+(s-1)\beta))^m}{m!} ds \\ & \widetilde{B_2}(\alpha,\beta) = -\frac{1}{2} \sum_{j_1+j_2+j_3+n\geq 1} \frac{-i\beta e^{2i\beta}}{1-e^{i\beta}} \frac{(-1)^{j_1+j_3}j_1+j_2+j_3}{j_1!j_2!j_3!} \phi(\alpha-\beta)^{j_1}\phi(\alpha)^{j_2} \\ & \cdot \int_0^1 e^{-i\beta s}\phi(\alpha+\beta(-1+s))^{j_3}(-1+s)\phi'(\alpha+\beta(-1+s))ds \\ & \cdot \left(\sum_{m=1}^\infty \frac{i\beta}{1-e^{i\beta}} \int_0^1 e^{-i(s-1)\beta} \frac{(-i\phi(\alpha+(s-1)\beta))^m}{m!} ds\right)^n \\ \widetilde{B_3}(\alpha,\beta) = \frac{1}{2} \sum_{j_1+j_2=1} \frac{(n+1)}{1-e^{i\beta}} \frac{-\beta^2 e^{-i\beta}}{(1-e^{-i\beta})^2} \frac{ij_1+j_2+j_3+j_4}{j_1!j_2!j_3!j_4!} \phi(\alpha)^{j_1}\phi(\alpha-\beta)^{j_2} \\ & \cdot \int_0^1 e^{-i\beta s}\phi(\alpha+\beta(-1+s))^{j_3} ds \\ & \cdot \left(\sum_{m=1}^\infty \frac{-i^m}{m!} e^{-i\alpha} \frac{i\beta}{1-e^{-i\beta}} \int_0^1 e^{i(\alpha+(s-1)\beta)}\phi(\alpha+(s-1)\beta)^m ds\right)^n \\ & + \frac{1}{2} \sum_{j_1+j_2\geq 1} \frac{(n+1)}{-\beta^2 e^{-i\beta}} \frac{i\beta}{(1-e^{-i\beta})^2} \frac{ij_1+j_2+j_3+j_4}{j_1!j_2!j_3!j_4!} \phi(\alpha)^{j_1}\phi(\alpha-\beta)^{j_2} \\ & \cdot \int_0^1 e^{-i\beta s}\phi(\alpha+\beta(-1+s))^{j_3} ds \\ & \cdot \int_0^1 e^{-i\beta s}\phi(\alpha+\beta(-1+s))^{j_3} ds \\ & \cdot \int_0^1 e^{-i\beta s}\phi(\alpha+\beta(-1+s))^{j_3} ds \\ & \cdot \int_0^1 e^{-i\beta s}\phi(\alpha+\beta(-1+s))^{j_3} ds \\ & \cdot \int_0^1 e^{-i\beta s}\phi(\alpha+\beta(-1+s))^{j_3} ds \\ & \cdot \int_0^1 e^{-i\beta s}\phi(\alpha+\beta(-1+s))^{j_3} ds \\ & \cdot \int_0^1 e^{-i\beta s}\phi(\alpha+\beta(-1+s))^{j_3} ds \\ & \cdot \int_0^1 e^{-i\beta s}\phi(\alpha+\beta(-1+s))^{j_3} ds \\ & \cdot \int_0^1 e^{-i\beta s}\phi(\alpha+\beta(-1+s))^{j_3} ds \\ & \cdot \int_0^1 e^{-i\beta s}\phi(\alpha+\beta(-1+s))^{j_3} ds \\ & \cdot \int_0^1 e^{-i\beta s}\phi(\alpha+\beta(-1+s))^{j_3} ds \\ & \cdot \int_0^1 e^{-i\beta s}\phi(\alpha+\beta(-1+s))^{j_3} d\alpha \\ & \cdot \left(\sum_{n=1}^\infty \frac{-i\beta s}{m!} \phi(\alpha+\beta(-1+s))^{j_3} d\alpha \right) \\ & \cdot \left(\sum_{n=1}^\infty \frac{-i\beta s}{m!} \phi(\alpha+\beta(-1+s))^{j_3} d\alpha \right) \\ & \cdot \left(\sum_{n=$$

$$\begin{split} &+\frac{1}{2}\cdot 2\cdot \frac{-\beta^2e^{-i\beta}}{(1-e^{-i\beta})^2}\int_0^1 e^{-i\beta s}ds\int_0^1 e^{i\beta s}(-1+s)ds\sum_{m=2}^\infty \frac{-i^m}{m!} \\ &\cdot e^{-i\alpha}\frac{i\beta}{1-e^{-i\beta}}\int_0^1 e^{i(\alpha+(s-1)\beta)}\phi(\alpha+(s-1)\beta)^mds \\ &\widetilde{B}_4(\alpha,\beta) = \frac{1}{2}\sum_{j_1+j_2+j_3+j_4+n\geq 1}(n+1)\frac{-\beta^2e^{-i\beta}}{(1-e^{-i\beta})^2}\frac{ij^{j_1+j_2+j_3+j_4}(-1)^{j_3}}{j_1!j_2!j_3!j_4!} \\ &\cdot \phi(\alpha)^{j_1}\phi(\alpha-\beta)^{j_2}\int_0^1 e^{-i\beta s}\phi(\alpha+\beta(-1+s))^{j_3}ds \\ &\cdot \int_0^1 e^{i\beta s}\phi(\alpha+\beta(-1+s))^{j_4}(-1+s)\phi'(\alpha+\beta(-1+s))ds \\ &\cdot \left(\sum_{m=1}^\infty \frac{-i^m}{m!}e^{-i\alpha}\frac{i\beta}{1-e^{-i\beta}}\int_0^1 e^{i(\alpha+(s-1)\beta)}\phi(\alpha+(s-1)\beta)^mds\right)^n \\ &\widetilde{B}_5(\alpha,\beta) = \frac{1}{2}\sum_{j_1+j_2=0}\frac{i\beta}{1-e^{-i\beta}}\frac{i^{j_1+j_2+j_3}(-1)^{j_3}}{j_1!j_2!j_3!}\phi(\alpha)^{j_1}\phi(\alpha-\beta)^{j_2} \\ &\cdot \int_0^1 e^{-i\beta s}\phi(\alpha+\beta(-1+s))^{j_3}(-1+s)ds \\ &\cdot \left(\sum_{m=1}^\infty \frac{-i\beta}{1-e^{-i\beta}}\int_0^1 e^{i(s-1)\beta}\frac{i\phi(\alpha+(s-1)\beta))^m}{m!}ds\right)^n \\ &+\frac{1}{2}\sum_{j_1+j_2\geq 1}\frac{i\beta}{1-e^{-i\beta}}\frac{i^{j_1+j_2+j_3}(-1)^{j_3}}{j_1!j_2!j_3!}\phi(\alpha)^{j_1}\phi(\alpha-\beta)^{j_2} \\ &\cdot \int_0^1 e^{-i\beta s}\phi(\alpha+\beta(-1+s))^{j_3}(-1+s)ds \\ &\cdot \left(\sum_{m=1}^\infty \frac{-i\beta}{1-e^{-i\beta}}\int_0^1 e^{i(s-1)\beta}\frac{i\phi(\alpha+(s-1)\beta))^m}{m!}ds\right)^n \\ &+\frac{1}{2}\cdot \frac{-i\beta}{1-e^{-i\beta}}\int_0^1 e^{i(s-1)\beta}\frac{i\phi(\alpha+(s-1)\beta))^m}{m!}ds \\ &\widetilde{B}_6(\alpha,\beta) &= \frac{1}{2}\sum_{j_1+j_2\geq 1}\frac{i\beta}{1-e^{-i\beta}}\frac{i^{j_1+j_2+j_3}(-1)^{j_2}}{j_1!j_2!j_3!}\phi(\alpha)^{j_1}\phi(\alpha-\beta)^{j_2} \\ &\cdot \int_0^1 e^{i\beta s}\phi(\alpha+\beta(-1+s))^{j_3}(-1+s)ds \\ &\cdot \left(\sum_{m=1}^\infty \frac{-i\beta}{1-e^{-i\beta}}\int_0^1 e^{i(s-1)\beta}\frac{i\phi(\alpha+(s-1)\beta))^m}{m!}ds\right)^n \\ &+\frac{1}{2}\sum_{j_1+j_2\geq 1}\frac{-i\beta}{1-e^{-i\beta}}\int_0^1 e^{i(s-1)\beta}\frac{i\phi(\alpha+(s-1)\beta))^m}{m!}ds \\ &\cdot \left(\sum_{m=1}^\infty \frac{-i\beta}{1-e^{-i\beta}}\int_0^1 e^{i(s-1)\beta}\frac{i\phi(\alpha+(s-1)\beta))^m}{m!}ds\right)^n \\ &+\frac{1}{2}\sum_{j_1+j_2\geq 1}\frac{-i\beta}{1-e^{-i\beta}}\int_0^1 e^{i(s-1)\beta}\frac{i\phi(\alpha+(s-1)\beta))^m}{m!}ds \right)^n \\ &+\frac{1}{2}\sum_{j_1+j_2\geq 1}\frac{-i\beta}{1-e^{-i\beta}}\int_0^1 e^{i(s-1)\beta}\frac{i\phi(\alpha+(s-1)\beta))^m}{m!}ds \right)^n \\ &+\frac{1}{2}\sum_{j_1+j_2\geq 1}\frac{-i\beta}{1-e^{-i\beta}}\int_0^1 e^{i(s-1)\beta}\frac{i\phi(\alpha+(s-1)\beta))^m}{m!}ds \right)^n \\ &\cdot \int_0^1 e^{i\beta s}\phi(\alpha+\beta(-1+s))^{j_3}(-1+s)ds \\ &\cdot \left(\sum_{m=1}^\infty \frac{-i\beta}{1-e^{-i\beta}}\int_0^1 e^{i(s-1)\beta}\frac{i\phi(\alpha+(s-1)\beta))^m}{m!}ds \right)^n \\ &\cdot \left(\sum_{m=1}^\infty \frac{-i\beta}{1-e^{-i\beta}}\int_0^1 e^{i(s-1)\beta}\frac{i\phi(\alpha+(s-1)\beta)}{m!}ds \right)^n \\ &\cdot \left(\sum_{m=1}^\infty \frac{-i\beta}{1-e^{-i\beta}}\int_0^1 e^{i(s-1)\beta}\frac{i\phi(\alpha+(s-1)\beta)}{m!}ds \right)^n \\ &\cdot \left(\sum_{m=1}^$$

$$\begin{split} &+\frac{1}{2}\cdot\frac{i\beta}{1-e^{-i\beta}}\int_{0}^{1}e^{i\beta s}(-1+s)ds\\ &\cdot\sum_{m=2}^{\infty}\frac{-i\beta}{1-e^{-i\beta}}\int_{0}^{1}e^{i(s-1)\beta}\frac{(i\phi(\alpha+(s-1)\beta))^{m}}{m!}ds\\ &\widetilde{B_{7}}(\alpha,\beta)=\frac{1}{2}\sum_{j_{1}+j_{2}+j_{3}+n\geq1}\frac{i\beta}{1-e^{-i\beta}}\frac{i^{j_{1}+j_{2}+j_{3}}(-1)^{j_{3}}}{j_{1}!j_{2}!j_{3}!}\phi(\alpha)^{j_{1}}\phi(\alpha-\beta)^{j_{2}}\\ &\cdot\int_{0}^{1}e^{-i\beta s}\phi(\alpha+\beta(-1+s))^{j_{3}}(-1+s)\phi'(\alpha+\beta(-1+s))ds\\ &\cdot\left(\sum_{m=1}^{\infty}\frac{-i\beta}{1-e^{-i\beta}}\int_{0}^{1}e^{i(s-1)\beta}\frac{(i\phi(\alpha+(s-1)\beta))^{m}}{m!}ds\right)^{n}\\ &\widetilde{B_{8}}(\alpha,\beta)=\frac{1}{2}\sum_{j_{1}+j_{2}+j_{3}+n\geq1}\frac{i\beta}{1-e^{-i\beta}}\frac{i^{j_{1}+j_{2}+j_{3}}(-1)^{j_{2}}}{j_{1}!j_{2}!j_{3}!}\phi(\alpha)^{j_{1}}\phi(\alpha-\beta)^{j_{2}}\\ &\cdot\int_{0}^{1}e^{i\beta s}\phi(\alpha+\beta(-1+s))^{j_{3}}(-1+s)\phi'(\alpha+\beta(-1+s))ds\\ &\cdot\left(\sum_{m=1}^{\infty}\frac{-i\beta}{1-e^{-i\beta}}\int_{0}^{1}e^{i(s-1)\beta}\frac{(i\phi(\alpha+(s-1)\beta))^{m}}{m!}ds\right)^{n}\\ &\widetilde{B_{13}}(\alpha,\beta)=\sum_{j_{1}+j_{2}\geq2}\frac{i^{j_{1}+j_{2}}}{j_{1}!j_{2}!}\phi(\alpha)^{j_{1}}\phi(\alpha-\beta)^{j_{2}}\left((-1)^{j_{2}}\frac{e^{i\beta}(1+e^{i\beta})}{2(-1+e^{i\beta})}-\frac{1}{2}\right). \end{split}$$

## <span id="page-33-2"></span>10.1 Estimating Fourier Modes of $U_{\geq 2}$

In our calculations, we adopt the notational convention that any product  $\prod$  in which the upper bound is strictly less than the lower bound is defined to be 1. To calculate the Fourier modes of  $U_{\geq 2}$ , we frequently use the identity

<span id="page-33-1"></span>
$$\mathcal{F}(g_1 g_2 \cdots g_n)(k_1) = \sum_{k_2, \dots, k_n \in \mathbb{Z}} \left( \prod_{d=1}^{n-1} \mathcal{F}(g_d)(k_d - k_{d+1}) \right) \mathcal{F}(g_n)(k_n).$$
 (10.3)

<span id="page-33-0"></span>The following estimate is used frequently.

**Lemma 11.** For  $n \geq 0$ , let

$$I_{n}(k_{1}, k_{j_{1}+1}, k_{j_{1}+j_{2}+1}, \dots, k_{j_{1}+j_{2}+n}, k_{j_{1}+j_{2}+n+1}, \beta)$$

$$= \prod_{d=1}^{n} \left( \frac{i\beta e^{i\beta}}{1 - e^{i\beta}} \int_{0}^{1} e^{-is\beta} e^{i(s-1)\beta(k_{j_{1}+j_{2}+d}-k_{j_{1}+j_{2}+d+1})} ds \right) \cdot e^{-i\beta(k_{1}-k_{j_{1}+1})} \cdot \int_{0}^{1} e^{-i\beta s} e^{i\beta(-1+s)k_{j_{1}+j_{2}+n+1}} (-1+s) ds.$$

Then

$$\left| \frac{\gamma}{4\pi} \int_{-\pi}^{\pi} I_n(k_1, k_{j_1+1}, k_{j_1+j_2+1}, \dots, k_{j_1+j_2+n}, k_{j_1+j_2+n+1}, \beta) \cdot \frac{-i\beta e^{2i\beta}}{1 - e^{i\beta}} d\beta \right| \le C_n,$$

where

$$C_n = \frac{\gamma}{4\pi} \left( (n+1) \cdot \left( \frac{\pi}{2} \right)^n \cdot \frac{1}{2} \sqrt{1 + \frac{\pi^2}{4}} \cdot \pi^2 + 2\pi \right).$$

*Proof.* We note that

$$\int_0^1 e^{-is\beta} e^{i(s-1)\beta k} ds = \begin{cases} \frac{i(e^{-i\beta} - e^{-i\beta k})}{\beta(1-k)} & \text{if } k \neq 1, \\ e^{-i\beta} & \text{if } k = 1. \end{cases}$$

In the case of  $n \ge 1$ , suppose that  $0 \le l \le n$  and l elements of  $\{k_{j_1+j_2+d}-k_{j_1+j_2+d+1}\}_{d=1}^n$  satisfy  $k_{j_1+j_2+d}-k_{j_1+j_2+d+1} = 1$ . Reordering the subscripts such that  $k_{j_1+j_2+d}-k_{j_1+j_2+d+1} \ne 1$  for  $d=1,\ldots,n-l$ , we obtain

$$I_{n} = e^{-i\beta(k_{1} - k_{j_{1}+1})} \prod_{d=1}^{n-l} \frac{-(1 - e^{-i\beta(-1 + k_{j_{1}+j_{2}+d} - k_{j_{1}+j_{2}+d+1})})}{(1 - e^{i\beta})(1 - k_{j_{1}+j_{2}+d} + k_{j_{1}+j_{2}+d+1})} \left(\frac{i\beta}{1 - e^{i\beta}}\right)^{l} \cdot \int_{0}^{1} e^{-i\beta s} e^{i\beta(-1+s)k_{j_{1}+j_{2}+n+1}} (-1+s) ds.$$

If  $k_{j_1+j_2+d} - k_{j_1+j_2+d+1} > 1$ , then

$$\frac{-(1 - e^{-i\beta(-1 + k_{j_1 + j_2 + d} - k_{j_1 + j_2 + d + 1})})}{1 - e^{i\beta}} = e^{-i\beta} \sum_{r_d = 0}^{-2 + k_{j_1 + j_2 + d} - k_{j_1 + j_2 + d + 1}} (e^{-i\beta})^{r_d}.$$

If  $k_{j_1+j_2+d} - k_{j_1+j_2+d+1} < 1$ , then

$$\frac{-(1 - e^{-i\beta(-1 + k_{j_1 + j_2 + d} - k_{j_1 + j_2 + d + 1})})}{1 - e^{i\beta}} = -\sum_{r=0}^{-(k_{j_1 + j_2 + d} - k_{j_1 + j_2 + d + 1})} (e^{i\beta})^{r_d}.$$

Without loss of generality, suppose that  $k_{j_1+j_2+d}-k_{j_1+j_2+d+1}<1$  only for  $d=w,\ldots,n-l$ . Then

$$\prod_{d=1}^{n-l} \frac{-(1-e^{-i\beta(-1+k_{j_1+j_2+d}-k_{j_1+j_2+d+1})})}{1-e^{i\beta}}$$

$$=e^{-i\beta} \sum_{r_1=0}^{-2+k_{j_1+j_2+1}-k_{j_1+j_2+2}} (e^{-i\beta})^{r_1} \cdot \dots \cdot e^{-i\beta} \sum_{r_{w-1}=0}^{-2+k_{j_1+j_2+w-1}-k_{j_1+j_2+w}} (e^{-i\beta})^{r_{w-1}}$$

$$\cdot (-1) \sum_{r_w=0}^{-(k_{j_1+j_2+w}-k_{j_1+j_2+w+1})} (e^{i\beta})^{r_w} \cdot \dots \cdot (-1) \sum_{r_{n-l}=0}^{-(k_{j_1+j_2+n-l}-k_{j_1+j_2+n-l+1})} (e^{i\beta})^{r_{n-l}}$$

$$= \sum_{r_1=0}^{-2+k_{j_1+j_2+1}-k_{j_1+j_2+2}} \dots \sum_{r_{w-1}=0}^{-2+k_{j_1+j_2+w-1}-k_{j_1+j_2+w}} \sum_{r_{w-1}=0}^{-(k_{j_1+j_2+w}-k_{j_1+j_2+w+1})} \dots \sum_{r_{w-l}=0}^{-(k_{j_1+j_2+w}-k_{j_1+j_2+w+1})} \sum_{r_{w-l}=0}^{-(k_{j_1+j_2+w}-k_{j_1+j_2+w+1})} \sum_{r_{w-l}=0}^{-(k_{j_1+j_2+w}-k_{j_1+j_2+w+1})} \sum_{r_{w-l}=0}^{-(k_{j_1+j_2+w}-k_{j_1+j_2+w+1})} (e^{-i\beta})^{r_1+\dots+r_{w-l}} (e^{i\beta})^{r_w+\dots+r_{n-l}}.$$

Hence,

$$I_{n} = \prod_{d=1}^{n-l} \frac{1}{1 - k_{j_{1} + j_{2} + d} + k_{j_{1} + j_{2} + d + 1}} \cdot \sum_{-2 + k_{j_{1} + j_{2} + 1} - k_{j_{1} + j_{2} + 2}} \frac{1}{1 - k_{j_{1} + j_{2} + d + 1}} \cdot \sum_{-2 + k_{j_{1} + j_{2} + w - 1} - k_{j_{1} + j_{2} + w}} \sum_{r_{w-1} = 0} \frac{1}{r_{w-1} - (k_{j_{1} + j_{2} + w} - k_{j_{1} + j_{2} + w + 1})} \cdot \sum_{r_{w-1} = 0} \frac{1}{r_{w-1} - (k_{j_{1} + j_{2} + w} - k_{j_{1} + j_{2} + w - 1} - k_{j_{1} + j_{2} + w - 1 + 1})} \cdot \sum_{r_{w-1} = 0} \frac{1}{r_{w-1} - (k_{j_{1} + j_{2} + w} - k_{j_{1} + j_{2} + w - 1} - k_{j_{1} + j_{2} + w - 1 + 1})} \cdot \sum_{r_{w-1} = 0} \frac{1}{r_{w-1} - (k_{j_{1} + j_{2} + w} - k_{j_{1} + j_{2} + w - 1} - k_{j_{1} + j_{2} + w} - k_{j_{1} + j_{2} + w - 1} - k_{j_{1} + j_{2} + w - 1} - k_{j_{1} + j_{2} + w - 1} - k_{j_{1} + j_{2} + w - 1} - k_{j_{1} + j_{2} + w - 1} - k_{j_{1} + j_{2} + w - 1} - k_{j_{1} + j_{2} + w - 1} - k_{j_{1} + j_{2} + w - 1} - k_{j_{1} + j_{2} + w - 1} - k_{j_{1} + j_{2} + w - 1} - k_{j_{1} + j_{2} + w - 1} - k_{j_{1} + j_{2} + w - 1} - k_{j_{1} + j_{2} + w - 1} - k_{j_{1} + j_{2} + w - 1} - k_{j_{1} + j_{2} + w - 1} - k_{j_{1} + j_{2} + w - 1} - k_{j_{1} + j_{2} + w - 1} - k_{j_{1} + j_{2} + w - 1} - k_{j_{1} + j_{2} + w - 1} - k_{j_{1} + j_{2} + w - 1} - k_{j_{1} + j_{2} + w - 1} - k_{j_{1} + j_{2} + w - 1} - k_{j_{1} + j_{2} + w - 1} - k_{j_{1} + j_{2} + w - 1} - k_{j_{1} + j_{2} + w - 1} - k_{j_{1} + j_{2} + w - 1} - k_{j_{1} + j_{2} + w - 1} - k_{j_{1} + j_{2} + w - 1} - k_{j_{1} + j_{2} + w - 1} - k_{j_{1} + j_{2} + w - 1} - k_{j_{1} + j_{2} + w - 1} - k_{j_{1} + j_{2} + w - 1} - k_{j_{1} + j_{2} + w - 1} - k_{j_{1} + j_{2} + w - 1} - k_{j_{1} + j_{2} + w - 1} - k_{j_{1} + j_{2} + w - 1} - k_{j_{1} + j_{2} + w - 1} - k_{j_{1} + j_{2} + w - 1} - k_{j_{1} + j_{2} + w - 1} - k_{j_{1} + j_{2} + w - 1} - k_{j_{1} + j_{2} + w - 1} - k_{j_{1} + j_{2} + w - 1} - k_{j_{1} + j_{2} + w - 1} - k_{j_{1} + j_{2} + w - 1} - k_{j_{1} + j_{2} + w - 1} - k_{j_{1} + j_{2} + w - 1} - k_{j_{1} + j_{2} + w - 1} - k_{j_{1} + j_{2} + w - 1} - k_{j_{1} + j_{2} + w - 1} - k_{j_{$$

Let

$$J_{n} = \frac{\gamma}{4\pi} \int_{-\pi}^{\pi} (e^{-i\beta})^{w-1+r_{1}+\dots+r_{w-1}-(r_{w}+\dots+r_{n-l})} \left(\frac{i\beta}{1-e^{i\beta}}\right)^{l} e^{-i\beta(k_{1}-k_{j_{1}+1})} \cdot \int_{0}^{1} e^{-i\beta s} e^{i\beta(-1+s)k_{j_{1}+j_{2}+n+1}} (-1+s) ds \cdot \frac{-i\beta e^{2i\beta}}{1-e^{i\beta}} d\beta.$$

Using that for all  $l \geq 0$ ,

$$\left| \left( \frac{i\beta}{1 - e^{i\beta}} \right)^l - 1 \right| \leq |\beta| \cdot l \cdot \left( \frac{\pi}{2} \right)^{l-1} \cdot \frac{1}{2} \sqrt{1 + \frac{\pi^2}{4}},$$

we obtain

$$|J_n| \le \frac{\gamma}{4\pi} \left( \int_{-\pi}^{\pi} \left| \left( \frac{i\beta}{1 - e^{i\beta}} \right)^{l+1} - 1 \right| d\beta + 2\pi \right)$$

$$\le \frac{\gamma}{4\pi} \left( (l+1) \cdot \left( \frac{\pi}{2} \right)^l \cdot \frac{1}{2} \sqrt{1 + \frac{\pi^2}{4}} \cdot \pi^2 + 2\pi \right)$$

$$\le \frac{\gamma}{4\pi} \left( (n+1) \cdot \left( \frac{\pi}{2} \right)^n \cdot \frac{1}{2} \sqrt{1 + \frac{\pi^2}{4}} \cdot \pi^2 + 2\pi \right)$$

$$= C_n.$$

Thus,

$$\left| \frac{\gamma}{4\pi} \int_{-\pi}^{\pi} I_n(k_1, k_{j_1+1}, k_{j_1+j_2+1}, \dots, k_{j_1+j_2+n}, k_{j_1+j_2+n+1}, \beta) \cdot \frac{-i\beta e^{2i\beta}}{1 - e^{i\beta}} d\beta \right|$$

$$\leq \prod_{d=1}^{n-l} \frac{1}{|1 - k_{j_1+j_2+d} + k_{j_1+j_2+d+1}|} \cdot \sum_{r_1=0}^{-2+k_{j_1+j_2+1} - k_{j_1+j_2+2}} \cdots \sum_{r_{w-1}=0}^{-2+k_{j_1+j_2+w} - k_{j_1+j_2+w-1} - k_{j_1+j_2+w}} \cdots \sum_{r_{w-1}=0}^{-(k_{j_1+j_2+w} - k_{j_1+j_2+w+1})} \cdots \sum_{r_{w}=0}^{-(k_{j_1+j_2+w} - k_{j_1+j_2+w} - k_{j_1+j_2+n-l+1})} |J_n|$$

$$\leq C_n.$$

In the case of n = 0,

$$\begin{split} &\left|\frac{\gamma}{4\pi}\int_{-\pi}^{\pi}I_0(k_1,k_{j_1+1},k_{j_1+j_2+1},\beta)\cdot\frac{-i\beta e^{2i\beta}}{1-e^{i\beta}}d\beta\right|\\ \leq &\frac{\gamma}{4\pi}\bigg(\int_{-\pi}^{\pi}|\beta|\cdot\frac{1}{2}\sqrt{1+\frac{\pi^2}{4}}d\beta+2\pi\bigg)\\ = &C_0. \end{split}$$

Let us calculate the Fourier modes of  $\widetilde{B_1}(\alpha,\beta)$ . We can write  $\widetilde{B_1} = \sum_{j=1}^3 \widetilde{B_{1,j}}$ , where

$$\widetilde{B_{1,1}}(\alpha,\beta) = -\sum_{\substack{j_1+j_2+n \geq 1 \\ j_3=1}} \frac{-i\beta e^{2i\beta}}{1 - e^{i\beta}} \frac{(-1)^{j_1+j_3} i^{j_1+j_2+j_3}}{2j_1! j_2! j_3!} \phi(\alpha - \beta)^{j_1} \phi(\alpha)^{j_2}$$

$$\cdot \int_0^1 e^{-i\beta s} \phi(\alpha + \beta(-1+s))^{j_3} (-1+s) ds$$

$$\cdot \left(\sum_{m=1}^{\infty} \frac{i\beta}{1 - e^{i\beta}} \int_0^1 e^{-i(s-1)\beta} \frac{(-i\phi(\alpha + (s-1)\beta))^m}{m!} ds\right)^n$$

$$\widetilde{B_{1,2}}(\alpha,\beta) = -\sum_{\substack{j_1 + j_2 + j_3 \ge 1 \\ n = 1}} \frac{-i\beta e^{2i\beta}}{1 - e^{i\beta}} \frac{(-1)^{j_1 + j_3} i^{j_1 + j_2 + j_3}}{2j_1! j_2! j_3!} \phi(\alpha - \beta)^{j_1} \phi(\alpha)^{j_2}$$

$$\cdot \int_0^1 e^{-i\beta s} \phi(\alpha + \beta(-1+s))^{j_3} (-1+s) ds$$

$$\cdot \left(\sum_{m=1}^{\infty} \frac{i\beta}{1 - e^{i\beta}} \int_0^1 e^{-i(s-1)\beta} \frac{(-i\phi(\alpha + (s-1)\beta))^m}{m!} ds\right)^n$$

$$\widetilde{B_{1,3}}(\alpha,\beta) = -\frac{-i\beta e^{2i\beta}}{1 - e^{i\beta}} \cdot \frac{1}{2} \int_0^1 e^{-i\beta s} (-1+s) ds$$

$$\cdot \sum_{n=1}^{\infty} \frac{i\beta}{1 - e^{i\beta}} \int_0^1 e^{-i(s-1)\beta} \frac{(-i\phi(\alpha + (s-1)\beta))^m}{m!} ds.$$

Due to similarity in calculations, we only calculate the Fourier modes of  $\widetilde{B_{1,1}}(\alpha,\beta)$  for illustration. We note that

$$\mathcal{F}(\widetilde{B_{1,1}})(k_1,\beta) = -\sum_{j_1+j_2+n\geq 1} \frac{-i\beta e^{2i\beta}}{1 - e^{i\beta}} \frac{(-1)^{j_1+1} i^{j_1+j_2+1}}{2j_1! j_2!}$$

$$\cdot \mathcal{F}\bigg(\phi(\alpha - \beta)^{j_1} \phi(\alpha)^{j_2} \int_0^1 e^{-i\beta s} \phi(\alpha + \beta(-1+s))(-1+s) ds$$

$$\cdot \bigg(\sum_{m=1}^\infty \frac{i\beta}{1 - e^{i\beta}} \int_0^1 e^{-i(s-1)\beta} \frac{(-i\phi(\alpha + (s-1)\beta))^m}{m!} ds\bigg)^n\bigg)(k_1).$$

Letting

$$P(k) = \sum_{m=1}^{\infty} \frac{(-i)^m}{m!} \mathcal{F}(\phi^m)(k),$$

we can write

$$\mathcal{F}\left(\phi(\alpha-\beta)^{j_1}\phi(\alpha)^{j_2}\int_0^1 e^{-i\beta s}\phi(\alpha+\beta(-1+s))(-1+s)ds \cdot \left(\sum_{m=1}^{\infty} \frac{i\beta}{1-e^{i\beta}}\int_0^1 e^{-i(s-1)\beta} \frac{(-i\phi(\alpha+(s-1)\beta))^m}{m!}ds\right)^n\right)(k_1)$$

$$= \sum_{k_2,\dots,k_{j_1+j_2+n+1}\in\mathbb{Z}} \prod_{d=1}^{j_1+j_2} \mathcal{F}(\phi)(k_d-k_{d+1})\mathcal{F}(\phi)(k_{j_1+j_2+n+1}) \cdot \prod_{d=1}^n P(k_{j_1+j_2+d}-k_{j_1+j_2+d+1}) \cdot I_n(k_1,k_{j_1+1},k_{j_1+j_2+1},\dots,k_{j_1+j_2+n},k_{j_1+j_2+n+1},\beta).$$

Then

$$\begin{split} &\frac{\gamma}{4\pi} \int_{-\pi}^{\pi} \mathcal{F}(\widetilde{B_{1,1}})(k_1,\beta) d\beta \\ = &- \sum_{j_1+j_2+n \geq 1} \frac{(-1)^{j_1+1} i^{j_1+j_2+1}}{2j_1! j_2!} \\ &\cdot \sum_{k_2,...,k_{j_1+j_2+n+1} \in \mathbb{Z}} \prod_{d=1}^{j_1+j_2} \mathcal{F}(\phi)(k_d-k_{d+1}) \mathcal{F}(\phi)(k_{j_1+j_2+n+1}) \\ &\cdot \prod_{d=1}^{n} P(k_{j_1+j_2+d}-k_{j_1+j_2+d+1}) \frac{\gamma}{4\pi} \int_{-\pi}^{\pi} \frac{-i\beta e^{2i\beta}}{1-e^{i\beta}} \end{split}$$

$$I_n(k_1, k_{j_1+1}, k_{j_1+j_2+1}, \dots, k_{j_1+j_2+n}, k_{j_1+j_2+n+1}, \beta)d\beta.$$

By Lemma 11,

$$\left| \frac{\gamma}{4\pi} \int_{-\pi}^{\pi} \mathcal{F}(\widetilde{B_{1,1}})(k_1, \beta) d\beta \right|$$

$$\leq \sum_{j_1+j_2+n\geq 1} \frac{C_n}{2j_1! j_2!} \sum_{k_2, \dots, k_{j_1+j_2+n+1} \in \mathbb{Z}} \prod_{d=1}^{j_1+j_2} |\mathcal{F}(\phi)(k_d - k_{d+1})| |\mathcal{F}(\phi)(k_{j_1+j_2+n+1})|$$

$$\cdot \prod_{d=1}^{n} |P(k_{j_1+j_2+d} - k_{j_1+j_2+d+1})|.$$

Similarly,

$$\begin{split} & \left| \frac{\gamma}{4\pi} \int_{-\pi}^{\pi} \mathcal{F}(\widetilde{B_{1,2}})(k_1,\beta) d\beta \right| \\ \leq & \sum_{j_1+j_2+j_3 \geq 1} \frac{C_1}{2j_1! j_2! j_3!} \sum_{k_2, \dots, k_{j_1+j_2+2} \in \mathbb{Z}} \prod_{d=1}^{j_1+j_2} |\mathcal{F}(\phi)(k_d - k_{d+1})| \left| \mathcal{F}(\phi^{j_3})(k_{j_1+j_2+2}) \right| \\ & \cdot |P(k_{j_1+j_2+1} - k_{j_1+j_2+2})| \end{split}$$

and

$$\left| \frac{\gamma}{4\pi} \int_{-\pi}^{\pi} \mathcal{F}(\widetilde{B_{1,3}})(k_1,\beta) d\beta \right| \leq \frac{1}{2} \cdot \frac{\gamma}{4\pi} \left( \frac{\pi}{2} \sqrt{1 + \frac{\pi^2}{4}} \cdot \pi^2 + 2\pi \right) \left| \widetilde{P}(k_1) \right|,$$

where

$$\widetilde{P}(k) = \sum_{m=2}^{\infty} \frac{(-i)^m}{m!} \mathcal{F}(\phi^m)(k).$$

Calculations associated with the rest of the terms in (10.2) can be done similarly.

## <span id="page-37-2"></span>10.2 Estimating $\|U_{\geq 2}\|_{\mathcal{F}^{0,1}_{\nu}}$

<span id="page-37-0"></span>Let us prove the following estimate for  $||U_{\geq 2}||_{\mathcal{F}_{0}^{0,1}}$ .

**Lemma 12.** For some monotone increasing functions  $D_1$  and  $D_2$  of  $\|\phi\|_{\mathcal{F}^{0,1}_{\omega}}$ ,

$$\|U_{\geq 2}\|_{\mathcal{F}_{\nu}^{0,1}} \leq D_{1}(\|\phi\|_{\mathcal{F}_{\nu}^{0,1}}) \|\phi\|_{\mathcal{F}_{\nu}^{0,1}}^{2} + D_{2}(\|\phi\|_{\mathcal{F}_{\nu}^{0,1}}) \|\phi\|_{\mathcal{F}_{\nu}^{0,1}} \|\phi'\|_{\mathcal{F}_{\nu}^{0,1}}.$$

Before commencing the proof of Lemma 12, let us introduce the setup for the proof. For ease of notation, we define the  $l_{\nu}^1$  norm of a sequence a=a(k) defined on  $\mathbb{Z}$  by

$$||a||_{l^1_{\nu}} = \sum_{k \in \mathbb{Z}} e^{\nu(t)|k|} |a(k)|.$$

<span id="page-37-1"></span>The following estimate of the  $l_{\nu}^{1}$  norm of the convolution is frequently used.

**Proposition 13.** If  $a_1, \ldots, a_n$  are sequences on  $\mathbb{Z}$  whose  $l_{\nu}^1$  norms are finite, then

$$||a_1 * \cdots * a_n||_{l^1_{\nu}} \le \prod_{i=1}^n ||a_i||_{l^1_{\nu}}.$$

*Proof.* It suffices to prove the case when n=2. We have

$$\begin{split} \|a*b\|_{l^1_\nu} &= \sum_{k\in\mathbb{Z}} e^{\nu(t)|k|} \left| (a*b)(k) \right| \\ &\leq \sum_{j\in\mathbb{Z}} \sum_{k\in\mathbb{Z}} e^{\nu(t)|k-j|} e^{\nu(t)|j|} \left| a(k-j) \right| \left| b(j) \right| \\ &= \sum_{j\in\mathbb{Z}} e^{\nu(t)|j|} \left| b(j) \right| \sum_{k\in\mathbb{Z}} e^{\nu(t)|k-j|} \left| a(k-j) \right| \\ &= \|a\|_{l^1} \, \|b\|_{l^1} \, , \end{split}$$

as needed.  $\Box$ 

We note that

<span id="page-38-0"></span>
$$||P||_{l_{\nu}^{1}} \leq \sum_{m=1}^{\infty} \frac{\|\phi\|_{\mathcal{F}_{\nu}^{0,1}}^{m}}{m!} = e^{\|\phi\|_{\mathcal{F}_{\nu}^{0,1}}} - 1, \tag{10.4}$$

<span id="page-38-1"></span>
$$\left\| \widetilde{P} \right\|_{l_{\nu}^{1}} \leq \sum_{m=2}^{\infty} \frac{\|\phi\|_{\mathcal{F}_{\nu}^{0,1}}^{m}}{m!} = e^{\|\phi\|_{\mathcal{F}_{\nu}^{0,1}}} - \|\phi\|_{\mathcal{F}_{\nu}^{0,1}} - 1.$$
 (10.5)

To begin the proof of Lemma 12, we observe that

$$||U_{\geq 2}||_{\mathcal{F}_{\nu}^{0,1}} \leq \sum_{j=1}^{8} \left\| \frac{\gamma}{4\pi} \int_{-\pi}^{\pi} \widetilde{B_{j}}(\alpha,\beta) d\beta \right\|_{\mathcal{F}_{\nu}^{0,1}} + \left\| \frac{\gamma}{4\pi} \int_{-\pi}^{\pi} \widetilde{B_{13}}(\alpha,\beta) d\beta \right\|_{\mathcal{F}_{\nu}^{0,1}}.$$

This means that it suffices to estimate each of the  $\mathcal{F}_{\nu}^{0,1}$  norms on the right hand side. By Proposition 13 and (10.4), we obtain

$$\sum_{k_{1} \in \mathbb{Z}} e^{\nu(t)|k_{1}|} \left| \frac{\gamma}{4\pi} \int_{-\pi}^{\pi} \mathcal{F}(\widetilde{B_{1,1}})(k_{1},\beta) d\beta \right|$$

$$\leq \sum_{j_{1}+j_{2}+n>1} \frac{C_{n}}{2j_{1}! j_{2}!} \|\phi\|_{\mathcal{F}_{\nu}^{0,1}}^{j_{1}+j_{2}+1} (e^{\|\phi\|_{\mathcal{F}_{\nu}^{0,1}}} - 1)^{n}.$$

By Propositions 2 and 13 and (10.4), we obtain

$$\begin{split} & \sum_{k_1 \in \mathbb{Z}} e^{\nu(t)|k_1|} \left| \frac{\gamma}{4\pi} \int_{-\pi}^{\pi} \mathcal{F}(\widetilde{B_{1,2}})(k_1,\beta) d\beta \right| \\ \leq & \sum_{j_1 + j_2 + j_3 \ge 1} \frac{C_1}{2j_1 j_2! j_3!} \left\| \phi \right\|_{\mathcal{F}_{\nu}^{0,1}}^{j_1 + j_2 + j_3} (e^{\|\phi\|_{\mathcal{F}_{\nu}^{0,1}}} - 1). \end{split}$$

By (10.5), we obtain

$$\sum_{k_1 \in \mathbb{Z}} e^{\nu(t)|k_1|} \left| \frac{\gamma}{4\pi} \int_{-\pi}^{\pi} \mathcal{F}(\widetilde{B_{1,3}})(k_1,\beta) d\beta \right| \leq \frac{C_2}{2} (e^{\|\phi\|_{\mathcal{F}^{0,1}_{\nu}}} - \|\phi\|_{\mathcal{F}^{0,1}_{\nu}} - 1).$$

Calculations associated with the rest of the terms in (10.2) can be done similarly. This completes the proof of Lemma 12.

# 10.3 Estimating $||U_{\geq 2}||_{\dot{\mathcal{F}}^{s,1}_u}$

We prove a useful estimate for  $||U_{\geq 2}||_{\dot{\mathcal{F}}^{s,1}_{\nu}}$ , s > 0.

<span id="page-39-0"></span>**Lemma 14.** For s > 0.

$$||U_{\geq 2}||_{\dot{\mathcal{F}}_{\nu}^{s,1}} \leq F_{1}(||\phi||_{\mathcal{F}_{\nu}^{0,1}}) ||\phi||_{\mathcal{F}_{\nu}^{0,1}} ||\phi||_{\dot{\mathcal{F}}_{\nu}^{s,1}} + F_{2}(||\phi||_{\mathcal{F}_{\nu}^{0,1}}) ||\phi||_{\mathcal{F}_{\nu}^{0,1}}^{2} ||\phi||_{\dot{\mathcal{F}}_{\nu}^{s,1}} + F_{3}(||\phi||_{\mathcal{F}_{\nu}^{0,1}}) ||\phi'||_{\mathcal{F}_{\nu}^{0,1}} ||\phi||_{\dot{\mathcal{F}}_{\nu}^{s,1}} + F_{4}(||\phi||_{\mathcal{F}_{\nu}^{0,1}}) ||\phi||_{\mathcal{F}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, ||\phi'||_{\dot{\mathcal{F}}_{\nu}^{s,1}},$$

where  $F_1$ ,  $F_2$ ,  $F_3$ , and  $F_4$  are monotone increasing functions of  $\|\phi\|_{\mathcal{F}^{0,1}_+}$ .

Before commencing the proof of Lemma 14, let us introduce the setup for the proof. For ease of notation, we define the  $l_{\nu}^{s}$  norm of a sequence a = a(k) defined on  $\mathbb{Z}$  by

$$||a||_{l_{\nu}^{s}} = \sum_{k \neq 0} e^{\nu(t)|k|} |k|^{s} |a_{k}|.$$

<span id="page-39-1"></span>The following estimate of the  $l_{\nu}^{s}$  norm of the convolution is frequently used.

**Proposition 15.** Let s>0. If  $a_1,\ldots,a_n$  are sequences on  $\mathbb{Z}$  whose  $l_{\nu}^s$  norms are finite, then

$$\|a_1 * \cdots * a_n\|_{l_{\nu}^s} \le b(n, s) \sum_{j=1}^n \|a_j\|_{l_{\nu}^s} \prod_{\substack{k=1\\k\neq j}}^n \|a_k\|_{l_{\nu}^1}.$$

*Proof.* We note that for any  $k_1, \ldots, k_n \in \mathbb{Z}$ ,

$$|k_1|^s \le b(n,s)(|k_1-k_2|^s + |k_2-k_3|^s + \dots + |k_{n-1}-k_n|^s + |k_n|^s),$$

which follows from the convexity of the function  $|\cdot|^s$  for  $s \ge 1$  and the triangle inequality for 0 < s < 1. Using (10.3), we then obtain

$$||a_{1} * \cdots * a_{n}||_{l_{\nu}^{s}} = \sum_{k_{1} \in \mathbb{Z}} e^{\nu(t)|k_{1}|} |k_{1}|^{s} |(a_{1} * \cdots * a_{n})(k_{1})|$$

$$\leq \sum_{k_{1} \in \mathbb{Z}} \sum_{k_{2}, \dots, k_{n} \in \mathbb{Z}} e^{\nu(t)|k_{1}|} |k_{1}|^{s} \prod_{d=1}^{n-1} |a_{d}(k_{d} - k_{d+1})| |a_{n}(k_{n})|$$

$$\leq \sum_{j=2}^{n} \sum_{k_{1} \in \mathbb{Z}} \sum_{k_{2}, \dots, k_{n} \in \mathbb{Z}} e^{\nu(t)|k_{1}|} b(n, s) |k_{j-1} - k_{j}|^{s}$$

$$\cdot \prod_{d=1}^{n-1} |a_{d}(k_{d} - k_{d+1})| |a_{n}(k_{n})|$$

$$+ \sum_{k_{1} \in \mathbb{Z}} \sum_{k_{2}, \dots, k_{n} \in \mathbb{Z}} e^{\nu(t)|k_{1}|} b(n, s) |k_{n}|^{s} \prod_{d=1}^{n-1} |a_{d}(k_{d} - k_{d+1})| |a_{n}(k_{n})|.$$

For  $j \in \{2, \ldots, n\}$ , we have

$$\sum_{k_{1}\in\mathbb{Z}}\sum_{k_{2},\dots,k_{n}\in\mathbb{Z}}e^{\nu(t)|k_{1}|}b(n,s)|k_{j-1}-k_{j}|^{s}\prod_{d=1}^{n-1}|a_{d}(k_{d}-k_{d+1})||a_{n}(k_{n})|$$

$$\leq b(n,s)\sum_{k_{n}\in\mathbb{Z}}|a_{n}(k_{n})|e^{\nu(t)|k_{n}|}\sum_{k_{n-1}\in\mathbb{Z}}|a_{n-1}(k_{n-1}-k_{n})|e^{\nu(t)|k_{n-1}-k_{n}|}$$

$$\cdots\sum_{k_{j-1}\in\mathbb{Z}}|k_{j-1}-k_{j}|^{s}|a_{j-1}(k_{j-1}-k_{j})|e^{\nu(t)|k_{j-1}-k_{j}|}$$

$$\cdots\sum_{k_{2}\in\mathbb{Z}}|a_{2}(k_{2}-k_{3})|e^{\nu(t)|k_{2}-k_{3}|}\sum_{k_{1}\in\mathbb{Z}}|a_{1}(k_{1}-k_{2})|e^{\nu(t)|k_{1}-k_{2}|}.$$

Making the changes of variables

$$k'_{1} = k_{1} - k_{2}$$

$$k'_{2} = k_{2} - k_{3}$$

$$\vdots$$

$$k'_{n-1} = k_{n-1} - k_{n}$$

in that order, we obtain

$$\sum_{k_1 \in \mathbb{Z}} \sum_{k_2, \dots, k_n \in \mathbb{Z}} e^{\nu(t)|k_1|} b(n, s) |k_{j-1} - k_j|^s \prod_{d=1}^{n-1} |a_d(k_d - k_{d+1})| |a_n(k_n)|$$

$$\leq b(n, s) ||a_{j-1}||_{l_{\nu}^s} \prod_{\substack{k=1\\k \neq j}}^n ||a_k||_{l_{\nu}^1}.$$

Similarly,

$$\sum_{k_1 \in \mathbb{Z}} \sum_{k_2, \dots, k_n \in \mathbb{Z}} e^{\nu(t)|k_1|} b(n, s) |k_n|^s \prod_{d=1}^{n-1} |a_d(k_d - k_{d+1})| |a_n(k_n)|$$

$$\leq b(n, s) ||a_n||_{l_{\nu}^s} \prod_{k=1}^{n-1} ||a_k||_{l_{\nu}^1}.$$

This completes the proof.

We note that

$$||P||_{l_{\nu}^{s}} \leq \left(\sum_{m=1}^{\infty} \frac{b(m,s)}{(m-1)!} ||\phi||_{\mathcal{F}_{\nu}^{0,1}}^{m-1}\right) ||\phi||_{\dot{\mathcal{F}}_{\nu}^{s,1}}, \tag{10.6}$$

<span id="page-40-1"></span><span id="page-40-0"></span>

$$\left\| \widetilde{P} \right\|_{l_{\nu}^{s}} \le \left( \sum_{m=2}^{\infty} \frac{b(m,s)}{(m-1)!} \left\| \phi \right\|_{\mathcal{F}_{\nu}^{0,1}}^{m-1} \right) \left\| \phi \right\|_{\dot{\mathcal{F}}_{\nu}^{s,1}}. \tag{10.7}$$

To begin the proof of Lemma 14, we observe that

$$\|U_{\geq 2}\|_{\dot{\mathcal{F}}^{s,1}_{\nu}} \leq \sum_{j=1}^{8} \left\| \frac{\gamma}{4\pi} \int_{-\pi}^{\pi} \widetilde{B_{j}}(\alpha,\beta) d\beta \right\|_{\dot{\mathcal{F}}^{s,1}_{\nu}} + \left\| \frac{\gamma}{4\pi} \int_{-\pi}^{\pi} \widetilde{B_{13}}(\alpha,\beta) d\beta \right\|_{\dot{\mathcal{F}}^{s,1}_{\nu}}.$$

This means that it suffices to estimate each of the  $\dot{\mathcal{F}}_{\nu}^{s,1}$  norms on the right hand side. By Proposition 15 and (10.6), we obtain

$$\begin{split} & \sum_{k_1 \neq 0} e^{\nu(t)|k_1|} \left| k_1 \right|^s \left| \frac{\gamma}{4\pi} \int_{-\pi}^{\pi} \mathcal{F}(\widetilde{B_{1,1}})(k_1,\beta) d\beta \right| \\ & \leq \sum_{j_1 + j_2 + n \geq 1} \frac{C_n}{2j_1! j_2!} b(j_1 + j_2 + n + 1, s) \\ & \cdot \left( \|\phi\|_{\dot{\mathcal{F}}^{s,1}_{\nu}} \|\phi\|_{\mathcal{F}^{0,1}_{\nu}}^{j_1 + j_2} \left( e^{\|\phi\|_{\mathcal{F}^{0,1}_{\nu}}} - 1 \right)^n (j_1 + j_2 + 1) \right. \\ & + \left. \left( \sum_{m=1}^{\infty} \frac{b(m,s)}{(m-1)!} \|\phi\|_{\mathcal{F}^{0,1}_{\nu}}^{m-1} \right) \|\phi\|_{\dot{\mathcal{F}}^{s,1}_{\nu}} \|\phi\|_{\mathcal{F}^{0,1}_{\nu}}^{j_1 + j_2 + 1} \left( e^{\|\phi\|_{\mathcal{F}^{0,1}_{\nu}}} - 1 \right)^{n-1} \cdot n \right). \end{split}$$

By Proposition 15 and (10.6), we obtain

$$\begin{split} & \sum_{k_1 \neq 0} e^{\nu(t)|k_1|} \left| k_1 \right|^s \left| \frac{\gamma}{4\pi} \int_{-\pi}^{\pi} \mathcal{F}(\widetilde{B_{1,2}})(k_1, \beta) d\beta \right| \\ \leq & \sum_{j_1 + j_2 + j_3 \geq 1} \frac{C_1}{2j_1! j_2! j_3!} b(j_1 + j_2 + 2, s) \\ & \cdot \left( \|\phi\|_{\dot{\mathcal{F}}_{\nu}^{s,1}} \|\phi\|_{\dot{\mathcal{F}}_{\nu}^{0,1}}^{j_1 + j_2 + j_3 - 1} \left( e^{\|\phi\|_{\mathcal{F}_{\nu}^{0,1}}} - 1 \right) \cdot (j_1 + j_2) \right. \\ & + b(j_3, s) \|\phi\|_{\dot{\mathcal{F}}_{\nu}^{s,1}} \|\phi\|_{\mathcal{F}_{\nu}^{0,1}} \cdot j_3 \cdot \|\phi\|_{\dot{\mathcal{F}}_{\nu}^{0,1}}^{j_1 + j_2} \left( e^{\|\phi\|_{\mathcal{F}_{\nu}^{0,1}}} - 1 \right) \\ & + \left( \sum_{m=1}^{\infty} \frac{b(m, s)}{(m-1)!} \|\phi\|_{\mathcal{F}_{\nu}^{0,1}}^{m-1} \right) \|\phi\|_{\dot{\mathcal{F}}_{\nu}^{s,1}} \|\phi\|_{\dot{\mathcal{F}}_{\nu}^{0,1}}^{j_1 + j_2 + j_3} \right). \end{split}$$

By (10.7), we obtain

$$\sum_{k_1 \neq 0} e^{\nu(t)|k_1|} |k_1|^s \left| \frac{\gamma}{4\pi} \int_{-\pi}^{\pi} \mathcal{F}(\widetilde{B_{1,3}})(k_1, \beta) d\beta \right|$$

$$\leq \frac{C_1}{2} \left( \sum_{m=2}^{\infty} \frac{b(m, s)}{(m-1)!} \|\phi\|_{\mathcal{F}_{\nu}^{0, 1}}^{m-1} \right) \|\phi\|_{\dot{\mathcal{F}}_{\nu}^{s, 1}}.$$

Calculations associated with the rest of the terms in (10.2) can be done similarly. This completes the proof of Lemma 14.

## <span id="page-41-0"></span>11 Estimating $(U_{\geq 2})_{\alpha}$

In Section 10, we derived that

$$U_{\geq 2}(\alpha) = \operatorname{Re}\left(\frac{\gamma}{4\pi} \int_{-\pi}^{\pi} B(\alpha, \beta) d\beta\right),$$

where

<span id="page-41-1"></span>
$$B(\alpha, \beta) = \sum_{j=1}^{8} \widetilde{B_j}(\alpha, \beta) + \widetilde{B_{13}}(\alpha, \beta).$$
(11.1)

To estimate the  $\dot{\mathcal{F}}_{\nu}^{s,1}$  norm of  $(U_{\geq 2})_{\alpha}$ , we differentiate the right hand side with respect to  $\alpha$ . For example, recalling that

$$\widetilde{B}_1(\alpha,\beta) = \widetilde{B}_{1,1}(\alpha,\beta) + \widetilde{B}_{1,2}(\alpha,\beta) + \widetilde{B}_{1,3}(\alpha,\beta),$$

we note that

$$(\widetilde{B_{1,1}})_{\alpha}(\alpha,\beta) = \sum_{j=1}^{4} B_{1,1}^{j}(\alpha,\beta),$$

where

$$B_{1,1}^{1}(\alpha,\beta) = -\sum_{j_1+j_2+n\geq 1} \frac{-i\beta e^{2i\beta}}{1 - e^{i\beta}} \cdot \frac{(-1)^{j_1+1}i^{j_1+j_2+1}}{2j_1!j_2!} j_1 \phi(\alpha - \beta)^{j_1-1}$$
$$\cdot \phi_{\alpha}(\alpha - \beta)\phi(\alpha)^{j_2} \int_0^1 e^{-i\beta s} \phi(\alpha + \beta(-1+s))(-1+s) ds$$
$$\cdot \left(\sum_{m=1}^{\infty} \frac{i\beta}{1 - e^{i\beta}} \int_0^1 e^{-i(s-1)\beta} \frac{(-i\phi(\alpha + (s-1)\beta))^m}{m!} ds\right)^n,$$

$$\begin{split} B_{1,1}^2(\alpha,\beta) &= -\sum_{j_1+j_2+n\geq 1} \frac{-i\beta e^{2i\beta}}{1-e^{i\beta}} \cdot \frac{(-1)^{j_1+1}i^{j_1+j_2+1}}{2j_1!j_2!} \phi(\alpha-\beta)^{j_1}j_2\phi(\alpha)^{j_2-1}\phi_{\alpha}(\alpha) \\ & \cdot \int_0^1 e^{-i\beta s}\phi(\alpha+\beta(-1+s))(-1+s)ds \\ & \cdot \left(\sum_{m=1}^\infty \frac{i\beta}{1-e^{i\beta}} \int_0^1 e^{-i(s-1)\beta} \frac{(-i\phi(\alpha+(s-1)\beta))^m}{m!} ds\right)^n \\ B_{1,1}^3(\alpha,\beta) &= -\sum_{j_1+j_2+n\geq 1} \frac{-i\beta e^{2i\beta}}{1-e^{i\beta}} \cdot \frac{(-1)^{j_1+1}i^{j_1+j_2+1}}{2j_1!j_2!} \phi(\alpha-\beta)^{j_1}\phi(\alpha)^{j_2} \\ & \cdot \int_0^1 e^{-i\beta s}\phi_{\alpha}(\alpha+\beta(-1+s))(-1+s)ds \\ & \cdot \left(\sum_{m=1}^\infty \frac{i\beta}{1-e^{i\beta}} \int_0^1 e^{-i(s-1)\beta} \frac{(-i\phi(\alpha+(s-1)\beta))^m}{m!} ds\right)^n, \\ B_{1,1}^4(\alpha,\beta) &= -\sum_{j_1+j_2+n\geq 1} \frac{-i\beta e^{2i\beta}}{1-e^{i\beta}} \cdot \frac{(-1)^{j_1+1}i^{j_1+j_2+1}}{2j_1!j_2!} \phi(\alpha-\beta)^{j_1}\phi(\alpha)^{j_2} \\ & \cdot \int_0^1 e^{-i\beta s}\phi(\alpha+\beta(-1+s))(-1+s)ds \\ & \cdot n\left(\sum_{m=1}^\infty \frac{i\beta}{1-e^{i\beta}} \int_0^1 e^{-i(s-1)\beta} \frac{(-i\phi(\alpha+(s-1)\beta))^m}{m!} ds\right)^{n-1} \\ & \cdot \left(\sum_{m=1}^\infty \frac{i\beta}{1-e^{i\beta}} \right. \\ & \cdot \int_0^1 e^{-i(s-1)\beta} \frac{m(-i\phi(\alpha+(s-1)\beta))^{m-1}(-i)\phi_{\alpha}(\alpha+(s-1)\beta)}{m!} ds\right). \end{split}$$

After differentiation, certain terms contain the second derivative of  $\phi$ . To such terms, we apply integration by parts to re-express them in terms of lower-order derivatives of  $\phi$ .

# <span id="page-42-0"></span>11.1 Estimating Fourier Modes of $(U_{\geq 2})_{\alpha}$

We use arguments as in Section 10.1 to estimate the Fourier modes of  $(U_{\geq 2})_{\alpha}$ . For example,

$$\left| \frac{\gamma}{4\pi} \int_{-\pi}^{\pi} \mathcal{F}(B_{1,1}^{1})(k_{1},\beta) d\beta \right| \leq \sum_{j_{1}+j_{2}+n\geq 1} \frac{j_{1}C_{n}}{2j_{1}!j_{2}!} \sum_{k_{2},\dots,k_{j_{1}+j_{2}+n+1}\in\mathbb{Z}} \prod_{d=1}^{j_{1}-1} |\mathcal{F}(\phi)(k_{d}-k_{d+1})| \cdot |\mathcal{F}(\phi')(k_{j_{1}}-k_{j_{1}+1})| \cdot \prod_{d=j_{1}+j_{2}+1}^{j_{1}+j_{2}+n} |\mathcal{F}(\phi)(k_{d}-k_{d+1})| \cdot |\mathcal{F}(\phi)(k_{j_{1}+j_{2}+n+1})| \cdot \prod_{d=j_{1}+j_{2}+1}^{j_{1}+j_{2}+n} |\mathcal{F}(k_{d}-k_{d+1})| \cdot |\mathcal{F}(\phi)(k_{j_{1}+j_{2}+n+1})| \cdot |\mathcal{F}(\phi)(k_{j_{1}+j_{2}+n+1})| \cdot |\mathcal{F}(\phi)(k_{j_{1}+j_{2}+n+1})| \cdot |\mathcal{F}(\phi)(k_{j_{1}+j_{2}+n+1})| \cdot |\mathcal{F}(\phi)(k_{j_{1}+j_{2}+n+1})| \cdot |\mathcal{F}(\phi)(k_{j_{1}+j_{2}+n+1})| \cdot |\mathcal{F}(\phi)(k_{j_{1}+j_{2}+n+1})| \cdot |\mathcal{F}(\phi)(k_{j_{1}+j_{2}+n+1})| \cdot |\mathcal{F}(\phi)(k_{j_{1}+j_{2}+n+1})| \cdot |\mathcal{F}(\phi)(k_{j_{1}+j_{2}+n+1})| \cdot |\mathcal{F}(\phi)(k_{j_{1}+j_{2}+n+1})| \cdot |\mathcal{F}(\phi)(k_{j_{1}+j_{2}+n+1})| \cdot |\mathcal{F}(\phi)(k_{j_{1}+j_{2}+n+1})| \cdot |\mathcal{F}(\phi)(k_{j_{1}+j_{2}+n+1})| \cdot |\mathcal{F}(\phi)(k_{j_{1}+j_{2}+n+1})| \cdot |\mathcal{F}(\phi)(k_{j_{1}+j_{2}+n+1})| \cdot |\mathcal{F}(\phi)(k_{j_{1}+j_{2}+n+1})| \cdot |\mathcal{F}(\phi)(k_{j_{1}+j_{2}+n+1})| \cdot |\mathcal{F}(\phi)(k_{j_{1}+j_{2}+n+1})| \cdot |\mathcal{F}(\phi)(k_{j_{1}+j_{2}+n+1})| \cdot |\mathcal{F}(\phi)(k_{j_{1}+j_{2}+n+1})| \cdot |\mathcal{F}(\phi)(k_{j_{1}+j_{2}+n+1})| \cdot |\mathcal{F}(\phi)(k_{j_{1}+j_{2}+n+1})| \cdot |\mathcal{F}(\phi)(k_{j_{1}+j_{2}+n+1})| \cdot |\mathcal{F}(\phi)(k_{j_{1}+j_{2}+n+1})| \cdot |\mathcal{F}(\phi)(k_{j_{1}+j_{2}+n+1})| \cdot |\mathcal{F}(\phi)(k_{j_{1}+j_{2}+n+1})| \cdot |\mathcal{F}(\phi)(k_{j_{1}+j_{2}+n+1})| \cdot |\mathcal{F}(\phi)(k_{j_{1}+j_{2}+n+1})| \cdot |\mathcal{F}(\phi)(k_{j_{1}+j_{2}+n+1})| \cdot |\mathcal{F}(\phi)(k_{j_{1}+j_{2}+n+1})| \cdot |\mathcal{F}(\phi)(k_{j_{1}+j_{2}+n+1})| \cdot |\mathcal{F}(\phi)(k_{j_{1}+j_{2}+n+1})| \cdot |\mathcal{F}(\phi)(k_{j_{1}+j_{2}+n+1})| \cdot |\mathcal{F}(\phi)(k_{j_{1}+j_{2}+n+1})| \cdot |\mathcal{F}(\phi)(k_{j_{1}+j_{2}+n+1})| \cdot |\mathcal{F}(\phi)(k_{j_{1}+j_{2}+n+1})| \cdot |\mathcal{F}(\phi)(k_{j_{1}+j_{2}+n+1})| \cdot |\mathcal{F}(\phi)(k_{j_{1}+j_{2}+n+1})| \cdot |\mathcal{F}(\phi)(k_{j_{1}+j_{2}+n+1})| \cdot |\mathcal{F}(\phi)(k_{j_{1}+j_{2}+n+1})| \cdot |\mathcal{F}(\phi)(k_{j_{1}+j_{2}+n+1})| \cdot |\mathcal{F}(\phi)(k_{j_{1}+j_{2}+n+1})| \cdot |\mathcal{F}(\phi)(k_{j_{1}+j_{2}+n+1})| \cdot |\mathcal{F}(\phi)(k_{j_{1}+j_{2}+n+1})| \cdot |\mathcal{F}(\phi)(k_{j_{1}+j_{2}+n+1})| \cdot |\mathcal{F}(\phi)(k_{j_{1}+j_{2}+n+1})| \cdot |\mathcal{F}(\phi)(k_{j_{1}+j_{2}+n+1})| \cdot |\mathcal{F}(\phi)(k_{j_{1}+j_{2}+n+1})| \cdot |\mathcal{F}(\phi)(k_{j_{1}+j_{2}+n+1})| \cdot |\mathcal{F}(\phi)(k_{$$

Calculations associated with the rest of the terms in the derivative of (11.1) can be done similarly.

# 11.2 Estimating $||(U_{\geq 2})_{\alpha}||_{\dot{\mathcal{F}}^{s,1}_{+}}$

We prove a useful estimate for  $\|(U_{\geq 2})_{\alpha}\|_{\dot{\mathcal{F}}^{s,1}_{\nu}}$ , s > 0.

<span id="page-43-1"></span>**Lemma 16.** For s > 0.

$$\begin{aligned} \|(U_{\geq 2})_{\alpha}\|_{\dot{\mathcal{F}}_{\nu}^{s,1}} &\leq R_{1}(\|\phi\|_{\mathcal{F}_{\nu}^{0,1}}) \|\phi'\|_{\mathcal{F}_{\nu}^{0,1}} \|\phi\|_{\dot{\mathcal{F}}_{\nu}^{s,1}} + R_{2}(\|\phi\|_{\mathcal{F}_{\nu}^{0,1}}) \|\phi\|_{\mathcal{F}_{\nu}^{0,1}} \|\phi'\|_{\dot{\mathcal{F}}_{\nu}^{s,1}} \\ &+ R_{3}(\|\phi\|_{\mathcal{F}_{\nu}^{0,1}}) \|\phi\|_{\mathcal{F}_{\nu}^{0,1}} \|\phi'\|_{\mathcal{F}_{\nu}^{0,1}} \|\phi\|_{\dot{\mathcal{F}}_{\nu}^{s,1}} \\ &+ R_{4}(\|\phi\|_{\mathcal{F}_{\nu}^{0,1}}) \|\phi'\|_{\mathcal{F}_{\nu}^{0,1}} \|\phi\|_{\dot{\mathcal{F}}_{\nu}^{s,1}} + R_{5}(\|\phi\|_{\mathcal{F}_{\nu}^{0,1}}) \|\phi'\|_{\mathcal{F}_{\nu}^{0,1}} \|\phi'\|_{\dot{\mathcal{F}}_{\nu}^{s,1}}, \end{aligned}$$

where  $R_1$ ,  $R_2$ ,  $R_3$ ,  $R_4$ , and  $R_5$  are monotone increasing functions of  $\|\phi\|_{\mathcal{F}^{0,1}_+}$ .

We use estimates from Section 11.1 to prove Lemma 16. For example,

$$\begin{split} & \left\| \frac{\gamma}{4\pi} \int_{-\pi}^{\pi} B_{1,1}^{1}(\alpha,\beta) d\beta \right\|_{\dot{\mathcal{F}}_{\nu}^{s,1}} \\ & \leq \sum_{j_{1}+j_{2}+n\geq 1} \frac{j_{1}C_{n}}{2j_{1}!j_{2}!} \left\| |\mathcal{F}(\phi)| * \cdots * |\mathcal{F}(\phi)| * |P| * \cdots * |P| * |\mathcal{F}(\phi')| \right\|_{l_{\nu}^{s}} \\ & \leq \sum_{j_{1}+j_{2}+n\geq 1} \frac{j_{1}C_{n}}{2j_{1}!j_{2}!} b(j_{1}+j_{2}+n+1,s) \\ & \cdot \left( \|\phi\|_{\dot{\mathcal{F}}_{\nu}^{s,1}} \|\phi\|_{\mathcal{F}_{\nu}^{0,1}}^{j_{1}+j_{2}-1} \|\phi'\|_{\mathcal{F}_{\nu}^{0,1}} \left( e^{\|\phi\|_{\mathcal{F}_{\nu}^{0,1}}-1 \right)^{n} (j_{1}+j_{2}) \right. \\ & + \left\| \phi' \right\|_{\dot{\mathcal{F}}_{\nu}^{s,1}} \|\phi\|_{\mathcal{F}_{\nu}^{0,1}}^{j_{1}+j_{2}} \left( e^{\|\phi\|_{\mathcal{F}_{\nu}^{0,1}}-1 \right)^{n} \\ & + \left( \sum_{m=1}^{\infty} \frac{b(m,s)}{(m-1)!} \|\phi\|_{\mathcal{F}_{\nu}^{0,1}}^{m-1} \right) \|\phi\|_{\dot{\mathcal{F}}_{\nu}^{s,1}} \|\phi\|_{\mathcal{F}_{\nu}^{0,1}}^{j_{1}+j_{2}} \|\phi'\|_{\mathcal{F}_{\nu}^{0,1}} \left( e^{\|\phi\|_{\mathcal{F}_{\nu}^{0,1}}-1 \right)^{n-1} \cdot n \right). \end{split}$$

Calculations associated with the rest of the terms in  $(U_{\geq 2})_{\alpha}$  can be done similarly. This completes the proof of Lemma 16.

### <span id="page-43-3"></span><span id="page-43-0"></span>12 Proof of the Main Theorem

#### 12.1 Proof of the Main a priori Estimate

To complete the estimate for the  $\dot{\mathcal{F}}_{\nu}^{s,1}$  norm of  $\widetilde{\mathcal{N}}$ , we let s=1. Recalling (8.1), we use Lemmas 9 and 10, the estimates of the  $\mathcal{F}_{\nu}^{0,1}$  norm of  $U_1$  and  $U_{\geq 2}$  in Sections 9.2 and 10.2, respectively, Lemma 16, and Proposition 1 to obtain an estimate for the  $\dot{\mathcal{F}}_{\nu}^{1,1}$  norm of  $\widetilde{\mathcal{N}}$ . We substitute this estimate of the  $\dot{\mathcal{F}}_{\nu}^{1,1}$  norm of  $\widetilde{\mathcal{N}}$  into (7.10) and use the fact that  $C_I$ , A,  $A_1^{-1}$ ,  $R_1$ ,  $R_2$ ,  $R_3$ ,  $R_4$ ,  $R_5$ ,  $D_1$ , and  $D_2$  are all monotone increasing and Proposition 1 to obtain

<span id="page-43-2"></span>
$$\frac{d}{dt} \|\phi\|_{\dot{\mathcal{F}}_{\nu}^{1,1}} \le -\left(\Lambda(\|\phi\|_{\dot{\mathcal{F}}_{\nu}^{1,1}}) - \nu'(t)\right) \|\phi\|_{\dot{\mathcal{F}}_{\nu}^{2,1}}, \tag{12.1}$$

where

$$\begin{split} \Lambda(\|\phi\|_{\dot{\mathcal{F}}_{\nu}^{1,1}}) = & \frac{1}{2\left(C_{I}(\|\phi\|_{\dot{\mathcal{F}}_{\nu}^{1,1}}) \|\phi\|_{\dot{\mathcal{F}}_{\nu}^{1,1}} + 1\right)} \pi \frac{2}{R} \frac{\gamma}{4\pi} - \frac{\gamma}{4\pi} \frac{1}{R} A(\|\phi\|_{\dot{\mathcal{F}}_{\nu}^{1,1}}) \|\phi\|_{\dot{\mathcal{F}}_{\nu}^{1,1}} \\ & - \frac{1}{R} \frac{1}{A_{1}(\|\phi\|_{\dot{\mathcal{F}}_{\nu}^{1,1}})} \left(R_{1}(\|\phi\|_{\dot{\mathcal{F}}_{\nu}^{1,1}}) \|\phi\|_{\dot{\mathcal{F}}_{\nu}^{1,1}} + R_{2}(\|\phi\|_{\dot{\mathcal{F}}_{\nu}^{1,1}}) \|\phi\|_{\dot{\mathcal{F}}_{\nu}^{1,1}} \\ & + R_{3}(\|\phi\|_{\dot{\mathcal{F}}_{\nu}^{1,1}}) \|\phi\|_{\dot{\mathcal{F}}_{\nu}^{1,1}}^{2} + R_{4}(\|\phi\|_{\dot{\mathcal{F}}_{\nu}^{1,1}}) \|\phi\|_{\dot{\mathcal{F}}_{\nu}^{1,1}}^{2} \\ & + R_{5}(\|\phi\|_{\dot{\mathcal{F}}_{\nu}^{1,1}}) \|\phi\|_{\dot{\mathcal{F}}_{\nu}^{1,1}}^{2} \\ & + 3\left(H_{3} \|\phi\|_{\dot{\mathcal{F}}_{\nu}^{1,1}} + H_{4} \|\phi\|_{\dot{\mathcal{F}}_{\nu}^{1,1}}\right) \\ & + 3\left(D_{1}(\|\phi\|_{\dot{\mathcal{F}}_{\nu}^{1,1}}) \|\phi\|_{\dot{\mathcal{F}}_{\nu}^{1,1}}^{2} + D_{2}(\|\phi\|_{\dot{\mathcal{F}}_{\nu}^{1,1}}) \|\phi\|_{\dot{\mathcal{F}}_{\nu}^{1,1}}^{2}\right) \left(1 + 2 \|\phi\|_{\dot{\mathcal{F}}_{\nu}^{1,1}}\right) \\ & + \left(D_{1}(\|\phi\|_{\dot{\mathcal{F}}_{\nu}^{1,1}}) \|\phi\|_{\dot{\mathcal{F}}_{\nu}^{1,1}} + D_{2}(\|\phi\|_{\dot{\mathcal{F}}_{\nu}^{1,1}}) \|\phi\|_{\dot{\mathcal{F}}_{\nu}^{1,1}}\right) \left(1 + 2 \|\phi\|_{\dot{\mathcal{F}}_{\nu}^{1,1}}\right) \end{split}$$

$$+6 \|\phi\|_{\dot{\mathcal{F}}_{\nu}^{1,1}} \left( H_3 \|\phi\|_{\dot{\mathcal{F}}_{\nu}^{1,1}} + H_4 \|\phi\|_{\dot{\mathcal{F}}_{\nu}^{1,1}} \right)$$

$$+2 \left( H_3 \|\phi\|_{\dot{\mathcal{F}}_{\nu}^{1,1}} + H_4 \|\phi\|_{\dot{\mathcal{F}}_{\nu}^{1,1}} \right).$$

Integrating (12.1) with respect to time, we obtain

$$\|\phi(t)\|_{\dot{\mathcal{F}}_{\nu}^{1,1}} + \int_{0}^{t} (\Lambda(\|\phi(\tau)\|_{\dot{\mathcal{F}}_{\nu}^{1,1}}) - \nu'(\tau)) \|\phi(\tau)\|_{\dot{\mathcal{F}}_{\nu}^{2,1}} d\tau \le \|\phi_{0}\|_{\dot{\mathcal{F}}^{1,1}}.$$

Choose the initial datum such that  $\Lambda(\|\phi_0\|_{\dot{\mathcal{F}}^{1,1}}) > 0$  and  $\nu_0 \in (0, \Lambda(\|\phi_0\|_{\dot{\mathcal{F}}^{1,1}}))$ . Then  $\Lambda(\|\phi_0\|_{\dot{\mathcal{F}}^{1,1}}) - \nu'(0) > 0$ . It follows that for all  $t \in [0, \infty)$ ,

$$\begin{split} \|\phi(t)\|_{\dot{\mathcal{F}}_{\nu}^{1,1}} &\leq \|\phi_{0}\|_{\dot{\mathcal{F}}^{1,1}} - \int_{0}^{t} \left(\Lambda(\|\phi(\tau)\|_{\dot{\mathcal{F}}_{\nu}^{1,1}}) - \nu'(\tau)\right) \|\phi(\tau)\|_{\dot{\mathcal{F}}_{\nu}^{2,1}} d\tau \\ &\leq \|\phi_{0}\|_{\dot{\mathcal{F}}^{1,1}} - \int_{0}^{t} \left(\Lambda(\|\phi_{0}\|_{\dot{\mathcal{F}}^{1,1}}) - \nu_{0}\right) \|\phi(\tau)\|_{\dot{\mathcal{F}}_{\nu}^{2,1}} d\tau. \end{split}$$

## 12.2 Boundedness of $\mathcal{F}(\theta)(0)$

Using the *a priori* estimate for  $\phi = \theta - \hat{\theta}(0)$  in Section 12.1, we now show that  $\hat{\theta}(0)$  is bounded in time. We take the zeroth Fourier mode of (2.15) and then integrate with respect to time to obtain

$$\begin{split} \hat{\theta}(0) - \hat{\theta}_0(0) &= \int_0^t \frac{2\pi}{L(\tau)} \mathcal{F}\bigg(T_1(\alpha)(1 + \theta_\alpha(\alpha))\bigg)(0) d\tau \\ &+ \int_0^t \frac{2\pi}{L(t)} \mathcal{F}\bigg(T_{\geq 2}(\alpha)(1 + \theta_\alpha(\alpha))\bigg)(0) d\tau. \end{split}$$

Combining the estimate

$$\left| \mathcal{F} \bigg( T_1(\alpha) (1 + \theta_{\alpha}(\alpha)) \bigg) (0) \right| \le \| T_1 \|_{\mathcal{F}^{0,1}} (1 + \| \phi \|_{\mathcal{F}^{1,1}})$$

with

$$||T_1||_{\mathcal{F}^{0,1}} \le 2 ||U_1||_{\dot{\mathcal{F}}^{0,1}_{\nu}} \le 2 ||U_1||_{\mathcal{F}^{0,1}_{\nu}} \le 2(H_3 + H_4) ||\phi||_{\dot{\mathcal{F}}^{1,1}_{\nu}}$$

$$\begin{split} \|T_{\geq 2}\|_{\mathcal{F}^{0,1}} \leq & 2\bigg(D_{1}(\|\phi\|_{\dot{\mathcal{F}}_{\nu}^{1,1}}) \|\phi\|_{\dot{\mathcal{F}}_{\nu}^{1,1}}^{2} + D_{2}(\|\phi\|_{\dot{\mathcal{F}}_{\nu}^{1,1}}) \|\phi\|_{\dot{\mathcal{F}}_{\nu}^{1,1}}^{2} \\ & + 2 \|\phi\|_{\dot{\mathcal{F}}_{\nu}^{1,1}} \left(H_{3} \|\phi\|_{\dot{\mathcal{F}}_{\nu}^{1,1}} + H_{4} \|\phi\|_{\dot{\mathcal{F}}_{\nu}^{1,1}}\right) \\ & + 2 \|\phi\|_{\dot{\mathcal{F}}_{\nu}^{1,1}} \left(D_{1}(\|\phi\|_{\dot{\mathcal{F}}_{\nu}^{1,1}}) \|\phi\|_{\dot{\mathcal{F}}_{\nu}^{1,1}}^{2} + D_{2}(\|\phi\|_{\dot{\mathcal{F}}_{\nu}^{1,1}}) \|\phi\|_{\dot{\mathcal{F}}_{\nu}^{1,1}}^{2}\right) \end{split}$$

and

$$\frac{2\pi}{L(t)} \le \frac{\sqrt{1 + \frac{\pi}{2} (e^{2\|\phi_0\|_{\dot{\mathcal{F}}^{1,1}}} - 1)}}{R},$$

we obtain

$$|\mathcal{F}(\theta)(0)| \le Y(\|\phi_0\|_{\dot{\mathcal{F}}^{1,1}}),$$

where

<span id="page-45-0"></span>
$$Y(\|\phi_0\|_{\dot{\mathcal{F}}_{1,1}}) = |\mathcal{F}(\theta_0)(0)|$$

$$+ \frac{\sqrt{1 + \frac{\pi}{2}(e^{2\|\phi_0\|_{\dot{\mathcal{F}}^{1,1}}} - 1)}}{R} 2(H_3 + H_4) \cdot \frac{\|\phi_0\|_{\dot{\mathcal{F}}_{1,1}}}{\Lambda(\|\phi_0\|_{\dot{\mathcal{F}}_{1,1}}) - \nu_0}$$

$$+ \frac{\sqrt{1 + \frac{\pi}{2}(e^{2\|\phi_0\|_{\dot{\mathcal{F}}^{1,1}}} - 1)}}{R} \cdot 2(H_3 + H_4) \|\phi_0\|_{\dot{\mathcal{F}}_{1,1}} \cdot \frac{\|\phi_0\|_{\dot{\mathcal{F}}_{1,1}}}{\Lambda(\|\phi_0\|_{\dot{\mathcal{F}}_{1,1}}) - \nu_0}$$

$$+ \frac{\sqrt{1 + \frac{\pi}{2}(e^{2\|\phi_0\|_{\dot{\mathcal{F}}^{1,1}}} - 1)}}{R}$$

$$\cdot 2\left(D_1(\|\phi_0\|_{\dot{\mathcal{F}}_{1,1}}) \|\phi_0\|_{\dot{\mathcal{F}}_{1,1}} + D_2(\|\phi_0\|_{\dot{\mathcal{F}}_{1,1}}) \|\phi_0\|_{\dot{\mathcal{F}}_{1,1}}\right)$$

$$+ 2\left(H_3 \|\phi_0\|_{\dot{\mathcal{F}}_{1,1}} + H_4 \|\phi_0\|_{\dot{\mathcal{F}}_{1,1}}\right)$$

$$+ 2\left(D_1(\|\phi_0\|_{\dot{\mathcal{F}}_{1,1}}) \|\phi_0\|_{\dot{\mathcal{F}}_{1,1}}^2 + D_2(\|\phi_0\|_{\dot{\mathcal{F}}_{1,1}}) \|\phi_0\|_{\dot{\mathcal{F}}_{1,1}}^2\right)$$

$$\cdot \frac{\|\phi_0\|_{\dot{\mathcal{F}}_{1,1}}}{\Lambda(\|\phi_0\|_{\dot{\mathcal{F}}_{1,1}}) - \nu_0}$$

$$+ \frac{\sqrt{1 + \frac{\pi}{2}(e^{2\|\phi_0\|_{\dot{\mathcal{F}}_{1,1}} - 1)}}{R}}{R}$$

$$\cdot 2\left(D_1(\|\phi_0\|_{\dot{\mathcal{F}}_{1,1}}) \|\phi_0\|_{\dot{\mathcal{F}}_{1,1}}^2 + D_2(\|\phi_0\|_{\dot{\mathcal{F}}_{1,1}}) \|\phi_0\|_{\dot{\mathcal{F}}_{1,1}}^2\right)$$

$$+ 2\|\phi_0\|_{\dot{\mathcal{F}}_{1,1}} \left(H_3 \|\phi_0\|_{\dot{\mathcal{F}}_{1,1}} + H_4 \|\phi_0\|_{\dot{\mathcal{F}}_{1,1}}\right)$$

$$+ 2\|\phi_0\|_{\dot{\mathcal{F}}_{1,1}} \left(D_1(\|\phi_0\|_{\dot{\mathcal{F}}_{1,1}}) \|\phi_0\|_{\dot{\mathcal{F}}_{1,1}}^2 + D_2(\|\phi_0\|_{\dot{\mathcal{F}}_{1,1}}) \|\phi_0\|_{\dot{\mathcal{F}}_{1,1}}^2\right)$$

$$\cdot \frac{\|\phi_0\|_{\dot{\mathcal{F}}_{1,1}}}{\Lambda(\|\phi_0\|_{\dot{\mathcal{F}}_{1,1}}) - \nu_0}.$$

Hence,  $\mathcal{F}(\theta)(0)$  is bounded in time.

#### 12.3 Regularization Argument

In this Section, we outline an argument to prove Theorem 5. We first regularize the original evolution equations for the interface for each  $N \in \mathbb{N}$ . The sequence of solutions to these regularized equations yields a solution to the original evolution equations for the interface. To obtain a solution to each regularized equation, we employ Picard's theorem in the Banach space setting as stated in Theorems 3.1 and 3.3 of [35]. To obtain a candidate for a solution to the original evolution equations for the interface, we use the Aubin-Lions lemma as stated in Lemma 7.5 of [29].

#### 12.3.1 Regularized Equations for Interface Dynamics

We recall that, under HLS parametrization, the dynamics of the interface are governed by

<span id="page-45-1"></span>
$$\theta_t(\alpha) = \frac{2\pi}{L(t)} (U_\alpha(\theta)(\alpha) + T(\theta)(\alpha)(1 + \theta_\alpha(\alpha))), \tag{12.3}$$

$$L(t) = 2\pi R \left( 1 + \frac{1}{2\pi} \text{Im} \int_{-\pi}^{\pi} \int_{0}^{\alpha} e^{i(\alpha - \eta)} \sum_{n \ge 1} \frac{i^{n}}{n!} (\theta(\alpha) - \theta(\eta))^{n} d\eta d\alpha \right)^{-\frac{1}{2}}.$$
 (12.4)

For each  $N \in \mathbb{N}$ , we define the regularized ordinary differential equation for the interface

$$\frac{d\theta_N}{dt} = (\mathcal{J}_N^1 \circ G_N)(\theta_N),$$

where  $\mathcal{J}_N^1$  is the high frequency cut-off operator introduced in (2.6) and

$$G_N(\theta_N) = R^{-1} \left( 1 + \frac{1}{2\pi} \operatorname{Im} \int_{-\pi}^{\pi} \int_0^{\alpha} e^{i(\alpha - \eta)} \sum_{n \ge 1} \frac{i^n}{n!} (\theta_N(\alpha) - \theta_N(\eta))^n d\eta d\alpha \right)^{\frac{1}{2}} \cdot \left( (U_\alpha)_N(\theta_N) + T_N(\theta_N) \left( 1 + (\theta_N)_\alpha \right) \right),$$

in which

$$(U_{\alpha})_{N}(\theta_{N})(\alpha) = (\mathcal{J}_{N} \circ \operatorname{Re}) \Big( W(\theta_{N})(\alpha) \Big)$$

$$U_{N}(\theta_{N})(\alpha) = (\mathcal{J}_{N} \circ \operatorname{Re}) \Big( V(\theta_{N})(\alpha) \Big)$$

$$T_{N}(\theta_{N})(\alpha) = \mathcal{M} \Big( \Big( 1 + (\theta_{N})_{\alpha}(\alpha) \Big) U_{N}(\theta_{N})(\alpha) \Big),$$

 $\mathcal{J}_N$  is the high frequency cut-off operator defined in (2.5), and

$$V(\theta_{N})(\alpha) = \sum_{j=1}^{7} \frac{\gamma}{4\pi} \int_{-\pi}^{\pi} E_{j}(\theta_{N})(\alpha, \beta) d\beta$$

$$+ \sum_{j=1}^{8} \frac{\gamma}{4\pi} \int_{-\pi}^{\pi} \widetilde{B}_{j}(\theta_{N})(\alpha, \beta) d\beta + \frac{\gamma}{4\pi} \int_{-\pi}^{\pi} \widetilde{B}_{13}(\theta_{N})(\alpha, \beta) d\beta,$$

$$W(\theta_{N})(\alpha) = V_{\alpha}(\theta_{N})(\alpha)$$

$$= \sum_{j=1}^{7} \frac{\gamma}{4\pi} \int_{-\pi}^{\pi} (E_{j})_{\alpha}(\theta_{N})(\alpha, \beta) d\beta$$

$$+ \sum_{j=1}^{8} \frac{\gamma}{4\pi} \int_{-\pi}^{\pi} (\widetilde{B}_{j})_{\alpha}(\theta_{N})(\alpha, \beta) d\beta + \frac{\gamma}{4\pi} \int_{-\pi}^{\pi} (\widetilde{B}_{13})_{\alpha}(\theta_{N})(\alpha, \beta) d\beta.$$

#### 12.3.2 Applying Picard's Theorem

We need to specify an appropriate Banach space for Picard's theorem. Due to HLS parametrization,

<span id="page-46-0"></span>
$$\int_{-\pi}^{\pi} e^{i(\alpha + \phi(\alpha, t))} d\alpha = 0, \tag{12.5}$$

which constrains the  $\pm 1$  Fourier modes of  $\phi(\alpha, t)$  to be completely determined by the rest of its nonzero Fourier modes. For this reason, we seek from the outset a solution whose  $\pm 1$  Fourier modes remain zero in time. For each  $N \in \mathbb{N}$ , let

$$H_N^m = \left\{ f \in H^m([-\pi, \pi)) : \operatorname{supp}(\hat{f}) \subseteq [-N, N], \ \hat{f}(\pm 1) = 0, \operatorname{Im}(f) = 0 \right\},$$

which is a Banach space. For M > 0, let

$$O^M = \{ f \in H_N^m : ||f||_{H_m} < M \}.$$

For sufficiently small M > 0, the conditions for Picard's theorem are met with  $B = H_N^m$ ,  $O = O^M$ , and  $F = \mathcal{J}_N^1 \circ G_N$ . By Picard's theorem, we obtain that, for any  $\theta_{N,0} \in O^M$ , there exists a time  $T_N > 0$  such that the ordinary differential equation

<span id="page-47-1"></span>
$$\frac{d\theta_N}{dt} = (\mathcal{J}_N^1 \circ G_N)(\theta_N), 
\theta_N(0) = \theta_{N,0} \in O^M$$
(12.6)

has a unique local solution  $\theta_N \in C^1([0, T_N); O^M)$ .

#### <span id="page-47-3"></span>12.3.3 Derivation of an a priori Estimate

For each  $N \in \mathbb{N}$ , define  $\phi_N(\alpha, t) = \theta_N(\alpha, t) - \hat{\theta}_N(0, t)$ . Then we may write

<span id="page-47-2"></span><span id="page-47-0"></span>
$$\frac{d\theta_N}{dt} = \mathcal{L}_N(\theta_N) + \mathcal{N}_N(\theta_N), \tag{12.7}$$

where  $\mathcal{L}_N(\theta_N)$  and  $\mathcal{N}_N(\theta_N)$  are the parts of the right hand side of (12.6) which are linear and superlinear in the variable  $\theta_N$ , respectively. The estimates presented in Sections 9, 10, and 11 and Lemmas 9 and 10 can be used to bound the right hand side of (12.7). Ultimately, we obtain

$$\frac{d}{dt} \|\phi_N\|_{\dot{\mathcal{F}}_{\nu}^{1,1}} \le -\left(\widetilde{\Lambda}(\|\phi_N\|_{\dot{\mathcal{F}}_{\nu}^{1,1}}) - \nu'(t)\right) \|\phi_N\|_{\dot{\mathcal{F}}_{\nu}^{2,1}},$$

where

$$\widetilde{\Lambda}(\|\phi_{N}\|_{\dot{\mathcal{F}}_{\nu}^{1,1}}) = \pi \frac{2}{R} \frac{\gamma}{4\pi} - \frac{\gamma}{4\pi} \frac{1}{R} A(\|\phi_{N}\|_{\dot{\mathcal{F}}_{\nu}^{1,1}}) \|\phi_{N}\|_{\dot{\mathcal{F}}_{\nu}^{1,1}} \\
- \frac{1}{R} \frac{1}{A_{1}(\|\phi_{N}\|_{\dot{\mathcal{F}}_{\nu}^{1,1}})} \\
\cdot \left( R_{1}(\|\phi_{N}\|_{\dot{\mathcal{F}}_{\nu}^{1,1}}) \|\phi_{N}\|_{\dot{\mathcal{F}}_{\nu}^{1,1}} + R_{2}(\|\phi_{N}\|_{\dot{\mathcal{F}}_{\nu}^{1,1}}) \|\phi_{N}\|_{\dot{\mathcal{F}}_{\nu}^{1,1}} \\
+ R_{3}(\|\phi_{N}\|_{\dot{\mathcal{F}}_{\nu}^{1,1}}) \|\phi_{N}\|_{\dot{\mathcal{F}}_{\nu}^{1,1}}^{2} + R_{4}(\|\phi_{N}\|_{\dot{\mathcal{F}}_{\nu}^{1,1}}) \|\phi_{N}\|_{\dot{\mathcal{F}}_{\nu}^{1,1}}^{2} \\
+ R_{5}(\|\phi_{N}\|_{\dot{\mathcal{F}}_{\nu}^{1,1}}) \|\phi_{N}\|_{\dot{\mathcal{F}}_{\nu}^{1,1}}^{2} + R_{4}(\|\phi_{N}\|_{\dot{\mathcal{F}}_{\nu}^{1,1}}) \|\phi_{N}\|_{\dot{\mathcal{F}}_{\nu}^{1,1}}^{2} \\
+ 3 \left( H_{3} \|\phi_{N}\|_{\dot{\mathcal{F}}_{\nu}^{1,1}} + H_{4} \|\phi_{N}\|_{\dot{\mathcal{F}}_{\nu}^{1,1}} \right) \\
+ 3 \left( D_{1}(\|\phi_{N}\|_{\dot{\mathcal{F}}_{\nu}^{1,1}}) \|\phi_{N}\|_{\dot{\mathcal{F}}_{\nu}^{1,1}}^{2} + D_{2}(\|\phi_{N}\|_{\dot{\mathcal{F}}_{\nu}^{1,1}}) \|\phi_{N}\|_{\dot{\mathcal{F}}_{\nu}^{1,1}} \right) \\
\cdot \left( 1 + 2 \|\phi_{N}\|_{\dot{\mathcal{F}}_{\nu}^{1,1}} \right) \\
+ \left( D_{1}(\|\phi_{N}\|_{\dot{\mathcal{F}}_{\nu}^{1,1}}) \|\phi_{N}\|_{\dot{\mathcal{F}}_{\nu}^{1,1}} + D_{2}(\|\phi_{N}\|_{\dot{\mathcal{F}}_{\nu}^{1,1}}) \|\phi_{N}\|_{\dot{\mathcal{F}}_{\nu}^{1,1}} \right) \\
\cdot \left( 1 + 2 \|\phi_{N}\|_{\dot{\mathcal{F}}_{\nu}^{1,1}} \right) \\
+ 6 \|\phi_{N}\|_{\dot{\mathcal{F}}_{\nu}^{1,1}} \left( H_{3} \|\phi_{N}\|_{\dot{\mathcal{F}}_{\nu}^{1,1}} + H_{4} \|\phi_{N}\|_{\dot{\mathcal{F}}_{\nu}^{1,1}} \right) \\
+ 2 \left( H_{3} \|\phi_{N}\|_{\dot{\mathcal{F}}_{\nu}^{1,1}} + H_{4} \|\phi_{N}\|_{\dot{\mathcal{F}}_{\nu}^{1,1}} \right) \right). \tag{12.8}}$$

Let  $\theta^0 \in \dot{\mathcal{F}}^{1,1}$ ,  $\operatorname{Im}(\theta^0) = 0$ , such that  $\widetilde{\Lambda}(\|\theta^0\|_{\dot{\mathcal{F}}^{1,1}}) > 0$ . To ensure that  $\widetilde{\Lambda}(\|\theta^0\|_{\dot{\mathcal{F}}^{1,1}})$  is well-defined, we choose  $\|\theta^0\|_{\dot{\mathcal{F}}^{1,1}}$  small enough so that all of the geometric series contained in this expression converge. We further require that

$$|\mathcal{F}(\theta^0)(0)| + Y(\|\theta^0\|_{\dot{\mathcal{F}}^{1,1}}) + 2^{1/2} \|\theta^0\|_{\dot{\mathcal{F}}^{1,1}} < M,$$

where the function Y is defined in (12.2). This condition ensures that the solution to the original evolution equations for the interface is global in time. For each  $N \in \mathbb{N}$ , let  $\theta_{N,0} = \mathcal{J}_N^1 \theta^0 \in H_N^m$ . Letting

$$\phi^{0} = \theta^{0} - \hat{\theta^{0}}(0)$$
$$\phi_{N,0} = \hat{\theta_{N,0}} - \hat{\theta_{N,0}}(0),$$

we choose  $\nu_0$  such that  $0 < \nu_0 < \Lambda(\|\phi^0\|_{\dot{\mathcal{F}}^{1,1}}) < \Lambda(\|\phi_{N,0}\|_{\dot{\mathcal{F}}^{1,1}})$ . It follows that for all  $t \in [0, T_N)$ ,

$$\|\phi_N(t)\|_{\dot{\mathcal{F}}^{1,1}_{\nu}} + \left(\Lambda(\|\theta^0\|_{\dot{\mathcal{F}}^{1,1}}) - \nu_0\right) \int_0^t \|\phi_N(\tau)\|_{\dot{\mathcal{F}}^{2,1}_{\nu}} d\tau \le \|\theta^0\|_{\dot{\mathcal{F}}^{1,1}}.$$

Then, for all  $t \in [0, T_N)$ ,

$$\frac{d}{dt} \|\phi_N\|_{\dot{\mathcal{F}}^{1,1}_{\nu}} \le -\left(\Lambda(\|\phi_{N,0}\|_{\dot{\mathcal{F}}^{1,1}}) - \nu_0\right) \|\phi_N\|_{\dot{\mathcal{F}}^{1,1}_{\nu}},$$

which implies that  $\|\phi_N\|_{\dot{\mathcal{F}}^{1,1}}$  decays exponentially on  $[0,T_N)$ .

#### 12.3.4 A Remark on the Solution Being Global in Time

The global-in-time nature of the solution to the original evolution equations for the interface is inherited from that of the solutions to the regularized equations. The latter is a consequence of the continuation property of Picard's theorem in the Banach space setting and that the zeroth Fourier mode of  $\theta_N$  is bounded in time.

#### 12.3.5 Applying Aubin-Lions' Lemma

To apply Aubin-Lions' lemma, we set  $X_0 = \dot{\mathcal{F}}_{\nu}^{2,1}$ ,  $X = \dot{\mathcal{F}}_{\nu}^{1,1}$ ,  $X_1 = \dot{\mathcal{F}}_{\nu}^{0,1}$ ,  $p = \infty$ , and let  $G = \{\theta_N : N \in \mathbb{N}\}$ . By Aubin-Lions' lemma, G is relatively compact in  $L^2([0,T];\dot{\mathcal{F}}_{\nu}^{1,1})$ . This means that there exists a subsequence convergent in  $L^2([0,T];\dot{\mathcal{F}}_{\nu}^{1,1})$ . That is, there exists  $\theta \in L^2([0,T];\dot{\mathcal{F}}_{\nu}^{1,1})$  such that  $\theta_N \to \theta$  in  $L^2([0,T];\dot{\mathcal{F}}_{\nu}^{1,1})$  as  $N \to \infty$ , where for notational convenience we continue to use  $\theta_N$  to denote the subsequence. Our application of Aubin-Lions' lemma provides a candidate for a solution to the original problem, but it remains silent on the dynamics of  $\mathcal{F}(\theta(t))(0)$ . Part of our task is to specify its dynamics. We first articulate the sense in which  $\theta$  is to become a solution.

<span id="page-48-1"></span>**Definition 17.** We say that  $\theta \in L^{\infty}([0,T]; \dot{\mathcal{F}}_{\nu}^{1,1}) \cap L^{1}([0,T]; \dot{\mathcal{F}}_{\nu}^{2,1})$  is a weak solution of (12.3) through (12.5) if for any  $\psi \in C_{0}^{\infty}([-\pi,\pi) \times [0,T])$ ,

$$\begin{split} &\int_{-\pi}^{\pi} \theta(\alpha,T) \psi(\alpha,T) d\alpha - \int_{-\pi}^{\pi} \theta(\alpha,0) \psi(\alpha,0) d\alpha - \int_{-\pi}^{\pi} \int_{0}^{T} \theta(\alpha,t) \psi_{t}(\alpha,t) dt d\alpha \\ &= \int_{-\pi}^{\pi} \int_{0}^{T} R^{-1} \bigg( 1 + \frac{1}{2\pi} \mathrm{Im} \int_{-\pi}^{\pi} \int_{0}^{\alpha} e^{i(\alpha-\eta)} \sum_{n \geq 1} \frac{i^{n}}{n!} (\theta(\alpha,t) - \theta(\eta,t))^{n} d\eta d\alpha \bigg)^{1/2} \\ &\cdot \bigg( U_{\alpha}(\theta)(\alpha,t) + T(\theta)(\alpha,t) (1 + \theta_{\alpha}(\alpha,t)) \bigg) \psi(\alpha,t) dt d\alpha. \end{split}$$

Let  $\phi(t) = \theta(t) - \mathcal{F}(\theta(t))(0)$ . We specify the dynamics of  $\mathcal{F}(\theta)(0)$  by requiring that

<span id="page-48-0"></span>
$$\frac{d}{dt}\mathcal{F}(\theta)(0) = \frac{2\pi}{L(\phi)} \left( U_{\alpha}(\phi) + T(\phi)(1 + \phi_{\alpha}) \right) - \frac{d}{dt}\phi$$
(12.9)

with the initial condition  $\mathcal{F}(\theta(0))(0) = \mathcal{F}(\theta^0)(0)$ . The dynamics equation (12.9) for  $\mathcal{F}(\theta)(0)$  implies that  $\theta$  is indeed a solution to the original problem in the sense of Definition 17.

12.3.6 Inheritance of the a priori Estimate

At the end of Section 12.3.3, we obtained that for all  $t \in [0, T]$ .

$$\|\phi_N(t)\|_{\dot{\mathcal{F}}_{\nu}^{1,1}} + \left(\Lambda(\|\theta^0\|_{\dot{\mathcal{F}}^{1,1}}) - \nu_0\right) \int_0^t \|\phi_N(\tau)\|_{\dot{\mathcal{F}}_{\nu}^{2,1}} d\tau \le \|\theta^0\|_{\dot{\mathcal{F}}^{1,1}}.$$

By Fatou's lemma, for any  $t \in [0, T]$ ,

$$\int_0^t \liminf_{N \to \infty} \|\phi_N(\tau)\|_{\dot{\mathcal{F}}^{2,1}_{\nu}} \, d\tau \leq \liminf_{N \to \infty} \int_0^t \|\phi_N(\tau)\|_{\dot{\mathcal{F}}^{2,1}_{\nu}} \, d\tau.$$

Using that

$$\liminf_{N \to \infty} \|\phi_N(t)\|_{\dot{\mathcal{F}}_{\nu}^{1,1}} = \|\phi(t)\|_{\dot{\mathcal{F}}_{\nu}^{1,1}}, 
\liminf_{N \to \infty} \|\phi_N(t)\|_{\dot{\mathcal{F}}_{\nu}^{2,1}} = \|\phi(t)\|_{\dot{\mathcal{F}}_{\nu}^{2,1}},$$

we then obtain that for all  $t \in [0, T]$ 

$$\begin{split} &\|\phi(t)\|_{\dot{\mathcal{F}}_{\nu}^{1,1}} + \left(\Lambda(\|\theta^{0}\|_{\dot{\mathcal{F}}^{1,1}}) - \nu_{0}\right) \int_{0}^{t} \|\phi(\tau)\|_{\dot{\mathcal{F}}_{\nu}^{2,1}} d\tau \\ &\leq \liminf_{N \to \infty} \|\phi_{N}(t)\|_{\dot{\mathcal{F}}_{\nu}^{1,1}} + \left(\Lambda(\|\theta^{0}\|_{\dot{\mathcal{F}}^{1,1}}) - \nu_{0}\right) \liminf_{N \to \infty} \int_{0}^{t} \|\phi_{N}(\tau)\|_{\dot{\mathcal{F}}_{\nu}^{2,1}} d\tau \\ &\leq \liminf_{N \to \infty} \left(\|\phi_{N}(t)\|_{\dot{\mathcal{F}}_{\nu}^{1,1}} + \left(\Lambda(\|\theta^{0}\|_{\dot{\mathcal{F}}^{1,1}}) - \nu_{0}\right) \int_{0}^{t} \|\phi_{N}(\tau)\|_{\dot{\mathcal{F}}_{\nu}^{2,1}} d\tau \right) \\ &\leq \|\theta^{0}\|_{\dot{\mathcal{F}}^{1,1}}. \end{split}$$

As a consequence,

$$\theta \in L^{\infty}([0,T]; \dot{\mathcal{F}}_{\nu}^{1,1}) \cap L^{1}([0,T]; \dot{\mathcal{F}}_{\nu}^{2,1})$$

and  $\|\phi(t)\|_{\dot{\mathcal{F}}^{1,1}_{\nu}}$  decays exponentially on [0,T].

12.3.7 Continuity in Time and Instantaneous Analyticity

That  $\theta \in C([0,T]; \dot{\mathcal{F}}_{\nu}^{1,1})$  follows from arguments similar to those outlined in [36]. That  $\theta$  is instantaneously analytic is due to the exponential weight in the  $\|\cdot\|_{\dot{\mathcal{F}}_{\nu}^{1,1}}$  norm of  $\theta(\cdot,t)$  for any t>0.

# <span id="page-49-0"></span>13 Uniqueness

Let  $\theta_1$  and  $\theta_2$  be two solutions to the original problem with the same initial datum, where the  $\pm 1$  Fourier modes remain zero in time. We may write

$$\|\theta_1 - \theta_2\|_{\dot{\mathcal{F}}^{1,1}} = \sum_{k \neq 0} |k| |\mathcal{F}(\theta_1 - \theta_2)(k)| = 2 \sum_{k>0} |k| |\mathcal{F}(\theta_1 - \theta_2)(k)|.$$

Differentiating this equation with respect to time and then using estimates analogous to those contained in earlier Sections, we can obtain that, for sufficiently small  $\|\theta^0\|_{\dot{\Xi}^{1,1}}$ ,

$$\frac{d}{dt} \|\phi_1 - \phi_2\|_{\dot{\mathcal{F}}^{1,1}} \le \mathcal{E} \|\phi_1 - \phi_2\|_{\mathcal{F}^{1,1}},$$

where  $\mathcal{E}$  is a coefficient that depends on  $\|\phi_1\|_{\dot{\mathcal{F}}^{1,1}}$ ,  $\|\phi_2\|_{\dot{\mathcal{F}}^{1,1}}$ ,  $\|\phi_1\|_{\dot{\mathcal{F}}^{2,1}}$ , and  $\|\phi_2\|_{\dot{\mathcal{F}}^{2,1}}$  such that  $\mathcal{E}$  is integrable in time. Since the two solutions share the same initial datum,  $\phi_1 = \phi_2$  by Grönwall's inequality. Moreover,  $\mathcal{F}(\theta_1)(0) = \mathcal{F}(\theta_2)(0)$  since the dynamics of  $\mathcal{F}(\theta_1)(0)$  and  $\mathcal{F}(\theta_2)(0)$  are determined completely by  $\phi_1$  and  $\phi_2$ , respectively, and they share the same initial condition  $\mathcal{F}(\theta^0)(0)$ .

## <span id="page-50-0"></span>14 Acknowledgements

This work was supported in part by the NSF under Grant DMS-2042144 (USA, awarded to Yoichiro Mori) and Grant DMS-2055271 (USA, awarded to Robert M. Strain).

## <span id="page-50-1"></span>References

- [1] Solonnikov, V. A. Solvability of the problem of evolution of an isolated volume of viscous, incompressible capillary fluid. J. Sov. Math. 32 (1986), pp. 223–228.
- [2] Solonnikov, V. A. Unsteady motion of a finite mass of fluid, bounded by a free surface. J. Sov. Math. 40 (1988), pp. 672–686.
- [3] Solonnikov, V. A. On the transient motion of an isolated volume of viscous incompressible fluid. Math. USSR Izv. 31.2 (1988), pp. 381–405.
- [4] Solonnikov, V. A. Unsteady motions of a finite isolated mass of a self-gravitating fluid. Algebra i Analiz 1.1 (1989), pp. 207–249.
- [5] Solonnikov, V. A. Solvability of a problem on the evolution of a viscous incompressible fluid, bounded by a free surface, on a finite time interval. Algebra i Analiz 3.1 (1991), pp. 222–257.
- [6] Solonnikov, V. A. "Lectures on evolution free boundary problems: classical solutions". Mathematical Aspects of Evolving Interfaces. Springer, 2003, pp. 123–175.
- <span id="page-50-2"></span>[7] Solonnikov, V. A. Lq-estimates for a solution to the problem about the evolution of an isolated amount of a fluid. J. Math. Sci. 117.3 (2003), pp. 4237–4259.
- <span id="page-50-3"></span>[8] Mogilevskii, I. S. and Solonnikov, V. A. "On the solvability of an evolution free boundary problem for the Navier-Stokes equations in H¨older spaces of functions". Mathematical Problems Relating to the Navier-Stokes Equations. World Scientific, 1992, pp. 105–181.
- <span id="page-50-4"></span>[9] Shibata, Y. and Shimizu, S. On a free boundary problem for the Navier-Stokes equations. Differential Integral Equations 20.3 (2007), pp. 241–276.
- [10] Shibata, Y. and Shimizu, S. On the Lp-Lq maximal regularity of the Neumann problem for the Stokes equations in a bounded domain. J. Reine Angew. Math. (2008), pp. 157–209.
- <span id="page-50-5"></span>[11] Shibata, Y. and Shimizu, S. Report on a local in time solvability of free surface problems for the Navier–Stokes equations with surface tension. Appl. Anal. 90.1 (2011), pp. 201–214.
- <span id="page-50-6"></span>[12] Allain, G. Small-time existence for the Navier-Stokes equations with a free surface. Appl. Math. Optim. 16 (1987), pp. 37–50.
- [13] Beale, J. T. Large-time regularity of viscous surface waves. Arch. Ration. Mech. Anal. 84.4 (1984), pp. 307–352.
- [14] Beale, J. T. and Nishida, T. Large-Time Behaviour of Viscous Surface Waves. North-Holland, 1985.
- [15] Tani, A. Small-time existence for the three-dimensional Navier-Stokes equations for an incompressible fluid with a free surface. Arch. Ration. Mech. Anal. 133 (1996), pp. 299–331.
- <span id="page-50-7"></span>[16] Tani, A. and Tanaka, N. Large-time existence of surface waves in incompressible viscous fluids with or without surface tension. Arch. Ration. Mech. Anal. 130 (1995), pp. 303–314.
- <span id="page-50-8"></span>[17] Denisova, I. V. A priori estimates for the solution of the linear nonstationary problem connected with the motion of a drop in a liquid medium. Tr. Mat. Inst. Steklova 188 (1990), pp. 3–21.
- <span id="page-50-9"></span>[18] Denisova, I. V. Problem of the motion of two viscous incompressible fluids separated by a closed free interface. Acta Appl. Math. 37 (1994), pp. 31–40.
- <span id="page-50-10"></span>[19] Denisova, I. V. and Solonnikov, V. A. Solvability in H¨older spaces of a model initial-boundary value problem generated by a problem on the motion of two fluids. J. Math. Sci. 70 (1994), pp. 1717–1746.
- <span id="page-50-11"></span>[20] Denisova, I. V. and Solonnikov, V. A. Classical solvability of the problem of the motion of two viscous incompressible fluids. Algebra i Analiz 7.5 (1995), pp. 101–142.

- <span id="page-51-0"></span>[21] Tanaka, N. Two-phase free boundary problem for viscous incompressible thermo-capillary convection. Japan. J. Math. (N.S.) 21.1 (1995), pp. 1–42.
- <span id="page-51-1"></span>[22] Prüss, J. and Simonett, G. On the Rayleigh-Taylor instability for the two-phase Navier-Stokes equations. *Indiana Univ. Math. J.* (2010), pp. 1853–1871.
- [23] Anger, G. and Simonett, G. On the two-phase Navier–Stokes equations with surface tension. *Interfaces Free Bound.* 12.3 (2010), pp. 311–345.
- <span id="page-51-2"></span>[24] Prüss, J. and Simonett, G. Analytic Solutions for the Two-Phase Navier-Stokes Equations with Surface Tension and Gravity. Springer, 2011.
- <span id="page-51-3"></span>[25] Günther, M. and Prokert, G. Existence results for the quasistationary motion of a free capillary liquid drop. Z. Anal. Anwendungen 16.2 (1997), pp. 311–348.
- <span id="page-51-4"></span>[26] Prokert, G. "Parabolic evolution equations for quasistationary free boundary problems in capillary fluid mechanics". PhD thesis. Eindhoven University of Technology, 1997.
- <span id="page-51-5"></span>[27] Escher, J. and Prokert, G. Analyticity of solutions to nonlinear parabolic equations on manifolds and an application to Stokes flow. J. Math. Fluid Mech. 8 (2006), pp. 1–35.
- <span id="page-51-6"></span>[28] Friedman, A. and Reitich, F. Quasi-static motion of a capillary drop, II: the three-dimensional case. J. Differ. Equ. 186.2 (2002), pp. 509-557.
- <span id="page-51-7"></span>[29] Gancedo, F., García-Juárez, E., Patel, N., and Strain, R. M. Global Regularity for Gravity Unstable Muskat Bubbles. Mem. Amer. Math. Soc. 292.1455 (2023), 87 pages. ISSN: 0065-9266,1947-6221. DOI: 10.1090/memo/1455. eprint: 1902.02318. URL: https://doi.org/10.1090/memo/1455.
- <span id="page-51-8"></span>[30] Gancedo, F., García-Juárez, E., Patel, N., and Strain, R. M. On Nonlinear Stability of Muskat Bubbles. arXiv preprint arXiv:2312.14323 (2023), pp. 1–26.
- <span id="page-51-9"></span>[31] Cameron, S. and Strain, R. M. Critical local well-posedness for the fully nonlinear Peskin problem. Comm. Pure Appl. Math. 77.2 (2024), pp. 901–989. ISSN: 0010-3640,1097-0312. DOI: 10.1002/cpa.22139. eprint: 2112.00692.
- <span id="page-51-10"></span>[32] García-Juárez, E., Mori, Y., and Strain, R. M. The Peskin problem with viscosity contrast. *Anal. PDE* 16.3 (2023), pp. 785–838. eprint: 2009.03360.
- <span id="page-51-11"></span>[33] Hou, T. Y., Lowengrub, J. S., and Shelley, M. J. Removing the stiffness from interfacial flows with surface tension. *J. Comput. Phys.* 114.2 (1994), pp. 312–338.
- <span id="page-51-12"></span>[34] Pozrikidis, C. Boundary Integral and Singularity Methods for Linearized Viscous Flow. Cambridge University Press, 1992.
- <span id="page-51-14"></span><span id="page-51-13"></span>[35] Majda, A. J. and Bertozzi, A. L. Vorticity and Incompressible Flow. Cambridge University Press, 2002.
- [36] Gancedo, F., Granero-Belinchón, R., and Scrobogna, S. Surface tension stabilization of the Rayleigh-Taylor instability for a fluid layer in a porous medium. *Ann. Inst. H. Poincaré Anal. Non Linéaire* 37.6 (2020), pp. 1299–1343.
- [37] Gancedo, F. A survey for the Muskat problem and a new estimate. Bol. Soc. Esp. Mat. Apl. 74.1 (2017), pp. 21–35.
- [38] Mori, Y., Rodenberg, A., and Spirn, D. Well-posedness and global behavior of the Peskin problem of an immersed elastic filament in Stokes flow. *Comm. Pure Appl. Math.* 72.5 (2019), pp. 887–980.
- [39] Ambrose, D., Siegel, M., and Zhang, K. Convergence of the boundary integral method for interfacial Stokes flow. *Math. Comp.* 92.340 (2023), pp. 695–748.
- [40] Prüss, J. and Simonett, G. Moving Interfaces and Quasilinear Parabolic Evolution Equations. Springer, 2016.
- [41] Shimizu, S. "Local solvability of free boundary problems for the two-phase Navier-Stokes equations with surface tension in the whole space". *Parabolic Problems: The Herbert Amann Festschrift*. Springer, 2011, pp. 647–686.
- [42] Hanzawa, E.-i. Classical solutions of the Stefan problem. Tohoku Math. J. (2) 33.3 (1981), pp. 297–335.

- [43] Solonnikov, V. A. "On quasistationary approximation in the problem of motion of a capillary drop". Topics in Nonlinear Analysis: The Herbert Amann Anniversary Volume. Springer, 1999, pp. 643–671.
- [44] Katznelson, Y. An Introduction to Harmonic Analysis. Cambridge University Press, 2004.
- [45] Talvila, E. Necessary and sufficient conditions for differentiating under the integral sign. Amer. Math. Monthly 108.6 (2001), pp. 544–548.
- [46] Choi, J. H. "On the stability of steady-state solutions of a two-phase Stokes problem with surface tension". PhD thesis. University of Pennsylvania, 2024.