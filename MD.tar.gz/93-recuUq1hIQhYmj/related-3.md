## Spectral Decomposition of Symmetric Operator Matrices

By REINHARD MENNICKEN of Regensburg and ANDREY A. SHKALIKOV of Moscow

(Received September 5, 1995) (Revised Version February 10, 1996)

Abstract. The authors study symmetric operator matrices

$$L_0 = \begin{pmatrix} A & B \\ B^* & C \end{pmatrix}$$

in the product of Hilbert spaces  $\mathbf{H} = H_1 \times H_2$ , where the entries are not necessarily bounded operators. Under suitable assumptions the closure  $\overline{L_0}$  exists and is a selfadjoint operator in  $\mathbf{H}$ . With  $\overline{L_0}$ , the closure of the transfer function

$$M(\lambda) = C - \lambda - B^*(A - \lambda)^{-1}B$$

is considered. Under the assumption that there exists a real number  $\beta < \inf \rho(A)$  such that  $M(\beta) << 0$ , it follows that  $\beta \in \rho\left(\overline{L_0}\right)$ . Applying a factorization result of A.I. VIROZUB and V.I. MATSAEV [VM] to the holomorphic operator function  $M(\lambda)$ , the spectral subspaces of  $\overline{L_0}$  corresponding to the intervals  $]-\infty,\beta]$  and  $[\beta,\infty[$  and the restrictions of  $\overline{L_0}$  to these subspaces are characterized. Similar results are proved for operator matrices

$$T_0 = \begin{pmatrix} A & B \\ -B^* & C \end{pmatrix}$$

which are symmetric in a Krein space.

## 0. Introduction

In this note we consider  $2 \times 2$  operator matrices of the form

$$(0.1) L_0 = \begin{pmatrix} A & B \\ B^* & C \end{pmatrix}$$

and

$$\mathbf{T}_0 = \begin{pmatrix} A & B \\ -B^* & C \end{pmatrix}$$

<sup>1991</sup> Mathematics Subject Classification. Primary 47 B 25; Secondary 47 A 11, 47 A 56, 47 B 50, 35 P 10.

Keywords and phrases. Selfadjoint operator matrices, transfer functions, half range completeness, eigenfunction expansions for PDO.

acting in the product of Hilbert spaces  $\boldsymbol{H}=H_1\times H_2$ . Some general results on operators acting in the product of two Banach spaces with unbounded operator entries were obtained in a recent paper by F. V. ATKINSON, H. LANGER, R. MENNICKEN and A. A. Shkalikov [ALMS]. The situation where  $\boldsymbol{L}_0$  is a symmetric operator in a Hilbert space  $\boldsymbol{H}$  occurs quite often in applications (see, for example, the survey article of J. A. Adams [A], the paper of J. P. Goedbloed [G], the book of A. Lifschitz [L], the papers of V. A. Malyshev and R. A. Minlos [Mam1, Mam2], A. Motovilov [M1, M2] and references there). Hence, the study of symmetric operator matrices is of particular interest. It is also natural to study operator matrices which are symmetric on a Krein space.

The main problem concerning operators of the form (0.1) or (0.2) is the existence of invariant subspaces having a so called "graph representation". If such invariant subspaces exist, then the restrictions of  $L := \overline{L}_0$  (or  $T := \overline{T}_0$ ) to these invariant subspaces are similar to selfadjoint operators acting in  $H_1$  and  $H_2$ , respectively. This fact allows to reduce the study of the operator L (or T) to the study of the corresponding linear operators in the component spaces of  $H_1 \times H_2$ .

Some results on invariant subspaces of L with a bounded operator B (and with sufficiently small norm of B) were obtained by V. A. MALYSHEV and R. A. MINLOS [MM1, MM2], and with B of Hilbert-Schmidt class by A. MOTOVILOV [M1, M2]. In a recent paper V. M. Adamjan and H. Langer [AL] consider operators of the form (0.1) and (0.2) with a bounded operator B and no restrictions on its norm. In addition they assume the separation condition on the spectra of A and C:

$$\sup \sigma(C) < \inf \sigma(A).$$

Their method is based on the representation of the Nevanlinna function

$$N(\lambda) := L^{-1}(\lambda) = \int_{-\infty}^{+\infty} \frac{dF(t)}{t-\lambda}, \quad \lambda = \overline{\lambda},$$

where  $L(\lambda) = A - \lambda I - B(C - \lambda I)^{-1}B^*$  and F(t) is a selfadjoint monotone operator function having the limits  $F(-\infty) = 0$ ,  $F(+\infty) = I$  in the strong operator topology. The development of this approach for unbounded B is presented in a paper of V. Adamjan, H. Langer, R. Mennicken and J. Saurer.

It is the aim of this paper to present another approach to the problem under consideration. The basic idea of our method is the factorization of the closure of the transfer function. Our method allows to weaken the separation condition on the spectra of A and C. Under this weaker condition we obtaain that the angular operators in the representation of the invariant subspaces  $\mathcal{L}_+$  and  $\mathcal{L}_-$  for  $\overline{L_0}$  are bounded, but not necessarily contractions as in [AL].

The following conditions will be assumed throughout the paper:

- (i) A is a selfadjoint operator in  $H_1$  with domain  $\mathcal{D}(A)$ ;
- (ii) C is a symmetric operator in  $H_2$ ;
- (iii) B is a densely defined closable operator from  $H_2$  to  $H_1$ ,  $B^*$  is the adjoint of B and  $\mathcal{D}(B^*) \supset \mathcal{D}(|A|^{1/2})$ ;
  - (iv)  $\mathcal{D}(C) \supset \mathcal{D}(B)$ .

$$\mathcal{D}(\mathbf{L}_0) := \mathcal{D}(\mathbf{T}_0) := \mathcal{D}(A) \times \mathcal{D}(B).$$

The main results of this note are obtained under the additional hypothesis that C is bounded. To omit this assumption and to weaken the condition  $\mathcal{D}(B^*) \supset \mathcal{D}(|A|^{1/2})$  is beyond the scope of this paper. We notice, however, that in many applications C represents a bounded multiplication operator. In particular, this is the case for the linearized Navier–Stokes operator which is considered as an example at the end of the paper.

## 1. The factorization of the transfer function

With the operator (0.1) we associate the rational operator function

$$M_0(\lambda) = C - \lambda I - B^*(A - \lambda I)^{-1}B$$

which is naturally defined on the domain  $\mathcal{D}(M_0) = \mathcal{D}(B)$  for  $\lambda \in \rho(A)$ . We note that  $M_0(\lambda)$  appears in the Frobenius-Schur factorization of  $L_0 - \lambda I$  (see below); it is called the transfer function associated with  $L_0$ .

We shall show that  $M_0(\lambda)$  is closable for  $\lambda \in \rho(A)$  and describe its closure. By assumption (iii) the operator

$$T := B^*(|A|+I)^{-1/2}$$

is closed and defined on the whole space  $H_1$ . It follows from the Closed Graph Theorem that T is bounded as an operator from  $H_1$  to  $H_2$ . Hence the operator  $(|A|+I)^{-1/2}B = T^*|_{\mathcal{D}(B)}$  is bounded. We have

(1.1) 
$$B^*(A - \lambda I)^{-1}B = TU(\lambda)T^*|_{\mathcal{D}(B)},$$

where, for  $\lambda \in \rho(A)$ , the operator

(1.2) 
$$U(\lambda) = (|A|+I)^{1/2}(A-\lambda I)^{-1}(|A|+I)^{1/2}$$

has a bounded extention to  $H_1$  which we also denote by  $U(\lambda)$ . Hence

$$S_0(\lambda) \;:=\; B^*(A-\lambda I)^{-1}B\,,\quad \lambda\in\rho(A)\,,$$

has a bounded extention (closure)  $S(\lambda) := \overline{S_0(\lambda)}$  (in the sequel the overlining denotes the closure of the operator). This implies that the operator function  $M_0(\lambda)$  is closable and its closure

$$(1.3) M(\lambda) := C_1 - \lambda I - S(\lambda), \quad C_1 = \overline{C|_{\mathcal{D}(B)}},$$

is defined for  $\lambda \in \rho(A)$  on the domain  $\mathcal{D}(M) = \mathcal{D}(C_1) \supset \mathcal{D}(B)$ .

In the following we will use the subsequent propositions whose proofs can be found in the paper by A. I. VIROZUB and V. I. MATSAEV [VM] (see also A. S. MARKUS and V. I. MATSAEV [MM1]).

**Proposition 1.1.** Suppose that  $M(\lambda)$  is a holomorphic function in a domain  $\Omega$  whose values are bounded operators in a Hilbert space H. Let  $\Omega$  contain a segment  $[\alpha,\beta] \subset R$  such that

$$(1.4) M(\alpha) \gg 0, M(\beta) \ll 0, M'(\lambda) \ll 0 for \lambda \in [\alpha, \beta].$$

Then there exists a domain  $\Omega' \supset [\alpha, \beta]$  such that  $M(\lambda)$  is invertible in  $\Omega' \setminus [\alpha, \beta]$ , and if  $\Gamma \subset \Omega'$  is a Jordan contour which surrounds  $[\alpha, \beta]$  then

$$G = -\frac{1}{2\pi i} \int_{\Gamma} M^{-1}(\lambda) d\lambda$$

is a strictly positive operator, i. e.,  $G \gg 0$ .

**Proposition 1.2.** Under the assumptions of Proposition 1.1 the operator function  $M(\lambda)$  admits a factorization

$$(1.6) M(\lambda) = M_{+}(\lambda)(Z - \lambda I),$$

where  $M_+(\lambda)$  is holomorphic and boundedly invertible in  $\Omega'$ , while Z is a bounded operator,  $\sigma(Z) \subset (\alpha, \beta)$  and ZG is selfadjoint, i. e., Z is selfadjoint in H equipped with the equivalent inner product  $[\cdot, \cdot] = (G^{-1} \cdot, \cdot)$ .

These propositions enable us to obtain the following statement.

**Theorem 1.3.** Suppose in addition to the assumptions (i) – (iv) that C is bounded, A is bounded from below and there is a real number  $\beta < \inf \sigma(A)$  such that

$$(1.7) M(\beta) \ll 0.$$

Then the transfer function  $M(\lambda)$  admits the factorization (1.6), where  $M_+(\lambda)$  is a holomorphic boundedly invertible operator function in the domain  $C \setminus [\beta, \infty)$ , while Z is a selfadjoint operator in H equipped with the inner product  $[\cdot, \cdot] = (G^{-1} \cdot, \cdot)$ , where G is given by (1.5). The spectrum of Z is a compact subset of  $(-\infty, \beta)$ .

Proof. Obviously,  $0 \le S(\lambda) \le S(\beta)$  for  $\lambda < \beta$ . Therefore  $M(\lambda) \gg 0$  for all  $\lambda < -||C|| - ||S(\beta)||$ . Moreover,

$$M'(\lambda) \; = \; -I - \overline{B^*(A-\lambda I)^{-2}B} \; \ll \; 0 \quad \text{for} \quad \lambda < \inf \sigma(A) \, .$$

Now apply Proposition 1.2.

**Remark 1.4.** The assumption that the spectra of A and C are separated, namely,

(1.8) 
$$\sup \sigma(C) =: c^+ < a^- := \inf \sigma(A),$$

was assumed in [M1, M2] as well as in [AL]. In the sequel we shall use the assertion (1.7) which is weaker than (1.8). Indeed, if  $\beta \in (c^+, a^-)$  then  $M(\beta) \ll 0$ . However, condition (1.7) may hold even if the spectra of A and C overlap: For example, let

 $H_1 = H_2$  and let A, C be bounded operators. If  $\beta < a^-$  and  $B^*B \ge \rho^2 I$  where  $\rho^2 > (c^+ - \beta)(a^+ - \beta)^{-1}$ ,  $a^+ := \sup \sigma(A)$ , then  $M(\beta) \ll 0$ .

Remark 1.5. The conditions (1.4) imply the invertibility of  $M(\lambda)$  in a neighbourhood of  $[\alpha, \beta]$ . Actually, the transfer function  $M(\lambda)$  is boundedly invertible for all  $\lambda \notin \mathbf{R}$  if  $C_1$  is selfadjoint. This can be shown directly (see Lemma 1.1 in [AL]) and follows from the subsequent Proposition 2.1.

We note that the proof of Proposition 1.1 is quite elementary (see Lemmas 1.4 and 1.5 in [MM1], and for the transfer function it can be proved even more easily), while Proposition 1.2 is by no means obvious. The first factorization theorems were obtained for operator polynomials, see [KL] and [L1]. The result of [VM] used in this paper it is obtained based on the factorization theorem due to I. Gohberg and Yu. Laiterer [GL]. For the further development of [VM] see [MM2] and [MM3]. In the next section we shall point out another role of the operator Z and make the factorization formula (1.6) more precise.

# 2. Invariant subspaces of the operator $\overline{L}_0$

In the sequel we use the notations from the book of T. KATO [Ka]. The range and the null space (the kernel) of a closed operator T in a Hilbert space H are denoted by  $\mathcal{R}(T)$  and  $\mathcal{N}(T)$ , respectively. We define

$$\operatorname{nul} T := \dim \mathcal{N}(T), \quad \operatorname{def} T := \dim H/\mathcal{R}(T).$$

A linear set  $\mathcal{M}$  is said to be a core of a closable operator T if the closure of the restriction  $T|_{\mathcal{M}}$  coincides with  $\overline{T}$ . Based on the results of [ALMS] we can easily obtain a criterion for the essential selfadjointness of the operator  $L_0$ .

**Proposition 2.1.** The operator  $L_0$  is essentially selfadjoint if and only if C is essentially selfadjoint and  $\mathcal{D}(B)$  is a core of C.

Proof. Let us denote  $F(\lambda) = B^*(A - \lambda I)^{-1}$  and write the Frobenius-Schur factorization

$$(2.1) L_0 - \lambda I = \begin{pmatrix} I & 0 \\ F(\lambda) & I \end{pmatrix} \begin{pmatrix} A - \lambda I & 0 \\ 0 & M_0(\lambda) \end{pmatrix} \begin{pmatrix} I & F^*(\lambda) \\ 0 & I \end{pmatrix} =: UD_0V,$$

where  $F^*(\lambda) = [F(\overline{\lambda})]^*$ . It is easily seen that (2.1) holds for

$$x = \begin{pmatrix} x_1 \\ x_2 \end{pmatrix} \in \mathcal{D}(A) \times \mathcal{D}(B)$$
.

As U and V are bounded and boundedly invertible in H we have

(2.2) 
$$\operatorname{def}\left(\overline{L_0} - \lambda I\right) = \operatorname{def}\left(\overline{M_0(\lambda)}\right) = \operatorname{def}M(\lambda), \quad \lambda \in \rho(A),$$

where  $M(\lambda)$  is defined by (1.3). From the definition of  $S(\lambda)$  and the relationships (1.1) and (1.2) we obtain the following estimate: For any  $\gamma > 0$ ,  $\eta > 0$  there exists a positive number K such that

$$(2.3) ||S(\lambda)|| \leq K, |\operatorname{Re} \lambda| \leq \gamma, |\operatorname{Im} \lambda| \geq \eta.$$

As  $C_1 := \overline{C|_{\mathcal{D}(B)}}$  is symmetric, we have  $||(C_1 - \lambda I)y|| \ge |\operatorname{Im} \lambda| \, ||y||$  for  $y \in \mathcal{D}(C_1)$ . Now the estimate (2.3) implies (see Th. 5.22, Ch. 4 of [Ka], for example) that

$$\operatorname{def} M(\lambda) = \operatorname{def} (C_1 - \lambda I), \quad \lambda \in C \setminus R$$

Therefore

(2.4) 
$$\operatorname{def}\left(\overline{\boldsymbol{L}}_{0}-\lambda\boldsymbol{I}\right) = \operatorname{def}\left(C_{1}-\lambda I\right), \quad \lambda \in \boldsymbol{C} \setminus \boldsymbol{R}.$$

This proves Proposition 2.1.

Remark 2.2. It follows from (2.1) that

$$\operatorname{nul}(\overline{L}_0 - \lambda I) = \operatorname{nul} M(\lambda), \quad \lambda \in \rho(A).$$

Proof. Together with (2.2) and (2.4) we find that  $M(\lambda)$  is boundedly invertible for all  $\lambda \in \rho(A) \setminus \mathbf{R}$  if and only if  $C_1 = C_1^*$ .

**Remark 2.3.** It easily follows from (2.1) (see also [ALMS]) that the closure  $L = \overline{L}_0$  is given by the relations

(2.5) 
$$\begin{cases} \mathcal{D}(\mathbf{L}) = \left\{ \mathbf{x} = \begin{pmatrix} x_1 \\ x_2 \end{pmatrix} \in \mathcal{H}, \ x_1 + F^*(\lambda) x_2 \in \mathcal{D}(A), \ x_2 \in \mathcal{D}(C_1) \right\}, \\ \mathbf{L} \begin{pmatrix} x_1 \\ x_2 \end{pmatrix} = \begin{pmatrix} A(x_1 + F^*(\lambda) x_2) - \lambda F^*(\lambda) x_2 \\ B^*(x_1 + F^*(\lambda) x_2) + (C_1 - S(\lambda)) x_2 \end{pmatrix}. \end{cases}$$

For the rest of this section it is assumed that C is bounded. In this case  $L = \overline{L}_0$  is selfadjoint and possesses a spectral function which we denote by  $E(\mu)$ .

**Proposition 2.4.** Let C be bounded, A be bounded from below and suppose that there exists a point  $\beta < a^- = \inf \sigma(A)$  such that  $M(\beta) \ll 0$ . Then the subspace

$$\mathcal{L}_{-} = \mathbf{E}(\beta) \mathbf{H}$$

admits a representation

$$\mathcal{L}_{-} = \left\{ \begin{pmatrix} Ky \\ y \end{pmatrix}, y \in H_2 \right\},\,$$

where K is a bounded operator from  $H_2$  to  $H_1$ . Moreover,  $K = YG^{-1}$ , where G is defined by (1.5),

(2.7) 
$$Y = -\frac{1}{2\pi i} \int_{\Gamma} F^{*}(\lambda) M^{-1}(\lambda) d\lambda, \quad F^{*}(\lambda) = \overline{(A - \lambda I)^{-1} B},$$

 $M(\lambda)$  is the transfer function given by (1.3), and  $\Gamma$  is a positively orientated Jordan contour which intersects  $\mathbf{R}$  in the point  $\beta$  and in a point  $\alpha < -||C|| - ||S(\beta)||$  (see the proof of Theorem 1.3).

Proof. It follows from (2.1) that the resolvent of L has the representation

$$(2.8) \qquad (\boldsymbol{L} - \lambda \boldsymbol{I})^{-1} = \begin{pmatrix} (A - \lambda I)^{-1} + F^*(\lambda)M^{-1}(\lambda)F(\lambda) & -F^*(\lambda)M^{-1}(\lambda) \\ -M^{-1}(\lambda)F(\lambda) & M^{-1}(\lambda) \end{pmatrix}.$$

Obviously,

(2.9) 
$$Q_{-} := E(\beta) = -\frac{1}{2\pi i} \int_{\Gamma} (L - \lambda I)^{-1} d\lambda =: \begin{pmatrix} D & Y \\ Y^{*} & G \end{pmatrix}.$$

By Proposition 1.2 we have

$$M^{-1}(\lambda) = (Z - \lambda I)^{-1} M_{+}^{-1}(\lambda)$$

where  $M_{+}^{-1}(\lambda)$  is a holomorphic operator function inside the contour  $\Gamma$ . The same is true for  $(A - \lambda I)^{-1}$ , hence

$$D = -\frac{1}{2\pi i} \int_{\Gamma} F^{*}(\lambda) (Z - \lambda I)^{-1} M_{+}^{-1}(\lambda) F(\lambda) d\lambda.$$

Due to the Daletskii-Krein formula (see Lemma 2.1, Ch. 1 of [DK]) we have

$$D = \left\{ \frac{1}{2\pi i} \int_{\Gamma} F^*(\lambda) (Z - \lambda I)^{-1} d\lambda \right\} \left\{ \frac{1}{2\pi i} \int_{\Gamma} (Z - \lambda I)^{-1} M_+^{-1}(\lambda) F(\lambda) d\lambda \right\}$$
  
=:  $PY^*$ .

Now let  $\begin{pmatrix} x \\ 0 \end{pmatrix} \in \mathcal{L}_{-} = \mathbf{Q}_{-}\mathbf{H}$ . Then

$$Q_{-}\begin{pmatrix} x \\ 0 \end{pmatrix} = \begin{pmatrix} x \\ 0 \end{pmatrix}$$

and thus Dx = x,  $Y^*x = 0$  which implies x = 0 because of the equality  $D = PY^*$ . Hence the subspace  $\mathcal{L}_-$  is the graph of a closed operator K, namely (see Ch. III, Problem 5.13 of [Ka]),

$$\mathcal{L}_{-} = \left\{ {Ky \choose y}, \ y \in \mathcal{D}(K) \subset H_2 \right\}.$$

It remains to be proved that  $\mathcal{D}(K)$  coincides with the whole space  $H_2$ . Indeed, from (2.9) we find

$$Q_{-}inom{0}{z}=inom{Yz}{Gz}\in\mathcal{L}_{-} ext{ for } z\in H_2$$
 .

Since  $G \gg 0$  by Proposition 1.1, we obtain  $\mathcal{D}(K) = H_2$  and  $K = YG^{-1}$ .

**Theorem 2.5.** Let the assumptions of Proposition 2.4 be fulfilled. Then the following statements hold:

(a) The subspaces

$$\mathcal{L}_{-} = \mathbf{E}(\beta)\mathbf{H}, \quad \mathcal{L}_{+} = (\mathbf{I} - \mathbf{E}(\beta))\mathbf{H}$$

have the representations

$$\mathcal{L}_{-} \ = \ \left\{ \binom{Ky}{y}, \ y \in H_2 \right\}, \quad \mathcal{L}_{+} \ = \ \left\{ \binom{x}{-K^*x}, \ x \in H_1 \right\},$$

where  $K = YG^{-1}$ , and G, Y are expressed in terms of the transfer function by (1.5) and (2.7), respectively;

(b) The operator K possesses the properties

$$\mathcal{R}(K) \subset \mathcal{D}(B^*), \quad \mathcal{R}(K|_{\mathcal{D}(B)}) \subset \mathcal{D}(A)$$

and satisfies the Riccati equation

$$(2.10) (KB^*K - B - AK + KC)y = 0, y \in \mathcal{D}(B);$$

- (c) The restriction  $L|_{\mathcal{L}_{-}}$  is unitarily equivalent to the operator  $Z = C + B^*K$ , which is selfadjoint in  $H_2$  equipped with the inner product  $[\cdot, \cdot] = (G^{-1} \cdot, \cdot)$ , and  $G = (I + K^*K)^{-1}$ ;
  - (d) The transfer function  $M(\lambda)$  admits a factorization (1.6) with

$$M_+(\lambda) \; = \; I - B^*(A - \lambda I)^{-1}K \,, \quad Z \; = \; C + B^*K \; = \; XG^{-1} \,,$$

and

(2.11) 
$$X = X^* = -\frac{1}{2\pi i} \int_{\Gamma} \lambda M^{-1}(\lambda) d\lambda;$$

(e) The restriction  $L|_{\mathcal{L}_+}$  is unitarily equivalent to an operator  $Z_1$  which is selfadjoint in  $H_1$  equipped with the inner product  $[\cdot,\cdot]_1=(G_1^{-1}\cdot,\cdot),\ G_1=(I+KK^*)^{-1}$ . This operator is given by the formula

(2.12) 
$$\begin{cases} \mathcal{D}(Z_1) = \{x \in H_1 : (I - F^*(\beta)K^*)x \in \mathcal{D}(A)\} \\ Z_1x = A(I - F^*(\beta)K^*)x + \beta F^*(\beta)K^*x. \end{cases}$$

Proof. Proposition 2.4 and the relation  $\mathcal{L}_{-} \perp \mathcal{L}_{+}$  prove the statement (a). As for  $\lambda \in \rho(A)$  the operator  $|A - \lambda I|^{-1/2}B$  is bounded, it follows from (2.7) that

$$\mathcal{R}(Y) \subset \mathcal{D}(|A|^{1/2}) \subset \mathcal{D}(B^*).$$

Since  $K = YG^{-1}$ , we have  $\mathcal{R}(K) \subset \mathcal{D}(B^*)$ . The operator L is bounded from below, hence the subspace  $\mathcal{L}_- \subset \mathcal{D}(L)$ . From the description of  $\mathcal{D}(L)$  in (2.5) it follows that

$$Ky + \overline{(A - \lambda I)^{-1}B} y \in \mathcal{D}(A)$$
 for  $y \in H_2$ 

whence  $Ky \in \mathcal{D}(A)$  if  $y \in \mathcal{D}(B)$ . Thus

$$\mathcal{R}\Big(K|_{\mathcal{D}(B)}\Big)\subset\mathcal{D}(A) \quad ext{and} \quad m{y} \ = \ inom{Ky}{y} \ \in \mathcal{D}(m{L}_0) \quad ext{if} \quad m{y} \in \mathcal{D}(B) \, .$$

As  $\mathcal{L}_{-}$  is an invariant subspace of L, we have  $L_{0}y = y_{1} = {Ky_{1} \choose y_{1}} \in \mathcal{L}_{-}$  if  $y \in \mathcal{L}_{-}$ . Notice that the relation

(2.13) 
$$L_0 y = \begin{pmatrix} A & B \\ B^* & C \end{pmatrix} \begin{pmatrix} Ky \\ y \end{pmatrix} = \begin{pmatrix} Ky_1 \\ y_1 \end{pmatrix}, \quad y \in \mathcal{D}(B),$$

is equivalent to (2.10). Thus (b) is proved.

Define the operator V by

$$V\binom{Ky}{y} = y.$$

Obviously, V maps  $\mathcal{L}_{-}$  isometrically onto  $H_2$  if  $H_2$  is equiped with the inner product  $[\cdot,\cdot]=((I+K^*K)\cdot,\cdot)$ . According to (2.13),

$$L_0\binom{Ky}{y} = V^{-1}(C+B^*K)V\binom{Ky}{y}, \quad y \in \mathcal{D}(B).$$

Taking the closure we obtain

$$(2.14) Z := C + B^*K = VL_{-}V^{-1}, \text{ where } L_{-} = L|_{\mathcal{L}_{-}}.$$

As  $L_{-}$  is selfadjoint in  $\mathcal{L}_{-}$  and  $V^{-1} = V^{*}$  we find that Z is selfadjoint in  $H_{2}$  with respect to the new inner product.

The equality  $K^*K + I = G^{-1}$  follows from (2.9) and the known fact (see [AI], Ch. 1, Problem 8.13) that the orthogonal projector  $Q_-$ , defined in (2.6), has the representation

$$Q_{-} = \begin{pmatrix} K(K^{*}K+I)^{-1}K^{*} & K(K^{*}K+I)^{-1} \\ (K^{*}K+I)^{-1}K^{*} & (K^{*}K+I)^{-1} \end{pmatrix}.$$

Thus (c) is proved. The statement (e) is proved in a similar way taking into account the representation (2.5) of the operator L.

To prove (d) we make use of (2.1) and (2.14) and obtain

$$V\begin{pmatrix} I & 0 \\ F(\lambda) & I \end{pmatrix}\begin{pmatrix} A - \lambda I & B \\ 0 & M(\lambda) \end{pmatrix} V^{-1} = V(\mathbf{L}_{-} - \lambda \mathbf{I})V^{-1} = Z - \lambda I.$$

Therefore

$$\begin{pmatrix} A - \lambda I & B \\ 0 & M(\lambda) \end{pmatrix} \begin{pmatrix} Ky \\ y \end{pmatrix} = \begin{pmatrix} I & 0 \\ -F(\lambda) & I \end{pmatrix} V^{-1} (Z - \lambda I) V \begin{pmatrix} Ky \\ y \end{pmatrix}.$$

Math. Nachr. 179 (1996)

From this equality we have

$$M(\lambda) = (I - F(\lambda)K)(Z - \lambda I).$$

Integrating the identity  $(Z - \lambda I) M^{-1}(\lambda) = (I - F(\lambda)K)^{-1} = M_+^{-1}(\lambda)$  along the contour  $\Gamma$  we obtain ZG = X, where X is given by (2.11). This completes the proof of Theorem 2.5.

Corollary 2.6. Let the assumptions of Proposition 2.4 be satisfied and assume that A has a compact resolvent. Then the spectrum of  $\mathbf{L}$  in  $[\beta, \infty)$  is discrete. If

$$f_k = \begin{pmatrix} f_k \\ -K^*f_k \end{pmatrix}, \quad k = 1, 2, \dots$$

is an orthonormal system of eigenvectors corresponding to the eigenvalues  $\lambda_k \in (\beta, \infty)$ , then the "first coordinate" system  $\{f_k\}_1^{\infty}$  forms a Riesz basis in  $H_1$  (and it is an orthonormal system in  $H_1$  equipped with the new scalar product  $[\cdot, \cdot]_1$ ).

Proof. According to the definition of the operator  $Z_1$  we have

$$(2.15) Z_1 - \beta I = (A - \beta I)(I - F^*(\beta)K^*).$$

If  $\beta \in \rho(L)$ , then  $\beta \in \rho(Z_1)$ . Hence the operator  $I - F^*(\beta)K^*$  has a trivial kernel. Moreover, the operator  $F^*(\beta)K^*$  is compact since A has a compact resolvent. Thus the operator  $I - F^*(\beta)K^*$  is boundedly invertible. From (2.15) we obtain that  $Z_1$  has a compact resolvent. Now the assertion follows from the statement (e).

Corollary 2.7. Let the assumptions of Proposition 2.4 be fulfilled and assume that  $H_2$  is a separable Hilbert space and the essential spectrum of  $\mathbf{L}$  in  $(-\infty, \beta)$  is a countable set. If  $\mathbf{g}_k = \binom{Kg_k}{g_k}$ ,  $k = -1, -2, \ldots$ , is an orthonormal system of eigenvectors corresponding to the eigenvalues  $\lambda_k \in (-\infty, \beta)$ , then the "second coordinate" system  $\{g_k\}_{-\infty}^{-\infty}$  forms a Riesz basis in  $H_2$ .

Proof. If the essential spectrum of L in  $(-\infty, \beta)$  is a countable set, then there is an orthonormal system  $\{g_k\}_{-1}^{-\infty}$  of eigenvectors which is complete in  $\mathcal{L}_-$  (this follows from the spectral theorem for selfadjoint operators). Now apply statement (c).

# 3. The spectral decomposition of the operator $\overline{T_0}$

The operator  $T_0$  is symmetric in the Krein space  $\mathcal{K}=H_1\times H_2$  with the inner product

$$[\boldsymbol{x}, \boldsymbol{y}] = (\boldsymbol{J}\boldsymbol{x}, \boldsymbol{y}), \quad \boldsymbol{J} = \begin{pmatrix} I & 0 \\ 0 & -I \end{pmatrix}, \quad \boldsymbol{x} = \begin{pmatrix} x_1 \\ x_2 \end{pmatrix}, \quad \boldsymbol{y} = \begin{pmatrix} y_1 \\ y_2 \end{pmatrix} \in \mathcal{K}.$$

It follows from Proposition 2.1 that  $T = \overline{T}_0$  is selfadjoint in  $\mathcal{K}$  if and only if  $C_1 = \overline{C}|_{\mathcal{D}(B)}$  is selfadjoint in  $H_2$ . In particular, T is selfadjoint in  $\mathcal{K}$  if C is bounded.

With the operator  $T_0$  we associate the transfer function

$$M_0(\lambda) = C - \lambda I + B^* (A - \lambda I)^{-1} B$$

and its closure

$$M(\lambda) = C_1 - \lambda I + S(\lambda), \quad S(\lambda) := \overline{B^* (A - \lambda I)^{-1} B}.$$

As in Section 2, we use the Frobenius-Schur factorization for  $T - \lambda I$  and find that  $M(\lambda)$  is boundedly invertible for  $\lambda \in \rho(A)$  if and only if  $\lambda \in \rho(T)$ . Moreover,

$$(3.1) (T - \lambda I)^{-1} = \begin{pmatrix} (A - \lambda I)^{-1} - F^*(\lambda) M^{-1}(\lambda) F(\lambda) & -F^*(\lambda) M^{-1}(\lambda) \\ M^{-1}(\lambda) F(\lambda) & M^{-1}(\lambda) \end{pmatrix}.$$

In general, the spectrum of T is not necessarily real. In order to prove a result analogous to Theorem 2.5 we need an additional assumption.

**Proposition 3.1.** Let  $C_1 = \overline{C|_{\mathcal{D}(B)}}$  be selfadjoint, A be bounded from below and

$$\sup \sigma(C_1) =: c^+ < a^- := \inf \sigma(A).$$

If  $\beta \in (c^+, a^-)$ , then the following conditions are equivalent:

 $(\star)$   $\beta \in \rho(T)$  and  $T - \beta I$  is nonnegative in K;

 $(\star\star)\ M(\beta)\ll 0\,;$ 

 $(\star \star \star)$   $M(\beta)$  is boundedly invertible and

$$(3.2) |(By,x)|^2 \le ((A-\beta I)x,x)((\beta I-C)y,y), x \in \mathcal{D}(A), y \in \mathcal{D}(C).$$

Proof. Without loss of generality we assume  $\beta = 0$ . Suppose that  $(\star)$  holds. Using (3.1) we find

$$0 \leq \left[ T^{-1} \binom{0}{y}, \binom{0}{y} \right] = - \left( M^{-1}(0)y, y \right), \quad y \in H_2,$$

As M(0) is invertible, we have  $M(0) \ll 0$ .

The condition  $(\star\star)$  implies the invertibility of M(0) and

$$||A^{-1/2}By||^2 \le |||C|^{1/2}y||^2, y \in \mathcal{D}(B).$$

Therefore

$$|(A^{-1/2} B |C|^{-1/2} u, v)| \le ||u|| ||v||,$$

and  $(\star \star \star)$  follows.

Finally, if  $(\star \star \star)$  holds, then  $0 \in \rho(T)$  and (cf. [AL])

$$\left[\boldsymbol{T} \begin{pmatrix} x \\ y \end{pmatrix}, \ \begin{pmatrix} x \\ y \end{pmatrix}\right] \ = \ (Ax, \ x) - (Cy, \ y) + 2\operatorname{Re}(By, x) \ \ge \ 0$$

which implies the condition (\*).

**Theorem 3.2.** Let C be bounded, A be semibounded from below and  $c^+ < a^-$ . Suppose also that there exists a point  $\beta \in (c^+, a^-)$  such that  $M(\beta) \ll 0$ . Then the operator  $T = \overline{T}_0$  is selfadjoint in K and possesses a pair of invariant subspaces  $\mathcal{L}_-$  and  $\mathcal{L}_+$  such that  $\mathcal{L}_-[+]\mathcal{L}_+ = K$  and the following statements are true:

(a)  $\mathcal{L}_{-}$  and  $\mathcal{L}_{+}$  are maximal uniformly negative and positive, respectively and

$$(3.3) \mathcal{L}_{-} = \left\{ \begin{pmatrix} Ky \\ y \end{pmatrix} : y \in H_{2} \right\}, \quad \mathcal{L}_{+} = \left\{ \begin{pmatrix} x \\ K^{*}x \end{pmatrix} : x \in H_{1} \right\},$$

where ||K|| < 1. The spectra of the restrictions  $\mathbf{T}_{-} = \mathbf{T}|_{\mathcal{L}_{-}}$  and  $\mathbf{T}_{+} = \mathbf{T}|_{\mathcal{L}_{+}}$  lie in the intervals  $(-\infty, \beta)$  and  $(\beta, \infty)$ , respectively;

(b) The operator K has the properties

$$\mathcal{R}(K) \subset \mathcal{D}(B^*), \quad \mathcal{R}\Big(K|_{\mathcal{D}(B)}\Big) \subset \mathcal{D}(A),$$

and satisfies the Riccati equation

$$(KB^*K + AK - KC + B)x = 0, \quad x \in \mathcal{D}(B);$$

- (c) The restriction  $T_-$  is unitarily equivalent to the operator  $Z=C-B^*K$  which is selfadjoint in the Hilbert space  $H_2$  equipped with the inner product  $[\cdot,\cdot]=(G^{-1}\cdot,\cdot)$ , where  $G=(I-K^*K)^{-1}$ ;
  - (d) The transfer function  $M(\lambda)$  admits the factorization

$$M(\lambda) = (I + F(\lambda)K)(Z - \lambda I), \quad Z = C - B^*K = XG^{-1},$$

where X and G are expressed by (2.11) and (1.5), respectively;

(e) The restriction  $T_+$  is unitarily equivalent to an operator  $Z_1$  which is selfadjoint in  $H_1$  equipped with the inner product  $[\cdot,\cdot]_1=((I-KK^*)\cdot,\cdot)$ . This operator is defined similarly as  $Z_1$  in (2.12).

Proof. It follows from Proposition 3.1 that  $T - \beta I$  is nonnegative and  $\rho(T)$  is not empty. Hence the spectrum of T is real (see [L2], for example). As C is bounded and  $S(\lambda)$  is uniformly bounded in the half-plane Re  $\lambda \leq \beta$ , we find that  $M(\lambda)$  is boundedly invertible for  $\lambda < -r_0$  if  $r_0$  is large enough. Hence  $\sigma_-(T) := \sigma(T) \cap (-\infty, \beta)$  is a compact set in  $(-\infty, \beta)$ . If a contour  $\Gamma$  surrounds only  $\sigma_-(T)$ , then

(3.4) 
$$Q_{-} = -\frac{1}{2\pi i} \int_{\Gamma} (T - \lambda I)^{-1} d\lambda$$

is the orthogonal projection in  $\mathcal{K}$  onto the subspace  $\mathcal{L}_{-} := \mathbf{Q}(\mathcal{K})$ . According to [L2] the subspace  $\mathcal{L}_{-}$  is uniformly negative in  $\mathcal{K}$  and hence has the representation (3.3) where  $\mathcal{K}$  is a contraction. Clearly, its orthogonal complement in  $\mathcal{K}$  has the representation given in (3.3),  $\sigma\left(\mathbf{T}|_{\mathcal{L}_{+}}\right) \subset (\beta, \infty)$  and both subspaces  $\mathcal{L}_{-}$  and  $\mathcal{L}_{+}$  are invariant under  $\mathbf{T}$ . Thus (a) is proved.

All other assertions are proved exactly in the same way as the corresponding statements in Theorem 2.5. We only have to recall that the orthogonal projection Q onto  $\mathcal{L}_{-}$  in  $\mathcal{K}$  has the representation

$$Q_{-} = \begin{pmatrix} K(K^{*}K - I)^{-1}K^{*} & K(I - K^{*}K)^{-1} \\ (K^{*}K - I)^{-1}K^{*} & (I - K^{*}K)^{-1} \end{pmatrix}$$

(see Ch. 1, Th. 8.17 in [AI]). Combining (3.1) and (3.4) we find that

$$G = (I - K^*K)^{-1}.$$

#### Half-range basis property for the linearized Navier-Stokes 4. operator

As an example we consider the linearized Navier-Stokes operator (see [LL], for example)

(4.1) 
$$\mathbf{L}_0 \mathbf{u} = \begin{pmatrix} -\Delta & -\operatorname{grad} \\ \operatorname{div} & 0 \end{pmatrix} \begin{pmatrix} \mathbf{u} \\ p \end{pmatrix},$$

where u is a 3-vector function and p is a scalar function on a bounded smooth domain  $\Omega \subset \mathbb{R}^3$ . For simplicity we consider the realization of  $L_0$  with Dirichlet boundary conditions. We define the Hilbert spaces  $H_1 = [L_2(\Omega)]^3$ ,  $H_2 = L_2(\Omega)$  and the entries of  $L_0$  as follows:

$$\begin{cases} Au &= -\Delta u, \\ \mathcal{D}(A) &= \left\{ u \in [H^2(\Omega)]^3, \ u|_{\partial\Omega} = 0 \right\}; \end{cases}$$

$$\begin{cases} B p &= -\operatorname{grad} p \\ \mathcal{D}(B) &= H^1(\Omega); \end{cases}$$

$$C = 0.$$

It is well known that  $A = A^*$ . The operator  $B^0$  is given by the equalities

$$B^0u = \operatorname{div} u, \quad \mathcal{D}(B^0) = \left[\overset{\circ}{H^1}(\Omega)\right]^3.$$

It is known (see [Gr], for example) that

$$\mathcal{D}\big(A^{1/2}\big) \;=\; \left[\overset{\circ}{H^1}(\Omega)\right]^3 \;=\; \mathcal{D}\big(B^0\big) \;.$$

If the operator B is defined as above, then clearly  $B^* \supset B^0$ . Hence  $\mathcal{D}(B^*) \supset \mathcal{D}(A^{1/2})$ and all assumptions (i) – (iv) are satisfied. Moreover, as  $A \gg 0$ , we have  $0 = c^+$  $a^-$ . Thus the assumptions of Theorem 2.5 are fulfilled. It can be shown that the operator  $\overline{L_0}$  is identical to the realization of the Navier-Stokes operator defined by

G. GRUBB and G. GEYMONAT [GG]. From the results of [GG] it follows that the essential spectrum of  $\overline{L}_0$  consists of the two points -1 and -1/2. (In [GG] general results for Douglis-Nirenberg elliptic systems are obtained. In this particular case of the Navier-Stokes operator this fact can be shown in a simpler way, e. g. by making use of recent results due to A. KOZHEVNIKOV [K]). The Corollaries 2.6 and 2.7 lead to the following results which seem to be new for the operator (4.1).

**Theorem 4.1.** Let 
$$\left\{ \begin{pmatrix} u_k \\ p_k \end{pmatrix} \right\}_{1}^{\infty}$$
 and  $\left\{ \begin{pmatrix} u_k \\ p_k \end{pmatrix} \right\}_{-1}^{-\infty}$  be orthonormal systems of eigen-

functions of the operator  $\overline{L}_0$  corresponding to the positive and the negative eigenvalues, respectively. Then the systems  $\{u_k\}_1^{\infty}$  and  $\{p_k\}_{-1}^{-\infty}$  form Riesz bases in  $[L_2(\Omega)]^3$  and  $L_2(\Omega)$ , respectively.

#### Acknowledgements

The support of this work by the Deutsche Forschungsgemeinschaft, DFG, and by the Russian Fund of Fundamental Investigations, RFFI, is gratefully acknowledged.

The authors express their gratitude to DR. CHR. TRETTER and R. GRINIV who looked through the manuscript, marked misprints and errors and made useful remarks.

## References

- [A] ADAM, J. A.: Critical Layer Singularities and Complex Eigenvalues in Some Differential Equations of Mathematical Physics, Phys. Rep. (Review Section of Physics Letters), 142, No. 5 (1986), 263-356
- [AI] AZIZOV, T. JA., and IOCHVIDOV, I. S.: Introduction to the Theory of Linear Operators in Spaces with Indefinite Metric, Moscow, 1987. English translation:
- [AL] ADAMJAN, V. M., and LANGER, H.: Spectral Properties of a Class of Rational Operator Valued Functions, J. Operator Theory 33 (1995), 259-277
- [ALMS] ATKINSON, F. V., LANGER, H., MENNICKEN, R., and SHKALIKOV, A. A.: The Essential Spectrum of Some Matrix Operators, Math. Nachr. 167 (1994), 5-20
- [DK] DALETSKII, YU. L., and KREIN, M. G.: The Stability of Solutions of Differential Equations in Banach Space, Moscow, 1970. English translation:
- [G] GOEDBLOED, J. P.,: Lecture Notes on Ideal Magnetohydrodynamics, Rijnhiuzen Report, Form-Instituut voor Plasmafysica, Nieuwegein 1983, 83-145
- [GG] GRUBB, G. and GEYMONAT, G.: The Essential Spectrum of Elliptic Systems of Mixed Order, Math. Ann., 227 (1977), 247-276
- [GL] GOHBERG I., and LAITERER, Yu.: General Theorems on the Canonical Factorization of Operator Functions with Respect to a Contour, Mathem. Issledovaniya 7, No 3 (1972), 87-134
- [Gr] GRISVARD, P.: Characterisation de Quelques Espaces d'Interpolation, Arch. Rational Mech. Anal., 25 (1967), 40-63
- [K] KOZHEVNIKOV, A. N.: The Basic Boundary Value Problems of Statistic Elasticity Theory and Their Cosserat Spectrum, Math. Zeitschrift, 213 (1993), 241-274
- [Ka] Kato, T.: Perturbation Theory for Linear Operators, Springer-Verlag, New York, 1966
- [KL] KREIN, M.G., and LANGER, H.: On Certain Mathematical Principles of the Theory of Damped Oscillations of Continua, Proc. of the Intern. Symp. on Application of Function Theory in the Mechanics of Continuous Media, V. 2, Nauka, Moscow (1965), 284-322

- [L] LIFSCHITZ, A. E.: Magnetohydrodynamics and Spectral Theory, Kluwer Acad. Publishers, Dordrecht, 1989
- [LL] LANDAU L. D., and LIFSHITZ, E. M.: Fluid Mechanics. London: Pergamon Press, 1959
- [L1] LANGER, H.: Über eine Klasse nichtlinearer Eigenwertprobleme, Acta Scient. Math. 35 (1973), 79-93
- [L2] LANGER, H.: Spectral Functions of Definitizable Operators in Krein Spaces, Lecture Notes in Mathematics, Vol. 948 (1982), 1-46
- [M1] MOTOVILOV, A. K.: The Removal of an Energy Dependence from the Interaction in Two Body Systems, J. Math. Phys. 32 (1991), 3509-3518
- [M2] MOTOVILOV, A. K.: Potentials Appearing after the Removal of an Energy Dependence and Scattering by Them, Proc. Intern. Workshop "Math. Aspects of the Scattering Theory and Applications" (St. Petersburg, 1991), 101-108
- [MaM1] MALYSHEV, V. A., and MINLOS, R. A.: Invariant Subspaces of Clustering Operators. I., J. Stat. Phys. 21 (1981), 231-242
- [MaM2] MALYSHEV, V. A., and MINLOS, R. A.: Invariant Subspaces of Clustering Operators. II., Comm. Math. Phys. 82 (1981), 211-226
- [MM1] MARKUS, A.S., and MATSAEV, V.I.: On the Basis Property for a Certain Part of the Eigenvectors and Associated Vectors of a Selfadjoint Operator Pencil, Math. USSR Sbornik, 61, No 2 (1988), 289-307
- [MM2] MARKUS, A.S., and MATSAEV, V.I.: Principal Part of Resolvent and Factorization of an Increasing Nonanalytic Operator Function, Int. Equations and Operator Theory, 14 (1991), 716-746
- [MM3] MARKUS, A.S., and MATSAEV, V.I.: Factorization of a Selfadjoint Nonanalitic Operator Function. II. Single Spectral Zone. Int. Equations and Operator Theory, 16 (1993), 539-554
- [VM] VIROZUB, A. I., and MATSAEV, V. I.: The Spectral Properties of a Certain Class of Self-Adjoint Operator Functions, Funct. Anal. and Appl. 8, No 1 (1974), 1-9

Department of Mathematics
NWF I - Mathematik
Universität Regensburg
Universitätsstr. 31
D - 93053 Regensburg
Germany

Department of Mathematics and Mechanics Moscow State University Moscow, 119899 Russia (CIS)