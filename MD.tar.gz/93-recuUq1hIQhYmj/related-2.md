# **Removing the Stiffness from Interfacial Flows with Surface Tension**

THOMAS **Y.** Hou

*Applied Mathematics, California Institute of Technology, Pasadena, California 91125* 

JOHN S. LOWENGRUB

*School of Mathematics, University of Minnesota, Minneapolis, Minnesota 55455* 

*AND* 

MICHAEL J. SHELLEY

*Courant Institute of Mathematical Sciences, New York University, New York, New York 10012* 

Received October 12, 1993

A new formulation and new methods are presented for computing the motion of fluid interfaces with surface tension in two-dimensional, irrotational, and incompressible fluids. Through the Laplace-Young condition at the interface, surface tension introduces high-order terms, both nonlinear and nonlocal, into the dynamics. This leads to severe stability constraints for explicit time integration methods and makes the application of implicit methods difficult. This new formulation has all the nice properties for time integration methods that are associated with having a linear, constant coefficient, highest order term. That is, using this formulation, we give implicit time integration methods that have *no*  high order time step stability constraint associated with surface tension *and* are explicit in Fourier space. The approach is based on a boundary integral formulation and applies more generally, even to problems beyond the fluid mechanical context. Here they are applied to computing with high resolution the motion of interfaces in Hele-Shaw flows and the motion of free surfaces in inviscid flows governed by the Euler equations. One Hele-Shaw computation shows the behavior of an expanding gas bubble over long-time as the interface undergoes successive tip-splittings and finger competition. A second computation shows the formation of a very ramified interface through the interaction of surface tension with an unstable density stratification. In Euler flows, the computation of a vortex sheet shows its roll-up through the Kelvin-Helmholtz instability. This motion culminates in the late time self-intersection of the interface, creating trapped bubbles of fluid. This is, we believe, a type of singularity formation previously unobserved for such flows in 2D. Finally, computations of falling plumes in an unstably stratified Boussinesq fluid show a very similar behavior. © 1994 **Academic** Press, Inc.

#### **1. INTRODUCTION**

The surface tension at an interface between two immiscible fluids arises from the imbalance of their respec-

tive intermolecular cohesive forces. As such, surface tension has an everpresent effect on the dynamics of interfaces, but it is especially central to understanding such fluid phenomena as pattern formation in Hele-Shaw cells, the motion of capillary waves on free surfaces, the formation of fluid droplets, and noise generation at the ocean surface [36].

While numerical simulation has become one of the most important tools for investigating fluid interface problems, it is still difficult to include surface tension. Surface tension effects are modelled classically by positing a pressure jump at the interface that is proportional to the local curvature (the Laplace-Young condition). This introduces, into the equations of motion for the interface, terms that have a large number of spatial derivatives. If an explicit time integration method is used, these terms induce strong stability constraints on the time step. These stability constraints are generally time dependent, and become more severe by the differential clustering of points along the interface.

The presence of such constraints is referred to as *stiffness,*  with the standard example being the second-order timestep constraint At < *C•x 2* for an Euler integration of the heat diffusion equation. For the heat equation, this constraint can be removed by using an implicit integration method such as backward Euler or Crank-Nicholson. And so, the general approach is to discretize the highest order term implicitly. In many important cases, like the Navier-Stokes equations, the highest order term (i.e., diffusion) appears linearly. This leads to a linear system of equations to be solved for the solution at the next step. If periodic boundary

conditions are used, this system is trivially inverted by the Fourier transform. The situation is much more difficult for fluid interfaces with surface tension. The stiffness now enters *nonlinearily* with the surface tension, both because curvature is a nonlinear functional of interface position and because the curvature is embedded nonlinearly *and* nonlocally into the equations of motion. A straightforward implicit discretization leads then to a nonlinear and nonlocal system that must be solved to obtain the solution at the next time step.

We present a new formulation and new methods for computing the motion of a fluid interface with surface tension in a two-dimensional, irrotational, and incompressible fluid. This new formulation has all the nice properties for time integration methods that are associated with having a linear highest order term. Thus, our new numerical methods have no high order time step stability constraints that are usually associated with surface tension. This approach is based on the boundary integral formulation [6] and applies more generally, even to problems beyond the fluid mechanical context. Here, they are applied to computing the motion of interfaces in Hele-Shaw flow, which is quasi two-dimensional and viscously dominated, and to computing the motion of free surfaces in inviscid, inertially dominated flows governed by the Euler equations.

What practical difference does it make to be able to remove the stiffness due to surface tension? At the basest level, the time step can be chosen to satisfy accuracy rather than stability requirements (except perhaps for a first-order CFL condition). For computations of the vortex sheet rollup in an Euler flow (with surface tension) using a modest number of points (128), the time step can be chosen 250 times larger than for an analogous explicit method. In the broader sense, this means being able to compute flows that were previously unobtainable and thereby discover new phenomena. To illustrate, the roll-up computations, using up to 8192 points, reveal the late time self-intersection of the interface, which creates trapped bubbles of fluid. This is extremely interesting. A collision of interfaces is a singularity in the evolution and is of a type which has not been previously observed for such flows in 2D. In the context of roll-up problems, surface tension has been suggested as a physical regularization of the Kelvin-Helmholtz singularity [ 7 ]. And indeed, it does disperse this early time singularity, but by increasing the order of the system, new singularity types are allowed and realized.

The evolution of a fluid interface with surface tension is a complicated motion-by-curvature problem. Our approach consists of two key ideas. The first idea involves using a special frame of reference so that the interface's tangent angle (0, the angle between the tangent vector and the x-axis) and its length (L), rather than its x and y positions, are the dynamical variables. The utility of this description for treating stiffness introduced by curvature is illustrated

below with the prototypical example of motion by mean curvature. While this reformulation of plane curve motion is unusual, it is not new as we also indicate below. However, for treating stiffness in the fluid interface setting, wherein curvature terms enter nonlocally and nonlinearly, this is not enough. We need to use also that stability constraints (i.e., stiffness) arise from the influence of the high-order term *only at small spatial scales.* This leads to an asymptotic analysis of the fluid dynamic equations that precisely determines the dominating terms at small scales and thus the source of stiffness. The equations are then reformulated with the dominant terms separated. This reformulation is referred to as the small scale deeomposition. In the 0- L description, the application of implicit or linear propagator time integration methods is then straightforward. We also indicate how other, more general reference frames might be used without high order stiffness constraints as well.

We motivate the 0 - L approach by considering the normal motion of a closed, plane curve F by its local curvature. The "curve shortening" problem was introduced by Mullins [ 34 ] to study the motion of grain boundaries (see also [ 24 ] for a modern treatment and many other references). Specifically, let F be given by X(~, t) = (x(~, t), y(~, t)), where a parametrizes the curve. X evolves by

$$\mathbf{X}_{t} = U\mathbf{n}$$
, where  $U = \kappa$  and 
$$\kappa = x_{s} y_{ss} - x_{ss} y_{s} = (x_{\alpha} y_{\alpha \alpha} - x_{\alpha \alpha} y_{\alpha})/s_{\alpha}^{3}$$
 is the curvature 
$$\mathbf{n} = (-y_{s}, x_{s}) = (-y_{\alpha}, x_{\alpha})/s_{\alpha}$$
 is the inward normal. (1)

Of course, s is arclength, but it is ~ and t that are the independent variables, and not s and r Still, the 0~ and s derivatives *can* be exchanged through the relation *O/Os=(1/s~)(O/O~),* where *s,=xv/~+y2.* X is assumed 2n-periodic in 0~. Subscripts refer to partial differentiation.

The numerical solution of Eq.(1) would seem straightforward; discretize the curve uniformly ins, calculate the normal and curvature pseudospectrally, and integrate the resulting system using the method of lines. However, it is well known that Eq. (1) has a second-order diffusive character. Therefore, using an explicit integration gives a second-order stability constraint. An implicit integration method, such as Crank-Nicholson or backwards Euler, would presumably be more stable. But, the source of the stiffness is the curvature, a nonlinear functional of interface position. Therefore, discretizing the curvature fully implicitly would lead to a system of nonlinear equations for the solution at the next timestep.

The *O-L* approach, on the other hand, makes the application of an implicit method trivial. It rests on two steps:

- (A) Motivated by the identity 0, = x, for 0 the tangent angle to the curve F, formulate the evolution with 0 and s~ as the independent ,dynamical variables, rather than x and y.
- (B) Introduce a change of frame in the parametrization off so that s~ is independent of~ and depends only on time. And thus, s~ evolves as the length L of the curve F.

This formulation of plane curve motion is not new. See, for example, Strain [48] in the context of unstable solidification, or Goldstein and Petrich [ 20 ] in the context of integrable curve dynamics. We derive it here for purposes of completeness and illustration.

To start, we note that the *shape* of the interface is determined solely by its normal velocity U. A tangential motion gives only a change in frame for the parametrization of the interface. Hence, a tangential velocity (T) may be introduced into the dynamics without altering the shape of the interface. That is,

$$\mathbf{X}_t = U\mathbf{n} + T\mathbf{s}$$
, where  $\mathbf{s} = (x_s, y_s)$  is the unit tangent. (2)

Recalling that U = x = *O~/s~,* the evolution in terms of 0 and s~ is

$$s_{\alpha t} = T_{\alpha} - \frac{1}{s_{\alpha}} \theta_{\alpha}^2 \tag{3}$$

$$\theta_t = \frac{1}{s} \left( \frac{1}{s} \theta_{\alpha} \right) + \frac{T}{s} \theta_{\alpha}. \tag{4}$$

The origin of stability constraints is now clear; Eq. (4) is a *convection-diffusion* equation, and for an explicit method, the stability constraint from the diffusion term is of the form

$$\Delta t < \bar{C} \cdot (\bar{s}_{\alpha}h)^2, \tag{5}$$

where g~ = min~ s~, and h is the grid spacing in ~. Therefore, the stability constraint is determined by the minimum grid spacing (i.e., *hs~ ~ As),* which is time dependent, and for flow by curvature, ever decreasing.

The stiffness in Eqs. (3) and (4) is really encoded into the 0 evolution, rather than s~, and an implicit treatment of Eq. (4), is not so difficult. However, it becomes trivial if s~ does not depend upon ~ (i.e., (B) is satisfied). This can be done by a choice for T which enforces the constraint that s~ is everywhere equal to its mean. That is,

$$s_{\alpha}(\alpha, t) = \frac{1}{2\pi} \int_{0}^{2\pi} s_{\alpha'}(\alpha', t) d\alpha' = \frac{1}{2\pi} L(t),$$
 (6)

where L is the length of F. Then, T is given by

$$T(\alpha, t) = T(0, t) + \frac{2\pi}{L} \int_0^{\alpha} \theta_{\alpha'}^2 d\alpha' - \frac{\alpha}{L} \int_0^{2\pi} \theta_{\alpha'}^2 d\alpha'.$$
 (7)

If s~ initially satisfies the constraint (6), this choice for T maintains that constraint in time. Here, T(0, t) is simply an arbitrary change of frame that is taken to be 0. The PDE for s~ is now reduced to an ODE for L. Consequently, L and 0 evolve by

$$L_t = -\frac{1}{L} \int_0^{2\pi} \theta_{\alpha'}^2 d\alpha', \tag{8}$$

$$\theta_t = \left(\frac{2\pi}{L}\right)^2 \theta_{\alpha\alpha} + \frac{2\pi}{L} T\theta_{\alpha}. \tag{9}$$

Equation (8) is clearly "curve shortening." Moreover, implicit integration of Eq. (9) is now trivial; the highest order term has no spatially varying prefactor. An implicit method such as Crank-Nicholson, or a linear propagator scheme, can be applied to the diffusion term in Eq. (9). And if L is updated before 0, then the update of 0 is obtained *explicitly* in Fourier space. Finally, Eq. (8) for L is not stiff and so by integrating it using an explicit method such as Adams-Bashforth, the update for L can always be obtained before that of 0.

A superficial inspection of the evolution equations for (3) fluid interfaces using a 0-L approach does not reveal any practical treatment of the stiffness from surface tension. Indeed, for the simplest Hele-Shaw flow, the normal (4) velocity U is not x, but rather is a complicated nonlinear and nonlocal functional of h: which involves the Birkhoff-Rott integral (see Eqs. (15) and (20)). However, these considerations do not make use of the following fact: stability constraints (i.e., stiffness) arise from the influence of the high-order term *only at small spatial scales.* At small scales the Birkhoff-Rott operator simplifies enormously. For the Hele-Shaw flow with surface tension parameter S, (5) we show that

$$U \sim \frac{S}{2} \left(\frac{2\pi}{L}\right)^2 \mathcal{H}[\theta_{\alpha\alpha}]$$
 at small scales, (10)

where Jf is the (linear) Hilbert transform. The Hilbert transform is what survives of the Birkhoff-Rott integral at small scales, and it diagonalizes under the Fourier transform. For the 0 evolution, we can then write

$$\theta_t = \frac{S}{2} \left( \frac{2\pi}{L} \right)^3 \, \mathcal{H} \left[ \theta_{\alpha\alpha\alpha} \right] + N(\alpha, t), \tag{11}$$

**1 2~ d~'=lL(t),** s~(g, t) = ~ fo s,,(0~', t) (6) where the Hilbert transform term is the dominating highorder term at small spatial scales, and N contains other, lower order terms in the evolution. There is also an equation analogous to Eq. (8) for L. Such a reformulation of fluid interface evolution, as in Eq. (11 ), is a "small scale decomposition." It is within the small scale decomposition that implicit integration or linear propagator methods can be applied to a high order linear term. With periodic boundary conditions, these methods are *explicit* in Fourier space *and*  have no high-order time step constraint. The time-stepping methods are coupled to spectrally accurate spatial discretizations. Small scale decompositions are given also for more general Hele-Shaw flows and for interface flows under the Euler equations.

An example of what is possible with these methods is seen in Fig. 1, which shows the simulation of a gas bubble expanding into a Hele-Shaw fluid (see [ 15, 16]) over long times. From the competition of surface tension with the fluid pumping, this simulation shows the development of ramification through successive tip-splitting events and the competition between adjacent fingers. This simulation is also spectrally accurate in space and uses a second-order in time linear propagator method for integrating the smallscale decomposition. There are no high-order time step constraints. The fluid velocity is calculated using the fast multipole method [23], and GMRES [42] is used to solve the integral equation that arises from having a viscosity con- " trast [22]. The operation count is *O(N)* at each time-step, where N is the number of points describing the boundary. Here N= 4096, S = 0.001, and At = 0.001. The time step is 103 times larger than that used by Dai and Shelley [ 16] in computations of a similar flow using an explicit method

![](_page_3_Figure_4.jpeg)

FIG. 1. An expanding Hele-Shaw bubble.

with a lesser number of points, and the interface here has developed far more structure.

The organization of the paper is as follows. In Section 2, boundary integral formulations are given for the motion of fluid interfaces under surface tension in both Hele-Shaw and two-dimensional Euler flows. The interface is interpreted as a vortex sheet whose normal velocity is determined by the Birkhoff-Rott integral. Its vortex sheet strength is determined by the equations of motion and boundary conditions. In Section 3, the source of stiffness in these problems is discussed and motivated by the generalized linear stability analysis of Beale, Hou, and Lowengrub [10-12]. In Section4, the Birkhoff-Rott integral is carefully examined. It is shown that this integral, asymptotically at small scales, becomes a Hilbert transform of the sheet strength over a flat interface, with a variable prefactor. In Section 5, the description of the interface is reformulated in terms of 0 and L. This step makes the variable coefficient depend only upon time, and at small scales, the leading order terms are only nonlocal through a Hilbert transform. This leads to small scale decompositions for the evolution problems. In Section 6, numerical methods are discussed. This includes second-order integration methods that exploit the small scale decomposition to remove the high-order stiffness, generalizations to higher order time discretizations, as well as other related numerical issues such as spectrally accurate spatial discretizations. In Section 7 the results of numerical simulations using these methods are presented. These results include the motion of Hele-Shaw interfaces moving under the competing influences of gravity and surface tension, in addition to the expanding gas bubble. The roll-up and collision of vortex sheets with surface tension in an Euler flow is also given. Concluding remarks are given in Section 8.

# 2. THE FORMULATION

In this section, boundary integral formulations are given for two illustrative incompressible flows. The first describes the motion of an interface separating two Hele-Shaw fluids of differing densities and viscosities. The second describes the motion of a vortex sheet in a two-dimensional, inviscid fluid. As the concept of a vortex sheet arises also in the Hele-Shaw case, this second case is referred to as an *inertial*  vortex sheet.

Consider an incompressible and irrotational velocity field in two dimensions given in terms of a velocity potential: *(u,v)=V~.* Suppose that ~b has a jump across a parametrized interface F= (x(~), y(0~)), but that its normal derivative is continuous (see Fig. 2). This implies that the velocity has a tangential discontinuity across F while the component normal to F is continuous (i.e., the kinematic boundary condition is satisfied). Such an interface is called

![](_page_4_Figure_2.jpeg)

FIG. 2. A schematic showing  $\Gamma$ , the interface separating two Hele-Shaw fluids.

a vortex sheet (see [43]). The velocity away from the interface has the integral representation

$$(u(x, y), v(x, y)) = \frac{1}{2\pi} \int \gamma(\alpha') \frac{(-(y - y(\alpha')), x - x(\alpha'))}{(x - x(\alpha'))^2 + (y - y(\alpha'))^2} d\alpha' + \mathbf{V}(x, y, t),$$
(12)

where  $(x, y) \neq (x(\alpha), y(\alpha))$ . The velocity **V** accounts for other contributions to the motion not given by the integral term. **V** is assumed smooth, at least across  $\Gamma$ , and can arise for many reasons, such as to satisfy far-field boundary conditions or to account for other interfaces.  $\gamma$  is called the (unnormalized) vortex sheet strength and measures the velocity difference across  $\Gamma$ . It is given by

$$\gamma(\alpha) = s_{\alpha}((u_1, v_1) - (u_2, v_2))|_{\Gamma} \cdot \mathbf{s}. \tag{13}$$

This representation is well known; see [6 and 51, 27] for some applications to inertial and Hele-Shaw flows, respectively.

While there is a discontinuity in the tangential component of the velocity at  $\Gamma$ , the normal component,  $U(\alpha)$ , is continuous and is given by (12) as

$$U(\alpha) = \mathbf{W}(\alpha) \cdot \mathbf{n} \tag{14}$$

where

$$\mathbf{W}(\alpha) = \frac{1}{2\pi} \mathbf{P.V.} \int \gamma(\alpha')$$

$$\times \frac{(-(\gamma(\alpha) - \gamma(\alpha')), x(\alpha) - x(\alpha'))}{(\gamma(\alpha) - \gamma(\alpha'))^2 + (\gamma(\alpha) - \gamma(\alpha'))^2} d\alpha' + \mathbf{V}$$
(15)

and P.V. denotes the principal value integral. This integral is called the Birkhoff–Rott integral. This representation can be given for closed or open interfaces and for situations with multiple fluids and interfaces. For Hele–Shaw and Euler flows, our two main examples, the full formulations now follow.

#### 2.1. Hele-Shaw Flows

Consider an interface  $\Gamma$ , as shown in Fig. 2, which separates two Hele-Shaw fluids of differing, but uniform,

viscosities, and densities. For simplicity,  $\Gamma$  is assumed periodic in the x-direction. The fluid below  $\Gamma$  is labeled fluid 1 and that above is labeled fluid 2, and likewise for their respective viscosities, etc. The density and viscosity are assumed to be constant above and below  $\Gamma$ , but they can differ across  $\Gamma$ . The velocity in each fluid is given by Darcy's law, together with the incompressibility constraint:

$$\mathbf{u}_{j} = (u_{j}, v_{j}) = -\frac{b^{2}}{12\mu_{i}} \nabla(p_{j} - \rho_{j} gy), \qquad \nabla \cdot \mathbf{u}_{j} = 0.$$
 (16)

Here b is the gap width of the Hele-Shaw cell,  $\mu_j$  is the viscosity,  $p_j$  is the pressure,  $\rho_j$  is the density, and gy is the gravitational potential. The boundary conditions we take are

(i) 
$$[\mathbf{u}]_{\Gamma} \cdot \mathbf{n} = 0$$
, the kinematic boundary condition (17)

(ii) 
$$[p]_{\Gamma} = \tau \kappa$$
, the Laplace-Young condition (18)

(iii) 
$$\mathbf{u}_i(x, y) \to 0$$
 as  $|y| \to \infty$ , (19)

where  $[f]_{\Gamma} = f_1 - f_2$  and  $f_1, f_2$  are the limiting values from below and above the interface, respectively. In addition,  $\kappa$  is defined as in Eq. (1) so that a circle has positive curvature. Condition (i) requires that  $\Gamma$  moves with the fluids on either side. Condition (ii) relates the pressure jump across  $\Gamma$  to the interfacial curvature  $\kappa$ , where  $\tau$  is the surface tension. Condition (iii) specifies that the fluid is at rest far from the interface.

That the velocity field has the form given in (12) with V = 0 follows from Darcy's law (16), which implies that the flow is irrotational, the incompressibility constraint, and from the boundary conditions (i) and (iii). An equation for  $\gamma$  follows from these, together with the Laplace-Young condition (ii); see [51 or 16] for details. In nondimensional variables,  $\gamma$  satisfies

$$\gamma = -2A_{\mu}s_{\alpha}\mathbf{W} \cdot \hat{\mathbf{s}} + S\kappa_{\alpha} - Ry_{\alpha}. \tag{20}$$

Here  $A_{\mu} = (\mu_1 - \mu_2)/(\mu_1 + \mu_2)$  is the Atwood ratio of the viscosities, S is the nondimensional surface tension, and R is a signed measure of density stratification  $(\rho_1 < \rho_2)$  implies R < 0. Due to the presence of  $\gamma$  in the velocity W, Eq. (20) is a Fredholm integral equation of the second kind for  $\gamma$ , and is, in general, uniquely solveable (see [6]). Further, from Eq. (20),  $\gamma$  is also a perfect derivative in  $\alpha$ , and hence has zero mean. This implies that condition (iii) is automatically satisfies.

Finally, the motion of the  $\Gamma$  itself must be determined. To satisfy the kinematic condition (i), the normal velocity of the interface must be chosen to be U given by Eq. (14).

Again, the shape of the interface is determined solely by the normal velocity, and a choice of tangential velocity only modifies the frame of the parametrization. Accordingly, the motion of F is given by

$$\mathbf{X}_{t}(\alpha, t) = (x_{t}, y_{t}) = U\mathbf{n} + T\mathbf{s}.$$
 (21)

Once T is specified, Eqs. (20) and (21) determine the entire flow through the motion of F. The usual choice of frame, T = W. s, is called the Lagrangian frame and corresponds **to**  choosing T to be the average of the limiting tangential fluid velocities from above and below F.

*Remarks.* (1) Hele-Shaw flow can also be interpreted as two-dimensional porous media flow. There is also a correspondence of the Hele-Shaw flow to the Ostwald ripening problem, a quasi-stationary appoximation to diffusion. See [52], for example.

(2) Only the simplest, classical dynamic boundary condition for Hele-Shaw flows have been considered here. More physically realistic boundary conditions have been derived in [ 40 ].

#### **2.2. Inertial Vortex Sheets**

The formulation of the motion of an interface, F, separating inviscid, incompressible, and irrotational fluids, is similiar to that for the Hele-Shaw case. As before, the density is assumed to be constant on each side of F. Here, the velocity on either side of Fis evolved by Euler's equation

$$\mathbf{u}_{jt} + (\mathbf{u}_j \cdot \nabla) \mathbf{u}_j = -\frac{1}{\rho_j} \nabla (p_j + \rho_j gy), \qquad \nabla \cdot \mathbf{u}_j = 0. \quad (22)$$

There are now the boundary conditions:

$$(\mathbf{i}) \quad [\mathbf{u}]_{\Gamma} \cdot \mathbf{n} = 0$$
 (23)

$$[p]_{\Gamma} = \tau \kappa \tag{24}$$

(iii) 
$$\mathbf{u}_i(x, y) \to (\pm V_0, 0)$$
 as  $y \to \pm \infty$ . (25)

Since the fluid is irrotational and incompressible, condition (i) again guarantees a vortex sheet representation of the solution, again with V = 0. Using the representation (12) of the velocity, Euler's equation at the interface, and the Laplace-Young condition, the equations of motion for the interface are

$$\mathbf{X}_{t} = U\mathbf{n} + T\mathbf{s}$$

$$\gamma_{t} - \partial_{\alpha}((T - \mathbf{W} \cdot \mathbf{s}) \gamma/s_{\alpha})$$

$$= -2A_{\rho}(s_{\alpha}\mathbf{W}_{t} \cdot \mathbf{s} + \frac{1}{8}\partial_{\alpha}(\gamma/s_{\alpha})^{2} + gy_{\alpha}$$

$$- (T - \mathbf{W} \cdot \mathbf{s}) \mathbf{W}_{\alpha} \cdot \mathbf{s}/s_{\alpha}) + S\kappa_{\alpha},$$
(27)

where *Ap=(pl--P2)/(pl+P2 )* is the Atwood ratio of densities and S= *2z/(pl +* P2) is a rescaled surface tension parameter (see [6, 45]). In contrast to Hele-Shaw flows, the vortex sheet strength y is an independent dynamic variable. This is because the motion is governed by inertial forces (Euler's equation) rather than by viscous forces (Darcy's law). And now, Eq. (27) is a Fredholm integral of the second kind for y, due to the presence of ~)t in W,. The *kernel* of the equation is the same as that in the Hele-Shaw integral equation with A, replaced by *Ap.* Finally, the mean of 7 is preserved by Eq. (27) and must be chosen to be 2 Vo, initially, to guarantee that condition (iii) is satisfied.

#### **3. STIFFNESS AND LINEAR THEORY**

Numerical stiffness arises through the presence of highorder terms (i.e., many spatial derivatives) in the evolution. The role of surface tension in producing numerical stiffness is illustrated by considering first the linearized equations of motion about the flat equilibrium. That is, consider x(ct, t) = ~ + e~(~, t) and y(ct, t) = *eq(ct, t),* with e ~ 1. This is sufficient for Hele-Shaw flows as ~ is a dependent variable. For inertial vortex sheets, this is suppliemented by 7(~, t) = So + ee~(0~, t), where 7o is a constant. For definiteness, the Lagrangian frame T= W. s is taken, and for simplicity, A, = A s = 0 for both the Hele-Shaw and inertial flows.

The linearized Hele-Shaw equations of motion are

$$\xi_t = 0 \tag{28}$$

$$\eta_t = \frac{1}{2} \mathcal{H} [S\eta_{\alpha\alpha\alpha} - R\eta_{\alpha}], \tag{29}$$

where ~ is the Hilbert transform,

$$\mathscr{H}[f](\alpha) = \frac{1}{\pi} \int_{-\infty}^{+\infty} \frac{f(\alpha')}{\alpha - \alpha'} d\alpha'. \tag{30}$$

is a skew-symmetric linear operator, is diagonalized by the Fourier transform, and satisfies

$$\mathcal{H}[e^{ikx}] = -i\operatorname{sgn}(k) e^{ikx}, \qquad \mathcal{H}[1] = 0. \tag{31}$$

Consequently, the linear growth rate for the amplitude perturbation t/is

$$\sigma_k = -\frac{1}{2}(S|k|^3 + R|k|). \tag{32}$$

Therefore, if R < 0, there is a band of unstable modes near (26) k = 0. This is a Saffman-Tayl0r type instability, driven by the unstable density stratification. At higher wavenumbers, this instability is cut off by the surface tension term which acts as third-order diffusion. Thus, in linearized Hele-Shaw (27) flows, surface tension is a *dissipative* regularization.

The source of stiffness is made clear by the linear motion. The stability constraint for an explicit time integration method applied to Eq. (29) has the form

$$\Delta t < C \cdot h^3 / S,\tag{33}$$

where C is a constant and h is the spatial grid size. However, this actually *understates* the case for the full motion of Hele-Shaw interfaces. Beale, Hou, and Lowengrub [12] have considered more general linearizations about an arbitrary, evolving interface  $\Gamma = (x(\alpha, t), y(\alpha, t))$ . As in the equilibrium case, they find the dominant behavior to be governed by  $\eta$ , now the component of the perturbation normal to the interface  $\Gamma$ . Its dominant behavior is given by

$$\eta_{t} = -R \frac{x_{\alpha}}{s_{\alpha}} \mathcal{H}[\eta_{\alpha}] + S \frac{1}{s_{\alpha}^{3}} \mathcal{H}[\eta_{\alpha\alpha\alpha}]. \tag{34}$$

A "frozen coefficient" analysis of Eq. (34) reveals the stricter stability constraint

$$\Delta t < C \cdot (\bar{s}_{\alpha}h)^3 / S, \tag{35}$$

where  $\bar{s}_{\alpha} = \min_{\alpha} s_{\alpha}$ . Therefore, the stability constraint is determined by the minimum grid spacing in arclength, which is strongly time dependent. Our experience is that the Lagrangian motion of the points can lead to "point clustering" and hence to very stiff systems, even for flows in which the interface is smooth and the surface tension is small

For inertial vortex sheets, the growth rate for perturbations about the flat equilibrium is given by

$$\sigma_k^2 = V_0^2 k^2 - \frac{S}{2} |k|^3. \tag{36}$$

Again, the surface tension controls a high wave-number instability. The instability here is the Kelvin-Helmholtz instability and it is due to the shearing motion across the interface. As can be seen from the growth rate, the surface tension is a dispersive regularization in contrast to the Hele-Shaw case where it is dissipative. Again, by linearizing around the time dependent inertial vortex sheet  $\Gamma = (x(\alpha, t), y(\alpha, t))$  with strength  $\gamma(\alpha, t)$ , Beale et al. [10, 12] find the dominant behavior for  $\eta$ , again the normal component of the perturbation, to be

$$\eta_{tt} = -\frac{\gamma^2}{4s_\alpha^4} \eta_{\alpha\alpha} + \frac{S}{2s_\alpha^3} \mathcal{H}[\eta_{\alpha\alpha\alpha}]. \tag{37}$$

The perturbation in  $\gamma$  is eliminated, to leading order, by using two time derivatives on  $\eta$ . A frozen coefficient analysis leads to the dynamic stability constraint

$$\Delta t < C \cdot (\bar{s}_{\alpha}h)^{3/2}/S. \tag{38}$$

While the time step constraint (38) is less restrictive than that for Hele-Shaw flows, our experience is that point clustering, through the Lagrangian point motion, still leads to prohibitively stiff systems.

#### 4. THE SMALL SCALE BEHAVIOR OF U

The stiffness of an explicit method occurs because the evolution at small length scales is controlled by a high order term introduced by the curvature. The normal velocity U from the Birkhoff-Rott integral contains the physically relevant part of the velocity field, and the curvature appears in it through the vortex sheet strength. In this section, the small scale behavior of U is analyzed and precisely determined in terms of the vortex sheet strength.

First, the normal velocity U is given in a convenient form. Let the complex position of the interface be given by  $z(\alpha, t) = x(\alpha, t) + iy(\alpha, t)$ . Then, the normal velocity is given by

$$U(\alpha, t) = -\frac{1}{s_{\alpha}} \operatorname{Im} \left\{ \frac{z_{\alpha}}{2\pi i} \operatorname{P.V.} \int_{-\infty}^{+\infty} \frac{\gamma(\alpha', t)}{z(\alpha, t) - z(\alpha', t)} d\alpha' \right\}.$$
(39)

This quantity is clearly related to the Hilbert transform of the vortex sheet strength  $\gamma$  over the curved interface  $\Gamma$ . Our original intuition was that the small-scale behavior of this expression could be found by simply retaining one term in the expansion of the denominator in the Birkhoff-Rott integral to yield a Hilbert transform over a flat interface,  $z=\alpha$ , with a variable coefficient prefactor. This intuition is set rigorously in the following way. The kernel in the Birkhoff-Rott integral is rewritten as

$$\frac{1}{z(\alpha, t) - z(\alpha', t)} = \frac{1}{z_{\alpha} \cdot (\alpha - \alpha')} + \left[ \frac{1}{z(\alpha, t) - z(\alpha', t)} - \frac{1}{z_{\alpha} \cdot (\alpha - \alpha')} \right].$$
(40)

Note that the bracketed term has a removable singularity at  $\alpha = \alpha'$ , provided that z is a smooth function of  $\alpha$ , the interface does not self-intersect, and  $s_{\alpha} > 0$ . The Birkhoff-Rott integral can then be rewritten as

P.V. 
$$\int_{-\infty}^{+\infty} \frac{\gamma(\alpha', t)}{z(\alpha, t) - z(\alpha', t)} d\alpha'$$
$$= \frac{\pi}{z_{\alpha}} \mathscr{H}[\gamma] + \int_{-\infty}^{+\infty} \gamma(\alpha', t) g(\alpha, \alpha', t) d\alpha', \quad (41)$$

where g is the term in the brackets of Eq. (40). Thus, the

integral term containing g is a smoothing operator on y. This proves the following result.

TrmOREM 1 (Small scale behavior of U). *Suppose that the coordinates ofF, (x(oc,* t), y(ct, t)), *are real analytic functions of oc for t <% T. Suppose that the strip of analyticity about the real axis is given by* I Im *ocl <% p with p > O. Suppose further that F does not self-intersect and that s~ > O. Then* 

$$U(\alpha, t) = \frac{1}{2s_{\alpha}} \mathcal{H}[\gamma](\alpha, t) + E[\gamma](\alpha, t)$$
 (42)

*for t <~ T, where E is a smoothing operator on y so that its Fourier transform satisfies* ~[Y] *:O(e--plkl~) for large wavenumber* Ikl.

*Remarks.* (1) It is important to note that the theorem holds *for any y* for which the Fourier transform is defined. It shows that there is no distinction between the cases where 7 is a variable that is *independent* of position (inertial vortex sheets) or a *dependent* variables of position (Hele-Shaw).

(2) This theorem can be viewed as a consequence of a much more general result. Let E denote a generic smoothing operator, and let G(a, ~') be an analytic function of~, but not necessarily of 0(. Then,

$$\mathcal{H}[G(\alpha, \cdot)](\alpha) \equiv \frac{1}{\pi} \text{ P.V.} \int_{-\infty}^{+\infty} \frac{G(\alpha, \alpha')}{\alpha - \alpha'} d\alpha'$$

$$= \frac{1}{\pi} \text{ P.V.} \int_{-\infty}^{+\infty} \frac{G(\alpha', \alpha')}{\alpha - \alpha'} d\alpha' + E[G(\alpha, \cdot)]$$
(43)

which shows that the small scale behavior of ~[ G(0c,. )] is controlled by the diagonal part of G, i.e., ~[G(.,.)]. Moreover, at small scales, smooth functions can be passed through Hilbert transforms as follows. Suppose that g is analytic, then

$$\mathcal{H}[fg] = g\mathcal{H}[f] + E[f], \tag{44}$$

so that the small scale behavior of *~[fg]* is controlled by *g~[f].* 

(3) The assumption of analyticity to obtain (42)-(44) can be relaxed to include functions with only a finite number of derivatives. The only difference is that the definition of the smoothing operator E must be changed accordingly. For example, rather than being exponentially smoothing at the high modes, E smoothes to only a finite degree. That is, /~[f] = O( Ikl "mJ~), for large Ikl, where m is the number of assumed derivatives.

A useful notation, f~ g, is introduced to mean that the difference betweenfand g is smoother thanfand g. And so,

$$U(\alpha, t) \sim \frac{1}{2s_{\alpha}} \mathcal{H}[\gamma](\alpha, t). \tag{45}$$

Now consider the dominant terms of y (and *Yt)* at small scales.

(A) *Hele-Shaw flow.* Recall that the vortex sheet strength is given by

$$\gamma = -2A_{\mu}s_{\alpha}\mathbf{W} \cdot \mathbf{s} + S\kappa_{\alpha} - Ry_{\alpha} \tag{46}$$

which is a Fredholm integral equation of the second kind for 7- The integral term, s~W. s, is actually a smoothing operator on y. Then, roughly speaking, at small scales the integral term becomes negligible, relative to the explicit presence of 7, and an *explicit* expression for y is obtained. To make this argument entirely valid, the fact that the integral equation is invertible with a bounded inverse must be used. This argument is given in Appendix 1. And so, y is dominated at small scales by *Sx~-Rye.* But, y is really dominated by only *Sx~,* which has more derivatives than y~. Therefore,

$$\gamma(\alpha, t) \sim S\kappa_{\alpha}.$$
 (47)

(B) *Inertial vortex sheets.* In the case of inertial vortex sheets, y is an independent variable, with its time derivative given by Eq. (27). It is now for 7, that the dominant terms are found. By a similar approach,

$$\gamma_t(\alpha, t) \sim S\kappa_{\alpha}.$$
 (48)

In the present formulations, Eqs.(20) and (21) for Hele-Shaw and Eqs. (26) and (27) for inertial vortex sheets, it is unclear how to take advantage of this information as the dominating terms involve the curvature, a nonlinear functional of interface position. However, the 0-L and, more generally, the 0- s~ formulation are naturally related to the curvature by the property 0s = x.

#### **5. THE 0 - s, FORMULATION**

The motion of F is reposed in terms of its tangent angle 0(0c, t) and its local arclength derivatives s~. Derivations have been given elsewhere (e.g., [48 or 20]), but for completeness it is included here. 0 is the angle between s and the x-axis. It satisfies

$$\mathbf{s}(\alpha, t) = (x_{\alpha}(\alpha, t), y_{\alpha}(\alpha, t))/s_{\alpha}(\alpha, t)$$
$$= (\cos \theta(\alpha, t), \sin \theta(\alpha, t)), \tag{49}$$

Recall that F evolves according to

$$\mathbf{X}_{t} = U\mathbf{n} + T\mathbf{s},\tag{50}$$

where U = W. n is the normal component of the velocity W, (45) and T is as yet unspecified. Using the Fr6net formulae, 8~s=xn and 8~n= -xs, together with *O~=x* and *O/8s= (1/s~)(8/OoO,* it is easy to see that s~ and 0 satisfy

$$S_{\alpha t} = T_{\alpha} - \theta_{\alpha} U \tag{51}$$

$$\theta_t = \frac{1}{s_\alpha} U_\alpha + \frac{T}{s_\alpha} \theta_\alpha. \tag{52}$$

Given s~ and 0, the position (x(a, t), y(0c, t)) is reconstructed up to a translation by direct integration of Eq. (49). In many problems, the motion is translation invariant and thus this lost constant is irrelevant. However, a single point on the interface can be evolved to provide the constant of integration. The velocities U and T can then be constructed and s~ and 0 updated through Eqs. (51) and (52).

#### **5.1. The Equations of Motion Reposed**

Using this formulation, the general small scale decomposition is given for Hele-Shaw and inertial flows. The dominant small scale behavior is assumed to come from the U~ term in the 0 equation and the curvature term in the y equation. U~ explicitly contains the curvature in the Hele-Shaw case and the vortex sheet strength in the inertial vortex sheet case. The evolution of s~ will be recast in terms of L in the next section.

(A) *Small scale decomposition: Hele-Shaw flow.* For the Hele-Shaw case, using that tc = *O~/s~* and recalling Eqs. (45) and (47), Eq. (52) becomes

$$\theta_{I} = \frac{S}{2} \frac{1}{s_{\alpha}} \left( \frac{1}{s_{\alpha}} \mathcal{H} \left[ \frac{\theta_{\alpha}}{s_{\alpha}} \right]_{\alpha} \right)_{\alpha}$$

$$+ \left[ \frac{1}{s_{\alpha}} U_{\alpha} - \frac{S}{2} \frac{1}{s_{\alpha}} \left( \frac{1}{s_{\alpha}} \mathcal{H} \left[ \frac{\theta_{\alpha}}{s_{\alpha}} \right]_{\alpha} \right)_{\alpha} \right] + \frac{1}{s_{\alpha}} \theta_{\alpha} T \quad (53)$$

$$= \frac{S}{2} \frac{1}{s_{\alpha}} \left( \frac{1}{s_{\alpha}} \mathcal{H} \left[ \frac{\theta_{\alpha}}{s_{\alpha}} \right]_{\alpha} \right)_{\alpha} + N(\alpha, t), \quad (54)$$

where N is defined as the remaining terms, on the right-hand side of Eq. (53), not included in the first term. By extracting the dominant term, the Hele-Shaw evolution is now in a form that reveals clearly the dominating behavior at small scales. But most importantly, if s, is considered to be given, the dominant small scale term is *linear* in the tangent angle 0, but *nonlocal* by virtue of the Hilbert transform and *variable coefficient* by the presence of s~.

(B) *Small scale decomposition: Inertial vortex sheets.*  Analogously, Eqs. (45) and (48) are used to give the 0 and y evolution for an inertial vortex sheet, in a way that displays the small scale dominating terms,

$$\theta_{t} = \frac{1}{2} \frac{1}{s_{\alpha}} \left( \frac{1}{s_{\alpha}} \mathcal{H}[\gamma] \right)_{\alpha} + P, \tag{55}$$

$$\gamma_t = S\left(\frac{\theta_\alpha}{s_\alpha}\right)_\alpha + Q. \tag{56}$$

Again, P and Q represent the remainder terms. Assuming, as before, that s, is given, the dominant small scale terms are linear in 0 and 7, nonlocal, and also variable coefficient.

As was the case for curve shortening ( U = x), the leading order terms in both cases (A) and (B) simplify considerably if s~ is independent of co. Again, this is enforced by a choice for T, the tangential velocity. We do remark, though, that in some situations it may be preferable to use other choices of T. Other choices may prove to be useful to resolve regions of high curvature or to naturally handle anisotropic surface energies. If that is the case, the general small scale decomposition, given above, may still be useful for implicit integration methods since the leading order terms are linear in0 (and X). Additional reference frames are given in Appendix 2 and are currently under study.

# **5.2. The 0 - L Formulation**

The general expression for T is now given so that s~ is independent of ~ in its evolution; s= will then depend only upon *t,* and the PDE (51) for s~ reduces to an ODE. Moreover, the dominant terms at small scales in Eq. (54) for Hele-Shaw and Eqs. (55) and (56) for inertial vortex sheets, become constant coefficient in space.

As in the Introduction, s~ is required to be everywhere equal to its mean, that is

$$s_{\alpha}(\alpha, t) = \frac{1}{2\pi} \int_{0}^{2\pi} s_{\alpha'}(\alpha', t) d\alpha' = \frac{1}{2\pi} L(t),$$
 (57)

where L is the length of the interface. By differentiating Eq. (57) with respect to t and using Eq. (51), Tis found to be

$$T(\alpha, t) = T(0, t) + \int_0^{\alpha} \theta_{\alpha'} U \, d\alpha' - \frac{\alpha}{2\pi} \int_0^{2\pi} \theta_{\alpha'} U \, d\alpha', \quad (58)$$

which expresses T entirely in terms of 0 and U. The spatial constant T(0, t) just gives an overall temporal shift in frame. For simplicity, it will be taken to be 0, although in principle, it could be evolved as well. Thus, if s, is initially uniform in ~, then the choice for T in Eq. (58) will maintain that constraint in time. An expression for L, is found directly by using Eqs. (51), (57), and (58). The evolution of the interface is now given in terms of L and 0 by

$$L_{t} = -\int_{0}^{2\pi} \theta_{\alpha'} U \, d\alpha' \tag{59}$$

$$\theta_t = \left(\frac{2\pi}{L}\right) (U_\alpha + \theta_\alpha T). \tag{60}$$

Given U, Eqs. (58), (59), and (60) are a complete formulation of the evolution problem. We note that this choice of frame through T is actually a special case of other, more general choices of frames. See Appendix 2.

The small scale decompositions for Hele-Shaw and inertial vortex sheet flows in the 0-L formulation are now given:

(A) *Small scale decomposition: Hele-Shaw flow.* In the 0- L formulation, Eq. (55) simplifies to

$$\theta_t = \frac{S}{2} \left( \frac{2\pi}{L} \right)^3 \mathcal{H} [\theta_{\alpha\alpha\alpha}] + N(\alpha). \tag{61}$$

Here, N is that inferred from Eq. (54) with the choice of T in Eq. (58). Equation (61 ) is posed, together with Eq. (59), the ODE for evolving L, and is a complete specification of the interfacial problem, with the highest order, linear behavior prominently displayed. This term is now diagonalizable by the Fourier transform, and so

$$\hat{\theta}_{t}(k) = -\frac{S}{2} \left(\frac{2\pi}{L}\right)^{3} |k|^{3} \,\hat{\theta}(k) + \hat{N}(k). \tag{62}$$

Implicit time integration methods, such as Crank-Nicholson differencing, or linear propagator methods, can now be easily applied.

(B) *Small scale decomposition: lnertial vortex sheets.*  Analogously, for the inertial vortex sheet, the equations in k'-space are

$$\hat{\theta}_t(k) = \frac{1}{2} |k| \left(\frac{2\pi}{L}\right)^2 \hat{\gamma}(k) + \hat{P}(k), \tag{63}$$

$$\hat{\gamma}_t(k) = -Sk^2 \frac{2\pi}{L} \hat{\theta}(k) + \hat{Q}(k). \tag{64}$$

Here, P and Q are those inferred by in Eqs. (55) and (56), with the choice of T in Eq. (58). The diagonalization of the leading order, linear system is trivial. And again, these equations must be posed together with Eq. (59).

#### **6. NUMERICAL METHODS**

In this section, discrete methods are discussed for computing the motion of inertial vortex sheets and Hele-Shaw interfaces. We begin by considering two types of time integration methods. Both methods use the 0-L small scale decomposition in a crucial way. The first uses an integrating factor to remove the leading order term and gives an explicit time discretization under the Fourier transform. This is the linear propagator method. The second is an implicit Crank-Nicholson discretization of the leading order term, which also gives an explicit method under the Fourier transform. Spatial discretizations are chosen to be spectrally accurate.

Assume for now that space is continuous. We begin by discussing the time integration of the length L. Its ordinary differential equation (59) can be discretized with an explicit method. In the calculations presented here, the secondorder Adams-Bashforth method is used,

$$L^{n+1} = L^n + \frac{\Delta t}{2} (3M^n - M^{n-1}), \tag{65}$$

where the superscript denotes the time level and M is given by

$$M = -\int_0^{2\pi} \theta_{\alpha'} U \, d\alpha'. \tag{66}$$

As this is an explicit method, L can be updated before either 0 or T. The 0 (and V) discretizations will require this updated L.

# **6.1. Hele--Shaw Time Discretizations**

*The Linear Propagator Method* 

Linear propagator methods factor out the leading order linear term prior to discretization. They usually provide stable, even high-order, methods for integrating diffusive problems. Linear propagator methods apply also to dispersive problems, but must be used more carefully. These methods have the property that in the absence of nonlinearity and variable coefficients, the discrete solution gives the exact solution to the constant coefficient linear problem. That is, the linear modes are propagated exactly. The first use of such a method (of which the authors are aware) is Rogallo [41] in simulations of the Navier-Stokes equations, although it has been rediscovered and used by several researchers in different contexts.

For Hele-Shaw, we rewrite Eq. (62) as

$$\frac{\partial}{\partial t}\psi(k,t) = \exp\left(\frac{S}{2}(2\pi |k|)^3 \int_0^t \frac{dt'}{L^3(t')}\right) \hat{N}(k,t), \quad (67)$$

where

$$\psi(k, t) = \exp\left(\frac{S}{2} (2\pi |k|)^3 \int_0^t \frac{dt'}{L^3(t')}\right) \hat{\theta}(k, t)$$
 (68)

Equation (67) follows from Eq. (62) by finding an integrating factor to incorporate the linear term into the time derivative. It is now Eq. (67) that is discretized using the second-order Adams-Bashforth method. In terms of 0, the result is

$$\hat{\theta}^{n+1}(k) = e_k(t_n, t_{n+1}) \, \hat{\theta}^n(k) + \frac{\Delta t}{2} \, (3e_k(t_n, t_{n+1}) \, \hat{N}^n(k) - e_k(t_{n-1}, t_{n+1}) \, \hat{N}^{n-1}(k)), \tag{69}$$

where  $t_n = n \Delta t$ , and

$$e_k(t_1, t_2) = \exp\left(-\frac{S}{2} (2\pi |k|)^3 \int_{t_1}^{t_2} \frac{dt'}{L^3(t')}\right). \tag{70}$$

The use of "linear propagator" is now clear;  $\hat{\theta}$  at the *n*th time step is propagated forward to the (n+1)th timestep at the exact exponential rate associated with the linear term. If  $N \equiv 0$ , this yields the *exact* solution to the linear problem. Of course, the factor  $e(t_1, t_2)$  still has a continuous time dependence. We retain second order by replacing the integrals with their trapezoidal rule approximations, i.e.,

$$e_{k}(t_{n}, t_{n+1}) = \exp\left(-\frac{S \Delta t}{4} (2\pi |k|)^{3} \left[\frac{1}{(L^{n})^{3}} + \frac{1}{(L^{n+1})^{3}}\right]\right)$$

$$e_{k}(t_{n-1}, t_{n+1}) = \exp\left(-\frac{S \Delta t}{2} (2\pi |k|)^{3} + \frac{1}{2(L^{n-1})^{3}} + \frac{1}{2(L^{n+1})^{3}}\right).$$
(71)

Thus, in the numerical scheme,  $\theta$  is propagated by a secondorder approximation of the exact exponential rate. Recall that  $L^{n+1}$  is computed explicitly by Eq. (65).

Remarks. 1. Near equilibrium, the second-order linear propagator method is unconditionally stable. That is, we require only  $\Delta t \leq C(S)$  independently of the wavenumber k. More generally, however, there may be a CFL condition arising from the transport term hidden in N (see Eqs. (53) and (54)). This term is not seen in the near equilibrium analysis. The long time simulations are always performed with a CFL condition in mind. The exponential damping factors also tend to suppress instabilities such as those arising from aliasing errors or underresolution. It has also been observed that, in the presence of singular behavior of the interface, this method tends to oversmooth the solution [19]. This difficulty is overcome by reducing the time step. We believe that it may also be ameliorated by using higher order time discretizations. If the solution is smooth, then this difficulty is not noticeable.

2. An advantage of a linear propagator method is that it is easy to derive higher order time discretizations. This is clear if there is no time-dependence in the coefficient of the linear term. On the other hand, if there is time dependence (as is the case here), then a time integral appears in the integrating factor (see Eq. (68)). An explicit quadrature of this integral is avoided by introducing a new independent variable corresponding exactly to the integral. Let I = I[L](t) be given by

$$I(t) = \int_0^t \frac{dt'}{L^3(t')}$$
 (72)

and so

$$I_t = \frac{1}{L^3}, \qquad I(0) = 0.$$
 (73)

Then, we supplement the original system (59) and (67) and solve

$$L_t = M[L, I, \psi](t) \tag{74}$$

$$I_t = \frac{1}{L^3} \tag{75}$$

$$\psi_t = e^{I(S/2)(2\pi |k|)^3} \hat{N}[L, I, \psi](k, t). \tag{76}$$

It is now straightforward to discretize this system to high order. Fourth-order Runge-Kutta is currently being implemented.

Crank-Nicholson Discretization

Another stable scheme is obtained by using the Crank-Nicholson discretization on the leading order stiff term and leapfrog on the nonlinearity. This gives the second-order integration

$$\frac{\hat{\theta}^{n+1}(k) - \hat{\theta}^{n-1}(k)}{2\Delta t} = -\frac{S|k|^3}{2} \left( \left( \frac{2\pi}{L^{n+1}} \right)^3 \hat{\theta}^{n+1}(k) + \left( \frac{2\pi}{L^{n-1}} \right)^3 \hat{\theta}^{n-1}(k) \right) + \hat{N}^n(k).$$
(77)

Since  $L^{n+1}$ ,  $L^n$ , and  $L^{n-1}$  are known, Eq. (77) gives an explicit expression for  $\hat{\theta}^{n+1}(k)$ .

Remarks. 1. A near equilibrium analysis shows that this method is unconditionally stable. Again, there may be a CFL condition from the transport term. Our computations confirm stability for short times, but they also indicate that for long times and, in the fully nonlinear regime, that the Crank-Nicholson method is susceptible to an aliasing instability. The time of onset of this instability increases as the spatial resolution is increased. However, we find that we can control this instability and retain accuracy, even over long times, by the application of a high-order Fourier filter (25 th order). We will discuss this further when we give the spatial discretizations and numerical results.

2. The Crank-Nicholson discretization may also be useful to compute in other frames of reference (i.e., using other choices of T). Of course,  $s_{\alpha}$  is no longer constant in  $\alpha$ , but the general small scale decompositions (54) and (55), (56) still apply. The PDE for  $s_{\alpha}$  is not expected to be stiff and the leading order terms in the  $\theta$  (and  $\gamma$ ) equations are still linear in  $\theta$  (and  $\gamma$ ), albeit with variable coefficients. Thus by

updating  $s_{\alpha}$  explicitly, a linear, but not diagonal, system can be obtained for the updates of  $\theta$  (and  $\gamma$ ). This system could then be solved by an iterative method such as GMRES [42].

#### 6.2. Inertial Vortex Sheet Time Discretizations

The Crank-Nicholson Discretization

A stable integration can be obtained by discretizing the leading order stiff terms implicitly using the Crank-Nicholson discretization. There are two possible ways of doing this. In one, the Eqs. (63) and (64) are diagonalized before the Crank-Nicholson discretization is used. However, we find it sufficient (and simpler) to use the Crank-Nicholson discretization directly on Eqs. (63) and (64), to give the method

$$\frac{\hat{\theta}^{n+1} - \hat{\theta}^{n-1}}{2\Delta t} = \frac{|k|}{4} \left( \left( \frac{2\pi}{L^{n+1}} \right)^2 \hat{\gamma}^{n+1} + \left( \frac{2\pi}{L^{n-1}} \right)^2 \hat{\gamma}^{n-1} \right) + \hat{P}^n(k) \quad (78)$$

$$\frac{\hat{y}_{2}^{n+1} - \hat{y}^{n-1}}{2\Delta t} = -\frac{S}{2}k^{2}\left(\frac{2\pi}{L^{n+1}}\hat{\theta}^{n+1} + \frac{2\pi}{L^{n-1}}\hat{\theta}^{n-1}\right) + \hat{Q}^{n}(k). \tag{79}$$

Now  $\hat{\theta}^{n+1}(k)$  and  $\hat{\gamma}^{n+1}(k)$  can be found explicitly by inverting a  $2 \times 2$  matrix.

Remarks. 1. A near equilibrium analysis shows that this method is unconditionally stable. Again there is the possibility that a CFL condition must be satisfied. As in the Hele-Shaw case, this method suffers from an aliasing instability at long times in the fully nonlinear regime. As before, the onset time increases with increasing resolution. And again, we find that we can control this instability and retain accuracy, even over long times, by the application of a high-order Fourier filter (25th order).

- 2. The scheme resulting from diagonalizing Eqs. (63) and (64) first, and then applying Crank-Nicholson is also unconditionally stable near equilibrium. It has not been implemented.
- 3. As in the Hele-Shaw case, the Crank-Nicholson discretization is adaptable to different choices of reference frames.

#### The Linear Propagator Method

A linear propagator method can also be constructed. This involves diagonalizing Eqs. (63) and (64) so as to write

$$\frac{\partial}{\partial t} \left( e^{-i\sqrt{(S/2)(2\pi|k|)^3} \int_0^t (dt'/L^{3/2}(t'))} v_1 \right) 
= e^{-i\sqrt{(S/2)(2\pi|k|)^3} \int_0^t (dt'/L^{3/2}(t'))} \tilde{F}_1$$
(80)

$$\frac{\partial}{\partial t} \left( e^{i\sqrt{(S/2)(2\pi|k|)^3}} \int_0^t (dt'/L^{3/2}(t')) v_2 \right.$$

$$= e^{i\sqrt{(S/2)(2\pi|k|)^3}} \int_0^t (dt'/L^{3/2}(t')) \tilde{F}_2, \tag{81}$$

where

$$\mathbf{v} = (v_1, v_2) = \Omega^{-1} \mathbf{w}, \qquad \mathbf{w} = (\hat{\theta}, \hat{\gamma})$$
 (82)

$$\mathbf{F} = (\tilde{F}_1, \tilde{F}_2) = \Omega^{-1} \mathbf{F} - \Omega^{-1} \Omega_1 \mathbf{v}, \qquad \mathbf{F} = (\hat{P}, \hat{Q})$$
 (83)

with the basis matrix  $\Omega$  given by

$$\Omega = \begin{bmatrix} \frac{|k|}{2} \left(\frac{2\pi}{L}\right)^2 & \frac{|k|}{2} \left(\frac{2\pi}{L}\right)^2 \\ i \left[ \left(\frac{2\pi |k|}{L}\right)^3 \frac{S}{2} \right]^{1/2} & -i \left[ \left(\frac{2\pi |k|}{L}\right)^3 \frac{S}{2} \right]^{1/2} \end{bmatrix}.$$

These equations can now be straightforwardly discretized in time in an analogous manner as was done for the Hele-Shaw case (see the previous section). The second-order Adams-Bashforth method is implemented for these equations. While it is difficult to identify analytically the stability constraint near equilibrium, it is clear that this discretization is *not* unconditionally stable. While there is certainly a restriction of the form  $\Delta t \leq C(Sh)^{1/2}$ , it seems, computationally, that the actual stability constraint is similar to that of the original system:  $\Delta t \leq C(Sh)^{3/2}$ . However, we believe that this constraint can be removed by another choice of integration method, found perhaps by using a method of undetermined coefficients.

#### 6.3. Spatial Discretization

For most of the calculations presented, the interface  $\Gamma$  is assumed to be  $2\pi$ -periodic in the x-direction, that is,  $(x(\alpha+2\pi,t),y(\alpha,t))=(2\pi+x(\alpha,t),y(\alpha,t))$ . In those cases, the Birkhoff-Rott integral (in its complex form) is reduced onto the  $2\pi$  period by the identity

$$\frac{1}{2\pi i} P.V. \int_{-\infty}^{+\infty} \frac{\gamma(\alpha')}{z(\alpha) - z(\alpha')} d\alpha'$$

$$= \frac{1}{4\pi i} P.V. \int_{0}^{2\pi} \gamma(\alpha') \cot \frac{1}{2} (z(\alpha) - z(\alpha')) d\alpha', (84)$$

where  $z(\alpha) = x(\alpha, t) + iy(\alpha, t)$  (Carrier, Krook, and Pearson [14]).

It has been observed by Baker and Nachbin [7] and by Beale et al. [10, 12] that lower order spatial discretizations can lead to violently unstable schemes. This is not due to a

time-stepping instability. This instability is observed in time continuous and space discrete schemes. It is due to the fact that lower order schemes unphysically suppress the stabilizing effects of surface tension at the highest modes. Beale *et al.* [ 12] show how lower order accurate schemes can be modified to be stable and convergent. However, none of these works address the issue of the temporal stability constraints, which is a central focus of the work here.

We use spectrally accurate spatial discretizations. Any differentiation, partial integration, or Hilbert transform is found at the mesh points by using the discrete Fourier transform (DFT). To compute the complex Lagrangian velocity of the interface (84), we use the spectrally accurate alternate point discretization

$$u_j - iv_j = \frac{2h}{4\pi i} \sum_{j+k \text{ odd}} \gamma_k \cot\left(\frac{z_j - z_k}{2}\right), \tag{85}$$

where *zj-=-xj + iyj* denotes the approximation to the position of the interface at the grid point *jh* with h = *2zr/N,* and N is the number of grid points (see [ 46, 44 ]). Similar spectrally accurate quadratures employing prior removal of the singularity are given by Baker [4]. Other integrals over the period, such as that in Eq. (66), are evaluated to spectral accuracy using the trapezoidal rule.

Care must also be taken with spectrally accurate methods. Although a near equilibrium, *spatially discrete*  analysis indicates that they are stable [7, 10, 12], this analysis involves only constant coefficients of perturbed quantities. Beale *et al.* [ 12] performed also a spatially discrete linear analysis far from equilibrium and noted that the spatial variation of coefficients leads to aliasing errors. These errors can be destabilizing if left uncontrolled, and Beale *et al.* describe several types of Fourier filtering that guarantee stability and convergence. Such errors arise as a result of the imposed periodicity on the discrete solutions in both space and wavenumber, and the resultant instabilities have been well studied in the context of hyperbolic equations. See [21, 25, 32, 49], for example. Fourier filtering is often used to remove them.

Typically, if the time discrete method is not smoothing at the highest modes, then aliasing instabilities can occur over long times. The linear propagator method for Hele-Shaw flows is inherently smoothing at the highest modes, due to the exponential damping factors and does not suffer from aliasing instabilities. The other methods we have described--Crank-Nicholson for Hele-Shaw flows and both methods for inertial vortex sheets-~lo suffer from aliasing instabilities since they are not naturally damping at the highest modes. As is expected with an aliasing instability, its onset time increases as the spatial resolution is increased. Thus, in principle, the instability can be controlled by simply increasing the spatial resolution. This

is expensive. Instead, the instability is controlled by using Fourier filtering to damp the highest modes. In particular, the 25 th order Fourier filter

$$\hat{\Pi}[f](k) = e^{-10(|k|/N)^{25}}\hat{f}(k)$$
 (86)

is employed. The filtering determines the overall accuracy of the method, and so the formal accuracy is O(h25). Certainly an infinite-order filter could have been used, but we did not do so. In addition, as high derivatives are computed in the code, Krasny filtering [31 ] (setting to 0 all Fourier modes below a tolerance level e) is employed along with/7 to control amplification of noise through taking derivatives. It is applied at the same time as //with e= 10 -~3, near the round-off level. This combination of both is now referred to as filtering. Again, filtering is used only in long-time computations involving the nonsmoothing methods. The use of Krasny filtering, however, is strictly a precautionary measure to keep the spectrum "clean" and is not necessary for stability. This is demonstrated in Section 7. Moreover, Krasny filtering alone would not control the aliasing instability as the highest modes are above the tolerance level and, hence, are not removed when the instability occurs.

As a final note, we add that the role of filtering here is somewhat different from its use in zero surface tension calculations [31, 44]. There, Krasny filtering is used to check an anomolous growth of noise induced by the Kelvin-Helmholtz instability. Uncontrolled, this growth destroys the accuracy of computations in very short times, well before any singular behavior occurs, and increasing the spatial resolution only enhances the instability. Here, the mathematical problems are at least linearly well posed [ 10, 12] and so for stable schemes, it should not be crucial that the computations are free of spurious erorrs. This is borne out for our methods as simply increasing the spatial resolution delays the onset of instability. The purpose of the filtering here is to provide an efficient way to preserve the overall accuracy in time. Finally, the techniques of Beale *et al.* [ 12] can be used to show the convergence of our numerical methods.

# **6.4. Other Considerations**

It is useful to discuss the construction of the initial equal arclength parametrization, as well as the construction of the mapping from the *(x,y)* description of the interface to (L, 0),

# *Equal Arclength Initialization*

The procedure for obtaining the initial equal arclength parametrization is presented in Appendix B of [9]. The idea is just to solve the nonlinear equation for the equal arclength grid points using Newton's method and Fourier interpolation. The equation that must be solved is

$$\int_{0}^{\beta_{j}} s_{\alpha'} d\alpha' = \frac{jh}{2\pi} \int_{0}^{2\pi} s_{\alpha'} d\alpha' = jh \frac{L}{2\pi}, \tag{87}$$

for flj as j=0(1)N with *h=2n/N.* Here ~ is a given parametrization, not necessarily arclength, and flj gives the location of points in the ~ parametrization that are equally spaced in arclength. L is obtained by trapezoidal integration ofs~ over its period.

Moreover, in the case of inertial vortex sheets, the unnormalized vortex sheet strength in the arbitrary parametrization ~, must be rescaled appropriately for use in the equal arclength frame. This is because in the inertial vortex sheet case, the *unnormalized* vortex sheet strength appears in a frame-dependent way in the equations of motion, see (15) and (27). In particular, suppose that ~(~, 0) is given. Then, the initial data used in the equal arclength frame is *y(flj, 0). fl~(jh),* where fl~ is computed from the solution of Eq. (87) using the DFT. The *true* vortex sheet strength (i.e., the tangential jump in velocity: *7/s~),* on the other hand, is frame-independent. Of course, it is not necessary to rescale the unnormalized vortex sheet strength in the Hele-Shaw case as it is not an independent variable and does, in fact, appear in a frame-independent way.

*The Forward Mapping (x, y) ~ (L, O)* 

Recall that the tangent angle is given by *O= tan-~(y~/x~).* However, this is not a good formula to use numerically as it is tricky to ensure that the variation of *y~/x~* over the interface does not result in jumps in 0 due to branching in the inverse tangent. It is better to construct 0 from the curvature by integrating the formula

$$\theta_{\alpha} = s_{\alpha} \kappa$$
, where  $\kappa = (x_{\alpha} y_{\alpha \alpha} - y_{\alpha} x_{\alpha \alpha})/s_{\alpha}^{3}$ . (88)

The constant of integration may be chosen by using the inverse tangent formula at the initial point of integration.

*The Inverse Mapping* (L, 0) ~ (x, y)

The difficulties in recovering (x, y) from (L, 0) are purely implementational; (x, y) are obtained by integrating the formulae

$$x_{\alpha} = \frac{L}{2\pi}\cos(\theta), \qquad y_{\alpha} = \frac{L}{2\pi}\sin(\theta).$$
 (89)

For the flows that are periodic in x, the formulation requires that x = cc + p(0c, t) and y = q(~, t), where p, q are periodic in 0~. In particular, the coefficient of the linear term in must be *exactly* 1 in the x coordinate and 0 in the y coordinate. Unfortunately, integrating (89) using the DFT perturbs these coefficients slightly due to numerical error. Unchecked, this has a devastating effect on the code as the assumed periodicity of the solution is altered. The alternating point quadrature role, for example, loses spectral accuracy and the code becomes unstable. This difficulty is easily fixed by forcing the coefficients to be exactly 1 and 0, respectively, after the reconstruction process. For example, we reconstruct x by using the discretization of

$$x(\alpha, t) = x(0, t) + \alpha \left[ 1 - \frac{L}{2\pi} \int_0^{2\pi} \cos(\theta(\alpha')) d\alpha' \right]$$
  
+ 
$$\frac{L}{2\pi} \int_0^{\alpha} \cos(\theta(\alpha')) d\alpha'.$$
 (90)

Of course, in the absence of numerical error, the explicit coefficient of~ in (90) vanishes. We have considered other ways to enforce this condition, but we have found that just explicitly forcing these coefficients to be 1 and 0, respectively, performs the best numerically. We remark that Strain also noted this difficulty in [48], but he did not seem to employ a correction of it computationally.

#### 7. SOME NUMERICAL RESULTS

In this section, the results of numerical simulations are presented for several fluid interface problems. The first of these is the motion of Hele-Shaw interfaces, which evolve by a competition of surface tension and unstable density stratification. The second is the expansion of a gas bubble into a Hele-Shaw fluid. The third is the motion of inertial vortex sheets, which evolve by a competition of surface tension and the Kelvin-Helmholtz instability. And the fourth is the motion of an interface with surface tension in an unstably stratified Boussinesq fluid. All of these simulations use the appropriate small scale decomposition, together with the associated numerical methods discussed in the previous section.

The computations in the open geometry (i.e., all cases but the expanding bubble) assume one-periodic interfaces rather than 2n-periodic as was assumed in the previous sections. The two are equivalent by a rescaling of time, space, and the physical parameters.

#### **7.1. Numerical Results: Hele-Shaw**

# *7.1.1. Numerical Stiffness*

This section begins with a comparison of the stability constraints of three methods for Hele-Shaw flow--the second-order linear propagator, the Crank-Nicholson/ leapfrog, and the explicit second-order Adams-Bashforth method applied to small scale decomposition (62). To demonstrate the constraints on these methods (especially for the explicit scheme), it is sufficient to consider short times and the simple initial condition

$$x(\alpha, 0) = \alpha,$$
  $y(\alpha, 0) = -0.01 \sin 2\pi\alpha.$  (91)

Here, R = -1 and S = 0.01 so that the flow is unstably stratified although  $k = \pm 1$  are the only linearly growing modes.  $A_{ii} = 0$  is taken for simplicity.

For each method, Fig. 3 shows plots of the Fourier transform  $\log_{10} |\hat{y}(k)|$  versus k at t = 0.1 for the two resolutions N = 64 (top) and N = 128 (bottom). The results from the integrating factor and Crank-Nicholson methods use the timestep  $\Delta t = 0.01$  at both spatial resolutions. Instability in a time-integration method is usually manifested as rapid and unphysical growth in the amplitudes of the highwavenumber modes. As is clear from the spectrum, no time step reduction is necessary for stability of either method as the resolution is increased, at least at these resolutions. For larger values of N, i.e., N up to 2048, we do see the emergence of a first-order CFL constraint imposed by the transport term. Although this constraint is not seen in the near equilibrium linear analysis, as the transport term (see Eq. (53)) is neglected, it is not surprising that it is seen in the full computation for large N.

The results for the explicit scheme are shown in the last column. The solid curve corresponds to t = 0.10 with  $\Delta t = 2.0 \times 10^{-5}$  for N = 64, and  $\Delta t = 0.25 \times 10^{-5}$  for N = 128. This reduction in time step is exactly the factor of 8 that is

![](_page_14_Figure_7.jpeg)

**FIG. 3.** Hele-Shaw numerical stiffness: a comparison of  $\log_{10} | \hat{p}(k)|$  vs k at t=0.10 and R=-1, S=0.01: (a) linear propagator, N=64,  $\Delta t=0.01$ ; (b) Crank-Nicholson N=64,  $\Delta t=0.01$ ; (c) explicit second-order Adams-Bashforth, N=64,  $\Delta t=2.0\times10^{-5}$  and at  $t=2.0\times10^{-3}$  with  $\Delta t=4.0\times10^{-5}$ ; (d) lin. prop., N=128,  $\Delta t=0.01$ ; (e) C-N, N=128,  $\Delta t=0.01$ ; (f) explicit A-B, N=128,  $\Delta t=0.25\times10^{-5}$  and  $t=2.0\times10^{-4}$  with  $\Delta t=0.5\times10^{-5}$ 

stipulated by the near equilibrium stability constraint  $\Delta t \leq Ch^3$ . To demonstrate the proximity of the stability threshold, the results are given also for computations using the intermediate time steps  $\Delta t = 4.0 \times 10^{-5}$ , at t = 0.002 for N = 64, and  $\Delta t = 0.5 \times 10^{-5}$ , at t = 0.0002 for N = 128 (given by the dashed lines). That the stability criterion is violated is shown by the unphysical growth of the spectrum at high wavenumbers. The latter two computations cannot be continued much beyond these times as the numerical solution blows up.

At these early times, the flow has not yet developed spatial complexity. Therefore, there are no significant aliasing errors and hence no filtering is used in these calculations. Aliasing errors become especially important when the active portion of the spectrum approaches and exceeds the Nyquist frequency k = N/2. Finally, the explicit computation with N = 128 and  $\Delta t = 0.25 \times 10^{-5}$  takes approximately 175 min on an IRIS Indigo workstation while the linear propagator and the Crank-Nicholson computations each take less than 30 s (due to the fact that their time steps are  $\Delta t = 0.01$  each).

#### 7.1.2. Longer Time Computations

Consider now the evolution from the multimodal intial condition

$$x(\alpha, 0) = \alpha,$$
  $y(\alpha, 0) = 0.01 \cos 2\pi\alpha - 0.01 \sin 6\pi\alpha,$  (92)

with S = 0.1, R = -50, and  $A_{\mu} = 0$ . Now, the modes  $|k| \le 3$  are linearly unstable, and the competition between the sur-

![](_page_14_Figure_15.jpeg)

**FIG. 4.** Long-time evolution of a Hele-Shaw interface: S = 0.1, R = -50, N = 2048,  $\Delta t = 3.125 \times 10^{-5}$ : (a) t = 0; (b) t = 0.04; (c) t = 0.06; (d) t = 0.08; (e) t = 0.10; (f) close-up of topmost pinching region, t = 0.10.

face tension and the unstable stratification causes the interface to rapidly develop a ramified spatial structure.

A time sequence of inteface positions is shown in Fig. 4 using N=2048 and *At=* 3.125 × 10 -5. The second-order linear propagator method is used, and the time step is chosen small enough so as to effectively eliminate time-stepping errors from the computation. At early times, three rising and falling fingers of fluid form. As time progresses, the tips of these fingers thicken and begin to resemble bubbles. The necks of the fastest moving fingers begin to narrow and their sides approach tangentially. The other necks appear to follow suit. These necks become localized jets, fluxing fluid from the bulk into the bubbles. At later times, the sides of the necks seem to self-intersect or pinch. However, a close-up of the neck region (box (f)) of the topmost bubble reveals that the pinching has not yet taken place by t = 0.10 and that the neck still has a nonzero width. As the necks narrow, however, it becomes more and more difficult to maintain resolution. This is because the alternate point discretization of the Birkhoff-Rott integral requires a minimum width of six or seven grid lengths in the neck region for accuracy [ 8 ]. This effect is illustrated in Fig. 5, where the interface positions are compared at t = 0.10 with N= 1024 and N---2048. Although pinching has already taken place in the N = 1024 calculation, it is unphysical. The rrrinimum width of the neck as a function of time is shown in Fig. 6 for several spatial resolutions: N= 512, N= 1024 and N=2048 (again using the same time step Lit= 3.125 x 10-5). The width is computed by minimizing the distance function between the bounding curves, which are represented by Fourier polynomials. The width of the neck decreases rapidly at early times. By t = 0.065 with N= 512, the neck is but one grid length wide, and the calculation becomes inaccurate. The higher resolution calculations

![](_page_15_Figure_4.jpeg)

FIG. 5. Comparison of Hele-Shaw interfaces at t = 0.10 for different spatial resolutions: the left corresponds to N= 1024 and the right to N=2048; S=0.1, R= -50, *At=* 3.125 x l0 -5.

![](_page_15_Figure_6.jpeg)

FIG. 6. Minimum distance to pinching for N= 512, N= 1024, and N= 2048; S = 0.1, R = -50, *At* = 3.125 x 10 -5.

indicate that the narrowing slows shortly thereafter. However, by t = 0.08, the N = 1024 calculation has a neck width of only five grid lengths, and that calculation becomes inaccurate. But by using N = 2048, the width is seen to saturate after t= 0.08 and shows only a slight further decrease by t = 0.10. The neck region is 11 of its grid lengths wide. Presumably, the width of the neck region scales with the surface tension, although this has not been studied in detail.

This lack of self-intersection in the neck region is consistent with behavior found by Goldstein, Pesci, and Shelley [ 18 ] in asymptotic models of jets in Hele-Shaw flows. Their modelling suggests also that the minimum neck width decreases by a factor of two with a fourfold decrease in the surface tension. It is only in the limit of zero surface tension that their model equation predicts the breaking of the neck. They do consider other cases, however, where the surface tension does not prevent the pinching of material interfaces.

Figure 7 shows the evolution of the curvature. The top left plot shows the inverse of the maximum absolute curvature. Vanishing in this plot would correspond to a divergence of the curvature. At early times, there is a rapid increase in the curvature (a decrease in the plot). It peaks around t= 0.015 and then begins to decrease. This lasts until t -- 0.05. The curvature then refocuses and the process repeats itself several times. By the end of the computation, the curvature has nearly reached again its peak at t = 0.015. The other plots in Fig. 7 show x as a function of ~ at several times; these graphs indicate that in fact, the curvature saturates at one part of the interface and refocuses in another, leading to a very complicated overall structure. The boundaries of the narrow neck regions are indicated by a pairs of closely spaced peaks of like signed curvature. The phenomenon of saturation and refocussing will be seen again in the context of inertial vortex sheets.

![](_page_16_Figure_2.jpeg)

FIG. 7. Time evolution of the curvature; S = 0.1, R = -50, N = 2048,  $\Delta t = 3.125 \times 10^{-5}$ : (a) plot of inverse maximum of curvature (absolute value); (b) curvature at t = 0.02; (c) t = 0.04; (d) t = 0.06; (e) t = 0.08; (f) t = 0.10.

Error Analysis. In Fig. 8, spatial convergence is demonstrated by comparing computations using N=256, 512, and 1024 with those from N=2048. The time step is  $\Delta t = 3.125 \times 10^{-5}$  for all resolutions. The error is measured as  $e_N(t) = \max_j |x_j(t; N) - x_j(t; 2048)|$ , where N is the number of points in the lower resolution calculations. The error is plotted on a negative logarithm (base 10) vertical scale. The error is consistently around  $10^{-10}$ , for each of the lower resolutions, until the interfaces nearly pinch. Then, rapid losses of accuracy are seen from about t=0.03 for N=256,

![](_page_16_Figure_5.jpeg)

**FIG. 8.** Error in x-coordinate  $(-\log_{10}(\text{error}))$ ; S = 0.1, R = -50,  $\Delta t = 3.125 \times 10^{-5}$ , exact solution approximated by N = 2048.

t=0.05 for N=512, and t=0.07 for N=1024. It is clear that more resolution will be required for further computation of this flow. Further, as the quadrature we use is the chief culprit in loss of accuracy, it would be useful to consider other types of quadrature (i.e., product integration methods) that do not lose accuracy so catastrophically through the close approach of interfaces. The second-order temporal convergence can be shown similarly, but it is not presented here.

# 7.1.3. The Expanding Bubble

The calculation of a gas bubble expanding into a Hele-Shaw fluid, shown in Fig. 1, is now briefly discussed. The dynamics of expanding bubbles in the radial geometry have attracted a great deal of attention due to the formation of striking patterns observed in experiments (see the many references and contributions in [47], for example). In this flow, an expanding, unstable interface is produced by placing a mass source at the center of the bubble. Linearization about an expanding circular bubble, with radius R(t) and pumping rate dA/dt, gives the instantaneous growth rate [16]

$$\sigma_k(t) = \frac{1}{R(t)^2} \left( (k-1) \frac{dA/dt}{2\pi} - \frac{S}{R(t)} (k-1) k(k+1) \right). \tag{93}$$

The pumping term replaces the gravitational term in the previous example as the source of instability. For a constant pumping rate (here  $dA/dt = 2\pi$ ) we obtain a Mullins-Sekerka type instability, which shows the competition between the destabilization effect due to pumping and the stabilizing effect due to surface tension.

Unlike the previous calculation, there is now a viscosity contrast  $(A_{\mu} = 1, \mu = 0)$  inside the bubble). Consequently, an integral equation analogous to Eq. (20) must be solved for the vortex sheet strength  $\gamma$  (see Dai and Shelley [16]). Here, the integral equation is solved in its dipole form, for the dipole strength  $\nu$ , which is related to  $\gamma$  by  $\gamma = \nu_{\alpha}$  (see Greenbaum, Greengard, and McFadden [22]). The integral equation is solved iteratively using the GMRES method [42]. Birkhoff-Rott type integrals over a closed interface (although with smooth kernels) must be evaluated at each step. The fast multipole method [23] is used to evaluate them. Thus, at each iteration, the operation count is O(N) as opposed to  $O(N^2)$  for direct summation. The convergence tolerance for the GMRES iteration is set to  $10^{-12}$ . The rate of convergence is improved considerably by a simple diagonal preconditioning, as used in [22], and by supplying a good first guess through an extrapolation of solutions at previous time steps. Once the solution to the integral equation is obtained, the Dirichlet-Neumann map is used to determine the normal velocity of the interface.

This results again in a Birkhoff–Rott type integral (now with a singular kernel) that must be evaluated and alternate point quadrature using the fast multipole methods is employed to this end. See [16, 22] for details. Time integration is accomplished using the second-order linear propagator method on the small scale decomposition; i.e., the method is given by Eq. (69) where the term  $\hat{N}$  is modified to account for a pumping term (see [16]). The method is spectrally accurate in space.

The initial condition is given by

$$(x_0(\alpha), y_0(\alpha)) = r(\alpha)(\cos \alpha, \sin \alpha)$$
with  $r(\alpha) = 1 + 0.1 \sin 2\alpha + 0.1 \cos 3\alpha$  (94)

and is shown as the innermost curve of Fig. 1; it imposes no particular symmetry on the ensuing motion. The value of the surface tension is S = 0.001. At t = 45, the time step is  $\Delta t = 0.0005$  and N = 8192.

Figure 1 shows the expansion of this bubble from t = 0 up to 45, at unit intervals of time. This simulation displays much of the behavior that has stimulated interest in pattern formation in Hele-Shaw flows. An early times, three main "fjords" form in the interface. These fjords separate three expanding fronts. The number of fjords arises from the k=3component in the initial data. The expanding fronts rapidly develop oscillations, particularly along their outer edges near the fjords, which themselves form "fingers" and "petals." The petals expand outwards and eventually tipsplit into two petals. Although this tip splitting temporarily restabilizes them, the process repeats itself. One petal in the second quadrant has already tip-split four times and is approaching a fifth tip-splitting. There is also abundant evidence of competition between these various structures. Of the approximately 25 protuberances that develop at early times (say between t = 5 and 8), only about 15 of them are still actively growing outwards as t = 45. The remainder have either stopped growing outwards, or have receded and been absorbed back towards the main bulk of the bubble.

Although further details of these calculations will appear elsewhere, we present one interesting diagnostic. Figure 9 shows the bubble area A(t) versus G(t), the "radius of gyration," on a log-log scale (upper graph). G(t) is defined as the maximum distance of a point on the interface from the injection point. It is computed numerically by maximizing the Fourier interpolant of the distance function from the origin (the injection point) to the interface. The radius of gyration has been used as a measurement of complexity, as the slope of log G versus log A, shown in the middle and lower graphs, gives roughly a dimension d, where d is the dimension of the bubble (i.e.,  $A \sim G^d$ ). For example, the slope is two for a circular bubble. This slope is, of course, not smooth, as the point of maximum radius jumps between dif-

![](_page_17_Figure_8.jpeg)

**FIG. 9.** (a) The bubble area A(t) vs the radius of gyration G(t) on a log-log scale. (b) The points are the slope (dimension) d measured from (a) as a function of time. The dashed lines are at d = 1.66 and 1.71 (DLA estimates).

ferent sites during the evolution. The jumps themselves are associated typically with tip-splitting events, as the splitting allows a newly formed finger to move outwards more quickly. The dashed lines have the values 1.71 and 1.66 (see [53, 26], respectively), which are estimates for the fractal dimension of a branched object grown via diffusion limited aggregation (DLA), a prototypic model for the growth of branched structures [53]. There is a short period (15 < t < 20) of good agreement with these values, but the behavior of the slope is mostly characterized by large deviations from these values.

On the computational side, it is the solution of the integral equation that consumes most of the effort. The number of iterations to convergence is initially only 4 or 5. It soon rises to 25, and then increases very slowly thereafter. By the end of the calculation the number of iterations to convergence was only 31. We find also that the number of iterations does not depend strongly upon N, once  $\Delta t$  is fixed, so long as the interface is well resolved. And so, the operation count is O(N) at each time step.

This calculation agrees very well with lower resolution calculations, which necessarily ran to lesser times. Here, each doubling of the number of points leads to a rough doubling in the amount of time that the interface is resolved. This is unlike the unstably stratified case where the self-approach of interfaces must be resolved. In this flow, there are no apparent near singular events (such as the self-approach) and the interface expands smoothly outwards. The computation ran to t = 6.0 with N = 1024, to t = 10.0 with N = 2048, and to t = 25.0 with N = 4096. The codes were stopped because the high modes of the spatial Fourier

spectrum had risen to  $10^{-8}$  (from  $10^{-16}$ ). The N = 8192 computation was stopped at t = 45, even though its high modes had risen to only  $10^{-11}$ . We note that the computed area of the bubble at t = 45 still agrees to six digits with its exact value.

The calculation to t = 25.0 took about 9 days on an IBM R6000 workstation. Had there been no accompaying integral equation to solve, it would have taken but a few hours. The best approach to reducing this time appears to be finding better preconditioners for the iteration. Previous calculations of similar flows have been performed [15, 16]. The time step here is  $10^3$  times larger than that used by Dai and Shelley [16] in computations of a similar flow using an explicit method with a lesser number of points, and the interface here has developed far more structure. Further, no symmetries have been imposed. Again, further details will appear elsewhere.

# 7.2. Numerical Results: Inertial Vortex Sheets

In these last two subsections, we examine the long-time evolution of inertial vortex sheets with surface tension, both in a homogeneous fluid and in a fluid with slight density stratification. Leaving aside issues such as dimensionality and viscous effects, the first case is not a completely artificial situation. Two immiscible fluids can be density matched and still produce a surface tension. Further, in the absence of surface tension, the singularities of a vortex sheet embedded within a homogeneous fluid give the basic form of the singularities observed on an interface evolving by the Rayleigh-Taylor instability [5]. Our results in the last subsection suggest that this still holds true with the addition of surface tension.

Computationally, such problems have also been considered by Pullin [38], by Rangel and Sirignano [39], by Baker and Nachbin [7], and by Beale et al. [10, 12]. Pullin used a method based on cubic splines and observed a persistent numerical instability that was only slightly ameliorated by additional smoothing of the interface position. His calculations are restricted to short times. Rangel et al. used a similar method, combined with a remeshing, using linear interpolation of the interface positions and sheet strength, at every time step. This is strongly smoothing. Indeed, they calculate the smooth roll-up of the sheet, even without surface tension, for which it is known that a singularity interrupts the motion well before roll-up occurs [33, 31, 44]. Baker and Nachbin and Beale et al. investigate the stability of spatial discretizations. In these works, the issue of stiffness is not addressed, and the calculations are again restricted to short times.

#### 7.2.1. Numerical Stiffness

In this section, the stability constraints are compared for the second-order linear propagator, Crank-Nicholson/ leapfrog, and explicit second-order Adams-Bashforth methods for small scale decomposition of the  $\theta-L$  formulation of inertial vortex sheets, Eqs. (55) and (56). For the explicit scheme, the Adams-Bashforth discretization is used in all three equations. The initial condition is

$$x(\alpha, 0) = \alpha + 0.01 \sin 2\pi\alpha,$$
  $y(\alpha, 0) = -0.01 \sin 2\pi\alpha,$  (95)  
 $y(\alpha, 0) = 1.0.$ 

This initial data was used by Krasny [31] in the absence of surface tension. In that case, a curvature singularity forms at  $t \approx 0.375$ . The calculations here have S = 0.005, which gives 16 linearly growing modes in the period.

Figure 10 shows plots of  $\log_{10} |\hat{y}(k)|$  for the three methods with N = 64 and N = 256 at t = 0.12. This is a factor of 4 increase in N, and so the near equilibrium constraint  $\Delta t < Ch^{3/2}$  requires a factor of 8 decrease in time step. The results from the Crank-Nicholson/leapfrog scheme are given in the first column. The time step  $\Delta t = 0.01$  is used for both resolutions and this scheme is clearly stable. As there is little spatial complexity (i.e., no large aliasing errors), filtering has not been used. The results from the explicit Adams-Bashforth scheme are given in the middle column. The +-curves correspond to  $\Delta t = 3.1 \times 10^{-4}$  for N = 64 and  $\Delta t = 3.9 \times 10^{-5}$  for N = 256. This is again the factor of 8 as predicted by the stability constraint. The solid lines show that the time step constraint is violated with  $\Delta t = 1.2 \times 10^{-3}$ with N = 64 and  $\Delta t = 7.8 \times 10^{-5}$  with N = 256. In the third column of the figure the results are from the integrating

![](_page_18_Figure_13.jpeg)

**FIG. 10.** Inertial vortex sheet numerical stiffness: a comparison of  $\log_{10} |\hat{y}(k)|$  vs k with S = 0.005 at t = 0.12: (a) Crank–Nicholson, N = 64,  $\Delta t = 0.01$ ; (b) explicit second-order Adams–Bashforth, N = 64,  $\Delta t = 1.2 \times 10^{-3}$ ,  $3.1 \times 10^{-4}$ ; (c) linear propagator, N = 64,  $\Delta t = 6.3 \times 10^{-4}$ ,  $1.6 \times 10^{-4}$ ; (d) C-N, N = 256,  $\Delta t = 0.01$ ; (e) explicit A-B, N = 256,  $\Delta t = 7.8 \times 10^{-5}$ ,  $3.9 \times 10^{-5}$ ; (f) lin. prop., N = 256,  $\Delta t$ ,  $\Delta t = 9.8 \times 10^{-6}$ .

factor method. The stability region of this scheme does not differ significantly from that of the explicit scheme. This is somewhat surprising but confirmed by near equilibrium analysis of the second-order linear propagator scheme. Other time discretizations, such as fourth-order Runge–Kutta, for the linear propagator method are currently being studied.

By virtue of its stability, the Crank-Nicholson method is about 250 times faster than both the explicit and linear propagator methods with N=256. Calculations with up to 8192 points will be presented for the Crank-Nicholson method. Following this scaling, the explicit Adams-Bashforth and the linear propagator would require a time step  $4 \times 10^5$  times smaller.

# 7.2.2. Long-Time Computation

The long-time evolution of the initial data (95) with S = 0.005 is now studied, using the Crank-Nicholson scheme, together with filtering. The effect of the filtering is discussed in detail below.

In Fig. 11, a time sequence of interface positions is given, starting from the initial condition. The calculation uses N=1024 and  $\Delta t=1.25\times 10^{-4}$ . At early times,  $0\leqslant t<0.40$ , the interface steepens and behaves similarly to the zero surface tension case. It passes smoothly through the S=0 Kelvin-Helmholtz singularity time ( $t\approx 0.375$ ). At t=0.45, the interface becomes vertical at the center. It subsequently rolls over and produces two fingers ( $t\approx 0.50$ ). These grow in length in the sheet-wise direction (box (b)). The tips of the fingers broaden and roll with the sheet. This is clearly seen

(a) (b) 0.2 0.2 -0.2-0.2 0.4 0.6 0.4 0.6 0.8 (c) (d) 0.2 0.2 -0.2 -0.20.2 0.4 0.6 0.8 0.2 T=0.80 T=1.20 (f) (e) 0.1 0.2 0.05 -0.2 0.45 0.5 0.55

**FIG. 11.** Inertial vortex sheet; sequence of interface positions: S = 0.005, N = 1024,  $\Delta t = 1.25 \times 10^{-4}$ : (a) t = 0; (b) t = 0.60; (c) t = 0.80; (d) t = 1.20; (e) t = 1.40; (f) close-up of top pinching region, t = 1.40.

at t = 0.80 and there is evidence of capillary waves, seen as wiggles along the sheet. By t = 1.20, the sheet produces another turn and the fingers have become broader and larger. Additional capillary waves also have been produced and they traverse the interface outwards from the center region. This is a dispersive effect of the surface tension that is seen more clearly in plots of the curvature and vortex sheet strength. Note that the part of the interface (on the inner turn) closest to the fingers has become quite flat and bends very slightly towards the fingers. At later times, this part bends even more towards the fingers, the tips of the fingers narrow and both pieces of the interface approach each other. At t = 1.40, the interface appears to self-intersect. but a close-up of the region at this time indicates that there is still a finite distance between the upper finger and the inner roll. The same is true for the lower finger by symmetry, although that symmetry is not imposed in the simulation. At this time, the gap is but five grid lengths wide, and the calculation is stopped here. The length of the interface has more than doubled (a factor of 2.6).

This type of self-approach is quite different from that seen in the Hele-Shaw flow. Here, each part of the interface appears to form a finite angle during the approach, whereas for Hele-Shaw, the approach is tangential. The mechanism driving the interface to self-approach is not yet well understood and is under active study. Rather than ultimately preventing the pinching, as is apparently the case in the Hele-Shaw jet flow, surface tension appears to push the flow further towards it by producing a jet through the narrow gaps between the fingers and the inner turn of the spiral. Fluid streams into each of the fingers and the

![](_page_19_Figure_11.jpeg)

FIG. 12. Inertial vortex sheet: sequence of  $\gamma$  vs.  $\alpha$ ; S = 0.005, N = 1024,  $\Delta t = 1.25 \times 10^{-4}$ : (a) t = 0; (b) t = 0.60; (c) t = 0.80; (d) t = 1.20; (e) t = 1.40; (f) strength on opposite pieces of the upper pinching region, t = 1.40.

two pieces of the interface are drawn togetherl This jet is recognized in that the approaching parts of the interface come with oppositely signed vortex sheet strengths, and their signs are such that fluid flows into the fingers. For this initial data (single-signed sheet strength), such a sign change in the vortex sheet strength can *only* occur in the presence of surface tension.

Figure 12 shows the unnormalized vortex sheet strength, ~, versus 0~. Recall that y, initially, is not identically equal to 1 as it has been rescaled appropriately for the 0- L frame. In this frame, the unnormalized vortex sheet strength differs from the true vortex sheet strength (i.e., the tangential jump 0 in velocity) by only the time-dependent scale factor *L/2zc.* At early times, two positive peaks form in the vortex sheet 20o strength (see box (b)). These are the remnants of the S = 0, Kelvin-Helmholtz instability, which concentrates vorticity 0 into the center. In the S = 0 case, there is only one peak [31] but the addition of a small surface tension splits it in -20% two. There are small waves that form at the outer edges of these peaks and are presumably dispersive waves produced by the surface tension saturation of the Kelvin-Helmholtz instability. At t = 0.80 (box (e)), the peaks have saturated and more waves have been produced. These disperse outward along the interface. The strength ? has also formed downward peaks at the edge of the wave packet. The saturation and dispersion continues through t--1.20 (box (f)). However, when the interface begins to self-approach, the vortex sheet strength refocusses, forming the jet. By the final time t = 1.40 (box (e)), two pairs of positive and negative peaks of vortex sheet strength have formed in each pinching region. These peaks have been isolated for the top pinching *region* in box (f). The top of the pinching region (inner turn of the spiral) comes with a negative signed vortex sheet strength and the bottom comes with a positive sign. This implies that fluid is streaming through the gap towards the center and into the downward pointing finger. <sup>i</sup>

Saturation and refocussing is also observed in the curvature. Its evolution is plotted in Fig. 13. The first graph shows the inverse maximum of the curvature (in absolute value) as a function of time. There is an initial region of rapid growth in the curvature (decrease in the plot) due to the S = 0 Kelvin-Helmholtz instability. Recall that for the 1c Kelvin-Helmholtz singularity, the curvature diverges. Here, <sup>8</sup>the curvature saturates and eventually refocusses. By the final time t = 1.40, the maximum of the curvature nearly ~ reaches that attained during the initial period of growth. 4 The refocussing, however, occurs at different places along the interface as seen in the other plots of t¢ versus ~. Disper- 2 sive waves are also generated and move outwards along the interface. At t = 1.40, the pinching points are indicated by pairs of like-signed peaks in the curvature.

Evidence is now presented to show that the pinching takes place in a finite time. Maintaining resolution is critical and so the neck widths obtained from different spatial and

![](_page_20_Figure_6.jpeg)

FIG. 13. Inertial vortex sheet: sequence ofx vs. a; S = 0.005, N= 1024, A t = 1.25 x 10 - 4: (a) plot of inverse maximum curvature (absolute value ): (b) plot of curvature, t=0.40; (c) t=0.60; (d) t=0.80; (e) t= 1.20; (f) t= 1.40.

temporal resolutions are compared. This is shown in the top graph of Fig. 14, which shows minimum width in the top pinching region, graphed as a function of time starting at t = 1.40. As in the Hele-Shaw case, the minimum width is computed by minimizing the distance function between each piece of the interface and using the Fourier interpolant

![](_page_20_Figure_9.jpeg)

FIG. 14. Pinching in, and accuracy in the energy of, the inertial vortex sheet: (a) minimum width of the top pinching region: S= 0.005; N= 1024 with At = 2.5 x I0-4; N = 2048 with At = 1.25 × I0-4; N= 4096 with At = 6.25 x 10-s; N=8192 with At=3.125 x 10 -5. (b) Number of accurate digits in the energy: S=0.005; N=512, N= 1024, N=2048 with At= 1.25 × 10-4, and N= 1024 with At = 3.125 × 10 -5 (1024ext).

of the curve. The spatial resolutions shown are N= 1024 with *At=2.5xlO-4,* N=2048 with *At=1.25xlO-4,*  N=4096 with At=6.25 x 10 -5 , and N=8192 with *At=*  3.125 x 10-5. The computations with N= 2048 and above are computed by restarting Fourier interpolants of lower resolutions. In particular, the N= 2048 computation is restarted from the N= 1024 computation at t = 1.25. The N=4096 and N= 8192 computations are restarted from N = 2048 at t = 1.40. These are times at which the active spatial spectrum of the lower resolution calculations begin to approach the Nyquist frequency. Additional details of these calculations will appear in a separate study [ 28 ].

In Fig. 14a, it is seen that the time of pinching is a *decreasing* function of resolution and strongly suggests that pinching occurs at *a finite* time. Moreover, the width seems to vanish with an infinite slope, implying that the pinching rate intensifies as the width narrows. Again, further details will appear in [ 28 ].

This apparent singularity is of a completely different type than that of the S = 0 Kelvin-Helmholtz singularity. Here, the singularity is a *topological singularity* and may signal an imminent change in the topology of the flow. The curvature, vortex sheet strength, and fluid velocity all apparently diverge at the pinching time [28]. In the S = 0 case, it is the velocity gradient (strain rate) and the curvature that diverge, but not 7- More fundamentally, with S = 0 the singularity occurs through a rapid *compression* of vorticity along the sheet at a single isolated point [33, 31, 9, 44]. Here, the divergence occurs through a rapid *production* of vorticity that is associated with the pinching. In a separate study, we will show evidence this collapse is a *local*  phenomenon in the flow and satisfies a scaling behavior [28]. We have also derived localized equations and they are currently under investigation.

*Error Analysis and the Role of Filtering.* We now turn to an analysis of the errors in our scheme, first by considering the energy E(t), which is a conserved quantity *not* conserved by the discrete methods. The energy E is the sum of the perturbation kinetic and the interfacial energies, given by

$$E(t) = E_s(t) + E_k(t),$$
 (96)

where

$$E_s(t) = S(L-1) \tag{97}$$

is the interfacial energy

$$E_k(t) = \frac{1}{2} \int_0^1 \psi(\alpha', t) \, \gamma(\alpha', t) \, d\alpha' \tag{98}$$

is the perturbation kinetic energy and ~k is the stream function,

$$\psi(\alpha, t) = -\frac{1}{2\pi} \operatorname{Re} \left\{ \int_0^1 \gamma(\alpha', t) \times \log[\sin \pi(z(\alpha, t) - z(\alpha', t))] d\alpha' \right\}.$$
 (99)

The formula for ff can be rewritten, by explicitly subtracting off the logarithmic singularity and integrating by parts, to yield an expression that can be computed with spectral accuracy numerically. See Pullin [38] and Baker and Nachbin [ 7 ] for details.

The lower graph of Fig. 14 shows -lOgl0 [(E(t)- *E(O) )/E(O* ) I for several spatial resolutions. This is essentially number of accurate digits in the energy. The time step is *At=* 1.25 x 10 -4 for all the resolutions except the one marked 1024ext. This uses *At=* 3.125 x 10 -5 and uses as initial data the other N= 1024 computation at t = 0.40. Prior to the time t = 0.40, there is essentially no difference between the different resolutions and the errors are dominated by the time stepping. Over nine digits of accuracy are obtained. Around t = 0.42, there is a sudden overall decrease in accuracy. This is an effect from the S = 0 Kelvin-Helmholtz singularity. This decrease is primarily due to time stepping since the N= 512, 1024, and 2048 curves all lie on top of one another immediately afterwards. This is reinforced by the 1024ext curve which has a four times smaller time step and lies well above the others. From t = 0.43 until nearly the end of the computation, the energy changes only slowly, and the N = 1024 and 2048 computations are slightly more accurate than the N= 512. Around t = 1.40, when the pinching begins to take place, there is another sudden loss of accuracy and now N = 2048 is more accurate than N= 1024 as spatial resolution becomes very important.

In view of these results, our code would certainly benefit from adaptive time stepping. A small time step is really only needed near the Kelvin-Helmholtz singularity time and near the time of pinching. Larger time steps could likely be used safely for the remainder of the computation. Finally, we remark that the energy of the N= 8192 computation used to compute the pinching distance still has over six digits of accuracy at the pinching time [ 28 ].

Since the energy is an integral quantity, using it to measure error is smoother than using a pointwise error. As in the Hele-Shaw case, we also consider the pointwise error in the x-component of the interface position. In Fig. 15, -lOgl0(e~t)) is plotted (see the Hele-Shaw results for a definition of *eN),* with the N = 2048 calculation again used as an approximation of the exact solution. Several resolutions are graphed and all use the time step *At* = 1.25 x 10-4. This graph is qualitatively similar to that of the energy and demonstrates the spatial convergence of our scheme. The temporal convergence can be similarly shown, but is not presented.

![](_page_22_Figure_2.jpeg)

FIG. 15. Error in x-coordinate; S = 0.005,  $\Delta t = 1.25 \times 10^{-4}$ , exact solution approximated by N = 2048.

The role of Fourier filtering ( $\Pi$  in Eq. (86)) is now discussed. As the higher Fourier modes rise above the round-off level (due to nonlinear interaction), an aliasing instability appears. This instability can be controlled by either increasing the resolution or by using some kind of filtering. Both have been tried, and we conclude that it is more practical to use a high order Fourier filtering that smooths the highest modes. By this, it is possible to achieve the same level of accuracy, at late times, using many fewer points than would be required without it. This is seen most directly by comparing their energies.

Figure 16 compares the energies of calculations both with and without filtering on the time interval 0.4 to 0.6. Recall

Number of Accurate Digits in Energy, (a) 10 -- unfiltered - filtered 1024 digits 256 1024 256 0.5 T 0.42 0.44 0.46 0.48 0.52 0.54 0.56 0.58 (b) 10 -- unfiltered - filtered digit 1024 0.54 0.56 0.58 0.46 0.48 0.52

FIG. 16. Accuracy in energy: filtered vs unfiltered, S = 0.005,  $\Delta t = 1.25 \times 10^{-4}$ : (a) filtered vs unfiltered, N = 256, 512, 1024; (b) filtered (N = 512) vs unfiltered (N = 1024).

that the filtering combines the Fourier and Krasny filters. The effect of Krasny filtering is discussed below. This is a very good test, as the spectrum is broadly populated due to the effect of the S=0 singularity. The time step is  $\Delta t=1.25\times10^{-4}$  for all the calculations. The filtered calculations show a generally slower loss of accuracy and are more accurate than their unfiltered counterparts by t=0.46. In fact, at t=0.46, the N=256 filtered calculation is more accurate than the unfiltered N=1024 computation! The unfiltered computations both break down before t=0.6.

The aliasing instability can be observed directly in spectral plots of the numerical solution. In Figs. 17a, b are shown the y-spectra of the filtered and unfiltered computations, respectively. In Fig. 17b, the aliasing instability is clearly seen through the artificial rise in the high wavenumber spectrum at t = 0.46. The unfiltered calculation cannot be continued long after this time, as this rise causes the code to blow up. The filtered computation, on the other hand, does not exhibit such a rise. Moreover, it is really only the last few modes that are damped by the filtering (modes 450-512). Since Krasny filtering is also employed in the filtering method, the modes at the roundoff level  $10^{-16}$  in the unsmoothed calculation are set to zero in the smoothed one. They are seen at the  $10^{-19}$  level in the plot (this kept the logarithm function in the graphics package from diverging). Moreover, it is clear from the behavior of the spectrum of the unfiltered computation that roundoff errors grow rather slowly and, therefore, the main effect of Krasny filtering is to keep the spectrum clean and is not necessary for stability.

The spectrum also indicates a very interesting behavior. At the early times  $0 \le t \le 0.46$ , energy is rapidly moved to the high wavenumbers due to the near Kelvin-Helmholtz

![](_page_22_Figure_11.jpeg)

FIG. 17. Log plot of power spectra ( $\log |\hat{y}(k)|$ ) at different times, S = 0.005,  $\Delta t = 1.25 \times 10^{-4}$ , N = 1024: (a) filtered Crank-Nicholson, short time; (b) unfiltered C-N, short time; (c) filtered C-N, long time.

singularity, and at t--0.46 all the modes lie above the round-off. Then, as seen in Fig. 17c, energy begins to move *from* high wavenumbes *back* to low wavenumbers. For example, the highest nonzero mode at t--0.60 is about k = 450 and by time t = 1.20, it moves to about k = 360. This behavior reflects the saturation observed in 7 and x. Between t = 1.20 and t = 1.40, the energy resumes its generation at high wavenumbers (refocussing) and by t = 1.40, all modes again lie above the round-off.

# **7.3. Boussinesq Interfaces**

In this section, a preliminary long time computation of an interface in an unstably stratified Boussinesq flow is presented. In Boussinesq flow, the fluids are only weakly stratified across the interface and the only contribution to vorticity production is through the buoyancy term. We remark that Boussinesq interface flows in the absence of surface tension develop finite time singularities of a form well described by those for inertial vortex sheets without surface tension [ 37, 5 ]. The 7 evolution equation is

$$\gamma_{t} - \partial_{\alpha}((T - \mathbf{W} \cdot \mathbf{s}) \gamma/s_{\alpha}) = S\kappa_{\alpha} - 2Ry_{\alpha}.$$
 (100)

The term Q in the small scale decomposition (56) is replaced *b'y Q-2Rye.* The Crank-Nicholson scheme is used with filtering for the same initial data in x and y as in the inertial vortex sheet calculation. Initially, 7 = 0. Further, R = -- 5 so that the flow is unstably stratfied, and there are 19 linearly unstable modes.

Figure 18 shows the time evolution of two periods of the

![](_page_23_Figure_8.jpeg)

FIG. 18. Evolution ofa Boussinesq interface; S = 0.005, R = - 5, *At =*  3.125x 10 -5 , N= 1024: (a) t=0; (b) t=0.60; (c) t=0.70; (d) t=0.80; (e) t = 0.89; (f) close-up of a left-most spiral, t = 0.89.

interface. This computation uses N=1024 and *At=*  3.125× 10 5. The classical Rayleigh-Taylor structure is seen as two spirals form on either side of the fluid plumes. The spirals are smaller than those for the inertial vortex sheet, but an examination of their inner structure shows them to be very similar. In particular, note the inward bulge in the second turn of the interface (t = 0.89, close-up). It seems very plausible that there will again be finite time pinching. One consequence of these smaller spirals is that this flow is more difficult to resolve than the previous case of inertial vortex sheets. More highly resolved computations will be presented in a separate study [28].

An intriguing question is whether such "bubble" formation, as is apparently predicted by these calculations, is observable in an experimental setting. Of course viscosity (and dimensionality) are crucial effects as the singularity is approached. But in his experimental study of the development of instability in sharply stratified shear flow between two immiscible fluids, Thorpe [ 50 ] remarks that the interface between the two fluids "became very irregular, sometimes being broken and drops of one fluid being produced in the other,...".

# 8. CONCLUSIONS

In this paper, we present new numerical methods for computing the motion of a fluid interface with surface tension in a two-dimensional, irrotational, and incompressible fluid. These methods have no high order stability constraint, are effectively explicit, and have high spatial accuracy. Our methods are applied to computing the motion, in 2D, of interfaces in Hele-Shaw flows (viscously dominated) and to the motion of free surfaces in inviscid, inertially dominated flows governed by the Euler equations.

In the former case, we compute the long-time development of an expanding gas bubble and a complicated "mixing zone" by the interpenetration of a heavy fluid with a lighter one. We show the robustness and accuracy of the method, even in the presence of ramified spatial structure. In the latter case, we compute the long-time evolution of a vortex sheet: The simulations suggest that in the process of forming a spiral, the turns of the spiral collide with one another, creating trapped bubbles of fluid. The results also indicate that this behavior is strongly tied to the presence of the surface tension, which allows the creation of local circulation along the sheet. To our knowledge, such a singularity has not been previously observed in such a flow in 2D.

These methods are finding application in problems beyond those discussed in this paper. To study the "quasistatic" limit of dendritic crystal growth, Almgren, Dai, and Hakim [ 1 ] have recently applied our methods to computing the expansion of a Hele-Shaw bubble with anisotropic surface tension. By being able to compute for long-times with good resolution and moderate time steps, they have discovered new scaling behaviors in the expansion and propagation of the large scale fingers. In collaboration with A. Greenbaum and D. Meiron, we have impleted the second-order linear propagator method, together with fast summation methods, to compute the many inclusion Ostwald ripening problem. Preliminary results indicate that the linear propagator method is substantially faster than an earlier implementation that used a standard ODE solver for stiff systems.

# APPENDIX 1: SMALL SCALE DECOMPOSITION OF INTEGRAL EQUATION

In this appendix, it shown that at small scales, the integral equations for Hele-Shaw interfaces and inertial vortex sheets yield explicit relations for  $\gamma$  and  $\gamma_t$ , respectively. Both integral equations can be written as

$$\xi(\alpha, t) + K[\xi](\alpha, t) = f(\alpha, t), \tag{101}$$

where  $\xi$  is the function to be determined (i.e.,  $\gamma$  or  $\gamma_t$ ) and f contains all the terms not involving  $\xi$ . K is the integral operator and is given by

$$K[\xi](\alpha, t) = -2A \int_{-\infty}^{+\infty} \xi(\alpha', t)$$

$$\times \operatorname{Re} \left\{ \frac{1}{2\pi i} \cdot \frac{z_{\alpha}(\alpha, t)}{z(\alpha, t) - z(\alpha', t)} \right\} d\alpha', \quad (102)$$

where  $A = A_{\mu}$  (Hele-Shaw) or  $A_{\rho}$  (inertial sheets) and  $|A| \le 1$  in either case. The integral equation (101) is a Fredholm integral equation of the second kind and it is well known that it is invertible and has a bounded inverse on an open and periodic geometry if z is smooth in  $\alpha$  (see [6]).

Moreover, if the components of the complex interface position z satisfy the assumptions of Theorem 1 (Section 4), then it is easy to see that the integral kernel

Re 
$$\left\{ \frac{1}{2\pi i} \cdot \frac{z_{\alpha}(\alpha)}{z(\alpha) - z(\alpha')} \right\}$$
 (103)

is a smooth function. Thus, K is a smoothing operator. As in Theorem 1, this means that for any  $\psi \in L^2$  the high wavenumber behavior of K is given by

$$\hat{K} \lceil \psi \rceil(k) = O(e^{-\rho |k|} \hat{\psi}(k)), \tag{104}$$

where  $\rho$  is the assumed strip width of analyticity of z in  $\alpha$ . Consider the integral equation (101). It can be inverted formally to give

$$\xi = (I + K)^{-1}f,\tag{105}$$

where I is the identity operator. Moreover, the boundedness of the inverse implies that if  $f \in L^2$  then so is  $(I + K)^{-1}f$ . Further, Eq. (101) can be rewritten as

$$\xi = f - K[\xi] = f - K[(I + K)^{-1}f]$$
 (106)

by using (105) only on the right-hand side. Finally, using (104) with  $\psi = (I + K)^{-1}f$ , gives

$$\xi \sim f$$
 (107)

in the notation of section 4 and thus, an explicit expression at small scales.

Remark. Actually, invertibility of the integral equation is not strictly necessary. It is only important that on its range, the inverse is bounded. In that case, if the Fredholm alternative is satisfied by the right-hand side, f, the above argument can then be repeated. Such singular integral equations appear in harmonic problems on multiply connected domains.

#### APPENDIX 2: OTHER CHOICES OF T

The equal arclength frame, given in Section 5.2., is actually a special case of two other more general choices of frame:

(1) Scaled initial parametrization frame. In the first, Eq. (57) is replaced with the requirement that

$$s_{\alpha}(\alpha, t) = \frac{1}{2\pi} L(t) R(\alpha),$$
with 
$$\int_{0}^{2\pi} R(\alpha') d\alpha' = 2\pi.$$
 (108)
$$= \frac{R(\alpha)}{2\pi} \int_{0}^{2\pi} s_{\alpha'} d\alpha'.$$
 (109)

This constraint is dynamically satisfied by choosing T to be

$$T(\alpha, t) = T(0, t) + \int_0^\alpha \theta_{\alpha'} U \, d\alpha'$$
$$-\frac{1}{2\pi} \int_0^\alpha R(\alpha') \, d\alpha' \cdot \int_0^{2\pi} \theta_{\alpha'} U \, d\alpha'. \tag{110}$$

This is easily seen by differentiating Eq. (109) with respect to time and using Eq. (51). This choice of frame implies that an initial parametrization of the curve is preserved, up to a time-dependent scaling. If it is known where complexity of the curve will develop, then a finer grid could be placed initially in this area. The equal arclength frame follows from Eq. (108) by setting  $R \equiv 1$ .

(2) Complexity Measuring Frame. In the second choice, one defines a strictly positive, smooth function  $f(\alpha, t)$ , which measures the complexity of the curve. For example,  $f = 1 + \kappa^2$ . Now, the product  $s_{\alpha}f$  is required to be equal everywhere to its mean. That is,

$$s_{\alpha}(\alpha, t) f(\alpha, t) = \frac{1}{2\pi} \int_{0}^{2\pi} s_{\alpha'}(\alpha', t) f(\alpha', t) d\alpha'$$
$$= \frac{1}{2\pi} \int_{0}^{L} f(s, t) ds. \tag{111}$$

Thus, where f is large,  $s_{\alpha}$  (the infinitesimal grid spacing) is small, and vice versa. For general f, it is not possible to obtain an explicit expression for the tangential velocity needed to dynamically enforce condition (111). However, it turns out that if  $f = C(\kappa)$ , then an explicit expression is obtained. Previously, curvature constraints have been used successfully to *statically* remesh interfaces (see [9, 27], for example). However, the choice of T to dynamically enforce (111) is given by

$$T(\alpha, t) = \frac{C|_{\alpha=0}}{C} \cdot T(0, t)$$

$$-\frac{1}{C} \int_{0}^{\alpha} \left\{ C' \left( \frac{1}{s_{\alpha'}} U_{\alpha'} \right)_{\alpha} + \theta_{\alpha'} U(\kappa C' - C) \right\} d\alpha'$$

$$+\frac{\alpha}{2\pi C} \int_{0}^{2\pi} \left\{ C' \left( \frac{1}{s_{\alpha'}} U_{\alpha'} \right)_{\alpha'} + \theta_{\alpha'} U(\kappa C' - C) \right\} d\alpha'$$
(112)

and the equal arclength frame again follows by setting C = 1.

More general reference frames (i.e., more general choices for f) may be useful, however. An important example where they may be needed is in the case of anisotropic surface tension [24, 1]. There, the surface tension coefficient is directionally dependent and so there are preferred directions of growth. It is possible to choose a reference frame that dynamically equidistributes grid points along the interface according to a measure of the anisotropic surface energy. In this case, the appropriate tangential velocity is found by solving a linear integro-differential equation. This is currently under study.

#### **ACKNOWLEDGMENTS**

We thank Russ Caflisch, Anne Greenbaum, Leslie Greengard, Joe Keller, Mike Ward, and especially Dan Meiron and Ray Goldstein, for important and stimulating conservations. All three of the authors thank the hospitality and support of the Institute for Advanced Study where they participated in the special year in fluid mechanics during the 1991 academic year, where some of the initial work of this paper was done. There, they were supported by NSF Grant DMS-9100383 and by Department of the

Air Force Grant F-49620-92-J-0023F. T.Y.H. acknowledges partial support from NSF Grant DMS-9003202 and Air Force Office of Scientific Research Grant AFOSR-90-0090. J.S.L. acknowledges the support of the National Science Foundation through a Mathematical Sciences Post-doctoral Fellowship, the University of Minnesota Army High Performance Computing Research Center, the Minnesota Supercomputer Center, where some of the data analysis was performed, and the University of Minnesota Geometry Center, where a movie was made of the pinching inertial vortex sheet. M.J.S. acknowledges partial support from DOE Grant DE-FG02-88ER25053 and the National Science Foundation through a Presidential Young Investigator Grant DMS-9396403.

#### REFERENCES

- 1. R. Almgren, W.-S. Dai, and V. Hakim, Phys. Rev. Lett. 71, 3461 (1993).
- 2. W. F. Ames, Numerical Methods for Partial Differential Equations (Academic press, New York, 1977).
- 3. C. Anderson, J. Comput. Phys. 62, 111 (1986).
- G. Baker, "Generalized Vortex Methods for Free-Surface Flows," in Waves on Fluid Interfaces, edited by R. E. Meyer (Academic Press, New York/London, 1983).
- 5. G. Baker, R. Caflisch, and M. Siegel, J. Fluid Mech. 252, 51 (1993).
- 6. G. Baker, D. Meiron, and S. Orszag, J. Fluid Mech. 123, 477 (1982).
- 7. G. Baker and A. Nachbin, preprint.
- 8. G. R. Baker and M. J. Shelley, J. Comput. Phys. 64, 112 (1986).
- 9. G. R. Baker and M. J. Shelley, J. Fluid Mech. 215, 161 (1990).
- J. T. Beale, T. Y. Hou, and J. S. Lowengrub, "On the Well-Posedness of Two Fluid Interfacial Flows with Surface Tension," in *Singularities in Fluids*, *Plasmas and Optics*, edited by R. C. Caflisch and G. C. Papanicolaou (Kluwer Academic, London, 1993).
- J. T. Beale, T. Y. Hou, and J. S. Lowengrub, Commun. Pure Appl. Math., to appear.
- 12. J. T. Beale, T. Y. Hou, and J. S. Lowengrub, in preparation.
- 13. G. Birkhoff, Proc. Symp. Appl. Math. 13, 55 (1962).
- 14. G. Carrier, M. Krook, and C. Pearson, Functions of a Complex Variable (McGraw-Hill, New York, 1966).
- 15. W. Dai, L. Kadanoff, and S. Zhou, Phys. Rev. A 43, 6672 (1991).
- 16. W.-S. Dai and M. J. Shelley, Phys. Fluids A 5, 2131 (1993).
- 17. A. J. DeGregoria and L. W. Schwartz, J. Fluid Mech. 164, 383 (1986).
- 18. R. Goldstein, A. Pesci, and M. Shelley, Phys. Rev. Lett. 70, 3043 (1993).
- 19. R. Goldstein, A. Pesci, and M. Shelley, in preparation.
- 20. R. Goldstein and D. M. Petrich, Phys. Rev. Lett. 67, 3203 (1991).
- 21. J. Goodman, T. Y. Hou, and E. Tadmor, Numer. Math., to appear.
- A. Greenbaum, L. Greengard, and G. B. McFadden, J. Comput. Phys. 105, 267 (1993).
- 23. L. Greengard and V. Rokhlin, J. Comput. Phys. 73, 325 (1987).
- M. Gurtin, Thermomechanics of Evolving Phase Boundaries in the Plane (Clarendon Press, Oxford, 1993).
- D. Gottlieb and S. A. Orszag, Numerical Analysis of Spectral Methods: Theory and Aplications, CBMS-NSF Regional Conference Series in Applied Mathematics, Vol. 26 (SIAM, Philadelphia, 1977).
- 26. T. Halsey and M. Leibig, Phys. Rev. A 46, 7793 (1992).
- 27. E. Meiburg and G. Homsy, Phys. Fluids 31, 429 (1988).
- 28. T. Hou, J. Lowengrub, and M. Shelley, in preparation.
- J. M. Hyman and M. J. Naughton, in Proc. SIAM-AMS Conf. on Large Computation in Fluid Mechanics (SIAM, Philadelphia, 1984).
- 30. D. Kellogg, Foundations of Potential Theory (Dover, New York, 1929).

- 31. R. Krasny, J. *FluidMech.* 167, 65 (1986).
- 32. H.-O. Kreiss and J. Ofiger, *SIAM J. Numer. Anal,* 16, 421 (1979).
- 33. D. Moore, *Proc. R. Soc. London* A 365, 105 (1979).
- 34. W. Mullins, J. *Appl. Phys.* 27, 900 (1956).
- 35. W. Mullins and R. Sekerka, J. *Appl. Phys.* 34, 323 (1963).
- 36. A. Prosperetti, L. A. Crum, and H. C. Pumphrey, J. *Geophys. Res.* 94, 3255 (1989).
- 37. D. A. Pugh, Ph.D. thesis, Imperial College, London, 1989.
- 38. D. I. Pullin, J. *FluidMech.* 119, 507 (1982).
- 39. R. Rangel and W. Sirignano, *Phys. Fluids* 31, 1845 (1988).
- 40. D. Reinelt, J. *FluidMech.* 183, 219 (1987).
- 41. R. Rogallo, NASA TM-73203 (unpublished).
- 42. Y. Saad and M. Schultz, *SIAMJ. ScL Stat. Comput.* 7, 856 (1986).

- 43. P. G. Saffman and G. R. Baker, *Annu. Rev. FluidMech.* 11, 95 (1979).
- 44. M. Shelley, *J. FluidMeeh.* 244, 493 (1992).
- 45. M. J. Shelley and M. Vinson, *Nonlinearity* 5, 323 (1992).
- 46. A. Sidi and M. Israeli, *J. Sei. Comput.* 3; 201 (1988).
- 47. H. E. Stanley and N. Ostrowsky (Eds.), *Random Fluctuations and Pattern Growth: Experiments and Models* (Kluwer Academic, London, 1988).
- 48. J. Strain, *J. Comput. Phys.* 85, 342 (1989).
- 49. E. Tadmor, *SIAM Rev.* 29, 525 (1987).
- 50. S. Thorpe, *J. FluidMeeh.* 39, 25 (1969).
- 51. G. Tryggvason and H. Aref, J. *FluidMech.* 136, 1 (1983).
- 52. P. W. Voorhees, G. B. McFadden, R. F. Boisvert, and D. I. Meiron, *Acta Metall. 36,* 207 (1988).
- 53. T. A. Witten and L. M. Sander, *Phys. Rev. B* 27, 5686 (1983).