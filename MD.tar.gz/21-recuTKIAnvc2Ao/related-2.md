# Policy gradient method

Contributors to Wikimedia projects

Policy gradient methods, a class of reinforcement learning algorithms, directly maximize the expected return by differentiating a parameterized policy, which in large language models corresponds to directly optimizing the probability distribution over generated tokens rather than indirectly shaping it through value functions. In training LLMs, this enables reinforcement learning from human or automated feedback (RLHF) to fine-tune the model's behavior end to end, optimizing for reward signals such as instruction following, helpfulness, or alignment instead of only likelihood of next-token prediction. This enables models to better capture nuanced user preferences, handle long-horizon interactions, and produce more aligned, contextually appropriate outputs, yielding measurable improvements in reliability, safety policy adherence, and user satisfaction compared to purely supervised or value-based approaches.

Policy gradient methods are a sub-class of policy optimization methods. Unlike valuebased methods which learn a value function to derive a policy, policy optimization methods directly learn a policy function

 $\pi$ 

that selects actions without consulting a value function. For policy gradient to apply, the policy function

 $\pi_{\theta}$ 

is parameterized by a differentiable parameter

[Image] heta

.

In policy-based RL, the actor is a parameterized policy function

 $\pi_{\theta}$ 

, where

![](_page_1_Picture_0.jpeg)

are the parameters of the actor. The actor takes as argument the state of the environment

[Image]

and produces a probability distribution

 $\pi_{ heta}(\cdot \mid s)$ 

•

If the action space is discrete, then

$$\sum_a \pi_\theta(a \mid s) = 1$$

. If the action space is continuous, then

$$\int_a \pi_ heta(a \mid s) \mathrm{d}a = 1$$

.

The goal of policy optimization is to find some

[Image]

ши шилишев ше слрески сриочи тетига

 $J(\theta)$ 

:

$$J( heta) = \mathbb{E}_{\pi_{ heta}}\left[\sum_{t \in 0:T} \gamma^t R_t \Big| S_0 = s_0
ight]$$

where

 $\gamma$ 

is the discount factor,

 $R_t$ 

is the reward at step

![](_page_2_Picture_9.jpeg)

 $s_0$ 

is the starting state, and

T

is the time-horizon (which can be infinite).

The **policy gradient** is defined as

$$\nabla_{\theta}J(\theta)$$

. Different policy gradient methods stochastically estimate the policy gradient in different ways. The goal of any policy gradient method is to iteratively maximize

 $J(\theta)$ 

by <u>gradient ascent</u>. Since the key part of any policy gradient method is the stochastic estimation of the policy gradient, they are also studied under the title of "Monte Carlo gradient estimation".

The **REINFORCE algorithm**, introduced by <u>Ronald J. Williams</u> in 1992, was the first policy gradient method. It is based on the identity for the policy gradient

$$egin{aligned} 
abla_{ heta} J( heta) &= \mathbb{E}_{\pi_{ heta}} \left[ \sum_{t \in 0:T} 
abla_{ heta} \ln \pi_{ heta}(A_t \mid S_t) \ \sum_{t \in 0:T} (\gamma^t R_t) \middle| S_0 = s_0 
ight] \end{aligned}$$

which can be improved via the "causality trick"

$$egin{aligned} 
abla_{ heta} J( heta) &= \mathbb{E}_{\pi_{ heta}} \left[ \sum_{t \in 0:T} 
abla_{ heta} \ln \pi_{ heta}(A_t \mid S_t) \sum_{ au \in t:T} (\gamma^{ au} R_{ au}) \middle| S_0 = s_0 
ight] \end{aligned}$$

Thus, we have an unbiased estimator of the policy gradient:

$$egin{aligned} 
abla_{ heta} J( heta) &pprox rac{1}{N} \sum_{n=1}^{N} \left[ \sum_{t \in 0:T} 
abla_{ heta} \ln \pi_{ heta}(A_{t,n} \mid S_{t,n}) \sum_{ au \in t:T} (\gamma^{ au-t} R_{ au,n}) 
ight] \end{aligned}$$

where the index

n

ranges over

[Image]

N

rollout trajectories using the policy

 $\pi_{\theta}$ 

.

The score function

$$\nabla_{\theta} \ln \pi_{\theta}(A_t \mid S_t)$$

can be interpreted as the direction in the parameter space that increases the probability of taking action

 $A_{t}$ 

in state

![](_page_3_Picture_15.jpeg)

. The policy gradient, then, is a <u>weighted average</u> of all possible directions to increase the probability of taking any action in any state, but weighted by reward signals, so that if taking a certain action in a certain state is associated with high reward, then that direction would be highly reinforced, and vice versa.

The REINFORCE algorithm is a loop:

1. Rollout

![](_page_4_Picture_1.jpeg)

N

trajectories in the environment, using

 $\pi_{\theta_t}$ 

as the policy function.

<sup>2.</sup> Compute the policy gradient estimation:

$$g_i \leftarrow rac{1}{N} \sum_{n=1}^N \left[ \sum_{t \in 0:T} 
abla_{ heta_t} \ln \pi_{ heta}(A_{t,n} \mid S_{t,n}) \sum_{ au \in t:T} (\gamma^{ au} R_{ au,n}) 
ight]$$

<sup>3.</sup> Update the policy by gradient ascent:

$$heta_{i+1} \leftarrow heta_i + lpha_i g_i$$

Here,

 $\alpha_i$ 

is the learning rate at update step

i

.

REINFORCE is an **on-policy** algorithm, meaning that the trajectories used for the update must be sampled from the current policy

$$\pi_{\theta}$$

. This can lead to high variance in the updates, as the returns

$$R(\tau)$$

can vary significantly between trajectories. Many variants of REINFORCE have been introduced, under the title of **variance reduction**.

#### **REINFORCE** with baseline

#### [edit]

A common way for reducing variance is the **REINFORCE with baseline** algorithm, based on the following identity:

$$abla_{ heta}J( heta) = \mathbb{E}_{\pi_{ heta}}\left[\sum_{t \in 0:T} 
abla_{ heta} \ln \pi_{ heta}(A_t|S_t) \left(\sum_{ au \in t:T} (\gamma^{ au}R_{ au}) - b(S_t)
ight) \Big| S_0 = s_0
ight]$$

$$b: \mathrm{States} 
ightarrow \mathbb{R}$$

. This can be proven by applying the previous lemma.

The algorithm uses the modified gradient estimator

$$g_i \leftarrow \frac{1}{N} \sum_{n=1}^N \left[ \sum_{t \in 0:T} \nabla_{\theta_t} \ln \pi_{\theta}(A_{t,n}|S_{t,n}) \left( \sum_{\tau \in t:T} (\gamma^{\tau} R_{\tau,n}) - b_i(S_{t,n}) \right) \right]$$

and the original REINFORCE algorithm is the special case where

$$b_i \equiv 0$$

.

#### Actor-critic methods

[edit]

If

 $b_i$ 

is chosen well, such that

$$b_i(S_t) pprox \sum_{ au \in t: T} (\gamma^ au R_ au) = \gamma^t V^{\pi_{ heta_i}}(S_t)$$

, this could significantly decrease variance in the gradient estimation. That is, the baseline should be as close to the **value function** 

$$V^{\pi_{ heta_{i}}}\left(S_{t}
ight)$$

as possible, approaching the ideal of:

$$egin{aligned} 
abla_{ heta} J( heta) &= \mathbb{E}_{\pi_{ heta}} \left[ \sum_{t \in 0:T} 
abla_{ heta} \ln \pi_{ heta}(A_t | S_t) \left( \sum_{ au \in t:T} (\gamma^{ au} R_{ au}) - \gamma^t V^{\pi_{ heta}}(S_t) 
ight) \Big| S_0 = s_0 
ight] \end{aligned}$$

Note that, as the policy

 $\pi_{\theta_t}$ 

updates, the value function

$$V^{\pi_{ heta_{i}}}\left(S_{t}
ight)$$

updates as well, so the baseline should also be updated. One common approach is to train a separate function that estimates the value function, and use that as the baseline. This is one of the <u>actor-critic methods</u>, where the policy function is the actor and the value function is the critic.

#### The **O-function**

 $Q^{\pi}$ 

can also be used as the critic, since

$$egin{aligned} 
abla_{ heta} J( heta) &= E_{\pi_{ heta}} \left[ \sum_{0 \leq t \leq T} \gamma^t 
abla_{ heta} \ln \pi_{ heta}(A_t|S_t) \cdot Q^{\pi_{ heta}}(S_t,A_t) \middle| S_0 = s_0 
ight] \end{aligned}$$

by a similar argument using the tower law.

Subtracting the value function as a baseline, we find that the advantage function

$$A^{\circ}(S,A) = Q^{\circ}(S,A) - V^{\circ}(S)$$

can be used as the critic as well:

$$egin{aligned} 
abla_{ heta} J( heta) &= E_{\pi_{ heta}} \left[ \sum_{0 \leq t \leq T} \gamma^t 
abla_{ heta} \ln \pi_{ heta}(A_t|S_t) \cdot A^{\pi_{ heta}}(S_t,A_t) \middle| S_0 = s_0 
ight] \end{aligned}$$

In summary, there are many unbiased estimators for

$$\nabla_{\theta} J_{\theta}$$

, all in the form of:

$$abla_{ heta} J( heta) = E_{\pi_{ heta}} \left[ \sum_{0 \leq t \leq T} 
abla_{ heta} \ln \pi_{ heta}(A_t | S_t) \cdot \Psi_t \Big| S_0 = s_0 
ight]$$

where

 $\Psi_t$ 

is any linear sum of the following terms:

 $\sum_{0 \leq au \leq T} (\gamma^ au R_ au)$ 

: never used.

$$\gamma^t \sum_{t \leq au \leq T} (\gamma^{ au - t} R_ au)$$

: used by the REINFORCE algorithm.

$$\gamma^t \sum_{t \leq au \leq T} (\gamma^{ au - t} R_ au) - b(S_t)$$

: used by the REINFORCE with baseline algorithm.

$$\gamma^{t}\left(R_{t}+\gamma V^{\pi_{ heta}}\left(S_{t+1}
ight)-V^{\pi_{ heta}}\left(S_{t}
ight)
ight)$$

: 1-step TD learning.

$$\gamma^t Q^{\pi_ heta}(S_t,A_t)$$

•

$$\gamma^t A^{\pi_ heta}(S_t,A_t)$$

Some more possible

 $\Psi_t$ 

are as follows, with very similar proofs.

### Natural policy gradient

#### [edit]

The natural policy gradient method is a variant of the policy gradient method, proposed by <a href="Sham Kakade">Sham Kakade</a> in 2001. Unlike standard policy gradient methods, which depend on the choice of parameters

![](_page_7_Picture_0.jpeg)

(making updates coordinate-dependent), the natural policy gradient aims to provide a coordinate-free update, which is geometrically "natural".

Standard policy gradient updates

$$\theta_{i+1} = \theta_i + \alpha \nabla_{\theta} J(\theta_i)$$

solve a constrained optimization problem:

$$egin{cases} \max_{ heta_{i+1}} J( heta_i) + ( heta_{i+1} - heta_i)^T 
abla_{ heta} J( heta_i) \ \| heta_{i+1} - heta_i\| \leq lpha \cdot \|
abla_{ heta} J( heta_i)\| \end{cases}$$

While the objective (linearized improvement) is geometrically meaningful, the Euclidean constraint

$$\|\theta_{i+1} - \theta_i\|$$

introduces coordinate dependence. To address this, the natural policy gradient replaces the Euclidean constraint with a Kullback-Leibler divergence (KL) constraint:

$$\left\{egin{aligned} \max_{ heta_{i+1}} J( heta_i) + ( heta_{i+1} - heta_i)^T 
abla_{ heta} J( heta_i) \ ar{D}_{KL}(\pi_{ heta_{i+1}} \| \pi_{ heta_i}) \leq \epsilon \end{aligned}
ight.$$

where the KL divergence between two policies is averaged over the state distribution under policy

$$\pi_{\theta_i}$$

. That is,

$$ar{D}_{KL}(\pi_{ heta_{i+1}} \| \pi_{ heta_i}) := \mathbb{E}_{s \sim \pi_{ heta_i}} \left[ D_{KL}(\pi_{ heta_{i+1}}(\cdot | s) \| \pi_{ heta_i}(\cdot | s)) 
ight]$$

This ensures updates are invariant to invertible affine parameter transformations.

### Fisher information approximation

[edit]

For small

![](_page_7_Picture_18.jpeg)

, the KL divergence is approximated by the Fisher information metric:

$$ar{D}_{KL}(\pi_{ heta_{i+1}} \| \pi_{ heta_i}) pprox rac{1}{2} ( heta_{i+1} - heta_i)^T F( heta_i) ( heta_{i+1} - heta_i)$$

where

$$F(\theta)$$

is the Fisher information matrix of the policy, defined as:

$$F( heta) = \mathbb{E}_{s,a \sim \pi_{ heta}} \left[ 
abla_{ heta} \ln \pi_{ heta}(a|s) (
abla_{ heta} \ln \pi_{ heta}(a|s))^T 
ight]$$

This transforms the problem into a problem in <u>quadratic programming</u>, yielding the natural policy gradient update:

$$heta_{i+1} = heta_i + lpha F( heta_i)^{-1} 
abla_ heta J( heta_i)$$

The step size

![](_page_8_Picture_9.jpeg)

is typically adjusted to maintain the KL constraint, with

$$lpha pprox \sqrt{rac{2\epsilon}{\left(
abla_{ heta}J( heta_i)
ight)^TF( heta_i)^{-1}
abla_{ heta}J( heta_i)}}$$

Inverting

$$F(\theta)$$

is computationally intensive, especially for high-dimensional parameters (e.g., neural networks). Practical implementations often use approximations.

### **Trust Region Policy Optimization (TRPO)**

[edit]

**Trust Region Policy Optimization** (TRPO) is a policy gradient method that extends the natural policy gradient approach by enforcing a <u>trust region</u> constraint on policy updates. Developed by Schulman et al. in 2015, TRPO improves upon the natural policy gradient method.

The natural gradient descent is theoretically optimal, if the objective is truly a quadratic function, but this is only an approximation. TRPO's line search and KL constraint

iunotion, put und id omy an approximation. Thi O d into dearch and the condumit

attempts to restrict the solution to within a "trust region" in which this approximation does not break down. This makes TRPO more robust in practice.

Like natural policy gradient, TRPO iteratively updates the policy parameters

![](_page_9_Picture_3.jpeg)

 $\theta$ 

by solving a constrained optimization problem specified coordinate-free:

$$\left\{egin{array}{l} \max_{ heta} L( heta, heta_i) \ ar{D}_{KL}(\pi_{ heta} \| \pi_{ heta_i}) \leq \epsilon \end{array}
ight.$$

where

Note that in general, other surrogate advantages are possible:

$$L( heta, heta_i) = \mathbb{E}_{s,a \sim \pi_{ heta_i}}\left[rac{\pi_{ heta}(a|s)}{\pi_{ heta_i}(a|s)}\Psi^{\pi_{ heta_i}}(s,a)
ight]$$

where

 $\Psi$ 

is any linear sum of the previously mentioned type. Indeed, OpenAI recommended using the Generalized Advantage Estimate, instead of the plain advantage

$$A^{\pi_{\theta}}$$

.

The surrogate advantage

$$L(\theta, \theta_t)$$

is designed to align with the policy gradient

$$abla_{ heta}J( heta)$$

. Specifically, when

$$heta = heta_t$$

,

$$\nabla_{\theta}L(\theta,\theta_t)$$

equals the policy gradient derived from the advantage function:

$$abla_{ heta} J( heta) = \mathbb{E}_{(s,a) \sim \pi_{ heta}} \left[ 
abla_{ heta} \ln \pi_{ heta}(a|s) \cdot A^{\pi_{ heta}}(s,a) 
ight] = 
abla_{ heta} L( heta, heta_t)$$

However, when

$$\theta 
eq \theta_i$$

, this is not necessarily true. Thus it is a "surrogate" of the real objective.

As with natural policy gradient, for small policy updates, TRPO approximates the surrogate advantage and KL divergence using Taylor expansions around

 $\theta_t$ 

:

$$egin{aligned} L( heta, heta_i) &pprox g^T( heta - heta_i), \ ar{D}_{ ext{KL}}(\pi_{ heta} \| \pi_{ heta_i}) &pprox rac{1}{2} ( heta - heta_i)^T H ( heta - heta_i), \end{aligned}$$

where:

 $g = 
abla_{ heta} L( heta, heta_i)ig|_{ heta = heta_i}$ 

is the policy gradient.

$$F = 
abla_{ heta}^2 ar{D}_{ ext{KL}}(\pi_{ heta} \| \pi_{ heta_i})ig|_{ heta = heta_i}$$

is the Fisher information matrix.

This reduces the problem to a quadratic optimization, yielding the natural policy gradient update:

$$heta_{i+1} = heta_i + \sqrt{rac{2\epsilon}{g^T F^{-1} g}} F^{-1} g.$$

So far, this is essentially the same as natural gradient method. However, TRPO improves upon it by two modifications:

## **Proximal Policy Optimization (PPO)**

[edit]

A further improvement is <u>proximal policy optimization</u> (PPO), which avoids even computing

$$F(\theta)$$

and

$$F(\theta)^{-1}$$

via a first-order approximation using clipped probability ratios.

Specifically, instead of maximizing the surrogate advantage

$$\max_{ heta} L( heta, heta_t) = \mathbb{E}_{s, a \sim \pi_{ heta_t}} \left[ rac{\pi_{ heta}(a|s)}{\pi_{ heta_t}(a|s)} A^{\pi_{ heta_t}}(s, a) 
ight]$$

under a KL divergence constraint, it directly inserts the constraint into the surrogate advantage:

$$\max_{ heta} \mathbb{E}_{s,a \sim \pi_{ heta_t}} \left[ \left\{ egin{aligned} \min\left(rac{\pi_{ heta}(a|s)}{\pi_{ heta_t}\left(a|s
ight)}, 1 + \epsilon
ight) A^{\pi_{ heta_t}}(s,a) & ext{ if } A^{\pi_{ heta_t}}(s,a) > 0 \ \max\left(rac{\pi_{ heta}(a|s)}{\pi_{ heta_t}\left(a|s
ight)}, 1 - \epsilon
ight) A^{\pi_{ heta_t}}(s,a) & ext{ if } A^{\pi_{ heta_t}}(s,a) < 0 \ \end{array} 
ight]$$

and PPO maximizes the surrogate advantage by stochastic gradient descent, as usual.

In words, gradient-ascending the new surrogate advantage function means that, at some state

s, a

, if the advantage is positive:

$$A^{\pi_{ heta_t}}(s,a)>0$$

, then the gradient should direct

![](_page_11_Picture_6.jpeg)

 $\theta$ 

towards the direction that increases the probability of performing action

[Image]  $oldsymbol{a}$ 

under the state

![](_page_11_Picture_11.jpeg)

. However, as soon as

![](_page_12_Picture_0.jpeg)

has changed so much that

$$\pi_{ heta}(a|s) \geq (1+\epsilon)\pi_{ heta_t}(a|s)$$

, then the gradient should stop pointing it in that direction. And similarly if

$$A^{\pi_{ heta_t}}(s,a) < 0$$

. Thus, PPO avoids pushing the parameter update too hard, and avoids changing the policy too much.

To be more precise, to update

 $\theta_t$ 

to

$$\theta_{t+1}$$

requires multiple update steps on the same batch of data. It would initialize

$$heta = heta_t$$

, then repeatedly apply gradient descent (such as the Adam optimizer) to update

![](_page_12_Picture_13.jpeg)

 $\theta$ 

until the surrogate advantage has stabilized. It would then assign

$$heta_{t+1}$$

to

![](_page_12_Picture_18.jpeg)

|                                                                  | I<br>L                   |                           |
|------------------------------------------------------------------|--------------------------|---------------------------|
| , and do it again.                                               | heta                     |                           |
|                                                                  |                          |                           |
| During this inner-loop, the fir                                  | st update to             |                           |
|                                                                  | [Image]                  |                           |
|                                                                  | heta                     |                           |
| would not hit the bounds, but as                                 | $1-\epsilon, 1+\epsilon$ |                           |
| bounds, but as                                                   | ·                        |                           |
|                                                                  | [Image]                  |                           |
|                                                                  | heta                     |                           |
| is updated further and further                                   | away from                |                           |
| , it eventually starts hitting the gradient becomes zero, and th |                          | nd hit, the corresponding |
|                                                                  | [Image]                  |                           |
|                                                                  | heta                     |                           |

.

This is important, because the surrogate loss assumes that the state-action pair s,a is sampled from what the agent would see if the agent runs the policy  $\pi_{\theta_t}$ , but policy gradient should be on-policy. So, as

![](_page_14_Picture_3.jpeg)

changes, the surrogate loss becomes more and more off-policy. This is why keeping

![](_page_14_Picture_5.jpeg)

proximal to

 $\theta_t$ 

is necessary.

If there is a reference policy

 $\pi_{\mathrm{ref}}$ 

that the trained policy should not diverge too far from, then additional KL divergence penalty can be added:

$$-eta \mathbb{E}_{s,a \sim \pi_{ heta_t}} \left[ \log \! \left( rac{\pi_{ heta}(a|s)}{\pi_{ ext{ref}}(a|s)} 
ight) 
ight]$$

where

![](_page_15_Picture_0.jpeg)

adjusts the strength of the penalty. This has been used in training <u>reasoning language</u> <u>models</u> with <u>reinforcement learning from human feedback</u>. The KL divergence penalty term can be estimated with lower variance using the equivalent form (see <u>f-divergence</u> for details):

$$-\beta \mathbb{E}_{s,a \sim \pi_{\theta_t}} \left[ \log \! \left( \frac{\pi_{\theta}(a|s)}{\pi_{\mathrm{ref}}(a|s)} \right) + \frac{\pi_{\mathrm{ref}}(a|s)}{\pi_{\theta}(a|s)} - 1 \right]$$

### **Group Relative Policy Optimization (GRPO)**

[edit]

The Group Relative Policy Optimization (GRPO) is a minor variant of PPO that omits the value function estimator

V

. Instead, for each state

![](_page_15_Picture_8.jpeg)

, it samples multiple actions

$$a_1,\ldots,a_G$$

from the policy

$$\pi_{\theta}$$

, then calculate the group-relative advantage

$$A^{\pi_{ heta_t}}(s,a_j) = rac{r(s,a_j) - \mu}{\sigma}$$

where

$$\mu, \sigma$$

are the mean and standard deviation of

$$r(s, a_1), \ldots, r(s, a_G)$$

. That is, it is the standard score of the rewards.

Then, it maximizes the PPO objective, averaged over all actions:

$$\max_{ heta} rac{1}{G} \sum_{i=1}^{G} \mathbb{E}_{(s,a_{1},\ldots,a_{G}) \sim \pi_{ heta_{t}}} \left[ \left\{ \min\left(rac{\pi_{ heta}(a_{i}|s)}{\pi_{ heta_{t}}(a_{i}|s)}, 1 + \epsilon
ight) A^{\pi_{ heta_{t}}}(s,a_{i}) & ext{ if } A^{\pi_{ heta_{t}}}(s,a_{i}) > 0 
ight. \ \left. \max\left(rac{\pi_{ heta}(a_{i}|s)}{\pi_{ heta_{t}}(a_{i}|s)}, 1 - \epsilon
ight) A^{\pi_{ heta_{t}}}(s,a_{i}) & ext{ if } A^{\pi_{ heta_{t}}}(s,a_{i}) < 0 
ight. 
ight.$$

Intuitively, each policy update step in GRPO makes the policy more likely to respond to each state with an action that performed relatively better than other actions tried at that state, and less likely to respond with one that performed relatively worse.

As before, the KL penalty term can be applied to encourage the trained policy to stay close to a reference policy. GRPO was first proposed in the context of training <u>reasoning</u> language models by researchers at DeepSeek.

- \* Reinforcement learning
- Deep reinforcement learning
- Actor-critic method
- 1. Ouyang, Long; Wu, Jeffrey; Jiang, Xu; Almeida, Diogo; Wainwright, Carroll; Mishkin, Pamela; Zhang, Chong; Agarwal, Sandhini; Slama, Katarina; Ray, Alex; Schulman, John; Askell, Amanda; Askell, Peter; Welinder, Peter; Christiano, Paul; Leike, Jan; Lowe, Ryan (2022). "Training language models to follow instructions with human feedback". arXiv:2203.02155 [cs.CL].
- <sup>2.</sup> Sutton, Richard S; McAllester, David; Singh, Satinder; Mansour, Yishay (1999).
  <u>"Policy Gradient Methods for Reinforcement Learning with Function</u>
  <u>Approximation"</u>. Advances in Neural Information Processing Systems. 12. MIT Press.
- <sup>3.</sup> Mohamed, Shakir; Rosca, Mihaela; Figurnov, Michael; Mnih, Andriy (2020).

  "Monte Carlo Gradient Estimation in Machine Learning". Journal of Machine Learning Research. 21 (132): 1–62. arXiv:1906.10652. ISSN 1533-7928.
- 4. Williams, Ronald J. (May 1992). "Simple statistical gradient-following algorithms for connectionist reinforcement learning". Machine Learning. 8 (3–4): 229–256. doi:10.1007/BF00992696. ISSN 0885-6125.
- 5. Sutton, Richard S; McAllester, David; Singh, Satinder; Mansour, Yishay (1999).
  "Policy Gradient Methods for Reinforcement Learning with Function
  Approximation". Advances in Neural Information Processing Systems. 12. MIT
  Press.
- 6. Schulman, John; Moritz, Philipp; Levine, Sergey; Jordan, Michael; Abbeel, Pieter (2018-10-20). "High-Dimensional Continuous Control Using Generalized Advantage Estimation". arXiv:1506.02438 [cs.LG].
- 7. Kakade, Sham M (2001). "A Natural Policy Gradient". Advances in Neural Information Processing Systems. 14. MIT Press.

8. Schulman, John; Levine, Sergey; Moritz, Philipp; Jordan, Michael; Abbeel, Pieter (2015-07-06). "Trust region policy optimization". Proceedings of the 32nd International Conference on International Conference on Machine Learning -

Volume 37. ICML'15. Lille, France: JMLR.org: 1889–1897.

9. Schulman, John; Wolski, Filip; Dhariwal, Prafulla; Radford, Alec; Klimov, Oleg (2017-08-28). "Proximal Policy Optimization Algorithms". arXiv:1707.06347 [cs.LG].

- Nisan Stiennon; Long Ouyang; Jeffrey Wu; Daniel Ziegler; Ryan Lowe; Chelsea Voss; Alec Radford; Dario Amodei; Paul F. Christiano (2020). "Learning to summarize with human feedback". Advances in Neural Information Processing Systems. 33.
- 11. ^ Shao, Zhihong; Wang, Peiyi; Zhu, Qihao; Xu, Runxin; Song, Junxiao; Bi, Xiao; Zhang, Haowei; Zhang, Mingchuan; Li, Y. K. (2024-04-27). "DeepSeekMath: Pushing the Limits of Mathematical Reasoning in Open Language Models".
  arXiv:2402.03300 [cs.CL].
  - \* Sutton, Richard S.; Barto, Andrew G. (2018). Reinforcement learning: an introduction. Adaptive computation and machine learning series (2 ed.). Cambridge, Massachusetts: The MIT Press. ISBN 978-0-262-03924-6.
  - \* Bertsekas, Dimitri P. (2019). Reinforcement learning and optimal control (2 ed.). Belmont, Massachusetts: Athena Scientific. <u>ISBN</u> 978-1-886529-39-7.
  - Grossi, Csaba (2010). Algorithms for Reinforcement Learning. Synthesis Lectures on Artificial Intelligence and Machine Learning (1 ed.). Cham: Springer International Publishing. <u>ISBN</u> 978-3-031-00423-0.
  - Mohamed, Shakir; Rosca, Mihaela; Figurnov, Michael; Mnih, Andriy (2020).

    "Monte Carlo Gradient Estimation in Machine Learning". Journal of Machine
    Learning Research. 21 (132): 1–62. arXiv:1906.10652. ISSN 1533-7928.
  - Weng, Lilian (2018-04-08). <u>"Policy Gradient Algorithms"</u>. lilianweng.github.io. Retrieved 2025-01-25.
  - \* <u>"Vanilla Policy Gradient Spinning Up documentation"</u>. spinningup.openai.com. Retrieved 2025-01-25.