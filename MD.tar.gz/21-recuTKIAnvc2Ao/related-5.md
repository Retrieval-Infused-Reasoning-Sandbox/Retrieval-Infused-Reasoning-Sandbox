# **Conditional expectation**

Contributors to Wikimedia projects

From Wikipedia, the free encyclopedia

In probability theory, the conditional expectation, conditional expected value, or conditional mean of a random variable is its expected value evaluated with respect to the conditional probability distribution. If the random variable can take on only a finite number of values, the "conditions" are that the variable can only take on a subset of those values. More formally, in the case when the random variable is defined over a discrete probability space, the "conditions" are a partition of this probability space.

Depending on the context, the conditional expectation can be either a random variable or a function. The random variable is denoted

$$E(X \mid Y)$$

analogously to conditional probability. The function form is either denoted

$$E(X \mid Y = y)$$

or a separate function symbol such as

is introduced with the meaning

$$E(X \mid Y) = f(Y)$$

# Example 1: Dice rolling

#### [edit]

Consider the roll of a fair die and let A = 1 if the number is even (i.e., 2, 4, or 6) and A = 0otherwise. Furthermore, let B = 1 if the number is prime (i.e., 2, 3, or 5) and B = 0otherwise.

|   | 1 | 2 | 3 | 4 | 5 | 6 |
|---|---|---|---|---|---|---|
| A | 0 | 1 | 0 | 1 | 0 | 1 |
| В | 0 | 1 | 1 | 0 | 1 | 0 |

The unconditional expectation of A is

$$E[A] = (0+1+0+1+0+1)/6 = 1/2$$

, but the expectation of A conditional on B = 1 (i.e., conditional on the die roll being 2, 3,

$$E[A \mid B=1] = (1+0+0)/3 = 1/3$$

, and the expectation of A conditional on B=0 (i.e., conditional on the die roll being 1, 4, or 6) is

$$E[A \mid B = 0] = (0 + 1 + 1)/3 = 2/3$$

. Likewise, the expectation of B conditional on A = 1 is

$$E[B \mid A = 1] = (1 + 0 + 0)/3 = 1/3$$

, and the expectation of B conditional on A = 0 is

$$E[B \mid A = 0] = (0 + 1 + 1)/3 = 2/3$$

.

## Example 2: Rainfall data

#### [edit]

Suppose we have daily rainfall data (mm of rain each day) collected by a weather station on every day of the ten-year (3652-day) period from January 1, 1990, to December 31, 1999. The unconditional expectation of rainfall for an unspecified day is the average of the rainfall amounts for those 3652 days. The *conditional* expectation of rainfall for an otherwise unspecified day known to be (conditional on being) in the month of March, is the average of daily rainfall over all 310 days of the ten-year period that fall in March. Similarly, the conditional expectation of rainfall conditional on days dated March 2 is the average of the rainfall amounts that occurred on the ten days with that specific date.

The related concept of <u>conditional probability</u> dates back at least to <u>Laplace</u>, who calculated conditional distributions. It was <u>Andrey Kolmogorov</u> who, in 1933, formalized it using the <u>Radon–Nikodym theorem</u>. In works of <u>Paul Halmos</u> and <u>Joseph L. Doob</u> from 1953, conditional expectation was generalized to its modern definition using <u>sub-</u> $\sigma$ -algebras.

# Conditioning on an event

[edit]

If A is an event in

with nonzero probability, and X is a <u>discrete random variable</u>, the conditional expectation of X given A is

$$egin{aligned} \mathrm{E}(X\mid A) &= \sum_x x P(X=x\mid A) \ &= \sum_x x rac{P(\{X=x\}\cap A)}{P(A)} \end{aligned}$$

where the sum is taken over all possible outcomes of X.

If

$$P(A) = 0$$

, the conditional expectation is undefined due to the division by zero.

#### Discrete random variables

[edit]

If X and Y are discrete random variables, the conditional expectation of X given Y is

$$egin{aligned} \mathrm{E}(X\mid Y=y) &= \sum_x x P(X=x\mid Y=y) \ &= \sum_x x rac{P(X=x,Y=y)}{P(Y=y)} \end{aligned}$$

where

$$P(X = x, Y = y)$$

is the <u>joint probability mass function</u> of X and Y. The sum is taken over all possible outcomes of X.

As above, the expression is undefined if

$$P(Y=y)=0$$

.

Conditioning on a discrete random variable is the same as conditioning on the corresponding event:

$$\mathrm{E}(X\mid Y=y)=\mathrm{E}(X\mid A)$$

where A is the set

$${Y = y}$$

.

### Continuous random variables

[edit]

Let

X

and

¥

be continuous random variables with joint density

$$f_{X,Y}(x,y),$$

Y

's density

$$f_Y(y)$$
,

and conditional density

$$f_{X\mid Y}(x\mid y) = rac{f_{X,Y}(x,y)}{f_{Y}(y)}$$

of

X

given the event

$$Y = y$$
.

The conditional expectation of

X

given

$$Y = y$$

is

$$egin{align} \mathrm{E}(X\mid Y=y) &= \int_{-\infty}^{\infty} x f_{X\mid Y}(x\mid y) \, \mathrm{d}x \ &= rac{1}{f_Y(y)} \int_{-\infty}^{\infty} x f_{X,Y}(x,y) \, \mathrm{d}x. \end{split}$$

When the denominator is zero, the expression is undefined.

Conditioning on a continuous random variable is not the same as conditioning on the event

$$\{Y=y\}$$

as it was in the discrete case. For a discussion, see <u>Conditioning on an event of probability zero</u>. Not respecting this distinction can lead to contradictory conclusions as illustrated by the <u>Borel-Kolmogorov paradox</u>.

## L<sup>2</sup> random variables

[edit]

All random variables in this section are assumed to be in

![](_page_3_Picture_22.jpeg)

| , that is <u>square integrable</u> . In it         |                            | l expectation is developed |
|----------------------------------------------------|----------------------------|----------------------------|
| without this assumption, see b                     | elow under . The           |                            |
|                                                    | [Image]                    |                            |
|                                                    | $L^2$                      |                            |
| theory is, however, considered                     | more intuitive and admits  | . In the context of        |
|                                                    | [Image] $L^2$              |                            |
| random variables, conditional                      |                            | egression.                 |
| In what follows let<br>be a probability space, and | $(\Omega, \mathcal{F}, P)$ |                            |
| in                                                 | $X:\Omega\to\mathbb{R}$    |                            |
|                                                    | [Image]                    |                            |

 $L^2$ 

with mean

[Image]  $\mu_X$ and variance  $\sigma_X^2$ . The expectation [Image]  $\mu_X$ minimizes the mean squared error:  $\min_{x\in\mathbb{R}}\mathrm{E}ig((X-x)^2ig)=\mathrm{E}ig((X-\mu_X)^2ig)=\sigma_X^2.$ The conditional expectation of X is defined analogously, except instead of a single number [Image]  $\mu_X$ , the result will be a function

![](_page_6_Picture_0.jpeg)

. Let

$$Y:\Omega o\mathbb{R}^n$$

be a random vector. The conditional expectation

$$e_X:\mathbb{R}^n o\mathbb{R}$$

is a measurable function such that

$$\min_{g \; ext{measurable}} \; \mathrm{E}ig((X-g(Y))^2ig) = \mathrm{E}ig((X-e_X(Y))^2ig).$$

Note that unlike

![](_page_6_Picture_8.jpeg)

, the conditional expectation

$$e_X$$

is not generally unique: there may be multiple minimizers of the mean squared error.

**Example 1**: Consider the case where Y is the constant random variable that is always 1. Then the mean squared error is minimized by any function of the form

$$e_X(y) = \left\{ egin{array}{ll} \mu_X & ext{if } y=1, \ ext{any number} & ext{otherwise}. \end{array} 
ight.$$

Example 2: Consider the case where Y is the 2-dimensional random vector

. Then clearly

$$\mathrm{E}(X\mid Y)=X$$

but in terms of functions it can be expressed as

$$e_X(y_1, y_2) = 3y_1 - y_2$$

$$e_X'(y_1,y_2) = y_2 - y_1$$

or infinitely many other ways. In the context of <u>linear regression</u>, this lack of uniqueness is called <u>multicollinearity</u>.

Conditional expectation is unique up to a set of measure zero in

![](_page_7_Picture_4.jpeg)

. The measure used is the pushforward measure induced by Y.

In the first example, the pushforward measure is a <u>Dirac distribution</u> at 1. In the second it is concentrated on the "diagonal"

$$\{y:y_2=2y_1\}$$

, so that any set not intersecting it has measure o.

The existence of a minimizer for

$$\min_g \mathrm{E}\big((X-g(Y))^2\big)$$

is non-trivial. It can be shown that

$$M:=\{g(Y):g \text{ is measurable and } \mathrm{E}(g(Y)^2)<\infty\}=L^2(\Omega,\sigma(Y))$$

is a closed subspace of the Hilbert space

$$L^2(\Omega)$$

. By the Hilbert projection theorem, the necessary and sufficient condition for

$$e_X$$

to be a minimizer is that for all

in M we have

$$\langle X - e_X(Y), f(Y) \rangle = 0.$$

In words, this equation says that the residual

$$X - e_X(Y)$$

is orthogonal to the space M of all functions of Y. This orthogonality condition, applied to the indicator functions

$$f(Y) = 1_{Y \in \mathcal{U}}$$

, is used below to extend conditional expectation to the case that X and Y are not necessarily in

![](_page_8_Picture_2.jpeg)

.

#### Connections to regression

#### [edit]

The conditional expectation is often approximated in <u>applied mathematics</u> and <u>statistics</u> due to the difficulties in analytically calculating it, and for interpolation.

The Hilbert subspace

![](_page_8_Picture_8.jpeg)

defined above is replaced with subsets thereof by restricting the functional form of g, rather than allowing any measurable function. Examples of this are <u>decision tree</u> regression when g is required to be a <u>simple function</u>, <u>linear regression</u> when g is required to be affine, etc.

These generalizations of conditional expectation come at the cost of many of no longer holding. For example, let M be the space of all linear functions of Y and let

 $\mathcal{E}_{M}$ 

denote this generalized conditional expectation/

[Image]  $L^2$ 

projection. If

[Image]

M

does not contain the constant functions, the tower property

$$\mathrm{E}(\mathcal{E}_M(X))=\mathrm{E}(X)$$

will not hold.

An important special case is when X and Y are jointly normally distributed. In this case it can be shown that the conditional expectation is equivalent to linear regression:

$$e_X(Y) = \alpha_0 + \sum_i \alpha_i Y_i$$

for coefficients

$$\{\alpha_i\}_{i=0..n}$$

described in Multivariate normal distribution#Conditional distributions.

# Conditional expectation with respect to a sub- $\sigma$ -algebra

[edit]

![](_page_10_Figure_0.jpeg)

Conditional expectation with respect to a  $\sigma$ -algebra: in this example the probability space

$$(\Omega, \mathcal{F}, P)$$

is the [0,1] interval with the <u>Lebesgue measure</u>. We define the following  $\sigma$ -algebras:

![](_page_10_Picture_4.jpeg)

1

is the  $\sigma$ -algebra generated by the intervals with end-points 0, 1/4, 1/2, 3/4, 1; and

![](_page_10_Picture_7.jpeg)

is the  $\sigma$ -algebra generated by the intervals with end-points 0, 1/2, 1. Here the conditional expectation is effectively the average over the minimal sets of the  $\sigma$ -algebra.

## Consider the following:

Since

is a sub

 $\sigma$ 

 $\mathcal{H}$ 

-algebra of

 $\mathcal{F}$ 

, the function

$$X{:}\,\Omega o\mathbb{R}^n$$

is usually not

 $\mathcal{H}$ 

-measurable, thus the existence of the integrals of the form

$$\int_H X \, dP|_{\mathcal{H}}$$

, where

$$H\in \mathcal{H}$$

and

$$P|_{\mathcal{H}}$$

is the restriction of

[Image]

P

to

 $\mathcal{H}$ 

, cannot be stated in general. However, the local averages

$$\int_H X \, dP$$

can be recovered in

$$(\Omega, \mathcal{H}, P|_{\mathcal{H}})$$

with the help of the conditional expectation.

# A conditional expectation of X given

 $\mathcal{H}$ 

, denoted as

 $E(X \mid \mathcal{H})$ 

, is any

 $\mathcal{H}$ 

IIICUDUIUDIC IUIICUOII

$$\Omega o \mathbb{R}^n$$

which satisfies:

$$\int_H \mathrm{E}(X\mid \mathcal{H})\,\mathrm{d}P = \int_H X\,\mathrm{d}P$$

for each

 $H\in \mathcal{H}$ 

.

As noted in the

![](_page_12_Picture_8.jpeg)

 $L^2$ 

discussion, this condition is equivalent to saying that the residual

$$X - \mathrm{E}(X \mid \mathcal{H})$$

is orthogonal to the indicator functions

 $1_H$ 

:

$$\langle X - \mathrm{E}(X \mid \mathcal{H}), 1_H 
angle = 0$$

The existence of

$$\mathrm{E}(X \mid \mathcal{H})$$

can be established by noting that

$$\mu^X \colon F \mapsto \int_F X \,\mathrm{d}P$$

for

$$F\in \mathcal{F}$$

is a finite measure on

$$(\Omega, \mathcal{F})$$

that is absolutely continuous with respect to

[Image]

P[Image] his the <u>natural injection</u> from  $\mathcal{H}$  $\mathcal{F}$  $\mu^X\circ h=\mu^X|_{\mathcal{H}}$  $\mu^X$  $\mathcal{H}$  $P\circ h=P|_{\mathcal{H}}$ [Image] P

to

. If

to

to

and

, then

is the restriction of

is the restriction of

 $\mathcal{H}$ 

. Furthermore,

$$\mu^X \circ h$$

is appointely continuous with respect to

$$P \circ h$$

, because the condition

$$P \circ h(H) = 0 \iff P(h(H)) = 0$$

implies

$$\mu^X(h(H)) = 0 \iff \mu^X \circ h(H) = 0.$$

Thus, we have

$$\mathrm{E}(X\mid \mathcal{H}) = rac{\mathrm{d}\mu^X|_{\mathcal{H}}}{\mathrm{d}P|_{\mathcal{H}}} = rac{\mathrm{d}(\mu^X\circ h)}{\mathrm{d}(P\circ h)},$$

where the derivatives are Radon-Nikodym derivatives of measures.

#### Conditional expectation with respect to a random variable

#### [edit]

Consider, in addition to the above,

The conditional expectation of X given Y is defined by applying the above construction on the  $\sigma$ -algebra generated by Y:

$$\mathrm{E}[X \mid Y] := \mathrm{E}[X \mid \sigma(Y)].$$

By the Doob-Dynkin lemma, there exists a measurable function

$$e_X \colon U o \mathbb{R}^n$$

such that

$$\mathrm{E}[X\mid Y]=e_X(Y).$$

° The definition of

$$\mathrm{E}(X \mid \mathcal{H})$$

may resemble that of

$$E(X \mid H)$$

for an event

but these are very different objects. The former is a

 $\mathcal{H}$ 

-measurable function

$$\Omega o \mathbb{R}^n$$

, while the latter is an element of

This is not a constructive definition; we are merely given the required property that a conditional expectation must satisfy.

![](_page_15_Picture_0.jpeg)

and

$$\mathrm{E}(X\mid H)\;P(H)=\int_{H}X\,\mathrm{d}P=\int_{H}\mathrm{E}(X\mid \mathcal{H})\,\mathrm{d}P$$

for

$$H\in\mathcal{H}$$

•

Often, one would like to think of

$$\mathrm{E}(X\mid\mathcal{H})$$

as a measure on

O

for fixed H. For example, it is extremely useful to claim that

$$\sum_i \mathrm{E}(X_i \mid \mathcal{H})$$

is additive for almost all H. However, this does not immediately follow because each

$$\mathrm{E}(X_i \mid \mathcal{H})$$

may have a different null set. Because countable unions of null sets are null sets, for a <u>countable set</u> of

$$X_i$$

, one can choose "versions" of each

$$\mathrm{E}(X_i \mid \mathcal{H})$$

with aligned null sets as to maintain additivity for almost all H. However, to align the "null sets of dysfunction" of

$$\mathrm{E}(X_i\mid \mathcal{H})$$

over all possible

$$X_i$$

, and thus treat

$$\mathrm{E}(X \mid \mathcal{H} = H)$$

as an almost surely unique measure over

Ω

(a "regular probability measure"), we need further regularity

<sup>&</sup>lt;sup>°</sup> Uniqueness can be shown to be <u>almost sure</u>: that is, versions of the same conditional expectation will only differ on a set of probability zero.

··· -- o----- r-------------------------

conditions. Intuitively, to do this, we need to be able to approximate all possible

$$X_i$$

with a countable set of them. This directly corresponds to the conditions for creating a regular probability measure, which are separability and completeness.

• The  $\sigma$ -algebra

$$\mathcal{H}$$

controls the "granularity" of the conditioning. A conditional expectation

$$E(X \mid \mathcal{H})$$

over a finer (larger)  $\sigma$ -algebra

$$\mathcal{H}$$

retains information about the probabilities of a larger class of events. A conditional expectation over a coarser (smaller)  $\sigma$ -algebra averages over more events.

#### Conditional probability

#### [edit]

For a Borel subset B in

$$\mathcal{B}(\mathbb{R}^n)$$

, one can consider the collection of random variables

$$\kappa_{\mathcal{H}}(\omega,B) := \mathrm{E}(1_{X \in B} | \mathcal{H})(\omega).$$

It can be shown that they form a Markov kernel, that is, for almost all

![](_page_16_Picture_18.jpeg)

 $\kappa_{\mathcal{H}}(\omega, -)$ 

is a probability measure.

The Law of the unconscious statistician is then

$$\mathrm{E}[f(X)\mid \mathcal{H}] = \int f(x) \kappa_{\mathcal{H}}(-,\mathrm{d}x),$$

This shows that conditional expectations are, like their unconditional counterparts, integrations, against a conditional measure.

In full generality, consider:

## The conditional expectation of

X

given

 $\mathcal{H}$ 

is the up to a

[Image]  $oldsymbol{P}$ 

-nullset unique and integrable

E

-valued

 $\mathcal{H}$ 

-measurable random variable

$$\mathrm{E}(X \mid \mathcal{H})$$

satisfying

$$\int_H \mathrm{E}(X\mid \mathcal{H})\,\mathrm{d}P = \int_H X\,\mathrm{d}P$$

for all

$$H\in \mathcal{H}$$

.

In this setting the conditional expectation is sometimes also denoted in operator notation as

$$\mathbf{E}^{\mathcal{H}} X$$

.

All the following formulas are to be understood in an almost sure sense.

• Pulling out independent factors:

.

• Stability:

•

\* Pulling out known factors:

 $^{\circ}$  If Z is a random variable, then

$$\mathrm{E}(f(Z)Y\mid Z) = f(Z)\,\mathrm{E}(Y\mid Z)$$

.

\* Law of total expectation:

$$E(E(X \mid \mathcal{H})) = E(X)$$

.

• Tower property:

\* Linearity: we have

[Image]

$$E(X_1 + X_2 \mid \mathcal{H}) = E(X_1 \mid \mathcal{H}) + E(X_2 \mid \mathcal{H})$$

and

$$E(aX \mid \mathcal{H}) = a E(X \mid \mathcal{H})$$

for

[Image]

 $a\in \mathbb{R}$ 

• Positivity: If

$$X \geq 0$$

then

$$E(X \mid \mathcal{H}) \geq 0$$

.

Monotonicity: If

$$X_1 < X_2$$

then

$$E(X_1 \mid \mathcal{H}) \leq E(X_2 \mid \mathcal{H})$$

.

Monotone convergence: If

$$0 < X_n \uparrow X$$

then

$$E(X_n \mid \mathcal{H}) \uparrow E(X \mid \mathcal{H})$$

.

\* Dominated convergence: If

$$X_n o X$$

and

$$|X_n| \leq Y$$

with

$$Y \in L^1$$

, then

$$E(X_n \mid \mathcal{H}) \to E(X \mid \mathcal{H})$$

.

• Fatou's lemma: If

$$E(\inf_n X_n \mid \mathcal{H}) > -\infty$$

then

$$E(\liminf_{n o \infty} X_n \mid \mathcal{H}) \leq \liminf_{n o \infty} E(X_n \mid \mathcal{H})$$

.

• Jensen's inequality: If

$$f:\mathbb{R} o\mathbb{R}$$

is a convex function, then

$$f(E(X \mid \mathcal{H})) \leq E(f(X) \mid \mathcal{H})$$

٠

- <u>Conditional variance</u>: Using the conditional expectation we can define, by analogy with the definition of the <u>variance</u> as the mean square deviation from the average, the conditional variance
- \* Martingale convergence: For a random variable

, that has finite expectation, we have

$$E(X \mid \mathcal{H}_n) \to E(X \mid \mathcal{H})$$

, if either

$$\mathcal{H}_1 \subset \mathcal{H}_2 \subset \cdots$$

is an increasing series of sub- $\sigma$ -algebras and

$$\mathcal{H} = \sigma(\bigcup_{n=1}^{\infty} \mathcal{H}_n)$$

or if

$$\mathcal{H}_1 \supset \mathcal{H}_2 \supset \cdots$$

is a decreasing series of sub-a-algebras and

is a accreasing series or sub-o-argebras and

$$\mathcal{H} = \bigcap_{n=1}^{\infty} \mathcal{H}_n$$

•

Conditional expectation as

![](_page_20_Picture_4.jpeg)

 $L^2$ 

-projection: If

are in the <u>Hilbert space</u> of <u>square-integrable</u> real random variables (real random variables with finite second moment) then

Conditioning is a contractive projection of  $L^p$  spaces

$$L^p(\Omega,\mathcal{F},P) o L^p(\Omega,\mathcal{H},P)$$

. I.e.,

$$\mathrm{E}\left(|\mathrm{E}(X\mid\mathcal{H})|^{p}
ight)\leq\mathrm{E}\left(|X|^{p}
ight)$$

for any  $p \ge 1$ .

Doob's conditional independence property: If

are conditionally independent given

Z

, then

$$P(X \in B \mid Y, Z) = P(X \in B \mid Z)$$

(equivalently,

$$E(1_{\{X \in B\}} \mid Y, Z) = E(1_{\{X \in B\}} \mid Z)$$

).

- Conditioning (probability)
- Disintegration theorem
- \* Doob-Dynkin lemma
- \* Factorization lemma
- Hidden Markov model
- Joint probability distribution
- Non-commutative conditional expectation
- \* Law of total cumulance (generalizes the other three)
- \* Law of total avpostation

- \* Law of total probability
- \* Law of total variance
- 1. Kolmogorov, Andrey (1933). Grundbegriffe der Wahrscheinlichkeitsrechnung (in German). Berlin: Julius Springer. p. 46.
  - <sup>°</sup> Translation: <u>Kolmogorov, Andrey</u> (1956). Foundations of the Theory of Probability (2nd ed.). New York: Chelsea. p. 53. <u>ISBN</u> 0-8284-0023-7. Archived from <u>the original</u> on 2018-09-14. Retrieved 2009-03-14.
- <sup>2.</sup> Oxtoby, J. C. (1953). <u>"Review: Measure theory, by P. R. Halmos"</u> (PDF). Bull. Amer. Math. Soc. **59** (1): 89–91. doi:10.1090/s0002-9904-1953-09662-8.
- <sup>3.</sup> J. L. Doob (1953). Stochastic Processes. <u>John Wiley & Sons</u>. <u>ISBN</u> 0-471-52369-0.
- 4. Olav Kallenberg: Foundations of Modern Probability. 2. edition. Springer, New York 2002, <u>ISBN</u> 0-387-95313-2, p. 573.
- <sup>5.</sup> "probability Intuition behind Conditional Expectation". Mathematics Stack Exchange.
- 6. Brockwell, Peter J. (1991). Time series: theory and methods (2nd ed.). New York: Springer-Verlag. ISBN 978-1-4419-0320-4.
- 7. Hastie, Trevor (26 August 2009). The elements of statistical learning: data mining, inference, and prediction (PDF) (Second, corrected 7th printing ed.). New York. <u>ISBN</u> 978-0-387-84858-7.{{cite book}}: CS1 maint: location missing publisher (<u>link</u>)
- 8. <u>Billingsley, Patrick</u> (1995). "Section 34. Conditional Expectation". Probability and Measure (3rd ed.). John Wiley & Sons. p. 445. <u>ISBN</u> 0-471-00710-2.
- 9. Klenke, Achim (30 August 2013). Probability theory: a comprehensive course (Second ed.). London. <u>ISBN</u> 978-1-4471-5361-0.{{cite book}}: CS1 maint: location missing publisher (<u>link</u>)
- <sup>10.</sup> Da Prato, Giuseppe; Zabczyk, Jerzy (2014). Stochastic Equations in Infinite Dimensions. Cambridge University Press. p. 26. <u>doi:10.1017/CBO9781107295513</u>. <u>ISBN 978-1-107-05584-1</u>. (Definition in separable Banach spaces)
- 11. Hytönen, Tuomas; van Neerven, Jan; Veraar, Mark; Weis, Lutz (2016). Analysis in Banach Spaces, Volume I: Martingales and Littlewood-Paley Theory. Springer Cham. doi:10.1007/978-3-319-48520-1. ISBN 978-3-319-48519-5. (Definition in general Banach spaces)
- 12. "Conditional expectation". www.statlect.com. Retrieved 2020-09-11.
- <sup>13.</sup> Kallenberg, Olav (2001). Foundations of Modern Probability (2nd ed.). York, PA, USA: Springer. p. 110. ISBN 0-387-95313-2.
  - \* William Feller, An Introduction to Probability Theory and its Applications, vol 1, 1950, page 223
  - Paul A. Meyer, *Probability and Potentials*, Blaisdell Publishing Co., 1966, page 28

Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Colonia Coloni

<u>Grimmett, Geoffrey</u>; Stirzaker, Davia (2001). Probability and Kanaom Processes (3rd ed.). Oxford University Press. <u>ISBN</u> 0-19-857222-0., pages 67–69

\* Ushakov, N.G. (2001) [1994], "Conditional mathematical expectation", Encyclopedia of Mathematics, EMS Press