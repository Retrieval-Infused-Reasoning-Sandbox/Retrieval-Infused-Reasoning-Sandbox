## Law of total expectation

Contributors to Wikimedia projects

From Wikipedia, the free encyclopedia

The proposition in <u>probability theory</u> known as the **law of total expectation**, the **law of iterated expectations** (**LIE**), **Adam's law**, the **tower rule**, and the **smoothing property of conditional expectation**, among other names, states that if

X

is a random variable whose expected value

[Image]  $\mathrm{E}(X)$ 

is defined, and

 $\boldsymbol{Y}$ 

is any random variable on the same probability space, then

$$\mathrm{E}(X) = \mathrm{E}(\mathrm{E}(X \mid Y)),$$

i.e., the expected value of the conditional expected value of

X

given

Y

is the same as the expected value of

X

.

The conditional expected value

[Image]

, with

Y

a random variable, is not a simple number; it is a random variable whose value depends on the value of

Y

. That is, the conditional expected value of

X

given the event

$$Y = y$$

is a number and it is a function of

[Image]

y

. If we write

g(y)

for the value of

[Image]

 $\mathrm{E}(X\mid Y=y)$ 

then the random variable

[Image]

 $\mathrm{E}(X \mid Y)$ 

is

g(Y)

•

One special case states that if

$$\{A_i\}$$

is a finite or countable partition of the sample space, then

$$\mathrm{E}(X) = \sum_i \mathrm{E}(X \mid A_i) \, \mathrm{P}(A_i).$$

Suppose that only two factories supply light bulbs to the market. Factory

's bulbs work for an average of 5000 hours, whereas factory

Y

's bulbs work for an average of 4000 hours. It is known that factory

supplies 60% of the total bulbs available. What is the expected length of time that a purchased bulb will work for?

Applying the law of total expectation, we have:

$$\mathrm{E}(L) = \mathrm{E}(L \mid X) \, \mathrm{P}(X) + \mathrm{E}(L \mid Y) \, \mathrm{P}(Y)$$
  
= 5000(0.6) + 4000(0.4)  
= 4600

where

Thus each purchased light bulb has an expected lifetime of 4600 hours.

When a joint <u>probability density function</u> is <u>well defined</u> and the expectations are integrable, we write for the general case

$$egin{aligned} \mathrm{E}(X) &= \int x \Pr[X=x] \; dx \ &\mathrm{E}(X \mid Y=y) = \int x \Pr[X=x \mid Y=y] \; dx \ &\mathrm{E}(\mathrm{E}(X \mid Y)) = \int \left( \int x \Pr[X=x \mid Y=y] \; dx 
ight) \Pr[Y=y] \; dy \ &= \int \int x \Pr[X=x,Y=y] \; dx \; dy \end{aligned}$$

$$egin{aligned} &= \int x \left( \int \Pr[X=x,Y=y] \; dy 
ight) \; dx \ &= \int x \Pr[X=x] \; dx \ &= \mathrm{E}(X) \, . \end{aligned}$$

A similar derivation works for discrete distributions using summation instead of integration. For the specific case of a partition, give each cell of the partition a unique label and let the random variable *Y* be the function of the sample space that assigns a cell's label to each point in that cell.

## Proof in the general case

[edit]

Let

 $(\Omega, \mathcal{F}, P)$ 

be a probability space on which two sub  $\sigma$ -algebras

$$\mathcal{G}_1 \subseteq \mathcal{G}_2 \subseteq \mathcal{F}$$

are defined. For a random variable

X

on such a space, the smoothing law states that if

$$\mathrm{E}[X]$$

is defined, i.e.

![](_page_3_Picture_13.jpeg)

, then

$$\mathrm{E}[\mathrm{E}[X\mid \mathcal{G}_2]\mid \mathcal{G}_1] = \mathrm{E}[X\mid \mathcal{G}_1] \quad ext{(a.s.)}.$$

**Proof.** Since a conditional expectation is a <u>Radon–Nikodym derivative</u>, verifying the following two properties establishes the smoothing law:

The first of these properties holds by definition of the conditional expectation. To prove the second one,

$$egin{split} \min\left(\int_{G_1} X_+ \, d\operatorname{P}, \int_{G_1} X_- \, d\operatorname{P}
ight) &\leq \min\left(\int_{\Omega} X_+ \, d\operatorname{P}, \int_{\Omega} X_- \, d\operatorname{P}
ight) \ &= \min(\operatorname{E}[X_+], \operatorname{E}[X_-]) < \infty, \end{split}$$

so the integral

$$\int_{G_1} X dP$$

is defined (not equal

$$\infty - \infty$$

).

The second property thus holds since

$$G_1 \in \mathcal{G}_1 \subseteq \mathcal{G}_2$$

implies

$$\int_{G_1} \mathrm{E}[\mathrm{E}[X\mid \mathcal{G}_2]\mid \mathcal{G}_1]\,d\,\mathrm{P} = \int_{G_1} \mathrm{E}[X\mid \mathcal{G}_2]\,d\,\mathrm{P} = \int_{G_1} X\,d\,\mathrm{P}.$$

Corollary. In the special case when

$$\mathcal{G}_1 = \{\emptyset, \Omega\}$$

and

$$\mathcal{G}_2 = \sigma(Y)$$

, the smoothing law reduces to

$$\mathrm{E}[\mathrm{E}[X\mid Y]] = \mathrm{E}[X].$$

## Alternative proof for

$$E[E[X \mid Y]] = E[X].$$

This is a simple consequence of the measure-theoretic definition of <u>conditional</u> expectation. By definition,

$$\mathrm{E}[X\mid Y]:=\mathrm{E}[X\mid \sigma(Y)]$$

is a

$$\sigma(Y)$$

-measurable random variable that satisfies

$$\int_A \mathrm{E}[X \mid Y] \, d\, \mathrm{P} = \int_A X \, d\, \mathrm{P},$$

for every measurable set

$$A \in \sigma(Y)$$

. Taking

$$A = \Omega$$

proves the claim.

<sup>\*</sup> The fundamental theorem of poker for one practical application.

- Law of total probability
- Law of total variance
- Law of total covariance
- Law of total cumulance
- <u>Product distribution#expectation</u> (application of the Law for proving that the product expectation is the product of expectations)
- <sup>1.</sup> Weiss, Neil A. (2005). A Course in Probability. Boston: Addison–Wesley. pp. 380–383. <u>ISBN</u> 0-321-18954-X.
- <sup>2.</sup> "Law of Iterated Expectation | Brilliant Math & Science Wiki". brilliant.org.
  Retrieved 2018-03-28.
- 3. "Adam's and Eve's Laws". Adam and Eve's laws (Shiny app). 2024-09-15. Retrieved 2022-09-15.
- <sup>4.</sup> Rhee, Chang-han (Sep 20, 2011). <u>"Probability and Statistics"</u> (PDF). Archived from the original (PDF) on March 26, 2023. Retrieved March 28, 2018.
- <sup>5</sup>· Wolpert, Robert (November 18, 2010). "Conditional Expectation" (PDF).
  - \* Billingsley, Patrick (1995). Probability and measure. New York: John Wiley & Sons. <u>ISBN</u> 0-471-00710-2. (Theorem 34.4)
  - Christopher Sims, "Notes on Random Variables, Expectations, Probability
     Densities, and Martingales", especially equations (16) through (18)