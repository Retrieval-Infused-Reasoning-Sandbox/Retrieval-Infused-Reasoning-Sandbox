## Measuring the speed of scalar induced gravitational waves from observations

Jun Li1, 2, [∗](#page-0-0) and Guang-Hai Guo1, [†](#page-0-1) <sup>1</sup>School of Mathematics and Physics, Qingdao University of Science and Technology, Qingdao 266061, China <sup>2</sup>CAS Key Laboratory of Theoretical Physics, Institute of Theoretical Physics, Chinese Academy of Sciences, Beijing 100190, China (Dated: December 11, 2023)

We investigate the scalar induced gravitational waves which propagate with a speed different from the speed of light. First, we analytically calculate the expression of the power spectrum of the scalar induced gravitational waves which is based on the speed and the spectrum of the primordial curvature perturbations. Then, we discuss several scalar power spectra and obtain corresponding fractional energy density, such as the monochromatic power spectrum, the scale invariant power spectrum and the power-law power spectrum. Finally, we constrain the scalar induced gravitational waves and evaluate the signatures of the speed from the combination of CMB+BAO and gravitational waves observations. The numerical results are obvious to reveal the influence of speed of scalar induced gravitational waves.

#### I. INTRODUCTION

Since the discovery of temperature anisotropies in the cosmic microwave background (CMB), it becomes significant to study the early universe and the cosmological evolution [\[1–](#page-10-0)[4\]](#page-10-1). We are interested in scalar perturbations to the metric since these couple to the density of matter and radiation and ultimately are responsible for most of the inhomogeneities and anisotropies in the universe. Inflation also generates tensor fluctuations in the metric, so-called gravitational waves. The scalar and tensor modes are decoupled in the first order of perturbation. Primordial gravitational waves are not couple to the density and so are not responsible for the large-scale structure of the universe, but they do induce fluctuations in the CMB [\[5–](#page-10-2)[19\]](#page-11-0). The theoretical first-order approximation from perturbations has been revealed through the CMB observations which include the Wilkinson Microwave Anisotropy Probe (WMAP) [\[20\]](#page-11-1), the Planck satellite [\[21\]](#page-11-2), the BICEP and Keck array (BK) [\[22\]](#page-11-3), and the Baryon Acoustic Oscillation (BAO) [\[23–](#page-11-4)[25\]](#page-11-5).

However, the rapid developments of the cosmological observations inspire us considering the deviation from the firstorder approximation. The curvature perturbations couple to the tensor perturbations at second order which produce the scalar induced gravitational waves in the radiation dominated era [\[26](#page-11-6)[–72\]](#page-12-0). The gravitational waves detections provide the latest way to find scalar induced gravitational waves which include Laser Interferometer Gravitationalwave Observatory (LIGO) and Virgo detector [\[73–](#page-12-1)[75\]](#page-12-2), Laser Interferometer Space Antenna (LISA) detector [\[76\]](#page-12-3), International Pulsar Timing Array (IPTA) [\[77\]](#page-12-4), Five-hundred-meter Aperture Spherical radio Telescope (FAST) [\[78,](#page-12-5) [79\]](#page-12-6) and Square Kilometer Array (SKA) [\[79\]](#page-12-6). IPTA is the combination of three Pulsar Timing Array (PTA) projects [\[80\]](#page-12-7), namely European Pulsar Timing Array (EPTA) [\[81\]](#page-12-8), Parkes Pulsar Timing Array (PPTA) [\[82\]](#page-12-9) and North American Observatory for Gravitational Waves (NANOGrav) [\[83\]](#page-12-10). If there is no detection of scalar induced gravitational waves from SKA project, the scalar amplitude A<sup>s</sup> and the spectral index n<sup>s</sup> of the power-law spectrum are smaller than the constraints from CMB+BAO data which have introduced in our previous work [\[26\]](#page-11-6). The upper limits of scalar induced gravitational waves from SKA project have given better constraints, while the influence of nontrivial speed of scalar induced gravitational waves is also significant.

The nontrivial speed of gravitational waves is a fundamental issue on the propagation of gravitational waves. In general relativity, gravitational waves propagate at the speed of light. When gravitational waves propagate with a speed different from the speed of light at large scales, this scenario would arise a variety of modified gravity theories. Probing the speed of gravitational waves is an important way to explore modified gravity theories and underlying new physics. The nontrivial speed has been considered through primordial gravitational waves [\[5–](#page-10-2)[10\]](#page-10-3), while the research on the speed of scalar induced gravitational waves are less which need more attention. Although the scalar induced gravitational waves are suppressed by the square of curvature perturbations, but they can compare with primordial

<span id="page-0-1"></span><span id="page-0-0"></span><sup>∗</sup>Electronic address: [lijun@qust.edu.cn](mailto:lijun@qust.edu.cn) †Electronic address: [ghguo@qust.edu.cn](mailto:ghguo@qust.edu.cn) gravitational waves if the curvature perturbations are large enough. It is worth looking forward to the signatures of the speed of scalar induced gravitational waves.

In this paper, we investigate the scalar induced gravitational waves which propagate with a speed different from the speed of light. In section 2, we analytically calculate the expression of the power spectrum of the scalar induced gravitational waves with nontrivial speed, and discuss several scalar power spectra, such as the monochromatic power spectrum, the scale invariant power spectrum and the power-law power spectrum. In section 3, we constrain the scalar induced gravitational waves and evaluate the signatures of the speed from the combination of CMB+BAO and gravitational waves observations. A brief summary will be given in section 4.

#### II. THE SCALAR INDUCED GRAVITATIONAL WAVES

In the conformal Newtonian gauge, the metric about the Friedmann-Robert-Walker background is taken as

$$ds^{2} = a^{2} \left\{ -(1+2\Phi)d\eta^{2} + \left[ (1-2\Phi)\delta_{ij} + \frac{h_{ij}}{2} \right] dx^{i} dx^{j} \right\},$$
 (1)

where  $\eta$  is the conformal time,  $a(\eta)$  is the scale factor,  $\Phi$  is the scalar perturbation and  $h_{ij}$  is the tensor perturbation. We neglect the vector perturbation, the first-order gravitational waves and the anisotropic stress. In the Fourier space, the tensor perturbation  $h_{ij}$  is

$$h_{ij}(\eta, \mathbf{x}) = \int \frac{\mathrm{d}^3 k}{(2\pi)^{3/2}} \left( e_{ij}^+(\mathbf{k}) h_{\mathbf{k}}^+(\eta) + e_{ij}^\times(\mathbf{k}) h_{\mathbf{k}}^\times(\eta) \right) e^{i\mathbf{k}\cdot\mathbf{x}},\tag{2}$$

where the plus and cross polarization tensors are

$$e_{ij}^{+}(\mathbf{k}) = \frac{1}{\sqrt{2}} \left( e_i(\mathbf{k}) e_j(\mathbf{k}) - \bar{e}_i(\mathbf{k}) \bar{e}_j(\mathbf{k}) \right), \quad e_{ij}^{\times}(\mathbf{k}) = \frac{1}{\sqrt{2}} \left( e_i(\mathbf{k}) \bar{e}_j(\mathbf{k}) + \bar{e}_i(\mathbf{k}) e_j(\mathbf{k}) \right), \tag{3}$$

the normalized vectors  $e_i(\mathbf{k})$  and  $\bar{e}_i(\mathbf{k})$  are orthogonal to each other and to  $\mathbf{k}$ . The tensor equation of motion for  $h_{ij}$  can be derived straightforwardly from the perturbed Einstein equation up to the second-order. The scalar perturbation couples from tensor perturbation in the second-order equation. The equation for induced gravitational waves with  $\Phi_{\mathbf{k}}$  being the source is given by

$$h_{\mathbf{k}}^{"}(\eta) + 2\mathcal{H}h_{\mathbf{k}}^{'}(\eta) + c_{g}^{2}k^{2}h_{\mathbf{k}}(\eta) = 4S_{\mathbf{k}}(\eta), \tag{4}$$

where the prime denotes derivative with respect to conformal time,  $\mathcal{H} = a'/a = aH$  is the conformal Hubble parameter, and  $c_q$  is the speed of scalar induced gravitational waves. The source term is given by

$$S_{\mathbf{k}} = \int \frac{\mathrm{d}^3 q}{(2\pi)^{3/2}} e_{ij}(\mathbf{k}) q_i q_j \left( 2\Phi_{\mathbf{q}} \Phi_{\mathbf{k} - \mathbf{q}} + \frac{4}{3(1+\omega)} \left( \mathcal{H}^{-1} \Phi_{\mathbf{q}}' + \Phi_{\mathbf{q}} \right) \left( \mathcal{H}^{-1} \Phi_{\mathbf{k} - \mathbf{q}}' + \Phi_{\mathbf{k} - \mathbf{q}} \right) \right). \tag{5}$$

We consider the Green's function method as

$$h_{\mathbf{k}}(\eta) = \frac{4}{a(\eta)} \int^{\eta} d\bar{\eta} G_{\mathbf{k}}(\eta, \bar{\eta}) a(\bar{\eta}) S_{\mathbf{k}}(\bar{\eta}), \tag{6}$$

where  $G_{\mathbf{k}}(\eta, \bar{\eta})$  satisfies the equation

$$G_{\mathbf{k}}^{"}(\eta,\bar{\eta}) + \left(c_g^2 k^2 - \frac{a^{"}(\eta)}{a(\eta)}\right) G_{\mathbf{k}}(\eta,\bar{\eta}) = \delta(\eta - \bar{\eta}). \tag{7}$$

In the Radiation dominated Universe, the solution of the Green's function is

$$G_{\mathbf{k}}(\eta, \bar{\eta}) = \frac{1}{k} \sin[c_g k(\eta - \bar{\eta})]. \tag{8}$$

The power spectrum of scalar induced gravitational waves is defined as

$$\langle h_{\mathbf{k}}(\eta) h_{\mathbf{k}'}(\eta) \rangle = \frac{2\pi^2}{k^3} \delta^{(3)}(\mathbf{k} + \mathbf{k}') \mathcal{P}_h(\eta, k), \tag{9}$$

and the fractional energy density is

$$\Omega_{\rm GW}(\eta, k) = \frac{1}{24} \left(\frac{k}{aH}\right)^2 \overline{\mathcal{P}_h(\eta, k)}.$$
 (10)

After calculation, the power spectrum of scalar induced gravitational waves takes the form

<span id="page-2-0"></span>
$$\mathcal{P}_h(\eta, k) = 4 \int_0^\infty dv \int_{|1-v|}^{1+v} du \left( \frac{4v^2 - (1+v^2 - u^2)^2}{4vu} \right)^2 I^2(v, u, x) \mathcal{P}_{\zeta}(kv) \mathcal{P}_{\zeta}(ku), \tag{11}$$

where  $\mathcal{P}_{\zeta}(k)$  is the power spectrum of the primordial curvature perturbations,  $x \equiv k\eta$ ,  $u = |\mathbf{k} - \tilde{\mathbf{k}}|/k$  and  $v = \tilde{k}/k$ . The function I(v, u, x) is defined as

$$I(v, u, x) = \int_0^x d\bar{x} \frac{a(\bar{\eta})}{a(\eta)} kG_{\mathbf{k}}(\eta, \bar{\eta}) f(v, u, \bar{x}), \tag{12}$$

where  $\bar{x} \equiv k\bar{\eta}$ , and  $f(v, u, \bar{x})$  comes from the source term

$$f(v,u,\bar{x}) = \frac{6(\omega+1)}{3\omega+5}\Phi(v\bar{x})\Phi(u\bar{x}) + \frac{6(1+3\omega)(\omega+1)}{(3\omega+5)^2} \left(\bar{x}\partial_{\bar{\eta}}\Phi(v\bar{x})\Phi(u\bar{x}) + \bar{x}\partial_{\bar{\eta}}\Phi(u\bar{x})\Phi(v\bar{x})\right) + \frac{3(1+3\omega)^2(1+\omega)}{(3\omega+5)^2}\bar{x}^2\partial_{\bar{\eta}}\Phi(v\bar{x})\partial_{\bar{\eta}}\Phi(u\bar{x}).$$

$$(13)$$

In the radiation-dominated Universe, the results are

$$f_{\rm RD}(v,u,\bar{x}) = \frac{12}{u^3 v^3 \bar{x}^6} \left( 18uv\bar{x}^2 \cos\frac{u\bar{x}}{\sqrt{3}} \cos\frac{v\bar{x}}{\sqrt{3}} + (54 - 6(u^2 + v^2)\bar{x}^2 + u^2 v^2 \bar{x}^4) \sin\frac{u\bar{x}}{\sqrt{3}} \sin\frac{v\bar{x}}{\sqrt{3}} + 2\sqrt{3}u\bar{x}(v^2\bar{x}^2 - 9) \cos\frac{u\bar{x}}{\sqrt{3}} \sin\frac{v\bar{x}}{\sqrt{3}} + 2\sqrt{3}v\bar{x}(u^2\bar{x}^2 - 9) \sin\frac{u\bar{x}}{\sqrt{3}} \cos\frac{v\bar{x}}{\sqrt{3}} \right), \tag{14}$$

$$I_{RD}(v, u, x) = \frac{3}{4u^{3}v^{3}x} \left( -\frac{4}{x^{3}} \left( uv(u^{2} + v^{2} - 3c_{g}^{2})x^{3} \sin(c_{g}x) - 3c_{g}(6 + (u^{2} + v^{2} - 3c_{g}^{2})x^{2}) \sin\frac{ux}{\sqrt{3}} \sin\frac{vx}{\sqrt{3}} \right) - 6c_{g}uvx^{2} \cos\frac{ux}{\sqrt{3}} \cos\frac{vx}{\sqrt{3}} + 6\sqrt{3}c_{g}ux \cos\frac{ux}{\sqrt{3}} \sin\frac{vx}{\sqrt{3}} + 6\sqrt{3}c_{g}vx \sin\frac{ux}{\sqrt{3}} \cos\frac{vx}{\sqrt{3}} \right) + (u^{2} + v^{2} - 3c_{g}^{2})^{2} \left( \sin(c_{g}x) \left( \operatorname{Ci} \left( \left( c_{g} - \frac{v - u}{\sqrt{3}} \right) x \right) + \operatorname{Ci} \left( \left( c_{g} + \frac{v - u}{\sqrt{3}} \right) x \right) \right) - \operatorname{Ci} \left( \left( c_{g} - \frac{v + u}{\sqrt{3}} \right) x \right) + \log \left| \frac{3c_{g}^{2} - (u + v)^{2}}{3c_{g}^{2} - (u - v)^{2}} \right| \right) + \cos(c_{g}x) \left( - \operatorname{Si} \left( \left( c_{g} - \frac{v - u}{\sqrt{3}} \right) x \right) - \operatorname{Si} \left( \left( c_{g} + \frac{v - u}{\sqrt{3}} \right) x \right) \right) + \operatorname{Si} \left( \left( c_{g} + \frac{v + u}{\sqrt{3}} \right) x \right) + \operatorname{Si} \left( \left( c_{g} - \frac{v + u}{\sqrt{3}} \right) x \right) \right).$$
 (15)

When we consider the power spectrum of scalar induced gravitational waves today, we can take the limit  $x \to \infty$  as

$$I_{\text{RD}}(v, u, x \to \infty) = \frac{3(u^2 + v^2 - 3c_g^2)}{4u^3v^3x} \left( \sin(c_g x) \left( -4uv + (u^2 + v^2 - 3c_g^2) \log \left| \frac{3c_g^2 - (u + v)^2}{3c_g^2 - (u - v)^2} \right| \right) - \pi \cos(c_g x)(u^2 + v^2 - 3c_g^2)\Theta(u + v - \sqrt{3}c_g) \right),$$

$$(16)$$

where  $\Theta(u+v-\sqrt{3}c_q)$  is the Heaviside theta function. The oscillation average is

$$\frac{I_{\text{RD}}^{2}(v, u, x \to \infty)}{I_{\text{RD}}^{2}(v, u, x \to \infty)} = \frac{1}{2} \left( \frac{3(u^{2} + v^{2} - 3c_{g}^{2})}{4u^{3}v^{3}x} \right)^{2} \left( \left( -4uv + (u^{2} + v^{2} - 3c_{g}^{2}) \log \left| \frac{3c_{g}^{2} - (u + v)^{2}}{3c_{g}^{2} - (u - v)^{2}} \right| \right)^{2} + \pi^{2} (u^{2} + v^{2} - 3c_{g}^{2})^{2} \Theta(u + v - \sqrt{3}c_{g}) \right).$$
(17)

In the  $c_g = 1$  case, the scalar induced gravitational waves propagate at the same speed as light [26–32]. In the following, we discuss some examples.

### A. The monochromatic power spectrum

The monochromatic curvature perturbations generate a delta-function-type power spectrum [28–31]

<span id="page-3-1"></span>
$$\mathcal{P}_{\zeta}(k) = A_s \delta\left(\log \frac{k}{k_*}\right),\tag{18}$$

where  $A_s$  is the scalar amplitude and  $k_*$  is the wavenumber at which the delta-function occurs. The fractional energy density becomes

$$\Omega_{\text{GW}}(\eta, k) = \frac{3A_s^2}{64} \left(\frac{4 - \bar{k}^2}{4}\right)^2 \bar{k}^2 \left(3c_g^2 \bar{k}^2 - 2\right)^2 \left(\left(4 + \left(3c_g^2 \bar{k}^2 - 2\right)\log\left|1 - \frac{4}{3c_g^2 \bar{k}^2}\right|\right)^2 + \pi^2 \left(3c_g^2 \bar{k}^2 - 2\right)^2 \Theta(2 - \sqrt{3}c_g \bar{k})\right) \Theta(2 - \bar{k}), \tag{19}$$

where  $\bar{k} \equiv k/k_*$  is the dimensionless wavenumber. In the calculation, only the mode  $u = v = \bar{k}^{-1}$  contributes to the integration in Eq. (11). The spectrum vanishes above  $k = 2k_*$  because no solutions satisfy the energy and momentum conservation. As shown in Fig. 1, signatures of the speed of scalar induced gravitational waves in the energy density fraction is obvious.

![](_page_3_Figure_7.jpeg)

<span id="page-3-0"></span>FIG. 1: The energy density fraction  $\Omega_{GW}$  of the scalar induced gravitational waves in Eq. (19) from the monochromatic power spectrum.

#### B. The scale invariant power spectrum

The scale invariant power spectrum is

<span id="page-3-3"></span>
$$\mathcal{P}_{\zeta}(k) = A_s, \tag{20}$$

which is independent of k. The fractional energy density becomes

$$\Omega_{\rm GW}(\eta, k) = Q(c_q) A_s^2, \tag{21}$$

where the overall coefficient  $Q(c_q)$  are given in Table. I.

| $c_g$    | 0.8    | 1.0    | 1.5    | 2.0    | 2.5    |
|----------|--------|--------|--------|--------|--------|
| $Q(c_g)$ | 1.1269 | 0.8211 | 0.3331 | 0.1564 | 0.0842 |

<span id="page-3-2"></span>TABLE I: The overall coefficient  $Q(c_g)$  in the energy density fraction of the scalar induced gravitational waves in Eq. (21) from the scale invariant power spectrum.

#### C. The power-law power spectrum

For a power-law scalar power spectrum

$$\mathcal{P}_{\zeta}(k) = A_s \left(\frac{k}{k_*}\right)^{n_s - 1},\tag{22}$$

the power spectrum of scalar induced gravitational waves takes the form

$$\mathcal{P}_h(\eta, k) = \frac{24Q(c_g, n_s)}{(k\eta)^2} A_s^2 \left(\frac{k}{k_*}\right)^{2(n_s - 1)},\tag{23}$$

where  $A_s$  is the scalar amplitude at the pivot scale  $k_* = 0.05 \text{ Mpc}^{-1}$ ,  $n_s$  is the scalar spectral index and  $Q(c_g, n_s)$  is the overall coefficient

$$Q(c_g, n_s) = \frac{1}{12} \int_0^\infty dv \int_{|1-v|}^{1+v} du \left( \frac{4v^2 - (1+v^2 - u^2)^2}{4vu} \right)^2 \left( \frac{3(u^2 + v^2 - 3c_g^2)}{4u^3v^3} \right)^2 \left( uv \right)^{n_s - 1}$$

$$\left( \left( -4uv + (u^2 + v^2 - 3c_g^2) \log \left| \frac{3c_g^2 - (u+v)^2}{3c_g^2 - (u-v)^2} \right| \right)^2 + \pi^2 (u^2 + v^2 - 3c_g^2)^2 \Theta(u+v-\sqrt{3}c_g) \right),$$
 (24)

which depends on  $c_g$  and  $n_s$  as Table. II. According to Planck18<sup>I</sup>+BAO constraint [21], the central value is  $n_s = 0.9665 \pm 0.0038$ . The fractional energy density becomes

<span id="page-4-1"></span>
$$\Omega_{\rm GW}(\eta, k) = Q(c_g, n_s) A_s^2 \left(\frac{k}{k_*}\right)^{2(n_s - 1)},\tag{25}$$

which corresponds to the quantity evaluated at late times during the radiation dominated era. If it is evaluated today, the present value of the energy fraction is related to the value in the radiation dominated era

$$\Omega_{\rm GW}(\eta_0, k) = \Omega_{r,0} \Omega_{\rm GW}(\eta_c, k), \tag{26}$$

where  $\Omega_{r,0} = \rho_{r,0}/\rho_0$  is the present value of the energy density fraction of radiation and  $\eta_c$  is some time after  $\Omega_{\rm GW}(\eta,k)$  has become constant.

| $c_g$ | 0.4    | 0.6    | 0.8    | 1.0    | 1.2    | 1.4    | 1.6    | 1.8    | 0.9665 |
|-------|--------|--------|--------|--------|--------|--------|--------|--------|--------|
| 0.8   | 1.356  | 1.227  | 1.149  | 1.127  | _      | 1.395  | 1.888  | 3.126  | 1.127  |
|       | 0.8182 |        |        |        |        |        |        |        | 0.8151 |
| 1.5   | 0.2165 |        |        |        |        |        |        |        | 0.3233 |
| 2.0   | I      |        | 0.1190 |        |        |        |        |        |        |
| 2.5   | 0.0312 | 0.0424 | 0.0590 | 0.0842 | 0.1257 | 0.2009 | 0.3612 | 0.7925 | 0.0792 |

<span id="page-4-0"></span>TABLE II: The overall coefficient  $Q(c_g, n_s)$  in the energy density fraction of the scalar induced gravitational waves in Eq. (25) from the power-law power spectrum.

Then, we characterize the scalar fluctuation spectrum in terms of the spectral index  $n_s$  and its first derivatives with respect to  $\ln k$  as [26]

$$\mathcal{P}_{\zeta}(k) = A_s \left(\frac{k}{k_*}\right)^{n_s - 1 + \frac{1}{2}\alpha_s \ln(k/k_*)},\tag{27}$$

where  $\alpha_s \equiv dn_s/d \ln k$  is the running of the spectral index. The power spectrum of scalar induced gravitational waves takes the form

$$\mathcal{P}_h(\eta, k) = \frac{24Q(c_g, n_s, \alpha_s, k)}{(k\eta)^2} A_s^2 \left(\frac{k}{k_*}\right)^{2\left[n_s - 1 + \frac{1}{2}\alpha_s \ln(k/k_*)\right]},\tag{28}$$

I Planck18=TTTEEE+lowE+lensing

where the overall coefficient is

$$Q(c_g, n_s, \alpha_s, k) = \frac{1}{12} \int_0^\infty dv \int_{|1-v|}^{1+v} du \left( \frac{4v^2 - (1+v^2 - u^2)^2}{4vu} \right)^2 \left( \frac{3(u^2 + v^2 - 3c_g^2)}{4u^3v^3} \right)^2$$

$$\left( \left( -4uv + (u^2 + v^2 - 3c_g^2) \log \left| \frac{3c_g^2 - (u+v)^2}{3c_g^2 - (u-v)^2} \right| \right)^2 + \pi^2 (u^2 + v^2 - 3c_g^2)^2 \Theta(u+v-\sqrt{3}c_g) \right)$$

$$\left( \frac{k}{k_*} \right)^{\frac{1}{2}\alpha_s \ln(uv)} \left( uv \right)^{n_s - 1 + \frac{1}{2}\alpha_s \ln(k/k_*)} v^{\frac{1}{2}\alpha_s \ln v} u^{\frac{1}{2}\alpha_s \ln u},$$

$$(29)$$

which depends on  $c_g$ ,  $n_s$ ,  $\alpha_s$  and k. According to Planck18+BAO constraints, the central values are  $n_s = 0.9659 \pm 0.0040$  and  $\alpha_s = -0.0041 \pm 0.0067$ . We fix  $n_s$  and  $\alpha_s$ , and obtain some overall coefficients  $Q(c_g, n_s, \alpha_s, k)$  in Table. III. The fractional energy density becomes

<span id="page-5-1"></span>
$$\Omega_{\rm GW}(\eta, k) = Q(c_g, n_s, \alpha_s, k) A_s^2 \left(\frac{k}{k_*}\right)^{2\left[n_s - 1 + \frac{1}{2}\alpha_s \ln(k/k_*)\right]}.$$
(30)

| $c_g$ $k/k_*$ | $4.09*10^{6}$ | $8.18*10^{6}$ | $2.04 * 10^{7}$ | $1.29*10^{13}$ | $5.16 * 10^{17}$ |
|---------------|---------------|---------------|-----------------|----------------|------------------|
| 0.8           | 1.127         | 1.128         | 1.128           | 1.137          | 1.147            |
| 1.0           | 0.8038        | 0.8035        | 0.8030          | 0.7975         | 0.7949           |
| 1.5           | 0.3055        | 0.3048        | 0.3039          | 0.2907         | 0.2811           |
| 2.0           | 0.1362        | 0.1356        | 0.1350          | 0.1254         | 0.1185           |
| 2.5           | 0.0704        | 0.0700        | 0.0695          | 0.0632         | 0.0586           |

<span id="page-5-0"></span>TABLE III: The overall coefficient  $Q(c_g, n_s, \alpha_s, k)$  in the energy density fraction of the scalar induced gravitational waves in Eq. (30) from the power-law power spectrum.

Furthermore, we can characterize the scalar fluctuation spectrum in terms of the spectral index  $n_s$  and its first two derivatives with respect to  $\ln k$ 

$$\mathcal{P}_{\zeta}(k) = A_s \left(\frac{k}{k_*}\right)^{n_s - 1 + \frac{1}{2}\alpha_s \ln(k/k_*) + \frac{1}{6}\beta_s (\ln(k/k_*))^2}, \tag{31}$$

where  $\beta_s \equiv d^2 n_s/d \ln k^2$  is the running of the spectral index. The power spectrum of scalar induced gravitational waves takes the form

$$\mathcal{P}_h(\eta, k) = \frac{24Q(c_g, n_s, \alpha_s, \beta_s, k)}{(k\eta)^2} A_s^2 \left(\frac{k}{k_*}\right)^{2\left[n_s - 1 + \frac{1}{2}\alpha_s \ln(k/k_*) + \frac{1}{6}\beta_s (\ln(k/k_*))^2\right]}, \tag{32}$$

where the overall coefficient is

$$Q(c_g, n_s, \alpha_s, \beta_s, k) = \frac{1}{12} \int_0^\infty dv \int_{|1-v|}^{1+v} du \left( \frac{4v^2 - (1+v^2 - u^2)^2}{4vu} \right)^2 \left( \frac{3(u^2 + v^2 - 3c_g^2)}{4u^3v^3} \right)^2 \\ \left( \left( -4uv + (u^2 + v^2 - 3c_g^2) \log \left| \frac{3c_g^2 - (u+v)^2}{3c_g^2 - (u-v)^2} \right| \right)^2 + \pi^2 (u^2 + v^2 - 3c_g^2)^2 \Theta(u+v-\sqrt{3}c_g) \right) \\ \left( \frac{k}{k_*} \right)^{\frac{1}{2}\alpha_s \ln(uv) + \frac{1}{6}\beta_s \left( (\ln v)^2 + 2\ln v \ln(k/k_*) + (\ln u)^2 + 2\ln u \ln(k/k_*) \right)} \left( uv \right)^{n_s - 1 + \frac{1}{2}\alpha_s \ln(k/k_*) + \frac{1}{6}\beta_s (\ln(k/k_*))^2} \\ v^{\frac{1}{2}\alpha_s \ln v + \frac{1}{6}\beta_s \left( (\ln v)^2 + 2\ln v \ln(k/k_*) \right)} u^{\frac{1}{2}\alpha_s \ln u + \frac{1}{6}\beta_s \left( (\ln u)^2 + 2\ln u \ln(k/k_*) \right)},$$

$$(33)$$

which depends on  $c_g$ ,  $n_s$ ,  $\alpha_s$ ,  $\beta_s$  and k. According to Planck18+BAO constraints, the central values are  $n_s = 0.9647 \pm 0.0043$ ,  $\alpha_s = 0.009 \pm 0.012$  and  $\beta_s = 0.0011 \pm 0.0099$ . We fix  $n_s$ ,  $\alpha_s$  and  $\beta_s$ , and obtain some overall coefficients  $Q(c_g, n_s, \alpha_s, \beta_s, k)$  in Table. IV. The fractional energy density becomes

<span id="page-6-1"></span>
$$\Omega_{\rm GW}(\eta, k) = Q(c_g, n_s, \alpha_s, \beta_s, k) A_s^2 \left(\frac{k}{k_*}\right)^{2\left[n_s - 1 + \frac{1}{2}\alpha_s \ln(k/k_*) + \frac{1}{6}\beta_s (\ln(k/k_*))^2\right]}.$$
(34)

| $c_g$ $k/k_*$ | $4.09*10^{6}$ | $8.18*10^{6}$ | $2.04*10^{7}$ |
|---------------|---------------|---------------|---------------|
| 0.9           | 2618.46       | 968.76        | 841.32        |
| 1.0           | 224.44        | 193.02        | 156.83        |
| 1.2           | 826.68        | 680.79        | 520.46        |
| 1.6           | 1356.45       | 1101.47       | 7950.39       |
| 2.0           | $2.35 * 10^6$ | $2.02*10^{6}$ | $1.63 * 10^6$ |

<span id="page-6-0"></span>TABLE IV: The overall coefficient  $Q(c_g, n_s, \alpha_s, \beta_s, k)$  in the energy density fraction of the scalar induced gravitational waves in Eq. (34) from the power-law power spectrum.

# III. MEASURING THE SPEED OF SCALAR INDUCED GRAVITATIONAL WAVES FROM OBSERVATIONS

We use the publicly available codes Cosmomc [84] to constrain the scalar induced gravitational waves and evaluate the signatures of the speed. In the standard  $\Lambda$ CDM model, the six parameters are the baryon density parameter  $\Omega_b h^2$ , the cold dark matter density  $\Omega_c h^2$ , the angular size of the horizon at the last scattering surface  $\theta_{\rm MC}$ , the optical depth  $\tau$ , the scalar amplitude  $A_s$  and the scalar spectral index  $n_s$ . Usually we introduce a new parameter, namely the tensor-to-scalar ratio r, to quantify the tensor amplitude  $A_t$  compared to the scalar amplitude  $A_s$  at the pivot scale:

$$r \equiv \frac{A_t}{A_s}. (35)$$

Here, we consider the power-law spectrum first. We extend the standard  $\Lambda$ CDM model by adding the tensor-to-scalar ratio r, and constrain these seven parameters from the combination of CMB<sup>II</sup>+BAO+SKA in the cases  $c_g=0.8$ ,  $c_g=1.0$ ,  $c_g=1.5$ ,  $c_g=2.0$  and  $c_g=2.5$ , respectively. Our numerical results are given in Table. V and Fig. 2.

| Parameter                        | $c_g = 0.8$                     | $c_g = 1.0$                     | $c_g = 1.5$                     | $c_g = 2.0$                     | $c_g = 2.5$                     |
|----------------------------------|---------------------------------|---------------------------------|---------------------------------|---------------------------------|---------------------------------|
| $\Omega_b h^2$                   | $0.02224^{+0.00012}_{-0.00013}$ | $0.02233 \pm 0.00013$           | $0.02241 \pm 0.00013$           | $0.02241 \pm 0.00013$           |                                 |
| $\Omega_c h^2$                   | $0.12183^{+0.00075}_{-0.00076}$ | $0.12056 \pm 0.00079$           |                                 | $0.11956 \pm 0.00093$           |                                 |
| $100	heta_{ m MC}$               | $1.04073 \pm 0.00029$           | $1.04088^{+0.00027}_{-0.00028}$ | $1.04099^{+0.00028}_{-0.00029}$ | $1.04099^{+0.00030}_{-0.00029}$ | $1.04099^{+0.00030}_{-0.00029}$ |
| au                               | $0.0428^{+0.0070}_{-0.0061}$    | $0.0505^{+0.0063}_{-0.0062}$    | $0.0565^{+0.0070}_{-0.0078}$    | $0.0565^{+0.0068}_{-0.0077}$    | $0.0566^{+0.0070}_{-0.0079}$    |
| $\ln \left( 10^{10} A_s \right)$ | $3.025^{+0.014}_{-0.013}$       | $3.038 \pm 0.013$               | $3.048^{+0.014}_{-0.015}$       | $3.048 \pm 0.014$               | $3.049^{+0.014}_{-0.015}$       |
| $n_s$                            | $0.9503^{+0.0013}_{-0.0010}$    | $0.9589^{+0.0021}_{-0.0011}$    | $0.9652 \pm 0.0037$             | $0.9653^{+0.0037}_{-0.0038}$    | $0.9653^{+0.0037}_{-0.0038}$    |
| $r_{0.05} (95\% \text{ CL})$     | < 0.034                         | < 0.035                         | < 0.037                         | < 0.037                         | < 0.037                         |

<span id="page-6-2"></span>TABLE V: The 68% limits on the cosmological parameters in the  $\Lambda$ CDM+r model from the combination of CMB+BAO+SKA in the cases  $c_g = 0.8$ ,  $c_g = 1.0$ ,  $c_g = 1.5$ ,  $c_g = 2.0$  and  $c_g = 2.5$ , respectively.

In the  $\Lambda$ CDM+r model, we see that the constraints on the cosmological parameters are affected by the speed of scalar induced gravitational waves. The subluminal case and superluminal cases are much different from the light one. After comparing  $c_g = 0.8$ ,  $c_g = 1.0$  and  $c_g = 1.5$  cases, we find that the mean values of the scalar amplitude

II CMB=Planck18+BK18

![](_page_7_Figure_1.jpeg)

<span id="page-7-0"></span>FIG. 2: The contour plots and the likelihood distributions for the cosmological parameters in the ΛCDM+r model at the 68% and 95% CL from the combination of CMB+BAO+SKA in the cases c<sup>g</sup> = 0.8, c<sup>g</sup> = 1.0, c<sup>g</sup> = 1.5, c<sup>g</sup> = 2.0 and c<sup>g</sup> = 2.5, respectively. The dashed black lines in the likelihood distributions are belong to c<sup>g</sup> = 1.0 case.

A<sup>s</sup> and spectral index n<sup>s</sup> shift to lower values when the speed of scalar induced gravitational waves become smaller. Although the differences between the subluminal case, the light case and the superluminal cases are obvious, but it is hard to distinguish three superluminal cases c<sup>g</sup> = 1.5, c<sup>g</sup> = 2.0 and c<sup>g</sup> = 2.5 in the ΛCDM+r model.

Then, we add the running of the spectral index α<sup>s</sup> and the running of the running of the spectral index β<sup>s</sup> into the ΛCDM+r model. We investigate the ΛCDM+r+α<sup>s</sup> model from the combination of CMB+BAO+SKA in the cases c<sup>g</sup> = 0.8, c<sup>g</sup> = 1.0, c<sup>g</sup> = 1.5, c<sup>g</sup> = 2.0 and c<sup>g</sup> = 2.5, respectively. Also, we explore the ΛCDM+r+αs+β<sup>s</sup> model from the combination of CMB+BAO+FAST in the cases c<sup>g</sup> = 0.9, c<sup>g</sup> = 1.0 and c<sup>g</sup> = 1.2, respectively. Our numerical results are given in Table. [VI,](#page-10-4) Table. [VII](#page-10-5) and Fig. [3](#page-8-0) to Fig. [4.](#page-9-0)

![](_page_8_Figure_1.jpeg)

<span id="page-8-0"></span>FIG. 3: The contour plots and the likelihood distributions for the cosmological parameters in the ΛCDM+r+α<sup>s</sup> model at the 68% and 95% CL from the combination of CMB+BAO+SKA in the cases c<sup>g</sup> = 0.8, c<sup>g</sup> = 1.0, c<sup>g</sup> = 1.5, c<sup>g</sup> = 2.0 and c<sup>g</sup> = 2.5, respectively. The dashed black lines in the likelihood distributions are belong to c<sup>g</sup> = 1.0 case.

In the ΛCDM+r+α<sup>s</sup> model, the signatures of speed of scalar induced gravitational waves are still obvious. When we consider the running of the spectral index αs, the index factor becomes more sensitive and the scalar amplitude becomes less sensitive to the speed of scalar induced gravitational waves. In Fig. [3,](#page-8-0) the mean values of the running of the spectral index α<sup>s</sup> shift to lower values when the speed of scalar induced gravitational waves become smaller. The differences between the subluminal case, the light case and the superluminal cases are apparent. Meanwhile, it is easy to distinguish three superluminal cases c<sup>g</sup> = 1.5, c<sup>g</sup> = 2.0 and c<sup>g</sup> = 2.5 in the ΛCDM+r+α<sup>s</sup> model. In the ΛCDM+r+αs+β<sup>s</sup> model, the cosmological parameters are less sensitive to the speed of scalar induced gravitational waves. The mean values almost maintain the same values except the running of the running of the spectral index

![](_page_9_Figure_1.jpeg)

<span id="page-9-0"></span>FIG. 4: The contour plots and the likelihood distributions for the cosmological parameters in the ΛCDM+r+αs+β<sup>s</sup> model at the 68% and 95% CL from the combination of CMB+BAO+FAST in the cases c<sup>g</sup> = 0.9, c<sup>g</sup> = 1.0 and c<sup>g</sup> = 1.2, respectively. The dashed black lines in the likelihood distributions are belong to c<sup>g</sup> = 1.0 case.

βs. It is hard to distinguish the subluminal case, the light case and the superluminal case in the ΛCDM+r+αs+β<sup>s</sup> model. From Fig. [2](#page-7-0) to Fig. [4,](#page-9-0) the speed of scalar induced gravitational waves changes the contours and likelihoods from the red ones to the black ones, blue ones which corresponding to the subluminal case, the light case and the superluminal case.

| Parameter                        | $c_g = 0.8$                   | $c_g = 1.0$                     | $c_g = 1.5$                     | $c_g = 2.0$                     | $c_g = 2.5$                   |
|----------------------------------|-------------------------------|---------------------------------|---------------------------------|---------------------------------|-------------------------------|
| $\Omega_b h^2$                   | $0.02246 \pm 0.00014$         | $0.02245 \pm 0.00014$           | $0.02243 \pm 0.00014$           | $0.02242 \pm 0.00014$           | $0.02242 \pm 0.00014$         |
| $\Omega_c h^2$                   | $0.11960 \pm 0.00093$         |                                 | $0.11956 \pm 0.00093$           | $0.11950^{+0.00094}_{-0.00093}$ | $0.11953 \pm 0.00093$         |
| $100\theta_{ m MC}$              | $1.04099 \pm 0.00029$         | $1.04100^{+0.00029}_{-0.00028}$ | $1.04100^{+0.00030}_{-0.00029}$ | $1.04099 \pm 0.00029$           |                               |
| au                               | $0.0577 \pm 0.0074$           | $0.0578^{+0.0070}_{-0.0076}$    | $0.0572^{+0.0071}_{-0.0080}$    | $0.0571 \pm 0.0073$             | $0.0567^{+0.0072}_{-0.0073}$  |
| $\ln \left( 10^{10} A_s \right)$ | $3.052^{+0.014}_{-0.016}$     | $3.052 \pm 0.014$               | $3.051^{+0.014}_{-0.016}$       | $3.050 \pm 0.015$               | $3.049^{+0.014}_{-0.015}$     |
| $n_s$                            | $0.9641^{+0.0038}_{-0.0037}$  | $0.9643 \pm 0.0038$             | $0.9648 \pm 0.0038$             | $0.9652^{+0.0038}_{-0.0039}$    | $0.9653 \pm 0.0038$           |
| $lpha_s$                         | $-0.0074_{-0.0022}^{+0.0055}$ | $-0.0062^{+0.0056}_{-0.0023}$   | $-0.0037^{+0.0070}_{-0.0031}$   | $-0.0018^{+0.0078}_{-0.0038}$   | $-0.0008^{+0.0083}_{-0.0047}$ |
| $r_{0.05}$ (95% CL)              | < 0.038                       | < 0.039                         | < 0.037                         | < 0.038                         | < 0.038                       |

TABLE VI: The 68% limits on the cosmological parameters in the  $\Lambda$ CDM+r+ $\alpha_s$  model from the combination of CMB+BAO+SKA in the cases  $c_g = 0.8$ ,  $c_g = 1.0$ ,  $c_g = 1.5$ ,  $c_g = 2.0$  and  $c_g = 2.5$ , respectively.

<span id="page-10-4"></span>

| Parameter                        | $c_g = 0.9$                     | $c_g = 1.0$                  | $c_g = 1.2$                     |
|----------------------------------|---------------------------------|------------------------------|---------------------------------|
| $\Omega_b h^2$                   | $0.02242 \pm 0.00014$           | $0.02242 \pm 0.00014$        | $0.02242 \pm 0.00014$           |
| $\Omega_c h^2$                   | $0.11941^{+0.00092}_{-0.00091}$ | $0.11941 \pm 0.00092$        |                                 |
| $100 	heta_{ m MC}$              | $1.04099 \pm 0.00029$           | $1.04099 \pm 0.00029$        | $1.04099^{+0.00028}_{-0.00029}$ |
| au                               | $0.0529^{+0.0073}_{-0.0080}$    | $0.0530^{+0.0069}_{-0.0081}$ | $0.0529_{-0.0080}^{+0.0073}$    |
| $\ln \left( 10^{10} A_s \right)$ | $3.041^{+0.015}_{-0.016}$       | $3.042^{+0.014}_{-0.016}$    | $3.041 \pm 0.015$               |
| $n_s$                            | $0.9690^{+0.0045}_{-0.0049}$    | $0.9689^{+0.0045}_{-0.0046}$ | $0.9689 \pm 0.0045$             |
| $lpha_s$                         | $-0.0063^{+0.010}_{-0.009}$     | $-0.0064^{+0.010}_{-0.009}$  | $-0.0063^{+0.010}_{-0.009}$     |
| $eta_s$                          | $-0.0219^{+0.020}_{-0.009}$     | $-0.0217^{+0.021}_{-0.010}$  | $-0.0217^{+0.020}_{-0.009}$     |
| $r_{0.05}$ (95% CL)              | < 0.037                         | < 0.037                      | < 0.037                         |

<span id="page-10-5"></span>TABLE VII: The 68% limits on the cosmological parameters in the  $\Lambda \text{CDM}+r+\alpha_s+\beta_s$  model from the combination of CMB+BAO+FAST in the cases  $c_g=0.9, c_g=1.0$  and  $c_g=1.2$ , respectively.

#### IV. SUMMARY

In this paper, we investigate the scalar induced gravitational waves which propagate with a speed different from the speed of light. First, we analytically calculate the expression of the power spectrum of the scalar induced gravitational waves which is based on the speed and the spectrum of the primordial curvature perturbations. Then, we discuss several scalar power spectra and obtain corresponding fractional energy density, such as the monochromatic power spectrum, the scale invariant power spectrum and the power-law power spectrum. Finally, we constrain the scalar induced gravitational waves and evaluate the signatures of the speed from the combination of CMB+BAO and gravitational waves observations. The numerical results are obvious to reveal the influence of speed of scalar induced gravitational waves.

**Acknowledgments**. This work is supported by Natural Science Foundation of Shandong Province (grant No. ZR2021QA073) and Research Start-up Fund of QUST (grant No. 1203043003587).

<span id="page-10-0"></span><sup>[1]</sup> A. Riotto, ICTP Lect. Notes Ser. 14 (2003), 317-413 [arXiv:hep-ph/0210162 [hep-ph]].

<sup>[2]</sup> P. Cabella and M. Kamionkowski, [arXiv:astro-ph/0403392 [astro-ph]].

<sup>[3]</sup> M. Katsuki, H. Kubotani, S. Nojiri and A. Sugamoto, Mod. Phys. Lett. A 10 (1995), 2143-2152 [arXiv:hep-th/9506072 [hep-th]].

<span id="page-10-1"></span><sup>[4]</sup> M. Zaldarriaga and U. Seljak, Phys. Rev. D 55 (1997), 1830-1840 [arXiv:astro-ph/9609170 [astro-ph]].

<span id="page-10-2"></span><sup>[5]</sup> Y. F. Cai, C. Lin, B. Wang and S. F. Yan, Phys. Rev. Lett. 126 (2021) no.7, 071303 [arXiv:2009.09833 [gr-qc]].

<sup>[6]</sup> W. Lin and M. Ishak, Phys. Rev. D 94 (2016) no.12, 123011 [arXiv:1605.03504 [astro-ph.CO]].

<sup>[7]</sup> P. Brax, S. Cespedes and A. C. Davis, JCAP **03** (2018), 008 [arXiv:1710.09818 [astro-ph.CO]].

<sup>[8]</sup> W. Giarè and F. Renzi, Phys. Rev. D **102** (2020) no.8, 083530 [arXiv:2007.04256 [astro-ph.CO]].

<sup>[9]</sup> Y. Cai, Y. T. Wang and Y. S. Piao, Phys. Rev. D **94** (2016) no.4, 043002 [arXiv:1602.05431 [astro-ph.CO]].

<span id="page-10-3"></span><sup>[10]</sup> J. M. Ezquiaga, W. Hu, M. Lagos and M. X. Lin, JCAP 11 (2021) no.11, 048 [arXiv:2108.10872 [astro-ph.CO]].

S. Dubovsky, R. Flauger, A. Starobinsky and I. Tkachev, Phys. Rev. D 81 (2010), 023523 [arXiv:0907.1658 [astro-ph.CO]].

<sup>[12]</sup> P. Campeti, E. Komatsu, D. Poletti and C. Baccigalupi, JCAP 01 (2021), 012 [arXiv:2007.04241 [astro-ph.CO]].

<sup>[13]</sup> K. Saikawa and S. Shirai, JCAP 05 (2018), 035 [arXiv:1803.01038 [hep-ph]].

- [14] J. Li and Q. G. Huang, JCAP 02 (2018), 020 [arXiv:1712.07771 [astro-ph.CO]].
- [15] J. Li and Q. G. Huang, Eur. Phys. J. C 78 (2018) no.11, 980 [arXiv:1806.01440 [astro-ph.CO]].
- [16] J. Li and Q. G. Huang, Sci. China Phys. Mech. Astron. 62 (2019) no.12, 120412 [arXiv:1906.01336 [astro-ph.CO]].
- [17] J. Li, Z. C. Chen and Q. G. Huang, Sci. China Phys. Mech. Astron. 62 (2019) no.11, 110421 [arXiv:1907.09794 [astroph.CO]].
- [18] J. Li and G. H. Guo, Mod. Phys. Lett. A 37 (2022) no.10, 2250066 [arXiv:2101.07970 [astro-ph.CO]].
- <span id="page-11-0"></span>[19] J. Li, Universe 8 (2022) no.7, 367 [arXiv:2110.14913 [astro-ph.CO]].
- <span id="page-11-1"></span>[20] E. Komatsu et al. [WMAP], Astrophys. J. Suppl. 180 (2009), 330-376 [arXiv:0803.0547 [astro-ph]].
- <span id="page-11-2"></span>[21] N. Aghanim et al. [Planck], Astron. Astrophys. 641 (2020), A6 [arXiv:1807.06209 [astro-ph.CO]].
- <span id="page-11-3"></span>[22] P. A. R. Ade et al. [BICEP and Keck], Phys. Rev. Lett. 127 (2021) no.15, 151301 [arXiv:2110.00483 [astro-ph.CO]].
- <span id="page-11-4"></span>[23] F. Beutler, C. Blake, M. Colless, D. H. Jones, L. Staveley-Smith, L. Campbell, Q. Parker, W. Saunders and F. Watson, Mon. Not. Roy. Astron. Soc. 416 (2011), 3017-3032 [arXiv:1106.3366 [astro-ph.CO]].
- [24] A. J. Ross, L. Samushia, C. Howlett, W. J. Percival, A. Burden and M. Manera, Mon. Not. Roy. Astron. Soc. 449 (2015) no.1, 835-847 [arXiv:1409.3242 [astro-ph.CO]].
- <span id="page-11-5"></span>[25] S. Alam et al. [BOSS], Mon. Not. Roy. Astron. Soc. 470 (2017) no.3, 2617-2652 [arXiv:1607.03155 [astro-ph.CO]].
- <span id="page-11-6"></span>[26] J. Li and G. H. Guo, Phys. Rev. D 107 (2023) no.4, 043536 [arXiv:2204.09237 [astro-ph.CO]].
- [27] J. Li and G. H. Guo, Eur. Phys. J. C 81 (2021) no.7, 602 [arXiv:2101.09949 [astro-ph.CO]].
- <span id="page-11-8"></span>[28] K. N. Ananda, C. Clarkson and D. Wands, Phys. Rev. D 75 (2007), 123518 [arXiv:gr-qc/0612013 [gr-qc]].
- [29] K. Inomata, M. Kawasaki, K. Mukaida, Y. Tada and T. T. Yanagida, Phys. Rev. D 95 (2017) no.12, 123510 [arXiv:1611.06130 [astro-ph.CO]].
- [30] K. Kohri and T. Terada, Phys. Rev. D 97 (2018) no.12, 123532 [arXiv:1804.08577 [gr-qc]].
- <span id="page-11-9"></span>[31] Y. Lu, Y. Gong, Z. Yi and F. Zhang, JCAP 12 (2019), 031 [arXiv:1907.11896 [gr-qc]].
- <span id="page-11-7"></span>[32] D. Baumann, P. J. Steinhardt, K. Takahashi and K. Ichiki, Phys. Rev. D 76 (2007), 084019 [arXiv:hep-th/0703290 [hep-th]].
- [33] L. Alabidi, K. Kohri, M. Sasaki and Y. Sendouda, JCAP 09 (2012), 017 [arXiv:1203.4663 [astro-ph.CO]].
- [34] L. Alabidi, K. Kohri, M. Sasaki and Y. Sendouda, JCAP 05 (2013), 033 [arXiv:1303.4519 [astro-ph.CO]].
- [35] Z. Zhou, J. Jiang, Y. F. Cai, M. Sasaki and S. Pi, Phys. Rev. D 102 (2020) no.10, 103527 [arXiv:2010.03537 [astro-ph.CO]].
- [36] Z. C. Chen, C. Yuan and Q. G. Huang, Phys. Rev. Lett. 124 (2020) no.25, 251101 [arXiv:1910.12239 [astro-ph.CO]].
- [37] C. Yuan, Z. C. Chen and Q. G. Huang, Phys. Rev. D 100 (2019) no.8, 081301 [arXiv:1906.11549 [astro-ph.CO]].
- [38] C. Yuan, Z. C. Chen and Q. G. Huang, Phys. Rev. D 101 (2020) no.4, 043019 [arXiv:1910.09099 [astro-ph.CO]].
- [39] C. Yuan, Z. C. Chen and Q. G. Huang, Phys. Rev. D 101 (2020) no.6, 063018 [arXiv:1912.00885 [astro-ph.CO]].
- [40] C. Yuan and Q. G. Huang, Phys. Lett. B 821 (2021), 136606 [arXiv:2007.10686 [astro-ph.CO]].
- [41] K. Inomata and T. Nakama, Phys. Rev. D 99 (2019) no.4, 043511 [arXiv:1812.00674 [astro-ph.CO]].
- [42] K. Inomata, K. Kohri, T. Nakama and T. Terada, Phys. Rev. D 100 (2019), 043532 [arXiv:1904.12879 [astro-ph.CO]].
- [43] K. Inomata, K. Kohri, T. Nakama and T. Terada, JCAP 10 (2019), 071 [arXiv:1904.12878 [astro-ph.CO]].
- [44] R. Jinno, T. Moroi and K. Nakayama, JCAP 01 (2014), 040 [arXiv:1307.3010 [hep-ph]].
- [45] H. Assadullahi and D. Wands, Phys. Rev. D 81 (2010), 023527 [arXiv:0907.4073 [astro-ph.CO]].
- [46] H. Assadullahi and D. Wands, Phys. Rev. D 79 (2009), 083511 [arXiv:0901.0989 [astro-ph.CO]].
- [47] R. G. Cai, S. Pi, S. J. Wang and X. Y. Yang, JCAP 05 (2019), 013 [arXiv:1901.10152 [astro-ph.CO]].
- [48] R. G. Cai, S. Pi, S. J. Wang and X. Y. Yang, JCAP 10 (2019), 059 [arXiv:1907.06372 [astro-ph.CO]].
- [49] R. g. Cai, S. Pi and M. Sasaki, Phys. Rev. Lett. 122 (2019) no.20, 201101 [arXiv:1810.11000 [astro-ph.CO]].
- [50] Y. F. Cai, C. Chen, X. Tong, D. G. Wang and S. F. Yan, Phys. Rev. D 100 (2019) no.4, 043518 [arXiv:1902.08187 [astro-ph.CO]].
- [51] W. T. Xu, J. Liu, T. J. Gao and Z. K. Guo, Phys. Rev. D 101 (2020) no.2, 023505 [arXiv:1907.05213 [astro-ph.CO]].
- [52] C. Unal, Phys. Rev. D 99 (2019) no.4, 041301 [arXiv:1811.09151 [astro-ph.CO]].
- [53] M. Giovannini, Phys. Rev. D 82 (2010), 083523 [arXiv:1008.1164 [astro-ph.CO]].
- [54] S. Matarrese, S. Mollerach and M. Bruni, Phys. Rev. D 58 (1998), 043504 [arXiv:astro-ph/9707278 [astro-ph]].
- [55] H. Noh and J. c. Hwang, Phys. Rev. D 69 (2004), 104011 [arXiv:astro-ph/0305123 [astro-ph]]
- [56] B. Osano, C. Pitrou, P. Dunsby, J. P. Uzan and C. Clarkson, JCAP 04 (2007), 003 [arXiv:gr-qc/0612108 [gr-qc]].
- [57] N. Orlofsky, A. Pierce and J. D. Wells, Phys. Rev. D 95 (2017) no.6, 063518 [arXiv:1612.05279 [astro-ph.CO]].
- [58] J. R. Espinosa, D. Racco and A. Riotto, JCAP 09 (2018), 012 [arXiv:1804.07732 [hep-ph]].
- [59] N. Bartolo, V. De Luca, G. Franciolini, M. Peloso, D. Racco and A. Riotto, Phys. Rev. D 99 (2019) no.10, 103521 [arXiv:1810.12224 [astro-ph.CO]].
- [60] Y. Tada and S. Yokoyama, Phys. Rev. D 100 (2019) no.2, 023537 [arXiv:1904.10298 [astro-ph.CO]].
- [61] Z. Q. You, Z. Yi and Y. Wu, JCAP 11 (2023), 065 [arXiv:2307.04419 [gr-qc]].
- [62] J. H. Jin, Z. C. Chen, Z. Yi, Z. Q. You, L. Liu and Y. Wu, JCAP 09 (2023), 016 [arXiv:2307.08687 [astro-ph.CO]].
- [63] H. Di and Y. Gong, JCAP 07 (2018), 007 [arXiv:1707.09578 [astro-ph.CO]].
- [64] G. Dom`enech and M. Sasaki, Phys. Rev. D 103 (2021) no.6, 063531 [arXiv:2012.14016 [gr-qc]].
- [65] J. C. Hwang, D. Jeong and H. Noh, Astrophys. J. 842 (2017) no.1, 46 [arXiv:1704.03500 [astro-ph.CO]].
- [66] K. Inomata and T. Terada, Phys. Rev. D 101 (2020) no.2, 023523 [arXiv:1912.00785 [gr-qc]].
- [67] K. Tomikawa and T. Kobayashi, Phys. Rev. D 101 (2020) no.8, 083529 [arXiv:1910.01880 [gr-qc]].
- [68] Z. Yi, Y. Gong, B. Wang and Z. h. Zhu, Phys. Rev. D 103 (2021) no.6, 063535 [arXiv:2007.09957 [gr-qc]].
- [69] G. Dom`enech, S. Pi and M. Sasaki, JCAP 08 (2020), 017 [arXiv:2005.12314 [gr-qc]].
- [70] F. Hajkarim and J. Schaffner-Bielich, Phys. Rev. D 101 (2020) no.4, 043522 [arXiv:1910.12357 [hep-ph]].
- [71] S. Pi and M. Sasaki, JCAP 09 (2020), 037 [arXiv:2005.12306 [gr-qc]].

- <span id="page-12-0"></span>[72] C. Fu, P. Wu and H. Yu, Phys. Rev. D 101 (2020) no.2, 023529 [arXiv:1912.05927 [astro-ph.CO]].
- <span id="page-12-1"></span>[73] E. Thrane and J. D. Romano, Phys. Rev. D 88 (2013) no.12, 124032 [arXiv:1310.5300 [astro-ph.IM]].
- [74] B. P. Abbott et al. [LIGO Scientific and Virgo], Phys. Rev. Lett. 118 (2017) no.12, 121101 [arXiv:1612.02029 [gr-qc]].
- <span id="page-12-2"></span>[75] B. P. Abbott et al. [LIGO Scientific and Virgo], Phys. Rev. D 100 (2019) no.6, 061101 [arXiv:1903.02886 [gr-qc]].
- <span id="page-12-3"></span>[76] C. Caprini, M. Hindmarsh, S. Huber, T. Konstandin, J. Kozaczuk, G. Nardini, J. M. No, A. Petiteau, P. Schwaller and G. Servant, et al. JCAP 04 (2016), 001 [arXiv:1512.06239 [astro-ph.CO]].
- <span id="page-12-4"></span>[77] J. P. W. Verbiest, L. Lentati, G. Hobbs, R. van Haasteren, P. B. Demorest, G. H. Janssen, J. B. Wang, G. Desvignes, R. N. Caballero and M. J. Keith, et al. Mon. Not. Roy. Astron. Soc. 458 (2016) no.2, 1267-1288 [arXiv:1602.03640 [astroph.IM]].
- <span id="page-12-5"></span>[78] R. Nan, D. Li, C. Jin, Q. Wang, L. Zhu, W. Zhu, H. Zhang, Y. Yue and L. Qian, Int. J. Mod. Phys. D 20 (2011), 989-1024 [arXiv:1105.3794 [astro-ph.IM]].
- <span id="page-12-6"></span>[79] K. Kuroda, W. T. Ni and W. P. Pan, Int. J. Mod. Phys. D 24 (2015) no.14, 1530031 [arXiv:1511.00231 [gr-qc]].
- <span id="page-12-7"></span>[80] R. w. Hellings and G. s. Downs, Astrophys. J. Lett. 265 (1983), L39-L42
- <span id="page-12-8"></span>[81] G. Desvignes et al. [EPTA], Mon. Not. Roy. Astron. Soc. 458 (2016) no.3, 3341-3380 [arXiv:1602.08511 [astro-ph.HE]].
- <span id="page-12-9"></span>[82] G. Hobbs, Class. Quant. Grav. 30 (2013), 224007 [arXiv:1307.2629 [astro-ph.IM]].
- <span id="page-12-10"></span>[83] M. A. McLaughlin, Class. Quant. Grav. 30 (2013), 224008 [arXiv:1310.0758 [astro-ph.IM]].
- <span id="page-12-11"></span>[84] A. Lewis and S. Bridle, Phys. Rev. D 66 (2002), 103511 [arXiv:astro-ph/0205436 [astro-ph]].