# Semianalytic Calculation of Gravitational Wave Spectrum Nonlinearly Induced from Primordial Curvature Perturbations

# Kazunori Kohri<sup>1</sup>,2,<sup>3</sup> and Takahiro Terada<sup>1</sup>

<sup>1</sup>Theory Center, IPNS, KEK, 1-1 Oho, Tsukuba, Ibaraki 305-0801, Japan <sup>2</sup>The Graduate University for Advanced Studies (SOKENDAI), 1-1 Oho, Tsukuba, Ibaraki 305-0801, Japan <sup>3</sup>Rudolf Peierls Centre for Theoretical Physics, The University of Oxford, 1 Keble Road, Oxford OX1 3NP, United Kingdom

#### Abstract

Whether or not the primordial gravitational wave (GW) produced during inflation is sufficiently strong to be observable, GWs are necessarily produced from the primordial curvature perturbations in the second order of perturbation. The induced GWs can be enhanced by curvature perturbations enhanced at small scales or by the presence of matter-dominated stages of the cosmological history. We analytically calculate the integral in the expression of the power spectrum of the induced GWs which is a universal part independent of the spectrum of the primordial curvature perturbations. This makes the subsequent numerical integrals significantly easy. In simple cases, we derive fully analytic formulas for the induced GW spectrum.

## 1 Introduction

Gravitational wave (GW) astronomy began after the detection of GWs by the LIGO and Virgo collaborations [\[1–](#page-22-0)[5\]](#page-23-0), and more signals or constraints are awaited for current and future precise observations. It is now important to study what we can learn about the early Universe or new physics beyond the Standard Model using GWs as probes. Currently, there is only an upper bound on the strength of the primordial GW [\[6,](#page-23-1) [7\]](#page-23-2) in terms of the tensor-to-scalar ratio, r < 0.07 (95% confidence level; Planck, BICEP2/Keck Array combined) [\[8\]](#page-23-3) at the pivot scale k = 0.05 Mpc−<sup>1</sup> , from the cosmic microwave background (CMB) observations.

Whether or not the primordial GW is observable, there exits an independent generation mechanism for GWs.[1](#page-1-0) The GWs are generated from curvature perturbations in the second order of perturbation [\[22\]](#page-24-0) although the tensor and scalar modes are decoupled in the first order of perturbation as is well known. It is true that the induced second-order GW is suppressed by the square of the curvature perturbations, but it can be sizable and can even become larger than the primordial (first-order) GW if the primordial curvature perturbations are enhanced at small scales compared to the CMB scale [\[22–](#page-24-0)[24\]](#page-24-1) or if the density perturbations grow in a matter-dominated (MD) phase of the Universe [\[25–](#page-24-2)[28\]](#page-24-3). The enhancement of the primordial curvature perturbations at small scales is realized in some models of inflation, and, in particular, motivates us to explore scenarios to produce primordial black holes (PBHs), which can explain dark matter and/or the binary black hole merger event rate; see, e.g., Refs. [\[29–](#page-24-4)[33\]](#page-24-5) and the references therein. In particular, the induced GWs are used as constraints on the PBH scenarios, and, conversely, the PBH constraints can be recast as the constraints on the induced GWs [\[23,](#page-24-6) [34–](#page-25-0)[36\]](#page-25-1). Similarly, the induced GWs can put constraints on inflation models which lead to small scale enhancement of perturbations [\[24,](#page-24-1) [28,](#page-24-3) [37\]](#page-25-2). Also, MD eras are expected in some scenarios involving heavy particles or oscillating scalar fields like an inflaton. Entropy production by the decay of such particles/fields at the end of the MD period can dilute unwanted long-lived particles like gravitinos in supersymmetric theories, which otherwise affects the CMB or big-bang nucleosynthesis (BBN). In this way, studies of induced GWs (as well as the primordial ones) are motivated by cosmology, astrophysics, and particle physics.

To calculate the power spectrum of the GW produced in the radiation-dominated (RD) Universe, we need to do multiple integrals of a highly oscillating function. Schematically,

$$\mathcal{P}_h \sim \int dk \int dk' \left( \int dt f(k, k', t) \right)^2 \mathcal{P}_{\zeta}(k) \mathcal{P}_{\zeta}(k'),$$

<span id="page-1-0"></span><sup>1</sup> Apart from the induced second-order GWs, which are the topic of this paper, there are other mechanisms of GW production in the early Universe, including those associated with preheating [\[9–](#page-23-4)[12\]](#page-23-5), phase transitions [\[13–](#page-23-6)[15\]](#page-23-7), and topological defects such as cosmic strings [\[16,](#page-23-8) [17\]](#page-23-9). In particular, it should be noted that the GWs are also produced from the primordial curvature perturbations in the subhorizon when shocks are formed [\[18\]](#page-24-7). It was reported in Ref. [\[18\]](#page-24-7) that the resultant GW power spectrum is similar to that of the induced GWs we are considering, but the frequency is lowered by P 1/2 ζ , which would affect the constraints on PBH scenarios which aim to explain the merger rate of binary black holes of around 30 solar masses. For light PBH scenarios, GWs emitted by Hawking radiation are relevant [\[19–](#page-24-8)[21\]](#page-24-9).

where  $\mathcal{P}_h$  ( $\mathcal{P}_\zeta$ ) is the power spectrum of the induced GW (primordial curvature perturbations), k and k' correspond to the momenta of the scalar source modes, t describes the time when the GW is sourced from the scalar modes (using the Green's function method), and f(k, k', t) is some oscillating function. We will shortly introduce the precise definition. This can be numerically done, but it is time consuming and sometimes obscures the underlying physics. An analytic calculation for the time integral was partially done in the pioneering paper [22], and we complete the calculation to obtain a relatively short, useful expression. An analytic formula was also obtained in Ref. [24], but we find it shows the wrong behavior for the contribution from the long-wavelength modes of the density perturbations. Once we obtain an analytic formula for the integral within the parentheses above, it is easy to take an oscillation average analytically, so the subsequent (numerical) integration with respect to the wavenumbers k and k' are greatly simplified and the calculation cost is significantly reduced.

In section 2, we review the derivation of the scalar-induced GWs basically following the conventions of Ref. [38]. In section 3, we analytically calculate the time integral, and take its oscillation average. We consider the cases of both the RD Universe and MD Universe, and we briefly discuss more general cases there and in Appendix A. For simple examples, we obtain fully analytic formulas for the power spectrum of the induced GWs. We conclude in section 4. The usage of our formulas is illustrated in Appendix B, where they are compared with future observations. As a byproduct, we derive a new BBN constraint on relativistic degrees of freedom (gravitons, in our case) in Appendix C.

### <span id="page-2-0"></span>2 Basic equations

In this section, we review the derivation of the master formula for the second-order GWs. We basically follow the conventions of Ref. [38] and extend their results so that we can use them both in a RD era and in a MD era. See also Refs. [22, 26] for the derivation.

#### 2.1 Definitions, energy density, and power spectrum

We choose the longitudinal (conformal Newtonian) gauge, and the metric reads

$$ds^{2} = g_{\mu\nu}dx^{\mu}dx^{\nu} = -a^{2}(1+2\Phi)d\eta^{2} + a^{2}\left((1-2\Psi)\delta_{ij} + \frac{1}{2}h_{ij}\right)dx^{i}dx^{j},$$
(1)

where  $\eta$  is the conformal time. We neglect the vector perturbations, the first-order GWs and the anisotropic stress, and  $\Phi = \Psi$  then follows. The effect of the difference  $\Phi - \Psi \neq 0$  was studied in Ref. [26], and it turns out to be small. With the above normalization, the second-order graviton action is

$$S = \frac{M_{\rm P}^2}{32} \int d\eta d^3x a^2 \left( h'_{ij} h'_{ij} - h_{ij,k} h_{ij,k} \right), \tag{2}$$

where  $M_{\rm P}=1/\sqrt{8\pi G}=1$  is the reduced Planck mass and primes denote the derivative with respect to the conformal time. The GW energy density  $\rho_{\rm GW}(\eta)=\int {\rm d} \ln k \rho_{\rm GW}(\eta,k)$  can be evaluated in the subhorizon as [39]

<span id="page-3-1"></span>
$$\rho_{\rm GW} = \frac{M_{\rm P}^2}{16a^2} \left\langle \overline{h_{ij,k} h_{ij,k}} \right\rangle,\tag{3}$$

where the overline denotes the oscillation average. The Fourier components of the tensor mode are introduced as usual.

$$h_{ij}(\eta, \mathbf{x}) = \int \frac{\mathrm{d}^3 k}{(2\pi)^{3/2}} \left( e_{ij}^+(\mathbf{k}) h_{\mathbf{k}}^+(\eta) + e_{ij}^\times(\mathbf{k}) h_{\mathbf{k}}^\times(\eta) \right) e^{i\mathbf{k}\cdot\mathbf{x}},\tag{4}$$

where the transverse traceless polarization tensors are defined as  $e_{ij}^+(\mathbf{k}) = \frac{1}{\sqrt{2}}(e_i(\mathbf{k})e_j(\mathbf{k}) - \bar{e}_i(\mathbf{k})\bar{e}_j(\mathbf{k}))$ and  $e_{ij}^{\times}(\mathbf{k}) = \frac{1}{\sqrt{2}}(e_i(\mathbf{k})\bar{e}_j(\mathbf{k}) + \bar{e}_i(\mathbf{k})e_j(\mathbf{k}))$ , with  $e_i(\mathbf{k})$  and  $\bar{e}_i(\mathbf{k})$  being normalized vectors orthogonal to each other and to  $\mathbf{k}$ . The dimensionless power spectrum is defined by

<span id="page-3-0"></span>
$$\langle h_{\mathbf{k}}^{\lambda}(\eta) h_{\mathbf{k}'}^{\lambda'}(\eta) \rangle = \delta_{\lambda \lambda'} \delta^{3}(\mathbf{k} + \mathbf{k}') \frac{2\pi^{2}}{k^{3}} \mathcal{P}_{h}(\eta, k), \tag{5}$$

where  $\lambda, \lambda' = +, \times$  represents the polarization index, which we omit in the following. We consider parity invariant situations so that both polarizations give the same result. The fraction of the GW energy density per logarithmic wavelength is

$$\Omega_{\rm GW}(\eta, k) = \frac{\rho_{\rm GW}(\eta, k)}{\rho_{\rm tot}(\eta)} = \frac{1}{24} \left(\frac{k}{a(\eta)H(\eta)}\right)^2 \overline{\mathcal{P}_h(\eta, k)},\tag{6}$$

where we have summed over the two polarization modes. This  $\Omega_{GW}$  is the observationally relevant quantity, and below we compute the power spectrum  $\mathcal{P}_h$ .

#### 2.2 Equations of motion

The equation of motion for the tensor mode  $h_{\mathbf{k}}(\eta)$  can be derived straightforwardly from the tensor part of the Einstein equation. In the second-order equation, squares of first-order quantities also appear. The first-order perturbations of the energy-momentum tensor can be related to the derivative of the gravitational potential  $\Phi$  via the first-order Einstein equation. Thus, one obtains the tensor equation of motion sourced by the scalar perturbations  $\Phi$ ,

$$h_{\mathbf{k}}''(\eta) + 2\mathcal{H}h_{\mathbf{k}}'(\eta) + k^2 h_{\mathbf{k}}(\eta) = 4S_{\mathbf{k}}(\eta), \tag{7}$$

where  $\mathcal{H} = aH$  is the conformal Hubble parameter, and the source term is given by

$$S_{\mathbf{k}} = \int \frac{\mathrm{d}^{3} q}{(2\pi)^{3/2}} e_{ij}(\mathbf{k}) q_{i} q_{j} \left( 2\Phi_{\mathbf{q}} \Phi_{\mathbf{k} - \mathbf{q}} + \frac{4}{3(1+w)} \left( \mathcal{H}^{-1} \Phi_{\mathbf{q}}' + \Phi_{\mathbf{q}} \right) \left( \mathcal{H}^{-1} \Phi_{\mathbf{k} - \mathbf{q}}' + \Phi_{\mathbf{k} - \mathbf{q}} \right) \right). \tag{8}$$

We have used −2H˙ = ρ + P = (1 + w)ρ = 3(1 + w)H<sup>2</sup> , where w = P/ρ is the equation-of-state parameter with P and ρ denoting pressure and energy density. The Fourier components Φ<sup>k</sup> of the gravitational potential are defined similarly to those of the tensor mode (of course without the polarization tensor). We adopt the Green's function method to solve hk(η),

<span id="page-4-0"></span>
$$a(\eta)h_{\mathbf{k}}(\eta) = 4 \int^{\eta} d\bar{\eta} G_{\mathbf{k}}(\eta, \bar{\eta}) a(\bar{\eta}) S_{\mathbf{k}}(\bar{\eta}), \tag{9}$$

where the Green's function Gk(η, η¯) is the solution of

$$G_{\mathbf{k}}''(\eta,\bar{\eta}) + \left(k^2 - \frac{a''(\eta)}{a(\eta)}\right) G_{\mathbf{k}}(\eta,\bar{\eta}) = \delta(\eta - \bar{\eta}). \tag{10}$$

The derivatives are with respect to η.

We need to know the time evolution of the source term Sk(η). The gravitational potential obeys the following equation of motion (see e.g. Ref. [\[40\]](#page-25-5)):

$$\Phi_{\mathbf{k}}^{"} + 3\mathcal{H}(1 + c_{s}^{2})\Phi_{\mathbf{k}}^{'} + (2\mathcal{H}' + (1 + 3c_{s}^{2})\mathcal{H}^{2} + c_{s}^{2}k^{2})\Phi_{\mathbf{k}} = \frac{a^{2}}{2}\tau\delta S,$$
(11)

where c 2 <sup>s</sup> and τ are defined as δP = c 2 s δρ + τ δS, with S being entropy. In the absence of entropy perturbations and using c 2 <sup>s</sup> = w, the above equation reduces to

<span id="page-4-1"></span>
$$\Phi_{\mathbf{k}}''(\eta) + \frac{6(1+w)}{(1+3w)\eta} \Phi_{\mathbf{k}}'(\eta) + wk^2 \Phi_{\mathbf{k}}(\eta) = 0.$$
 (12)

In the following, we pull out the primordial value φ<sup>k</sup> from the definition of Φ<sup>k</sup> = Φ(kη)φ<sup>k</sup> so that the transfer function Φ(kη) approaches unity well before the horizon entry. The primordial value is related to the curvature perturbation as

$$\langle \phi_{\mathbf{k}} \phi_{\mathbf{k}'} \rangle = \delta(\mathbf{k} + \mathbf{k}') \frac{2\pi^2}{k^3} \left( \frac{3 + 3w}{5 + 3w} \right)^2 \mathcal{P}_{\zeta}(k), \tag{13}$$

where w should be evaluated at time well before the horizon entry. As the above equation implies, we define the "primordial" value φ<sup>k</sup> as being well before the horizon entry but not too early so that the equation of state of the Universe at the "primordial time" is the same as that at the horizon entry.

One can compute the correlation function hSk(η)Sk<sup>0</sup>(η 0 )i by neglecting the non-Gaussianity of the primordial curvature perturbations. It involves integration with respect to the wavenumber ˜k corresponding to that of the scalar source Φk˜. It turns out to be useful to introduce the dimensionless variables u = |k − k˜|/k and v = ˜k/k. The details for this calculation can be found in Refs. [\[22,](#page-24-0) [26,](#page-24-10) [31\]](#page-24-11). After some algebra, by comparing hSk(η)Sk<sup>0</sup>(η 0 )i with the definition of Ph, one can extract the power spectrum  $\mathcal{P}_h$ ,

$$\mathcal{P}_h(\eta, k) = 4 \int_0^\infty dv \int_{|1-v|}^{1+v} du \left( \frac{4v^2 - (1+v^2 - u^2)^2}{4vu} \right)^2 I^2(v, u, x) \mathcal{P}_{\zeta}(kv) \mathcal{P}_{\zeta}(ku), \tag{14}$$

where the dimensionless combination  $x \equiv k\eta$  should not be confused with the spatial coordinate. The function I(v, u, x) is defined as

<span id="page-5-2"></span><span id="page-5-1"></span>
$$I(v, u, x) = \int_0^x d\bar{x} \frac{a(\bar{\eta})}{a(\eta)} kG_k(\eta, \bar{\eta}) f(v, u, \bar{x}), \tag{15}$$

and the source information is contained in

$$f(v, u, \bar{x}) = \frac{6(w+1)}{3w+5} \Phi(v\bar{x}) \Phi(u\bar{x}) + \frac{6(1+3w)(w+1)}{(3w+5)^2} \left( \bar{x} \partial_{\bar{\eta}} \Phi(v\bar{x}) \Phi(u\bar{x}) + \bar{x} \partial_{\bar{\eta}} \Phi(u\bar{x}) \Phi(v\bar{x}) \right) + \frac{3(1+3w)^2(1+w)}{(3w+5)^2} \bar{x}^2 \partial_{\bar{\eta}} \Phi(v\bar{x}) \partial_{\bar{\eta}} \Phi(u\bar{x}),$$
(16)

where  $\bar{x} = k\bar{\eta}$ , and we have used  $\mathcal{H} = aH = 2/((1+3w)\eta)$ . Note that the integral defining  $\mathcal{P}_h$  includes the square of a single function I(v,u,x). The integral has been recast in this form by noticing symmetries of the integrand under changes of variables as explained in Ref. [31]. This was seemingly unnoticed in the original paper [22], which makes their analytic expression so complicated. Related to this, both the integrand and the integral region are symmetric under the exchange of u and v. Taking advantage of the above form, we will calculate the function I(v,u,x) analytically in the following section.

### <span id="page-5-0"></span>3 Analytic integration

We find it useful to introduce new variables t = u + v - 1 and s = u - v to finally execute the remaining integrals. The Jacobian for this transformation is 1/2. Using these variables, the power spectrum is rewritten as

<span id="page-5-3"></span>
$$\mathcal{P}_h(\eta, k) = 2 \int_0^\infty dt \int_{-1}^1 ds \left[ \frac{t(2+t)(s^2-1)}{(1-s+t)(1+s+t)} \right]^2 I^2(v, u, x) \mathcal{P}_{\zeta}(kv) \mathcal{P}_{\zeta}(ku), \tag{17}$$

where u = (t + s + 1)/2 and v = (t - s + 1)/2, and we remind the reader of the definition  $x = k\eta$ . In the following, we give expressions of I in terms of u and v as well as t and s. We separately study the cases of a pure RD era and a pure MD era, finally discussing more realistic situations.

#### 3.1 Radiation-dominated Universe

In the RD Universe, the solution to eq. (10) for the Green's function of GW is

$$kG_{\mathbf{k}}(\eta, \bar{\eta}) = -x\bar{x}(j_0(x)y_0(\bar{x}) - y_0(x)j_0(\bar{x}))$$
  
= \sin(x - \bar{x}), (18)

where  $j_0(x)$   $(y_0(x))$  is the spherical Bessel function of the first (second) kind. The solution to eq. (12) for the gravitational potential which approaches 1 in the past  $(x \to 0)$  is

$$\Phi(x) = \frac{9}{x^2} \left( \frac{\sin(x/\sqrt{3})}{x/\sqrt{3}} - \cos(x/\sqrt{3}) \right).$$
 (19)

The factor  $1/\sqrt{3}$  is the sound speed in the RD era. The gravitational potential decays like  $x^{-2}$  at large x.

The source function f in the RD era is

$$f_{\text{RD}}(v, u, x) = \frac{12}{u^3 v^3 x^6} \left( 18uvx^2 \cos \frac{ux}{\sqrt{3}} \cos \frac{vx}{\sqrt{3}} + (54 - 6(u^2 + v^2)x^2 + u^2 v^2 x^4) \sin \frac{ux}{\sqrt{3}} \sin \frac{vx}{\sqrt{3}} + 2\sqrt{3}ux(v^2 x^2 - 9) \cos \frac{ux}{\sqrt{3}} \sin \frac{vx}{\sqrt{3}} + 2\sqrt{3}vx(u^2 x^2 - 9) \sin \frac{ux}{\sqrt{3}} \cos \frac{vx}{\sqrt{3}} \right). \quad (20)$$

This is equal to 4/3 at x=0 and decays like  $\sim 1/(uvx^2)$  at large x. The factor  $a(\bar{\eta})/a(\eta)$  in the definition of I(v,u,x) is equal to  $\bar{x}/x$  in the RD era.<sup>2</sup>

Combining this information, we calculate the integral I(v, u, x). To this end, multiple usages of the trigonometric addition theorem and integration by parts are required [22]. The result is

$$\begin{split} I_{\mathrm{RD}}(v,u,x) = & \frac{3}{4u^3v^3x} \left( -\frac{4}{x^3} \left( uv(u^2 + v^2 - 3)x^3 \sin x - 6uvx^2 \cos \frac{ux}{\sqrt{3}} \cos \frac{vx}{\sqrt{3}} \right. \right. \\ & + 6\sqrt{3}ux \cos \frac{ux}{\sqrt{3}} \sin \frac{vx}{\sqrt{3}} + 6\sqrt{3}vx \sin \frac{ux}{\sqrt{3}} \cos \frac{vx}{\sqrt{3}} - 3(6 + (u^2 + v^2 - 3)x^2) \sin \frac{ux}{\sqrt{3}} \sin \frac{vx}{\sqrt{3}} \right) \\ & + (u^2 + v^2 - 3)^2 \left( \sin x \left( \mathrm{Ci} \left( \left( 1 - \frac{v - u}{\sqrt{3}} \right) x \right) + \mathrm{Ci} \left( \left( 1 + \frac{v - u}{\sqrt{3}} \right) x \right) \right. \\ & - \mathrm{Ci} \left( \left| 1 - \frac{v + u}{\sqrt{3}} \right| x \right) - \mathrm{Ci} \left( \left( 1 + \frac{v + u}{\sqrt{3}} \right) x \right) + \log \left| \frac{3 - (u + v)^2}{3 - (u - v)^2} \right| \right) \\ & + \cos x \left( - \mathrm{Si} \left( \left( 1 - \frac{v - u}{\sqrt{3}} \right) x \right) - \mathrm{Si} \left( \left( 1 + \frac{v - u}{\sqrt{3}} \right) x \right) \end{split}$$

$$\frac{a(\bar{\eta})}{a(\eta)} = \frac{\bar{\eta}}{\eta} \left( \frac{g_*(T(\bar{\eta}))}{g_*(T(\eta))} \right)^{1/2} \left( \frac{g_{*,s}(T(\eta))}{g_{*,s}(T(\bar{\eta}))} \right)^{2/3}. \tag{21}$$

Before recombination, both numbers are the same,  $g_*(T) = g_{*,s}(T)$ , and the power is only 1/6. We neglect these factors for analytic calculations.

<span id="page-6-0"></span><sup>&</sup>lt;sup>2</sup> Precisely speaking, it involves the effective numbers of relativistic degrees of freedom,

$$+\operatorname{Si}\left(\left(1-\frac{v+u}{\sqrt{3}}\right)x\right)+\operatorname{Si}\left(\left(1+\frac{v+u}{\sqrt{3}}\right)x\right)\right),$$
 (22)

where Si and Ci functions are defined as follows:

<span id="page-7-0"></span>
$$\operatorname{Si}(x) = \int_0^x d\bar{x} \frac{\sin \bar{x}}{\bar{x}}, \qquad \operatorname{Ci}(x) = -\int_x^\infty d\bar{x} \frac{\cos \bar{x}}{\bar{x}}. \tag{23}$$

We have used the fact that

$$\int_0^x d\bar{x} \frac{\cos A\bar{x} - \cos B\bar{x}}{\bar{x}} = \operatorname{Ci}(Ax) - \log(Ax) - \operatorname{Ci}(Bx) + \log(Bx). \tag{24}$$

For small x, the leading term is independent of u and v,  $I_{RD}(v, u, x) \simeq x^2/2$ .

We are interested in the GW spectrum observed today, so let us take the late-time limit  $\eta \to \infty$  or  $x \gg 1$ :

$$I_{\text{RD}}(v, u, x \to \infty) = \frac{3(u^2 + v^2 - 3)}{4u^3v^3x} \left( \sin x \left( -4uv + (u^2 + v^2 - 3)\log \left| \frac{3 - (u + v)^2}{3 - (u - v)^2} \right| \right) -\pi (u^2 + v^2 - 3)\Theta(v + u - \sqrt{3})\cos x \right).$$
(25)

We have used  $\lim_{x\to\pm\infty} \mathrm{Si}(x) = \pm \pi/2$  and  $\lim_{x\to+\infty} \mathrm{Ci}(x) = 0$ , and the sign change of the limit of Si is the origin of the Heaviside theta function  $\Theta$  in the above expression. We can see that it redshifts like  $x^{-1} \propto a^{-1}$  in this limit. What we want to know is its oscillation average [see eq. (6)]. It is

<span id="page-7-1"></span>
$$\overline{I_{\text{RD}}^{2}(v, u, x \to \infty)} = \frac{1}{2} \left( \frac{3(u^{2} + v^{2} - 3)}{4u^{3}v^{3}x} \right)^{2} \left( \left( -4uv + (u^{2} + v^{2} - 3)\log\left| \frac{3 - (u + v)^{2}}{3 - (u - v)^{2}} \right| \right)^{2} + \pi^{2}(u^{2} + v^{2} - 3)^{2}\Theta(v + u - \sqrt{3}) \right).$$
(26)

In terms of the variables t = u + v - 1 and s = u - v,

$$\overline{I_{\text{RD}}^{2}(t,s,x\to\infty)} = \frac{288(-5+s^{2}+t(2+t))^{2}}{x^{2}(1-s+t)^{6}(1+s+t)^{6}} \left(\frac{\pi^{2}}{4}(-5+s^{2}+t(2+t))^{2}\Theta(t-(\sqrt{3}-1))\right) + \left(-(t-s+1)(t+s+1) + \frac{1}{2}(-5+s^{2}+t(2+t))\log\left|\frac{-2+t(2+t)}{3-s^{2}}\right|\right)^{2}\right).$$
(27)

These formulas are our main results.

<span id="page-7-2"></span>Let us discuss some simple examples.

#### **Example 1: Monochromatic source** Consider the monochromatic curvature perturbations,

<span id="page-8-2"></span><span id="page-8-0"></span>
$$\mathcal{P}_{\zeta}(k) = A_{\zeta} \delta(\log k / k_*), \tag{28}$$

where  $A_{\zeta}$  is the overall normalization and  $k_*$  is the wavenumber at which the power spectrum has a delta-function peak. This may be regarded as a rough approximation of a spectrum with a sharp peak. For example,  $k_*$  should be about  $3.5 \times 10^5 \,\mathrm{Mpc^{-1}}$  or  $2.7 \times 10^{-14} \,\mathrm{Mpc^{-1}}$  for PBHs produced in a RD era to explain dark matter abundance or the LIGO/Virgo binary black hole merger rate, respectively.

In this monochromatic case, the GW strength is

$$\Omega_{\text{GW}}(\eta, k) = \frac{3A_{\zeta}^{2}}{64} \left(\frac{4 - \tilde{k}^{2}}{4}\right)^{2} \tilde{k}^{2} \left(3\tilde{k}^{2} - 2\right)^{2} \\
\times \left(\pi^{2} (3\tilde{k}^{2} - 2)^{2} \Theta(2\sqrt{3} - 3\tilde{k}) + \left(4 + (3\tilde{k}^{2} - 2) \log\left|1 - \frac{4}{3\tilde{k}^{2}}\right|\right)^{2}\right) \Theta(2 - \tilde{k}), \quad (29)$$

where the dimensionless wavenumber  $\tilde{k} \equiv k/k_*$  is introduced for notational simplicity. The result of Ref. [38] is reproduced in the small  $\tilde{k}$  limit where their approximation is valid. The logarithmic singularity at  $k = (2/\sqrt{3})k_*$  ( $u + v = \sqrt{3}$ ) is due to resonant amplification: the frequency of the source term oscillation is twice that of the gravitational potential  $2 \times k_*/\sqrt{3}$ . The factor 2 appears because this is the second-order effect, and  $1/\sqrt{3}$  is the ratio between the propagating speeds of GWs and radiation. The spectrum vanishes above  $k = 2k_*$  because there are no solutions satisfying the energy and momentum conservation. Equation. (29) is shown in Figure 1.

<span id="page-8-1"></span>![](_page_8_Figure_6.jpeg)

Figure 1: The energy density fraction  $\Omega_{GW}$  of GWs produced in the RD era, eq. (29), from the monochromatic source, eq. (28).

**Example 2: Scale-invariant case** The scale-invariant power spectrum is

<span id="page-9-1"></span>
$$\mathcal{P}_{\zeta}(k) = A_{\zeta},\tag{30}$$

where  $A_{\zeta}$  is independent of k. We can do a numerical integration to obtain

$$\mathcal{P}_h(\eta, k) \simeq \frac{19.73}{(k\eta)^2} A_{\zeta}^2,$$
  $\Omega_{\text{GW}}(\eta, k) \simeq 0.8222 A_{\zeta}^2,$  (31)

where we have used  $\mathcal{H} = \eta^{-1}$  in the RD era.

**Example 3: power-law spectrum** We extend the previous case to a general power-law spectrum,

$$\mathcal{P}_{\zeta} = A_{\zeta} \left(\frac{k}{k_*}\right)^{n_s - 1},\tag{32}$$

where  $k_*$  is a reference scale and  $n_s - 1$  controls the spectral tilt. In this case,

$$\mathcal{P}_{h}(\eta, k) = \frac{24Q(n_{\rm s})}{(k\eta)^{2}} A_{\zeta}^{2} \left(\frac{k}{k_{*}}\right)^{2(n_{\rm s}-1)}, \qquad \Omega_{\rm GW}(\eta, k) = Q(n_{\rm s}) A_{\zeta}^{2} \left(\frac{k}{k_{*}}\right)^{2(n_{\rm s}-1)}, \qquad (33)$$

where examples of the overall coefficient  $Q(n_s)$  are shown in Table 1. For the central value of the Planck 2015 TT+lowP constraint,  $n_s = 0.9655 \pm 0.0062$  [41], and Q(0.9655) = 0.8149.

Too large or small  $n_{\rm s}$  makes the integral divergent.

<span id="page-9-0"></span>Table 1: The overall coefficient of the second-order GW sourced from the power-law index spectrum

| $n_{ m s}$     | 0.4    | 0.6    | 0.8    | 1.0    | 1.2    | 1.4   | 1.6   | 1.8   | 2.0   | 2.2   | 2.4   |
|----------------|--------|--------|--------|--------|--------|-------|-------|-------|-------|-------|-------|
| $Q(n_{\rm s})$ | 0.8196 | 0.7984 | 0.7956 | 0.8222 | 0.8988 | 1.074 | 1.470 | 2.478 | 5.783 | 24.77 | 708.2 |

#### 3.2 Matter-dominated Universe

The GW spectrum from the curvature perturbations in a MD Universe was studied in Refs. [26, 27], and the analytic formula for I(v, u, x) was obtained there. We also derive the formula using our conventions for self-completeness, which makes comparisons with other papers easier, and obtain fully analytic formulas of the GW power spectrum for simple examples, some of which were obtained only approximately.

In the MD Universe, the solution of eq. (10) for the Green's function of GW is

$$kG_{\mathbf{k}}(\eta, \bar{\eta}) = -x\bar{x}(j_1(x)y_1(\bar{x}) - y_1(x)j_1(\bar{x}))$$

$$= \frac{1}{x\bar{x}} \left( (1 + x\bar{x}) \sin(x - \bar{x}) - (x - \bar{x}) \cos(x - \bar{x}) \right). \tag{34}$$

For a late-time η η¯ and for a sufficiently large k, it is almost the sinusoidal functions, − 1 x¯ cos(x−x¯) and sin(x−x¯), respectively. The solution of eq. [\(12\)](#page-4-1) for the gravitational potential which is regular at x → 0 is[3](#page-10-0)

$$\Phi(x) = 1. \tag{35}$$

The source function f is

<span id="page-10-1"></span>
$$f_{\rm MD}(v, u, x) = \frac{6}{5}.$$
 (36)

Since this is constant, the function I(v, u, x) in the MD era can be much more easily obtained. The ratio a(¯η)/a(η) is now (¯x/x) 2 in the MD era. The function I(v, u, x) turns out to be

$$I_{\text{MD}}(v, u, x) = \frac{6(x^3 + 3x\cos x - 3\sin x)}{5x^3}.$$
 (37)

This asymptotes to 6/5 in the large x limit. For a small x, the leading term is 3x <sup>2</sup>/25. When we introduce the oscillation average in eq. [\(3\)](#page-3-1), we neglect the kinetic term and instead multiply the gradient term by 2. To compensate for the factor 2 for the oscillation average of the nonoscillating term, we have to multiply the correction factor by 1/2 to obtain

<span id="page-10-2"></span>
$$\overline{I^2(v, u, x \to \infty)} = \frac{18}{25}.$$
 (38)

Example 1: Monochromatic source The first example for the curvature perturbation is the monochromatic case,

$$\mathcal{P}_{\zeta}(k) = A_{\zeta} \delta\left(\log(k/k_*)\right). \tag{39}$$

The GW spectrum is obtained as

$$\Omega_{\rm GW} = \frac{3}{25} \left( \frac{k_*}{aH} \right)^2 \left( 1 - \left( \frac{k}{2k_*} \right)^2 \right)^2 A_{\zeta}^2 \Theta(2k_* - k). \tag{40}$$

Example 2: Scale-invariant case If the MD era continues eternally, the density perturbations eventually become nonlinear. Then the perturbation approach becomes invalid, so we set a cutoff scale kmax to the curvature perturbations. Actually, the integral is divergent in the pure MD era

<span id="page-10-0"></span><sup>3</sup>This heuristic derivation is actually not a proper treatment because small perturbations to the pure MD equation affect properties of its solution significantly. A proper treatment without neglecting the entropy perturbation shows the existence of the constant solution sourced by the entropy perturbation, which is a well-known fact in cosmology.

unless we introduce such a cutoff. In practice, the cutoff scale is the larger of the nonlinear scale  $k_{\rm NL}^{-1} \sim \mathcal{P}_{\zeta}^{1/4} \mathcal{H}^{-1}$  [27] (see also Appendix B) and the scale corresponding to the onset of the MD era  $k_{\rm MD}^{-1}$  (for example, the beginning of the inflaton oscillation). Thus, as a toy model, we assume a scale-invariant curvature perturbation with a cutoff  $k_{\rm max}$  [27],

<span id="page-11-2"></span><span id="page-11-0"></span>
$$\mathcal{P}_{\zeta}(k) = A_{\zeta}\Theta(k_{\text{max}} - k). \tag{41}$$

For  $0 < k \le k_{\text{max}}$ , the integration regions dictated by the Heaviside theta function are  $0 < t < \frac{2k_{\text{max}}}{k} - 2$ , -1 < s < 1 and  $\frac{2k_{\text{max}}}{k} - 2 < t < \frac{2k_{\text{max}}}{k} - 1$ ,  $t - \frac{2k_{\text{max}}}{k} + 1 < s < -(t - \frac{2k_{\text{max}}}{k} + 1)$ , while for  $k_{\text{max}} < k \le 2k_{\text{max}}$ , the integration region is  $0 < t < \frac{2k_{\text{max}}}{k} - 1$ ,  $t - \frac{2k_{\text{max}}}{k} + 1 < s < -(t - \frac{2k_{\text{max}}}{k} + 1)$ . The GW strength is

$$\Omega_{\text{GW}} = \frac{A_{\zeta}^{2}}{14000} \left(\frac{k}{aH}\right)^{2} \times \begin{cases} \left(1792\tilde{k}^{-1} - 2520 + 768\tilde{k} + 105\tilde{k}^{2}\right) & (0 < k \le k_{\text{max}}) \\ \left(1 - 2\tilde{k}^{-1}\right)^{4} \left(105\tilde{k}^{2} + 72\tilde{k} + 16 - 32\tilde{k}^{-1} - 16\tilde{k}^{-2}\right) & (k_{\text{max}} < k \le 2k_{\text{max}}) \end{cases}, \tag{42}$$

where  $\tilde{k} \equiv k/k_{\text{max}}$ . The two expressions coincide up to and including the third derivative at  $k = k_{\text{max}}$ . Equation (42) is shown as the dashed brown line in Figure 2.

Note that the power spectrum  $\mathcal{P}_h$  is enhanced by  $\tilde{k}^{-1} = k_{\text{max}}/k$  for a small k. This enhancement is due to the effect of a nondecaying scalar source,  $\Phi = \text{const.}$ , during the MD era. Taking the leading term for a small k reproduces the result in Ref. [27] up to a numerical factor.<sup>4</sup>

#### 3.3 Transitions between radiation/matter eras

So far, we have considered the pure RD and the pure MD Universe. However, the RD epoch is taken over by the late-time MD epoch. Also, an early MD era such as an inflaton oscillation period may precede the RD era. We consider these transitions, the MD era to the RD era and the RD era to the MD era, separately below. When one considers nonminimal cosmological scenarios, there may be multiple transitions. Generalization to such cases is a straightforward task.

### 3.3.1 MD-to-RD transition

We imagine a MD era dominated by some massive field which decays to reheat the Universe. After the decay, it is a RD era. We indicate the reheating time by the subscript R. Before reheating ( $x < x_R \equiv k\eta_R$ ), the function I(v, u, x) is the same as the MD case we have seen above, i.e.  $I(v, u, x) = x_R = x_R + x_R$ 

<span id="page-11-1"></span><sup>&</sup>lt;sup>4</sup> After taking into account the difference of the normalization conventions, a factor 2 is missed in the source side of their equation of motion for GW, and a geometric factor  $\cos 2\phi/\sqrt{2}$  is missed for projection to the transverse traceless mode where  $\phi$  is the angle between the polarization vector  $e(\mathbf{k})$  and the projection of the source wavenumber  $\tilde{k}$  onto the plane spanned by  $e(\mathbf{k})$  and  $\bar{e}(\mathbf{k})$ .

<span id="page-11-3"></span><sup>&</sup>lt;sup>5</sup> For this choice with  $A_{\zeta} \sim 10^{-9}$ , the nonlinear scale  $k_{\rm NL}$  comes below  $k_{\rm max}$ . The reason for this choice is to clearly show the characteristic behavior of each of the modes  $k \ll k_{\rm R}$ ,  $k_{\rm R} \ll k < k_{\rm max}$ , and  $k_{\rm max} < k$ .

<span id="page-12-0"></span>![](_page_12_Figure_0.jpeg)

Figure 2: The energy density fraction ΩGW of GWs produced in the MD era from the scale-invariant source. The brown lines (vanishing at k = 2kmax) show the case of an abrupt cutoff kmax [\(41\)](#page-11-2), which may be interpreted as the scale corresponding to the beginning of inflaton oscillation or the scale where density perturbations become nonlinear. The dashed curve represents eq. [\(42\)](#page-11-0) where reheating is not considered (the pure MD case). The effect of reheating (transition to the RD era) is included in the solid line by multiplying eq. [\(45\)](#page-13-0) for the case k<sup>R</sup> = 10−3kmax [5](#page-11-3) . These lines overlap for k kR. The above plot shows the spectra observed at late time (η ηR) scaled back in time by the common redshift factor (independent of k) in such a way that they coincide with the spectra at H = k<sup>R</sup> for modes k kR. In other words, we have taken into account the evolution of modes k k<sup>R</sup> since reheating to their horizon entry. The green line shows the case of a MD era preceded by a RD era. kmax is identified as keq. The standard radiation-matter transition corresponds to this case with keq = 1.0 × 10−<sup>2</sup> Mpc−<sup>1</sup> [\[42\]](#page-25-7). This line is obtained numerically using the interpolating transfer function [\(49\)](#page-14-0). Note that ΩGW grows during the MD era. The above plot shows the spectra at H = 10−3kmax (see footnote [5\)](#page-11-3). The pink line (horizontal dotted dashed) is the standard in the RD era [see eq. [\(31\)](#page-9-1)] shown for comparison.

IMD(v, u, x). After reheating (x > xR), we separate the time integral as follows:

<span id="page-12-1"></span>
$$I(v, u, x) = \int_{0}^{x_{\rm R}} d\bar{x} \left(\frac{x_{\rm R}}{x}\right) \left(\frac{\bar{x}}{x_{\rm R}}\right)^{2} kG_{k}^{\rm MD \to RD}(\eta, \bar{\eta}) f_{\rm MD}(v, u, \bar{x})$$
$$+ \int_{x_{\rm R}}^{x} d\bar{x} \left(\frac{\bar{x}}{x}\right) kG_{k}^{\rm RD}(\eta, \bar{\eta}) f_{\rm MD \to RD}(v, u, \bar{x}), \tag{43}$$

where the first line is the contribution from the MD era taking into account the fact that the propagation of the GW changes after reheating. The second line is the contribution from the RD era taking into account the fact that the scalar source experienced the MD era.

We may integrate it explicitly, but the expression is complicated. Here, let us focus on terms with a qualitatively new behavior, that is, a feature beyond the simple sum of the RD and MD contributions. Such a nontrivial feature resides in modes which were about to grow near the end of the MD era. These come from the first line of eq. [\(43\)](#page-12-1). We connect the GW solution at the transition requiring continuity of the zeroth and first derivatives. Then the first line becomes

$$\int_{0}^{x_{\rm R}} d\bar{x} \left(\frac{x_{\rm R}}{x}\right) \left(\frac{\bar{x}}{x_{\rm R}}\right)^{2} kG_{k}^{\rm MD\to RD}(\eta, \bar{\eta}) f_{\rm MD}(v, u, \bar{x})$$

$$= \frac{3}{5xx_{\rm R}^{3}} \left(3(2x_{\rm R}^{2} - 1)\cos x - 6x_{\rm R}\sin x + 2x_{\rm R}^{4}\cos(x - x_{\rm R}) + 4x_{\rm R}^{3}\sin(x - x_{\rm R}) + 3\cos(x - 2x_{\rm R})\right).$$
(44)

In the limit x<sup>R</sup> → x, this reduces to the pure MD case result, eq. [\(37\)](#page-10-1). On the other hand, in the limit x xR, it is approximated as (12/25)(x 2 R /x) sin x. By taking the square and oscillation average for x and dividing it by eq. [\(38\)](#page-10-2) and the common redshift factor (xR/x), we obtain the relative factor R explaining the inefficient enhancement of superhorizon modes at reheating,

<span id="page-13-1"></span><span id="page-13-0"></span>
$$R = \frac{1}{4x_{\rm R}^8} \left( \left( -6x_{\rm R} + 4x_{\rm R}^3 \cos x_{\rm R} + 2x_{\rm R}^4 \sin x_{\rm R} + 6\cos x_{\rm R} \sin x_{\rm R} \right)^2 + \left( -3 + 6x_{\rm R}^2 + 2x_{\rm R}^4 \cos x_{\rm R} + 3\cos 2x_{\rm R} - 4x_{\rm R}^3 \sin x_{\rm R} \right)^2 \right), \tag{45}$$

which reduces to one in the subhorizon limit x<sup>R</sup> 1 and is proportional to x 2 R in the superhorizon limit x<sup>R</sup> 1. Multiplying eq. [\(42\)](#page-11-0) by this factor, we obtain the brown solid line in Figure [2.](#page-12-0)

The contribution to I(v, u, x) from modes entering the horizon a bit after reheating scales like k. Squaring this and multiplying the integration region of t which scales like kmax/k, the power spectrum for this range of wavenumber behaves like P<sup>h</sup> ∼ (a(ηR)/a(η))<sup>2</sup> (kmaxk/k<sup>2</sup> R )P 2 ζ (k), where we have replaced η<sup>R</sup> ∼ k −1 <sup>R</sup> with k<sup>R</sup> ≡ H(ηR). This scaling is valid at late times η η<sup>R</sup> since we have taken the late-time limit. Note that the snapshot of the power spectrum at the time of reheating scales as k 3 , but the observed spectrum scales as k, taking into account the evolution of modes since reheating to their horizon entry. The origin of this evolution is the kinetic energy of GWs already developed at reheating. It seems that this change of scaling has not been explicitly noticed in the literature.

For shorter length scales, k<sup>R</sup> < k < kmax, it is similar to the MD case, P<sup>h</sup> ∼ (a(ηR)/a(η))<sup>2</sup> (kmax/k)P 2 ζ (k). On the other hand, for larger length scales, k < k<sup>R</sup> its with the intersection k R its ≡ kR(kR/kmax) 1/3 , it is similar to the RD case, P<sup>h</sup> ∼ (a(ηR)/a(η))<sup>2</sup> (kR/k) 2P 2 ζ (k). The common factor (a(ηR)/a(η))<sup>2</sup> represents redshift, and P 2 ζ (k) represents the source characteristics. The remaining factor represents the specific feature for the MD, RD, or intermediate era.

### 3.3.2 RD-to-MD transition

We now consider a RD era followed by a MD era denoting the equality time by the subscript eq. Before the equality (i.e. x < xeq ≡ kηeq), I(v, u, x) = IRD(v, u, x) is satisfied. After the equality, we may split the time integral for the function I(v, u, x) as follows:

<span id="page-14-1"></span>
$$I(v, u, x) = \int_{0}^{x_{\text{eq}}} d\bar{x} \left(\frac{x_{\text{eq}}}{x}\right)^{2} \left(\frac{\bar{x}}{x_{\text{eq}}}\right) kG_{k}^{\text{RD}\to\text{MD}}(\eta, \bar{\eta}) f_{\text{RD}}(v, u, \bar{x})$$

$$+ \int_{x_{\text{eq}}}^{x} d\bar{x} \left(\frac{\bar{x}}{x}\right)^{2} kG_{k}^{\text{MD}}(\eta, \bar{\eta}) f_{\text{RD}\to\text{MD}}(v, u, \bar{x}). \tag{46}$$

The first line is the contribution produced in the RD era when taking into account the fact that the GW propagation changes after the radiation-matter equality. The second line is the contribution produced in the MD era when taking into account the fact that the source term experienced the RD era.

Again, for modes entering the horizon well before equality and well after equality, the power spectrum is essentially the same as that in the RD era and in the MD era, respectively. This time, the only nontrivial terms come from the second line. The scalar modes entering the horizon a bit before equality are suppressed in the RD Universe, so, even after the enhancement in the MD era, the corresponding GW power spectrum is less enhanced compared to the modes entering the horizon after equality. Note also that this effect gives a physical cutoff for an otherwise divergent integral in the MD era. Quantitatively, this effect is explained by the large k limit of the transfer function,

$$\Phi(\eta \gg \eta_{\rm eq}, k \gg k_{\rm eq}) = \frac{\ln(c_1 k \eta_{\rm eq})}{(c_2 k \eta_{\rm eq})^2}, \quad c_1 = \frac{2}{\sqrt{3}(\sqrt{2} - 1)} e^{\gamma - \frac{7}{2}} \approx 0.15, \quad c_2 = \frac{\sqrt{9/10}}{9(\sqrt{2} - 1)} \approx 0.25. \quad (47)$$

This is a standard result: see e.g. Ref. [40]. Using this, the second line of eq. (46) becomes

$$\int_{x_{\text{eq}}}^{x} d\bar{x} \left(\frac{\bar{x}}{x}\right)^{2} kG_{k}^{\text{MD}}(\eta, \bar{\eta}) f_{\text{RD}\to\text{MD}}(v, u, \bar{x})$$

$$= \frac{(x^{3} - 3(x - x_{\text{eq}}) - xx_{\text{eq}}^{2}) \cos(x - x_{\text{eq}}) - (3 + 3xx_{\text{eq}} - x_{\text{eq}}^{2}) \sin(x - x_{\text{eq}})}{x^{3}} \times \frac{6 \ln(c_{1}ux_{\text{eq}})}{5 \frac{\ln(c_{1}ux_{\text{eq}})}{(c_{2}ux_{\text{eq}})^{2}} \frac{\ln(c_{1}vx_{\text{eq}})}{(c_{2}vx_{\text{eq}})^{2}}, (48)$$

For a late time  $\eta \gg \eta_{\rm eq}$ , the first factor asymptotes to 1, and the k dependence at large k is given just by  $\Phi^2$ , or  $k^{-4}(\ln k)^2$ . Squaring this and numerically integrating<sup>6</sup> it with respect to t and s, we find that the power spectrum scales as  $\mathcal{P}_h \sim (k\eta_{\rm eq})^{-2\gamma(k)}\mathcal{P}_{\zeta}^2(k)$  with  $3 \lesssim \gamma(k) \lesssim 4$  being an increasing function of k. This is consistent with an observation in Ref. [26]. For larger length scales,  $k < k_{\rm eq}$ , it is essentially the MD era, and  $\mathcal{P}_h \sim (k_{\rm eq}/k)\mathcal{P}_{\zeta}^2(k)$ , where  $k_{\rm max}$  has been

<span id="page-14-4"></span><span id="page-14-3"></span><span id="page-14-0"></span>
$$\Phi(\eta \gg \eta_{\rm eq}, k) = \frac{\log(1 + c_1 k \eta_{\rm eq})}{\log(1 + c_1 k \eta_{\rm eq}) + (c_2 k \eta_{\rm eq})^2}.$$
(49)

The numerical result of  $\Omega_{GW}$  using this transfer function in the case of the scale-invariant source is shown as the green solid line in Figure 2.

<span id="page-14-2"></span><sup>&</sup>lt;sup>6</sup> For this purpose, we interpolate the large k behavior of the transfer function (47) and the small k limit  $\Phi = 1$  with the following function:

replaced by the physical cutoff keq. For shorter length scales, keq < k < keq its with the intersection k eq its ≡ keq(keq/H(η))2/(γ−1), it is essentially the RD era, so P<sup>h</sup> ∼ (a(ηeq)/a(η))<sup>2</sup> (keq/k) 2P 2 ζ (k).

# <span id="page-15-0"></span>4 Summary and conclusion

Traditionally, the second-order GWs sourced from the primordial curvature perturbations have been studied mainly numerically. We have analytically calculated the part of the curvature-induced GW power spectrum I(v, u, x) [defined in eq. [\(15\)](#page-5-1)], which is calculable independently of the primordial curvature perturbations P<sup>ζ</sup> (k). One of our main results is the expression [\(22\)](#page-7-0) and its late-time oscillation average, I 2 RD(v, u, x) [eq. [\(26\)](#page-7-1)], or, equivalently in terms of the other variables, I 2 RD(t, s, x) [eq. [\(27\)](#page-7-2)]. Once the primordial curvature perturbation P<sup>ζ</sup> (k) is specified, one can easily compute the remaining integrals for u and v [eq. [\(14\)](#page-5-2)], or, equivalently, t and s [eq. [\(17\)](#page-5-3)] whose physical meaning is the wavenumber of the gravitational potential Φ.

As applications of the analytic formula, we have calculated the power spectrum of the induced GW for simple examples of the primordial curvature perturbations. This has been done numerically or fully analytically when possible. For completeness, we have also studied the second-order GWs induced in a MD era and have obtained analytic formulas for simple examples. Moreover, we have suggested an approximate way of analytically calculating the GW power spectrum in the presence of transitions between the RD and MD eras. In fact, using our formulas, we have derived the nontrivial wavenumber dependence of the induced GW power spectrum. In particular, we have analytically obtained the suppression factor [\(45\)](#page-13-0) for modes entering the horizon after reheating by assuming the sudden transition between the MD and RD eras, taking into account the growth of these modes after reheating until their horizon entry. The RD-to-MD transition can be treated numerically. In this way, the nontrivial shape of the power spectrum of the induced GWs in the presence of finite duration of the MD era, during which the GW spectrum is enhanced, is obtained (semi)analytically, as demonstrated in Figure [2](#page-12-0) for the case of the scale-invariant curvature perturbations.

Our results are useful when one quantitatively evaluates the power spectrum Ph(η, k) or the corresponding energy fraction parameter ΩGW(η, k) of the GW induced from the curvature perturbations. These quantities are to be compared with observations as illustrated in Appendix [B](#page-19-0) and Figure [3](#page-20-0) with simple examples. From Figure [3,](#page-20-0) one can see that it would be difficult to detect the induced GWs by near future observations if the curvature perturbation can be approximated as a scale-invariant one. This is so even if we assume the presence of an early MD era to enhance the induced GWs, as long as we consider the linear regime. By contrast, if the spectrum of the curvature perturbation has a sufficiently blue tilt or running, it may be possible to detect it as shown in the Figure [3.](#page-20-0) In such a case, one has to consider constraints on the enhanced curvature perturbations by µ distortion of the CMB [\[43,](#page-25-8) [44\]](#page-25-9), change of the baryon-to-photon ratio [\[45\]](#page-25-10) and the neutron-to-proton ratio [\[46\]](#page-25-11) (see also Ref. [\[47\]](#page-25-12)) in BBN, and overproduction of ultracompact minihalos [\[48,](#page-26-0) [49\]](#page-26-1) or PBHs (for reviews of the constraints, see e.g. Refs. [\[33,](#page-24-5) [50,](#page-26-2) [51\]](#page-26-3)).

### Note added

Ref. [52] appeared recently after the most parts of this paper had been completed. They derived an analytic formula of the late-time limit of the gravitational field  $h_{\mathbf{k}}(\eta)$  induced in the radiation dominated era right after inflation, from which the power spectrum as well as bispectrum can also be calculated, in the context of the Standard Model Higgs instability.

### Acknowledgments

The authors are grateful to Sachiko Kuroyanagi for reading the manuscript and for the useful discussion. TT thanks Kyohei Mukaida for explaining the conventions in Ref. [38]. This work is supported in part by the JSPS Research Fellowship for Young Scientists (TT) and JSPS KAK-ENHI Grants No. JP17J00731 (TT), No. JP17H01131 (KK), and No. 26247042 (KK), and MEXT KAKENHI Grants No. JP15H05889 (KK), No. JP16H0877 (KK), and No. JP18H04594 (KK).

## <span id="page-16-0"></span>A General integral formulas with radiation/matter transitions

In this Appendix, we provide general formulas which can be used for the calculation of I(v, u, x) in the presence of multiple RD/MD transitions. We need to consider a generalization of eqs. (43) and (46).

In general, in a RD era,  $\Phi$  can be written as a linear combination of two independent solutions,  $3j_1(x/\sqrt{3})/(x/\sqrt{3})$  and  $3y_1(x/\sqrt{3})/(x/\sqrt{3})$ . The GW solution is a linear combination of two independent solutions,  $\sin \bar{x}$  and  $\cos \bar{x}$ . On the other hand, in a MD era,  $\Phi$  can be written as a linear combination of two independent solutions, 1 and  $x^{-5}$ . (However, the power of the decaying mode changes when we perturb the pure MD case, and in any case, we neglect the decaying mode) The GW solution is a linear combination of two independent solutions,  $\bar{x}j_1(\bar{x})$  and  $\bar{x}y_1(\bar{x})$ .

For the RD case, we consider

$$\mathcal{I}_{RD}(v, u, x_1, x_2) = \int_{x_1}^{x_2} d\bar{x} \, \bar{x}(C \sin \bar{x} + D \cos \bar{x}) f_{RD}(v, u, \bar{x})|_{\Phi(\bar{x}) = 3\sqrt{3}(Aj_1(\bar{x}/\sqrt{3}) + By_1(\bar{x}/\sqrt{3}))/\bar{x}}. \quad (50)$$

For the MD case, we consider

$$\mathcal{I}_{\text{MD}}(v, u, x_1, x_2) = \int_{x_1}^{x_2} d\bar{x} \, \bar{x}^2 (C\bar{x}j_1(\bar{x}) + D\bar{x}y_1(\bar{x})) f_{\text{MD}}(v, u, \bar{x})|_{\Phi(\bar{x}) = A}, \tag{51}$$

where  $x_1 \equiv k\eta_1$  and  $x_2 \equiv k\eta_2$ , and where A, B, C, and D are constants with respect to  $\bar{\eta}$ . A and B may depend on k and  $\eta_1$ , and C and D may depend on k,  $\eta_2$ , and the present time  $\eta$ . Substituting  $\Phi$  into  $f(v, u, k, \eta)$ , A(k) becomes A(uk) or A(vk), and B behaves similarly. We show only the dependence on u and v, so we express this as A(u) and A(v).

The function f is now

$$f_{\text{RD}}(v, u, \bar{x})|_{\Phi(\bar{x}) = 3\sqrt{3}(Aj_1(\bar{x}/\sqrt{3}) + By_1(\bar{x}/\sqrt{3}))/\bar{x}} = \frac{1}{u^3v^3\bar{x}^6} \left( E^{\cos, v - u} \cos \frac{(v - u)\bar{x}}{\sqrt{3}} + E^{\sin, v - u} \sin \frac{(v - u)\bar{x}}{\sqrt{3}} + E^{\cos, v + u} \cos \frac{(v + u)\bar{x}}{\sqrt{3}} + E^{\sin, v + u} \sin \frac{(v + u)\bar{x}}{\sqrt{3}} \right),$$
(52)

where the E values are functions of  $(u, v, \bar{x})$ ,

$$E^{\cos,v-u} = 6 \left( A(u)A(v) + B(u)B(v) \right) \left( 54 - 6(u^2 + v^2 - 3uv)\bar{x}^2 + u^2v^2\bar{x}^4 \right)$$

$$+ 12\sqrt{3} \left( A(u)B(v) - A(v)B(u) \right) (u - v)\bar{x}(9 + uv\bar{x}^2), \tag{53}$$

$$E^{\cos,v+u} = -6 \left( 2\sqrt{3} \left( A(u)B(v) + A(v)B(u) \right) (u + v)\bar{x}(-9 + uv\bar{x}^2)$$

$$+ \left( A(u)A(v) - B(u)B(v) \right) \left( 54 - 6(u^2 + v^2 + 3uv)\bar{x}^2 + u^2v^2\bar{x}^4 \right) \right), \tag{54}$$

$$E^{\sin,v-u} = -6 \left( 2\sqrt{3}\bar{x} \left( A(u)A(v) + B(u)B(v) \right) (u - v)(9 + uv\bar{x}^2)$$

$$+ \left( A(v)B(u) - A(u)B(v) \right) \left( 54 - 6(u^2 - 3uv + v^2)\bar{x}^2 + u^2v^2\bar{x}^4 \right) \right), \tag{55}$$

$$E^{\sin,v+u} = 6 \left( 2\sqrt{3} \left( A(u)A(v) - B(u)B(v) \right) (u + v)\bar{x}(-9 + uv\bar{x}^2)$$

$$+ \left( A(u)B(v) + A(v)B(u) \right) (-54 + 6(u^2 + v^2 + 3uv)\bar{x}^2 - u^2v^2\bar{x}^4 \right) \right). \tag{56}$$

The counterpart in the MD case is

$$f_{\text{MD}}(v, u, \bar{x})|_{\Phi(\bar{x})=A} = \frac{6A(u)A(v)}{5}.$$
 (57)

The integrals  $\mathcal{I}(v, u, x_1, x_2)$  are as follows:

$$\mathcal{I}_{RD}(v, u, x_1, x_2) = \frac{3}{4u^3v^3} \left[ \frac{1}{x^4} \left( F^{--} \cos y^{--} + F^{+-} \cos y^{+-} + F^{-+} \cos y^{-+} + F^{++} \cos y^{++} \right) + G^{--} \sin y^{--} + G^{+-} \sin y^{+-} + G^{-+} \sin y^{-+} + G^{++} \sin y^{++} \right]_{x_1}^{x_2} + \frac{3(u^2 + v^2 - 3)^2}{4u^3v^3} \left[ H^{--} \text{Ci}(y^{--}) + H^{+-} \text{Ci}(y^{+-}) + H^{-+} \text{Ci}(|y^{-+}|) + H^{++} \text{Ci}(y^{++}) + I^{--} \text{Si}(y^{--}) + I^{+-} \text{Si}(y^{+-}) + I^{-+} \text{Si}(y^{-+}) + I^{++} \text{Si}(y^{++}) \right]_{x_1}^{x_2}, \quad (58)$$

where we have introduced  $y^{\pm\pm} = \left(1 \pm \frac{v \pm u}{\sqrt{3}}\right) x$  for compact notation, where the first (second)  $\pm$  on the left side corresponds to the first (second)  $\pm$  on the right side. (The first sign is the relative sign between 1 and v, and the second sign is the relative sign between v and v.) The coefficient functions F, G, H, and I are defined as

$$F^{--} = I^{--} \left( 18(-1 + \sqrt{3}(u - v))x + (-3 + \sqrt{3}(u - v))((u + v)^2 - 3)x^3 \right)$$

$$\begin{split} &-H^{--}\left(54-3(3+u^2+v^2-6uv+2\sqrt{3}(v-u))x^2\right) & (59) \\ F^{+-} &= -I^{+-}\left(18(1+\sqrt{3}(u-v))x+(3+\sqrt{3}(u-v))((u+v)^2-3)x^3\right) \\ &-H^{+-}\left(54-3(3+u^2+v^2-6uv+2\sqrt{3}(u-v))x^2\right) & (60) \\ F^{-+} &= -I^{-+}\left(18(1+\sqrt{3}(u+v))x+(3+\sqrt{3}(u+v))((u-v)^2-3)x^3\right) \\ &-H^{-+}\left(54-3(3+u^2+v^2+6uv+2\sqrt{3}(u+v))x^2\right) & (61) \\ F^{++} &= I^{++}\left(18(-1+\sqrt{3}(u+v))x+(-3+\sqrt{3}(u+v))((u-v)^2-3)x^3\right) \\ &-H^{++}\left(54-3(3+u^2+v^2+6uv-2\sqrt{3}(u+v))x^2\right) & (62) \\ G^{--} &= -H^{--}\left(18(-1+\sqrt{3}(u-v))x+(-3+\sqrt{3}(u-v))((u+v)^2-3)x^3\right) \\ &-I^{--}\left(54-3(3+u^2+v^2-6uv+2\sqrt{3}(v-u))x^2\right) & (63) \\ G^{+-} &= H^{+-}\left(18(1+\sqrt{3}(u-v))x+(3+\sqrt{3}(u-v))((u+v)^2-3)x^3\right) \\ &-I^{+-}\left(54-3(3+u^2+v^2-6uv+2\sqrt{3}(u-v))x^2\right) & (64) \\ G^{-+} &= H^{-+}\left(18(1+\sqrt{3}(u+v))x+(3+\sqrt{3}(u+v))((u-v)^2-3)x^3\right) \\ &-I^{-+}\left(54-3(3+u^2+v^2-6uv+2\sqrt{3}(u+v))x^2\right) & (65) \\ G^{++} &= -H^{++}\left(18(-1+\sqrt{3}(u+v))x+(-3+\sqrt{3}(u+v))((u-v)^2-3)x^3\right) \\ &-I^{++}\left(54-3(3+u^2+v^2+6uv+2\sqrt{3}(u+v))x^2\right) & (65) \\ G^{++} &= -H^{++}\left(18(-1+\sqrt{3}(u+v))x+(-3+\sqrt{3}(u+v))((u-v)^2-3)x^3\right) \\ &-I^{++}\left(54-3(3+u^2+v^2+6uv-2\sqrt{3}(u+v))x^2\right) & (66) \\ H^{--} &= (A(u)A(v)+B(u)B(v))D+(A(u)B(v)-A(v)B(u))C, & (67) \\ H^{+-} &= (A(u)A(v)+B(u)B(v))D+(A(u)B(v)+A(v)B(u))C, & (68) \\ H^{-+} &= -((A(u)A(v)-B(u)B(v))D-(A(u)B(v)+A(v)B(u))C), & (69) \\ H^{++} &= -((A(u)A(v)-B(u)B(v))D-(A(u)B(v)+A(v)B(u))C), & (69) \\ H^{-+} &= -((A(u)A(v)-B(u)B(v))D-(A(u)B(v)+A(v)B(u))C), & (69) \\ H^{-+} &= -((A(u)A(v)-B(u)B(v))D-(A(u)B(v)+A(v)B(u))C), & (69) \\ H^{-+} &= -((A(u)A(v)-B(u)B(v))D-(A(u)B(v)+A(v)B(u))C), & (69) \\ H^{-+} &= -((A(u)A(v)-B(u)B(v))D-(A(u)B(v)+A(v)B(u))C), & (69) \\ H^{-+} &= -((A(u)A(v)-B(u)B(v))D-(A(u)B(v)+A(v)B(u))C), & (69) \\ H^{-+} &= -((A(u)A(v)-B(u)B(v))D-(A(u)B(v)+A(v)B(u))C), & (69) \\ H^{-+} &= -((A(u)A(v)-B(u)B(v))D-(A(u)B(v)+A(v)B(u))C), & (69) \\ H^{-+} &= -((A(u)A(v)-B(u)B(v))D-(A(u)B(v)+A(v)B(u))C), & (69) \\ H^{-+} &= -((A(u)A(v)-B(u)B(v))D-(A(u)B(v)+A(v)B(u))C), & (69) \\ H^{-+} &= -((A(u)A(v)-B(u)B(v))D-(A(u)B(v)+A(v)B(u))C), & (69) \\ H^{-+} &= -((A(u)A(v)-B(u)B(v))D-(A(u)B(v)+A(v)B(u))C), & (69) \\ H^{-+} &= -((A(u)A(v)-B(u)B(v$$

$$I^{--} = (A(u)A(v) + B(u)B(v))C + (A(v)B(u) - A(u)B(v))D,$$
(71)

$$I = -(I(w)I(v) + B(w)B(v)) + (I(v)B(w) - I(w)B(v))B, \tag{11}$$

$$I^{+-} = (A(u)A(v) + B(u)B(v))C + (A(u)B(v) - A(v)B(u))D,$$

$$I^{-+} = -((A(u)A(v) - B(u)B(v))C - (A(u)B(v) + A(v)B(u))D),$$
(72)

$$I^{-+} = -((A(u)A(v) - B(u)B(v))C - (A(u)B(v) + A(v)B(u))D),$$

$$I^{++} = -((A(u)A(v) - B(u)B(v))C + (A(u)B(v) + A(v)B(u))D).$$
(73)

The x<sup>1</sup> → 0 limit can be taken by using limx1→<sup>0</sup> Ci(Ax1) − Ci(Bx1) = log A − log B. The above formula correctly reproduces earlier results. For example, if we take A = 1, B = 0, C = − cos x, and D = sin x, then x −1 limx1→<sup>0</sup> IRD(v, u, x1, x) = IRD(v, u, x).

The MD counterpart of the integral is

$$\mathcal{I}_{\text{MD}}(v, u, x_1, x_2) = \frac{6A(u)A(v)}{5} \left[ C\left( -3x\cos x + (3-x^2)\sin x \right) + D\left( -3x\sin x + (x^2-3)\cos x \right) \right]_{x_1}^{x_2}.$$
(75)

If we take A = 1, C = xy1(x), and D = −xj1(x), this reduces to the pure MD result, x −2 limx1→<sup>0</sup> IMD(v, u, x1, x) = IMD(v, u, x). Equation [\(44\)](#page-13-1) is obtained by using the values of C and D which equate the zeroth and first derivatives before and after the reheating (sudden decay approximation is used). Also, we substitute Φ in eq. [\(47\)](#page-14-3) to A to obtain eq. [\(48\)](#page-14-4).

## <span id="page-19-0"></span>B Comparison with observations

Although the focus of this paper is the derivation of the analytic formulas of the power spectrum of the induced GWs, we briefly illustrate how to compare our results to observations. The related discussion is given at the end of section [4.](#page-15-0)

Well after the horizon entry, GWs produced in a RD era redshift as radiation ρGW ∝ a −4 , so ΩGW is constant during a RD era, but it is diluted as a −1 in a MD era. This fact is represented by the redshift factor (xeq/x) 2 in eq. [\(46\)](#page-14-1). The present value of the energy fraction for the contribution from or before the RD era is thus

$$\Omega_{\rm GW}(\eta_0, k) = \Omega_{\rm r,0} \Omega_{\rm GW}(\eta_c, k), \tag{76}$$

where Ωr,<sup>0</sup> = ρr,0/ρ<sup>0</sup> is the present value of the energy density fraction of radiation, and η<sup>c</sup> is some time after ΩGW(η, k) has become constant so ΩGW(ηc, k) is the asymptotic constant value during the RD era [\[31\]](#page-24-11). A precise formula taking into account the change in the number of relativistic degrees of freedom can be found, e.g., in Ref. [\[66\]](#page-27-0) in the context of the primordial GWs. For a comprehensive discussion on the precise temperature dependence of the effective degrees of freedom, see Ref. [\[67\]](#page-27-1). We do not show such a dependence here because we neglect such changes in the analytic integral; see footnote [2.](#page-6-0)

On the other hand, the present value of the energy fraction for the contribution after the radiation-matter equality is obtained as

$$\Omega_{\text{GW}}(\eta_0, k) = \frac{\rho_{\text{GW}}(\eta_0, k)}{\rho_{\text{GW}}(\eta_\Lambda, k)} \frac{\rho_{\text{GW}}(\eta_\Lambda, k)}{\rho(\eta_\Lambda)} \frac{\rho(\eta_\Lambda)}{\rho_m(\eta_0)} \frac{\rho_m(\eta_0)}{\rho(\eta_0)}$$

$$\simeq 2 \Omega_{\text{m},0} \frac{a(\eta_\Lambda)}{a(\eta_0)} \Omega_{\text{GW}}(\eta_\Lambda, k), \tag{77}$$

where Ωm,<sup>0</sup> = ρm,0/ρ<sup>0</sup> is the present value of the matter energy fraction, η<sup>Λ</sup> is the conformal time when the dark energy begins to dominate the Universe, ρm(ηΛ) = ρΛ(ηΛ) ' ρ(ηΛ)/2, and we approximate ΩGW(ηΛ, k) by the MD-to-RD formula because GWs are supposed to redshift like

<span id="page-20-0"></span>![](_page_20_Figure_0.jpeg)

Figure 3: Simple examples of the energy density fraction ΩGWh <sup>2</sup> of the induced GWs. The brown lines show the case of the scale-invariant curvature perturbations with A<sup>ζ</sup> = 2.2 × 10−<sup>9</sup> . The horizontal part is the contribution from the RD era. The bottom left curves show the effect of the late-time MD era. The dashed line is in the nonlinear regime, and the solid line is a conservative one neglecting all of the contributions beyond the nonlinearity scale. The bottom right curve shows an example of an early MD era with the reheating temperature T<sup>R</sup> = 10<sup>9</sup> GeV. The scale of the onset of the early MD era is assumed to be 200 times shorter than the reheating scale so that there is no nonlinearity issue. The green line shows the contribution from the RD era in the case of power-law curvature perturbations with A<sup>ζ</sup> = 10−<sup>12</sup> , n<sup>s</sup> = 2, and k<sup>∗</sup> = 0.05 Mpc−<sup>1</sup> . The blue lines denote existing pulsar timing array constraints from EPTA [\[53\]](#page-26-5), NANOGrav [\[54\]](#page-26-6), and PPTA [\[55\]](#page-26-7). The pink lines show sensitivity curves [\[56\]](#page-26-8) of various future GW observations reproduced from Ref. [\[57\]](#page-26-9). The observations are from SKA [\[58\]](#page-26-10), eLISA [\[59\]](#page-26-11), LISA [\[60\]](#page-26-12), BBO [\[61\]](#page-27-2), DECIGO [\[62\]](#page-27-3), Einstein Telescope [\[63\]](#page-27-4), Cosmic Explorer [\[64\]](#page-27-5), and KAGRA [\[65\]](#page-27-6). The gray line (dotted) shows the upper bound on the relativistic degrees of freedom from BBN, ΩGWh <sup>2</sup> < 1.8×10−<sup>6</sup> (95% C.L.) derived in Appendix [C.](#page-21-0)

radiation after the MD era.

To suppress the uncertainty of the Hubble parameter, it is customary to multiply ΩGW with h 2 0 , which is defined as H<sup>0</sup> = 100 h<sup>0</sup> km/s/Mpc. Some simple examples are plotted in Figure [3](#page-20-0) for illustration. The brown lines show the scale-invariant case with two MD eras. The green line shows an example of the power-law spectrum, which may be interpreted qualitatively as a rough approximation for some PBH scenarios with curvatons [\[68–](#page-27-7)[71\]](#page-27-8). The pulsar timing array constraints and the sensitivity curves of future GW detectors are also shown, as blue and pink lines, respectively.

The dashed line in the Figure [3](#page-20-0) indicates that it is in the nonlinear regime. Since the gravita-

tional potential and the density perturbation are related to each other through  $\Delta\Phi \simeq a^2\delta\rho/2$  in the deep subhorizon limit, we define the nonlinear scale as (see Ref. [27])

$$k_{\rm NL}(\eta) = \frac{3}{2} \mathcal{P}_{\zeta}^{-1/4} \mathcal{H}(\eta). \tag{78}$$

We are mostly interested in the nonlinear scale evaluated at the end of the MD era. The solid line below the dashed one is the case in which we cut off the source spectrum at the nonlinear scale, and the line of the RD era is simply extrapolated. This should be too conservative because there would be a contribution which gets marginally nonlinear during the MD era and subsequently diluted just by cosmic expansion. This contribution scales as  $(k_{\rm NL}/k)^4$  [27]. However, to derive the precise spectrum, including the region around  $k \simeq k_{\rm NL}$ , one has to consider a time-dependent cutoff  $k_{\rm NL}(\eta)$  or rely on nonlinear lattice simulations. For simplicity, we neglect this contribution. The true value will be between the dashed and solid curves.

### <span id="page-21-0"></span>C Constraints on GW from Big-Bang Nucleosynthesis

An extra component of radiation such as the primordial gravitational wave background speeds up the expansion of the Universe, which can be checked by light element abundances produced in the epoch of BBN. Such an extra component of radiation is often parametrized by the effective number of neutrino species  $N_{\nu,\text{eff}} \equiv \rho_{\nu,\text{eff}}/\rho_{\nu_i}$ , where  $\rho_{\nu,\text{eff}}$  is the total energy density for the three species of active neutrinos and the extra component of radiation, and  $\rho_{\nu_i}$  is the energy density for one species of active neutrino  $\nu_i$ . If  $N_{\nu,\text{eff}}$  is larger than  $\sim 3$ , the interconverting reactions between neutron (n) and proton (p) should be decoupled from the thermal bath earlier than the time in the case of the standard BBN, which gives a larger neutron to proton ratio (n/p) as its freeze-out value. Then more <sup>4</sup>He and D are produced due to this larger n/p. Compared with observational light element abundances of <sup>4</sup>He and D, we can constrain  $N_{\nu,\text{eff}}$  for a fixed value of baryon number. Here, we adopt the value of the baryon number to be  $\Omega_{\rm B}h_0^2 = 0.02229^{+0.00029}_{-0.00027}$  (95% C.L.) [42].

In this paper we adopt the following observational values of the mass fraction of <sup>4</sup>He [72] and the deuterium (D) to hydrogen (H) ratio [73] at 68% C.L.,

$$Y_p = 0.2449 \pm 0.0040, \tag{79}$$

and

$$(D/H)_p = (2.545 \pm 0.025) \times 10^{-5},$$
 (80)

respectively.

In Fig. 4a, we plot  $\chi^2$ s as a function of  $N_{\nu,\text{eff}}$  to fit the observational abundance of D and <sup>4</sup>He, respectively, by using theoretical values of abundances calculated in BBN with errors of nuclear

<span id="page-22-1"></span>![](_page_22_Figure_0.jpeg)

![](_page_22_Figure_1.jpeg)

(a) D and <sup>4</sup>He

(b) Total

Figure 4: (4a)  $\chi^2$  as a function of  $N_{\nu,\rm eff}$  to fit abundances of D and <sup>4</sup>He, respectively. (4b) Total  $\chi^2$  as a function of  $\Omega_{\rm GW}h_0^2$  to simultaneously fit both D and <sup>4</sup>He.

reaction rates. By using these values of  $\chi^2$ , we can calculate the total  $\chi^2$ , which is plotted in Fig. 4b as a function of  $\Omega_{\rm GW} h_0^2 \sim 5.6 \times 10^{-6} (N_{\nu,\rm eff} - 3)$ .

From this figure, we obtain the upper bound on the energy density of the primordial GWs to be  $\Omega_{\rm GW}h_0^2 < 1.8 \times 10^{-6}$  at 95% C.L. It is notable that this constraint is sensitive to both the adiabatic and nonadiabatic components of radiation. This constraint is shown in Fig. 3 as the gray dotted line.

### References

- <span id="page-22-0"></span>[1] Virgo, LIGO Scientific Collaboration, B. P. Abbott *et al.*, "Observation of Gravitational Waves from a Binary Black Hole Merger," *Phys. Rev. Lett.* **116** no. 6, (2016) 061102, arXiv:1602.03837 [gr-qc].
- [2] Virgo, LIGO Scientific Collaboration, B. P. Abbott *et al.*, "GW151226: Observation of Gravitational Waves from a 22-Solar-Mass Binary Black Hole Coalescence," *Phys. Rev. Lett.* **116** no. 24, (2016) 241103, arXiv:1606.04855 [gr-qc].

- [3] VIRGO, LIGO Scientific Collaboration, B. P. Abbott et al., "GW170104: Observation of a 50-Solar-Mass Binary Black Hole Coalescence at Redshift 0.2," [Phys. Rev. Lett.](http://dx.doi.org/10.1103/PhysRevLett.118.221101) 118 no. 22, (2017) [221101,](http://dx.doi.org/10.1103/PhysRevLett.118.221101) [arXiv:1706.01812 \[gr-qc\]](http://arxiv.org/abs/1706.01812).
- [4] Virgo, LIGO Scientific Collaboration, B. P. Abbott et al., "GW170814: A Three-Detector Observation of Gravitational Waves from a Binary Black Hole Coalescence," [Phys. Rev. Lett.](http://dx.doi.org/10.1103/PhysRevLett.119.141101) 119 [no. 14, \(2017\) 141101,](http://dx.doi.org/10.1103/PhysRevLett.119.141101) [arXiv:1709.09660 \[gr-qc\]](http://arxiv.org/abs/1709.09660).
- <span id="page-23-0"></span>[5] Virgo, LIGO Scientific Collaboration, B. P. Abbott et al., "GW170608: Observation of a 19-solar-mass Binary Black Hole Coalescence," Astrophys. J. 851 [no. 2, \(2017\) L35,](http://dx.doi.org/10.3847/2041-8213/aa9f0c) [arXiv:1711.05578 \[astro-ph.HE\]](http://arxiv.org/abs/1711.05578).
- <span id="page-23-1"></span>[6] L. P. Grishchuk, "Amplification of gravitational waves in an istropic universe," Sov. Phys. JETP 40 (1975) 409–415. [Zh. Eksp. Teor. Fiz.67,825(1974)].
- <span id="page-23-2"></span>[7] A. A. Starobinsky, "Spectrum of relict gravitational radiation and the early state of the universe," JETP Lett. 30 (1979) 682–685. [,767(1979)].
- <span id="page-23-3"></span>[8] BICEP2, Keck Array Collaboration, P. A. R. Ade et al., "Improved Constraints on Cosmology and Foregrounds from BICEP2 and Keck Array Cosmic Microwave Background Data with Inclusion of 95 GHz Band," [Phys. Rev. Lett.](http://dx.doi.org/10.1103/PhysRevLett.116.031302) 116 (2016) 031302, [arXiv:1510.09217 \[astro-ph.CO\]](http://arxiv.org/abs/1510.09217).
- <span id="page-23-4"></span>[9] S. Y. Khlebnikov and I. I. Tkachev, "Relic gravitational waves produced after preheating," [Phys. Rev.](http://dx.doi.org/10.1103/PhysRevD.56.653) D56 [\(1997\) 653–660,](http://dx.doi.org/10.1103/PhysRevD.56.653) [arXiv:hep-ph/9701423 \[hep-ph\]](http://arxiv.org/abs/hep-ph/9701423).
- [10] R. Easther and E. A. Lim, "Stochastic gravitational wave production after inflation," [JCAP](http://dx.doi.org/10.1088/1475-7516/2006/04/010) 0604 [\(2006\) 010,](http://dx.doi.org/10.1088/1475-7516/2006/04/010) [arXiv:astro-ph/0601617 \[astro-ph\]](http://arxiv.org/abs/astro-ph/0601617).
- [11] R. Easther, J. T. Giblin, Jr., and E. A. Lim, "Gravitational Wave Production At The End Of Inflation," [Phys. Rev. Lett.](http://dx.doi.org/10.1103/PhysRevLett.99.221301) 99 (2007) 221301, [arXiv:astro-ph/0612294 \[astro-ph\]](http://arxiv.org/abs/astro-ph/0612294).
- <span id="page-23-5"></span>[12] J. F. Dufaux, A. Bergman, G. N. Felder, L. Kofman, and J.-P. Uzan, "Theory and Numerics of Gravitational Waves from Preheating after Inflation," Phys. Rev. D76 [\(2007\) 123517,](http://dx.doi.org/10.1103/PhysRevD.76.123517) [arXiv:0707.0875 \[astro-ph\]](http://arxiv.org/abs/0707.0875).
- <span id="page-23-6"></span>[13] E. Witten, "Cosmic Separation of Phases," Phys. Rev. D30 [\(1984\) 272–285.](http://dx.doi.org/10.1103/PhysRevD.30.272)
- [14] C. J. Hogan, "Gravitational radiation from cosmological phase transitions," Mon. Not. Roy. Astron. Soc. 218 (1986) 629–636.
- <span id="page-23-7"></span>[15] R. Jinno and M. Takimoto, "Gravitational waves from bubble collisions: An analytic derivation," Phys. Rev. D95 [no. 2, \(2017\) 024009,](http://dx.doi.org/10.1103/PhysRevD.95.024009) [arXiv:1605.01403 \[astro-ph.CO\]](http://arxiv.org/abs/1605.01403).
- <span id="page-23-8"></span>[16] T. Vachaspati and A. Vilenkin, "Gravitational Radiation from Cosmic Strings," [Phys. Rev.](http://dx.doi.org/10.1103/PhysRevD.31.3052) D31 [\(1985\) 3052.](http://dx.doi.org/10.1103/PhysRevD.31.3052)
- <span id="page-23-9"></span>[17] T. Damour and A. Vilenkin, "Gravitational radiation from cosmic (super)strings: Bursts, stochastic background, and observational windows," Phys. Rev. D71 [\(2005\) 063510,](http://dx.doi.org/10.1103/PhysRevD.71.063510) [arXiv:hep-th/0410222](http://arxiv.org/abs/hep-th/0410222) [\[hep-th\]](http://arxiv.org/abs/hep-th/0410222).

- <span id="page-24-7"></span>[18] U.-L. Pen and N. Turok, "Shocks in the Early Universe," Phys. Rev. Lett. 117 [no. 13, \(2016\) 131301,](http://dx.doi.org/10.1103/PhysRevLett.117.131301) [arXiv:1510.02985 \[astro-ph.CO\]](http://arxiv.org/abs/1510.02985).
- <span id="page-24-8"></span>[19] G. S. Bisnovatyi-Kogan and V. N. Rudenko, "Very high frequency gravitational wave background in the universe," [Class. Quant. Grav.](http://dx.doi.org/10.1088/0264-9381/21/14/001) 21 (2004) 3347–3359, [arXiv:gr-qc/0406089 \[gr-qc\]](http://arxiv.org/abs/gr-qc/0406089).
- [20] R. Anantua, R. Easther, and J. T. Giblin, "GUT-Scale Primordial Black Holes: Consequences and Constraints," [Phys. Rev. Lett.](http://dx.doi.org/10.1103/PhysRevLett.103.111303) 103 (2009) 111303, [arXiv:0812.0825 \[astro-ph\]](http://arxiv.org/abs/0812.0825).
- <span id="page-24-9"></span>[21] R. Dong, W. H. Kinney, and D. Stojkovic, "Gravitational wave production by Hawking radiation from rotating primordial black holes," JCAP 1610 [no. 10, \(2016\) 034,](http://dx.doi.org/10.1088/1475-7516/2016/10/034) [arXiv:1511.05642 \[astro-ph.CO\]](http://arxiv.org/abs/1511.05642).
- <span id="page-24-0"></span>[22] K. N. Ananda, C. Clarkson, and D. Wands, "The Cosmological gravitational wave background from primordial density perturbations," Phys. Rev. D75 [\(2007\) 123518,](http://dx.doi.org/10.1103/PhysRevD.75.123518) [arXiv:gr-qc/0612013 \[gr-qc\]](http://arxiv.org/abs/gr-qc/0612013).
- <span id="page-24-6"></span>[23] E. Bugaev and P. Klimai, "Induced gravitational wave background and primordial black holes," [Phys.](http://dx.doi.org/10.1103/PhysRevD.81.023517) Rev. D81 [\(2010\) 023517,](http://dx.doi.org/10.1103/PhysRevD.81.023517) [arXiv:0908.0664 \[astro-ph.CO\]](http://arxiv.org/abs/0908.0664).
- <span id="page-24-1"></span>[24] L. Alabidi, K. Kohri, M. Sasaki, and Y. Sendouda, "Observable Spectra of Induced Gravitational Waves from Inflation," JCAP 1209 [\(2012\) 017,](http://dx.doi.org/10.1088/1475-7516/2012/09/017) [arXiv:1203.4663 \[astro-ph.CO\]](http://arxiv.org/abs/1203.4663).
- <span id="page-24-2"></span>[25] S. Mollerach, D. Harari, and S. Matarrese, "CMB polarization from secondary vector and tensor modes," Phys. Rev. D69 [\(2004\) 063002,](http://dx.doi.org/10.1103/PhysRevD.69.063002) [arXiv:astro-ph/0310711 \[astro-ph\]](http://arxiv.org/abs/astro-ph/0310711).
- <span id="page-24-10"></span>[26] D. Baumann, P. J. Steinhardt, K. Takahashi, and K. Ichiki, "Gravitational Wave Spectrum Induced by Primordial Scalar Perturbations," Phys. Rev. D76 [\(2007\) 084019,](http://dx.doi.org/10.1103/PhysRevD.76.084019) [arXiv:hep-th/0703290 \[hep-th\]](http://arxiv.org/abs/hep-th/0703290).
- <span id="page-24-12"></span>[27] H. Assadullahi and D. Wands, "Gravitational waves from an early matter era," [Phys. Rev.](http://dx.doi.org/10.1103/PhysRevD.79.083511) D79 [\(2009\) 083511,](http://dx.doi.org/10.1103/PhysRevD.79.083511) [arXiv:0901.0989 \[astro-ph.CO\]](http://arxiv.org/abs/0901.0989).
- <span id="page-24-3"></span>[28] L. Alabidi, K. Kohri, M. Sasaki, and Y. Sendouda, "Observable induced gravitational waves from an early matter phase," JCAP 1305 [\(2013\) 033,](http://dx.doi.org/10.1088/1475-7516/2013/05/033) [arXiv:1303.4519 \[astro-ph.CO\]](http://arxiv.org/abs/1303.4519).
- <span id="page-24-4"></span>[29] E. D. Kovetz, "Probing Primordial-Black-Hole Dark Matter with Gravitational Waves," [Phys. Rev.](http://dx.doi.org/10.1103/PhysRevLett.119.131301) Lett. 119 [no. 13, \(2017\) 131301,](http://dx.doi.org/10.1103/PhysRevLett.119.131301) [arXiv:1705.09182 \[astro-ph.CO\]](http://arxiv.org/abs/1705.09182).
- [30] K. Kohri and T. Terada, "Primordial Black Hole Dark Matter and LIGO/Virgo Merger Rate from Inflation with Running Spectral Indices," [arXiv:1802.06785 \[astro-ph.CO\]](http://arxiv.org/abs/1802.06785).
- <span id="page-24-11"></span>[31] K. Inomata, M. Kawasaki, K. Mukaida, and T. T. Yanagida, "Double inflation as a single origin of primordial black holes for all dark matter and LIGO observations," Phys. Rev. D97 [no. 4, \(2018\)](http://dx.doi.org/10.1103/PhysRevD.97.043514) [043514,](http://dx.doi.org/10.1103/PhysRevD.97.043514) [arXiv:1711.06129 \[astro-ph.CO\]](http://arxiv.org/abs/1711.06129).
- [32] J. Garcia-Bellido, M. Peloso, and C. Unal, "Gravitational Wave signatures of inflationary models from Primordial Black Hole Dark Matter," JCAP 1709 [no. 09, \(2017\) 013,](http://dx.doi.org/10.1088/1475-7516/2017/09/013) [arXiv:1707.02441](http://arxiv.org/abs/1707.02441) [\[astro-ph.CO\]](http://arxiv.org/abs/1707.02441).
- <span id="page-24-5"></span>[33] M. Sasaki, T. Suyama, T. Tanaka, and S. Yokoyama, "Primordial black holes—perspectives in gravitational wave astronomy," Class. Quant. Grav. 35 [no. 6, \(2018\) 063001,](http://dx.doi.org/10.1088/1361-6382/aaa7b4) [arXiv:1801.05235](http://arxiv.org/abs/1801.05235) [\[astro-ph.CO\]](http://arxiv.org/abs/1801.05235).

- <span id="page-25-0"></span>[34] R. Saito and J. Yokoyama, "Gravitational wave background as a probe of the primordial black hole abundance," [Phys. Rev. Lett.](http://dx.doi.org/10.1103/PhysRevLett.102.161101, 10.1103/PhysRevLett.107.069901) 102 (2009) 161101, [arXiv:0812.4339 \[astro-ph\]](http://arxiv.org/abs/0812.4339). [Erratum: Phys. Rev. Lett.107,069901(2011)].
- [35] R. Saito and J. Yokoyama, "Gravitational-Wave Constraints on the Abundance of Primordial Black Holes," [Prog. Theor. Phys.](http://dx.doi.org/10.1143/PTP.126.351, 10.1143/PTP.123.867) 123 (2010) 867–886, [arXiv:0912.5317 \[astro-ph.CO\]](http://arxiv.org/abs/0912.5317). [Erratum: Prog. Theor. Phys.126,351(2011)].
- <span id="page-25-1"></span>[36] E. Bugaev and P. Klimai, "Constraints on the induced gravitational wave background from primordial black holes," Phys. Rev. D83 [\(2011\) 083521,](http://dx.doi.org/10.1103/PhysRevD.83.083521) [arXiv:1012.4697 \[astro-ph.CO\]](http://arxiv.org/abs/1012.4697).
- <span id="page-25-2"></span>[37] N. Orlofsky, A. Pierce, and J. D. Wells, "Inflationary theory and pulsar timing investigations of primordial black holes and gravitational waves," Phys. Rev. D95 [no. 6, \(2017\) 063518,](http://dx.doi.org/10.1103/PhysRevD.95.063518) [arXiv:1612.05279 \[astro-ph.CO\]](http://arxiv.org/abs/1612.05279).
- <span id="page-25-3"></span>[38] K. Inomata, M. Kawasaki, K. Mukaida, Y. Tada, and T. T. Yanagida, "Inflationary primordial black holes for the LIGO gravitational wave events and pulsar timing array experiments," [Phys. Rev.](http://dx.doi.org/10.1103/PhysRevD.95.123510) D95 [no. 12, \(2017\) 123510,](http://dx.doi.org/10.1103/PhysRevD.95.123510) [arXiv:1611.06130 \[astro-ph.CO\]](http://arxiv.org/abs/1611.06130).
- <span id="page-25-4"></span>[39] M. Maggiore, "Gravitational wave experiments and early universe cosmology," [Phys. Rept.](http://dx.doi.org/10.1016/S0370-1573(99)00102-7) 331 (2000) [283–367,](http://dx.doi.org/10.1016/S0370-1573(99)00102-7) [arXiv:gr-qc/9909001 \[gr-qc\]](http://arxiv.org/abs/gr-qc/9909001).
- <span id="page-25-5"></span>[40] V. Mukhanov, Physical Foundations of Cosmology. Cambridge University Press, Oxford, 2005. <http://www-spires.fnal.gov/spires/find/books/www?cl=QB981.M89::2005>.
- <span id="page-25-6"></span>[41] Planck Collaboration, P. A. R. Ade et al., "Planck 2015 results. XX. Constraints on inflation," [Astron. Astrophys.](http://dx.doi.org/10.1051/0004-6361/201525898) 594 (2016) A20, [arXiv:1502.02114 \[astro-ph.CO\]](http://arxiv.org/abs/1502.02114).
- <span id="page-25-7"></span>[42] Planck Collaboration, P. A. R. Ade et al., "Planck 2015 results. XIII. Cosmological parameters," [Astron. Astrophys.](http://dx.doi.org/10.1051/0004-6361/201525830) 594 (2016) A13, [arXiv:1502.01589 \[astro-ph.CO\]](http://arxiv.org/abs/1502.01589).
- <span id="page-25-8"></span>[43] J. Chluba, A. L. Erickcek, and I. Ben-Dayan, "Probing the inflaton: Small-scale power spectrum constraints from measurements of the CMB energy spectrum," [Astrophys. J.](http://dx.doi.org/10.1088/0004-637X/758/2/76) 758 (2012) 76, [arXiv:1203.2681 \[astro-ph.CO\]](http://arxiv.org/abs/1203.2681).
- <span id="page-25-9"></span>[44] K. Kohri, T. Nakama, and T. Suyama, "Testing scenarios of primordial black holes being the seeds of supermassive black holes by ultracompact minihalos and CMB µ-distortions," [Phys. Rev.](http://dx.doi.org/10.1103/PhysRevD.90.083514) D90 no. 8, [\(2014\) 083514,](http://dx.doi.org/10.1103/PhysRevD.90.083514) [arXiv:1405.5999 \[astro-ph.CO\]](http://arxiv.org/abs/1405.5999).
- <span id="page-25-10"></span>[45] T. Nakama, T. Suyama, and J. Yokoyama, "Reheating the Universe Once More: The Dissipation of Acoustic Waves as a Novel Probe of Primordial Inhomogeneities on Even Smaller Scales," [Phys. Rev.](http://dx.doi.org/10.1103/PhysRevLett.113.061302) Lett. 113 [\(2014\) 061302,](http://dx.doi.org/10.1103/PhysRevLett.113.061302) [arXiv:1403.5407 \[astro-ph.CO\]](http://arxiv.org/abs/1403.5407).
- <span id="page-25-11"></span>[46] K. Inomata, M. Kawasaki, and Y. Tada, "Revisiting constraints on small scale perturbations from big-bang nucleosynthesis," Phys. Rev. D94 [no. 4, \(2016\) 043527,](http://dx.doi.org/10.1103/PhysRevD.94.043527) [arXiv:1605.04646 \[astro-ph.CO\]](http://arxiv.org/abs/1605.04646).
- <span id="page-25-12"></span>[47] D. Jeong, J. Pradler, J. Chluba, and M. Kamionkowski, "Silk damping at a redshift of a billion: a new limit on small-scale adiabatic perturbations," [Phys. Rev. Lett.](http://dx.doi.org/10.1103/PhysRevLett.113.061301) 113 (2014) 061301, [arXiv:1403.3697](http://arxiv.org/abs/1403.3697) [\[astro-ph.CO\]](http://arxiv.org/abs/1403.3697).

- <span id="page-26-0"></span>[48] B. C. Lacki and J. F. Beacom, "Primordial Black Holes as Dark Matter: Almost All or Almost Nothing," Astrophys. J. 720 [\(2010\) L67–L71,](http://dx.doi.org/10.1088/2041-8205/720/1/L67) [arXiv:1003.3466 \[astro-ph.CO\]](http://arxiv.org/abs/1003.3466).
- <span id="page-26-1"></span>[49] T. Bringmann, P. Scott, and Y. Akrami, "Improved constraints on the primordial power spectrum at small scales from ultracompact minihalos," Phys. Rev. D85 [\(2012\) 125027,](http://dx.doi.org/10.1103/PhysRevD.85.125027) [arXiv:1110.2484](http://arxiv.org/abs/1110.2484) [\[astro-ph.CO\]](http://arxiv.org/abs/1110.2484).
- <span id="page-26-2"></span>[50] B. J. Carr, K. Kohri, Y. Sendouda, and J. Yokoyama, "New cosmological constraints on primordial black holes," Phys. Rev. D81 [\(2010\) 104019,](http://dx.doi.org/10.1103/PhysRevD.81.104019) [arXiv:0912.5297 \[astro-ph.CO\]](http://arxiv.org/abs/0912.5297).
- <span id="page-26-3"></span>[51] B. Carr, F. Kuhnel, and M. Sandstad, "Primordial Black Holes as Dark Matter," [Phys. Rev.](http://dx.doi.org/10.1103/PhysRevD.94.083504) D94 [no. 8, \(2016\) 083504,](http://dx.doi.org/10.1103/PhysRevD.94.083504) [arXiv:1607.06077 \[astro-ph.CO\]](http://arxiv.org/abs/1607.06077).
- <span id="page-26-4"></span>[52] J. R. Espinosa, D. Racco, and A. Riotto, "A Cosmological Signature of the SM Higgs Instability: Gravitational Waves," [arXiv:1804.07732 \[hep-ph\]](http://arxiv.org/abs/1804.07732).
- <span id="page-26-5"></span>[53] L. Lentati et al., "European Pulsar Timing Array Limits On An Isotropic Stochastic Gravitational-Wave Background," [Mon. Not. Roy. Astron. Soc.](http://dx.doi.org/10.1093/mnras/stv1538) 453 no. 3, (2015) 2576–2598, [arXiv:1504.03692 \[astro-ph.CO\]](http://arxiv.org/abs/1504.03692).
- <span id="page-26-6"></span>[54] NANOGRAV Collaboration, Z. Arzoumanian et al., "The NANOGrav 11-year Data Set: Pulsar-timing Constraints On The Stochastic Gravitational-wave Background," [arXiv:1801.02617](http://arxiv.org/abs/1801.02617) [\[astro-ph.HE\]](http://arxiv.org/abs/1801.02617).
- <span id="page-26-7"></span>[55] R. M. Shannon et al., "Gravitational waves from binary supermassive black holes missing in pulsar observations," Science 349 [no. 6255, \(2015\) 1522–1525,](http://dx.doi.org/10.1126/science.aab1910) [arXiv:1509.07320 \[astro-ph.CO\]](http://arxiv.org/abs/1509.07320).
- <span id="page-26-8"></span>[56] B. S. Sathyaprakash and B. F. Schutz, "Physics, Astrophysics and Cosmology with Gravitational Waves," [Living Rev. Rel.](http://dx.doi.org/10.12942/lrr-2009-2) 12 (2009) 2, [arXiv:0903.0338 \[gr-qc\]](http://arxiv.org/abs/0903.0338).
- <span id="page-26-9"></span>[57] C. J. Moore, R. H. Cole, and C. P. L. Berry, "Gravitational-wave sensitivity curves," [Class. Quant.](http://dx.doi.org/10.1088/0264-9381/32/1/015014) Grav. 32 [no. 1, \(2015\) 015014,](http://dx.doi.org/10.1088/0264-9381/32/1/015014) [arXiv:1408.0740 \[gr-qc\]](http://arxiv.org/abs/1408.0740).
- <span id="page-26-10"></span>[58] P. E. Dewdney, P. J. Hall, R. T. Schilizzi, and T. J. L. W. Lazio, "The square kilometre array," Proceedings of the IEEE 97 [no. 8, \(Aug, 2009\) 1482–1496.](http://dx.doi.org/10.1109/JPROC.2009.2021005)
- <span id="page-26-11"></span>[59] eLISA Collaboration, P. A. Seoane et al., "The Gravitational Universe," [arXiv:1305.5720](http://arxiv.org/abs/1305.5720) [\[astro-ph.CO\]](http://arxiv.org/abs/1305.5720).
- <span id="page-26-12"></span>[60] P. Amaro-Seoane, H. Audley, S. Babak, J. Baker, E. Barausse, P. Bender, E. Berti, P. Binetruy, M. Born, D. Bortoluzzi, J. Camp, C. Caprini, V. Cardoso, M. Colpi, J. Conklin, N. Cornish, C. Cutler, K. Danzmann, R. Dolesi, L. Ferraioli, V. Ferroni, E. Fitzsimons, J. Gair, L. Gesa Bote,
  - D. Giardini, F. Gibert, C. Grimani, H. Halloin, G. Heinzel, T. Hertog, M. Hewitson,
  - K. Holley-Bockelmann, D. Hollington, M. Hueller, H. Inchauspe, P. Jetzer, N. Karnesis, C. Killow,
  - A. Klein, B. Klipstein, N. Korsakova, S. L. Larson, J. Livas, I. Lloro, N. Man, D. Mance, J. Martino,
  - I. Mateos, K. McKenzie, S. T. McWilliams, C. Miller, G. Mueller, G. Nardini, G. Nelemans,
  - M. Nofrarias, A. Petiteau, P. Pivato, E. Plagnol, E. Porter, J. Reiche, D. Robertson, N. Robertson,
  - E. Rossi, G. Russano, B. Schutz, A. Sesana, D. Shoemaker, J. Slutsky, C. F. Sopuerta, T. Sumner,

- N. Tamanini, I. Thorpe, M. Troebs, M. Vallisneri, A. Vecchio, D. Vetrugno, S. Vitale, M. Volonteri, G. Wanner, H. Ward, P. Wass, W. Weber, J. Ziemer, and P. Zweifel, "Laser Interferometer Space Antenna," ArXiv e-prints (Feb., 2017) , [arXiv:1702.00786 \[astro-ph.IM\]](http://arxiv.org/abs/1702.00786).
- <span id="page-27-2"></span>[61] G. M. Harry, P. Fritschel, D. A. Shaddock, W. Folkner, and E. S. Phinney, "Laser interferometry for the big bang observer," [Class. Quant. Grav.](http://dx.doi.org/10.1088/0264-9381/23/24/C01, 10.1088/0264-9381/23/15/008) 23 (2006) 4887–4894. [Erratum: Class. Quant. Grav.23,7361(2006)].
- <span id="page-27-3"></span>[62] N. Seto, S. Kawamura, and T. Nakamura, "Possibility of direct measurement of the acceleration of the universe using 0.1-Hz band laser interferometer gravitational wave antenna in space," [Phys. Rev. Lett.](http://dx.doi.org/10.1103/PhysRevLett.87.221103) 87 [\(2001\) 221103,](http://dx.doi.org/10.1103/PhysRevLett.87.221103) [arXiv:astro-ph/0108011 \[astro-ph\]](http://arxiv.org/abs/astro-ph/0108011).
- <span id="page-27-4"></span>[63] M. Punturo et al., "The Einstein Telescope: A third-generation gravitational wave observatory," [Class. Quant. Grav.](http://dx.doi.org/10.1088/0264-9381/27/19/194002) 27 (2010) 194002.
- <span id="page-27-5"></span>[64] LIGO Scientific Collaboration, B. P. Abbott et al., "Exploring the Sensitivity of Next Generation Gravitational Wave Detectors," Class. Quant. Grav. 34 [no. 4, \(2017\) 044001,](http://dx.doi.org/10.1088/1361-6382/aa51f4) [arXiv:1607.08697](http://arxiv.org/abs/1607.08697) [\[astro-ph.IM\]](http://arxiv.org/abs/1607.08697).
- <span id="page-27-6"></span>[65] KAGRA Collaboration, K. Somiya, "Detector configuration of KAGRA: The Japanese cryogenic gravitational-wave detector," [Class. Quant. Grav.](http://dx.doi.org/10.1088/0264-9381/29/12/124007) 29 (2012) 124007, [arXiv:1111.7185 \[gr-qc\]](http://arxiv.org/abs/1111.7185).
- <span id="page-27-0"></span>[66] R. Jinno, T. Moroi, and K. Nakayama, "Inflationary Gravitational Waves and the Evolution of the Early Universe," JCAP 1401 [\(2014\) 040,](http://dx.doi.org/10.1088/1475-7516/2014/01/040) [arXiv:1307.3010 \[hep-ph\]](http://arxiv.org/abs/1307.3010).
- <span id="page-27-1"></span>[67] K. Saikawa and S. Shirai, "Primordial gravitational waves, precisely: The role of thermodynamics in the Standard Model," [arXiv:1803.01038 \[hep-ph\]](http://arxiv.org/abs/1803.01038).
- <span id="page-27-7"></span>[68] M. Kawasaki, N. Kitajima, and T. T. Yanagida, "Primordial black hole formation from an axionlike curvaton model," Phys. Rev. D87 [no. 6, \(2013\) 063519,](http://dx.doi.org/10.1103/PhysRevD.87.063519) [arXiv:1207.2550 \[hep-ph\]](http://arxiv.org/abs/1207.2550).
- [69] K. Kohri, C.-M. Lin, and T. Matsuda, "Primordial black holes from the inflating curvaton," [Phys.](http://dx.doi.org/10.1103/PhysRevD.87.103527) Rev. D87 [no. 10, \(2013\) 103527,](http://dx.doi.org/10.1103/PhysRevD.87.103527) [arXiv:1211.2371 \[hep-ph\]](http://arxiv.org/abs/1211.2371).
- [70] B. Carr, T. Tenkanen, and V. Vaskonen, "Primordial black holes from inflaton and spectator field perturbations in a matter-dominated era," Phys. Rev. D96 [no. 6, \(2017\) 063507,](http://dx.doi.org/10.1103/PhysRevD.96.063507) [arXiv:1706.03746](http://arxiv.org/abs/1706.03746) [\[astro-ph.CO\]](http://arxiv.org/abs/1706.03746).
- <span id="page-27-8"></span>[71] K. Ando, K. Inomata, M. Kawasaki, K. Mukaida, and T. T. Yanagida, "Primordial Black Holes for the LIGO Events in the Axion-like Curvaton Model," [arXiv:1711.08956 \[astro-ph.CO\]](http://arxiv.org/abs/1711.08956).
- <span id="page-27-9"></span>[72] E. Aver, K. A. Olive, and E. D. Skillman, "The effects of He I λ10830 on helium abundance determinations," JCAP 1507 [no. 07, \(2015\) 011,](http://dx.doi.org/10.1088/1475-7516/2015/07/011) [arXiv:1503.08146 \[astro-ph.CO\]](http://arxiv.org/abs/1503.08146).
- <span id="page-27-10"></span>[73] E. O. Zavarygin, J. K. Webb, S. Riemer-Sørensen, and V. Dumont, "Primordial deuterium abundance at z=2.504 towards Q1009+2956," 2018. [arXiv:1801.04704 \[astro-ph.CO\]](http://arxiv.org/abs/1801.04704). <https://inspirehep.net/record/1648127/files/arXiv:1801.04704.pdf>.