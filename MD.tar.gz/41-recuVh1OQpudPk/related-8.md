## Beta-2 microglobulin

Contributors to Wikimedia projects

From Wikipedia, the free encyclopedia

| B2M                            |                |                                                                                 |  |       |  |  |
|--------------------------------|----------------|---------------------------------------------------------------------------------|--|-------|--|--|
| Available structures           |                |                                                                                 |  |       |  |  |
|                                | Ortho          | Ortholog search: PDBe RCSB                                                      |  |       |  |  |
| PDB                            |                | List of PDB id codes                                                            |  |       |  |  |
| Identifiers                    |                |                                                                                 |  |       |  |  |
| Aliases                        | <u>B2M</u> , e | B2M, entrez:567, IMD43, beta-2-microglobulin, B2 microglobulin                  |  |       |  |  |
| External<br>IDs                |                | OMIM: 109700; MGI: 88127; HomoloGene: 2987; GeneCards: B2M; OMA:B2M - orthologs |  |       |  |  |
| Gene location ( <u>Human</u> ) |                |                                                                                 |  |       |  |  |
| Gene location ( <u>Mouse</u> ) |                |                                                                                 |  |       |  |  |
| RNA expression pattern         |                |                                                                                 |  |       |  |  |
| Gene ontology                  |                |                                                                                 |  |       |  |  |
| Orthologs                      |                |                                                                                 |  |       |  |  |
| Specie                         | Species        |                                                                                 |  | Mouse |  |  |
| <u>Entrez</u>                  |                | <u>567</u>                                                                      |  | 12010 |  |  |
|                                |                |                                                                                 |  |       |  |  |

| <b>Ensembl</b>              | ENSG00000166710<br>ENSG00000273686   |                 | ENSMUSGoooooo60802               |  |  |
|-----------------------------|--------------------------------------|-----------------|----------------------------------|--|--|
| <u>UniProt</u>              | UniProt P61769                       |                 | <u>Po1887</u>                    |  |  |
| RefSeq (mRNA)               | efSeq (mRNA)  NM_004048              |                 | NM_009735                        |  |  |
| RefSeq (protein)  NP_004039 |                                      |                 | NP_033865                        |  |  |
| Location (UCSC)             | Location (UCSC) Chr 15: 44.71 – 44.7 |                 | <u>Chr 2: 121.98 – 121.98 Mb</u> |  |  |
| PubMed search               |                                      |                 |                                  |  |  |
| Wikidata                    |                                      |                 |                                  |  |  |
| View/Edit Human             |                                      | View/Edit Mouse |                                  |  |  |

 $\beta_2$  microglobulin (B2M) is a component of MHC class I molecules. MHC class I molecules have  $\alpha_1$ ,  $\alpha_2$ , and  $\alpha_3$  proteins which are present on all nucleated cells (excluding red blood cells). In humans, the  $\beta_2$  microglobulin protein is encoded by the B2M gene.

## Structure and function

[edit]

![](_page_1_Picture_4.jpeg)

![](_page_2_Picture_0.jpeg)

Schematic representation of MHC class I

 $\beta_2$  microglobulin lies beside the  $\alpha_3$  chain on the cell surface. Unlike  $\alpha_3$ ,  $\beta_2$  has no <u>transmembrane</u> region. Directly above  $\beta_2$  (that is, further away from the cell) lies the  $\alpha_1$  chain, which itself is next to the  $\alpha_2$ .

 $\beta_2$  microglobulin associates not only with the alpha chain of MHC class I molecules, but also with class I-like molecules such as <u>CD1</u> (5 genes in humans), <u>MR1</u>, the <u>neonatal Fc receptor</u> (FcRn), and Qa-1 (a form of <u>alloantigen</u>). Nevertheless, the  $\beta_2$  microglobulin gene is outside of the MHC (HLA) locus, on a different chromosome.

An additional function is association with the <u>HFE protein</u>, together regulating the expression of <u>hepcidin</u> in the <u>liver</u> which targets the iron transporter <u>ferroportin</u> on the basolateral membrane of <u>enterocytes</u> and cell membrane of <u>macrophages</u> for degradation resulting in decreased iron uptake from food and decreased iron release from recycled red blood cells in the MPS (mononuclear phagocyte system) respectively. Loss of this function causes iron excess and hemochromatosis.

In a <u>cytomegalovirus</u> infection, a viral protein binds to  $\beta_2$  microglobulin, preventing assembly of MHC class I molecules and their transport to the plasma membrane. [citation needed]

Mice models deficient for the  $\beta_2$  microglobulin gene have been engineered. These mice demonstrate that  $\beta_2$  microglobulin is necessary for cell surface expression of MHC class I and stability of the peptide-binding groove. In fact, in the absence of  $\beta_2$  microglobulin, very limited amounts of MHC class I (classical and non-classical) molecules can be detected on the surface (bare lymphocyte syndrome or BLS). In the absence of MHC class I, CD8<sup>+</sup> T cells cannot develop. (CD8<sup>+</sup> T cells are a subset of T cells involved in the development of acquired immunity.)[citation needed]

## Clinical significance

## [edit]

In patients on long-term <u>hemodialysis</u>, it can aggregate into <u>amyloid</u> fibers that deposit in joint spaces, a disease, known as <u>dialysis-related amyloidosis</u>.

Low levels of  $\beta_2$  microglobulin can indicate non-progression of HIV.

Levels of  $\beta_2$  microglobulin can be elevated in <u>multiple myeloma</u> and <u>lymphoma</u>, though in these cases primary amyloidosis (amyloid light chain) and secondary amyloidosis (amyloid associated protein) are more common. [clarification needed] The normal value of  $\beta_2$  microglobulin is < 2 mg/L. However, with respect to multiple myeloma, the levels of  $\beta_2$  microglobulin may also be at the other end of the spectrum. Diagnostic testing for multiple myeloma includes obtaining the  $\beta_2$  microglobulin level, for this level is an important prognostic indicator. As of 2011, a patient with a level < 4 mg/L is expected to have a median survival of 43 months, while one with a level > 4 mg/L has a median survival of only 12 months.  $\beta_2$  microglobulin levels cannot, however, distinguish between monoclonal gammopathy of undetermined significance (MGUS), which has a better prognosis, and *smouldering* (low grade) myeloma.

Loss-of-function mutations in this gene have been reported in cancer patients unresponsive to immunotherapies. [citation needed]

 $\beta_2$  microglobulin has been shown to be of high relevance for viral entry of Coxsackievirus A9 and Vaccinia virus (a Poxvirus). For Coxsackievirus A9, it is likely that  $\beta_2$  microglobulin is required for the transport to plasma membrane of the identified receptor, the Human Neonatal Fc Receptor (FcRn). However, the specific function for Vaccinia virus has not yet been elucidated.

1. ^ ENSG00000273686 GRCh38: Ensembl release 89: ENSG00000166710,

- EN5G00000273080 Ensembl, May 2017
- <sup>2</sup>· ^ GRCm38: Ensembl release 89: ENSMUSG00000060802 Ensembl, May 2017
- 3. <u>"Human PubMed Reference:"</u>. National Center for Biotechnology Information, U.S. National Library of Medicine.
- <sup>4.</sup> "Mouse PubMed Reference:". National Center for Biotechnology Information, U.S. National Library of Medicine.
- 5. "Entrez Gene: Beta-2-microglobulin".
- 6. ^ Güssow D, Rein R, Ginjaar I, Hochstenbach F, Seemann G, Kottman A, et al. (November 1987). "The human beta 2-microglobulin gene. Primary structure and definition of the transcriptional unit". Journal of Immunology. 139 (9): 3132—3138. doi:10.4049/jimmunol.139.9.3132. PMID 3312414. S2CID 38290153.
- <sup>7.</sup> Cunningham BA, Wang JL, Berggård I, Peterson PA (November 1973). "The complete amino acid sequence of beta 2-microglobulin". Biochemistry. **12** (24): 4811–4822. doi:10.1021/bi00748a001. PMID 4586824.
- 8. Suggs SV, Wallace RB, Hirose T, Kawashima EH, Itakura K (November 1981).

  "Use of synthetic oligonucleotides as hybridization probes: isolation of cloned

  cDNA sequences for human beta 2-microglobulin". Proceedings of the National

  Academy of Sciences of the United States of America. 78 (11): 6613–6617.

  Bibcode:1981PNAS...78.6613S. doi:10.1073/pnas.78.11.6613. PMC 349099.

  PMID 6171820.
- 9. Hundall SD (2011). "Chapter 3: Iron, Heme, and Hemoglobin". Hematology: A Pathophysiologic Approach (1st ed.). Elsevier Health Sciences Division. pp. 17–25. <u>ISBN</u> 978-0-323-04311-3.
- <sup>10.</sup> Rao M, Sayal SK, Uppal SS, Gupta RM, Ohri VC, Banerjee S (October 1997).
  <u>"Beta-2-Microglobulin Levels in Human-Immunodeficiency Virus Infected Subjects"</u>. Medical Journal, Armed Forces India. 53 (4): 251–254.
  doi:10.1016/S0377-1237(17)30746-3. PMC 5531080. PMID 28769505.
- <sup>11.</sup> Pignone M, Nicoll D, McPhee SJ (2004). Pocket guide to diagnostic tests (4th ed.). New York: McGraw-Hill. pp. 191. ISBN 0-07-141184-4.
- <sup>12.</sup> "Amyloidosis". The Lecturio Medical Concept Library. Retrieved 28 June 2021.
- <sup>13.</sup> Munshi NC, Longo DL, Anderson KC (2011). "Chapter 111: Plasma Cell Disorders". In Loscalzo J, Longo DL, Fauci AS, Dennis LK, Hauser SL (eds.). Harrison's Principles of Internal Medicine (18th ed.). McGraw-Hill Professional. pp. 936–44. <u>ISBN</u> 978-0-07-174889-6.
- 14. Rajkumar SV (2005). "MGUS and smoldering multiple myeloma: update on pathogenesis, natural history, and management". Hematology. American Society of Hematology. Education Program. 2005: 340–345. doi:10.1182/asheducation-2005.1.340. PMID 16304401.
- 15. Bataille R, Klein B (November 1992). "Serum levels of beta 2 microglobulin and interleukin-6 to differentiate monoclonal gammopathy of undetermined significance" Blood 80 (0): 2422-2424 doi:10.1182/blood V80.0.2422.2422

- PMID 1421418.
- 16. Matía A, Lorenzo MM, Romero-Estremera YC, Sánchez-Puig JM, Zaballos A, Blasco R (December 2022). "Identification of β2 microglobulin, the product of B2M gene, as a Host Factor for Vaccinia Virus Infection by Genome-Wide CRISPR genetic screens". PLOS Pathogens. 18 (12) e1010800. doi:10.1371/journal.ppat.1010800. PMC 9829182. PMID 36574441.
- <sup>17.</sup> Zhao X, Zhang G, Liu S, Chen X, Peng R, Dai L, et al. (May 2019). "Human Neonatal Fc Receptor Is the Cellular Uncoating Receptor for Enterovirus B". Cell. 177 (6): 1553–1565.e16. doi:10.1016/j.cell.2019.04.035. PMC 7111318. PMID 31104841.
  - Huang WC, Havel JJ, Zhau HE, Qian WP, Lue HW, Chu CY, et al. (September 2008). "Beta2-microglobulin signaling blockade inhibited androgen receptor axis and caused apoptosis in human prostate cancer cells". Clinical Cancer Research.
     14 (17): 5341-5347. doi:10.1158/1078-0432.CCR-08-0793. PMC 3032570.
     PMID 18765525.
  - Huang WC, Wu D, Xie Z, Zhau HE, Nomura T, Zayzafoon M, et al. (September 2006). "beta2-microglobulin is a signaling and growth-promoting factor for human prostate cancer bone metastasis". Cancer Research. 66 (18): 9108–9116. doi:10.1158/0008-5472.CAN-06-1996. PMID 16982753.
  - Winchester JF, Salsberg JA, Levin NW (October 2003). "Beta-2 microglobulin in ESRD: an in-depth review". Advances in Renal Replacement Therapy. 10 (4): 279–309. doi:10.1053/j.arrt.2003.11.003. PMID 14681859.
  - Krangel MS, Orr HT, Strominger JL (December 1979). "Assembly and maturation of HLA-A and HLA-B antigens in vivo". Cell. **18** (4): 979–991. doi:10.1016/0092-8674(79)90210-1. PMID 93026.
  - Okon M, Bray P, Vucelić D (September 1992). "1H NMR assignments and secondary structure of human beta 2-microglobulin in solution". Biochemistry. 31 (37): 8906–8915. doi:10.1021/bi00152a030. PMID 1390678.
  - Guo HC, Jardetzky TS, Garrett TP, Lane WS, Strominger JL, Wiley DC (November 1992). "Different length peptides bind to HLA-Aw68 similarly at their ends but bulge out in the middle". Nature. **360** (6402): 364–366.

    <u>Bibcode:1992Natur.360..364G</u>. doi:10.1038/360364ao. PMID 1448153.
    S2CID 4324984.
  - Gattoni-Celli S, Kirsch K, Timpane R, Isselbacher KJ (March 1992). "Beta 2-microglobulin gene is mutated in a human colon cancer cell line (HCT) deficient in the expression of HLA class I antigens on the cell surface". Cancer Research. 52 (5): 1201–1204. PMID 1737380.
  - Saper MA, Bjorkman PJ, Wiley DC (May 1991). "Refined structure of the human histocompatibility antigen HLA-A2 at 2.6 A resolution". Journal of Molecular

- Biology. 219 (2): 277–319. doi:10.1016/0022-2836(91)90567-P. PMID 2038058. Caruana RJ, Lobel SA, Leffell MS, Campbell H, Cheek PL (December 1990). "Tumor necrosis factor, interleukin-1 and beta 2-microglobulin levels in chronic hemodialysis patients". The International Journal of Artificial Organs. 13 (12): 794–798. doi:10.1177/039139889001301205. PMID 2289831. S2CID 24952854.
- Hochman JH, Shimizu Y, DeMars R, Edidin M (April 1988). "Specific associations of fluorescent beta-2-microglobulin with cell surfaces. The affinity of different H-2 and HLA antigens for beta-2-microglobulin". Journal of Immunology. 140 (7): 2322–2329. doi:10.4049/jimmunol.140.7.2322. PMID 2450918. S2CID 34035543.
- Homma N, Gejyo F, Isemura M, Arakawa M (1989). "Collagen-binding affinity of beta-2-microglobulin, a preprotein of hemodialysis-associated amyloidosis". Nephron. **53** (1): 37–40. doi:10.1159/000185699. PMID 2674742.
- Bataille R, Grenier J, Commes T (1988). "In vitro production of beta 2 microglobulin by human myeloma cells". Cancer Investigation. 6 (3): 271–277. doi:10.3109/07357908809080649. PMID 3048575.
- \* Hönig R, Marsen T, Schad S, Barth C, Pollok M, Baldamus CA (November 1988).

  "Correlation of beta-2-microglobulin concentration changes to changes of distribution volume". The International Journal of Artificial Organs. 11 (6): 459–464. PMID 3060434.
- Bjorkman PJ, Saper MA, Samraoui B, Bennett WS, Strominger JL, Wiley DC (1987). "Structure of the human class I histocompatibility antigen, HLA-A2". Nature. 329 (6139): 506–512. Bibcode: 1987Natur.329..506B. doi:10.1038/329506ao. PMID 3309677. S2CID 4373217.
- Güssow D, Rein R, Ginjaar I, Hochstenbach F, Seemann G, Kottman A, et al. (November 1987). "The human beta 2-microglobulin gene. Primary structure and definition of the transcriptional unit". Journal of Immunology. 139 (9): 3132—3138. doi:10.4049/jimmunol.139.9.3132. PMID 3312414. S2CID 38290153.
- Cunningham BA, Wang JL, Berggård I, Peterson PA (November 1973). "The complete amino acid sequence of beta 2-microglobulin". Biochemistry. 12 (24): 4811–4822. doi:10.1021/bi00748a001. PMID 4586824.
- Suggs SV, Wallace RB, Hirose T, Kawashima EH, Itakura K (November 1981).

  "Use of synthetic oligonucleotides as hybridization probes: isolation of cloned cDNA sequences for human beta 2-microglobulin". Proceedings of the National Academy of Sciences of the United States of America. 78 (11): 6613–6617.

  Bibcode: 1981PNAS...78.6613S. doi:10.1073/pnas.78.11.6613. PMC 349099.

  PMID 6171820.
- Momoi T, Suzuki M, Titani K, Hisanaga S, Ogawa H, Saito A (May 1995). "Amino acid sequence of a modified beta 2-microglobulin in renal failure patient urine and long-term dialysis patient blood". Clinica Chimica Acta; International

- Journal of Clinical Chemistry. **236** (2): 135–144. <u>doi:10.1016/0009-</u>8981(95)06039-G. PMID 7554280.
- \* Collins EJ, Garboczi DN, Karpusas MN, Wiley DC (February 1995). "The three-dimensional structure of a class I major histocompatibility complex molecule missing the alpha 3 domain of the heavy chain". Proceedings of the National Academy of Sciences of the United States of America. 92 (4): 1218–1221.

  Bibcode: 1995PNAS...92.1218C. doi:10.1073/pnas.92.4.1218. PMC 42670.

  PMID 7862664.
- Matoba R, Okubo K, Hori N, Fukushima A, Matsubara K (September 1994). "The addition of 5'-coding information to a 3'-directed cDNA library improves analysis of gene expression". Gene. **146** (2): 199–207. doi:10.1016/0378-1119(94)90293-3. PMID 8076819.