![](_page_0_Picture_4.jpeg)

# **HHS Public Access**

Author manuscript

Methods Mol Biol. Author manuscript; available in PMC 2022 January 01.

Published in final edited form as:

Methods Mol Biol. 2021 ; 2223: 201–215. doi:10.1007/978-1-0716-1001-5\_15.

## **Cellular and Biochemical Analysis of Bronchoalveolar Lavage Fluid from Murine Lungs.**

**Rama Satyanarayana Raju Kalidhindi**1, **Nilesh Sudhakar Ambhore**1, **Venkatachalem Sathish**1,\*

<sup>1</sup>Department of Pharmaceutical Sciences, College of Health Professions, School of Pharmacy, North Dakota State University, Fargo, ND, USA

## **Abstract**

Bronchoalveolar lavage (BAL) is a technique used to collect the contents of the airways. The fluid recovered, called BAL fluid (BALF), serves as a dynamic tool to identify various disease pathologies ranging from asthma to infectious diseases to cancer in the lungs. A wide array of tests can be performed with BALF, including total and differential leukocyte counts (DLC), enzymelinked immunosorbent assays (ELISA) or flow-cytometric quantitation of inflammatory mediators, such as cytokines, chemokines and adhesion molecules, and assessment of nitrate and nitrite content for estimation of nitric oxide synthase (NOS) activity. Here, we describe a detailed procedure for the collection of BALF for a variety of downstream usages, including DLC by cytological and flow-cytometry-based methods, multiplex cytokine analysis by flow cytometry, and NOS activity analysis by determining nitrate and nitrite levels.

#### **Keywords**

Differential leukocyte count; Cytokines; Nitric oxide synthase; Flow cytometry; Tracheostomy

## **1. Introduction**

The lung is considered the most exposed organ in the body for its continuous interactions with external airborne antigens and other toxins [1]. Such constant exposures to exogenous substances at the airway mucosal surface can trigger immunological reactions in the lungs, resulting in disorders such as asthma and chronic obstructive pulmonary disease (COPD) [2, 3, 4, 5, 6, 7, 8]. When interstitial lung disorders are suspected, biopsy is not the first choice for identifying pathological and biochemical changes due to its invasive nature. Bronchoalveolar lavage (BAL) is often performed instead to examine the immune cells present in the lungs and to determine cytokine, chemokine, and adhesion molecule profiles.

BAL is a saline-based wash of the airways first established in 1970 [9, 10, 11]. In humans, it is a minimally invasive procedure to investigate lung pathophysiologies [2, 3, 12, 13, 14, 15, 16, 17] and often used to diagnose patients suffering from interstitial lung disorders [2]. The fluid recovered by BAL is known as BAL fluid (BALF) and contains a multitude of airway

<sup>\*</sup>**Corresponding author**: s.venkatachalem@ndsu.edu.

constituents, including cells, lipids, proteins, and other chemical or biological substances from the mucosal surface of the bronchial tree [18]. Most proteins present in BALF include albumin, immunoglobulin, α1-anti trypsin, transferrin, fibronectin, collagen, and collagenase. In addition, prostaglandins and a few metabolites that are either locally synthesized or reach the lungs via active transport by immunoglobulins or via passive transport by albumin are also found in BALF [4]. The cellular contents of BALF are predominantly leukocytes, with a few exceptions like erythrocytes and platelets [19, 20]. Identifying the pattern and population of differential leukocyte counts (DLC) plays a crucial role in characterizing various lung diseases [10]. In laboratory research using in vivo animal models for various lung disorders [21, 22, 23], BAL serves as an important and most commonly used technique to study inflammatory cell infiltration, biochemical, and molecular changes [2, 24].

Conventionally, DLC is performed by cytological staining of air-dried BALF smears with Wright-Giemsa, May- Grunwald-Giemsa, or Differential-Quik stain [25, 26]. Following staining, 200–500 cells are counted under a microscope and manually classified into neutrophils, eosinophils, macrophages, basophils, etc. However, DLC by this conventional method is prone to human errors and its diagnostic validity may be challenged for yielding false results. In this context, with the advancements of microfluidics technology and abundance of cell-specific antibodies, flow-cytometry-based DLC has become a more rapid and trustworthy tool.

In addition to DLC, BALF has been used for the detection of cytokines, chemokines, and adhesion molecules. However, independent ELISA kits were used to quantify the proteins, which is both time and cost consuming. In contrast, flow-cytometry-based multiplex assays provide a solution to minimize these challenges by facilitating the simultaneous detection of multiple proteins in a single sample. Furthermore, markers used for detecting oxidative stress in the lungs can also be measured in BALF. Oxidative stress plays a crucial role in the pathophysiology of lung disease by generating reactive oxygen species (ROS), which when combined with nitric oxide, forms potent peroxy nitryl radicals, resulting in the nitrosylation of proteins leading to lipid peroxidation [27, 28, 29, 30, 31, 32, 33].

In this chapter, we describe detailed procedures to perform the collection of BALF from mice followed by performing DLC using both conventional cytological and flow-cytometric methods. In addition, we also describe a procedure to assay multiple cytokines in BALF with flow -cytometry using a commercially available multiplex kit. Finally, we describe a method to quantify nitrate and nitrite levels in BALF as an indicator of NOS activity, which suggests the extent of ROS generation in the airways

## **2. Materials**

### **2.1. BALF Collection**

- **1.** Mice: 8–12 weeks old (see Note 1).
- **2.** Anesthetics: Ketamine (100 mg/kg) and xylazine (10 mg/kg) cocktail (9:1 ratio).
- **3.** Sodium Pentobarbital: 100 mg/kg body weight for euthanasia.

- **4.** 18-Gauge cannula: Used for tracheostomy.
- **5.** Surgical thread.
- **6.** Phosphate-buffered saline (PBS) with protease and phosphatase inhibitor: 2.66 mM KCl, 1.47 mM KH2PO4, 137.93 mM NaCl, 8.06 mM Na2HPO4−7H2O, pH ~7.4. Add protease and phosphatase inhibitor cocktail (1×).
- **7.** 2-mL Syringe.
- **8.** Surgical dissection tools: Pointed forceps, serrated forceps, pointed bent scissors, scalpel, and conventional small scissors.
- **9.** Microfuge tubes: 1.5-mL and 2-mL sizes for collection and storage of BALF.
- **10.** Ice in an ice bucket.

#### **2.2. DLC by Cytology**

- **1.** 0.4% (w/v) Trypan blue solution (Cat# 15250061 ThermoFisher) or weigh 0.4 g of trypan blue and dissolve in 100 mL of PBS.
- **2.** Automated or manual cell counter: Countess™ Cell Counting Chamber Slides with Countess II FL Automated Cell Counter or a hemocytometer using a microscope.
- **3.** Cytospin (see Note 2).
- **4.** Glass slides: 25 × 75 × 1.0 mm.
- **5.** Coverslips: 22 × 22 mm.
- **6.** Romanowsky-Giemsa (modified Giemsa) staining kit: Diff-Quik Stain Kit or commercially available equivalent with a fixative (methanol), eosinophilic xanthene dye (eosin Y), and basophilic thiazine dye (methylene blue).
- **7.** Absolute ethanol: Histological grade. Used for dehydration of cells.
- **8.** Xylene.
- **9.** Mounting medium for placing cover slip.
- **10.** Microscope.
- **11.** Cell counter.

#### **2.3. DLC by Flow Cytometry**

- **1.** Flow cytometer: Equipped with two lasers capable of distinguishing 575–585 nm and 660 nm.
- **2.** Flow cytometry data analysis software.
- **3.** 3% (w/v) Bovine serum albumin (BSA): Dissolve 3 g of BSA in 100 mL of PBS.
- **4.** Monoclonal antibody cocktail: Combine antibodies against CD36, CD2, CD19, CD45, and CD294 in PBS at their recommended concentrations (see Table 1 for more details).

**5.** DAPI nuclear stain solution: 100 μg/mL DAPI in PBS. Make the working concentration of DAPI by diluting a 1 mg/mL DAPI stock solution to 1:10 in PBS.

## **2.4. Multiplex Cytokine Assay by Flow Cytometry**

- **1.** Flow cytometer: Equipped with two lasers capable of distinguishing 575–585 nm and 660 nm.
- **2.** Flow cytometry data analysis software.
- **3.** Multichannel pipettors: 5–200 μL.
- **4.** Reagent reservoirs for multichannel pipettors.
- **5.** Mouse cytokine multiplex detection kit: BioLegend 13-plex LEGENDplex™ Inflammation Panel or equivalent (see Note 3).
- **6.** Microplate vacuum manifold or centrifuge: used for washing the filter or Vbottom 96-well plate provided in the multiplex kit.
- **7.** Wash buffer: Thaw the entire container of 20× wash buffer from the multiplex kit and bring to room temperature. Add 475 mL of deionized water to make 1× wash buffer. This solution can be stored at 2– 8 °C for upto 1 month.
- **8.** 1.5-mL Polypropylene microfuge tubes.
- **9.** Refrigerated centrifuge.
- **10.** Vortex mixer.
- **11.** Sonicator bath.
- **12.** Aluminum foil.
- **13.** Paper towels.
- **14.** Plate shaker.

#### **2.5. Nitric Oxide Synthase (NOS) Assay**

- **1.** Reaction buffer: 50 mM HEPES, (4-(2-hydroxyethyl)-1 piperazineethanesulfonic acid) pH 7.4, 5 μM FAD (flavin adenine dinucleotide), 0.1 mM NADPH (nicotinamide adenine dinucleotide phosphate hydrogen), 0.2 U/mL nitrate reductase in 290 μL of distilled water.
- **2.** 1 mM Potassium ferricyanide prepared in Millipore water. Prepare this solution freshly on the day of experiment.
- **3.** Greiss reagent: Dissolve 0.2% (w/v) N-(1-Naphthyl) ethylenediamine (NED), 2% (w/v) sulphanilamide, and 5% (v/v) 95% phosphoric acid in double distilled water and stir it using a magnetic stirrer until the solution appears free of any particles.
- **4.** UV-visible microplate spectrophotometer.

**5.** Clear 96-well plates.

## **3. Methods**

## **3.1. BALF Collection**

**1.** Euthanize mice with an overdose of sodium pentobarbital (100 mg/kg body weight) injected intraperitoneally.

- **2.** Place the mice in supine position and make an incision at the cervical region using surgical scissors (or scalpel) and removing the skin (Fig. 1).
- **3.** Carefully separate the tissues near the thyroid region to either side. Make a vertical incision on the external connective tissue (adventitia) to expose the trachea. Take precautions not to disturb any blood vessels to avoid bleeding (see Note 4).
- **4.** Using a sharp scalpel, make a small horizontal incision on the trachea without severing (see Note 5). Slowly insert an 18-gauge cannula into the trachea, with the needlepoint facing toward the lungs. Secure the cannula in place by tying a surgical thread around the trachea (Fig. 1a, b).
- **5.** Using a 5-mL syringe, slowly inject 1 mL of PBS with protease and phosphatase inhibitor into the cannula. Collect the BALF by slowly drawing the injected PBS back into the syringe (see Note 6). Place the collected BALF in a 2-mL microfuge tube and place it on ice until BALF samples from all mice are collected.
- **6.** After collecting the BALF from all the experimental mice, centrifuge the BALF at 2000 × g for 5 min at 4 °C.
- **7.** Transfer the supernatants into new microfuge tubes (see Note 7). Store them in aliquots of 100 μL at −80 °C until use (see Note 8).
- **8.** Resuspend the cell pellets in 200 μL of PBS and keep at 4 °C until use (see Note 9).

#### **3.2. Total and Differential Leukocyte Counts**

#### **3.2.1. DLC by Cytological Staining**

- **1.** Transfer 20 μL of the cell suspension from Subheading 3.1 step 8 into a microfuge tube and add an equal volume of trypan blue. Mix gently.
- **2.** Place the solution on a Countess™ Cell Counting Chamber Slide and count the total number of cells using Countess II FL Automated Cell Counter. Alternatively, count the cells manually under a microscope using a hemocytometer and a cell counter.
- **3.** Place 100 μL of the cell suspension from Subheading 3.1 step 8 and onto a glass slide. Use a Cytospin to disperse the cells uniformly onto the slide (see Notes 2 and 10).

**4.** Leave the slide at room temperature for 30 min (see Note 11). Fix the air-dried cells for 30 s in the methanol fixative solution provided in the Diff-Quik Stain Kit.

- **5.** Stain the slide with Diff-Quick Solution II for 30 s followed by counterstaining with Solution I for 30 s. Drain well between the stains.
- **6.** Rinse the stained slide in tap water to remove excess stain and dehydrate in absolute ethanol. Place coverslip using two drops of mounting medium.
- **7.** Perform the differential cell count using a digital light microscope at 100× magnification by oil immersion technique. Using a cell counter, count at least 200 cells per slide along a zigzag path, left to right and right to left as shown in Fig. 3.
- **8.** Identify individual cell types based on the color and appearance as described in Table 2 and shown in Fig. 2.

### **3.2.2. DLC by Flow Cytometry**

- **1.** To 100 μL of the BALF cell suspension from Subheading 3.1, step 8, add 100 μL of 3% BSA in PBS and incubate for 1 h at room temperature as a blocking step. Prepare an additional cell sample as a no- stain (no antibodies) control to be used for flow cytometry (see Note 12).
- **2.** Centrifuge the samples at 600 × g for 5 min and discard the supernatant.
- **3.** Resuspend the cell pellet in 80 μL of PBS, add 20 μL of the antibody cocktail (Table 1), and incubate at room temperature for 1 h. Protect the cells from light (see Note 13).
- **4.** Centrifuge the samples at 600 × g for 5 min and discard the supernatant (see Note 14).
- **5.** Resuspend the pellets in PBS and centrifuge at 600 × g for 5 min and discard the supernatant. Repeat this step for one more time.
- **6.** Add 100 μL of the diluted DAPI solution to the cell pellet and incubate for 10 min at room temperature.
- **7.** Wash the cells with PBS and centrifuge the samples at 600 × g for 5 min and discard the supernatant to remove excess DAPI stain.
- **8.** Resuspend the cell pellet in 100 μL of PBS and immediately perform flow cytometry.
- **9.** Set the flow cytometer to capture at least 40,000 nucleated events.
- **10.** Using the no-stain control sample from step 1 on an FSC vs. SSC plot, apply gating to eliminate unstained cells.
- **11.** On an SSC vs. CD45 plot, apply gating to isolate total lymphocyte count.

**12.** Identify T-lymphocytes on a CD45 vs. CD2, where CD2+ cells are Tlymphocytes and CD2− cells are B-lymphocytes. Alternatively, on a CD45 vs. CD19 plot, identify CD19+ as B-lymphocytes and CD19− cells as Tlymphocytes.

- **13.** To identify eosinophils and neutrophils, plot SSC on the x-axis and CD294 on the y-axis. Here, eosinophils appear toward the y-axis and away from the x-axis while neutrophils appear away from the y-axis and toward the x-axis (see Note 15).
- **14.** Determine the number of each cell type in a BALF sample using a flow cytometry data analysis software.

#### **3.3. Multiplex Cytokine Assay by Flow Cytometry**

- **1.** Completely thaw the BALF supernatant from Subheading 3.1, step 7, and keep on ice prior to performing the assay.
- **2.** Create a template for loading the standards and samples (see Table 3).
- **3.** Sonicate the bottle of pre-mixed beads from the multiplex cytokine assay kit for 1 min (see Note 16).
- **4.** Reconstitute the mouse inflammation panel standard cocktail using 250 μL of the assay buffer, keep it at room temperature for 10 min, and label it as C7.
- **5.** Prepare 1:4 dilutions serially in the following sequence: C6, C5, C4, C3, C2, and C1. Use the assay buffer alone for the 0 pg/mL standard.
- **6.** Prior to initiating the assay, wet the wells of the 96-well filter plate with 100 μL of the wash buffer and let it sit at room temperature for 1 min.
- **7.** Remove the wash buffer by placing the filter plate on a vacuum manifold (see Note 17).
- **8.** With the filter plate on an inverted plate lid, first add 25 μL of assay buffer to all the wells, and then add 25 μL of standards prepared at steps 3 and 4, or BALF supernatants to respective standard or sample wells (see Note 18).
- **9.** Briefly vortex the bead mixture for 30 s and add 25 μL to each of the standard and sample wells with the filter plate on the inverted plate lid.
- **10.** Seal the plate with a plate sealer, wrap the plate with aluminum foil, and incubate for 2 h at room temperature on a plate shaker at 500 rpm.
- **11.** Remove the solution as described in step 6 and add 200 μL of the wash buffer to each well on the inverted plate lid (see Note 19).
- **12.** Remove the wash buffer by applying vacuum to the filter plate on the manifold and blot any residual wash buffer using a paper towel.
- **13.** Repeat steps 11 and 12 one more time.

**14.** Add 25 μL of the detection antibody solution from the kit to each well. Seal the plate with a new plate sealer, wrap it with aluminum foil, and incubate for 1 h at room temperature on a plate shaker at 500 rpm.

- **15.** After the 1-h incubation with the detection antibody, add 25 μL of SA-PE from the kit directly to each well. Seal the plate with a new plate sealer, wrap the plate in an aluminum foil and incubate for 30 min at room temperature on a shaker at 500 rpm.
- **16.** Wash the plate twice by repeating steps 11 and 12. Add 150 μL of the wash buffer to each well on the inverted plate lid. Using a plate shaker, shake the plate briefly to resuspend the beads. The beads are ready for flow cytometry and should be analyzed on the same day.
- **17.** Vortex the plate for 5 s and place it on an autosampler.
- **18.** Set the flow rate to low and set the number of beads to be acquired at 300 per sample.
- **19.** Analyze the data using the LEGENDplex™ data analysis software provided with the kit [34] (see Note 20).

#### **3.4. Nitric Oxide Synthase Activity Assay**

- **1.** Completely thaw the BALF supernatants from Subheading 3.1, step 7 and keep on ice prior to performing the assay. Prepare all the reagents freshly on the day of the assay (see Note 21).
- **2.** Prepare another identical set of tubes, omitting nitrate reductase. This sample set is used for determining nitrite content alone.
- **3.** Incubate 100 μL of the BALF supernatant samples with 400 μL of the reaction buffer at 37 °C for 30 min to convert nitrate to nitrite.
- **4.** Add 500 μL of 2 mM potassium ferricyanide to the sample tubes to make the final concentration to 1 mM. Incubate at 25 °C for 10 min to oxidize any unreacted NADPH in the reaction buffer.
- **5.** Add 1 mL of Griess reagent and incubate at 25 °C for 10 min. Read the absorbance at 543 nm (see Note 22). The linear limit of detection for the assay is 1 mM [35].

## **4. Notes**

1. Mice should be housed under constant temperature and a 12-h light/dark cycle with food and water provided ad libitum. All procedures must be conducted in accordance with the National Institutes of Health Guide for the Care and Use of Laboratory Animals and approval by the Institutional Animal Care and use Committee at your institution. Always use personal protective equipment while handling mice or biological samples.

2. If a cytospin is not available, BALF cells may be spread onto the slide by smearing a droplet of cell suspension across the slide with another glass slide held at a 30–45° angle.

- 3. Some multiplex kits offer a choice of either a filter plate or V-bottom plate for the 96-well sample plate. Here we describe a procedure using a filter plate.
- 4. To avoid damaging blood vessels, carefully remove the skin layer and use two blunt forceps to pull apart the thyroid tissue to expose the trachea.
- 5. While performing tracheostomy, be extremely cautious not to disturb any blood vessels near the tracheal incision as it will contaminate the BAL samples and the cellular analysis will be compromised.
- 6. It is almost impossible to extract the whole amount of BAL (1 mL) as there will be a 20% loss, which is expected. Massaging the thorax region may facilitate maximum recovery of the injected PBS. BALF appears as a slightly cloudy solution with clearly visible particulate matter.
- 7. After centrifuging the BALF sample at 600 × g for 5 min, take precaution while separating the supernatant from the cells. Leave the last 50 μL of the supernatant to prevent collecting any cells.
- 8. The supernatant from the BALF samples should be stored at −80 °C until analysis. Avoid repeated freeze–thaw cycles to prevent any degradation of cytokines. It is highly recommended to store the sample in equally divided aliquots of 100 μL each.
- 9. Keep the resuspended cells from BALF samples on ice and process immediately on the same day for DLC to avoid cell loss due to lysis.
- 8. During the cytospin procedure, proper assembling of the slide, filter paper, and the solution-holding accessory is vital. Make sure the openings of all three components align to prevent loss of cells during the centrifuging step. Carefully dismantle the cytospin components to prevent smudging of the smear.
- 9. Do not let the smear dry for more than 30 min.
- 10. The cell suspension for flow analysis should always be placed in a dark container and the tubes need to be wrapped in aluminum foil to prevent bleaching of fluorescent molecules.
- 11. When DLC is performed using flow cytometry, wash the cells thoroughly after the incubation with primary antibodies to avoid any artifacts, which compromise the integrity of data.
- 12. Thereafter, the bottle of beads should be vortexed for 30 s just prior to adding to samples.
- 13. Eosinophils are less granular and hence appear toward the y-axis, whereas neutrophils appear away due to dense granules. In terms of CD-294 staining, eosinophils stain positive for CD294 and appear away from the x-axis, whereas neutrophils stain negative for CD294 and hence appear closer to the x-axis. If the plot

is separated into 4 quadrants, eosinophils appear on the top left quadrant and neutrophils appear on the bottom right quadrant.

- 14. The vacuum pressure should always be set to 10 mmHg to prevent any damage to the filter located at the bottom of the plate.
- 15. Centrifuge the samples and perform the assay with the supernatants to prevent any particulate matters from clogging the bottom of the plate during vacuum application. Perform a protein assay to quantify the protein concentrations of the supernatants and use the same amount of proteins for all samples when performing the cytokine or NOS assays.
- 16. Do not touch the bottom of the well with the pipette tip as you can damage the filter; instead, introduce the samples or any solutions along the sides of the wells.
- 17. If the filter becomes clogged at the bottom, use a pipette to pipette up and down the contents of the well. Clear the bottom of the clogged well with a clean wipe and apply vacuum.
- 18. If the data obtained is not within the standard range, adjust the dilution of the samples and repeat the assay.
- 19. For consistency of the reaction condition, assay all the samples to be compared at the same time.
- 20. If the sample values are too diluted, use a concentrating centrifuge tube like Vivaspin 6 Centrifugal Concentrator and repeat the assay.
- 21. For consistency of the reaction condition, assay all the samples to be compared at the same time.
- 22. If the sample values are too diluted, use a concentrating centrifuge tube like Vivaspin 6 Centrifugal Concentrator and repeat the assay.

## **Acknowledgments**

This work was supported by NIH grants R01-HL123494, R01-HL123494-02S1, R01-HL146705 (Venkatachalem).

## **References**

- 1. Harbeck RJ (1998) Immunophenotyping of bronchoalveolar lavage lymphocytes. Clin Diagn Lab Immunol 5(3):271–277 [PubMed: 9605975]
- 2. Costabel U, Guzman J, Bonella F, Oshimo S (2007) Bronchoalveolar lavage in other interstitial lung diseases. Semin Respir Crit Care Med 28(5):514–524 [PubMed: 17975779]
- 3. Meyer KC, Raghu G, Baughman RP, Brown KK, Costabel U, du Bois RM, Drent M, Haslam PL, Kim DS, Nagai S, Rottoli P, Saltini C, Selman M, Strange C, Wood B, American Thoracic Society Committee on BALiILD (2012) An official American Thoracic Society clinical practice guideline: the clinical utility of bronchoalveolar lavage cellular analysis in interstitial lung disease. Am J Respir Crit Care Med 185(9):1004–1014 [PubMed: 22550210]
- 4. Hunninghake GW, Gadek JE, Kawanami O, Ferrans VJ, Crystal RG (1979) Inflammatory and immune processes in the human lung in health and disease: evaluation by bronchoalveolar lavage. Am J Pathol 97(1):149–206 [PubMed: 495693]

5. Ambhore NS, Katragadda R, Kalidhindi RSR, Thompson MA, Pabelick CM, Prakash Y, Sathish V (2018) Estrogen receptor beta signaling inhibits PDGF induced human airway smooth muscle proliferation. Mol Cell Endocrinol 476:37–47 [PubMed: 29680290]

- 6. Loganathan J, Pandey R, Ambhore NS, Borowicz P, Sathish V (2019) Laser-capture microdissection of murine lung for differential cellular RNA analysis. Cell Tissue Res 376(3):425–432 [PubMed: 30710174]
- 7. Ambhore NSKR, Pabelick CM, Hawse JA, Prakash YS, Sathish V (2019) Differential estrogenreceptor activation regulates extracellular matrix deposition in human airway smooth muscle remodeling via NFκB pathway. FASEB J 33(12):13935–13950 [PubMed: 31638834]
- 8. Kalidhindi RSR, Katragadda R, Beauchamp KL, Pabelick CM, Prakash Y, Sathish V (2019) Androgen receptor-mediated regulation of intracellular calcium in human airway smooth muscle cells. Cell Physiol Biochem 53:215–228 [PubMed: 31299143]
- 9. Chamberlain DW, Braude AC, Rebuck AS (1987) A critical evaluation of bronchoalveolar lavage. Criteria for identifying unsatisfactory specimens. Acta Cytol 31(5):599–605 [PubMed: 3673466]
- 10. Levy H, Horak DA, Lewis MI (1988) The value of bronchial washings and bronchoalveolar lavage in the diagnosis of lymphangitic carcinomatosis. Chest 94(5):1028–1030 [PubMed: 3180853]
- 11. Weynants P, Cordier JF, Cellier CC, Pages J, Loire R, Brune J (1985) Primary immunocytoma of the lung: the diagnostic value of bronchoalveolar lavage. Thorax 40(7):542–543 [PubMed: 3839942]
- 12. Poletti V, Poletti G, Murer B, Saragoni L, Chilosi M (2007) Bronchoalveolar lavage in malignancy. Semin Respir Crit Care Med 28(5):534–545 [PubMed: 17975781]
- 13. Baughman RP, Dohn MN, Loudon RG, Frame PT (1991) Bronchoscopy with bronchoalveolar lavage in tuberculosis and fungal infections. Chest 99(1):92–97 [PubMed: 1898648]
- 14. Yarova PL, Stewart AL, Sathish V, Britt RD Jr, Thompson MA, APP L, Freeman M, Aravamudan B, Kita H, Brennan SC, Schepelmann M, Davies T, Yung S, Cholisoh Z, Kidd EJ, Ford WR, Broadley KJ, Rietdorf K, Chang W, Bin Khayat ME, Ward DT, Corrigan CJ, TW JP, Kemp PJ, Pabelick CM, Prakash YS, Riccardi D (2015) Calcium-sensing receptor antagonists abrogate airway hyperresponsiveness and inflammation in allergic asthma. Sci Transl Med 7(284):284ra60
- 15. Ambhore NS, Kalidhindi RSR, Loganathan J, Venkatachalem S (2019) Role of differential estrogen receptor activation on airway hyperreactivity and remodeling in a murine model of asthma. Am J Respir Cell Mol Biol 61(4):469–480 [PubMed: 30958966]
- 16. Britt RD Jr, Thompson MA, Wicher SA, Manlove LJ, Roesler A, Fang YH, Roos C, Smith L, Miller JD, Pabelick CM, Prakash YS (2019) Smooth muscle brain-derived neurotrophic factor contributes to airway hyperreactivity in a mouse model of allergic asthma. FASEB J 33(2):3024– 3034 [PubMed: 30351991]
- 17. Kalidhindi RSR, Ambhore NS, Bhallamudi S, Loganathan J, Sathish V (2020) Role of estrogen receptors α and β in a murine model of asthma: exacerbated airway hyperresponsiveness and remodeling in ERβ knockout mice. Front Pharmacol 10:1499 [PubMed: 32116656]
- 18. King TE (1992) The handling and analysis of bronchoalveolar lavage specimens In: Baughman RP (ed) Bronchoalveolar lavage. Mosby Year Book, St. Louis, MO, pp 3–29
- 19. Linder J, Rennard SI (1988) Bronchoalveolar lavage. American Society of Clinical Pathologists Press, Chicago, IL
- 20. Stanley M (1991) Qualitative and quantitative cytology in control subjects Bronchoalveolar lavage: cytology and clinical applications. Igaku-Shoin, New York, pp 27–65
- 21. Barrios R (2008) Animal models of lung disease In: Zander DS, Popper HH, Jagirdar J, Haque AK, Cagle PT, Barrios R (eds) Molecular pathology of lung diseases. Springer, New York, NY, pp 144– 149
- 22. Moore B, Lawson WE, Oury TD, Sisson TH, Raghavendran K, Hogaboam CM (2013) Animal models of fibrotic lung disease. Am J Respir Cell Mol Biol 49(2):167–179 [PubMed: 23526222]
- 23. Tashiro J, Rubio GA, Limper AH, Williams K, Elliot SJ, Ninou I, Aidinis V, Tzouvelekis A, Glassberg MK (2017) Exploring animal models that resemble idiopathicp fibrosis. Front Med (Lausanne) 4:118–118 [PubMed: 28804709]

24. Sharma SK, Pande JN, Verma K, Guleria JS (1989) Bronchoalveolar lavage fluid (BALF) analysis in interstitial lung diseases—a 7-year experience. Indian J Chest Dis Allied Sci 31(3):187–196 [PubMed: 2638654]

- 25. (1989) Technical recommendations and guidelines for bronchoalveolar lavage (BAL). Report of the European Society of Pneumology Task Group. Eur Respir J 2(6):561–585 [PubMed: 2663535]
- 26. (1990) Bronchoalveolar lavage constituents in healthy individuals, idiopathic pulmonary fibrosis, and selected comparison groups. The BAL Cooperative Group Steering Committee. Am Rev Respir Dis 141(5 Pt 2):S169–S202 [PubMed: 2186681]
- 27. Kirkham P, Rahman I (2006) Oxidative stress in asthma and COPD: antioxidants as a therapeutic strategy. Pharmacol Ther 111(2):476–494 [PubMed: 16458359]
- 28. Ricciardolo FL, Di Stefano A, Sabatini F, Folkerts G (2006) Reactive nitrogen species in the respiratory tract. Eur J Pharmacol 533(1–3):240–252. [PubMed: 16464450]
- 29. van der Vliet A, Eiserich JP, Shigenaga MK, Cross CE (1999) Reactive nitrogen species and tyrosine nitration in the respiratory tract: epiphenomena or a pathobiologic mechanism of disease? Am J Respir Crit Care Med 160(1):1–9 [PubMed: 10390372]
- 30. Raju KR, Kumar MN, Gupta S, Naga ST, Shankar JK, Murthy V, Madhunapanthula SR, Mulukutla S, Ambhore NS, Tummala S, Vishnuvarthan VJ, Azam A, Elango K (2014) 5-Aminosalicylic acid attenuates allergen-induced airway inflammation and oxidative stress in asthma. Pulm Pharmacol Ther 29(2):209–216 [PubMed: 25101553]
- 31. Raju KR, Ambhore NS, Mulukutla S, Gupta S, Murthy V, Kumar MN, Madhunapantula SR, Kuppuswamy G, Elango K (2016) Salicylic acid derivatives as potential anti asthmatic agents using disease responsive drug delivery system for prophylactic therapy of allergic asthma. Med Hypotheses 87:75–79 [PubMed: 26643666]
- 32. Gupta S, Duraiswamy B, Nataraj SM, Raju R, Babu U, Kumar S, Porwal O, Gupta R (2014) Inhibitory potential of Yucca gloriosa L. extract and isolated gloriosaol isomeric mixture on ovalbumin induced airway hyperresponsiveness in Balb/C mice. Clinic Pharmacol Biopharmaceut 2:002
- 33. Gupta S, Basavan D, Nataraj SKM, Raju KRS, Babu U, Sharath Kumar LM, Gupta R (2014) Assessment of inhibitory potential of Pothos scandens L. on ovalbumin-induced airway hyper responsiveness in balb/c mice. Int Immunopharmacol 18(1):151–162 [PubMed: 24287447]
- 34. Ambigapathy G, Schmit T, Mathur RK, Nookala S, Bahri S, Pirofski LA, Khan MN (2019) Double-edged role of interleukin 17A in Streptococcus pneumoniae pathogenesis during influenza virus coinfection. J Infect Dis 220(5):902–912 [PubMed: 31185076]
- 35. Toward TJ, Broadley KJ (2000) Airway reactivity, inflammatory cell influx and nitric oxide in guinea-pig airways after lipopolysaccharide inhalation. Br J Pharmacol 131(2):271–281 [PubMed: 10991920]

![](_page_12_Picture_5.jpeg)

**Fig. 1.**  Collection of bronchoalveolar lavage (BAL). (a) Image showing tracheostomized mice in supine position. Inset shows magnified area of trachostomy. (b) Lateral view of tracheostomized mice. (c) From left to right: images showing the collection of BAL from tracheostomized mice using syringe connected to the canula

![](_page_13_Picture_5.jpeg)

**Fig. 2.**  Figure showing major leukocytes found in BAL fluid. (**a**) Neutrophil (black circles); (**b**) eosinophil (red circles); (**c**) basophil (orange circles); (**d**) monocyte (green circles), and (**e**) macrophage (purple circles)

![](_page_14_Picture_5.jpeg)

**Fig. 3.**  Representative image showing the pattern of counting cells on a stained BAL smear

Kalidhindi et al. Page 16

**Table 1:** Antibodies (clones) and their working concentrations for identifying different leukocytes in murine BALF.

| Antibody Target | Clone Name | Conjugation      | Cell Type             | Working Concentration         |  |  |
|-----------------|------------|------------------|-----------------------|-------------------------------|--|--|
| CD36            | SMΦ        | Alexa Fluor® 488 | Monocytes/macrophages | 0.4 μg/mL final concentration |  |  |
| CD2             | 3B6        | PE               | T lymphocytes         | 0.4 μg/mL final concentration |  |  |
| CD19            | B-1        | Alexa Fluor® 594 | B lymphocytes         | 0.4 μg/mL final concentration |  |  |
| CD45            | 2D-1       | Alexa Fluor® 680 | Lymphocytes           | 0.4 μg/mL final concentration |  |  |
| CD294 (CRTH2)   | No3m1scz   | Alexa Fluor® 647 | Granulocytes          | 0.4 μg/mL final concentration |  |  |

**Table 2:**

Morphological description of different leukocytes in BALF stained with Diffquik.

| Cell Type   | Color and Appearance                                                                       |
|-------------|--------------------------------------------------------------------------------------------|
| Neutrophils | Have a dark blue multi-lobed nucleus and pale pink cytoplasm with purple granules.         |
| Eosinophils | Have a blue bi-lobed nucleus and cytoplasmic granules varying from red to reddish orange.  |
| Basophils   | Have a purple to dark blue nucleus and black or dark purple granules.                      |
| Monocytes   | Have purple nucleus with sky blue cytoplasm.                                               |
| Macrophages | Have purple nucleus with sky blue cytoplasm as monocytes but larger than other leukocytes. |

**Table 3:**

Sample template for flowcytometric analysis of cytokines in using BioLegend 13-plex LEGENDplex™ Inflammation Panel. C0-C7 are standards and S1-S40 are samples.

|   | A  | B  | C  | D  | E   | F   | G   | H   | I   | J   | K   | L   |
|---|----|----|----|----|-----|-----|-----|-----|-----|-----|-----|-----|
| 1 | C0 | C4 | S1 | S5 | S9  | S13 | S17 | S21 | S25 | S29 | S33 | S37 |
| 2 | C0 | C4 | S1 | S5 | S9  | S13 | S17 | S21 | S25 | S29 | S33 | S37 |
| 3 | C1 | C5 | S2 | S6 | S10 | S14 | S18 | S22 | S26 | S30 | S34 | S38 |
| 4 | C1 | C5 | S2 | S6 | S10 | S14 | S18 | S22 | S26 | S30 | S34 | S38 |
| 5 | C2 | C6 | S3 | S7 | S11 | S15 | S19 | S23 | S27 | S31 | S35 | S39 |
| 6 | C2 | C6 | S3 | S7 | S11 | S15 | S19 | S23 | S27 | S31 | S35 | S39 |
| 7 | C3 | C7 | S4 | S8 | S12 | S16 | S20 | S24 | S28 | S32 | S36 | S40 |
| 8 | C3 | C7 | S4 | S8 | S12 | S16 | S20 | S24 | S28 | S32 | S36 | S40 |