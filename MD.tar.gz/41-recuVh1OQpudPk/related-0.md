## Inflammatory cytokines mediate the induction of and awakening from metastatic dormancy

## Graphical abstract

![](_page_0_Picture_4.jpeg)

## Authors

Paulo Pereira, Joshua Panier, Marc Nater, ..., Paulino Tallo´ n de Lara, Steve Pascolo, Maries van den Broek

### Correspondence

[maries.vandenbroek@uzh.ch](mailto:maries.vandenbroek@uzh.ch)

### In brief

Using a model for breast cancer, Pereira et al. report that the induction of metastatic dormancy in the lungs requires CD8<sup>+</sup> T cells aided by CD4<sup>+</sup> T cells, with IFNg as a key mediator. Awakening depends on inflammatory signals, notably IL-17A, while maintenance of dormancy occurs independently of lymphocyte surveillance.

### Highlights

- <sup>d</sup> T cells and IFNg induce metastatic dormancy
- <sup>d</sup> T and NK cells are dispensable for the maintenance of metastatic dormancy
- <sup>d</sup> IL-17A mediates the awakening of disseminated dormant cancer cells

![](_page_0_Picture_15.jpeg)

![](_page_0_Picture_16.jpeg)

## **Cell Reports**

![](_page_1_Picture_1.jpeg)

#### **Article**

# Inflammatory cytokines mediate the induction of and awakening from metastatic dormancy

Paulo Pereira, Joshua Panier, Marc Nater, Michael Herbst, Anna Laura Calvanese, Hakan Köksal, Héctor Castañón, Virginia Cecconi, Paulino Tallón de Lara, Steve Pascolo, and Maries van den Broek 1,4,\*

<span id="page-1-0"></span><sup>1</sup>Institute of Experimental Immunology, University of Zurich, Zurich, Switzerland

<span id="page-1-4"></span>\*Correspondence: maries.vandenbroek@uzh.ch https://doi.org/10.1016/j.celrep.2025.115388

#### **SUMMARY**

Metastases arise from disseminated cancer cells (DCCs) that detach from the primary tumor and seed distant organs. There, quiescent DCCs can survive for an extended time, a state referred to as metastatic dormancy. The mechanisms governing the induction, maintenance, and awakening from metastatic dormancy are unclear. We show that the differentiation of dormancy-inducing CD8<sup>+</sup> T cells requires CD4<sup>+</sup> T cell help and that interferon (IFN) $\gamma$  directly induces dormancy in DCCs. The maintenance of metastatic dormancy, however, is independent of T cells. Instead, awakening from dormancy requires an inflammatory signal, and we identified CD4<sup>+</sup> T cell-derived interleukin (IL)-17A as an essential wake-up signal for dormant DCCs in the lungs. Thus, the induction of and awakening from metastatic dormancy require an external stimulus, while the maintenance of dormancy does not rely on continuous surveillance by lymphocytes.

#### **INTRODUCTION**

Most of the research in the field of metastasis focuses on aggressive and rapidly metastasizing cancers. In some human cancers, however, the period between the resection of the primary tumor and the appearance of macroscopic metastases can be as long as decades. <sup>1–3</sup> The relevance of this fact is illustrated by the knowledge that approximately two-thirds of breast cancerrelated deaths occur more than 5 years after the removal of the primary tumor. <sup>4</sup>

Those late metastatic relapses are thought to originate from cancer cells that remain quiescent for a long time. This is supported by the finding that disseminated cancer cells (DCCs) are present in a dormant state in the bone marrow of patients with early-stage breast cancer. Moreover, several studies showed that patients who received organs from individuals who had been cured of non-invasive melanoma decades ago can still develop melanomas from donor origin, highlighting the longevity of these quiescent cancer cells.

Although the mechanisms governing dormancy and awakening are largely unknown, several factors that influence the duration of dormancy have been suggested. The tyrosine kinase Src is required for the survival of dormant breast cancer cells, and the transcription factor ZFP281 keeps early DCCs in the lungs in a dormant state. In human carcinoma cell lines, a high p38/ERK ratio is associated with cell-cycle arrest, while a low p38/ERK ratio is observed in proliferating cells. In vivo studies showed that the orphan nuclear receptor NR2F1,

also required for the induction of dormancy, is upregulated in dormant head and neck squamous carcinoma and in disseminated prostate cancer cells in individuals with dormant disease. 11

Despite the importance of cancer cell-intrinsic mechanisms, extracellular signals from the microenvironment also regulate metastatic dormancy. Wnt5a, a protein paradoxically described to have oncogenic and tumor-suppressive functions, <sup>12</sup> induces metastatic dormancy in prostate cancer cells in the lungs, <sup>13</sup> and the bone morphogenic protein 7 induces cell-cycle arrest in prostate cancer stem-like cells in the bone. <sup>14</sup> Similarly, osteopontin stops the proliferation of acute lymphoblastic leukemia cells in the bone marrow, protecting them from chemotherapeutic interventions. <sup>15</sup>

Nevertheless, despite their clinical relevance, the pathways responsible for activating these mechanisms remain unidentified. Even less clear are the pathways and cells responsible for the awakening from metastatic dormancy.

Some factors, such as lipopolysaccharide (LPS)-induced neutrophil extracellular traps, can awaken dormant cancer cells in the lungs, <sup>16</sup> but the role of other immune cells and cytokines in the awakening of dormant cancer cells remains unknown.

Here, we identify the role of adaptive immunity in the production of the cytokines required for the induction of and awakening from metastatic dormancy, whereas the maintenance of metastatic dormancy is independent of T cell surveillance.

![](_page_1_Picture_21.jpeg)

<span id="page-1-2"></span><sup>&</sup>lt;sup>2</sup>Department of Dermatology, University Hospital Zurich, Zurich, Switzerland

<span id="page-1-1"></span><sup>&</sup>lt;sup>3</sup>Present address: Division of Cancer Medicine, The University of Texas MD Anderson Cancer Center, Houston, TX, USA

<span id="page-1-3"></span><sup>&</sup>lt;sup>4</sup>Lead contact

![](_page_2_Picture_0.jpeg)

<span id="page-2-0"></span>![](_page_2_Figure_2.jpeg)

Figure 1. Induction of metastatic dormancy requires CD4+ T cell help

(A) Experimental design. Female BALB/cJRj mice received 0.5 mg isotype or anti-CD4 antibody i.p. at days 1 and +5 relative to the injection of 10<sup>5</sup> 4T07-LZ cells in the mammary fat pad. The lungs and the primary tumor were collected on day 25 to quantify the metastatic burden and characterize intratumoral CD8<sup>+</sup> T cells.

![](_page_3_Picture_2.jpeg)

#### RESULTS

#### Induction of metastatic dormancy requires CD4+ T cell help

We used a preclinical breast cancer model, 4T07, for metastatic dormancy. In this model, cancer cells disseminate from the primary tumor to the lungs, where they persist as quiescent cells.[17](#page-12-5) We recently showed that the induction of metastatic dormancy is mediated by CD8<sup>+</sup> PD-1<sup>+</sup> CD39<sup>+</sup> T cells that produce tumor necrosis factor alpha (TNF-a) and interferon (IFN) g. [18,](#page-12-6)[19](#page-12-7) The generation and maintenance of protective CD8<sup>+</sup> T cells in the context of cancer relies on CD4<sup>+</sup> T cells.[20](#page-12-8) To study the contribution of CD4<sup>+</sup> T cells in the induction of metastatic dormancy, we depleted CD4<sup>+</sup> T cells before and during the priming of CD8<sup>+</sup> T cells by the antigens derived from the primary 4T07-LZ tumor (expressing luciferase and ZsGreen). We then quantified the lung metastatic load 25 days later [\(Fig](#page-2-0)[ure 1A](#page-2-0)). Mice lacking CD4<sup>+</sup> T cells had a significantly higher metastatic burden in the lungs than non-depleted mice [\(Figures 1B](#page-2-0) and 1C), suggesting that CD4<sup>+</sup> T cells are required for the induction of metastatic dormancy. To investigate whether CD4<sup>+</sup> T cells induce dormancy by promoting the development of the dormancy-inducing CD8<sup>+</sup> T cells, we characterized the intratumoral CD8<sup>+</sup> T cells in CD4-depleted (unhelped CD8<sup>+</sup> T cells) and non-depleted (helped CD8<sup>+</sup> T cells) mice using high-dimensional flow cytometry ([Figures 1](#page-2-0)D and 1E). Whereas the frequency of the identified clusters was similar in both experimental conditions, unhelped CD8<sup>+</sup> T cells were nearly bereft of IFNg<sup>+</sup> CD8<sup>+</sup> T effector cells (cluster 1) [\(Figure 1](#page-2-0)F). To determine whether intratumoral CD4<sup>+</sup> T cells, besides providing help to CD8<sup>+</sup> T cells, directly protect against metastases, we tested their anti-tumor activity. Therefore, we intravenously (i.v.) injected tumor-experienced CD4<sup>+</sup> T cells together with 4T07-LZ cells into naive mice and measured the tumor load in the lungs. As controls, we injected helped or unhelped CD8<sup>+</sup> T cells together with tumor cells [\(Figure S1A](#page-10-9)). On day 22, the primary tumors in CD4-depleted mice had progressed more than those in control, isotype-injected mice [\(Figures S1](#page-10-9)B and S1C). This finding confirms our observation that the effector function of unhelped CD8<sup>+</sup> T cells is inferior to that of helped CD8<sup>+</sup> T cells ([Figure 1\)](#page-2-0). We found that three out of four mice adoptively transferred with helped CD8<sup>+</sup> T cells had a lower tumor burden in the lungs than control mice, as opposed to one out of four mice adoptively transferred with CD4<sup>+</sup> T cells ([Figure S1D](#page-10-9)). These results confirm the compromised effector functions of unhelped CD8<sup>+</sup> T cells and, moreover, argue against a direct protective effector function of CD4<sup>+</sup> T cells in this experimental setup.

#### Sensing of IFNg by cancer cells induces metastatic dormancy

To determine whether IFNg acts directly on cancer cells or indirectly via other cells, we generated IFNgR1-deficient 4T07-LZ cells [\(Figure S2](#page-10-9)A). To functionally confirm IFNgR1 deficiency, we analyzed the IFNg-induced expression of PD-L1 on control 4T07-LZ*nt* (non-targeting single-guide [sg]RNA) and 4T07- LZD*Ifngr1*. Our observation that IFNg only induced the expression of PD-L1 in the control cell line confirmed the successful deletion of *Ifngr1* [\(Figure S2](#page-10-9)B). We then orthotopically injected 4T07-LZ*nt* or 4T07-LZD*Ifngr1* cells, monitored tumor growth, and screened the lungs for metastatic outbreaks 21 days later [\(Figure 2A](#page-4-0)). In contrast to control tumors, most IFNgR1-deficient tumors started decreasing in size from day 14 onwards, and several tumors had regressed completely by day 21 [\(Figure 2B](#page-4-0)).

The failure to upregulate PD-L1 in response to IFNg may explain the reduced growth of 4T07-LZD*Ifngr1* primary tumors *in vivo*. Indeed, 4T07-mChD*Ifngr1* cells expressed significantly less PD-L1 *in vivo* than 4T07-mCh*nt* cells ([Figure S2C](#page-10-9)), which may result in better immune control and a consequent decrease in tumor size.

Irrespective of the smaller tumor size, the lungs of mice bearing 4T07-LZD*Ifngr1* tumors contained significantly more DCCs than those of mice with 4T07-LZ*nt* tumors ([Figures 2](#page-4-0)C and 2D), suggesting that sensing of IFNg by DCCs contributes to dormancy. This is further supported by our observation that CD8<sup>+</sup> T cells in IFNgR1-deficient and control 4T07-mCh tumors are phenotypically similar ([Figures S2D](#page-10-9) and S2E).

Altogether, we show that IFNg is the main driver of CD8+ T cellinduced metastatic dormancy of breast cancer.

#### T and NK cells are dispensable for the maintenance of metastatic dormancy

After identifying the essential role of T cells in the induction of metastatic dormancy, we evaluated their role in maintaining dormancy. Therefore, we depleted T cells and analyzed the lungs for metastatic outbreaks. Before depletion, we resected the primary tumor to prevent the continuous influx of DCCs into the lungs ([Figure 3A](#page-5-0)). To confirm that dormant DCCs persist in the lungs after the resection of the primary tumor without any further intervention, we screened the lungs for cancer cells in the lungs 63 days after resection [\(Figure S3A](#page-10-9)). We did not observe any nodules on the surface of the lungs or spontaneous awakening of the DCCs, but we did observe single, non-proliferating cancer cells by immunofluorescence [\(Figures S3B](#page-10-9) and S3C).

The depletion of CD4<sup>+</sup> or CD8<sup>+</sup> T cells did not result in metastatic outbreaks or increase the number of DCCs in the lungs [\(Figures 3](#page-5-0)B and 3C), nor did the simultaneous depletion of CD4<sup>+</sup> and CD8<sup>+</sup> T cells ([Figures S4](#page-10-9)A–S4C). The depletion

<sup>(</sup>B) Quantification of the bioluminescent signal from the lungs. Isotype, *n* = 5; anti-CD4, *n* = 3. Statistical analysis was performed with a Mann-Whitney test. Each symbol represents an individual mouse. Data are shown as the mean ± standard deviation. The experiment is a representative example of 2 independent experiments.

<sup>(</sup>C) Bioluminescence images of the lungs on day 25.

<sup>(</sup>D) Uniform manifold approximation and projection (UMAP) visualization of cytokines, proteins, and markers after gating on single, live, CD45<sup>+</sup> , CD11b, CD3<sup>+</sup> , CD8+ cells. Isotype, *n* = 5; anti-CD4, *n* = 3.

<sup>(</sup>E) Heatmap with the relative expression of the tested markers in the identified clusters.

<sup>(</sup>F) UMAP visualization of the clusters of intratumoral CD8<sup>+</sup> T cells.

![](_page_4_Picture_1.jpeg)

<span id="page-4-0"></span>![](_page_4_Picture_2.jpeg)

![](_page_4_Figure_3.jpeg)

![](_page_4_Figure_4.jpeg)

Figure 2. Sensing of IFNg by cancer cells induces metastatic dormancy

- (A) Experimental design. 4T07-mLZ*nt* = 10; 4T07-LZD*Ifngr1* = 10.
- (B) Growth curves of the primary tumor from day 10 until the endpoint. Each symbol represents the tumor size of a single mouse.
- (C) Quantification of 4T07-LZ in the lungs on day 21. Statistical analysis was performed with a Mann-Whitney test. Each dot represents the density of cancer cells in a randomly chosen location in the lungs. The mean is represented by the dashed line.
- (D) Immunofluorescence images of the lungs on day 21 (scale bars, 50 mm).

![](_page_5_Picture_1.jpeg)

<span id="page-5-0"></span>![](_page_5_Figure_2.jpeg)

![](_page_5_Figure_3.jpeg)

![](_page_5_Figure_4.jpeg)

![](_page_5_Figure_5.jpeg)

![](_page_5_Figure_6.jpeg)

![](_page_5_Figure_7.jpeg)

![](_page_6_Picture_0.jpeg)

of T cells was confirmed by flow cytometry on the blood ([Figure S4](#page-10-9)D).

Because natural killer (NK) cells are also important producers of IFNg, we depleted NK cells for 4 weeks after the resection of the primary tumor, after which we screened the lungs for metastatic outbreaks [\(Figure 3](#page-5-0)D). The depletion of NK cells did not increase the metastatic load in the lungs compared to isotypetreated mice ([Figure 3](#page-5-0)E), suggesting that NK cells are also not required for the maintenance of the dormant phenotype in the DCCs.

Altogether, our data show that NK and T cells are dispensable for the maintenance of metastatic dormancy.

#### LPS-induced inflammation awakens dormant cancer cells

Based on our findings, we proposed that dormant 4T07-mCh cells may not require continuous signals to remain dormant but rather stimuli to awaken, such as inflammation. We used LPS, a well-characterized inflammatory stimulus, to test this hypothesis. Specifically, we repeatedly administered LPS intranasally (i.n.) after resecting the primary tumor and analyzed the lungs for metastatic outbreaks 12 h and 7 days (168 h) after the last LPS administration (endpoint [E]12 and E168, respectively) [\(Fig](#page-7-0)[ure 4A](#page-7-0)). On E12, we observed a trend toward more DCCs in the lungs of LPS-treated mice when compared to the PBS-treated controls [\(Figures 4](#page-7-0)B and 4C). On E168, the number of DCCs in the lungs of LPS-treated mice was significantly higher than in control mice [\(Figures 4](#page-7-0)B and 4C). The observation that a higher proportion of DCCs are cycling in the lungs of LPS-treated mice on E12 ([Figure 4](#page-7-0)C) suggests a proliferative burst that is responsible for the observed awakening.

We reasoned that characterizing the inflammatory molecules in the lungs of LPS-treated mice may identify essential mediators for awakening. Thus, we collected the bronchoalveolar lavage fluid (BALF) on E12 for the quantification of inflammatory cytokines. We measured a higher concentration of TNF-a, interleukin (IL)-6, and IL-17A in the BALF of LPS-treated mice than PBStreated mice, whereas the other cytokines remained at very low concentrations, below the limit of quantification ([Figure 4](#page-7-0)D).

#### IL-17A mediates the awakening of dormant cancer cells

To identify individual awakening factors, we focused on IL-17A. IL-17A is a cytokine produced by several immune cells, such as neutrophils and T cells, and is involved in anti-microbial and antifungal responses.[21](#page-12-9) The constant exposure of the airways to bacteria, spores, and, for smokers, LPS (as a component of tobacco smoke)[22](#page-12-10) makes IL-17A a physiologically relevant cytokine in this context. Therefore, we i.v. injected encapsulated mRNA encoding IL-17A into mice 1 week after the resection of the primary tumor. Then, 6 days after starting the mRNA injections, we analyzed the lungs for metastatic outbreaks and quantified the immune cells in the BALF [\(Figure 5](#page-9-0)A). The production of IL-17A and the lung-targeting capacity of the material were confirmed *in vitro* and *in vivo* ([Figures S5A](#page-10-9) and S5B). There was no difference in the frequency of immune cells in the BALF of control and IL-17A mRNA-treated mice [\(Figure 5B](#page-9-0)), suggesting that IL-17A per se does not recruit immune cells to the lungs.

The lungs of mice treated with liposomes containing IL-17Aencoding mRNA contained significantly more 4T07-mCh cells than the control group ([Figures 5C](#page-9-0) and 5D). Furthermore, a higher proportion of DCCs expressed Ki67 in the IL-17AmRNA-treated group, indicating the proliferation of cancer cells [\(Figures 5](#page-9-0)C and 5D). Thus, the administration of mRNA encoding IL-17A phenocopied LPS administration concerning the awakening of dormant DCCs. This discovery identified IL-17A as a wake-up mediator; however, we cannot exclude that other inflammatory mediators have similar potential.

#### LPS promotes the differentiation of TH17 cells in the lungs

To determine the source of IL-17A after LPS-induced inflammation in the lungs, we harvested and processed the lungs of mice that received PBS or LPS i.n. and stained the resulting single-cell suspension for IL-17A ([Figure 6](#page-11-0)A). We gated on live CD45<sup>+</sup> cells and, for each identified immune population, checked for the production of IL-17A ([Figure S6\)](#page-10-9). At the steady state, neutrophils, CD4, CD8, and gd T cells produced IL-17A, but LPS significantly induced IL-17A production by CD4+ and, to a lesser extent, CD8+ T cells [\(Figure 6](#page-11-0)B). We observed no changes in the production of IL-17A by gd T cells or neutrophils after LPS administration ([Figure 6B](#page-11-0)). To determine the relative contribution of different cell types to the production of IL-17A in the lungs, we gated on IL-17A+ live CD45<sup>+</sup> cells and identified the same 4 major producers: neutrophils, T cell receptor (TCR)ab CD4<sup>+</sup> , TCRab CD8+ , and TCRgd T cells, as well as other cells [\(Figure S7\)](#page-10-9). In the steady state, neutrophils were responsible for 70% of the total IL-17A production, while TCRgd T and TCRab CD4<sup>+</sup> T cells accounted for approximately 6% each ([Figure 6C](#page-11-0)). However, LPS administration drastically increased the relative contribution of TCRab CD4<sup>+</sup> T cells to the IL-17A-producing pool at the expense of neutrophils and other cell types [\(Figure 6](#page-11-0)C). This finding prompted us to characterize the phenotype of lung CD4+ T cells by high-dimensional flow cytometry. We identified a total of 8 clusters, with a significant increase in the frequency of the

#### Figure 3. T and NK cells are dispensable for the maintenance of metastatic dormancy

(A) Experimental design. 4T07-mCh cells (10<sup>5</sup> ) were injected into the mammary fat pad, and the primary tumor was resected on day 21. Mice received 0.5 mg of isotype, anti-CD4, or anti-CD8 antibodies i.p. on days 30 and 42. The lungs were collected on day 56 to quantify the cancer cells by immunofluorescence. Isotype, *n* = 4; anti-CD4, *n* = 5; anti-CD8, *n* = 3.

<sup>(</sup>B) Immunofluorescence images of the lungs on day 56. The experiment is a representative example of 2 independent experiments (scale bars, 50 mm).

<sup>(</sup>C) Quantification of the DCCs in the lungs on day 56. Each dot represents the density of cancer cells in a randomly chosen location in the lungs. Statistical analyses were performed with Brown-Forsythe and Welch ANOVA tests with a Dunnett's T3 multiple comparisons test. The mean is represented by a dashed line. (D) Experimental design. Mice received 50 mg of isotype or anti-asialo-GM1 antibodies i.p. once per week starting 1 week after tumor resection until the endpoint.

On day 56, the lungs were collected for quantification of the metastatic load by IVIS. Isotype, *n* = 4; anti-asialo-GM1, *n* = 5.

<sup>(</sup>E) Quantification of the bioluminescent signal from the lungs. Isotype = 4; anti-asialo-GM-1 = 5. Statistical analysis was performed with a Mann-Whitney test. Each symbol represents an individual mouse. Data are shown as the mean ± standard deviation.

![](_page_7_Picture_1.jpeg)

<span id="page-7-0"></span>![](_page_7_Figure_2.jpeg)

![](_page_8_Picture_0.jpeg)

![](_page_8_Picture_1.jpeg)

subsets expressing RORgt, consistent with a T helper 17 (TH17) phenotype ([Figure 6D](#page-11-0)). Of these, cluster 3 had the highest expression of IL-17A, and this subset was significantly enriched in the LPS condition [\(Figures 6](#page-11-0)D and 6E). These data indicate that LPS promotes the differentiation of CD4<sup>+</sup> T cells into a TH17 phenotype and triggers their production of IL-17A.

#### DISCUSSION

We aimed to identify the mechanisms involved in the different stages of metastatic dormancy, namely induction, maintenance, and awakening. We previously showed that CD8<sup>+</sup> T cells induce metastatic dormancy via the production of IFNg and TNF-a, [18](#page-12-6) but the role of CD4<sup>+</sup> T cells was not addressed. Here, we show that CD4<sup>+</sup> T cells are indispensable for the induction of metastatic dormancy. Our results suggest that the delivery of help to CD8<sup>+</sup> T cells is the major function of CD4<sup>+</sup> T cells in this context, which is in line with previously published data.[23](#page-12-11) It is likely, however, that CD4<sup>+</sup> T cells are an additional source of IFNg. This pleiotropic cytokine acts on hematopoietic and non-hematopoietic cells[24–28](#page-12-12) and is an important regulator of immune defense and homeostasis. In addition, IFNg has direct tumor-restricting effects on cancer cells.[29–32](#page-12-13) By using cancer cells that cannot sense IFNg, we found that the induction of dormancy most likely requires IFNg sensing by cancer cells and not by other cells.

Our observation that dormant DCCs are Ki67 negative suggests that metastatic dormancy is attributed to cell-cycle arrest on the cellular level rather than an equilibrium of proliferation and elimination on the population level. Consequently, after its induction, dormancy likely is a cancer-cell-intrinsic feature. According to this hypothesis, the depletion of NK or T cells should not lead to metastatic outbreaks. Indeed, the depletion of these immune cells did not awaken dormant DCCs, as shown by the absence of Ki67 expression or cluster formation of DCCs in the lungs of depleted mice. It may be unexpected that dormant DCCs are not eliminated by effector T cells but instead persist in the face of adaptive immunity. We explain this observation by the hypothesis that the resection of the primary tumor eliminates the major source of tumor antigens, thus leading to attrition of tumor-specific effector cells. Our hypothesis is supported by the observation that tumor resection is associated with a decreased cytolytic activity in CD8<sup>+</sup> T cells.[33](#page-12-14) The situation for NK cells seems more controversial: a recently published study using 4T07 showed a loss of dormancy in DCCs in the liver after depletion of NK cells,[34](#page-12-15) whereas we did not observe the awakening of DCCs in the lungs after NK cell depletion. A possible explanation for this discrepancy, despite using similar experimental conditions, could be the anatomical and immunological differences between the lungs and the liver. Indeed, the liver contains more NK cells than the lungs.[35](#page-12-16),[36](#page-12-17) The relative paucity of resident NK cells in the lungs may decrease their chance of contact with the rare dormant cancer cells.

The maintenance of dormancy seems to be a cell-autonomous state. In contrast, awakening and resuming proliferation is an active process requiring a stimulus. Because an inflammatory response is a likely event in barrier tissues, we focused on the pro-inflammatory stimulus provided by LPS and found that the inhalation of LPS awoke dormant DCCs. Mechanistically, we identified IL-17A as a factor that mediates the awakening of dormant cancer cells, but we cannot exclude that other mediators may have similar potential. Although many cell types can produce IL-17A,[37](#page-12-18) our results suggest that the local differentiation of CD4<sup>+</sup> T cells into TH17 cells is essential. IL-17A is an important protective cytokine in barrier tissues and is produced in response to fungi,[38](#page-13-0) which are omnipresent in inhaled air[.39](#page-13-1),[40](#page-13-2) Further research is warranted to elucidate how IL-17A mediates the process of awakening dormant DCCs and whether this pathway is unique to IL-17A.

#### Limitations of the study

We discovered that CD4+ T cells and IFNg play a key role in the induction of metastatic dormancy in the lungs. We also found that inflammation caused by LPS increases the concentration of IL-17A, which is mostly produced by TH17 CD4<sup>+</sup> T cells. This IL-17A mediates the awakening of dormant cancer cells. However, we did not explore exactly how IL-17A causes these cells to wake up. We do not know whether the dormant cancer cells directly respond to IL-17A or whether other cells in the area respond to it and then help the cancer cells to wake up. We did not check whether IL-17A is the only factor causing cancer cells to wake up from dormancy. This study was performed using a single mouse breast cancer cell line (4T07). The lack of other models of spontaneous metastatic dormancy induced by T cells precluded a validation of our findings in other experimental systems.

#### RESOURCE AVAILABILITY

#### Lead contact

Further information and requests for resources and reagents should be directed to and will be fulfilled by the lead contact, Maries van den Broek ([vandenbroek@immunology.uzh.ch\)](mailto:vandenbroek@immunology.uzh.ch).

#### Materials availability

The materials generated for this study can be provided upon reasonable request.

#### <span id="page-8-0"></span>Figure 4. LPS-induced inflammation awakens dormant cancer cells

(A) Experimental design. 4T07-mCh cells (10<sup>5</sup> ) were injected into the mammary fat pad, and the primary tumor was resected on day 21, after which mice received 10 mg of LPS or an equivalent volume of PBS intranasally twice per week. The lungs were collected 12 h (E12) and 7 days (E168) after the last intranasal administration for analysis. PBS E12, *n* = 5; LPS E12, *n* = 6; PBS E168, *n* = 5; LPS E168, *n* = 6.

(B) Immunofluorescence images of the lungs on endpoints E12 and E168. Proliferating cancer cells are identified with a red arrow (scale bars, 50 mm).

(C) Quantification of the DCCs in the lungs on endpoints E12 and E168. Each dot represents the density of cancer cells in a randomly chosen location in the lungs. Statistical analyses were performed with Brown-Forsythe and Welch ANOVA tests with a Dunnett's T3 multiple comparisons test. The mean is represented by a dashed line.

(D) Concentration of cytokines in the bronchoalveolar lavage fluid on endpoint E12. The limit of quantification is indicated by a dotted line.

<span id="page-9-0"></span>![](_page_9_Picture_1.jpeg)

![](_page_9_Picture_2.jpeg)

![](_page_9_Figure_3.jpeg)

![](_page_10_Picture_0.jpeg)

![](_page_10_Picture_1.jpeg)

#### Data and code availability

- d All data reported in this paper will be shared by the [lead contact](#page-8-0) upon reasonable request.
- d This paper does not report original codes.
- d Any additional information required to reanalyze the data reported in this paper is available from the [lead contact](#page-8-0) upon reasonable request.

#### ACKNOWLEDGMENTS

This work was supported by the University Research Priority Program ''Translational Cancer Research'' (University of Zurich; M.v.d.B.), SKINTEGRITY.ch (University of Zurich; M.v.d.B.), the Hartmann-Muller Foundation (P.P.), the € Swiss National Science Foundation (310030\_208145; M.v.d.B.), and the Monique-Dornonville-de-la-Cour-Foundation (M.v.d.B.). The authors thank the personnel of the Laboratory Animal Services Center (LASC, University of Zurich) and the Zurich Integrative Rodent Physiology (ZIRP, University of Zurich) for expert animal care. We thank the Flow Cytometry Facility (FCF, University of Zurich) and the Center for Microscopy and Image Analysis (ZMB, University of Zurich) for excellent support. We thank Salome´ LeibundGut-Landmann for providing essential insights for the IL-17A experiments. We thank Conrad Wyss from the Department of Dermatology for assisting in the production of the mRNA.

#### AUTHOR CONTRIBUTIONS

P.P., P.T.d.L., and M.v.d.B. conceived the experiments. P.P. and M.v.d.B. wrote the manuscript. P.P., J.P., A.L.C., H.C., M.H., and V.C. performed experiments and collected and analyzed data. M.N. and H.K. performed part of the analyses. S.P. provided essential reagents. M.v.d.B. secured funding. All authors reviewed the results and approved the final manuscript.

#### DECLARATION OF INTERESTS

The authors declare no competing interests.

#### STAR+METHODS

Detailed methods are provided in the online version of this paper and include the following:

- d [KEY RESOURCES TABLE](#page-14-0)
- d [EXPERIMENTAL MODELS AND STUDY PARTICIPANT DETAILS](#page-16-0)
  - B Animals
  - B Cell lines
- d [METHOD DETAILS](#page-16-1)
  - B *In vivo* procedures
  - B Immunofluorescence
  - B Flow cytometry of tumor/lung samples
  - B Flow cytometry of *in vitro*-cultured cells
- d [QUANTIFICATION AND STATISTICAL ANALYSIS](#page-17-0)

#### <span id="page-10-9"></span>SUPPLEMENTAL INFORMATION

Supplemental information can be found online at [https://doi.org/10.1016/j.](https://doi.org/10.1016/j.celrep.2025.115388) [celrep.2025.115388.](https://doi.org/10.1016/j.celrep.2025.115388)

Received: August 5, 2024 Revised: December 6, 2024 Accepted: February 11, 2025 Published: March 1, 2025

#### REFERENCES

- <span id="page-10-0"></span>1. Dent, R., Trudeau, M., Pritchard, K.I., Hanna, W.M., Kahn, H.K., Sawka, C.A., Lickley, L.A., Rawlinson, E., Sun, P., and Narod, S.A. (2007). Triple-Negative Breast Cancer: Clinical Features and Patterns of Recurrence. Clin. Cancer Res. *13*, 4429–4434. [https://doi.org/10.1158/1078-](https://doi.org/10.1158/1078-0432.CCR-06-3045) [0432.CCR-06-3045](https://doi.org/10.1158/1078-0432.CCR-06-3045).
- 2. Karrison, T.G., Ferguson, D.J., and Meier, P. (1999). Dormancy of Mammary Carcinoma After Mastectomy. J. Natl. Cancer Inst. *91*, 80–85. <https://doi.org/10.1093/jnci/91.1.80>.
- 3. Pedersen, R.N., Esen, B.O¨ ., Mellemkjær, L., Christiansen, P., Ejlertsen, B., Lash, T.L., Nørgaard, M., and Cronin-Fenton, D. (2022). The Incidence of Breast Cancer Recurrence 10-32 Years After Primary Diagnosis. J. Natl. Cancer Inst. *114*, 391–399. [https://doi.org/10.1093/jnci/djab202.](https://doi.org/10.1093/jnci/djab202)
- <span id="page-10-1"></span>4. Klein, C.A. (2011). Framework models of tumor dormancy from patientderived observations. Curr. Opin. Genet. Dev. *21*, 42–49. [https://doi.org/](https://doi.org/10.1016/j.gde.2010.10.011) [10.1016/j.gde.2010.10.011](https://doi.org/10.1016/j.gde.2010.10.011).
- <span id="page-10-2"></span>5. Sa¨ nger, N., Effenberger, K.E., Riethdorf, S., Van Haasteren, V., Gauwerky, J., Wiegratz, I., Strebhardt, K., Kaufmann, M., and Pantel, K. (2011). Disseminated tumor cells in the bone marrow of patients with ductal carcinoma in situ. Int. J. Cancer *129*, 2522–2526. [https://doi.org/10.1002/ijc.](https://doi.org/10.1002/ijc.25895) [25895.](https://doi.org/10.1002/ijc.25895)
- <span id="page-10-3"></span>6. Tjensvoll, K., Oltedal, S., Farmen, R.K., Shammas, F.V., Heikkila¨ , R., Kvaløy, J.T., Gilje, B., Smaaland, R., and Nordga˚rd, O. (2010). Disseminated Tumor Cells in Bone Marrow Assessed by TWIST1, Cytokeratin 19, and Mammaglobin A mRNA Predict Clinical Outcome in Operable Breast Cancer Patients. Clin. Breast Cancer *10*, 378–384. [https://doi.org/10.3816/](https://doi.org/10.3816/CBC.2010.n.050) [CBC.2010.n.050](https://doi.org/10.3816/CBC.2010.n.050).
- <span id="page-10-4"></span>7. MacKie, R.M., Reid, R., and Junor, B. (2003). Fatal Melanoma Transferred in a Donated Kidney 16 Years after Melanoma Surgery. N. Engl. J. Med. *348*, 567–568. [https://doi.org/10.1056/NEJM200302063480620.](https://doi.org/10.1056/NEJM200302063480620)
- <span id="page-10-5"></span>8. Zhang, X.H.F., Wang, Q., Gerald, W., Hudis, C.A., Norton, L., Smid, M., Foekens, J.A., and Massague´ , J. (2009). Latent Bone Metastasis in Breast Cancer Tied to Src-Dependent Survival Signals. Cancer Cell *16*, 67–78. [https://doi.org/10.1016/j.ccr.2009.05.017.](https://doi.org/10.1016/j.ccr.2009.05.017)
- <span id="page-10-6"></span>9. Nobre, A.R., Dalla, E., Yang, J., Huang, X., Wullkopf, L., Risson, E., Razghandi, P., Anton, M.L., Zheng, W., Seoane, J.A., et al. (2022). ZFP281 drives a mesenchymal-like dormancy program in early disseminated breast cancer cells that prevents metastatic outgrowth in the lung. Nat. Cancer *3*, 1165–1180. [https://doi.org/10.1038/s43018-022-00424-8.](https://doi.org/10.1038/s43018-022-00424-8)
- <span id="page-10-7"></span>10. [Aguirre-Ghiso, J.A., Liu, D., Mignatti, A., Kovalski, K., and Ossowski, L.](http://refhub.elsevier.com/S2211-1247(25)00159-7/sref10) [\(2001\). Urokinase Receptor and Fibronectin Regulate the ERK MAPK to](http://refhub.elsevier.com/S2211-1247(25)00159-7/sref10) [P38 MAPK Activity Ratios That Determine Carcinoma Cell Proliferation](http://refhub.elsevier.com/S2211-1247(25)00159-7/sref10) [or Dormancy In Vivo. Mol. Biol. Cell](http://refhub.elsevier.com/S2211-1247(25)00159-7/sref10) *12*, 863–879.
- <span id="page-10-8"></span>11. Sosa, M.S., Parikh, F., Maia, A.G., Estrada, Y., Bosch, A., Bragado, P., Ekpin, E., George, A., Zheng, Y., Lam, H.M., et al. (2015). NR2F1 controls tumour cell dormancy via SOX9- and RARb-driven quiescence programmes. Nat. Commun. *6*, 6170. [https://doi.org/10.1038/ncomms7170.](https://doi.org/10.1038/ncomms7170)

#### Figure 5. IL-17A mediates the awakening of dormant cancer cells

(A) Experimental design. 4T07-mCh cells (10<sup>5</sup> ) were injected into the mammary fat pad, and the primary tumor was resected on day 21. One week after the resection, mice were intravenously injected with PBS or liposomes containing IL-17A mRNA. One day after the last injection, the lungs were collected for quantification of cancer cells. PBS, *n* = 5;liposomal transfection reagent + IL-17A mRNA, *n* = 5.

(B) Frequency of immune cells in the BALF on day 34. Statistical analyses were performed with a Mann-Whitney test. Each symbol represents an individual mouse. Data are shown as the mean ± standard deviation.

(C) Quantification of Ki67⁻ DCCs and Ki67<sup>+</sup> DCCs in the lungs on day 34. Each dot represents the density of cancer cells in a randomly chosen location in the lungs. Statistical analyses were performed with a Mann-Whitney test. The mean is represented by a dashed line.

(D) Immunofluorescence images of the lungs on day 34 (scale bars, 50 mm).

<span id="page-11-0"></span>![](_page_11_Picture_1.jpeg)

![](_page_11_Picture_2.jpeg)

![](_page_11_Figure_3.jpeg)

![](_page_12_Picture_0.jpeg)

![](_page_12_Picture_1.jpeg)

- <span id="page-12-0"></span>12. McDonald, S.L., and Silver, A. (2009). The opposing roles of Wnt-5a in cancer. Br. J. Cancer *101*, 209–214. [https://doi.org/10.1038/sj.bjc.6605174.](https://doi.org/10.1038/sj.bjc.6605174)
- <span id="page-12-1"></span>13. Ren, D., Dai, Y., Yang, Q., Zhang, X., Guo, W., Ye, L., Huang, S., Chen, X., Lai, Y., Du, H., et al. (2019). Wnt5a induces and maintains prostate cancer cells dormancy in bone. J. Exp. Med. *216*, 428–449. [https://doi.org/10.](https://doi.org/10.1084/jem.20180661) [1084/jem.20180661](https://doi.org/10.1084/jem.20180661).
- <span id="page-12-2"></span>14. Kobayashi, A., Okuda, H., Xing, F., Pandey, P.R., Watabe, M., Hirota, S., Pai, S.K., Liu, W., Fukuda, K., Chambers, C., et al. (2011). Bone morphogenetic protein 7 in dormancy and metastasis of prostate cancer stem-like cells in bone. J. Exp. Med. *208*, 2641–2655. [https://doi.org/10.1084/jem.](https://doi.org/10.1084/jem.20110840) [20110840](https://doi.org/10.1084/jem.20110840).
- <span id="page-12-3"></span>15. Boyerinas, B., Zafrir, M., Yesilkanal, A.E., Price, T.T., Hyjek, E.M., and Sipkins, D.A. (2013). Adhesion to osteopontin in the bone marrow niche regulates lymphoblastic leukemia cell dormancy Key Points. [https://doi.org/](https://doi.org/10.1182/blood-2012-12) [10.1182/blood-2012-12](https://doi.org/10.1182/blood-2012-12).
- <span id="page-12-4"></span>16. Albrengues, J., Shields, M.A., Ng, D., Park, C.G., Ambrico, A., Poindexter, M.E., Upadhyay, P., Uyeminami, D.L., Pommier, A., Kuttner, V., et al. € (2018). Neutrophil extracellular traps produced during inflammation awaken dormant cancer cells in mice. Science *361*, eaao4227. [https://](https://doi.org/10.1126/science.aao4227) [doi.org/10.1126/science.aao4227](https://doi.org/10.1126/science.aao4227).
- <span id="page-12-5"></span>17. Aslakson, C.J., McEachern, D., Conaway, D.H., and Miller, F.R. (1991). Inhibition of lung colonization at two different steps in the metastatic sequence. Clin. Exp. Metastasis *9*, 139–150. [https://doi.org/10.1007/](https://doi.org/10.1007/BF01756385) [BF01756385](https://doi.org/10.1007/BF01756385).
- <span id="page-12-6"></span>18. Tallo´ n de Lara, P., Castan˜ o´ n, H., Vermeer, M., Nu´ n˜ ez, N., Silina, K., Sobottka, B., Urdinez, J., Cecconi, V., Yagita, H., Movahedian Attar, F., and Hiltbrunner, S. (2021). CD39+PD-1+CD8+ T cells mediate metastatic dormancy in breast cancer. Nat. Commun. *12*, 769. [https://doi.org/10.](https://doi.org/10.1038/s41467-021-21045-2) [1038/s41467-021-21045-2.](https://doi.org/10.1038/s41467-021-21045-2)
- <span id="page-12-7"></span>19. Tallo´ n de Lara, P., Castan˜ o´ n, H., Sterpi, M., and van den Broek, M. (2022). Antimetastatic defense by CD8+ T cells. Trends Cancer *8*, 145–157. <https://doi.org/10.1016/j.trecan.2021.10.006>.
- <span id="page-12-8"></span>20. Ahrends, T., Spanjaard, A., Pilzecker, B., Ba˛ ba1a, N., Bovens, A., Xiao, Y., Jacobs, H., and Borst, J. (2017). CD4+ T Cell Help Confers a Cytotoxic T Cell Effector Program Including Coinhibitory Receptor Downregulation and Increased Tissue Invasiveness. Immunity *47*, 848–861.e5. [https://](https://doi.org/10.1016/j.immuni.2017.10.009) [doi.org/10.1016/j.immuni.2017.10.009.](https://doi.org/10.1016/j.immuni.2017.10.009)
- <span id="page-12-9"></span>21. Huangfu, L., Li, R., Huang, Y., and Wang, S. (2023). The IL-17 family in diseases: from bench to bedside. Signal Transduct. Target. Ther. *8*, 402. <https://doi.org/10.1038/s41392-023-01620-3>.
- <span id="page-12-11"></span><span id="page-12-10"></span>22. Hasday, J.D., Bascom, R., Costa, J.J., Fitzgerald, T., and Dubin, W. (1999). Bacterial Endotoxin Is an Active Component of Cigarette Smoke. Chest *115*, 829–835. [https://doi.org/10.1378/chest.115.3.829.](https://doi.org/10.1378/chest.115.3.829)
- 23. Wang, J.C.E., and Livingstone, A.M. (2003). Cutting Edge: CD4+ T Cell Help Can Be Essential for Primary CD8+ T Cell Responses In Vivo. J. Immunol. *171*, 6339–6343. [https://doi.org/10.4049/jimmunol.171.](https://doi.org/10.4049/jimmunol.171.12.6339) [12.6339.](https://doi.org/10.4049/jimmunol.171.12.6339)
- <span id="page-12-12"></span>24. Schreiber, R.D., Hicks, L.J., Celada, A., Buchmeier, N.A., and Gray, P.W. (1985). Monoclonal antibodies to murine gamma-interferon which differentially modulate macrophage activation and antiviral activity. J. Immunol. *134*, 1609–1618. <https://doi.org/10.4049/jimmunol.134.3.1609>.

- 25. Abed, N.S., Chace, J.H., Fleming, A.L., and Cowdery, J.S. (1994). Interferon-g Regulation of B Lymphocyte Differentiation: Activation of B Cells Is a Prerequisite for IFN-g-Mediated Inhibition of B Cell Differentiation. Cell. Immunol. *153*, 356–366. <https://doi.org/10.1006/cimm.1994.1034>.
- 26. Bradley, L.M., Dalton, D.K., and Croft, M. (1996). A direct role for IFNgamma in regulation of Th1 cell development. J. Immunol. *157*, 1350– 1358. [http://www.ncbi.nlm.nih.gov/pubmed/8759714.](http://www.ncbi.nlm.nih.gov/pubmed/8759714)
- 27. [Siegel, J.P. \(1988\). Effects of Interferon-y on the Activation of Human T](http://refhub.elsevier.com/S2211-1247(25)00159-7/sref27) [Lymphocytes. Cell. Immunol.](http://refhub.elsevier.com/S2211-1247(25)00159-7/sref27) *111*, 461–472.
- 28. Kammertoens, T., Friese, C., Arina, A., Idel, C., Briesemeister, D., Rothe, M., Ivanov, A., Szymborska, A., Patone, G., Kunz, S., et al. (2017). Tumour ischaemia by interferon-g resembles physiological blood vessel regression. Nature *545*, 98–102. [https://doi.org/10.1038/nature22311.](https://doi.org/10.1038/nature22311)
- <span id="page-12-13"></span>29. Song, M., Ping, Y., Zhang, K., Yang, L., Li, F., Zhang, C., Cheng, S., Yue, D., Maimela, N.R., Qu, J., et al. (2019). Low-Dose IFNg Induces Tumor Cell Stemness in Tumor Microenvironment of Non–Small Cell Lung Cancer. Cancer Res. *79*, 3737–3748. [https://doi.org/10.1158/0008-5472.CAN-](https://doi.org/10.1158/0008-5472.CAN-19-0596)[19-0596](https://doi.org/10.1158/0008-5472.CAN-19-0596).
- 30. Braumuller, H., Wieder, T., Brenner, E., Aßmann, S., Hahn, M., Alkhaled, € M., Schilbach, K., Essmann, F., Kneilling, M., Griessinger, C., et al. (2013). T-helper-1-cell cytokines drive cancer into senescence. Nature *494*, 361–365. [https://doi.org/10.1038/nature11824.](https://doi.org/10.1038/nature11824)
- 31. [Dighe, A.S., Richards, E., Old, L.J., and Schreiber', R.D. \(1994\). Enhanced](http://refhub.elsevier.com/S2211-1247(25)00159-7/sref31) [In Vivo Growth and Resistance to Rejection of Tumor Cells Expressing](http://refhub.elsevier.com/S2211-1247(25)00159-7/sref31) [Dominant Negative IFNy Receptors. Immunity](http://refhub.elsevier.com/S2211-1247(25)00159-7/sref31) *1*, 447–456.
- 32. Boulch, M., Cazaux, M., Cuffel, A., Guerin, M.V., Garcia, Z., Alonso, R., Lema^ıtre, F., Beer, A., Corre, B., Menger, L., et al. (2023). Tumor-intrinsic sensitivity to the pro-apoptotic effects of IFN-g is a major determinant of CD4+ CAR T-cell antitumor activity. Nat. Cancer *4*, 968–983. [https://doi.](https://doi.org/10.1038/s43018-023-00570-7) [org/10.1038/s43018-023-00570-7](https://doi.org/10.1038/s43018-023-00570-7).
- <span id="page-12-14"></span>33. Brown, M.D., Van der Most, R., Vivian, J.B., Lake, R.A., Larma, I., Robinson, B.W.S., and Currie, A.J. (2012). Loss of antigen cross-presentation after complete tumor resection is associated with the generation of protective tumor-specific cd8+ T-cell immunity. OncoImmunology *1*, 1084–1094. <https://doi.org/10.4161/onci.20924>.
- <span id="page-12-15"></span>34. Correia, A.L., Guimaraes, J.C., Auf der Maur, P., De Silva, D., Trefny, M.P., Okamoto, R., Bruno, S., Schmidt, A., Mertz, K., Volkmann, K., et al. (2021). Hepatic stellate cells suppress NK cell-sustained breast cancer dormancy. Nature *594*, 566–571. [https://doi.org/10.1038/s41586-021-](https://doi.org/10.1038/s41586-021-03614-z) [03614-z.](https://doi.org/10.1038/s41586-021-03614-z)
- <span id="page-12-17"></span><span id="page-12-16"></span>35. Gao, B., Jeong, W.I., and Tian, Z. (2008). Liver: An organ with predominant innate immunity. Hepatology *47*, 729–736. [https://doi.org/10.1002/hep.](https://doi.org/10.1002/hep.22034) [22034.](https://doi.org/10.1002/hep.22034)
- 36. Barletta, K.E., Cagnina, R.E., Wallace, K.L., Ramos, S.I., Mehrad, B., and Linden, J. (2012). Leukocyte compartments in the mouse lung: Distinguishing between marginated, interstitial, and alveolar cells in response to injury. J. Immunol. Methods *375*, 100–110. [https://doi.org/10.1016/j.](https://doi.org/10.1016/j.jim.2011.09.013) [jim.2011.09.013](https://doi.org/10.1016/j.jim.2011.09.013).
- <span id="page-12-18"></span>37. Ge, Y., Huang, M., and Yao, Y.M. (2020). Biology of Interleukin-17 and Its Pathophysiological Significance in Sepsis. Front. Immunol. *11*, 1558. [https://doi.org/10.3389/fimmu.2020.01558.](https://doi.org/10.3389/fimmu.2020.01558)

#### Figure 6. LPS induces a TH17 phenotype in CD4<sup>+</sup> T cells

- (A) Experimental design. 4T07-mCh cells (10<sup>5</sup> ) were injected into the mammary fat pad, and the primary tumor was resected on day 21. Mice then received 10 mg of LPS or an equivalent volume of PBS intranasally twice per week. The lungs were collected 7 days after the last intranasal administration for characterization of IL-17A-producing immune cells by flow cytometry. PBS, *n* = 4; LPS, *n* = 5.
- (B) Frequency of T cells and neutrophils that produce IL-17A. Statistical analyses were performed with a Mann-Whitney test. Each symbol represents an individual mouse. Data are shown as the mean ± standard deviation.
- (C) Proportion of IL-17A-producing cells in the lungs on day 50 after PBS or LPS administrations.
- (D) Heatmap with the relative expression of the tested markers.
- (E) Clusters with high expression of RORgt. Statistical analyses were performed with a Mann-Whitney test. Each symbol represents an individual mouse. Data are shown as the mean ± standard deviation.

![](_page_13_Picture_2.jpeg)

- <span id="page-13-0"></span>38. Sparber, F., and LeibundGut-Landmann, S. (2019). Interleukin-17 in Antifungal Immunity. Pathogens *8*, 54. [https://doi.org/10.3390/path](https://doi.org/10.3390/pathogens8020054)[ogens8020054.](https://doi.org/10.3390/pathogens8020054)
- <span id="page-13-1"></span>39. Bauer, H., Schueller, E., Weinke, G., Berger, A., Hitzenberger, R., Marr, I.L., and Puxbaum, H. (2008). Significant contributions of fungal spores to the organic carbon and to the aerosol mass balance of the urban atmospheric aerosol. Atmos. Environ. *42*, 5542–5549. [https://doi.org/10.1016/](https://doi.org/10.1016/j.atmosenv.2008.03.019) [j.atmosenv.2008.03.019](https://doi.org/10.1016/j.atmosenv.2008.03.019).
- <span id="page-13-2"></span>40. Elbert, W., Taylor, P.E., Andreae, M.O., and Po¨ schl, U. (2007). Contribution of fungi to primary biogenic aerosols in the atmosphere: wet and dry discharged spores, carbohydrates, and inorganic ions. Atmos. Chem. Phys. *7*, 4569–4588. <https://doi.org/10.5194/acp-7-4569-2007>.
- <span id="page-13-3"></span>41. Ran, F.A., Hsu, P.D., Wright, J., Agarwala, V., Scott, D.A., and Zhang, F. (2013). Genome engineering using the CRISPR-Cas9 system. Nat. Protoc. *8*, 2281–2308. <https://doi.org/10.1038/nprot.2013.143>.
- <span id="page-13-4"></span>42. Rueden, C.T., Schindelin, J., Hiner, M.C., DeZonia, B.E., Walter, A.E., Arena, E.T., and Eliceiri, K.W. (2017). ImageJ2: ImageJ for the next generation of scientific image data. BMC Bioinform. *18*, 529. [https://doi.org/10.](https://doi.org/10.1186/s12859-017-1934-z) [1186/s12859-017-1934-z.](https://doi.org/10.1186/s12859-017-1934-z)
- <span id="page-13-5"></span>43. Habu, S., Fukui, H., Shimamura, K., Kasai, M., Nagai, Y., Okumura, K., and Tamaoki, N. (1981). In vivo effects of anti-asialo GM1. I. Reduction of NK activity and enhancement of transplanted tumor growth in nude mice. J. Immunol. *127*, 34–38. <http://www.ncbi.nlm.nih.gov/pubmed/7240748>.
- 44. Yoshino, H., Ueda, T., Kawahata, M., Kobayashi, K., Ebihara, Y., Manabe, A., Tanaka, R., Ito, M., Asano, S., Nakahata, T., and Tsuji, K. (2000). Natural killer cell depletion by anti-asialo GM1 antiserum treatment enhances human hematopoietic stem cell engraftment in NOD/Shi-scid mice. Bone Marrow Transplant. *26*, 1211–1216. [https://doi.org/10.1038/sj.bmt.](https://doi.org/10.1038/sj.bmt.1702702) [1702702.](https://doi.org/10.1038/sj.bmt.1702702)
- 45. Pastille, E., Bardini, K., Fleissner, D., Adamczyk, A., Frede, A., Wadwa, M., von Smolinski, D., Kasper, S., Sparwasser, T., Gruber, A.D., et al. (2014). Transient Ablation of Regulatory T cells Improves Antitumor Immunity in Colitis-Associated Colon Cancer. Cancer Res. *74*, 4258–4269. [https://](https://doi.org/10.1158/0008-5472.CAN-13-3065) [doi.org/10.1158/0008-5472.CAN-13-3065](https://doi.org/10.1158/0008-5472.CAN-13-3065).
- 46. Burrack, K.S., Tan, J.J.L., McCarthy, M.K., Her, Z., Berger, J.N., Ng, L.F.P., and Morrison, T.E. (2015). Myeloid Cell Arg1 Inhibits Control of Arthritogenic Alphavirus Infection by Suppressing Antiviral T Cells. PLoS Pathog. *11*, e1005191. [https://doi.org/10.1371/journal.ppat.1005191.](https://doi.org/10.1371/journal.ppat.1005191)
- 47. Vashist, N., Trittel, S., Ebensen, T., Chambers, B.J., Guzma´ n, C.A., and Riese, P. (2018). Influenza-Activated ILC1s Contribute to Antiviral Immunity Partially Influenced by Differential GITR Expression. Front. Immunol. *9*, 505. [https://doi.org/10.3389/fimmu.2018.00505.](https://doi.org/10.3389/fimmu.2018.00505)
- 48. Moynihan, K.D., Opel, C.F., Szeto, G.L., Tzeng, A., Zhu, E.F., Engreitz, J.M., Williams, R.T., Rakhra, K., Zhang, M.H., Rothschilds, A.M., et al.

- (2016). Eradication of large established tumors in mice by combination immunotherapy that engages innate and adaptive immune responses. Nat. Med. *22*, 1402–1410. [https://doi.org/10.1038/nm.4200.](https://doi.org/10.1038/nm.4200)
- 49. Budda, S.A., and Zenewicz, L.A. (2018). IL-22 deficiency increases CD4 T cell responses to mucosal immunization. Vaccine *36*, 3694–3700. <https://doi.org/10.1016/j.vaccine.2018.05.011>.
- 50. Balogh, K.N., Templeton, D.J., and Cross, J.V. (2018). Macrophage Migration Inhibitory Factor protects cancer cells from immunogenic cell death and impairs anti-tumor immune responses. PLoS One *13*, e0197702. [https://doi.org/10.1371/journal.pone.0197702.](https://doi.org/10.1371/journal.pone.0197702)
- <span id="page-13-6"></span>51. Liu, S., Cheng, Q., Wei, T., Yu, X., Johnson, L.T., Farbiak, L., and Siegwart, D.J. (2021). Membrane-destabilizing ionizable phospholipids for organselective mRNA delivery and CRISPR–Cas gene editing. Nat. Mater. *20*, 701–710. <https://doi.org/10.1038/s41563-020-00886-0>.
- <span id="page-13-7"></span>52. Di, J., Huang, P., and Chen, X. (2024). Targeting Strategies for Site-Specific mRNA Delivery. Bioconjug. Chem. *35*, 453–456. [https://doi.org/](https://doi.org/10.1021/acs.bioconjchem.4c00038) [10.1021/acs.bioconjchem.4c00038](https://doi.org/10.1021/acs.bioconjchem.4c00038).
- <span id="page-13-8"></span>53. Tusup, M., French, L.E., De Matos, M., Gatfield, D., Kundig, T., and Pascolo, S. (2019). Design of in vitro Transcribed mRNA Vectors for Research and Therapy. Chimia *73*, 391–394. [https://doi.org/10.2533/chimia.](https://doi.org/10.2533/chimia.2019.391) [2019.391.](https://doi.org/10.2533/chimia.2019.391)
- <span id="page-13-9"></span>54. Melsen, J.E., van Ostaijen-ten Dam, M.M., Lankester, A.C., Schilham, M.W., and van den Akker, E.B. (2020). A Comprehensive Workflow for Applying Single-Cell Clustering and Pseudotime Analysis to Flow Cytometry Data. J. Immunol. *205*, 864–871. [https://doi.org/10.4049/jimmunol.](https://doi.org/10.4049/jimmunol.1901530) [1901530.](https://doi.org/10.4049/jimmunol.1901530)
- <span id="page-13-10"></span>55. Brummelman, J., Haftmann, C., Nu´ n˜ ez, N.G., Alvisi, G., Mazza, E.M.C., Becher, B., and Lugli, E. (2019). Development, application and computational analysis of high-dimensional fluorescent antibody panels for single-cell flow cytometry. Nat. Protoc. *14*, 1946–1969. [https://doi.org/10.](https://doi.org/10.1038/s41596-019-0166-2) [1038/s41596-019-0166-2](https://doi.org/10.1038/s41596-019-0166-2).
- <span id="page-13-11"></span>56. McInnes, L., Healy, J., and Melville, J. (2018). UMAP: Uniform Manifold Approximation and Projection for Dimension Reduction. Preprint at arxiv. [http://arxiv.org/abs/1802.03426.](http://arxiv.org/abs/1802.03426)
- <span id="page-13-12"></span>57. Becht, E., McInnes, L., Healy, J., Dutertre, C.A., Kwok, I.W.H., Ng, L.G., Ginhoux, F., and Newell, E.W. (2018). Dimensionality reduction for visualizing single-cell data using UMAP. Nat. Biotechnol. *37*, 38–44. [https://doi.](https://doi.org/10.1038/nbt.4314) [org/10.1038/nbt.4314](https://doi.org/10.1038/nbt.4314).
- <span id="page-13-13"></span>58. Levine, J.H., Simonds, E.F., Bendall, S.C., Davis, K.L., Amir, E.a.D., Tadmor, M.D., Litvin, O., Fienberg, H.G., Jager, A., Zunder, E.R., et al. (2015). Data-Driven Phenotypic Dissection of AML Reveals Progenitorlike Cells that Correlate with Prognosis. Cell *162*, 184–197. [https://doi.](https://doi.org/10.1016/j.cell.2015.05.047) [org/10.1016/j.cell.2015.05.047.](https://doi.org/10.1016/j.cell.2015.05.047)

![](_page_14_Picture_0.jpeg)

![](_page_14_Picture_1.jpeg)

#### STAR+METHODS

#### KEY RESOURCES TABLE

<span id="page-14-0"></span>

| REAGENT or RESOURCE                                | SOURCE                 | IDENTIFIER                        |
|----------------------------------------------------|------------------------|-----------------------------------|
| Antibodies                                         |                        |                                   |
| Anti-CTLA4 in APC-AR700 (clone UC10-4F10-11)       | BD Biosciences         | Cat# 565778, RRID:AB_2739350      |
| Anti-IFNg in BUV737 (clone XMG1.2)                 | BD Biosciences         | Cat# 612769, RRID:AB_2870098      |
| Anti-Lag3 in BV421 (clone C9B7W)                   | BioLegend              | Cat# 125221, RRID:AB_2572080      |
| Anti-Ki67 in BV480 (clone B56)                     | BD Biosciences         | Cat# 566109, RRID:AB_2739511      |
| Anti-KLRG1 in APC-Cy7 (clone 2F1/KLRG1)            | BioLegend              | Cat# 138426, RRID:AB_2566554      |
| Anti-Eomes in PE-eFluor610 (clone Dan11mag)        | Invitrogen             | Cat# 61-4875-82, RRID:AB_2574614  |
| Anti-Tbet in PE-Cy7 (clone eBio4B10)               | Invitrogen             | Cat# 25-5825-82, RRID:AB_11042699 |
| Anti-TNFa in BV711 (clone MP6-XT22)                | BioLegend              | Cat# 506349, RRID:AB_2629800      |
| Anti-PD-1 in BV785 (clone 29F.1A12)                | BioLegend              | Cat# 135225, RRID:AB_2563680      |
| Anti-PD-1 in PE-Cy7 (clone RMP1-30)                | BioLegend              | Cat# 109110, RRID:AB_572017       |
| Anti-CD107a in FITC (clone 1D4B)                   | BioLegend              | Cat# 121606, RRID:AB_572007       |
| Anti-TOX in PE (clone TXRX10)                      | Invitrogen             | Cat# 12-6502-82, RRID:AB_10855034 |
| Anti-CD39 in PerCP-eFluor710 (clone 24DMS1)        | Invitrogen             | Cat# 46-0391-82, RRID:AB_10717953 |
| Anti-CD39 in PE-Dazzle594 (clone Duha59)           | BioLegend              | Cat# 143812, RRID:AB_2750322      |
| Anti-TCRgd in APC (clone eBioGL3)                  | Invitrogen             | Cat# 17-5711-82, RRID:AB_842756   |
| Anti-IL-17A in FITC (clone TC11-18H10)             | BioLegend              | Cat# 506908, RRID:AB_536010       |
| Anti-IL-17A in APC (clone TC11-18H10)              | BioLegend              | Cat# 506916, RRID:AB_536018       |
| Anti-RORgt in BV421 (clone Q31-378)                | BD Biosciences         | Cat# 562894, RRID:AB_2687545      |
| Anti-CD4 in BUV496 (clone GK1.5)                   | BD Biosciences         | Cat# 612952, RRID:AB_2813886      |
| Anti-CD45 in BUV563 (clone 30-F11)                 | BD Biosciences         | Cat# 612924, RRID:AB_2870209      |
| Anti-CD11b in BUV661 (clone M1/70)                 | BD Biosciences         | Cat# 612977, RRID:AB_2870249      |
| Anti-CD8 in BUV805 (clone 53-6.7)                  | BD Biosciences         | Cat# 612898, RRID:AB_2870186      |
| Anti-F4/80 in BV785 (clone BM8)                    | BioLegend              | Cat# 123141, RRID:AB_2563667      |
| Anti-SiglecF in PE-CF594 (clone E50-2440)          | BD Biosciences         | Cat# 562757, RRID:AB_2687994      |
| Anti-SiglecF in Super Bright 645 (clone 1RNM44N)   | Invitrogen             | Cat# 64-1702-82, RRID:AB_2688082  |
| Anti-Ly6G in APC (clone 1A8)                       | BioLegend              | Cat# 127614, RRID:AB_2227348      |
| Anti-Ly6G in BV510 (clone 1A8)                     | BioLegend              | Cat# 127633, RRID:AB_2562937      |
| Anti-CD3 in APC-Cy7 (clone 17A2)                   | BioLegend              | Cat# 100222, RRID:AB_2242784      |
| Anti-PD-L1 in APC (clone 10F.9G2)                  | BioLegend              | Cat# 124312, RRID:AB_10612741     |
| Anti-PD-L1 in PE-Cy7 (clone 10F.9G2)               | BioLegend              | Cat# 124314, RRID:AB_10643573     |
| Anti-IFNGR1 in BV421 (clone GR20)                  | BD Biosciences         | Cat# 740032, RRID:AB_2739804      |
| Anti-TIM3 in BV650 (clone 5D12)                    | BD Biosciences         | Cat# 747623, RRID:AB_2744189      |
| Anti-Granzyme B in PE-Dazzle594 (clone QA16A02)    | BioLegend              | Cat# 372216, RRID:AB_2728383      |
| Anti-CD4 (clone GK1.5)                             | BioXCell               | Cat# BE0003-1 RRID:AB_1107636     |
| Anti-CD8 (clone YTS 169.4)                         | BioXCell               | Cat# BE0117 RRID:AB_10950145      |
| Anti-KLH (clone LTF-2)                             | BioXCell               | Cat# BE0090, RRID:AB_1107780      |
| Rabbit IgG (isotype)                               | Invitrogen             | Cat# 10500C, RRID:AB_2532981      |
| Rabbit anti-asialo-GM1 (polyclonal)                | Invitrogen             | Cat# 16-6507-39, RRID:AB_10718540 |
| Rabbit anti-luciferase (polyclonal)                | Sigma-Aldrich          | Cat# L0159, RRID:AB_260379        |
| Goat anti-mCherry (polyclonal)                     | SICGEN                 | Cat# AB0040, RRID:AB_2333093      |
| Rabbit anti-Ki67 (monoclonal)                      | abcam                  | Cat# ab16667, RRID:AB_302459      |
| Rat anti-CD45 in CoraLite<br>Plus 647 (monoclonal) | Proteintech            | Cat# CL647-65087, RRID:AB_2883673 |
| Donkey anti-goat in Alexa Fluor 594 (polyclonal)   | Jackson ImmunoResearch | Cat# 705-585-147, RRID:AB_2340433 |
| Donkey anti-rabbit in Alexa Fluor 488 (polyclonal) | Jackson ImmunoResearch | Cat# 711-545-152, RRID:AB_2313584 |

(*Continued on next page*)

![](_page_15_Picture_2.jpeg)

| Continued                                                              |                                                                                              |                                                                |
|------------------------------------------------------------------------|----------------------------------------------------------------------------------------------|----------------------------------------------------------------|
| REAGENT or RESOURCE                                                    | SOURCE                                                                                       | IDENTIFIER                                                     |
| Chemicals, peptides, and recombinant proteins                          |                                                                                              |                                                                |
| Mouse IFNg                                                             | Peprotech                                                                                    | 315–05                                                         |
| D-Luciferin                                                            | Promega                                                                                      | P1043                                                          |
| LPS (E. coli O111:B4)                                                  | Merck                                                                                        | L2630                                                          |
| DOTAP                                                                  | Merck                                                                                        | 11202375001                                                    |
| Roti-Histofix 4%                                                       | Roth                                                                                         | P087.4                                                         |
| O.C.T.TM                                                               | Tissue-Tek                                                                                   | 4583                                                           |
| FastDigest BpiI (IIs class)                                            | Thermo Fisher Scientific                                                                     | FD1014                                                         |
| Water for Molecular Biology                                            | AppliChem                                                                                    | A7398,0500                                                     |
| ProlongDiamond medium                                                  | Invitrogen                                                                                   | P36961                                                         |
| Foxp3/Transcription Factor Staining Buffer Set                         | eBioscience                                                                                  | 00-5523-00                                                     |
| Critical commercial assays                                             |                                                                                              |                                                                |
| LEGENDplexTM MU Th Cytokine Panel (12-plex) w/VbP V03                  | BioLegend                                                                                    | 741044                                                         |
| Lipofectamine<br>3000 Transfection Kit                                 | Invitrogen                                                                                   | L3000-008                                                      |
| Experimental models: Cell lines                                        |                                                                                              |                                                                |
| 4T07                                                                   | Laboratory of Fred Miller                                                                    | RRID:CVCL_B383                                                 |
| 4T07-mCh                                                               | This paper                                                                                   | N/A                                                            |
| 4T07-LZ                                                                | This paper                                                                                   | N/A                                                            |
| 4T07-mChnt-sgRNA                                                       | This paper                                                                                   | N/A                                                            |
| 4T07-LZnt-sgRNA                                                        | This paper                                                                                   | N/A                                                            |
| 4T07-mChIfngr1 KO                                                      | This paper                                                                                   | N/A                                                            |
| 4T07-LZIfngr1 KO                                                       | This paper                                                                                   | N/A                                                            |
| Experimental models: Organisms/Strains                                 |                                                                                              |                                                                |
| BALB/cJRj mouse                                                        | Janvier Labs                                                                                 | N/A                                                            |
| Oligonucleotides                                                       |                                                                                              |                                                                |
| sgRNA DNA sequence for the nt-sgRNA:<br>GAAATGTGAGATCAGAGTAAT          | This paper                                                                                   | N/A                                                            |
| sgRNA DNA sequence for the knockout<br>of Ifngr1: GCGGGCCCATTCCTGCGCGA | This paper                                                                                   | N/A                                                            |
| Recombinant DNA                                                        |                                                                                              |                                                                |
| pSpCas9(BB)-2A-GFP (PX458)                                             | Ran et al.41                                                                                 | Addgene plasmid #48138                                         |
| Software and algorithms                                                |                                                                                              |                                                                |
| Living Image                                                           | Revvity                                                                                      | RRID:SCR_014247                                                |
| ImageJ2                                                                | Rueden et al.42                                                                              | https://imagej.net/software/imagej2/                           |
| Rstudio                                                                | RStudio Team (2021). RStudio:                                                                | RRID:SCR_000432                                                |
|                                                                        | Integrated Development<br>Environment for R. RStudio,<br>Version 1.4.1717<br>PBC, Boston, MA |                                                                |
| inForm                                                                 | Akoya Biosciences                                                                            | https://www.akoyabio.com/<br>phenoimager/inform-tissue-finder/ |
| Phenochart                                                             | Akoya Biosciences                                                                            | https://www.akoyabio.com/<br>software-data-analysis/           |
| FlowJo                                                                 | FlowJoTM Software,<br>Version 10.7.1, Ashland 2023                                           | RRID: SCR_008520                                               |
| Other                                                                  |                                                                                              |                                                                |
| Autoclip wound clips                                                   | Ethicon                                                                                      | 427631                                                         |
| 5-0 Coated Vicryl stitches                                             | BD Biosciences                                                                               | V303H                                                          |
| Fentanyl                                                               | Kantonsapotheke Zurich                                                                       | N/A                                                            |

![](_page_16_Picture_0.jpeg)

![](_page_16_Picture_1.jpeg)

#### <span id="page-16-0"></span>EXPERIMENTAL MODELS AND STUDY PARTICIPANT DETAILS

#### Animals

Eight-to-ten-week-old female BALB/cJRj mice were purchased from Janvier (Roubaix, FR). Mice were housed under specific pathogen-free conditions in individually ventilated cages at the Laboratory Animal Services Center (LASC), University of Zurich. Mice had access to food and water *ad libitum* and were kept in a 12-h light/dark cycle. All experiments were performed according to the Swiss cantonal and federal regulations on animal protection and approved by the Cantonal Veterinary Office Zurich under the license ZH026/2021.

#### Cell lines

4T07 cells (female sex) were cultured in Dulbecco's Modified Eagle's Medium (DMEM, Gibco) supplemented with 5% fetal bovine serum (FBS), 2 mM L-glutamine, 100 U/mL penicillin and 100 mg/mL streptomycin. The cells were cultured at 37C in a humid atmosphere with 5% CO2.

4T07 cells were lentivirally transduced to express mCherry or luciferase-ZsGreen (4T07-mCh and 4T07-LZ, respectively), as described.[18](#page-12-6) The *Ifngr1* gene was deleted in 4T07-mCh and 4T07-LZ cells by CRISPR/Cas9a technology. Briefly, the plasmid pSpCas9(BB)-2A-GFP (PX458)[41](#page-13-3) was digested with BpiI and a DNA oligonucleotide coding for a sgRNA specific for *Ifngr1* (or not specific for any sequence of the mouse genome – non-targeting sgRNA) was annealed to the digested plasmid. The resulting plasmid was transfected into 4T07-mCh and 4T07-LZ cells with the Lipofectamine 3000 Transfection Reagent.

All cells were expanded, frozen in aliquots and stored in the gas phase of liquid nitrogen. Only cells of early passages were used for experiments. Cells were tested negative for *Mycoplasma* ssp. by PCR analysis. Cells were also tested negative for 18 additional mouse pathogens by PCR (IMPACT II Test, IDEXX Bioanalytics).

#### <span id="page-16-1"></span>METHOD DETAILS

#### In vivo procedures

One hundred thousand 4T07 cells or derivatives were orthotopically injected into the 4th right mammary fat pad in 50 mL of sterile PBS. Health checks were conducted twice per week. The tumor area was measured with a digital caliper as width x length.

For intravenous (i.v.) injection, 2.5 x 10<sup>4</sup> 4T07-LZ and 5 3 10<sup>4</sup> T cells were injected in 100 mL sterile PBS. For the depletion of CD4<sup>+</sup> cells, 500 mg anti-CD4 (clone GK1.5) were intraperitoneally (i.p.) injected. For the depletion of CD8<sup>+</sup> cells, 500 mg of anti-CD8 (clone YTS 169.4) were i.p. injected. For the depletion of NK cells, 50 mg of anti-asialo-GM1 (polyclonal) were i.p. injected. As a control, 500 mg of anti-KLH or 50 mg of rabbit IgG isotype control were i.p. injected. Antibodies were administered in 100 mL sterile PBS. We confirmed the efficacy of the depletions by flow cytometry, as have numerous other publications.[43–50](#page-13-5)

Macro-metastases of 4T07-LZ in the lungs were quantified using an IVIS200 imaging system (PerkinElmer). Mice were i.p. injected with 150 mg/kg of D-Luciferin and the photon flux was measured 20 min later. For *ex vivo* IVIS, mice were euthanized 18 min after the i.p. injection of D-Luciferin and the photon flux from the dissected lungs was measured immediately after.

For the resection of the primary tumor, mice were anesthetized with 3% isoflurane and given a pre-emptive, subcutaneous injection of 0.04 mg/kg of fentanyl. The area around the tumor was shaved and disinfected, and the tumor was resected. Next, the anterior part of the wound was closed with wound clips. The posterior part of the wound was stitched to ensure mobility. The wound was disinfected and the mice were subcutaneously injected with 0.1 mg/kg of buprenorphine. Mice had *ad libitum* access to water with 10 mg/mL of buprenorphine for 48 h following surgery. Based on the tumor size at resection, mice were allocated to an experimental group. The average tumor size between experimental groups was identical after randomization. This was validated by performing an unpaired t test or one-way ANOVA with Tukey's multiple comparisons test (for experiments with 2 or 3 groups, respectively) and obtaining non-significant *p* values.

For the awakening experiments, mice were anesthetized with 3% isoflurane and intranasally (i.n.) received 10 mg LPS in 50 mL of sterile PBS or 50 mL of PBS as described for each experiment.

To collect bronchial alveolar lavage fluid (BALF), mice were euthanized and the lungs were resected. Lungs were inflated with 1 mL of PBS containing 2 mM EDTA and the BALF was collected by aspiration. The BALF was centrifuged at 350 *g* for 5 min. The concentration of cytokines in the supernatant of the BALF was measured with a LEGENDplex kit, while the pellet from the BALF was stained for flow cytometry, as described below.

For preparation of encapsulated mRNA, 90 mL of 1 mg/mL DOTAP (N-(2,3-Dioleoyloxy-1-propyl)trimethylammonium methyl sulfate) were mixed with 10 mL of 1 mg/mL mRNA at room temperature. This formulation with DOTAP has been described to predominantly home to the lungs.[51,](#page-13-6)[52](#page-13-7) The structure of the mRNA is as described by Tusup et al.[53](#page-13-8) The following mRNAs were used: IL-17A and luciferase. The resulting 100 mL of the liposomal complex were i.v. injected as described for each experiment.

#### Immunofluorescence

Lungs were resected, inflated with 2 mL of 4% formaldehyde, incubated in a tube with 10 mL of 4% formaldehyde for 15 min at room temperature, and transferred to a 15% sucrose in PBS. After overnight incubation at 4C, the lungs were incubated with 30% sucrose in PBS for 2 days at 4C. The lungs were then cryoembedded in Optimal Cutting Temperature (O.C.T.) Compound using a slurry with

# **Cell Reports**

![](_page_17_Picture_2.jpeg)

dry ice/100% ethanol. The frozen lungs were stored at -80°C. Ten-μm-thick sections were cut using a cryotome, mounted on glass slides, dried for 1 h at 37°C, and stored at -80°C until staining.

For immunofluorescence staining, the slides were thawed and dried at 37°C for 30 min and fixed with 4% formaldehyde for 10 min. After washing with PBS, the slides were incubated for 10 min with PBS containing 4% BSA and 0.01% Triton X-100 to prevent unspecific binding. The slides were then washed with PBS containing 0.05% Tween 20 and incubated overnight with primary antibodies diluted in PBS containing 1% BSA at 4°C in a humidified chamber. The following day, the slides were washed with PBS containing 0.05% Tween 20 and incubated with secondary antibodies for 1 h at room temperature in a humidified chamber. Then, the slides were washed with PBS containing 0.05% Tween 20 and stained in 100 μL of 4',6 diamidine-2-phenylindole (DAPI) (0.5 μg) for 5 min. The slides were washed with PBS containing 0.05% Tween 20 and mounted with ProlongDiamond medium. The slides were scanned using the automated multispectral microscopy system Vectra 3.0 (PerkinElmer). A slide stained with the primary antibody specific for mCherry and all the secondary antibodies was used to generate the spectral profile of autofluorescence of the lungs. The multispectral images (MSIs) of each scanned slide were randomly chosen on Phenochart based solely on the expression of DAPI, to ensure the analysis was performed in an unbiased way. An average of 45 MSIs were taken per slide. The MSIs were then analyzed with inForm by performing a spectral unmixing of the individual fluorophores, adaptive tissue segmentation, cell segmentation, and phenotyping of the different cell populations. MSIs with clear immunoprecipitation regions were discarded from analysis to prevent false positives. ImageJ2 was used to determine the scale bar of each MSI.<sup>42</sup>

#### Flow cytometry of tumor/lung samples

Mice were euthanized and the primary tumors or lungs were collected in complete RPMI (RPMI supplemented with 5% fetal bovine serum, 2 mM L-glutamine, 100 U/mL penicillin and 100 µg/mL streptomycin). The tissues were cut into small pieces and digested for 45 min at 37°C in complete RPMI supplemented with 1 mg/mL collagenase IV and 2.6 μg/mL of DNase I on a rotating wheel. After digestion, the samples were washed with PBS, mechanically disaggregated, and filtered through 70-µm filters. The filters were washed with PBS and the samples were centrifuged at 350 g for 5 min. The pellet was resuspended in 2 mL of red blood cell lysis buffer (9 g NH<sub>4</sub>Cl, 1.1 g KHCO<sub>3</sub>, 0.37 g EDTA in 100 mL of water) for 2 min to remove the erythrocytes. After washing with PBS, the cells were surface-stained with 50 µL of antibody mix diluted in PBS. For intracellular staining of cytokines, cells were stimulated for 4 h at 37°C with 100 ng/mL of phorbol 12-myristate 13-acetate (PMA), 1 μg/mL of ionomycin, 1 μg/mL Brefeldin A and 1 μg/mL monensin. Non-stimulated samples were incubated under the same conditions with Brefeldin A and monensin only. After incubation, cells were surface-stained for 30 min at 4°C, washed with PBS and then fixed for 45 min at 4°C. The cells were washed with permeabilization buffer and stained overnight at 4°C with the intracellular antibody mix in permeabilization buffer. The following day, the cells were washed with permeabilization buffer, resuspended in PBS, and acquired using a CyAn ADP9 flow cytometer (Beckman Coulter), FACS LSRII Fortessa (BD Biosciences) or Cytek Aurora (5L) (Cytek).

#### Flow cytometry of in vitro-cultured cells

To functionally validate the knockout of the  $\mathit{lfngr1}$  gene,  $4\mathsf{T07}-\mathsf{LZ}^{nt}$ ,  $4\mathsf{T07}-\mathsf{LZ}^{\Delta\mathit{lfngr1}}$ ,  $4\mathsf{T07}-\mathsf{mCh}^{nt}$  and  $4\mathsf{T07}-\mathsf{mCh}^{nt}$  cells were incubated with 20 ng/mL of mouse IFNγ for one day. In the following day, the cells were surface-stained for PD-L1 at 4°C for 30 min and then washed with PBS. Changes in the expression of PD-L1 were measured by flow cytometry with FACS LSRII Fortessa (BD Biosciences).

To validate both the functionality of the IL-17A mRNA and of the delivery system with DOTAP, HEK-293T cells were incubated for 24 h with 100 μL of PBS or 100 μL of the liposomal complex containing IL-17A mRNA. The following day, the cells were incubated for 4 h at 37°C with 1 μg/mL Brefeldin A and 1 μg/mL monensin. After incubation, the cells were surface-stained for 30 min at 4°C, washed with PBS and then fixed for 45 min at 4°C. The cells were washed with permeabilization buffer and stained in permeabilization buffer overnight at 4°C for the detection of IL-17A. The following day, the cells were washed with permeabilization buffer, resuspended in PBS, and acquired in FACS LSRII Fortessa (BD Biosciences).

#### <span id="page-17-0"></span>**QUANTIFICATION AND STATISTICAL ANALYSIS**

Group sizes and replications are provided in the figure legends. FCS files from flow cytometry were preprocessed using FlowJo. Data from compensated cell populations of interest were exported as new FCS files and imported into R. Arcsinh transformation followed by quantile normalization (1st and 99th quantile as boundaries) was applied to raw marker intensities. 54,55 Dimensionality reduction was performed using the uniform manifold approximation and projection (UMAP) algorithm.<sup>56,57</sup> Unsupervised clustering was achieved using the RPhenograph algorithm.<sup>58</sup> Visualizations were created using the ggplot2 R package. R version 4.1.0 and Bioconductor version 3.16 were used.

All immunofluorescence slides were scanned with Vectra 3.0.5 imaging system and the resulting MSIs were analyzed with inForm 2.4.6.

All figures were plotted and statistically analyzed using GraphPad Prism version 10.

Statistical tests were performed as stated in each figure legend. Significance was defined as p values inferior to 0.05.