# Influenza A virus - WikiProjectMed

![](_page_0_Picture_1.jpeg)

#### Structure of influenza A virus

![](_page_0_Picture_3.jpeg)

TEM micrograph of influenza A viruses

|             | Virus classification |  |  |  |
|-------------|----------------------|--|--|--|
|             |                      |  |  |  |
| (unranked): | <u>Virus</u>         |  |  |  |
| Realm:      | Riboviria            |  |  |  |

|          | Subtypes            |
|----------|---------------------|
| Species: | Influenza A virus   |
| Genus:   | Alphainfluenzavirus |
| Family:  | Orthomyxoviridae    |
| Order:   | Articulavirales     |
| Class:   | Insthoviricetes     |
| Phylum:  | Negarnaviricota     |
| Kingdom: | Orthornavirae       |

Influenza A virus (IAV) causes <u>influenza</u> in birds and some <u>mammals</u>, and is the only <u>species</u> of the <u>genus</u> Alphainfluenzavirus of the virus family <u>Orthomyxoviridae</u>. <u>Strains</u> of all subtypes of influenza A virus have been isolated from wild birds, although disease is uncommon. Some <u>isolates</u> of influenza A virus cause severe disease both in domestic poultry and, rarely, in humans. Occasionally, viruses are transmitted from wild aquatic birds to domestic poultry, and this may cause an outbreak or give rise to human influenza pandemics.

Influenza A viruses are <u>negative-sense</u>, single-stranded, segmented <u>RNA viruses</u>. The several subtypes are labeled according to an H number (for the type of <u>hemagglutinin</u>) and an N number (for the type of <u>neuraminidase</u>). There are 18 different known H <u>antigens</u> (H1 to H18) and 11 different known N antigens (N1 to N11). H17N10 was isolated from <u>fruit bats</u> in 2012. H18N11 was discovered in a Peruvian bat in 2013.

A filtered and purified influenza A vaccine for humans has been developed and many countries have stockpiled it to allow a quick administration to the population in the event of an <u>avian influenza pandemic</u>. Avian influenza is sometimes called avian flu, and colloquially, bird flu. In 2011, researchers reported the discovery of <u>an antibody</u> effective against all types of the influenza A virus.

# Structure and genetics

Influenza type A viruses are very similar in structure to influenza viruses types B, C, and D. The virus particle (also called the virion) is 80–120 nanometers in diameter such that the smallest virions adopt an elliptical shape. The length of each particle varies considerably, owing to the fact that influenza is pleomorphic, and can be in excess of many tens of micrometers, producing filamentous virions. Confusion about the nature of influenza virus pleomorphy stems from the observation that lab adapted strains typically lose the ability to form filaments and that these lab adapted strains were the first to be visualized by electron microscopy. Despite these varied shapes, the virions of all influenza type A viruses are similar in composition. They are all made up of a viral envelope containing two main types of proteins, wrapped around a central core.

The two large proteins found on the outside of viral particles are hemagglutinin (HA) and neuraminidase (NA). HA is a protein that mediates binding of the virion to target cells and entry of the viral genome into the target cell. NA is involved in release from the abundant non-productive attachment sites present in mucus as well as the release of progeny virions from infected cells. These proteins are usually the targets for antiviral drugs. Furthermore, they are also the antigen proteins to which a host's antibodies can bind and trigger an immune response. Influenza type A viruses are categorized into subtypes based on the type of these two proteins on the surface of the viral envelope. There are 16 subtypes of HA and 9 subtypes of NA known, but only H 1, 2 and 3, and N 1 and 2 are commonly found in humans.

The central core of a virion contains the viral genome and other viral proteins that package and protect the genetic material. Unlike the genomes of most organisms (including humans, animals, plants, and bacteria) which are made up of double-stranded DNA, many viral genomes are made up of a different, single-stranded nucleic acid called RNA. Unusually for a virus, though, the influenza type A virus genome is not a single piece of RNA; instead, it consists of segmented pieces of negative-sense RNA, each piece containing either one or two genes which code for a gene product (protein). The term negative-sense RNA just implies that the RNA genome cannot be translated into protein directly; it must first be transcribed to positive-sense RNA before it can be translated into protein products. The segmented nature of the genome allows for the exchange of entire genes between different viral strains.

![](_page_2_Picture_3.jpeg)

![](_page_3_Picture_0.jpeg)

A transmission electron micrograph (TEM) of the reconstructed 1918 pandemic influenza virus. The bottom structure represents membrane debris from the cells used to amplify the virus. Pictured are the 'elliptical' particles representing the smallest particles produced by influenza virus. Purification techniques often deform the particles without proper fixation protocols, leading to 'spherical' appearance. (Filamentous or intermediate sized particles simply extend along the long axis on the opposite side of the genome segments.)

![](_page_3_Figure_2.jpeg)

![](_page_4_Figure_0.jpeg)

viral Ribonucleoprotein Complex (vRNP)

#### Influenza A virus structure

![](_page_4_Figure_3.jpeg)

Influenza A virus replication cycle

The entire Influenza A virus genome is 13,588 bases long and is contained on eight RNA segments that code for at least 10 but up to 14 proteins, depending on the strain. The relevance or presence of alternate gene products can vary:

- Segment 1 encodes RNA polymerase subunit (PB2).
- \* C -----------------------------------

Segment 2 encodes KINA polymerase subunit (PB1) and the PB1-F2 protein, which induces cell death, by using different reading frames from the same RNA segment.

- Segment 3 encodes RNA polymerase subunit (PA) and the PA-X protein, which has a role in host transcription shutoff.
- Segment 4 encodes for HA (hemagglutinin). About 500 molecules of hemagglutinin are needed to make one virion. HA determines the extent and severity of a viral infection in a host organism.
- \* Segment 5 encodes NP, which is a nucleoprotein.
- Segment 6 encodes NA (neuraminidase). About 100 molecules of neuraminidase are needed to make one virion.
- Segment 7 encodes two matrix proteins (M1 and M2) by using different reading frames from the same RNA segment. About 3,000 matrix protein molecules are needed to make one virion.
- Segment 8 encodes two distinct non-structural proteins (NS1 and NEP) by using different reading frames from the same RNA segment.

The RNA segments of the viral genome have complementary base sequences at the terminal ends, allowing them to bond to each other with hydrogen bonds. Transcription of the viral (-) sense genome (vRNA) can only proceed after the PB2 protein binds to host capped RNAs, allowing for the PA subunit to cleave several nucleotides after the cap. This host-derived cap and accompanied nucleotides serve as the primer for viral transcription initiation. Transcription proceeds along the vRNA until a stretch of several uracil bases is reached, initiating a 'stuttering' whereby the nascent viral mRNA is polyadenylated, producing a mature transcript for nuclear export and translation by host machinery.

The RNA synthesis takes place in the cell nucleus, while the synthesis of proteins takes place in the cytoplasm. Once the viral proteins are assembled into virions, the assembled virions leave the nucleus and migrate towards the cell membrane. The host cell membrane has patches of viral transmembrane proteins (HA, NA, and M2) and an underlying layer of the M1 protein which assist the assembled virions to budding through the membrane, releasing finished enveloped viruses into the extracellular fluid. The subtypes of influenza A virus are estimated to have diverged 2,000 years ago. Influenza viruses A and B are estimated to have diverged from a single ancestor around 4,000 years ago, while the ancestor of influenza viruses A and B and the ancestor of influenza virus C are estimated to have diverged from a common ancestor around 8,000 years ago.

### Replication

Typically influenza is transmitted from infected birds through their droppings. Out of a

host, flu viruses can remain infectious for about one week at human body temperature, over 30 days at 0 °C (32 °F), and indefinitely at very low temperatures.

The viruses bind to a cell through interactions between its <a href="https://example.com/hemagglutinin">hemagglutinin</a> glycoprotein and <a href="mailto:sialic acid">sialic acid</a> sugars on the surfaces of <a href="mailto:epithelial cells">epithelial cells</a> in the lung and throat. The cell imports the virus by <a href="mailto:endosome">endocytosis</a>. In the acidic <a href="endosome">endosome</a>, part of the hemagglutinin protein fuses the viral envelope with the vacuole's membrane, releasing the viral RNA molecules, accessory proteins and <a href="mailto:RNA">RNA</a>-dependent RNA polymerase into the <a href="mailto:cytoplasm">cytoplasm</a>. These proteins and vRNA form a complex that is transported into the <a href="mailto:cell nucleus">cell nucleus</a>, where the RNA-dependent RNA polymerase begins transcribing complementary positive-sense cRNA . The cRNA is either exported into the cytoplasm and translated , or remains in the nucleus. Newly synthesised viral proteins are either secreted through the <a href="mailto:Golgi-apparatus">Golgi-apparatus</a> onto the cell surface or transported back into the nucleus to bind vRNA and form new viral genome particles

# **Multiplicity reactivation**

Influenza virus is able to undergo multiplicity reactivation after inactivation by UV radiation, or by ionizing radiation. If any of the eight RNA strands that make up the genome contains damage that prevents replication or expression of an essential gene, the virus is not viable when it alone infects a cell, which is a single infection. However, when two or more damaged viruses infect the same cell, which is multiple infection, viable progeny viruses can be produced provided each of the eight genomic segments is present in at least one undamaged copy.

Upon infection, influenza virus induces a host response involving increased production of reactive oxygen species, and this can damage the virus genome. If, under natural conditions, virus survival is ordinarily vulnerable to the challenge of oxidative damage, then multiplicity reactivation is likely selectively advantageous as a kind of genomic repair process. It has been suggested that multiplicity reactivation involving segmented RNA genomes may be similar to the earliest evolved form of sexual interaction in the RNA world that likely preceded the DNA world.

# Subtypes and variants

![](_page_6_Picture_6.jpeg)

![](_page_7_Figure_0.jpeg)

Diagram of influenza nomenclature

Influenza type A viruses are <u>RNA viruses</u> categorized into subtypes based on the type of two <u>proteins</u> on the surface of the viral envelope:

- H = hemagglutinin, a protein that causes red blood cells to agglutinate.
- N = <u>neuraminidase</u>, an enzyme that cleaves the <u>glycosidic bonds</u> of the monosaccharide sialic acid

The hemagglutinin is central to the virus's recognizing and binding to target cells, and also to its then infecting the cell with its <u>RNA</u>. The neuraminidase, on the other hand, is critical for the subsequent release of the daughter virus particles created within the infected cell so they can spread to other cells.

Different influenza viruses encode for different hemagglutinin and neuraminidase proteins. For example, the <a href="H5N1 virus">H5N1 virus</a> designates an influenza A subtype that has a type 5 hemagglutinin (H) protein and a type 1 neuraminidase (N) protein. There are 18 known types of hemagglutinin and 11 known types of neuraminidase, so, in theory, 198 different combinations of these proteins are possible. Some variants are identified and named according to the isolate they resemble, thus are presumed to share lineage (example <a href="Fujian flu">Fujian flu</a> virus-like); according to their typical host (example <a href="human flu">human flu</a> virus); according to their subtype (example H3N2); and according to their deadliness (example LP, low pathogenic). So a flu from a virus similar to the isolate A/Fujian/411/2002(H3N2) is called <a href="Fujian">Fujian</a> flu. Several variants use this naming convention.

Variants have also sometimes been named according to their deadliness in poultry, especially chickens:

Low pathogenic avian influenza (LPAI)

Highly pathogenic avian influenza (HPAI), also called deadly flu or death flu

#### Annual flu

The annual flu (also called "seasonal flu" or "human flu") in the US "results in approximately 36,000 deaths and more than 200,000 hospitalizations each year. In addition to this human toll, influenza is annually responsible for a total cost of over \$10 billion in the U.S.""Contemporary human H3N2 influenza viruses are now <a href="endemic">endemic</a> in pigs in southern China and can <a href="mailto:reasort">reassort</a> with avian <a href="H5N1">H5N1</a> viruses in this intermediate host."

#### Human influenza virus

![](_page_8_Figure_4.jpeg)

Timeline of flu pandemics and epidemics caused by influenza A virus

![](_page_9_Figure_0.jpeg)

Human cases and fatalities caused by different influenza A virus subtypes

"Human influenza virus" usually refers to those subtypes that spread widely among humans. H1N1, H1N2, and H3N2 are the only known influenza A virus subtypes currently circulating among humans. Genetic factors in distinguishing between "human flu viruses" and "avian influenza viruses" include:

- \* PB2: (RNA polymerase): <u>Amino acid</u> (or <u>residue</u>) position 627 in the PB2 protein encoded by the PB2 RNA gene. Until H5N1, all known avian influenza viruses had a <u>Glu</u> at position 627, while all human influenza viruses had a <u>lysine</u>.
- HA: (hemagglutinin): Avian influenza HA binds alpha 2-3 sialic acid receptors, while human influenza HA binds alpha 2-6 sialic acid receptors.

Human flu symptoms usually include fever, cough, <u>sore throat</u>, <u>muscle aches</u>, <u>conjunctivitis</u> and, in severe cases, breathing problems and <u>pneumonia</u> that may be fatal. The severity of the infection will depend in large part on the state of the infected person's <u>immune system</u> and if the victim has been exposed to the strain before, and is therefore

partially immune. Follow-up studies on the impact of <u>statins</u> on influenza virus replication show that pre-treatment of cells with atorvastatin suppresses virus growth in culture. Highly pathogenic H5N1 avian influenza in a human is far worse, killing 50% of humans who catch it. In one case, a boy with H5N1 experienced <u>diarrhea</u> followed rapidly by a coma without developing respiratory or flu-like symptoms. The influenza A virus subtypes that have been confirmed in humans, ordered by the number of known human pandemic deaths, are:

- H1N1 caused "Spanish flu" in 1918 and the 2009 swine flu pandemic
- \* H2N2 caused "Asian flu" in the late 1950s
- H3N2 caused "Hong Kong flu" in the late 1960s
- <u>H5N1</u> is considered a global <u>influenza pandemic</u> threat through <u>its spread</u> in the mid-2000s
- H7N9 is responsible for a 2013 epidemic in China.
- \* H7N7 has some zoonotic potential: it has rarely caused disease in humans
- \* H1N2 is currently endemic in pigs and has rarely caused disease in humans
- H9N2, H7N2, H7N3, H5N2, H10N7, H10N3, and H5N8

#### H<sub>1</sub>N<sub>1</sub>

H1N1 was responsible for the 2009 pandemic in both human and pig populations. A variant of H1N1 was responsible for the Spanish flu pandemic that killed some 50 million to 100 million people worldwide over about a year in 1918 and 1919. .

Controversy arose in October 2005, after the H1N1 genome was published in a journal, because of fears that this information could be used for bioterrorism.

#### H<sub>1</sub>N<sub>2</sub>

H<sub>1</sub>N<sub>2</sub> is endemic in pig populations and has been documented in a few human cases.

#### H2N2

The Asian flu, a pandemic outbreak of H2N2 avian influenza, originated in China in 1957, spread worldwide that same year during which an influenza vaccine was developed, lasted until 1958 and caused between one and four million deaths.

![](_page_10_Picture_15.jpeg)

![](_page_11_Picture_0.jpeg)

Influenza virus that caused the Hong Kong flu

#### H<sub>3</sub>N<sub>2</sub>

H<sub>3</sub>N<sub>2</sub> is endemic in both human and pig populations. It evolved from H<sub>2</sub>N<sub>2</sub> by antigenic shift and caused the Hong Kong flu pandemic of 1968, and 1969, that killed up to 750,000.

A severe form of the H3N2 virus killed several children in the United States in late 2003.

The dominant strain of annual flu in January 2006 was H3N2. Measured resistance to the standard antiviral drugs amantadine and rimantadine in H3N2 increased from 1% in 1994 to 12% in 2003 to 91% in 2005.

Human H<sub>3</sub>N<sub>2</sub> influenza viruses are endemic in pigs in southern China, where they circulate together with avian H<sub>5</sub>N<sub>1</sub> viruses.

![](_page_11_Figure_7.jpeg)

Highly-pathogenic avian influenza (HPAI) Highly-pathogenic avian influenza (HPAI) is a severe form of bird flu that can quickly spread and cause deadly disease in poultry.
 Some cases have also been recorded in humans, particularly from H5N1 and H7N9 flu strains, and have had a high case fatality rate.

#### H<sub>5</sub>N<sub>1</sub>

Research has shown that a highly contagious strain of H5N1, one that might allow airborne transmission between mammals, can be reached in only a few mutations, raising concerns about a pandemic and bioterrorism.

As of 31 January, 2025 the widespread impact of the virus has infected over 138 million birds across all 50 states(U.S.) and has spread to millions more in other continents. This has also affected more than 500 species, which includes 485 avian and 70 mammal speciesOn 24 February the CDC confirmed 70 human cases and seven probable cases.

As of June 2025 several other countries have had human cases including Cambodia with 4 cases and Bangladesh with 2 cases

#### H<sub>5</sub>N<sub>2</sub>

Japan's Health Ministry said January 2006 that poultry farm workers in Ibaraki prefecture may have been exposed to H5N2 in 2005. The H5N2 antibody titers of paired sera of 13 subjects increased fourfold or more.

#### H<sub>5</sub>N8

In February 2021, Russia reported the first known cases of H5N8 in humans. Seven people were confirmed to have been infected in December 2020 and have since recovered. There was no indication of human-to-human transmission.

#### H5N9

A highly pathogenic strain of H5N9 caused a minor <u>flu</u> outbreak in 1966 in <u>Ontario</u> and <u>Manitoba</u>, <u>Canada</u> in <u>turkeys</u>.

#### H7N2

One person in New York in 2003, and one person in <u>Virginia</u> in 2002, were found to have serologic evidence of infection with H7N2.

#### H7N3

In North America, the presence of avian influenza strain H7N3 was confirmed at several poultry farms in British Columbia in February 2004. As of April 2004, 18 farms had been quarantined to halt the spread of the virus. Two cases of humans with avian influenza have been confirmed in that region. "Symptoms included conjunctivitis and mild influenza-like illness."

conjunctivitio una mina minacina macinimisco.

#### H7N7

H7N7 has unusual zoonotic potential. In 2003 in the Netherlands, 89 people were confirmed to have H7N7 influenza virus infection following an outbreak in poultry on several farms. One death was recorded.

#### H7N9

On 2 April 2013, the <u>Centre for Health Protection</u> (CHP) of the Department of Health of Hong Kong confirmed four more cases in <u>Jiangsu</u> province in addition to the three cases initially reported on 31 March 2013. This virus also has the greatest potential for an influenza pandemic among all of the Influenza A subtypes.

On 16 March 2025 it was reported that the U.S. had detected the first outbreak of H7N9 bird flu since 2017. The outbreak occurred at a poultry farm in Noxubee, Mississippi.

#### H<sub>9</sub>N<sub>2</sub>

Low pathogenic avian influenza A (H9N2) infection was confirmed in 1999, in China and Hong Kong in two children, and in 2003 in Hong Kong in one child. All three fully recovered.

#### H<sub>10</sub>N<sub>7</sub>

In 2004, in <u>Egypt</u>, H10N7 was reported for the first time in humans. It caused illness in two infants in Egypt. One child's father was a poultry merchant.

#### H<sub>10</sub>N<sub>3</sub>

In May 2021, in **Zhenjiang**, China H10N3 was reported for the first time in humans. One person was infected.

#### Other animals

See <u>H5N1</u> for the <u>epizootic</u> (an epidemic in nonhumans) and panzootic (a disease affecting animals of many species especially over a wide area) of H5N1 influenza

#### Avian influenza

<u>Fowl</u> act as natural <u>asymptomatic carriers</u> of influenza A viruses. Prior to the H<sub>5</sub>N<sub>1</sub> epizootic, strains of influenza A virus had been demonstrated to be transmitted from wildfowl to only birds, pigs, horses, <u>seals</u>, whales and humans; and only between humans and pigs and between humans and domestic fowl; and not other pathways such

as domestic fowl to horse. Wild aquatic birds are the natural hosts for a large variety of influenza A viruses. Occasionally, viruses are transmitted from these birds to other species and may then cause devastating outbreaks in domestic poultry or give rise to human influenza pandemics. H5N1 has been shown to be transmitted to tigers, leopards, and domestic cats that were fed uncooked domestic fowl (chickens) with the virus. H3N8 viruses from horses have crossed over and caused outbreaks in dogs. Laboratory mice have been infected successfully with a variety of avian flu genotypes.

Influenza A viruses spread in the air, and survives longer in cold weather. They can also be transmitted by contaminated feed, water, equipment, and clothing; however, there is no evidence the virus can survive in well-cooked meat. Avian influenza viruses are monitored by several organizations that test for to control poultry disease

![](_page_14_Picture_2.jpeg)

Avian influenza A H5N1 virus

Known outbreaks of highly pathogenic flu in poultry 1959–2003

| Year | Area     | Affected | Subtype |
|------|----------|----------|---------|
| 1050 | Scotland | Chicken  | H5N1    |

| -,0, |                                   |                    |                               |
|------|-----------------------------------|--------------------|-------------------------------|
| 1963 | England                           | Turkey             | <u>H7N3</u>                   |
| 1966 | Ontario<br>(Canada)               | Turkey             | H5N9                          |
| 1976 | Victoria<br>(Australia)           | Chicken            | <u>H7N7</u>                   |
| 1979 | Germany                           | Chicken            | H7N7                          |
| 1979 | England                           | Turkey             | H7N7                          |
| 1983 | Pennsylvania<br>(US)*             | Chicken,<br>turkey | <u>H5N2</u>                   |
| 1983 | Ireland                           | Turkey             | H5N8                          |
| 1985 | Victoria<br>(Australia)           | Chicken            | H7N7                          |
| 1991 | England                           | Turkey             | H <sub>5</sub> N <sub>1</sub> |
| 1992 | Victoria<br>(Australia)           | Chicken            | H7N3                          |
| 1994 | Queensland<br>(Australia)         | Chicken            | H7N3                          |
| 1994 | Mexico*                           | Chicken            | H5N2                          |
| 1994 | Pakistan*                         | Chicken            | H7N3                          |
| 1997 | New South<br>Wales<br>(Australia) | Chicken            | <u>H7N4</u>                   |
| 1997 | Hong Kong<br>(China)*             | Chicken            | H5N1                          |
| 1997 | Italy                             | Chicken            | H5N2                          |
| 1999 | Italy*                            | Turkey             | <u>H7N1</u>                   |
| 2002 | Hong Kong<br>(China)              | Chicken            | H5N1                          |

| 2002 | Chile        | Chicken | H7N3 |  |
|------|--------------|---------|------|--|
| 2003 | Netherlands* | Chicken | H7N7 |  |

\*Outbreaks with significant spread to numerous farms, resulting in great economic losses. Most other outbreaks involved little or no spread from the initially infected farms.

More than 400 harbor seal deaths were recorded in <u>New England</u> between December 1979 and October 1980, from acute pneumonia caused by the influenza virus, A/Seal/Mass/1/180 (H7N7).

![](_page_16_Picture_3.jpeg)

Swine flu

Swine flu

Swine influenza (or "pig influenza") refers to a subset of Orthomyxoviridae that

create influenza and are endemic in pigs. The species of Orthomyxoviridae that can cause flu in pigs are influenza A virus and <u>influenza C virus</u>, but not all genotypes of these two species infect pigs. The known subtypes of influenza A virus that create influenza and are endemic in pigs are H1N1, H1N2, <u>H3N1</u> and H3N2. In 1997, H3N2 viruses from humans entered the pig population, causing widespread disease among pigs.

#### Horse flu

Horse flu (or "equine influenza") refers to varieties of influenza A virus that affect horses. Horse flu viruses were only isolated in 1956. The two main types of virus are called equine-1 (H7N7), which commonly affects horse heart muscle, and equine-2 (H3N8), which is usually more severe. H3N8 viruses from horses have infected dogs.

#### Dog flu

Dog flu (or "canine influenza") refers to varieties of influenza A virus that affect dogs. The equine influenza virus H3N8 was found to infect and kill – with respiratory illness – greyhound race dogs at a Florida racetrack in January 2004.

#### Bat flu

Bat flu (or "Bat influenza") refers to the H17N10 and H18N11 influenza A virus strains that were discovered in Central and South American fruit bats as well as a H9N2 virus isolated from the Egyptian fruit bat. Until now it is unclear whether these bat-derived viruses are circulating in any non-bat species and whether they pose a zoonotic threat. Initial characterization of the H18N11 subtype, however, suggests that this bat influenza virus is not well adapted to any other species than bats.

#### H<sub>3</sub>N<sub>8</sub>

H3N8 is now endemic in birds, horses and dogs.

#### List of Subtypes- Influenza A virus

### Vaccine

Globally the toll of influenza virus is estimated at 290,000-645,000 deaths annually,

of <a href="https://example.com/hemagglutinin">hemagglutinin</a> (HA) surface glycoprotein components from influenza <a href="https://example.com/H3N2">H3N2</a>, <a href="https://example.com/H1N1">H1N1</a>, and <a href="https://example.com/Binfluenza">Binfluenza</a> viruses. <a href="https://example.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com/Manualle.com

#### FI6 antibody

<u>FI6</u>, an <u>antibody</u> that targets the hemagglutinin protein, was discovered in 2011. FI6 is the only known antibody effective against all 16 subtypes of the influenza A virus.

## **Evolution**

![](_page_18_Figure_4.jpeg)

Genetic evolution of human and swine influenza viruses, 1918–2009

#### According to Jeffery Taubenberger:

"All influenza A pandemics since [the Spanish flu pandemic], and indeed almost all cases of influenza A worldwide (excepting human infections from avian viruses such as H5N1 and H7N7), have been caused by descendants of the 1918 virus, including "drifted" H1N1 viruses and reassorted H2N2 and H3N2 viruses. The latter are composed of key genes from the 1918 virus, updated by subsequently incorporated avian influenza genes that code for novel surface proteins, making the 1918 virus indeed the "mother" of all pandemics."

Researchers from the <u>National Institutes of Health</u> used data from the <u>Influenza</u>

<u>Genome Sequencing Project</u> and concluded that during the ten-year period examined, most of the time the hemagglutinin gene in H<sub>3</sub>N<sub>2</sub> showed no significant excess of mutations in the antigenic regions while an increasing variety of strains accumulated. This resulted in one of the variants eventually achieving higher fitness, becoming dominant, and in a brief interval of rapid <u>evolution</u>, rapidly sweeping through the population and eliminating most other variants.

In the short-term evolution of influenza A virus, a 2006 study found that stochastic, or random, processes are key factors. Influenza A virus HA antigenic evolution appears to be characterized more by punctuated, sporadic jumps as opposed to a constant rate of antigenic change. Using phylogenetic analysis of 413 complete genomes of human influenza A viruses that were collected throughout the state of New York, the authors of Nelson et al. 2006 were able to show that genetic diversity, and not antigenic drift, shaped the short-term evolution of influenza A via random migration and reassortment. The evolution of these viruses is dominated more by the random importation of genetically different viral strains from other geographic locations and less by natural selection. Within a given season, adaptive evolution is infrequent and had an overall weak effect as evidenced from the data gathered from the 413 genomes. Phylogenetic analysis revealed the different strains were derived from newly imported genetic material as opposed to isolates that had been circulating in New York in previous seasons. Therefore, the gene flow in and out of this population, and not natural selection, was more important in the short term.

### See also

- \* FI6 (antibody)
- \* Influenza vaccine
- \* Veterinary virology

### **Notes**

- "Taxonomy". International Committee on Taxonomy of Viruses (ICTV). <u>Archived</u> from the original on 20 March 2020. Retrieved 19 July 2018.
- <sup>2.</sup> "Avian influenza (" bird flu") Fact sheet". WHO. Archived from the original on 27 May 2020. Retrieved 22 April 2022.
- 3. ↑ Klenk HD, Matrosovich M, Stech J (2008). "Avian Influenza: Molecular Mechanisms of Pathogenesis and Host Range". In Mettenleiter TC, Sobrino F (eds.). Animal Viruses: Molecular Biology. Caister Academic Press. ISBN 978-1-904455-22-6. Archived from the original on 20 August 2016. Retrieved 22 April

2022.

- 4. \(\gamma\) Kawaoka Y, ed. (2006). Influenza Virology: Current Topics. Caister Academic Press. <u>ISBN</u> 978-1-904455-06-6. <u>Archived</u> from the original on 9 May 2008. Retrieved 22 April 2022.
- 5. ↑ "Influenza Type A Viruses and Subtypes". Centers for Disease Control and Prevention. 2 April 2013. Archived from the original on 1 June 2021. Retrieved 13 June 2013.
- 6. ↑ Tong S, Zhu X, Li Y, Shi M, Zhang J, Bourgeois M, Yang H, Chen X, Recuenco S, Gomez J, Chen LM, Johnson A, Tao Y, Dreyfus C, Yu W, McBride R, Carney PJ, Gilbert AT, Chang J, Guo Z, Davis CT, Paulson JC, Stevens J, Rupprecht CE, Holmes EC, Wilson IA, Donis RO (October 2013). "New world bats harbor diverse influenza A viruses". PLOS Pathogens. 9 (10): e1003657.
  doi:10.1371/journal.ppat.1003657. PMC 3794996. PMID 24130481.{{citejournal}}: CS1 maint: unflagged free DOI (link)
- 7. "Unique new flu virus found in bats". NHS Choices. 1 March 2012. Archived from the original on 8 August 2020. Retrieved 16 May 2012.
- 8. Tong S, Li Y, Rivailler P, Conrardy C, Castillo DA, Chen LM, Recuenco S, Ellison JA, Davis CT, York IA, Turmelle AS, Moran D, Rogers S, Shi M, Tao Y, Weil MR, Tang K, Rowe LA, Sammons S, Xu X, Frace M, Lindblade KA, Cox NJ, Anderson LJ, Rupprecht CE, Donis RO (March 2012). "A distinct lineage of influenza A virus from bats". Proceedings of the National Academy of Sciences of the United States of America. 109 (11): 4269–74. Bibcode: 2012PNAS..109.4269T. doi:10.1073/pnas.1116200109. PMC 3306675. PMID 22371588.
- 9. Gallagher J (29 July 2011). "Super antibody' fights off flu". BBC News. Archived from the original on 4 January 2021. Retrieved 29 July 2011.
- Nakatsu S, Murakami S, Shindo K, Horimoto T, Sagara H, Noda T, Kawaoka Y (March 2018). "Influenza C and D Viruses Package Eight Organized Ribonucleoprotein Complexes". Journal of Virology. 92 (6): e02084–17. doi:10.1128/jvi.02084-17. PMC 5827381. PMID 29321324.
- <sup>11.</sup> Noda T (2011). "Native morphology of influenza virions". Frontiers in Microbiology. 2: 269. doi:10.3389/fmicb.2011.00269. PMC 3249889. PMID 22291683.
- 12. ↑ Sugita Y, Noda T, Sagara H, Kawaoka Y (November 2011). "Ultracentrifugation deforms unfixed influenza A virions". The Journal of General Virology. 92 (Pt 11): 2485–93. doi:10.1099/vir.0.036715-0. PMC 3352361. PMID 21795472.
- <sup>13.</sup> Dadonaite B, Vijayakrishnan S, Fodor E, Bhella D, Hutchinson EC (August 2016).
  <u>"Filamentous influenza viruses"</u>. The Journal of General Virology. 97 (8): 1755–64. doi:10.1099/jgv.0.000535. PMC 5935222. PMID 27365089.
- 14. Seladi-Schulman J, Steel J, Lowen AC (December 2013). "Spherical influenza

- strains are selected in vivo". Journal of Virology. 87 (24): 13343-53. doi:10.1128/JVI.02004-13. PMC 3838284. PMID 24089563.
- <sup>15.</sup> Mosley VM, Wyckoff RW (March 1946). <u>"Electron micrography of the virus of influenza"</u>. Nature. **157** (3983): 263. <u>Bibcode</u>:1946Natur.157..263M. doi:10.1038/157263ao. PMID 21016866. S2CID 6478026.
- 16. ↑ Bouvier NM, Palese P (September 2008). <u>"The biology of influenza viruses"</u>. Vaccine. **26** (Suppl 4): D49–53. <u>doi:10.1016/j.vaccine.2008.07.039</u>. PMC 3074182. PMID 19230160.
- 17. Cohen M, Zhang XQ, Senaati HP, Chen HW, Varki NM, Schooley RT, Gagneux P (November 2013). "Influenza A penetrates host mucus by cleaving sialic acids with neuraminidase". Virology Journal. 10: 321. doi:10.1186/1743-422x-10-321. PMC 3842836. PMID 24261589.{{cite journal}}: CS1 maint: unflagged free DOI (link)
- 18. ↑ Suzuki Y (March 2005). "Sialobiology of influenza: molecular mechanism of host range variation of influenza viruses". Biological & Pharmaceutical Bulletin. **28** (3): 399–408. doi:10.1248/bpb.28.399. PMID 15744059.
- 19. Wilson JC, von Itzstein M (July 2003). "Recent strategies in the search for new anti-influenza therapies". Current Drug Targets. 4 (5): 389–408. doi:10.2174/1389450033491019. PMID 12816348.
- <sup>20.</sup> Lynch JP, Walsh EE (April 2007). "Influenza: evolving strategies in treatment and prevention". Seminars in Respiratory and Critical Care Medicine. 28 (2): 144–58. doi:10.1055/s-2007-976487. PMID 17458769.
- <sup>21.</sup> "Details Public Health Image Library(PHIL)". phil.cdc.gov. Archived from the original on 26 October 2020. Retrieved 24 April 2018.
- <sup>22.</sup> Eisfeld AJ, Neumann G, Kawaoka Y (January 2015). "At the centre: influenza A virus ribonucleoproteins". Nature Reviews. Microbiology. 13 (1): 28–41. doi:10.1038/nrmicro3367. PMC 5619696. PMID 25417656.
- <sup>23.</sup> Dadonaite, Bernadeta; Gilbertson, Brad; Knight, Michael L.; Trifkovic, Sanja; Rockman, Steven; Laederach, Alain; Brown, Lorena E.; Fodor, Ervin; Bauer, David L. V. (November 2019). "The structure of the influenza A virus genome". Nature Microbiology. 4 (11): 1781–1789. doi:10.1038/s41564-019-0513-7. PMC 7191640. PMID 31332385.
- 24. "Orthomyxoviruses". web.archive.org. 21 February 2009. Archived from the original on 21 February 2009. Retrieved 18 May 2022. {{cite web}}: CS1 maint: bot: original URL status unknown (link)
- 25. Khaperskyy DA, Schmaling S, Larkins-Ford J, McCormick C, Gaglia MM (February 2016). "Selective Degradation of Host RNA Polymerase II Transcripts by Influenza A Virus PA-X Host Shutoff Protein". PLOS Pathogens. 12 (2): e1005427. doi:10.1371/journal.ppat.1005427. PMC 4744033. PMID 26849127.

- ticite journatiss Col manit, unnagged nee DOI (mik)
- 26. Te Velthuis AJ, Fodor E (August 2016). "Influenza virus RNA polymerase: insights into the mechanisms of viral RNA synthesis". Nature Reviews. Microbiology. 14 (8): 479–93. doi:10.1038/nrmicro.2016.87. PMC 4966622. PMID 27396566.
- <sup>27.</sup> ↑ Smith AE, Helenius A (April 2004). "How viruses enter animal cells". Science. **304** (5668): 237–42. <u>Bibcode</u>:2004Sci...304..237S. <u>doi</u>:10.1126/science.1094823.

  PMID 15073366. S2CID 43062708.
- 28. Yoshiyuki Suzuki; Masatoshi Nei (1 April 2001). "Origin and Evolution of Influenza Virus Hemagglutinin Genes". Molecular Biology and Evolution. 19 (4). Ocford Academic: 501–509. doi:10.1093/oxfordjournals.molbev.a004105. PMID 11919291. Archived from the original on 3 March 2022. Retrieved 22 April 2022.
- <sup>29.</sup> Suarez DL, Spackman E, Senne DA, Bulaga L, Welsch AC, Froberg K (2003). "The effect of various disinfectants on detection of avian influenza virus by real time RT-PCR". Avian Diseases. 47 (3 Suppl): 1091–5. doi:10.1637/0005-2086-47.s3.1091. PMID 14575118. S2CID 8612187.
- 30. "Avian Influenza (Bird Flu) Implications for Human Disease. Physical characteristics of influenza A viruses". CIDRAP Center for Infectious Disease Research and Policy. University of Minnesota. <u>Archived</u> from the original on 17 June 2013. Retrieved 3 May 2022.
- 31. "Flu viruses 'can live for decades' on ice". The New Zealand Herald. Reuters. 30 November 2006. Archived from the original on 1 July 2020. Retrieved 1 November 2011.
- 32. Wagner R, Matrosovich M, Klenk H (May–June 2002). "Functional balance between haemagglutinin and neuraminidase in influenza virus infections". Rev Med Virol. 12 (3): 159–66. doi:10.1002/rmv.352. PMID 11987141. S2CID 30876482.
- 33. Lakadamyali M, Rust M, Babcock H, Zhuang X (5 August 2003). "Visualizing infection of individual influenza viruses". Proc Natl Acad Sci USA. 100 (16): 9280–85. Bibcode:2003PNAS..100.9280L. doi:10.1073/pnas.0832269100. PMC 170909. PMID 12883000.
- 34. Cros J, Palese P (September 2003). "Trafficking of viral genomic RNA into and out of the nucleus: influenza, Thogoto and Borna disease viruses". Virus Res. 95 (1-2): 3-12. doi:10.1016/S0168-1702(03)00159-X. PMID 12921991.
- 35. Kash J, Goodman A, Korth M, Katze M (July 2006). "Hijacking of the host-cell response and translational control during influenza virus infection". Virus Res. 119 (1): 111–20. doi:10.1016/j.virusres.2005.10.013. PMID 16630668.
- 36. Barry RD (August 1961). "The multiplication of influenza virus. II. Multiplicity reactivation of ultraviolet irradiated virus". Virology. 14 (4): 398–405.

- uoi.10.1010/0042-0022(01/90330-0. hui.1005/109240.1 http://
- 37. Henle W, Liu OC (October 1951). "Studies on host-virus interactions in the chick embryo-influenza virus system. VI. Evidence for multiplicity reactivation of inactivated virus". The Journal of Experimental Medicine. 94 (4): 305–22. doi:10.1084/jem.94.4.305. PMC 2136114. PMID 14888814.
- 38. Gilker JC, Pavilanis V, Ghys R (June 1967). "Multiplicity reactivation in gamma irradiated influenza viruses". Nature. **214** (5094): 1235–7.

  <u>Bibcode:1967Natur.214.1235G</u>. <u>doi:10.1038/2141235ao</u>. <u>PMID 6066111</u>.

  S2CID 4200194.
- 39. Multiplicity Reactivation. Springer Netherlands. 2008. p. 1289. doi:10.1007/978-1-4020-6754-9\_10950. ISBN 978-1-4020-6753-2. Archived from the original on 4 May 2022. Retrieved 4 May 2022.
- 40. Behzadi, Payam (19 May 2021). DNA: Damages and Repair Mechanisms. BoD Books on Demand. p. 25. <u>ISBN</u> 978-1-83881-093-1. <u>Archived</u> from the original on 21 May 2022. Retrieved 21 May 2022.
- 41. Peterhans E (May 1997). "Oxidants and antioxidants in viral diseases: disease mechanisms and metabolic regulation". The Journal of Nutrition. 127 (5 Suppl): 962S 965S. doi:10.1093/jn/127.5.962S. PMID 9164274.
- 42. Bernstein H, Byerly HC, Hopf FA, Michod RE (October 1984). "Origin of sex". Journal of Theoretical Biology. 110 (3): 323–51. <u>Bibcode</u>:1984JThBi.110..323B. doi:10.1016/S0022-5193(84)80178-2. <u>PMID</u> 6209512.
- 43. ↑ Russell, Rupert J.; Kerry, Philip S.; Stevens, David J.; Steinhauer, David A.;
  Martin, Stephen R.; Gamblin, Steven J.; Skehel, John J. (18 November 2008).

  "Structure of influenza hemagglutinin in complex with an inhibitor of membrane
  fusion". Proceedings of the National Academy of Sciences. 105 (46): 17736–17741.
  doi:10.1073/pnas.0807142105. Archived from the original on 7 May 2022.
  Retrieved 7 May 2022.
- 44. Air, Gillian M. (July 2012). "Influenza neuraminidase". Influenza and Other Respiratory Viruses. 6 (4): 245–256. doi:10.1111/j.1750-2659.2011.00304.x. ISSN 1750-2659. Archived from the original on 7 May 2022. Retrieved 7 May 2022.
- 45. Schmitz, U.; Lou, L.; Roberts, C.; Griffith, R. (1 January 2007). "7.13 Ribonucleic Acid Viruses: Antivirals for Influenza A and B, Hepatitis C Virus, and Respiratory Syncytial Virus". Comprehensive Medicinal Chemistry II. Elsevier. pp. 373–417. <a href="ISBN 978-0-08-045044-5">ISBN 978-0-08-045044-5</a>. <a href="Archived from the original on 6 November 2021">Archived from the original on 6 November 2021</a>. <a href="Retrieved 20 May 2022">Retrieved 20 May 2022</a>.
- 46. "Influenza Research Database Strain A/Fujian/411/2002(H3N2)".

  www.fludb.org. Archived from the original on 11 May 2022. Retrieved 11 May 2022.
- 47. "A revision of the system of nomenclature for influenza viruses: a WHO

  memorandum" (PDF) Bulletin of the World Health Organization #8 (4): 585-01

1980. PMID 6969132. Archived (PDF) from the original on 15 February 2022.

Retrieved 16 May 2022.

- 48. \(\gamma\) "Avian Influenza in Birds". Centers for Disease Control and Prevention. 9
  March 2022. Archived from the original on 30 April 2022. Retrieved 15 May
  2022.
- 49. whitehouse.gov Archived 21 February 2009 at the Wayback Machine National Strategy for Pandemic Influenza - Introduction - "Although remarkable advances have been made in science and medicine during the past century, we are constantly reminded that we live in a universe of microbes - viruses, bacteria, protozoa and fungi that are forever changing and adapting themselves to the human host and the defenses that humans create. Influenza viruses are notable for their resilience and adaptability. While science has been able to develop highly effective vaccines and treatments for many infectious diseases that threaten public health, acquiring these tools is an ongoing challenge with the influenza virus. Changes in the genetic makeup of the virus require us to develop new vaccines on an annual basis and forecast which strains are likely to predominate. As a result, and despite annual vaccinations, the US faces a burden of influenza that results in approximately 36,000 deaths and more than 200,000 hospitalizations each year. In addition to this human toll, influenza is annually responsible for a total cost of over \$10 billion in the US. A pandemic, or worldwide outbreak of a new influenza virus, could dwarf this impact by overwhelming our health and medical capabilities, potentially resulting in hundreds of thousands of deaths, millions of hospitalizations, and hundreds of billions of dollars in direct and indirect costs. This Strategy will guide our preparedness and response activities to mitigate that impact."

 $^{50.}$   $\uparrow$  , p.  $\underline{^{126}}$ 

"H5N1 virus is now endemic in poultry in Asia (Table 2-1) and has gained an entrenched ecological niche from which to present a long-term pandemic threat to humans. At present, these viruses are poorly transmitted from poultry to humans, and there is no conclusive evidence of human-to-human transmission. However, continued, extensive exposure of the human population to H5N1 viruses increases the likelihood that the viruses will acquire the necessary characteristics for efficient human-to-human transmission through genetic mutation or reassortment with a prevailing human influenza A virus. Furthermore, contemporary human H3N2 influenza viruses are now endemic in pigs in southern China (Peiris et al., 2001) and can reassort with avian H5N1 viruses in this 'intermediate host.' Therefore, it is imperative that outbreaks of H5N1 disease in poultry in Asia are rapidly and sustainably controlled. The seasonality of the disease in poultry, together with the control measures already implemented, are likely to reduce temporarily the frequency of H5N1 influenza outbreaks and the probability of human infection."

- Influenza (Bird Flu) and Avian Influenza A (H5N1) Virus
- 52. Tarendeau, Franck; Crepin, Thibaut; Guilligay, Delphine; Ruigrok, Rob W. H.; Cusack, Stephen; Hart, Darren J. (29 August 2008). "Host Determinant Residue Lysine 627 Lies on the Surface of a Discrete, Folded Domain of Influenza Virus Polymerase PB2 Subunit". PLOS Pathogens. 4 (8): e1000136. doi:10.1371/journal.ppat.1000136. ISSN 1553-7374. PMC 2515345. PMID 18769709.{{cite journal}}: CS1 maint: unflagged free DOI (link)
- 53. Trebbien, Ramona; Larsen, Lars E.; Viuff, Birgitte M. (8 September 2011).
  "Distribution of sialic acid receptors and influenza A virus of avian and swine origin in experimentally infected pigs". Virology Journal. 8: 434.
  doi:10.1186/1743-422X-8-434. ISSN 1743-422X. Archived from the original on 7 November 2020. Retrieved 16 May 2022. {{cite journal}}: CS1 maint: unflagged free DOI (link)
- 54. Leung, Horasis S. Y.; Li, Olive T. W.; Chan, Renee W. Y.; Chan, Michael C. W.; Nicholls, John M.; Poon, Leo L. M. (October 2012). "Entry of Influenza A Virus with a a2,6-Linked Sialic Acid Binding Preference Requires Host Fibronectin". Journal of Virology. 86 (19): 10704–10713. doi:10.1128/JVI.01166-12. Archived from the original on 17 May 2022. Retrieved 16 May 2022.
- 55. "Atorvastatin restricts the ability of influenza virus to generate lipid droplets and severely suppresses the replication of the virus". The FASEB Journal. 33 (8): 9516–9525. April 2019. doi:10.1096/fj.201900428RR. PMC 6662987. PMID 31125254. CS1 maint: unflagged free DOI (link)
- 56. de Jong MD, Bach VC, Phan TQ, Vo MH, Tran TT, Nguyen BH, Beld M, Le TP, Truong HK, Nguyen VV, Tran TH, Do QH, Farrar J (February 2005). "Fatal avian influenza A (H5N1) in a child presenting with diarrhea followed by coma". The New England Journal of Medicine. 352 (7): 686–91.
  doi:10.1056/NEJMoa044307. PMID 15716562. S2CID 17703507. Archived from the original on 1 August 2020. Retrieved 22 April 2022.
- 57. "1918 Pandemic (H1N1 virus) | Pandemic Influenza (Flu) | CDC". www.cdc.gov. 16 June 2020. Archived from the original on 27 March 2020. Retrieved 6 May 2022.
- 58. Jilani, Talha N.; Jamil, Radia T.; Siddiqui, Abdul H. (2022). "H1N1 Influenza". StatPearls. StatPearls Publishing. <u>Archived</u> from the original on 12 March 2020. Retrieved 6 May 2022.
- 59. "1957-1958 Pandemic (H2N2 virus) | Pandemic Influenza (Flu) | CDC". www.cdc.gov. 22 January 2019. Archived from the original on 30 January 2019. Retrieved 6 May 2022.
- 60. Tam, John S. (15 May 2002). "Influenza A (H5N1) in Hong Kong: an overview".

  Vaccine. 20 Suppl 2: S77–81. doi:10.1016/s0264-410x(02)00137-8. ISSN 0264410X. Archived from the original on 20 January 2022. Retrieved 6 May 2022.

<u>\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_</u>

61. International Committee on Taxonomy of Viruses (2002). "46.0.1. Influenzavirus A". Archived from the original on 7 December 2004. Retrieved 17 April 2006.

- 62. "New bird flu strain in China "one of the most lethal" warns WHO". MercoPress.

  Archived from the original on 14 May 2013. Retrieved 6 December 2020.
- 63. Boston, 677 Huntington Avenue; Ma 02115 +1495-1000 (24 October 2013).
  "Making the leap". News. Archived from the original on 3 January 2021.
  Retrieved 6 December 2020.{{cite web}}: CS1 maint: numeric names: authors list (link)
- 64. Ungchusak, Kumnuan; Auewarakul, Prasert; Dowell, Scott F.; Kitphati, Rungrueng; Auwanit, Wattana; Puthavathana, Pilaipan; Uiprasertkul, Mongkol; Boonnak, Kobporn; Pittayawonganon, Chakrarat; Cox, Nancy J.; Zaki, Sherif R. (27 January 2005). "Probable Person-to-Person Transmission of Avian Influenza A (H5N1)". New England Journal of Medicine. 352 (4): 333– 340. doi:10.1056/NEJMoa044021. ISSN 0028-4793. PMID 15668219. Archived from the original on 21 August 2020. Retrieved 22 April 2022.
- 65. ↑ Komadina N, McVernon J, Hall R, Leder K (2014). "A historical perspective of influenza A(H1N2) virus". Emerg Infect Dis. 20 (1): 6–12.

  doi:10.3201/eid2001.121848. PMC 3884707. PMID 24377419.{{cite journal}}:
  CS1 maint: multiple names: authors list (link)
- 66. Guan Y, Shortridge KF, Krauss S, Webster RG (August 1999). "Molecular characterization of H9N2 influenza viruses: were they the donors of the "internal" genes of H5N1 viruses in Hong Kong?". Proc. Natl. Acad. Sci. U.S.A. 96 (16): 9363-7. Bibcode:1999PNAS...96.9363G. doi:10.1073/pnas.96.16.9363. PMC 17788. PMID 10430948.
- 67. NAID NIH Archived 2010-03-06 at the Wayback Machine
- 68. <u>"CDC: Influenza Type A Viruses"</u>. <u>Archived</u> from the original on 1 June 2021. Retrieved 22 April 2022.
- 69. ↑ "CDC NIOSH Publications and Products Protecting Poultry Workers from
  Avian Influenza (Bird Flu) (2008-128)". www.cdc.gov. 2008.
  doi:10.26616/NIOSHPUB2008128. Archived from the original on 10 January
  2009. Retrieved 30 July 2015.
- 70. [1] Archived 6 April 2020 at the <u>Wayback Machine</u> article Kuwait: Avian influenza H5N1 confirmed case in flamingo November 12, 2005
- 71. Wright PF, Neumann G, Kawaoka Y (2013). "41-Orthomyxoviruses". In Knipe DM, Howley PM (eds.). Fields Virology. Vol. 1 (6th ed.). Philadelphia, PA: Wolters Kluwer/Lippincott Williams & Wilkins. p. 1201. ISBN 978-1-4511-0563-6.
- 72. Patton, Dominique; Gu, Hallie (1 June 2021). "China reports first human case of H10N3 bird flu". www.reuters.com. Archived from the original on 3 June 2021. Retrieved 1 June 2021.
- 73. Wana Vana Niu Shaowei Zhana Rina Vana Chenahuai Zhou Zhonahui (27

 $rrang, rang, rna, onaowei, znang, rang, rang, onengnaai, znoa, znongnai (<math>\epsilon$ )

June 2021). "The whole genome analysis for the first human infection with H10N3 influenza virus in China". The Journal of Infection.

doi:10.1016/j.jinf.2021.06.021. ISSN 1532-2742. PMID 34192524.

- 74. "Human infection with avian influenza A (H5N8) the Russian Federation".
  World Health Organization. 26 February 2021. Archived from the original on 26 February 2021. Retrieved 26 February 2021.
- 75·, p. 7
- 76. Peiterson, Laura; Levin, Calli. Department of Defense Biological Threat Responses to the 2009-2010 H1N1 Influenza Outbreak: A Real World Exercise (PDF). Defense.gov. <u>Archived</u> (PDF) from the original on 22 March 2021. Retrieved 8 May 2022.
- <sup>77.</sup> "Influenza A Virus (H1N2) an overview". ScienceDirect Topics. Archived from the original on 2 November 2021. Retrieved 21 February 2021.
- 78. Hilleman, Maurice R. (2002). "Realities and enigmas of human viral influenza: pathogenesis, epidemiology and control". Vaccine. 20 (25–26): 3068–3087.
  <u>CiteSeerX 10.1.1.523.7697. doi:10.1016/S0264-410X(02)00254-2.</u>
  PMID 12163258.
- 79. "The Influenza H5N1 Report". Pliva.com. 2 April 1998. Archived from the original on 24 October 2004.
- 80. Detailed chart of its evolution <u>here Archived</u> 9 May 2009 at the <u>Wayback Machine</u> at PDF called *Ecology and Evolution of the Flu*
- 81. , p. <u>115</u>
  - "There is particular pressure to recognize and heed the lessons of past influenza pandemics in the shadow of the worrisome 2003–2004 flu season. An early-onset, severe form of influenza A H3N2 made headlines when it claimed the lives of several children in the United States in late 2003. As a result, stronger than usual demand for annual flu inactivated vaccine outstripped the vaccine supply, of which 10 to 20 percent typically goes unused. Because statistics on pediatric flu deaths had not been collected previously, it is unknown if the 2003–2004 season witnessed a significant change in mortality patterns."
- 82. Reason Archived 26 October 2006 at the Wayback Machine Altman LK (15

  January 2006). "This Season's Flu Virus Is Resistant to 2 Standard Drugs". The

  New York Times. Archived from the original on 11 May 2013. Retrieved 22 April
  2022.
- 83. <u>"H5N1 influenza: monthly reported cases"</u>. Our World in Data. Retrieved 21 June 2025.
- 84. <u>"Fears of bioterrorism or an accidental release"</u>. 16 February 2012. <u>Archived</u> from the original on 21 November 2012.
- 85. "Deadly H5N1 bird flu becomes an 'existential threat' to biodiversity worldwide".

  Health News Florida, 31 January 2025, Archived from the original on 10

- February 2025. Retrieved 12 February 2025.
- 86. Sharma, Arjun (11 February 2025). "Stopgap measures against H5N1 bird flu can only go so far". STAT. Archived from the original on 11 February 2025. Retrieved 12 February 2025.
- 87. "H5N1 strikes more poultry in 4 states; CDC updates details on recent human cases | CIDRAP". www.cidrap.umn.edu. 24 February 2025. Archived from the original on 24 February 2025. Retrieved 25 February 2025.
- 88. "WHO South-East Asia Region Epidemiological Bulletin, 11th edition (2025), 04

  Jun 2025. Reporting period: 19 May to 02 Jun 2025 India | ReliefWeb".

  reliefweb.int. 5 June 2025. Archived from the original on 25 June 2025. Retrieved
  5 June 2025.
- <sup>89.</sup> "Cambodia records fourth death of H5N1 bird flu in 2025". suryaa. Archived from the original on 30 May 2025. Retrieved 5 June 2025.
- 90. CBS News Archived 18 May 2013 at the Wayback Machine article Dozens in Japan May Have Mild Bird Flu January 2006.
- 91. Ogata T, Yamazaki Y, Okabe N, Nakamura Y, Tashiro M, Nagata N, Itamura S, Yasui Y, Nakashima K, Doi M, Izumi Y, Fujieda T, Yamato S, Kawada Y (July 2008). "Human H5N2 avian influenza infection in Japan and the factors associated with high H5N2-neutralizing antibody titer". Journal of Epidemiology. 18 (4): 160–6. doi:10.2188/jea.JE2007446. PMC 4771585.
  PMID 18603824. Archived from the original on 28 September 2018. Retrieved 22 April 2022.
- <sup>92.</sup> "Russia reports first human cases of H5N8 bird flu". BNO News. 20 February 2021. Archived from the original on 1 May 2022. Retrieved 20 February 2021.
- 93. "Russia records first cases of human infection with bird flu strain H5N8". Sky News. 20 February 2021. Archived from the original on 13 June 2021. Retrieved 21 February 2021.
- 94. "WHO: Avian influenza A(H5N1)- update 31: Situation (poultry) in Asia: need for a long-term response, comparison with previous outbreaks". 7 March 2004. Archived from the original on 7 March 2004.
- 95. "NYC DOHMH 2016 Health Alert #52: Update on Avian Influenza A H7N2

  Infection in Cats in NYC Shelters" (PDF). Archived from the original (PDF) on 23

  December 2016. Retrieved 9 May 2022.
- 96. Tweed SA, Skowronski DM, David ST, Larder A, Petric M, Lees W, Li Y, Katz J, Krajden M, Tellier R, Halpert C, Hirst M, Astell C, Lawrence D, Mak A (December 2004). "Human illness from avian influenza H7N3, British Columbia". Emerging Infectious Diseases. 10 (12): 2196–9. doi:10.3201/eid1012.040961. PMC 3323407. PMID 15663860.
- 97. "Early bird flu warning for Dutch". Panorama. BBC News. 6 November 2005.

  Archived from the original on 7 March 2012. Retrieved 25 May 2015.

- 98. Schnirring L (2 April 2013). "China reports 4 more H7N9 infections". CIDRAP News. Archived from the original on 17 May 2013. Retrieved 22 April 2022.
- <sup>99.</sup> "Avian Influenza A (H7N9) Virus | Avian Influenza (Flu)". www.cdc.gov. Archived from the original on 29 April 2013. Retrieved 24 February 2017.
- 100. "Deadly bird flu strain outbreak reported in US: How easily does it spread?". www.msn.com. Retrieved 17 March 2025.
- 101. "COMMUNICABLE DISEASE THREATS REPORT Week 16, 18-24 April 2021"
  (PDF). European Centre for Disease Prevention and Control. 23 April 2021.
  Archived (PDF) from the original on 23 April 2021. Retrieved 23 April 2021.
- 102. niaid.nih.gov Archived 26 December 2005 at the Wayback Machine Timeline of Human Flu Pandemics
- 103. "China reports first human case of H10N3 bird flu". Reuters. 1 June 2021.
  Archived from the original on 3 June 2021. Retrieved 22 June 2021.
- <sup>104.</sup>, p. <u>30</u>
- <sup>105.</sup> , p. <u>82</u>

"Interestingly, recombinant influenza viruses containing the 1918 HA and NA and up to three additional genes derived from the 1918 virus (the other genes being derived from the A/WSN/33 virus) were all highly virulent in mice (Tumpey et al., 2004). Furthermore, expression microarray analysis performed on whole lung tissue of mice infected with the 1918 HA/NA recombinant showed increased upregulation of genes involved in apoptosis, tissue injury, and oxidative damage (Kash et al., 2004). These findings were unusual because the viruses with the 1918 genes had not been adapted to mice. The completion of the sequence of the entire genome of the 1918 virus and the reconstruction and characterization of viruses with 1918 genes under appropriate biosafety conditions will shed more light on these findings and should allow a definitive examination of this explanation. Antigenic analysis of recombinant viruses possessing the 1918 HA and NA by hemagglutination inhibition tests using ferret and chicken antisera suggested a close relationship with the A/swine/Iowa/30 virus and H1N1 viruses isolated in the 1930s (Tumpey et al., 2004), further supporting data of Shope from the 1930s (Shope, 1936). Interestingly, when mice were immunized with different H1N1 virus strains, challenge studies using the 1918-like viruses revealed partial protection by this treatment, suggesting that current[when?] vaccination strategies are adequate against a 1918-like virus (Tumpey et al., 2004)."

- 106. "Flu Virus Fortified In Colder Weather". National Institutes of Health (NIH). 26 May 2015. Archived from the original on 14 January 2022. Retrieved 19 May 2022.
- 107. "Avian Flu: Questions & Answers". www.fao.org. Archived from the original on 24 March 2022. Retrieved 19 May 2022.
- 108. "Avian Influenza". OIE World Organisation for Animal Health. Archived from

- the original on 8 April 2022. Retrieved 20 May 2022.
- 109. Capua, Ilaria; Marangon, Stefano (September 2006). "Control of Avian Influenza in Poultry". Emerging Infectious Diseases. 12 (7): 1319–1324. doi:10.3201/eid1209.060430. Archived from the original on 30 April 2022. Retrieved 13 May 2022.
- 110. "Avian influenza A(H5N1)- update 31: Situation (poultry) in Asia: need for a long-term response, comparison with previous outbreaks". Epidemic and Pandemic Alert and Response (EPR). WHO. 2004. Archived from the original on 7 March 2004.
  - Known outbreaks of highly pathogenic flu in poultry 1959-2003.
- 111. Geraci JR, St Aubin DJ, Barker IK, Webster RG, Hinshaw VS, Bean WJ, Ruhnke HL, Prescott JH, Early G, Baker AS, Madoff S, Schooley RT (February 1982).

  "Mass mortality of harbor seals: pneumonia associated with influenza A virus".

  Science. 215 (4536): 1129–31. Bibcode:1982Sci...215.1129G.

  doi:10.1126/science.7063847. PMID 7063847. More than 400 harbor seals, most of them immature, died along the New England coast between December 1979 and October 1980 of acute pneumonia associated with influenza virus,

  A/Seal/Mass/1/180 (H7N7). The virus has avian characteristics, replicates principally in mammals, and causes mild respiratory disease in experimentally infected seals. Concurrent infection with a previously undescribed mycoplasma or adverse environmental conditions may have triggered the epizootic. The similarities between this epizootic and other seal mortalities in the past suggest that these events may be linked by common biological and environmental factors.
- 112. ↑ CDC Archived 6 May 2015 at the Wayback Machine Centers for Disease Control and Prevention Transmission of Influenza A Viruses Between Animals and People
- 113. "Key Facts about Canine Influenza (Dog Flu)". Centers for Disease Control. 22 April 2015. <u>Archived</u> from the original on 4 April 2019. Retrieved 14 September 2015.
- <sup>114.</sup> Kandeil A, Gomaa MR, Shehata MM, El Taweel AN, Mahmoud SH, Bagato O (January 2019). "Isolation and Characterization of a Distinct Influenza A Virus from Egyptian Bats". Journal of Virology. 93 (2): e01059-18. doi:10.1128/JVI.01059-18. PMC 6321940. PMID 30381492.
- 115. Ciminski K, Ran W, Gorka M, Lee J, Schinköthe J, Eckley M, Murrieta MA, Aboellail TA, Campbell CL, Ebel GD, Ma J, Pohlmann A, Franzke K, Ulrich R, Hoffmann D, Garcia-Sastre A, Ma W, Schountz T, Beer M, Schwemmle M (2019). "Bat influenza viruses transmit among bats but are poorly adapted to non-bat species". Nature Microbiology. 4 (12): 2298–2309. doi:10.1038/s41564-019-0556-9. PMC 7758811. PMID 31527796. S2CID 202580293.
- <sup>116</sup>. McGrath, Matt (31 July 2012). "New flu virus found in seals concerns scientists".

BBC News. Archived from the original on 17 June 2019. Retrieved 31 July 2012.

- 117. Iuliano AD, Roguski KM, Chang HH, Muscatello DJ, Palekar R, Tempia S, Cohen C, Gran JM, Schanzer D, Cowling BJ, Wu P, Kyncl J, Ang LW, Park M, Redlberger-Fritz M, Yu H, Espenhain L, Krishnan A, Emukule G, van Asten L, Pereira da Silva S, Aungkulanon S, Buchholz U, Widdowson MA, Bresee JS (March 2018). "Estimates of global seasonal influenza-associated respiratory mortality: a modelling study". Lancet. 391 (10127): 1285–1300. doi:10.1016/s0140-6736(17)33293-2. PMC 5935243. PMID 29248255.
- 118. Daum LT, Shaw MW, Klimov AI, Canas LC, Macias EA, Niemeyer D, Chambers JP, Renthal R, Shrestha SK, Acharya RP, Huzdar SP, Rimal N, Myint KS, Gould P (August 2005). "Influenza A (H3N2) outbreak, Nepal". Emerging Infectious Diseases. 11 (8): 1186–91. doi:10.3201/eid1108.050302. PMC 3320503. PMID 16102305.

"The 2003–2004 influenza season was severe in terms of its impact on illness because of widespread circulation of antigenically distinct influenza A (H3N2) Fujian-like viruses. These viruses first appeared late during the 2002–2003 influenza season and continued to persist as the dominant circulating strain throughout the subsequent 2003–2004 influenza season, replacing the A/Panama/2007/99-like H3N2 viruses (1). Of the 172 H3N2 viruses genetically characterized by the Department of Defense in 2003–2004, only one isolate (from Thailand) belonged to the A/Panama-like lineage. In February 2003, the World Health Organization (WHO) changed the H3N2 component for the 2004–2005 influenza vaccine to afford protection against the widespread emergence of Fujian-like viruses (2). The annually updated trivalent vaccine consists of hemagglutinin (HA) surface glycoprotein components from influenza H3N2, H1N1, and B viruses."

- <sup>119</sup>. "Amantadine Monograph for Professionals". Drugs.com. Archived from the original on 15 July 2021. Retrieved 14 May 2022.
- 120. "RiMANTAdine Monograph for Professionals". Drugs.com. Archived from the original on 14 August 2021. Retrieved 14 May 2022.