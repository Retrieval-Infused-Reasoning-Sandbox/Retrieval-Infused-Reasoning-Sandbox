# EXPONENTIAL SEPARATION OF QUANTUM AND CLASSICAL ONE-WAY COMMUNICATION COMPLEXITY

ZIV BAR-YOSSEF\*, T. S. JAYRAM<sup>†</sup>, AND IORDANIS KERENIDIS<sup>‡</sup>

Abstract. We give the first exponential separation between quantum and bounded-error randomized one-way communication complexity. Specifically, we define the Hidden Matching Problem  $\mathrm{HM}_n$ : Alice gets as input a string  $\mathbf{x} \in \{0,1\}^n$  and Bob gets a perfect matching M on the n coordinates. Bob's goal is to output a tuple  $\langle i,j,b\rangle$  such that the edge (i,j) belongs to the matching M and  $b=x_i\oplus x_j$ . We prove that the quantum one-way communication complexity of  $\mathrm{HM}_n$  is  $O(\log n)$ , yet any randomized one-way protocol with bounded error must use  $\Omega(\sqrt{n})$  bits of communication. No asymptotic gap for one-way communication was previously known. Our bounds also hold in the model of Simultaneous Messages (SM) and hence we provide the first exponential separation between quantum SM and randomized SM with public coins.

For a Boolean decision version of  $\mathrm{HM}_n$ , we show that the quantum one-way communication complexity remains  $O(\log n)$  and that the 0-error randomized one-way communication complexity is  $\Omega(n)$ . We prove that any randomized linear one-way protocol with bounded error for this problem requires  $\Omega(\sqrt[3]{n\log n})$  bits of communication.

Key words. Communication complexity, quantum computation, separation, hidden matching

AMS subject classifications. 68P30.68Q15.68Q17.81P68

1. Introduction. The investigation of the strength and limitations of quantum computing has become an important field of study in theoretical computer science. The celebrated algorithm of Shor [22] for factoring numbers in polynomial time on a quantum computer gives strong evidence that quantum computers are more powerful than classical ones. The further study of the relationship between quantum and classical computing in models like black-box computation, communication complexity, and interactive proof systems help towards a better understanding of quantum and classical computing.

In this paper we answer an open question about the relative power of quantum one-way communication protocols. We describe a problem which can be solved by a quantum one-way communication protocol exponentially faster than any classical one. No asymptotic gap was previously known. We prove a similar result in the model of Simultaneous Messages.

Communication complexity, defined by Yao [23] in 1979, is a central model of computation with numerous applications. It has been used for proving lower bounds in many areas including Boolean circuits, time-space tradeoffs, data structures, automata, formulae size, etc. Examples of these applications can be found in the textbook of Kushilevitz and Nisan [15]. A communication complexity problem is defined by three sets X, Y, Z and a relation  $\mathcal{R} \subseteq X \times Y \times Z$ . Two computationally all-powerful players, Alice and Bob, are given inputs  $x \in X$  and  $y \in Y$ , respectively. Neither of the players has any information about the other player's input. Alice and Bob exchange

<sup>\*</sup>Done in part while the author was at the IBM Almaden Research Center. Supported by the European Commission Marie Curie International Re-integration Grant. Department of Electrical Engineering, Technion, Haifa 32000, Israel (zivby@ce.technion.ac.il).

<sup>†</sup>IBM Almaden Research Center, 650 Harry Road, San Jose, CA 95120, USA (jayram@almaden.ibm.com).

<sup>&</sup>lt;sup>‡</sup>Part of this work was done while the author was visiting IBM Almaden Research Center. Supported by ARO grant DAAD19-03-1-0082 and by the European Commission under the Integrated Project Qubit Applications (QAP) funded by the IST directorate as Contract Number 015848. CNRS - LRI, Université Paris-Sud, 91405 Orsay, France (jkeren@lri.fr).

messages according to a shared protocol, until Bob has sufficient information to announce an output  $z \in Z$  s.t.  $(x, y, z) \in \mathcal{R}$ . The communication cost of a protocol is the sum of the lengths of messages (in bits) Alice and Bob exchange on the worst-case choice of inputs x and y. The communication complexity of the problem  $\mathcal{R}$  is the cost of the best protocol that computes  $\mathcal{R}$  correctly.

One important special case of the above model is one-way communication complexity [19, 2, 14], where Alice is allowed to send only one message to Bob, after which Bob announces the output. Simultaneous Messages (SM) is a variant in which Alice and Bob cannot communicate directly with each other; instead, each of them sends a single message to a third party, the "referee", who announces the output based on the two messages.

Depending on the kind of allowed protocols, we can define different measures of communication complexity for a problem  $\mathcal{R}$ . The classical deterministic communication complexity of  $\mathcal{R}$  is the one described above. In a bounded-error randomized protocol with error probability  $\delta > 0$ , both players have access to public random coins, and for any inputs x, y, the output z announced should be correct (i.e., should satisfy  $(x,y,z) \in \mathcal{R}$ ) with probability at least  $1-\delta$  (the probability is over the public random coins). The cost of such a protocol is the number of bits Alice and Bob exchange on the worst-case choice of inputs and of values for the random coins. The randomized communication complexity of  $\mathcal{R}$  (w.r.t.  $\delta$ ) is the cost of the optimal randomized protocol for  $\mathcal{R}$ . In a  $\theta$ -error randomized protocol (a.k.a. Las Vegas protocol) the output announced should be correct with probability 1. The cost of such a protocol is the expected number of bits Alice and Bob exchange on the worst-case choice of inputs. These complexity measures can also be specialized by restricting the communication model to be SM or one-way communication. An interesting variant for randomized protocols in the SM model is when the random coins are restricted to be *private* (i.e., each of Alice and Bob has access to his/her own private random coins, and these coins are independent of each other  $).^1$ .

Quantum communication complexity, also introduced by Yao [25], apart from being of interest in itself, has been used to prove bounds on quantum formulae size, automata, data structures, etc. (e.g., [25, 12, 21]). In this setting, Alice and Bob hold qubits, some of which are initialized to the input. In a communication round, each player can perform some arbitrary unitary operation on his/her part of the qubits and send some of them to the other player. At the end of the protocol they perform a measurement and decide on an outcome. The output of the protocol is required to be correct with probability  $1 - \delta$ , for some  $\delta > 0$ . The quantum communication complexity of  $\mathcal{R}$  is the number of qubits exchanged in the optimal bounded-error quantum protocol for  $\mathcal{R}$ . It can be shown that the quantum communication is as powerful as bounded-error randomized communication with private coins<sup>2</sup>, even when restricted to variants such as one-way communication and SM. It is a natural and important question to ask whether quantum channels can significantly reduce the amount of communication necessary to solve certain problems.

It is known that randomized one-way communication protocols can be much more efficient than deterministic protocols. For example, the equality function on bitstrings of length n can be solved by a O(1) randomized one-way protocol, though its deter-

<sup>&</sup>lt;sup>1</sup>The difference in complexity between public and private coins for the other models is only  $O(\log \log(|X||Y|) + \log(1/\delta))$  [16].

<sup>&</sup>lt;sup>2</sup>As noted earlier, the distinction between public and private coins is significant only for the SM model.

ministic one-way communication complexity is  $\Omega(n)$  (cf. [15]). However, the question of whether quantum one-way communication could be exponentially more efficient than the randomized one remained open. We resolve this in the affirmative, by exhibiting a problem for which the quantum complexity is exponentially smaller than the randomized one.

1.1. Related work. The area of quantum communication complexity was introduced by Yao [25]. Since then, a series of papers have investigated the power and limitations of quantum communication complexity. Buhrman, Cleve, and Wigderson [7] described a relation  $\mathcal{R}$  with deterministic communication complexity of  $\Theta(n)$  and 0-error quantum communication complexity of  $\Theta(\log n)$ . However, the bounded-error randomized communication complexity of this problem is O(1). An exponential separation with respect to bounded-error randomized protocols was given by Ambainis et al. [4] in the so called sampling model. However, the separation does not hold in the presence of public coins. Buhrman et al. [6] were able to solve the equality problem in the SM model with a quantum protocol of complexity  $O(\log n)$  rather than the  $\Theta(\sqrt{n})$  bits necessary in any bounded-error randomized SM protocol with private coins [17, 5]. Again, if we allow the players to share random coins, then equality can be solved classically with O(1) communication.

Ran Raz [20] was the first to show an exponential gap between the quantum and the bounded-error public-coin randomized communication complexity models. He described a relation  $\mathcal{P}_1$  with an efficient quantum protocol of complexity  $O(\log n)$ . He then proved a lower bound of  $\Omega(n^{1/4})$  on the classical randomized communication complexity of  $\mathcal{P}_1$ . Since the quantum protocol given for  $\mathcal{P}_1$  uses two rounds, the separation holds only for protocols that use two rounds or more. The definition of  $\mathcal{P}_1$  was motivated, in part, by another relation  $\mathcal{P}_0$ . The latter was first introduced by Kremer [13] who showed that  $\mathcal{P}_0$  is a complete problem for quantum one-way communication complexity (in particular, it has a  $O(\log n)$  quantum one-way protocol). However, no lower bound is given for the one-way randomized communication complexity of  $\mathcal{P}_0$ . Proving an exponential separation of classical and quantum one-way communication complexity has been an open question since.

Klauck [12] proved that the 0-error quantum one-way communication complexity of total functions (i.e., problems  $\mathcal{R} \subseteq X \times Y \times Z$ , for which every  $x \in X$  and  $y \in Y$  have exactly one  $z \in Z$  with  $(x, y, z) \in \mathcal{R}$ ) is equal to the classical deterministic one. It is still an open question whether for total functions quantum and bounded-error randomized one-way communication complexity are polynomially related.

Subsequent to our work, Aaronson [1] showed that for any Boolean function f, the deterministic one-way communication complexity of f is  $O(\log |Y| \cdot Q^1(f) \cdot \log Q^1(f))$ , where  $Q^1(f)$  is the bounded-error quantum one-way communication complexity of f; namely, if the given communication problem is a Boolean function in which Bob's domain is small, then deterministic one-way communication complexity is almost as efficient as bounded-error quantum one-way communication complexity. Moreover, Gavinsky et al [10] described a relation, which has randomized communication complexity  $O(\log n)$  in the Simultaneous Messages with public coins model, though its quantum Simultaneous Messages communication complexity is  $\Omega(\sqrt{n})$ . This separation in the opposite direction from ours shows that the two models are incomparable.

1.2. Our results. Our main result is the definition and analysis of the communication complexity of the Hidden Matching Problem. This provides the first exponential separation between quantum and classical one-way communication complexity.

### The HIDDEN MATCHING PROBLEM:

Let n be a positive even integer. In the Hidden Matching Problem, denoted  $\mathrm{HM}_n$ , Alice is given  $\mathbf{x} \in \{0,1\}^n$  and Bob is given  $M \in \mathcal{M}_n$  ( $\mathcal{M}_n$  denotes the family of all possible perfect matchings on n nodes). Their goal is to output a tuple  $\langle i,j,b\rangle$  such that the edge (i,j) belongs to the matching M and  $b=x_i\oplus x_j$ .

This problem is new and we believe that its definition plays the major role in obtaining our result. The inspiration comes from the work by Kerenidis and de Wolf on Locally Decodable Codes [11]. Let us give the intuition why this problem is hard for classical communication complexity protocols. Suppose (to make the problem even easier) that Bob's matching M is restricted to be one of n fixed disjoint matchings on  $\mathbf{x}$ . Bob's goal is to find the value of  $x_i \oplus x_j$  for some  $(i,j) \in M$ . However, since Alice has no information about which matching Bob has, her message needs to contain information about the parity of at least one pair from each matching. Hence, she needs to communicate parities of  $\Omega(n)$  different pairs to Bob. It can be shown that such message must be of size  $\Omega(\sqrt{n})$ . In Section 4 we turn this intuition into a proof for the randomized one-way communication complexity of  $\mathrm{HM}_n$ . We also show that our lower bound is tight by describing a randomized one-way protocol with communication  $O(\sqrt{n})$ . In this protocol, Alice just sends  $O(\sqrt{n})$  random bits of her input. By the birthday paradox, with high probability, Bob can recover the value of at least one of his matching pairs from Alice's message.

Remarkably, this problem remains easy for quantum one-way communication. Alice only needs to send a uniform superposition of her string  $\mathbf{x}$ , hence communicating only  $O(\log n)$  qubits. Bob can perform a measurement on this superposition which depends on the matching M and then output the parity of some pair in M. In Section 3 we describe the quantum protocol in more detail.

In section 5 we show that  $\mathrm{HM}_n$  also provides the first exponential separation between quantum SM and randomized SM with public coins. Previously such a bound was known only in the private coins model. This result, together with the exponential separation in the opposite direction proved by Gavinsky et al. [10], shows that, in fact, the models of quantum SM and public-coin randomized SM are incomparable.

Our main result exhibits a separation between quantum and classical one-way communication complexity for a relation. Ideally, one would like to prove such a separation for the most basic type of problems—total Boolean functions. The best known separation between quantum and classical communication complexity (even for an arbitrary number of rounds) for such functions is only quadratic [7]. It is still conceivable that for total functions, the two models are polynomially related. Raz's result [20] shows an exponential gap for a partial Boolean function (i.e., a Boolean function that is defined only on a subset of the domain  $\mathcal{X} \times \mathcal{Y}$ ) and for two-way communication protocols.

We consider a partial Boolean function induced by the Hidden Matching Problem, defined below. In the definition we view each matching  $M \in \mathcal{M}_n$  as an  $\frac{n}{2} \times n$  edge-vertex incidence matrix. For two Boolean vectors  $\mathbf{v}, \mathbf{w}$ , we denote by  $\mathbf{v} \oplus \mathbf{w}$  the vector obtained by xoring  $\mathbf{v}$  and  $\mathbf{w}$  coordinate-wise. For a bit  $b \in \{0, 1\}$ , we denote by  $\mathbf{b}$  the vector all of whose entries are b.

## The BOOLEAN HIDDEN MATCHING PROBLEM:

Let n be a positive integer multiple of 4. In the Boolean Hidden Matching Problem, denoted BHM<sub>n</sub>, Alice is given  $\mathbf{x} \in \{0,1\}^n$  and Bob is given  $M \in \mathcal{M}_n$  and  $\mathbf{w} \in \{0,1\}^{n/2}$ , which satisfy the following promise: either  $M\mathbf{x} \oplus \mathbf{w} = \mathbf{1}$  (a YES instance) or  $M\mathbf{x} \oplus \mathbf{w} = \mathbf{0}$  (a No instance). Their goal is to decide which of the two cases holds.

With a slight modification, the quantum protocol for  $\mathrm{HM}_n$  also solves  $\mathrm{BHM}_n$  using  $O(\log n)$  qubits. We believe that  $\mathrm{BHM}_n$  should also exhibit an exponential gap in its quantum and classical one-way communication complexity.

Conjecture 1. The one-way randomized communication complexity of the Boolean Hidden Matching problem is  $n^{\Omega(1)}$ . Although we were unable to resolve the above conjecture, we give a strong indication for our belief with two lower bounds. First, we prove an  $\Omega(n)$  lower bound on the 0-error randomized one-way communication complexity of  $BHM_n$ . We then show that a natural class of randomized bounded-error protocols require  $\Omega(\sqrt[3]{n})$  bits of communication to compute BHM<sub>n</sub>. The protocols we refer to are *linear*; that is, Alice and Bob use the public coins to choose a random matrix  $\mathbf{A}$ , and Alice's message on input  $\mathbf{x}$  is simply  $\mathbf{A}\mathbf{x}$ . These protocols are natural for our problem, because Bob needs to compute a linear transformation of Alice's input. In particular, the  $O(\sqrt{n})$  communication protocol that we described earlier is trivially a linear protocol. We note that the study of linear protocols is not unique to our problem. For example, one-way linear protocols for the indexing function can be viewed as linear random access codes [3]. Thus, lower bounds for linear protocols preclude the feasibility of a natural class of protocols. Generalizing this lower bound to the case of non-linear randomized protocols still remains an open problem. These results are described in Section 6.

#### 2. Preliminaries.

**2.1.** Information theory. Throughout the paper we use basic notions and facts from information theory, which we briefly review next. We refer the reader to the textbook of Cover and Thomas [8] for details and proofs.

We deal only with finite discrete probability spaces. The distribution of a random variable X is denoted by  $\mu_X$ , and let  $\mu_X(x) \stackrel{\text{def}}{=} \Pr[X = x]$ . The entropy of X (or, equivalently, of  $\mu_X$ ) is  $\mathrm{H}(X) \stackrel{\text{def}}{=} \sum_{x \in \mathcal{X}} \mu_X(x) \log \frac{1}{\mu_X(x)}$ , where  $\mathcal{X}$  is the domain of X. The entropy of a Bernoulli random variable with probability of success p is called the binary entropy function of p and is denoted  $H_2(p)$ . The joint entropy of X and Y is the entropy of the joint distribution  $\mu_{XY}$  of X and Y. The conditional entropy of X given an event A, denoted  $\mathrm{H}(X|A)$ , is the entropy of the conditional distribution of  $\mu_X$  given A. The conditional entropy of X given Y is  $\mathrm{H}(X|Y) \stackrel{\text{def}}{=} \sum_{y \in \mathcal{Y}} \mu_Y(y) \, \mathrm{H}(X|Y = y)$ , where  $\mathcal{Y}$  is the domain of Y. The mutual information between X and Y is  $\mathrm{I}(X;Y) \stackrel{\text{def}}{=} \mathrm{H}(X) - \mathrm{H}(X|Y) = \mathrm{H}(Y) - \mathrm{H}(Y|X)$ . The conditional mutual information between X and Y given X is  $\mathrm{I}(X;Y|X) = \mathrm{H}(X|X) - \mathrm{H}(X|X) = \mathrm{H}(X|X) - \mathrm{H}(X|X) = \mathrm{H}(X|X) - \mathrm{H}(X|X) = \mathrm{H}(X|X) - \mathrm{H}(X|X) = \mathrm{H}(X|X) - \mathrm{H}(X|X) = \mathrm{H}(X|X) - \mathrm{H}(X|X) = \mathrm{H}(X|X) - \mathrm{H}(X|X) = \mathrm{H}(X|X) - \mathrm{H}(X|X) = \mathrm{H}(X|X) - \mathrm{H}(X|X) = \mathrm{H}(X|X) - \mathrm{H}(X|X) = \mathrm{H}(X|X) - \mathrm{H}(X|X) = \mathrm{H}(X|X) - \mathrm{H}(X|X) = \mathrm{H}(X|X) - \mathrm{H}(X|X) = \mathrm{H}(X|X) - \mathrm{H}(X|X) = \mathrm{H}(X|X) - \mathrm{H}(X|X) = \mathrm{H}(X|X) - \mathrm{H}(X|X) = \mathrm{H}(X|X) - \mathrm{H}(X|X) = \mathrm{H}(X|X) - \mathrm{H}(X|X) = \mathrm{H}(X|X) - \mathrm{H}(X|X) = \mathrm{H}(X|X) - \mathrm{H}(X|X) = \mathrm{H}(X|X) - \mathrm{H}(X|X) = \mathrm{H}(X|X) - \mathrm{H}(X|X) = \mathrm{H}(X|X) - \mathrm{H}(X|X) = \mathrm{H}(X|X) - \mathrm{H}(X|X) = \mathrm{H}(X|X) - \mathrm{H}(X|X) = \mathrm{H}(X|X) - \mathrm{H}(X|X) = \mathrm{H}(X|X) - \mathrm{H}(X|X) = \mathrm{H}(X|X) - \mathrm{H}(X|X) = \mathrm{H}(X|X) - \mathrm{H}(X|X) = \mathrm{H}(X|X) - \mathrm{H}(X|X) = \mathrm{H}(X|X) - \mathrm{H}(X|X) = \mathrm{H}(X|X) - \mathrm{H}(X|X) = \mathrm{H}(X|X) - \mathrm{H}(X|X) = \mathrm{H}(X|X) - \mathrm{H}(X|X) = \mathrm{H}(X|X) - \mathrm{H}(X|X) = \mathrm{H}(X|X) - \mathrm{H}(X|X) = \mathrm{H}(X|X) - \mathrm{H}(X|X) = \mathrm{H}(X|X) - \mathrm{H}(X|X) = \mathrm{H}(X|X) - \mathrm{H}(X|X) = \mathrm{H}(X|X) - \mathrm{H}(X|X) = \mathrm{H}(X|X) - \mathrm{H}(X|X) = \mathrm{H}(X|X) - \mathrm{H}(X|X) = \mathrm{H}(X|X) - \mathrm{$ 

Some basic properties of entropy and mutual information we are using in this paper are the following.

Theorem 2.1. Let X, Y, Z be random variables.

- 1.  $H(X) \leq \log |supp(X)|$ , where supp(X) is the support of X. Equality holds iff X is uniform on supp(X).
- 2. Conditioning reduces entropy:  $H(X|Y) \leq H(X)$ . Equality holds iff X, Y are independent.
- 3. Entropy subadditivity:  $H(X,Y) \leq H(X) + H(Y)$ . Equality holds iff X,Y are independent.

- 4. Data processing inequality I: For any k-to-1 function f,  $H(X) \leq H(f(X)) +$  $\log k$ .
- 5. Data processing inequality II: For any function f,  $I(X; f(Y)) \leq I(X; Y)$ . Equality holds, if f is 1-1.
- 6. Chain rule for mutual information: I(X; Y, Z) = I(X; Y) + I(X; Z|Y).
- 7. I(X;Y) = 0 iff X, Y are independent.
- 8. If X, Y are jointly independent of Z, then I(X;Y|Z) = I(X;Y). 9. For any positive integers n and  $m \le n/2$ ,  $\sum_{i=0}^{m} \binom{n}{i} \le 2^{nH_2(m/n)}$ .

We will also use the following theorems:

THEOREM 2.2 (Fano's inequality). Let X be a binary random variable, and let Y be any random variable on a domain  $\mathcal{Y}$ . Let  $f: \mathcal{Y} \to \{0,1\}$  be a prediction function, which tries to predict the value of X based on an observation of Y. Let  $\delta \stackrel{\text{def}}{=} \Pr(f(Y) \neq \emptyset)$ X) be the error probability of the prediction function. Then,  $H_2(\delta) \geq H(X|Y)$ .

Theorem 2.3. Let  $C \subseteq \{0,1\}^*$  be a finite prefix-free code (i.e., no codeword in C is a prefix of any other codeword in C). Let X be a random variable corresponding to a uniformly chosen codeword in C. Then,  $H(X) \leq E(|X|)$ .

**2.2.** Quantum computation. We explain the standard notation of quantum computing and describe the basic notions that will be useful in this paper. For more details we refer the reader to the textbook of Nielsen and Chuang [18].

Let H denote a 2-dimensional complex vector space, equipped with the standard inner product. We pick an orthonormal basis for this space, label the two basis vectors  $|0\rangle$  and  $|1\rangle$ , and for simplicity identify them with the vectors  $\begin{pmatrix} 1 \\ 0 \end{pmatrix}$  and

 $\begin{pmatrix} 0 \\ 1 \end{pmatrix}$ , respectively. A qubit is a unit length vector in this space, and so can be expressed as a linear combination of the basis states:

$$\alpha_0|0\rangle + \alpha_1|1\rangle = \begin{pmatrix} \alpha_0 \\ \alpha_1 \end{pmatrix}.$$

Here  $\alpha_0, \alpha_1$  are complex amplitudes, and  $|\alpha_0|^2 + |\alpha_1|^2 = 1$ .

An m-qubit system is a unit vector in the m-fold tensor space  $H \otimes \cdots \otimes H$ . The  $2^m$ basis states of this space are the m-fold tensor products of the states  $|0\rangle$  and  $|1\rangle$ . For example, the basis states of a 2-qubit system are the four 4-dimensional unit vectors  $|0\rangle \otimes |0\rangle$ ,  $|0\rangle \otimes |1\rangle$ ,  $|1\rangle \otimes |0\rangle$ , and  $|1\rangle \otimes |1\rangle$ . We abbreviate, e.g.,  $|1\rangle \otimes |0\rangle$  to  $|1\rangle |0\rangle$ , or  $|1,0\rangle$ , or  $|10\rangle$ , or even  $|2\rangle$  (since 2 is 10 in binary). With these basis states, an m-qubit state  $|\phi\rangle$  is a  $2^m$ -dimensional complex unit vector

$$|\phi\rangle = \sum_{i \in \{0,1\}^m} \alpha_i |i\rangle.$$

We use  $\langle \phi | = | \phi \rangle^*$  to denote the conjugate transpose of the vector  $| \phi \rangle$ , and  $\langle \phi | \psi \rangle =$  $\langle \phi | \cdot | \psi \rangle$  for the inner product between states  $| \phi \rangle$  and  $| \psi \rangle$ . These two states are orthogonal if  $\langle \phi | \psi \rangle = 0$ . The norm of  $| \phi \rangle$  is  $| \phi | = \sqrt{\langle \phi | \phi \rangle}$ .

Let  $|\phi\rangle$  be an *m*-qubit state and  $B = \{|b_1\rangle, \dots, |b_{2^m}\rangle\}$  an orthonormal basis of the m-qubit space. A measurement of the state  $|\phi\rangle$  in the B basis means that we apply the projection operators  $P_i = |b_i\rangle\langle b_i|$  to  $|\phi\rangle$ . The resulting quantum state is  $|b_i\rangle$  with probability  $p_i = |\langle \phi | b_i \rangle|^2$ .

**3.** The quantum upper bound. We present a quantum protocol for the hidden matching problem with communication complexity of  $O(\log n)$  qubits. Let  $\mathbf{x} = x_1 \dots x_n$  be Alice's input and  $M \in \mathcal{M}_n$  be Bob's input.

QUANTUM PROTOCOL FOR  $\mathrm{HM}_n$ 

- 1. Alice sends the state  $|\psi\rangle = \frac{1}{\sqrt{n}} \sum_{i=1}^{n} (-1)^{x_i} |i\rangle$ .
- 2. Bob performs a measurement on the state  $|\psi\rangle$  in the orthonormal basis  $B = \{\frac{1}{\sqrt{2}}(|k\rangle \pm |\ell\rangle) \mid (k,\ell) \in M\}.$

The probability that the outcome of the measurement is a basis state  $\frac{1}{\sqrt{2}}(|k\rangle+|\ell\rangle)$  is

$$|\langle \psi | \frac{1}{\sqrt{2}} (|k\rangle + |\ell\rangle)\rangle|^2 = \frac{1}{2n} ((-1)^{x_k} + (-1)^{x_\ell})^2.$$

This equals 2/n if  $x_k \oplus x_\ell = 0$  and 0 otherwise. Similarly for the states  $\frac{1}{\sqrt{2}}(|k\rangle - |\ell\rangle)$  we have that  $|\langle \psi| \frac{1}{\sqrt{2}}(|k\rangle - |\ell\rangle)\rangle|^2$  equals 0 if  $x_k \oplus x_\ell = 0$  and 2/n if  $x_k \oplus x_\ell = 1$ . Hence, if the outcome of the measurement is a state  $\frac{1}{\sqrt{2}}(|k\rangle + |\ell\rangle)$  then Bob knows with certainty that  $x_k \oplus x_\ell = 0$  and outputs  $\langle k, \ell, 0 \rangle$ . If the outcome is a state  $\frac{1}{\sqrt{2}}(|k\rangle - |\ell\rangle)$  then Bob knows with certainty that  $x_k \oplus x_\ell = 1$  and hence outputs  $\langle k, \ell, 1 \rangle$ . Note that the measurement depends only on Bob's input and that the algorithm is 0-error.

This protocol can be tweaked to solve also BHM<sub>n</sub>: after obtaining the value  $\langle k, \ell, c \rangle$  from that protocol, where  $(k, \ell)$  is the *i*-th pair in Bob's input matching M, Bob outputs  $w_i \oplus c$ . Note that if  $c = x_k \oplus x_\ell$ , then  $w_i \oplus c$  equals the desired bit b.

Remark. As mentioned above, the inspiration for this problem comes from Locally Decodable Codes. We can think of a 2-query Locally Decodable Code as a code  $C: \{0,1\}^n \to \{0,1\}^m$  with the property that for every index  $k \in [n]$  there exists a matching  $M_k$  on the coordinates of  $C(\mathbf{x})$ , such that for every pair  $(i,j) \in M_k$ ,  $x_k = C(\mathbf{x})_i \oplus C(\mathbf{x})_j$ . We can cast this problem as a communication problem, by letting Alice have the codeword  $C(\mathbf{x})$ , Bob have the index k and the corresponding matching  $M_k$ , and the goal is for Bob to output  $C(\mathbf{x})_i \oplus C(\mathbf{x})_j$  for some  $(i,j) \in M_k$ . This gives rise to our Hidden Matching Problem. The fact that a uniform superposition of  $C(\mathbf{x})$  is sufficient to compute the parity of some pair in each matching was used by Kerenidis and de Wolf [11] to prove a lower bound on the length of classical 2-query Locally Decodable Codes.

**4. The randomized lower bound.** We prove an  $\Omega(\sqrt{n})$  lower bound on the one-way communication complexity of the hidden matching problem.

THEOREM 4.1. Any one-way randomized protocol for computing  $HM_n$  with error probability less than 1/8 requires  $\Omega(\sqrt{n})$  bits of communication.

*Proof.* Using Yao's Lemma [24], in order to prove the lower bound, it suffices to construct a "hard" distribution  $\mu$  over instances of  $HM_n$ , and prove a lower bound for deterministic one-way protocols whose distributional error w.r.t.  $\mu$  is at most  $\delta$ , where  $\delta < 1/8$ . This is accomplished as follows.

For a deterministic one-way protocol  $\Pi$  and for inputs  $\mathbf{x}$  and M to Alice and Bob, respectively, we denote by  $\Pi(\mathbf{x}, M)$  the output of the protocol on  $\mathbf{x}$  and M. This output is a triple (i, j, b), where  $i, j \in [n]$  and b is a bit. The protocol is correct on  $(\mathbf{x}, M)$ , if  $(i, j, b) \in \mathrm{HM}_n(\mathbf{x}, M)$ . That is, (i, j) is an edge in M and  $b = \mathbf{x}_i \oplus \mathbf{x}_j$ .

Since Bob knows the matching M and also is the one who announces the output  $\Pi(\mathbf{x}, M)$ , we can assume without loss of generality that the pair (i, j) is always an edge in M. Therefore, an error can occur only if  $b \neq \mathbf{x}_i \oplus \mathbf{x}_j$ .

The following notation will be used in the proof. For a pair of random inputs U and V to Alice and Bob, respectively, let  $\mathcal{E}rr_{\Pi}(U,V)$  denote the distributional error of  $\Pi$  when the inputs are drawn according to the joint distribution  $\mu$  of U and V. That is,

$$\mathcal{E}rr_{\Pi}(U,V) = \Pr_{(U,V) \sim \mu} (\Pi(U,V) \notin \mathrm{HM}_n(U,V)).$$

We define the hard distribution  $\mu$  as follows: let  $\mathbf{X}$  be a uniformly chosen bitstring in  $\{0,1\}^n$ ; let  $\mathbf{M}$  be an independent and uniformly chosen perfect matching in  $\mathcal{M}$ , where  $\mathcal{M}$  is any set of  $m = \Omega(n)$  pairwise edge-disjoint matchings. (For example, let m = n/2 and  $\mathcal{M} = \{M_1, M_2, \ldots, M_m\}$ , where  $M_i$  is defined by the edge set  $\{(j, m + (j+i) \bmod m) \mid j = 0, \ldots, m-1\}$ .) Fix any deterministic protocol  $\Pi$  whose distributional error on  $\mu$  is at most  $\delta$ , i.e.,  $\mathcal{E}rr_{\Pi}(\mathbf{X}, \mathbf{M}) \leq \delta$ .

For each  $\mathbf{x}$ , let  $\hat{e}_{\mathbf{x}} = \mathcal{E}rr_{\Pi}(\mathbf{x}, \mathbf{M})$  denote the distributional error of  $\Pi$  on the fixed input  $\mathbf{x}$  to Alice and a random input  $\mathbf{M}$  to Bob. Note that  $\mathbb{E}[\hat{e}_{\mathbf{X}}] = \mathcal{E}rr_{\Pi}(\mathbf{X}, \mathbf{M}) \leq \delta$ . By Markov's inequality,  $\Pr[\hat{e}_{\mathbf{X}} \geq 2\delta] \leq 1/2$ . Since  $\mathbf{X}$  is uniformly distributed, this means that  $\hat{e}_{\mathbf{x}} \leq 2\delta$  for at least half of the individual  $\mathbf{x}$ 's.

Let  $A(\mathbf{x})$  denote the message that Alice sends on input  $\mathbf{x}$  in the protocol  $\Pi$ . For every message  $\tau$ , define

$$S_{\tau} = \{ \mathbf{x} \mid A(\mathbf{x}) = \tau \text{ and } \hat{e}_{\mathbf{x}} \leq 2\delta \}.$$

Since  $\hat{e}_{\mathbf{x}} \leq 2\delta$  for at least half of the  $\mathbf{x}$ 's, we have

$$\sum_{\tau} |S_{\tau}| \ge 2^{n-1}.\tag{4.1}$$

On the other hand, we will prove the following upper bound on the size of  $S_{\tau}$ :

Lemma 4.2. For every message  $\tau$ ,

$$|S_{\tau}| \leq 2^{n - \Omega(\sqrt{n})}$$
.

Before we prove the lemma observe that the above Equation 4.1 and Lemma 4.2 imply that the number of distinct  $\tau$ 's is at least  $2^{\Omega(\sqrt{n})}$ . Thus, the communication cost of  $\Pi$  is  $\Omega(\sqrt{n})$ , proving the theorem.  $\square$ 

*Proof.* [Lemma 4.2] Fix a message  $\tau$  of Alice, and let  $\mathbf{X}_{\tau}$  be uniformly distributed in  $S_{\tau}$ . Define  $e_{\tau} = \mathcal{E}rr_{\Pi}(\mathbf{X}_{\tau}, \mathbf{M})$  to be the distributional error of  $\Pi$  on the random inputs  $(\mathbf{X}_{\tau}, \mathbf{M})$ . By the definition of  $S_{\tau}$ ,  $\hat{e}_{\mathbf{x}} \leq 2\delta$  for every input  $\mathbf{x}$  in  $S_{\tau}$ . It follows that  $e_{\tau} \leq 2\delta$  as well.

For each matching  $M \in \mathcal{M}$ , let  $e_{\tau,M} = \mathcal{E}rr_{\Pi}(\mathbf{X}_{\tau}, M)$ . Note that  $\mathbb{E}[e_{\tau,\mathbf{M}}] = e_{\tau}$ . By Markov's inequality,

$$\Pr(e_{\tau,\mathbf{M}} \ge 2e_{\tau}) \le \frac{1}{2}.$$

Therefore, for at least half of the matchings M,  $e_{\tau,M} \leq 2e_{\tau} \leq 4\delta$  (recall that **M** is uniform on the matchings). Let  $\mathcal{M}'$  be the set of matchings M for which  $e_{\tau,M} \leq 2e_{\tau}$ . By the above,  $|\mathcal{M}'| \geq |\mathcal{M}|/2 = m/2 = \Omega(n)$ .

The output of  $\Pi$  depends only on  $\tau$  and on the input to Bob. Therefore, for each fixed matching M, the output of the protocol on inputs  $\mathbf{X}_{\tau}$  and M is a constant triple  $(i_M, j_M, b_M)$ , where  $(i_M, j_M)$  is an edge in M and  $b_M$  is a bit. Let  $G_{\tau}$  be the graph defined by the set of edges  $\{(i_M, j_M)|M \in \mathcal{M}'\}$ . The graph has n nodes and  $|\mathcal{M}'| \geq \Omega(n)$  edges. (Note that here we use the fact the matchings are pairwise disjoint, hence edges corresponding to different matchings must be distinct.) Let  $\mathbf{u} \in \{0, 1\}^{|\mathcal{M}'|}$  be the sequence of bits  $b_M$  for  $M \in \mathcal{M}'$ .

We will use the following proposition to extract an acyclic subgraph of  $G_{\tau}$ :

PROPOSITION 4.3. Every graph G with t edges has an acyclic subgraph with  $\Omega(\sqrt{t})$  edges.

The proof of the proposition is given below. Let then F be an acyclic subgraph of  $G_{\tau}$  with  $|F| = \Omega(\sqrt{n})$  (here, |F| denotes the number of edges in F). Let N denote the  $n \times |F|$  vertex-edge incidence matrix of F, and let  $\mathbf{v} \in \{0,1\}^{|F|}$  denote the projection of  $\mathbf{u}$  on F. For any  $\mathbf{x} \in \{0,1\}^n$ , the vector  $\mathbf{x}N$  taken over GF[2] is of length |F|.

Since F is a subgraph of  $G_{\tau}$  and each edge of  $G_{\tau}$  is associated with a unique matching  $M \in \mathcal{M}'$ , we can label the coordinates of the vectors  $\mathbf{x}N$  and  $\mathbf{v}$  by matchings. Let  $\mathcal{M}_F$  be the set of matchings  $M \in \mathcal{M}'$ , for which  $(i_M, j_M) \in F$ . For a matching  $M \in \mathcal{M}_F$ , we know  $\mathbf{v}_M = b_M$ . On the other hand,  $(\mathbf{x}N)_M = \mathbf{x}_{i_M} \oplus \mathbf{x}_{j_M}$ . Thus, disagreements of the vectors  $\mathbf{v}$  and  $\mathbf{x}N$  correspond to errors of  $\Pi$  on the input  $\mathbf{x}$ . In fact, the number of errors of  $\Pi$  on inputs of the form  $(\mathbf{x}, M)$ , where M varies over  $\mathcal{M}_F$ , is exactly the  $Hamming\ distance$  between the vectors  $\mathbf{x}N$  and  $\mathbf{v}$ .

Let  $\mathbf{F}$  be a uniformly chosen matching from  $\mathcal{M}_F$  and consider  $\mathcal{E}rr_{\Pi}(\mathbf{X}_{\tau}, \mathbf{F})$ —the distributional error of  $\Pi$  on inputs drawn from  $\mathbf{X}_{\tau}$  and  $\mathbf{F}$  independently. Let  $h(\mathbf{x}N, \mathbf{v})$  denote the relative hamming distance between the vectors  $\mathbf{x}N$  and  $\mathbf{v}$ . (That is,  $h(\mathbf{x}N, \mathbf{v}) = (1/|F|) \cdot |\{M \in \mathcal{M}_F | (\mathbf{x}N)_M \neq \mathbf{v}_M\}|.$ ) By the above observation,  $\mathcal{E}rr_{\Pi}(\mathbf{X}_{\tau}, \mathbf{F}) = \mathbb{E}[h(\mathbf{X}_{\tau}N, \mathbf{v})].$ 

There is another way to look at  $\mathcal{E}rr_{\Pi}(\mathbf{X}_{\tau}, \mathbf{F})$ . Recall that for a fixed matching M,  $e_{\tau,M} = \mathcal{E}rr_{\Pi}(\mathbf{X}_{\tau}, M)$ . Recall also that for every matching  $M \in \mathcal{M}'$ ,  $e_{\tau,M} \leq 2e_{\tau}$ . Hence,  $\mathcal{E}rr_{\Pi}(\mathbf{X}_{\tau}, \mathbf{F}) = \mathbb{E}[e_{\tau,\mathbf{F}}] \leq 2e_{\tau}$ . We conclude that  $\mathbb{E}[h(\mathbf{X}_{\tau}N, \mathbf{v})] \leq 2e_{\tau}$ .

Next, we resort to another proposition, whose proof appears below:

PROPOSITION 4.4. Let Z be a random variable on  $\{0,1\}^k$  and suppose there exists a vector  $\mathbf{v} \in \{0,1\}^k$  s.t.  $\mathbb{E}[h(Z,\mathbf{v})] \le \epsilon$  with  $0 \le \epsilon \le 1/2$ . Then,  $H(Z) \le k \cdot H_2(\epsilon)$ .

It follows from the above proposition and the fact  $\mathbb{E}[h(\mathbf{X}_{\tau}N,\mathbf{v})] \leq 2e_{\tau}$  that  $H(\mathbf{X}_{\tau}N) \leq |F| \cdot H_2(2e_{\tau})$ . Note that  $2e_{\tau} \leq 4\delta < 1/2$  as required by the proposition.

The matrix N has full rank, because it is the vertex-edge incidence matrix of an acyclic graph. It follows that the dimension of the null space of N is n - rank(N) = n - |F|. Hence, the mapping  $\mathbf{x} \mapsto \mathbf{x}N$  is a  $2^{n-|F|}$  to 1 mapping. By the first data processing inequality (Theorem 2.1, part 4), since  $H(\mathbf{X}_{\tau}N) \leq |F| \cdot H_2(2e_{\tau})$ , then

$$H(\mathbf{X}_{\tau}) \le |F| \cdot H_2(2e_{\tau}) + \log(2^{n-|F|}) = n - |F| \cdot (1 - H_2(2e_{\tau})) = n - \Omega(\sqrt{n}),$$

since  $H_2(2e_{\tau}) \leq H_2(4\delta) < 1$  when  $2e_{\tau} \leq 4\delta < 1/2$ . This completes the proof of the lemma.  $\square$ 

Proof. [Proposition 4.3] Let  $C_1, C_2, \ldots, C_s$  be the connected components of G, and let  $b_1, b_2, \ldots, b_s$  be the number of edges they have  $(b_1 + b_2 + \cdots + b_s = t)$ .  $C_i$  has  $\Omega(\sqrt{b_i})$  nodes, and thus has a spanning tree with  $\Omega(\sqrt{b_i})$  edges. Therefore, G contains a forest F with at least  $\sum_i \Omega(\sqrt{b_i}) = \Omega(\sqrt{t})$  edges, using the fact that  $\sqrt{u} + \sqrt{v} \ge \sqrt{u + v}$ . F is the desired acyclic subgraph.  $\square$ 

*Proof.* [Proposition 4.4] We will prove the proposition for the case  $\mathbf{v} = 0^k$ . The generalization to other  $\mathbf{v}$ 's is straightforward.

Let  $(Z_1, \ldots, Z_k)$  be the coordinates of Z. Each  $Z_i$  is a Bernoulli random variable and let  $\alpha_i = \Pr[Z_i = 1]$ . We have,

$$\mathbb{E}[h(Z, 0^k)] = \frac{1}{k} \sum_{i=1}^k \mathbb{E}[Z_i] = \frac{1}{k} \sum_{i=1}^k \Pr(Z_i = 1) = \frac{1}{k} \sum_{i=1}^k \alpha_i.$$
 (4.2)

Applying the subadditivity of entropy (Theorem 2.1, part 3), and the concavity of the binary entropy function,

$$H(Z) \le \sum_{i=1}^{k} H(Z_i) = \sum_{i=1}^{k} H_2(\alpha_i) \le k \cdot H_2(\frac{1}{k} \sum_{i=1}^{k} \alpha_i)$$
 (4.3)

Combining Equations 4.2 and 4.3, we obtain:

$$H(Z) \le k \cdot H_2(\mathbb{E}[h(Z, 0^k)]) \le k \cdot H_2(\epsilon),$$

since  $\mathbb{E}[h(Z,0^k)] \leq \epsilon \leq 1/2$  and  $H_2(\cdot)$  is non-decreasing in [0,1/2].  $\square$ 

Next, we describe a public-coin randomized protocol of complexity  $O(\sqrt{n})$  for  $\mathrm{HM}_n$ . Alice uses the shared random string to pick  $O(\sqrt{n})$  locations in [n] and sends the corresponding bits to Bob. A standard birthday paradox argument shows that these bits include the end-points of at least one edge of the matching with constant probability. This shows that our lower bound is tight and thus:

Theorem 4.5. The randomized one-way communication complexity of  $HM_n$  is  $\Theta(\sqrt{n})$ .

5. An exponential separation for Simultaneous Messages. Recall that in the model of Simultaneous Messages (SM), Alice and Bob both send a single message to a referee, after which he computes the output. We prove an exponential separation in this model between quantum and public-coin randomized communication complexity. To this end, we use a restricted version of the Hidden Matching problem.

The Restricted Hidden Matching Problem  $(RHM_n)$ :

Let n be a positive even integer. In the Restricted Hidden Matching Problem, fix  $\mathcal{M}$  to be any set of  $m = \Omega(n)$  pairwise edge-disjoint matchings. Alice is given  $\mathbf{x} \in \{0,1\}^n$  and Bob is given  $M \in \mathcal{M}$ . Their goal is to output a tuple  $\langle i,j,b \rangle$  such that the edge (i,j) belongs to the matching M and  $b = x_i \oplus x_j$ .

The lower bound we proved for  $HM_n$  in the model of one-way communication (Theorem 4.1) is in fact a lower bound for  $RHM_n$ . This lower bound holds also in the SM model since this model is no more powerful than one-way communication (cf. [14]). Hence,

THEOREM 5.1. Any public-coin Simultaneous Messages protocol for computing RHM<sub>n</sub> with error probability at most 1/8 requires  $\Omega(\sqrt{n})$  bits of communication.

On the other hand, the Restricted Hidden Matching Problem can be solved by a quantum protocol with only  $O(\log n)$  communication. Bob sends the index of his matching to the referee using  $O(\log n)$  bits and Alice sends a superposition of her input string using  $O(\log n)$  qubits, similarly to the one-way protocol. Since the referee knows Bob's input matching M, he can perform the same measurement Bob performed in the one-way protocol and compute the XOR of some pair in the matching.

#### 6. The complexity of Boolean Hidden Matching.

**6.1. Lower bound for** 0-error protocols. In order to prove the lower bound for 0-error randomized one-way protocols, we note the following characterization of such protocols for partial functions. Let  $f: \mathcal{X} \times \mathcal{Y} \to \{0,1,*\}$  be a partial Boolean function. We say that the input (x,y) is legal, if  $f(x,y) \neq *$ . A protocol for f is required to be correct only on legal inputs; it is allowed to output arbitrary answers on illegal inputs. The  $confusion\ graph\ G_f$  of f is a graph whose vertex set is  $\mathcal{X}$ ; (x,x') is an edge in  $G_f$  if and only if there exists a y such that both (x,y) and (x',y) are legal inputs and  $f(x,y) \neq f(x',y)$ .

It is known [15] that the deterministic one-way communication complexity of f is  $\log \chi(G_f) + O(1)$ , where  $\chi(G_f)$  is the chromatic number of the graph  $G_f$ . We will obtain a lower bound on the 0-error randomized one-way communication complexity via another measure on  $G_f$ . For any graph G = (V, E), let

$$\theta(G) = \max_{W \subseteq V} \frac{|W|}{\alpha(G_W)},$$

where  $G_W$  is the subgraph of G induced on W and  $\alpha(G_W)$  is the independence number of  $G_W$ . It is easy to see that  $\chi(G) \geq \theta(G)$ . The following theorem gives a lower bound on the 0-error communication complexity of f in terms of  $\theta(G_f)$ .

THEOREM 6.1. The 0-error randomized one-way communication complexity of any partial Boolean function f is at least  $\Omega(\log \theta(G_f))$ .

*Proof.* Let  $G_f = (V, E)$  and let  $W \subseteq V$  achieve the maximum for  $\theta(G_f)$ . Define  $\mu$  to be the uniform distribution on W.

Suppose  $\Pi$  is a randomized 0-error one-way protocol for f with public randomness R, and whose cost is c+1 (Bob just outputs a bit which is the last bit of the transcript). Let  $A(\mathbf{x}, R)$  be the message sent by Alice on input  $\mathbf{x}$ , and let  $B(\tau, y, R)$  be the output of the protocol given by Bob on input y when the message sent by Alice is  $\tau$ . For any legal input (x, y), we have  $\mathbb{E}[|A(x, R)|] \leq c$ , and  $\Pr[B(A(x, R), y, R) = f(x, y)] = 1$ .

Let X be a random input for Alice whose distribution is  $\mu$ . Then  $\mathbb{E}[|A(X,R)|] \leq c$ , where the randomness is now over both X and R. Therefore, there exists a choice  $r^*$  for R such that  $\mathbb{E}[|A(X,r^*)|] \leq c$ . Define a deterministic protocol where  $A'(x) = A(x,r^*)$  and  $B'(\tau,y) = B(\tau,y,r^*)$ . Note that this protocol correctly computes f and  $\mathbb{E}[|A'(X)|] \leq c$ . Let T be the set of messages sent by Alice in this new protocol. For any message  $\tau \in T$ , define  $S_{\tau} = \{x \in W : A'(x) = \tau\}$ . By the definition of  $G_f$ , it follows that  $S_{\tau}$  is an independent set, so  $|S_{\tau}| \leq \alpha(G_W)$ . Therefore, the entropy of the random variable A'(X) satisfies:

$$H(A'(X)) = \sum_{\tau \in T} \frac{|S_{\tau}|}{|W|} \log\left(\frac{|W|}{|S_{\tau}|}\right)$$

$$\geq \sum_{\tau \in T} \frac{|S_{\tau}|}{|W|} \log\left(\frac{|W|}{\alpha(G_W)}\right) = \log \theta(G_f),$$
(6.1)

because the  $S_{\tau}$ 's partition W.

Finally, if we assume that the messages are prefix-free (which can be achieved with a constant factor blow-up in the communication cost), then  $\mathbb{E}[|A'(X)|] \geq \mathrm{H}(A'(X))$  (Theorem 2.3). It follows from Equation 6.1 that  $c = \Omega(\log \theta(G_f))$ .

We use this characterization to prove the lower bound for  $BHM_n$ :

Theorem 6.2. Let n=4p, where p is prime. Then, the 0-error randomized one-way communication complexity of  $BHM_n$  is  $\Omega(n)$ .

*Proof.* Let f denote the partial function BHM<sub>n</sub>. The vertex set of the confusion graph  $G_f$  is  $\{0,1\}^n$ . We next show that  $(\mathbf{x},\mathbf{x}')$  is an edge in  $G_f$  if and only if the Hamming distance between  $\mathbf{x}$  and  $\mathbf{x}'$  is exactly n/2.

Suppose  $(\mathbf{x}, \mathbf{x}')$  is an edge in  $G_f$ . Therefore, there exists a matching M and a vector  $\mathbf{w}$ , so that  $M\mathbf{x} \oplus \mathbf{w} = \mathbf{0}$  and  $M\mathbf{x}' \oplus \mathbf{w} = \mathbf{1}$ , or vice versa. That means that for every edge  $(i, j) \in M$ ,  $x_i \oplus x_j \neq x_i' \oplus x_j'$ , and thus  $\mathbf{x}, \mathbf{x}'$  agree on one of the position i, j and disagree on the other. Hence, the Hamming distance between  $\mathbf{x}$  and  $\mathbf{x}'$  is exactly n/2. Conversely, given two strings  $\mathbf{x}, \mathbf{x}'$  of Hamming distance n/2, let M be any matching between the positions on which  $\mathbf{x}, \mathbf{x}'$  agree and the positions on which they disagree. Let  $\mathbf{w} = M\mathbf{x}$ . Clearly,  $M\mathbf{x} \oplus \mathbf{w} = \mathbf{0}$ . For each edge (i, j) in M we have  $x_i \oplus x_j \neq x_i' \oplus x_j'$ , and therefore  $M\mathbf{x}' \oplus \mathbf{w} = \mathbf{1}$ , implying  $(\mathbf{x}, \mathbf{x}')$  is an edge in  $G_f$ .

If n/2 is odd,  $G_f$  is the bipartite graph between the even and odd parity vertices. Therefore,  $G_f$  is 2-colorable, implying that f has a O(1) protocol (Alice just sends the parity of her input). We will show that the situation changes dramatically when n is a prime multiple of 4.

PROPOSITION 6.3 (Frankl and Wilson [9]). Let m = 4p - 1, where p is prime. Define the graph G = (V, E) where  $V = \{A \subseteq [m] : |A| = 2p - 1\}$ , and  $(A, B) \in E$  if and only if  $|A \cap B| = p - 1$ . Then,

$$\alpha(G) \le \sum_{i=0}^{p-1} \binom{m}{i}.$$

Let m = 4p - 1 = n - 1 and let G be the graph defined by Proposition 6.3. We claim that G is isomorphic to a vertex-induced subgraph of the confusion graph  $G_f$ : for every vertex A in G, the corresponding vertex in  $G_f$  is the characteristic vector of the set  $A \cup \{4p\}$ . Let V denote the vertex set of G; it follows that  $\theta(G_f) > |V|/\alpha(G)$ .

the set  $A \cup \{4p\}$ . Let V denote the vertex set of G; it follows that  $\theta(G_f) \geq |V|/\alpha(G)$ . We have,  $|V| = {m \choose 2p-1} \approx 2^m/\sqrt{m}$ , and by Proposition 6.3 and Theorem 2.1, part  $0, \alpha(G) \leq 2^{mH_2(\gamma)}$ , where  $H_2$  is the binary entropy function and  $\gamma = (p-1)/(4p-1) \leq 1/4$ . The result now follows from Theorem 6.1.  $\square$ 

**6.2. Lower bound for linear randomized protocols.** In this section, we study a natural class of randomized bounded-error protocols for BHM<sub>n</sub> and show a  $\tilde{\Omega}(\sqrt[3]{n})$  communication lower bound for them.

DEFINITION 6.4 (Linear protocols). A deterministic one-way communication complexity protocol is called linear, if for any input  $\mathbf{x} \in \{0,1\}^n$ , Alice's message on  $\mathbf{x}$  is of the form  $A\mathbf{x}$ , where A is a fixed  $c \times n$  Boolean matrix.

A public-coin one-way protocol is linear, if for any input  $\mathbf{x} \in \{0,1\}^n$ , Alice's message on  $\mathbf{x}$  is of the form  $\mathbf{A}\mathbf{x}$ , where  $\mathbf{A}$  is a random  $c \times n$  Boolean matrix chosen using the public random bits.

THEOREM 6.5. Let n be a positive integer multiple of 4, and let  $0 < \delta < 1/2$  be a constant bounded away from 1/2. Then, any  $\delta$ -error public-coin one-way linear protocol for BHM<sub>n</sub> requires  $\Omega(\sqrt[3]{n \log n})$  bits of communication.

*Proof.* Using Yao's Lemma [24], in order to prove the lower bound, it suffices to construct a "hard" distribution  $\mu$  over instances of BHM<sub>n</sub>, and prove a distributional lower bound w.r.t. deterministic one-way linear protocols. We define  $\mu$  as follows: let  $\mathbf{X}$  be a uniformly chosen bitstring in  $\{0,1\}^n$ ; let  $\mathbf{M}$  be a uniformly chosen perfect matching in  $\mathcal{M}_n$ ; and let B be a uniformly chosen bit.  $\mathbf{W}$  is a random bitstring in  $\{0,1\}^{n/2}$ , defined as  $\mathbf{W} \stackrel{\text{def}}{=} \mathbf{M} \mathbf{X} \oplus \mathbf{B}$  (recall that  $\mathbf{B}$  is the vector all of whose entries are B).

Let  $\Pi$  be any deterministic one-way linear protocol that has error probability of at most  $\delta$  when solving BHM<sub>n</sub> on inputs drawn according to  $\mu$ . Let c be the communication cost of  $\Pi$ .

Since  $\Pi$  is deterministic, one-way, and linear, there exists a fixed  $c \times n$  Boolean matrix A, such that the message of  $\Pi$  on any input x is Ax. By adding at most one bit to the communication cost of  $\Pi$ , we can assume 1 is one of the rows of A. We also assume, without loss of generality, that A has a full row rank, because otherwise Alice sends redundant information, which Bob can figure out by himself.

We assume c satisfies  $c^3/\log c \le 3n/4$ , since, otherwise,  $c \ge \Omega(\sqrt[3]{n \log n})$ , and we are done.

For a matrix T, we denote by sp(T) the span of the row vectors of T over the field GF(2). Clearly, for any matrix T,  $\mathbf{0} \in \operatorname{sp}(T)$ . In particular,  $\mathbf{0} \in \operatorname{sp}(M) \cap \operatorname{sp}(A)$ , for any matching  $M \in \mathcal{M}_n$  (recall that we view a matching M as an  $\frac{n}{2} \times n$  edgevertex incidence matrix). By our assumption about  $A, 1 \in \operatorname{sp}(A)$ . Since M is a perfect matching, the sum of its rows is 1, thus  $1 \in \operatorname{sp}(M)$ . We conclude that for any M,  $\{0,1\} \subseteq \operatorname{sp}(M) \cap \operatorname{sp}(A)$ . Let Z be an indicator random variable of the event  $\{\operatorname{sp}(\mathbf{M}) \cap \operatorname{sp}(A) = \{0,1\}\}\$ , meaning that **0** and **1** are the only vectors in the intersection of the spans.

At a high level, our plan for the rest of the proof is as follows. Loosely speaking, for any matching M belonging to the above event (i.e., sp  $M \cap sp(A) = \{0, 1\}$ ) and for any possible input  $\mathbf{x} \neq \mathbf{0}, \mathbf{1}$ , the vectors  $M\mathbf{x}$  and  $A\mathbf{x}$  are linearly independent. This linear independence implies also statistical independence of the random variables  $M\mathbf{X}$ and AX. In particular, it means that Alice's message, AX, has no information about MX, and thus Bob cannot determine whether  $MX \oplus W = 1$  or  $MX \oplus W = 0$ . We conclude that the protocol can succeed only when the event does not happen. We will prove that the probability of this event not happening is  $O(c^3/n)$ , and thus only when  $c > \Omega(\sqrt[3]{n})$ , the success probability of the protocol is sufficiently high. The formal argument follows.

In the protocol  $\Pi$ , Bob observes values of the random variables AX, M, and Wand uses them to predict the random variable B with error probability  $\delta$ . Therefore, by Fano's inequality (Theorem 2.2),

$$H_2(\delta) \ge H(B \mid A\mathbf{X}, \mathbf{M}, \mathbf{W}).$$
 (6.2)

Since conditioning reduces entropy,

$$H(B \mid A\mathbf{X}, \mathbf{M}, \mathbf{W}) \geq H(B \mid A\mathbf{X}, \mathbf{M}, \mathbf{W}, Z)$$

$$= H(B \mid A\mathbf{X}, \mathbf{M}, \mathbf{W}, Z = 1) \cdot \Pr(Z = 1)$$

$$+ H(B \mid A\mathbf{X}, \mathbf{M}, \mathbf{W}, Z = 0) \cdot \Pr(Z = 0)$$

$$\geq H(B \mid A\mathbf{X}, \mathbf{M}, \mathbf{W}, Z = 1) \cdot \Pr(Z = 1).$$
(6.3)

The following two lemmas bound the two factors in the last expression:

LEMMA 6.6. 
$$H(B \mid AX, M, W, Z = 1) = 1$$

Lemma 6.6. 
$$H(B \mid A\mathbf{X}, \mathbf{M}, \mathbf{W}, Z = 1) = 1$$
. Lemma 6.7.  $\Pr(Z = 1) \ge 1 - O(\frac{c^3}{n \log c})$ .

The proofs of the Lemma 6.6 and 6.7 are provided below. Let us first show how the two lemmas derive the theorem. By combining Equations 6.2 and 6.3, and Lemmas 6.6 and 6.7, we have:

$$H_2(\delta) \geq 1 - O\left(\frac{c^3}{n \log c}\right).$$

Therefore,

$$c \ge \Omega(\sqrt[3]{n(1 - H_2(\delta)) \cdot \log(n(1 - H_2(\delta)))})$$
$$= \Omega(\sqrt[3]{n \log n}),$$

since  $H_2(\delta)$  is a constant bounded away from 1. This completes the proof of the theorem.  $\square$ 

*Proof.* [Lemma 6.6] Recall that we assume **1** is one of the rows of A and that A has a full row rank. Let A' be the submatrix of A consisting of all the rows of A, except **1**. Clearly,  $\operatorname{sp}(A') \subseteq \operatorname{sp}(A)$  and  $\mathbf{1} \not\in \operatorname{sp}(A')$ . It follows that the event  $\{\operatorname{sp}(\mathbf{M}) \cap \operatorname{sp}(A) = \{\mathbf{0}, \mathbf{1}\}\}$  is the same as the event  $\{\operatorname{sp}(\mathbf{M}) \cap \operatorname{sp}(A') = \{\mathbf{0}\}\}$ . Thus, from now on we will think of Z as an indicator random variable of the latter.

Observe that since n is a multiple of 4, the parity of the bits of  $\mathbf{w}$  always equals to the parity of the bits of  $\mathbf{x}$ . The parity of the bits of  $\mathbf{x}$  is exactly the inner product  $\mathbf{1}^{t} \cdot \mathbf{x}$ , which is one of the bits in the vector  $A\mathbf{x}$ . It follows that there is a 1-1 mapping f s.t.  $f(A(\mathbf{x}), \mathbf{w}) = (A'(\mathbf{x}), \mathbf{w})$ . By the second data processing inequality (Theorem 2.1, part 5), we can therefore rewrite  $H(B \mid A\mathbf{X}, \mathbf{M}, \mathbf{W}, Z = 1)$  as  $H(B \mid A'\mathbf{X}, \mathbf{M}, \mathbf{W}, Z = 1)$ .

By the definition of mutual information,

$$H(B \mid A'\mathbf{X}, \mathbf{M}, \mathbf{W}, Z = 1)$$
  
=  $H(B \mid \mathbf{M}, \mathbf{W}, Z = 1) - I(B ; A'\mathbf{X} \mid \mathbf{M}, \mathbf{W}, Z = 1).$ 

The next proposition shows that the random variables B,  $\mathbf{M}$ , and  $\mathbf{W}$  are mutually independent given the event  $\{Z=1\}$ , which together with Theorem 2.1, part 2, implies that  $H(B \mid \mathbf{M}, \mathbf{W}, Z=1) = H(B|Z=1)$ . Since B and Z are independent (Z is a function of  $\mathbf{M}$  only), then H(B|Z=1) = H(B) = 1. Thus, in order to prove the lemma it would suffice to show that  $I(B; A'\mathbf{X} \mid \mathbf{M}, \mathbf{W}, Z=1) = 0$ .

PROPOSITION 6.8. The random variables  $B, \mathbf{M}$ , and  $\mathbf{W}$  are mutually independent, given the event  $\{Z = 1\}$ .

*Proof.* We will show the random variables B, M, and W are mutually independent unconditionally. This independence would then hold even given the event  $\{Z=1\}$ , because this event is a function of M only.

The random variables B and  $\mathbf{M}$  are independent, by definition. Let M be any value of the random variable  $\mathbf{M}$ , and let b be any value of the random variable B. In order to show the desired independence, we need to prove that for any possible value  $\mathbf{w}$  of  $\mathbf{W}$ ,  $\Pr(\mathbf{W} = \mathbf{w} \mid \mathbf{M} = M, B = b) = \Pr(\mathbf{W} = \mathbf{w})$ .

Using conditional probability, we can rewrite  $\Pr(\mathbf{W} = \mathbf{w} \mid \mathbf{M} = M, B = b)$  as follows:

$$\begin{aligned} & \Pr(\mathbf{W} = \mathbf{w} \mid \mathbf{M} = M, B = b) = \\ & \sum_{\mathbf{x} \in \{0,1\}^n} \Pr(\mathbf{W} = \mathbf{w} \mid \mathbf{M} = M, B = b, \mathbf{X} = \mathbf{x}) \\ & \cdot \Pr(\mathbf{X} = \mathbf{x} \mid \mathbf{M} = M, B = b). \end{aligned}$$

Since  $\mathbf{X}, \mathbf{M}$ , and B are mutually independent by definition, then  $\Pr(\mathbf{X} = \mathbf{x} \mid \mathbf{M} = M, B = b) = \Pr(\mathbf{X} = \mathbf{x}) = 1/2^n$ .  $\Pr(\mathbf{W} = \mathbf{w} \mid \mathbf{M} = M, B = b, \mathbf{X} = \mathbf{x}) = 1$  only if  $\mathbf{w} = M\mathbf{x} \oplus \mathbf{b}$ , and it is 0 otherwise. The number of  $\mathbf{x}$ 's that satisfy this condition is the number of solutions to the linear system  $M\mathbf{x} = \mathbf{w} \oplus \mathbf{b}$  over  $\mathbb{Z}_2^n$ . Since M is an  $\frac{n}{2} \times n$  matrix that has a full row rank, this number is  $2^{n/2}$ . Therefore,  $\Pr(\mathbf{W} = \mathbf{w} \mid \mathbf{M} = M, B = b) = 2^{n/2}/2^n = 1/2^{n/2}$ .

Consider now the quantity  $Pr(\mathbf{W} = \mathbf{w})$ . Using conditional probability we can rewrite it as:

$$Pr(\mathbf{W} = \mathbf{w}) = \sum_{M,b} Pr(\mathbf{W} = \mathbf{w} \mid \mathbf{M} = M, B = b) \cdot Pr(\mathbf{M} = M, B = b).$$

We already proved that for all M and b,  $\Pr(\mathbf{W} = \mathbf{w} \mid \mathbf{M} = M, B = b) = 1/2^{n/2}$ . Therefore, also  $\Pr(\mathbf{W} = \mathbf{w}) = 1/2^{n/2}$ , completing the proof.  $\square$ 

Next we prove  $I(B ; A'X \mid M, W, Z = 1) = 0$ . By the chain rule for mutual information,

$$I(B, \mathbf{M}, \mathbf{W}; A'\mathbf{X} \mid Z = 1)$$
  
=  $I(\mathbf{M}, \mathbf{W}; A'\mathbf{X} \mid Z = 1) + I(B; A'\mathbf{X} \mid \mathbf{M}, \mathbf{W}, Z = 1).$ 

Since mutual information is always a non-negative quantity, it would thus suffice to show that  $I(B, \mathbf{M}, \mathbf{W} ; A'\mathbf{X} | Z = 1) = 0$ .

The function  $f(b, M, \mathbf{w}) = (b, M, \mathbf{w} \oplus \mathbf{b})$  is a 1-1 function. Note that  $f(B, \mathbf{M}, \mathbf{W}) = \mathbf{0}$   $(B, \mathbf{M}, \mathbf{W} \oplus \mathbf{B}) = (B, \mathbf{M}, \mathbf{MX})$ . Therefore, by the second data processing inequality (Theorem 2.1, part 5), we have:

$$I(B, M, W; A'X | Z = 1) = I(B, M, MX; A'X | Z = 1).$$

Using again the chain rule for mutual information we have:

$$I(B, \mathbf{M}, \mathbf{MX}; A'\mathbf{X} \mid Z = 1) =$$

$$I(B, \mathbf{M}; A'\mathbf{X} \mid Z = 1) + I(\mathbf{MX}; A'\mathbf{X} \mid B, \mathbf{M}, Z = 1).$$

$$(6.4)$$

We next show that each of the above mutual information quantities is 0. By the definition of the input distribution  $\mu$ , the random variables  $B, \mathbf{M}$ , and  $\mathbf{X}$  are mutually independent. This holds even given the event  $\{Z=1\}$ , because the latter is a function of  $\mathbf{M}$  only. It follows that also  $B, \mathbf{M}, A'\mathbf{X}$  are mutually independent given the event  $\{Z=1\}$ , and thus  $I(B, \mathbf{M}; A'\mathbf{X} \mid Z=1) = 0$  (Theorem 2.1, part 7).

As for the second mutual information quantity on the RHS of Equation 6.4, we use again the independence of B,  $\mathbf{M}$ , and  $A'\mathbf{X}$  given  $\{Z=1\}$  as well as Theorem 2.1, part 8, to derive  $I(\mathbf{MX} \; ; \; A'\mathbf{X} \mid B, \mathbf{M}, Z=1) = I(\mathbf{MX} \; ; \; A'\mathbf{X} \mid \mathbf{M}, Z=1)$ . The following proposition proves that for any matching M satisfying the condition indicated by the event  $\{Z=1\}$ , the random variables  $M\mathbf{X}$  and  $A'\mathbf{X}$  are independent. It then follows that  $I(\mathbf{MX} \; ; \; A'\mathbf{X} \mid \mathbf{M}, Z=1) = 0$ .

PROPOSITION 6.9. For any matching  $M \in \mathcal{M}_n$  satisfying the condition  $\operatorname{sp}(M) \cap \operatorname{sp}(A') = \{0\}$ , the random variables  $M\mathbf{X}$  and  $A'\mathbf{X}$  are independent.

*Proof.* Let  $\mathbf{z}$  be any possible value for the random variable  $M\mathbf{X}$  and let  $\mathbf{y}$  be any possible value for the random variable  $A'\mathbf{X}$ . In order to prove the independence, we need to show that  $\Pr(M\mathbf{X} = \mathbf{z} \mid A'\mathbf{X} = \mathbf{y}) = \Pr(M\mathbf{X} = \mathbf{z})$ .

M is an  $\frac{n}{2} \times n$  Boolean matrix that has a full row rank. Therefore, the number of solutions to the linear system  $M\mathbf{x} = \mathbf{z}$  over  $\mathbb{Z}_2^n$  is exactly  $2^{n/2}$ . Recall that  $\mathbf{X}$  was chosen uniformly at random from  $\mathbb{Z}_2^n$ . Therefore,  $\Pr(M\mathbf{X} = \mathbf{z}) = 1/2^{n/2}$ .

By the definition of conditional probability,  $\Pr(M\mathbf{X} = \mathbf{z} \mid A'\mathbf{X} = \mathbf{y}) = \Pr(M\mathbf{X} = \mathbf{z}, A'\mathbf{X} = \mathbf{y}) / \Pr(A'\mathbf{X} = \mathbf{y})$ . Since A' is a  $(c-1) \times n$  Boolean matrix and has a full row rank, the same argument as above shows that  $\Pr(A'\mathbf{X} = \mathbf{y}) = 1/2^{n-c+1}$ . Let

D be an  $(\frac{n}{2}+c-1) \times n$  matrix, which is composed by putting M on top of A'. Since  $\operatorname{sp}(M) \cap \operatorname{sp}(A') = \{\mathbf{0}\}$ , D is has a full row rank. We thus obtain  $\operatorname{Pr}(M\mathbf{X} = \mathbf{z}, A'\mathbf{X} = \mathbf{y}) = \operatorname{Pr}(D\mathbf{X} = (\mathbf{z}, \mathbf{y})) = 1/2^{n/2-c+1}$ . Hence,  $\operatorname{Pr}(M\mathbf{X} = \mathbf{z} \mid A'\mathbf{X} = \mathbf{y}) = 2^{n/2-c+1}/2^{n-c+1} = 1/2^{n/2} = \operatorname{Pr}(M\mathbf{X} = \mathbf{z})$ . The proposition follows. □

This completes the proof of Lemma 6.6.

We now turn to the proof of Lemma 6.7.

Proof. [Lemma 6.7] Denote the event  $\{\operatorname{sp}(\mathbf{M}) \cap \operatorname{sp}(A) \neq \{\mathbf{0}, \mathbf{1}\}\}\$  by E. We would like to prove  $\Pr(E) \leq O(c^3/(n\log c))$ . For  $0 \leq k \leq n$ , define  $\operatorname{sp}_k(A)$  to be the vectors in  $\operatorname{sp}(A)$  whose Hamming weight is k. Define  $E_k$  to be the event  $\{\operatorname{sp}(\mathbf{M}) \cap \operatorname{sp}_k(A) \neq \emptyset\}$ . Since  $\operatorname{sp}_0(A) = \{\mathbf{0}\}$  and  $\operatorname{sp}_n(A) = \{\mathbf{1}\}$ , the event E can be rewritten as  $\bigvee_{k=1}^{n-1} E_k$ . Thus, using the union bound, we can bound the probability of E as follows:

$$\Pr(E) \le \sum_{k=1}^{n-1} \Pr(\operatorname{sp}(\mathbf{M}) \cap \operatorname{sp}_k(A) \neq \emptyset).$$
 (6.5)

Let M be any matching in  $\mathcal{M}_n$ . Any vector  $\mathbf{v}$  in  $\mathrm{sp}(M)$ , when viewed as a set  $S_{\mathbf{v}}$  (i.e.,  $\mathbf{v}$  is the characteristic vector of  $S_{\mathbf{v}}$ ), is a disjoint union of edges from M. We thus immediately conclude that  $\mathbf{v}$  has to have an even Hamming weight. This implies that for all odd  $1 \le k \le n-1$ ,

$$\Pr(\operatorname{sp}(\mathbf{M}) \cap \operatorname{sp}_k(A) \neq \emptyset) = 0. \tag{6.6}$$

Consider then an even k, and let  $\mathbf{v}$  be any vector in  $\operatorname{sp}_k(A)$ . If  $\mathbf{v}$  belongs to  $\operatorname{sp}(M)$ , then M can be partitioned into two perfect "sub-matchings": a perfect matching on  $S_{\mathbf{v}}$  and perfect matching on  $[n] \setminus S_{\mathbf{v}}$ . We conclude that the number of matchings M in  $\mathcal{M}_n$ , for which  $\mathbf{v} \in \operatorname{sp}(M)$ , is exactly  $m_k \cdot m_{n-k}$ , where  $m_\ell$  is the number of perfect matchings on  $\ell$  nodes. Note that  $m_\ell = \frac{\ell!}{(\ell/2)!2^{\ell/2}}$ , and thus,

$$\Pr(\mathbf{v} \in \mathrm{sp}(\mathbf{M})) = \frac{m_k \cdot m_{n-k}}{m_n} = \frac{\binom{\frac{n}{2}}{\frac{k}{2}}}{\binom{n}{k}}.$$

It follows, by the union bound, that for any even k,

$$\Pr(\operatorname{sp}(\mathbf{M}) \cap \operatorname{sp}_k(A) \neq \emptyset) \leq |\operatorname{sp}_k(A)| \cdot \frac{\binom{\frac{n}{2}}{k}}{\binom{n}{k}}. \tag{6.7}$$

Since  $\mathbf{1} \in \operatorname{sp}(A)$ , then  $|\operatorname{sp}_k(A)| = |\operatorname{sp}_{n-k}(A)|$ , for all  $0 \le k \le n$ . Combining this and Equations 6.5, 6.6, and 6.7, it would thus suffice to prove the following:

$$\sum_{j=1}^{n/4} |\operatorname{sp}_{2j}(A)| \cdot \frac{\binom{\frac{n}{2}}{j}}{\binom{n}{2j}} \le O(\frac{c^3}{n \log c}). \tag{6.8}$$

We start by bounding the ratio in each of the terms:

$$\frac{\binom{\frac{n}{2}}{j}}{\binom{n}{2j}} = \frac{(\frac{n}{2})! \cdot (2j)! \cdot (n-2j)!}{(\frac{n}{2}-j)! \cdot j! \cdot n!} 
= \frac{\frac{\frac{n}{2} \cdots (\frac{n}{2}-j+1) \cdot (2j) \cdots (j+1)}{n \cdots (n-2j+1)} 
\leq (\frac{1}{2})^j \cdot (\frac{2j}{n-j})^j = (\frac{j}{n-j})^j \leq (\frac{4j}{3n})^j.$$
(6.9)

The last inequality follows from the fact  $j \leq n/4$ . We next bound  $|\operatorname{sp}_{2i}(A)|$  for small values of j:

PROPOSITION 6.10. For every  $1 \le j \le \lfloor c/2 \rfloor$ ,  $|\operatorname{sp}_{2j}(A)| \le \sum_{i=1}^{2j} {c \choose i}$ . Proof. Using just the elementary row operations of Gaussian Elimination, we can transform A into a matrix A', which has exactly the same span as A, and that has the  $c \times c$  identity matrix as a submatrix. (Recall that A has a full row rank of c.) It follows that any linear combination of t rows of A' results in a vector of Hamming weight at least t. Therefore, the only linear combinations to give vectors in  $\operatorname{sp}_{2i}(A)$ are ones that use at most 2j rows of A'. The proposition follows, since the number of the latter is  $\sum_{i=1}^{2j} {c \choose i}$ .  $\square$  We conclude that for  $1 \leq j \leq \lfloor c/2 \rfloor$ ,  $|\operatorname{sp}_{2j}(A)| \leq \sum_{i=1}^{2j} c^i =$  $\frac{c^{2j}-1}{c-1} \cdot c \leq 2c^{2j}$  (assuming  $c \geq 2$ ). On the other hand, we have for all  $1 \leq j \leq n/4$ ,  $|\operatorname{sp}_{2j}(A)| \leq |\operatorname{sp}(A)| \leq 2^c$ . Note that the quantity  $2c^{2j}$  exceeds  $2^c$ , when  $j \geq \frac{c-1}{2\log c}$ We thus define  $\ell \stackrel{\text{def}}{=} \lfloor \frac{c-1}{2\log c} \rfloor$  and break the sum on the RHS of Equation 6.8, which we need to bound, into two parts as follows:

$$\sum_{j=1}^{n/4} |\operatorname{sp}_{2j}(A)| \cdot \frac{\binom{\frac{n}{2}}{j}}{\binom{n}{2j}} \\
= \sum_{j=1}^{\ell} |\operatorname{sp}_{2j}(A)| \cdot \frac{\binom{\frac{n}{2}}{j}}{\binom{n}{2j}} + \sum_{j=\ell+1}^{n/4} |\operatorname{sp}_{2j}(A)| \cdot \frac{\binom{\frac{n}{2}}{j}}{\binom{n}{2j}} \\
\leq \sum_{j=1}^{\ell} (2c^{2j}) \cdot (\frac{4j}{3n})^j + 2^c \cdot \max_{\ell < j \le n/4} (\frac{4j}{3n})^j.$$
(6.10)

The last inequality follows from Equation 6.9, from Proposition 6.10, and from the fact  $\sum_{j=\ell+1}^{n/4} |\operatorname{sp}_{2j}(A)| \le |\operatorname{sp}(A)| \le 2^c$ . We bound each of the terms on the RHS of Equation 6.10 separately. We start with the first one:

$$\sum_{j=1}^{\ell} (2c^{2j}) \cdot (\frac{4j}{3n})^j = 2 \cdot \sum_{j=1}^{\ell} (\frac{4c^2j}{3n})^j \le 2 \cdot \sum_{j=1}^{\ell} (\frac{4c^2\ell}{3n})^j$$

Recall that we assumed  $c^3/\log c \le 3n/4$ . Hence,  $4c^2\ell/(3n) \le 2c^3/(3n\log c) \le 1/2$ . We can thus bound the geometric series as follows:

$$2 \cdot \sum_{j=1}^{\ell} \left(\frac{4c^{2}\ell}{3n}\right)^{j} \le 2 \cdot \frac{4c^{2}\ell}{3n} \cdot \frac{1}{1 - \frac{4c^{2}\ell}{3n}} \le \frac{16c^{2}\ell}{3n}$$
$$\le \frac{8c^{3}}{3n\log c}.$$
 (6.11)

We now turn to bounding the second term on the RHS of Equation 6.10.

Proposition 6.11. The function  $g(j) = (aj)^j$ , where a > 0, has a local minimum at  $j^* = \frac{1}{ae}$  in the interval  $(0, \infty)$ .

*Proof.* We rewrite g as follows:  $g(j) = e^{j \ln(aj)}$ . The derivative of g is the following:

$$g'(j) = e^{j \ln(aj)} \cdot (\ln(aj) + 1).$$

Thus, g has a local extremum at  $j^* = \frac{1}{ae}$ . We next verify it is a local minimum. The second derivative of g is the following:

$$g''(j) = g'(j) \cdot (\ln(aj) + 1) + g(j) \cdot \frac{1}{j} = g(j) \cdot ((\ln(aj) + 1)^2 + \frac{1}{j}).$$

Since g is positive in the interval  $(0, \infty)$ , then g''(j) > 0 for all j in this interval. In particular,  $g''(j^*) > 0$ , implying  $j^*$  is a local minimum.  $\square$ 

Proposition 6.11 shows that the function  $g(j)=(aj)^j$  has a local minimum at  $j^*=\frac{1}{ae}$  in the interval  $(0,\infty)$ . In our case  $a=\frac{4}{3n}$ , and thus  $j^*=3n/(4e)\geq n/4$ . Therefore the maximum of  $(\frac{4j}{3n})^j$  in the interval  $[\ell,n/4]$  is obtained at  $j=\ell$ . We conclude that:

$$2^{c} \cdot \max_{\ell < j \le n/4} \left(\frac{4j}{3n}\right)^{j} \le 2^{c} \cdot \left(\frac{4\ell}{3n}\right)^{\ell} \le 2^{c} \cdot \left(\frac{2c}{3n \log c}\right)^{\frac{c}{2\log c}}$$

$$\le \left(\frac{4c}{3n \log c}\right)^{c} \le \left(\frac{2c}{n}\right)^{c} \le \frac{c}{n}$$

$$\le \frac{c^{3}}{n \log c}.$$
(6.12)

In the next to the last inequality we used the fact  $2 \le c \le n/4$ . Combining Equations 6.10, 6.11, and 6.12, we have

$$\sum_{j=1}^{n/4} |\operatorname{sp}_{2j}(A)| \cdot \frac{\binom{\frac{n}{2}}{j}}{\binom{n}{2j}} \le \frac{8c^3}{3n \log c} + \frac{c^3}{n \log c} \le O(\frac{c^3}{n \log c}).$$

This completes the proof of Lemma 6.7.  $\square$ 

**Remark.** As mentioned previously, the randomized lower bound for  $\operatorname{HM}_n$  holds also for a restricted version of the Hidden Matching problem (which we denoted by  $\operatorname{RHM}_n$ ), in which Bob's input is a matching M taken from a small set  $\mathcal{M}$  of  $\Theta(n)$  disjoint matchings only. One can define an analogous restricted version of  $\operatorname{BHM}_n$ , denoted  $\operatorname{RBHM}_n$ . However, in this case the complexity of  $\operatorname{BHM}_n$  and  $\operatorname{RBHM}_n$  are entirely different. By Aaronson's result [1], and by our  $O(\log n)$  bit quantum upper bound for  $\operatorname{BHM}_n$  (which, of course, works also for  $\operatorname{RBHM}_n$ ), the deterministic one-way communication complexity of  $\operatorname{RBHM}_n$  is only  $O(\log^2 n \cdot \log \log n)$ . On the other hand, the deterministic (and even 0-error randomized) one-way communication complexity of  $\operatorname{BHM}_n$  is  $\Omega(n)$  (Theorem 6.2). Hence, there is an exponential gap between the two.

7. Open problems. The main question in quantum communication complexity is to characterize its power in relation to classical communication complexity. For partial Boolean functions it was known that quantum two-way communication complexity could be exponentially lower than the classical one [20]. Here we prove a similar result for a relation for one-way communication complexity and Simultaneous Messages. The main open question is to find the relation between quantum and classical communication complexity for total functions. Are they polynomially related for all total functions? Is this relationship even tighter in the case of one-way communication complexity? Moreover, can we show an exponential separation between quantum one-way communication complexity and randomized two-way communication complexity?

**Acknowledgments.** We would like to thank Umesh Vazirani, Ashwin Nayak and Kunal Talwar for helpful discussions.

#### REFERENCES

[1] S. AARONSON, Limitations of quantum advice and one-way communication, in Proceedings of the 19th IEEE Conference on Computational Complexity (CCC), 2004, pp. 320–332.

- [2] F. Ablayev, Lower bounds for one-way probabilistic communication complexity and their application to space complexity, Theoretical Computer Science, 157 (1996), pp. 139–159.
- [3] Andris Ambainis, Ashwin Nayak, Amnon Ta-Shma, and Umesh V. Vazirani, Dense quantum coding and quantum finite automata., Journal of the ACM, 49 (2002), pp. 496–511.
- [4] A. Ambainis, L. J. Schulman, A. Ta-Shma, U. V. Vazirani, and A. Wigderson, The quantum communication complexity of sampling, SIAM J. on Computing, 32 (2003), pp. 1570– 1585.
- [5] L. Babai and P. G. Kimmel, Randomized simultaneous messages: Solution of a problem of Yao in communication complexity, in Proceedings of the 12th IEEE Conference on Computational Complexity (CCC), 1997, pp. 239–246.
- [6] H. Buhrman, R. Cleve, J. Watrous, and R. de Wolf, Quantum fingerprinting, Physical Review Letters, 87 (2001).
- [7] H. Buhrman, R. Cleve, and A. Wigderson, Quantum vs. classical communication and computation, in Proceedings of the 30th ACM Symposium on Theory of Computing (STOC), 1998, pp. 63–68.
- [8] T. M. Cover and J. A. Thomas, Elements of Information Theory, John Wiley & Sons, Inc., 1991.
- [9] P. Frankl and R. M. Wilson, Intersection theorems with geometric consequences, Combinatorica, 1 (1981), pp. 357–368.
- [10] Dmitry Gavinsky, Julia Kempe, Oded Regev, and Ronald de Wolf, Bounded-error quantum state identification and exponential separations in communication complexity. To appear in ACM Symposium on Theory of Computing (STOC), 2006.
- [11] I. Kerenidis and R. de Wolf, Exponential lower bound for 2-query locally decodable codes via quantum argument, in Proceedings of the 35th ACM Symposium on Theory of Computing (STOC), 2003, pp. 106–115.
- [12] H. Klauck, On quantum and probabilistic communication: Las Vegas and one-way protocols, in Proceedings of the 32nd ACM Symposium on Theory of Computing (STOC), 2000, pp. 644–651.
- [13] I. Kremer, Quantum Communication, Master's Thesis, The Hebrew University of Jerusalem, 1995.
- [14] I. Kremer, N. Nisan, and D. Ron, On randomized one-round communication complexity, Computational Complexity, 8 (1999), pp. 21–49.
- [15] E. Kushilevitz and N. Nisan, Communication Complexity, Cambridge University Press, 1997.
- [16] I. Newman, Private vs. common random bits in communication complexity, Information Processing Letters, 39 (1991), pp. 67–71.
- [17] I. Newman and M. Szegedy, Public vs. private coin flips in one round communication games, in Proceedings of the 28th ACM Symposium on Theory of Computing (STOC), 1996, pp. 561–570.
- [18] M.A. Nielsen and I.L. Chuang, Quantum Computation and Quantum Information, Cambridge University Press, 2000.
- [19] C. H. Papadimitriou and M. Sipser, Communication complexity, Journal of Computer and System Sciences, 28 (1984), pp. 260–269.
- [20] R. Raz, Exponential separation of quantum and classical communication complexity, in Proceedings of the 31st ACM Symposium on Theory of Computing (STOC), 1999, pp. 358–367.
- [21] P. Sen and S. Venkatesh, Lower bounds in the quantum cell probe model, in Proceedings of the 28th ICALP, volume 2076, 2001, pp. 358–369.
- [22] P. W. Shor, Polynomial-time algorithms for prime factorization and discrete logarithms on a quantum computer, SIAM J. on Computing, 26 (1997), pp. 1484–1509.
- [23] A. C-C. Yao, Some complexity questions related to distributive computing, in Proceedings of the 11th ACM Symposium on Theory of Computing (STOC), 1979, pp. 209–213.
- [24] , Lower bounds by probabilistic arguments, in Proceedings of the 24th Annual IEEE Symposium on Foundations of Computer Science (FOCS), 1983, pp. 420–428.
- [25] , Quantum circuit complexity, in Proceedings of the 34th IEEE Annual Symposium on Foundations of Computer Science (FOCS), Los Alamitos, CA, 1993, pp. 352–361.