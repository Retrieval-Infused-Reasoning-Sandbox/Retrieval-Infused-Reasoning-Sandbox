# Rectangles Are Nonnegative Juntas

Mika G¨o¨os<sup>1</sup> Shachar Lovett<sup>2</sup> Raghu Meka<sup>3</sup> Thomas Watson<sup>4</sup> David Zuckerman<sup>5</sup>

 Department of Computer Science, University of Toronto Computer Science and Engineering, University of California, San Diego Department of Computer Science, University of California, Los Angeles Department of Computer Science, University of Memphis

<sup>5</sup> Department of Computer Science, University of Texas at Austin

October 1, 2016

### Abstract

We develop a new method to prove communication lower bounds for composed functions of the form f ◦ g <sup>n</sup> where f is any boolean function on n inputs and g is a sufficiently "hard" two-party gadget. Our main structure theorem states that each rectangle in the communication matrix of f ◦ g n can be simulated by a nonnegative combination of juntas. This is a new formalization for the intuition that each low-communication randomized protocol can only "query" few inputs of f as encoded by the gadget g. Consequently, we characterize the communication complexity of f ◦ g n in all known one-sided (i.e., not closed under complement) zero-communication models by a corresponding query complexity measure of f. These models in turn capture important lower bound techniques such as corruption, smooth rectangle bound, relaxed partition bound, and extended discrepancy.

As applications, we resolve several open problems from prior work: We show that SBPcc (a class characterized by corruption) is not closed under intersection. An immediate corollary is that MAcc 6= SBPcc. These results answer questions of Klauck (CCC 2003) and B¨ohler et al. (JCSS 2006). We also show that approximate nonnegative rank of partial boolean matrices does not admit efficient error reduction. This answers a question of Kol et al. (ICALP 2014) for partial matrices. In subsequent work, our structure theorem has been applied to resolve the communication complexity of the Clique vs. Independent Set problem.

Most of this work was done while the authors were visiting Microsoft Research, Silicon Valley Lab at various times. Shachar Lovett was supported in part by NSF CAREER award 1350481. David Zuckerman was supported in part by NSF Grant CCF-1218723. An extended abstract of this work was published as [\[GLM](#page-35-0)<sup>+</sup>15].

## Contents

| 1 |                                              | Introduction<br>3                                  |    |  |  |  |
|---|----------------------------------------------|----------------------------------------------------|----|--|--|--|
|   | 1.1                                          | Main structural result: Junta Theorem<br>          | 3  |  |  |  |
|   | 1.2                                          | Communication versus query: Simulation Theorem<br> | 5  |  |  |  |
|   | 1.3                                          | Applications<br>                                   | 7  |  |  |  |
|   | 1.4                                          | Open problems and subsequent developments<br>      | 8  |  |  |  |
|   | 1.5                                          | Notational conventions<br>                         | 9  |  |  |  |
| 2 |                                              | Proof of the Junta Theorem<br>10                   |    |  |  |  |
|   | 2.1                                          | Proof overview<br>                                 | 10 |  |  |  |
|   | 2.2                                          | Block-wise density<br>                             | 10 |  |  |  |
|   | 2.3                                          | Reduction to a packing problem<br>                 | 12 |  |  |  |
|   | 2.4                                          | Solving the packing problem<br>                    | 13 |  |  |  |
|   |                                              | 2.4.1<br>Core packing step<br>                     | 14 |  |  |  |
|   |                                              | 2.4.2<br>Pruning step<br>                          | 16 |  |  |  |
|   |                                              |                                                    |    |  |  |  |
| 3 |                                              | Definitions of models                              | 17 |  |  |  |
|   | 3.1                                          | Restricted communication models<br>                | 18 |  |  |  |
|   | 3.2                                          | Unrestricted communication models<br>              | 20 |  |  |  |
|   | 3.3                                          | Query models<br>                                   | 21 |  |  |  |
| 4 | Proof of the Simulation Theorem<br>22        |                                                    |    |  |  |  |
|   | 4.1                                          | Communication lower bounds<br>                     | 22 |  |  |  |
|   | 4.2                                          | Communication upper bounds<br>                     | 23 |  |  |  |
| 5 | Applications of the Simulation Theorem<br>24 |                                                    |    |  |  |  |
|   | 5.1                                          | Nonclosure under intersection<br>                  | 24 |  |  |  |
|   | 5.2                                          | Unamplifiability of error<br>                      | 26 |  |  |  |
|   |                                              |                                                    |    |  |  |  |
| 6 |                                              | Unrestricted–restricted equivalences               | 28 |  |  |  |
|   | 6.1                                          | The Truncation Lemma<br>                           | 28 |  |  |  |
|   | 6.2                                          | Proofs of unrestricted–restricted equivalences<br> | 30 |  |  |  |
| A |                                              | Appendix: Additional proofs                        | 32 |  |  |  |
|   | A.1                                          | Proof of Fact 24<br>                               | 32 |  |  |  |
|   | A.2                                          | Proof of Fact 27<br>                               | 32 |  |  |  |
|   | A.3                                          | Proof of Fact 36<br>                               | 33 |  |  |  |
|   | A.4                                          | Proof of Fact 35<br>                               | 33 |  |  |  |
|   |                                              |                                                    |    |  |  |  |
|   | References                                   |                                                    | 39 |  |  |  |

## <span id="page-2-0"></span>1 Introduction

Many functions studied in communication complexity (e.g., equality, set-disjointness, inner-product, gap-Hamming; see [\[KN97,](#page-36-0) [Juk12\]](#page-36-1)) are composed functions of the form f ◦ g <sup>n</sup> where f : {0, 1} <sup>n</sup> → {0, 1, ∗} is a partial function and g : X × Y → {0, 1} is some small two-party function, often called a gadget. Here Alice and Bob are given inputs x ∈ X <sup>n</sup> and y ∈ Y<sup>n</sup> , respectively; we think of the inputs as being partitioned into blocks x<sup>i</sup> ∈ X and y<sup>i</sup> ∈ Y for i ∈ [n]. Their goal is to compute

$$(f \circ g^n)(x,y) := f(g(x_1,y_1),\ldots,g(x_n,y_n)).$$

Intuitively, the difficulty in computing f ◦ g n stems from the fact that for any i, the i-th input zi := g(x<sup>i</sup> , yi) to f remains unknown to either party until they decide to communicate enough information about x<sup>i</sup> and y<sup>i</sup> . Indeed, an educated guess is that—assuming g is chosen carefully—the communication complexity of f ◦ g n should be explained by some query measure of f.

This work is about formalizing the above intuition. Our main result is the following.

Simulation Theorem [\(Theorem 2,](#page-5-0) informally). Many types of randomized protocols for f ◦ g n can be simulated by a corresponding type of randomized decision tree for f.

This result makes it easy to prove strong lower bounds for f ◦g n in all known one-sided (and some two-sided) zero-communication models. Here a zero-communication protocol is understood in the sense of [\[KLL](#page-36-2)+15] as a probability distribution over (labeled) rectangles R = X ×Y (where X ⊆ X <sup>n</sup> and Y ⊆ Y<sup>n</sup> ) together with some acceptance criterion (and hence no communication is needed for Alice and Bob to select a rectangle, since it can be sampled with public randomness). Such models can be used to capture all known rectangle-based lower bound techniques used in communication complexity. This includes widely studied measures such as corruption [\[Yao83,](#page-38-0) [BFS86,](#page-34-0) [Raz92,](#page-37-0) [Kla03,](#page-36-3) [BPSW06,](#page-34-1) [She12a,](#page-38-1) [GW16\]](#page-35-1), smooth rectangle bound [\[JK10,](#page-36-4) [Kla10,](#page-36-5) [CKW12,](#page-34-2) [JY12,](#page-36-6) [HJ13,](#page-36-7) [KMSY14\]](#page-36-8), relaxed partition bound [\[KLL](#page-36-2)+15], and extended discrepancy [\[Kla03,](#page-36-3) [GL14\]](#page-35-2); see [\[JK10\]](#page-36-4) for an extensive catalog. The Simulation Theorem applies to all these measures: it reduces the task of understanding a specific communication complexity measure of f ◦ g n to the task of understanding a corresponding query complexity measure of f, which is typically a far easier task.

## <span id="page-2-1"></span>1.1 Main structural result: Junta Theorem

In order to motivate our approach (and to introduce notation), we start by reviewing some previous influential work in communication complexity.

Prior work: Approximation by polynomials. A long line of prior work has developed a framework of polynomial approximation to analyze the communication complexity of composed functions. Building on the work of Razborov [\[Raz03\]](#page-37-1), a general framework was introduced by Sherstov [\[She09,](#page-37-2) [She11a\]](#page-38-2) (called the pattern matrix method) and independently by Shi and Zhu [\[SZ09\]](#page-38-3) (called the block-composition method). See also the survey [\[She08\]](#page-37-3). Both methods have since been studied in the two-party setting [\[LZ10,](#page-37-4) [RS10,](#page-37-5) [She11b\]](#page-38-4) and also the multiparty setting [\[LS09b,](#page-37-6) [AC08,](#page-34-3) [Cha08,](#page-34-4) [She12b,](#page-38-5) [She14,](#page-38-6) [RY15\]](#page-37-7).

One way to phrase the approach taken in these works (a "primal" point of view championed in [\[She12b\]](#page-38-5)) is as follows. Let Π be a randomized protocol and let accΠ(x, y) denote the probability that Π accepts an input (x, y). For example, if Π computes a two-party function F with error at most 1/4, then  $\operatorname{acc}_{\Pi}(x,y) \in [3/4,1]$  for every 1-input  $(x,y) \in F^{-1}(1)$  and  $\operatorname{acc}_{\Pi}(x,y) \in [0,1/4]$  for every 0-input  $(x,y) \in F^{-1}(0)$ . When  $F := f \circ g^n$  is a composed function, we can define  $\operatorname{acc}_{\Pi}(z)$  for  $z \in \operatorname{dom} f$  (domain of f) meaningfully as the probability that  $\Pi$  accepts a random two-party encoding of z. More specifically, letting  $\mathbf{E}$  denote expectation and  $\mathcal{U}_z$  the uniform distribution over  $(g^n)^{-1}(z)$  we define

$$\operatorname{acc}_{\Pi}(z) := \underset{(\boldsymbol{x}, \boldsymbol{y}) \sim \mathcal{U}_z}{\mathbf{E}} \operatorname{acc}_{\Pi}(\boldsymbol{x}, \boldsymbol{y}).$$

The centerpiece in the framework is the following type of structure theorem: assuming g is chosen carefully, for any cost-c protocol  $\Pi$  there is a degree-O(c) multivariate polynomial p(z) such that  $\text{acc}_{\Pi}(z) \approx p(z)$ . Here the approximation error is typically measured point-wise. Consequently, if f cannot be approximated point-wise with a low-degree polynomial, one obtains lower bounds against any bounded-error protocol computing  $f \circ g^n$ .

A technical convenience that will be useful for us is that since randomized protocols are essentially linear combinations of 0/1-labeled rectangles R, it suffices to study the acceptance probability of each individual rectangle R. More formally, it suffices to understand  $\operatorname{acc}_R(z)$ , defined as the probability that  $(x, y) \in R$  for a random encoding  $(x, y) \sim \mathcal{U}_z$  of z. Put succinctly,

<span id="page-3-0"></span>
$$\operatorname{acc}_R(z) := \mathcal{U}_z(R).$$

An important feature of the polynomial framework is that it often yields tight lower bounds for two-sided (i.e., closed under complement) randomized models. However, polynomials are not always the most precise modeling choice when it comes to understanding one-sided (i.e., not closed under complement) randomized models, such as randomized generalizations of NP and measures like nonnegative rank.

This work: Approximation by conical juntas. In this work, we show that randomized protocols for composed functions can be simulated by *conical juntas*, a nonnegative analog of polynomials. Let  $h: \{0,1\}^n \to \mathbb{R}_{\geq 0}$  be a function. We say that h is a d-junta if it only depends on at most d of its input bits—we stress that all juntas in this work are nonnegative by definition. More generally, we call h a *conical d*-junta if it lies in the nonnegative cone generated by d-juntas, i.e., if we can write  $h = \sum_i a_i h_i$  where  $a_i \geq 0$  are nonnegative coefficients and  $h_i$  are d-juntas. Equivalently, a conical d-junta can be viewed as a nonnegative combination of width-d conjunctions (i.e., functions of the form  $(\ell_1 \wedge \cdots \wedge \ell_w)$  where  $w \leq d$  and each  $\ell_i$  is an input variable or its negation). Note that a conical d-junta is, in particular, a polynomial of degree at most d.

For concreteness, we state and prove our results for logarithmic-size inner-product gadgets. That is, throughout this work, we restrict our attention to the following setting of parameters:

• The gadget is given by 
$$g(x,y) \coloneqq \langle x,y \rangle \mod 2$$
, where  $x,y \in \{0,1\}^b$ .

<span id="page-3-1"></span>• The block length b = b(n) satisfies  $b(n) \ge 100 \log n$ .

(However, our results hold more generally whenever g is a sufficiently strong two-source extractor; see Remark 1. Further, lower bounds for the inner-product gadget as above can be used to get lower bounds for other gadgets with worse parameters. See Section 1.4 for more discussion.)

We are now ready to state our key structural result. The result essentially characterizes the computational power of a single rectangle in the communication matrix of f ◦ g n . Note that the theorem makes no reference to f.

<span id="page-4-1"></span>Theorem 1 (Junta Theorem). Assume ([†](#page-3-0)). For any d ≥ 0 and any rectangle R in the domain of g n there exists a conical d-junta h such that, for all z ∈ {0, 1} n ,

$$acc_R(z) \in (1 \pm 2^{-\Theta(b)}) \cdot h(z) \pm 2^{-\Theta(db)}.$$
 (1)

Discussion. [Theorem 1](#page-4-1) is similar in spirit to the approach taken by Chan et al. [\[CLRS13\]](#page-34-5). They gave a black-box method for converting Sherali–Adams lower bounds into size lower bounds for extended formulations. A key step in their proof is to approximate a single nonnegative rank-1 matrix with a single junta. In our approach, we approximate a single rectangle with a whole nonnegative combination of juntas. This allows us to achieve better error bounds that yield tight characterizations for many communication models (as discussed in [Section 1.2](#page-4-0) below). In the language of communication complexity, the lower bounds of [\[CLRS13\]](#page-34-5) went up to about Ω(log<sup>2</sup> n). See [\[CLRS13,](#page-34-5) §3.1] for more discussion.

The additive error 2−Θ(db) in [Theorem 1](#page-4-1) is essentially optimal, and the same additive error appears in the polynomial approximation framework. The multiplicative error (1 ± 2 −Θ(b) ) is new: this is the cost we end up incurring for using juntas instead of polynomials. Such multiplicative error does not appear in the polynomial approximation framework. Whether one can achieve better multiplicative accuracy in [Theorem 1](#page-4-1) is left as an open problem (see [Section 1.4\)](#page-7-0).

Maybe the biggest drawback with [Theorem 1](#page-4-1) is that our proof assumes block length b = Ω(log n) (cf. the pattern matrix method works even when b = Θ(1)). Whether [Theorem 1](#page-4-1) (or some relaxed form of it) is true for b = Θ(1) is left as an open problem.

## <span id="page-4-0"></span>1.2 Communication versus query: Simulation Theorem

The most intuitive way to formalize our Simulation Theorem is in terms of different randomized models of computation rather than in terms of different lower bound measures. Indeed, we consider several models originally introduced in the context of Turing machine complexity theory: for any such model C one can often associate, in a canonical fashion, a communication model C cc and a decision tree model C dt. We follow the convention of using names of models as complexity measures so that C cc(F) denotes the communication complexity of F in model C cc, and C dt(f) denotes the query complexity of f in model C dt. In this work, we further identify C cc with the class of partial functions F with C cc(F) ≤ poly(log n). We stress that our complexity classes consist of partial functions (i.e., promise problems)—for total functions many surprising collapses are possible (e.g., NPcc ∩ coNPcc = P cc for total functions [\[KN97,](#page-36-0) §2.3]).

Our methods allow us to accurately analyze the models listed below (see also [Figure 1\)](#page-5-1). Our discussion in this introduction is somewhat informal; see [Section 3](#page-16-0) for precise definitions.

• NP: Nondeterminism. We view an NP computation as a randomized computation where 1-inputs are accepted with non-zero probability and 0-inputs are accepted with zero probability. The communication analog NPcc was formalized in the work of Babai et al. [\[BFS86\]](#page-34-0) that introduced communication complexity analogs of classical complexity classes.

<span id="page-5-1"></span>![](_page_5_Figure_0.jpeg)

Figure 1: Models and lower bound methods at a glance. Arrows denote class inclusions.

- WAPP: Weak Almost-Wide PP [BGM06]. A WAPP computation is a randomized computation such that 1-inputs are accepted with probability in  $[(1 \epsilon)\alpha, \alpha]$ , and 0-inputs are accepted with probability in  $[0, \epsilon \alpha]$  where  $\alpha = \alpha(n) > 0$  is arbitrary and  $\epsilon < 1/2$  is a constant. The communication analog WAPP<sup>cc</sup> is equivalent to the (one-sided) smooth rectangle bound of Jain and Klauck [JK10] and also to approximate nonnegative rank by a result of Kol et al. [KMSY14]. We also study a two-sided model WAPP  $\cap$  coWAPP whose communication analog corresponds to the two-sided smooth rectangle bound, which was called the relaxed partition bound by [KLL+15].
- SBP: Small Bounded-Error Probability [BGM06]. An SBP computation is a randomized computation such that 1-inputs are accepted with probability in  $[\alpha, 1]$  and 0-inputs are accepted with probability in  $[0, \alpha/2]$  where  $\alpha = \alpha(n) > 0$  is arbitrary. The communication analog SBP<sup>cc</sup> is equivalent to the (one-sided) corruption bound originally defined in [Yao83] (see [GW16]).
- PostBPP: Postselected BPP [Aar05]. (Equivalent to BPP<sub>path</sub> [HHT97].) A PostBPP computation is a randomized computation that may sometimes output  $\bot$  (representing "abort" or "don't know"), but conditioned on not outputting  $\bot$  the output is correct with probability at least 3/4. The communication analog PostBPP<sup>cc</sup> was first studied in [Kla03] (under the name "approximate majority covers") and subsequently in [GL14] (under the generic name "zero-communication protocols") where the term extended discrepancy was coined for the dual characterization of PostBPP<sup>cc</sup>.

We apply the Junta Theorem to show that when  $\mathcal{C}$  is one of the above models, any  $\mathcal{C}^{\mathsf{cc}}$  protocol for  $f \circ g^n$  can be converted into a corresponding  $\mathcal{C}^{\mathsf{dt}}$  decision tree for f. Roughly speaking, this is because such a protocol can be formulated as a distribution over (labeled) rectangles, and each rectangle can be converted (via the Junta Theorem) into a distribution over conjunctions. Hence lower bounds on  $\mathcal{C}^{\mathsf{cc}}(f \circ g^n)$  follow in a black-box way from lower bounds on  $\mathcal{C}^{\mathsf{dt}}(f)$ .

<span id="page-5-0"></span>**Theorem 2** (Simulation Theorem). Assume  $(\dagger)$ . For any partial  $f: \{0,1\}^n \to \{0,1,*\}$  we have

$$\begin{array}{lll} \mathcal{C}^{\mathsf{cc}}(f \circ g^n) &=& \Theta(\mathcal{C}^{\mathsf{dt}}(f) \cdot b) & & \textit{for } \mathcal{C} \in \{\mathsf{NP}, \mathsf{WAPP}, \mathsf{SBP}\}, \\ \mathcal{C}^{\mathsf{cc}}(f \circ g^n) &\geq& \Omega(\mathcal{C}^{\mathsf{dt}}(f) \cdot b) & & \textit{for } \mathcal{C} = \mathsf{PostBPP}. \end{array}$$

(Here we crucially ignore constant factors in the error parameter  $\epsilon$  for  $\mathcal{C} = \mathsf{WAPP}$ .)

Naturally, the upper bounds in Theorem 2 follow from the fact that a communication protocol for  $f \circ g^n$  can simulate the corresponding decision tree for f: when the decision tree queries the

*i*-th input of f, the protocol spends b+1 bits of communication to figure out  $z_i = g(x_i, y_i)$  in a brute-force manner. (There is one subtlety concerning the two-sided model PostBPP; see Remark 3.)

We also mention that the result for the simplest model C = NP does not require the full power of the Junta Theorem: it is possible to prove it using only a proper subset of the ideas that we present for the other randomized models (see [Göö15]).

### <span id="page-6-0"></span>1.3 Applications

Using the Simulation Theorem we can resolve several questions from prior work.

SBP and corruption. Our first application is the following.

<span id="page-6-1"></span>**Theorem 3.** SBP<sup>cc</sup> is not closed under intersection.

We prove this theorem by first giving an analogous lower bound for query complexity: there exists a partial f such that  $\mathsf{SBP^{dt}}(f) \leq O(1)$ , but  $\mathsf{SBP^{dt}}(f_{\wedge}) \geq n^{\Omega(1)}$ , where  $f_{\wedge} \colon \{0,1\}^{2n} \to \{0,1,*\}$  is defined by  $f_{\wedge}(z,z') \coloneqq f(z) \wedge f(z')$ . This query separation alone yields via standard diagonalization (e.g., [AW09, §5]) an oracle relative to which the classical complexity class  $\mathsf{SBP}$  is not closed under intersection, solving an open problem posed by [BGM06]. Applying the Simulation Theorem to  $f \circ g^n$  and  $f_{\wedge} \circ g^{2n} = (f \circ g^n)_{\wedge}$  we then obtain Theorem 3.

Theorem 3 has consequences for Arthur–Merlin communication ( $\mathsf{MA^{cc}}$ ,  $\mathsf{AM^{cc}}$ ) which has been studied in [Kla03, RS04, AW09, GS10, Kla11, GR15, GPW16b]. Namely, Klauck [Kla03] asked (using the language of uniform threshold covers) whether the known inclusion  $\mathsf{MA^{cc}} \subseteq \mathsf{SBP^{cc}}$  is strict. (This was also re-asked in [GW16].) Put diffferently, is corruption a complete lower bound method for  $\mathsf{MA^{cc}}$  up to polynomial factors? Since  $\mathsf{MA^{cc}}$  is closed under intersection, we conclude that the answer is "no".

#### Corollary 4. SBP<sup>cc</sup> ⊈ MA<sup>cc</sup>.

Proving explicit lower bounds for  $AM^{cc}$  remains one of the central challenges in communication complexity. Motivated by this [GPW16b] studied a certain unambiguous restriction of  $AM^{cc}$ , denoted  $UAM^{cc}$ , as a stepping stone towards  $AM^{cc}$ . They asked whether  $UAM^{cc} \subseteq SBP^{cc}$ . In other words, does corruption give lower bounds against  $UAM^{cc}$  in a black-box fashion? They showed that the answer is "no" for query complexity. Using the Simulation Theorem it is now straightforward to convert this result into an analogous communication separation.

## <span id="page-6-2"></span>Corollary 5. $UAM^{cc} \not\subseteq SBP^{cc}$ .

Intriguingly, we still lack UAM<sup>cc</sup> lower bounds for set-disjointness. Corollary 5 implies that such lower bounds cannot be blindly derived from Razborov's corruption lemma [Raz92].

WAPP and nonnegative rank. Kol et al. [KMSY14] asked whether the error in the definition of WAPP can be efficiently *amplified*, i.e., whether the parameter  $\epsilon$  can be *reduced* without blowing up the cost too much. It is known that such amplification is possible for the closely related two-sided model AWPP, *Almost-Wide* PP (related to smooth discrepancy and approximate rank), using "amplification polynomials"; see [Fen03, §3] (or [LS09a, §3.2] and [Alo03] for approximate rank). In [KMSY14] it was shown that no one-sided analog of amplification polynomials exists, ruling out one particular approach to amplification.

We show unconditionally that WAPPcc (and hence rank<sup>+</sup> , approximate nonnegative rank) does not admit efficient error amplification in the case of partial functions. For total functions, this at least shows that no "point-wise" method can be used to amplify , since such methods would also work for partial functions. We write WAPPcc for the measure corresponding to error .

<span id="page-7-2"></span>Theorem 6. For all constants 0 < < δ < 1/2 there exists a two-party partial function F such that WAPPcc δ (F) ≤ O(log n) but WAPPcc (F) ≥ Ω(n).

<span id="page-7-1"></span>Corollary 7. For all constants 0 < < δ < 1/2 there exists a partial boolean matrix F such that rank<sup>+</sup> δ (F) ≤ n <sup>O</sup>(1) but rank<sup>+</sup> (F) ≥ 2 Ω(n) .

In order to conclude [Corollary 7](#page-7-1) from [Theorem 6](#page-7-2) we actually need a stronger equivalence of WAPPcc and approximate nonnegative rank than the one proved by Kol et al. [\[KMSY14\]](#page-36-8): they showed the equivalence for total functions while we need the equivalence for partial functions. The extension to partial functions is nontrivial, and is related to the issue of "unrestricted" vs. "restricted" models of communication.

Unrestricted vs. restricted models. So far we have discussed "restricted" communication models. We can also define their "unrestricted" counterparts in analogy to the well-studied pair of classes PPcc (a.k.a. discrepancy [\[Kla07,](#page-36-12) §8]) and UPPcc (a.k.a. sign-rank [\[PS86\]](#page-37-9)). Recall that a PP computation is a randomized computation such that 1-inputs are accepted with probability in [1/2+α, 1], and 0-inputs are accepted with probability in [0, 1/2−α] where α = α(n) > 0 is arbitrary. In the unrestricted model UPPcc the parameter α > 0 can be arbitrarily small (consequently, the model is defined using private randomness), whereas in the restricted model PPcc the cost of a protocol with parameter α is defined as the usual communication cost plus log(1/α). It is known that PPcc ( UPPcc where the separation is exponential [\[BVdW07\]](#page-34-9).

One can analogously ask whether the unrestricted–restricted distinction is relevant for the models considered in this work. (The question was raised and left unresolved for SBP in [\[GW16\]](#page-35-1).) In fact, the separation of [\[BVdW07\]](#page-34-9) already witnesses PostBPPcc ( UPostBPPcc where the latter is the unrestricted version of the former. By contrast, we prove that the distinction is immaterial for WAPP and SBP, even for partial functions: the unrestricted models UWAPPcc and USBPcc (see [Section 3](#page-16-0) for definitions) are essentially no more powerful than their restricted counterparts. Consequently, the Simulation Theorem can be applied to analyze these unrestricted models, too—but the equivalences are also interesting in their own right.

<span id="page-7-4"></span>Theorem 8. SBPcc(F) ≤ O(USBPcc(F) + log n) for all F.

<span id="page-7-3"></span>Theorem 9. WAPPcc δ (F) ≤ O(UWAPPcc (F) + log(n/(δ − ))) for all F and all 0 < < δ < 1/2.

The seemingly more powerful models USBPcc and UWAPPcc admit characterizations in terms of the nonnegative rank of matrices: instead of rectangles, the protocols compute using nonnegative rank-1 matrices. In particular, UWAPPcc turns out to capture rank<sup>+</sup> ; it is [Theorem 9](#page-7-3) that will be used in the proof of [Corollary 7](#page-7-1) above.

## <span id="page-7-0"></span>1.4 Open problems and subsequent developments

Our main open question is whether [Theorem 1](#page-4-1) continues to hold for b = O(1). If true, such a result would be very useful as inner-product on b bits can be simulated by most other gadgets on blocks

of length roughly 2<sup>b</sup> (which would be O(1) again). This in turn would give new and more unified proofs of important communication complexity lower bounds such as Razborov's corruption lower bound for set-disjointness [\[Raz92\]](#page-37-0) and the lower bound for gap-Hamming [\[CR12,](#page-35-8) [She12a,](#page-38-1) [Vid13\]](#page-38-7). A first hurdle in understanding the case b = O(1) seems to be [Lemma 13—](#page-10-1)does some version of it hold for b = O(1)? In particular, using notions from [Section 2.2,](#page-9-2) we can ask the following concrete question as a starting point: For b a sufficiently big constant, g the inner-product gadget, and two independent 0.9-dense sources X,Y over ({0, 1} b ) n , does g n (X,Y ) have full support over {0, 1} n ? The following are some other relevant open problems.

- Can the multiplicative accuracy in [Theorem 1](#page-4-1) be improved? This issue seems to be what is preventing us from quantitatively improving on the lower bounds obtained by [\[CLRS13\]](#page-34-5) for the LP extension complexity of approximating Max-Cut.
- Raz and McKenzie [\[RM99\]](#page-37-10) (see also [\[GPW15\]](#page-35-9)) obtained a simulation theorem that converts deterministic communication protocols for f ◦ g n into deterministic decision trees for f, where g is a certain polynomial-size gadget. Can our methods be used to simplify their proof, or to extend their result to other g's?
- Our focus in this work has been on partial functions. It remains open whether SBPcc = MAcc for total functions, or whether efficient error amplification exists for WAPPcc for total functions.

Since this paper first appeared, our main results have found several further applications.

- In [\[G¨o¨o15\]](#page-35-3), [Theorem 2](#page-5-0) (specialized to NP) has been applied to obtain the first superlogarithmic communication lower bound for the Clique vs. Independent Set problem.
- In [\[GPW16a\]](#page-35-10), [Theorem 2](#page-5-0) (more precisely, the key technical component of the proof, [Theorem 16\)](#page-12-1) has been applied to obtain a result exploring the question of whether rank-1 matrices are inherently more powerful than rectangles in communication complexity. This is motivated by the open question of whether PPcc 6⊆ UPostBPPcc .
- In [\[GJPW15\]](#page-35-11), [Theorem 2](#page-5-0) has been applied to obtain an essentially tight randomized communication lower bound for the Clique vs. Independent Set problem, as well as to prove that there exist boolean matrices for which the randomized communication complexity can be superlogarithmic in the number of monochromatic rectangles needed to partition the matrix.
- In [\[GJ16\]](#page-35-12), [Theorem 2](#page-5-0) has been applied to obtain strong randomized communication lower bounds for the recursive NAND function and the recursive majority-of-3 function.
- In [\[Wat16\]](#page-38-8), [Theorem 16](#page-12-1) has been applied to obtain an exponential separation between nonnegative rank and binary rank for partial boolean matrices.
- In [\[ABBD](#page-33-2)+16], [Theorem 2](#page-5-0) has been applied to obtain a super-quadratic separation between randomized and quantum communication complexities of a total function.
- In [\[BR16\]](#page-34-10), [Theorem 2](#page-5-0) has been applied to obtain a polynomial lower bound on the (randomized) communication complexity of finding an approximate Nash equilibrium.

## <span id="page-8-0"></span>1.5 Notational conventions

We always write random variables in bold (e.g., x, y, z). Capital letters X, Y are reserved for subsets of inputs to G = g n (so all rectangles R are of the form X × Y ). We identify such sets with flat distributions: we denote by X the random variable that is uniformly distributed on X. Given a distribution D and an event E we denote by (D | E) the conditional distribution of D given E, specifically, (D | E)(·) := D(· ∩ E)/D(E). We also use the shorthand D(· | E) := (D | E)(·).

## <span id="page-9-0"></span>2 Proof of the Junta Theorem

In this section we prove [Theorem 1,](#page-4-1) restated here for convenience.

Theorem 1 (Junta Theorem). Assume ([†](#page-3-0)). For any d ≥ 0 and any rectangle R in the domain of g n there exists a conical d-junta h such that, for all z ∈ {0, 1} n ,

$$acc_R(z) \in (1 \pm 2^{-\Theta(b)}) \cdot h(z) \pm 2^{-\Theta(db)}.$$
 (1)

## <span id="page-9-1"></span>2.1 Proof overview

We write G := g n for short. Fix d ≥ 0 and a rectangle L ⊆ dom G. Our goal is to approximate accL(z) by some conical d-junta h(z). (We are going to use the symbol L for the "main" rectangle so as to keep the symbol R free for later use as a more generic rectangle.) The high-level idea in our proof is extremely direct: to find a suitable h we partition—or at least almost partition—the rectangle L into subrectangles R ⊆ L that behave like width-d conjunctions.

Definition 10 (Conjunction rectangles). A rectangle R is a (d, )-conjunction if there exists a width-d conjunction h<sup>R</sup> : {0, 1} <sup>n</sup> → {0, 1} (i.e., h<sup>R</sup> can be written as (`<sup>1</sup> ∧ · · · ∧ `w) where w ≤ d and each `<sup>i</sup> is an input variable or its negation) such that accR(z) ∈ (1 ± ) · aRhR(z) for some a<sup>R</sup> ≥ 0 and all z ∈ {0, 1} n .

The proof is split into three subsections.

- (§ [2.2\)](#page-9-2) Block-wise density: We start by discussing a key property that is a sufficient condition for a subrectangle R ⊆ L to be a conjunction rectangle.
- (§ [2.3\)](#page-11-0) Reduction to a packing problem: Instead of partitioning L into conjunctions, we show that it suffices to find a packing (disjoint collection) of conjunction subrectangles of L that cover most of L relative to a given distribution over inputs. This will formalize our main technical task: solving a type of packing-with-conjunctions problem.
- (§ [2.4\)](#page-12-0) Solving the packing problem: This is the technical heart of the proof: we describe an algorithm to find a good packing for L.

## <span id="page-9-2"></span>2.2 Block-wise density

In this subsection we introduce a central notion that will allow us to extract close to uniform output from sufficiently random inputs to G = g n : {0, 1} bn × {0, 1} bn → {0, 1} n . Recall that in the setting of two-source extractors (e.g., [\[Vad12\]](#page-38-9)), one considers a pair of independent random inputs x and y that have high min-entropy, defined by H∞(x) := min<sup>x</sup> log(1/ Pr[ x = x ]). In our setting we think of G = g <sup>n</sup> as a local two-source extractor: each of the n output bits depends only on few of the input bits. Hence we need a stronger property than high min-entropy on x and y to guarantee that z := G(x, y) will be close to uniform. This property we call block-wise density. Below, for I ⊆ [n], we write x<sup>I</sup> for the restriction of x to the blocks determined by I.

**Definition 11** (Block-wise density). A random variable  $\boldsymbol{x} \in \{0,1\}^{bn}$  is  $\delta$ -dense if for all  $I \subseteq [n]$  the blocks  $\boldsymbol{x}_I$  have min-entropy rate at least  $\delta$ , that is,  $\mathbf{H}_{\infty}(\boldsymbol{x}_I) \geq \delta b |I|$ .

**Definition 12** (Multiplicative uniformity). A distribution  $\mathcal{D}$  on  $\{0,1\}^m$  is  $\epsilon$ -uniform if  $\mathcal{D}(z) \in (1 \pm \epsilon) \cdot 2^{-m}$  for all outcomes z.

<span id="page-10-1"></span>**Lemma 13.** Assume (†). If x and y are independent and 0.6-dense, then G(x,y) is  $2^{-b/20}$ -uniform.

*Proof.* Let z := G(x, y). First observe that for any  $I \subseteq [n]$  the parity of the output bits  $z_I$  is simply  $\langle x_I, y_I \rangle$  mod 2. We use the fact that inner-product is a good two-source extractor to argue that this parity is close to an unbiased random bit. Indeed, by 0.6-density we have  $\mathbf{H}_{\infty}(x_I) + \mathbf{H}_{\infty}(y_I) \geq 1.2 \cdot b|I|$  and this implies by a basic theorem of Chor and Goldreich [CG88, Theorem 9] that for  $I \neq \emptyset$ ,

<span id="page-10-3"></span>
$$|\operatorname{\mathbf{Pr}}[\langle \boldsymbol{x}_I, \boldsymbol{y}_I \rangle \bmod 2 = 0] - 1/2| \le 2^{-0.1 \cdot b|I| + 1}.$$
 (2)

This bound is enough to yield  $\epsilon$ -uniformity for  $\epsilon := 2^{-b/20}$ , as we next verify using standard Fourier analysis (see, e.g., [O'D14]). Let  $\mathcal{D}$  be the distribution of z. We think of  $\mathcal{D}$  as a function  $\{0,1\}^n \to [0,1]$  and write it in the Fourier basis as

$$\mathcal{D}(z) = \sum_{I \subseteq [n]} \widehat{\mathcal{D}}(I) \chi_I(z)$$

where  $\chi_I(z) := (-1)^{\sum_{i \in I} z_i}$  and  $\widehat{\mathcal{D}}(I) := 2^{-n} \sum_z \mathcal{D}(z) \chi_I(z) = 2^{-n} \cdot \mathbf{E}_{z \sim \mathcal{D}}[\chi_I(z)]$ . Note that  $\widehat{\mathcal{D}}(\emptyset) = 2^{-n}$  because  $\mathcal{D}$  is a distribution. In this language, property (2) says that, for all  $I \neq \emptyset$ ,  $2^n \cdot |\widehat{\mathcal{D}}(I)| = |\mathbf{E}[(-1)^{\langle \mathbf{z}_I, \mathbf{y}_I \rangle}]| \leq 2^{-0.1 \cdot b|I| + 2}$ , which is at most  $\epsilon 2^{-2|I| \log n}$  by our definition of b and  $\epsilon$ . Hence,

$$2^n \sum_{I \neq \emptyset} |\widehat{\mathcal{D}}(I)| \leq \epsilon \sum_{I \neq \emptyset} 2^{-2|I| \log n} = \epsilon \sum_{k=1}^n \binom{n}{k} 2^{-2k \log n} \leq \epsilon \sum_{k=1}^n 2^{-k \log n} \leq \epsilon.$$

We use this to show that  $|\mathcal{D}(z) - 2^{-n}| \le \epsilon 2^{-n}$  for all  $z \in \{0,1\}^n$ , which proves the lemma. To this end, let  $\mathcal{U}$  denote the uniform distribution (note that  $\widehat{\mathcal{U}}(I) = 0$  for all  $I \ne \emptyset$ ) and let  $\mathbb{1}_z$  denote the indicator for z defined by  $\mathbb{1}_z(z) = 1$  and  $\mathbb{1}_z(z') = 0$  for  $z' \ne z$  (note that  $|\widehat{\mathbb{1}}_z(I)| = 2^{-n}$  for all I). We can now calculate

$$\begin{aligned} |\mathcal{D}(z) - 2^{-n}| &= |\langle \mathbb{1}_z, \mathcal{D} \rangle - \langle \mathbb{1}_z, \mathcal{U} \rangle| &= |\langle \mathbb{1}_z, \mathcal{D} - \mathcal{U} \rangle| &= 2^n \cdot |\langle \widehat{\mathbb{1}}_z, \widehat{\mathcal{D}} - \widehat{\mathcal{U}} \rangle| \\ &\leq 2^n \cdot \sum_{I \neq \emptyset} |\widehat{\mathbb{1}}_z(I)| \cdot |\widehat{\mathcal{D}}(I)| &= \sum_{I \neq \emptyset} |\widehat{\mathcal{D}}(I)| \leq \epsilon 2^{-n}. \quad \Box \end{aligned}$$

<span id="page-10-0"></span>Remark 1. The only properties of inner-product we needed in the above proof were that it is a strong two-source extractor and that it satisfies an XOR-lemma. However, all sufficiently strong two-source extractors have the latter property automatically [Sha03], so we could have fixed g to be any such extractor in Theorem 1. It is known [LSŠ08] that an XOR-lemma holds even under the weaker assumption of g having low discrepancy (not necessarily under the uniform distribution over dom g). Hence it is plausible that Theorem 1 could be extended to handle such g, as well.

<span id="page-10-2"></span><sup>&</sup>lt;sup>1</sup>This fact resembles the classic "Vazirani XOR-Lemma" [Vaz86], except that the latter only guarantees the distribution is close to uniform in statistical distance, and it assumes a single bound on the bias of all parities (whereas we assume a bound that depends on the size of the parity).

We have the following corollary; here we write  $\bar{I} := [n] \setminus I$  for short.

<span id="page-11-3"></span>Corollary 14. Assume (†). Let  $R = X \times Y$  and suppose there is an  $I \subseteq [n]$  such that  $X_I$  and  $Y_I$  are fixed while  $X_{\bar{I}}$  and  $Y_{\bar{I}}$  are 0.6-dense. Then R is an  $(|I|, O(2^{-b/20}))$ -conjunction.

Proof. Let z := G(X, Y) and note that  $z_I$  is fixed. Write  $\epsilon := 2^{-b/20}$  for short. Applying Lemma 13 to  $x = X_{\bar{I}}$  and  $y = Y_{\bar{I}}$  (x and y are 0.6-dense) shows that  $|G^{-1}(z) \cap R|/|R| \in (1 \pm \epsilon) \cdot 2^{-|\bar{I}|}$  whenever  $z_I = z_I$  (and 0 otherwise). If g were perfectly balanced, then we would have  $|G^{-1}(z)|/2^{2bn} = 2^{-n}$  for all  $z \in \{0,1\}^n$ ; instead, since g is only approximately balanced  $(|g^{-1}(1)|, |g^{-1}(0)| \in 2^{2b-1} \pm 2^{b-1})$ , it can be seen by direct calculation that  $|G^{-1}(z)|/2^{2bn} \in (1 \pm \epsilon) \cdot 2^{-n}$  for all  $z \in \{0,1\}^n$  (though this can also be seen by another application of Lemma 13—to uniform  $x, y \in \{0,1\}^{bn}$ , which are 1-dense). Therefore  $\operatorname{acc}_R(z) = |G^{-1}(z) \cap R|/|G^{-1}(z)| \in (1 \pm O(\epsilon)) \cdot 2^{|I|-2bn}|R|$  if  $z_I = z_I$  and  $\operatorname{acc}_R(z) = 0$  if  $z_I \neq z_I$ . This is of the form  $(1 \pm O(\epsilon)) \cdot a_R h_R(z)$  (where  $h_R(z) = 1$  iff  $z_I = z_I$ ), as required.

### <span id="page-11-0"></span>2.3 Reduction to a packing problem

The purpose of this subsection is to massage the statement of the Junta Theorem into an alternative form in order to uncover its main technical content. We will end up with a certain type of packing problem, formalized in Theorem 16 at the end of this subsection.

Fix some "multiplicative" error bound  $\epsilon := 2^{-\Theta(b)}$  for the purposes of the following discussion. Whenever  $\mathscr{C}$  is a packing (disjoint collection) of  $(d, \epsilon)$ -conjunction subrectangles of L we let

$$h_{\mathscr{C}} \coloneqq \sum_{R \in \mathscr{C}} a_R h_R.$$

Write  $\cup \mathscr{C} := \bigcup_{R \in \mathscr{C}} R$  for short. Then  $\operatorname{acc}_{\cup \mathscr{C}} := \sum_{R \in \mathscr{C}} \operatorname{acc}_R$  is multiplicatively approximated by the conical d-junta  $h_{\mathscr{C}}$  in the sense that  $\operatorname{acc}_{\cup \mathscr{C}}(z) \in (1 \pm \epsilon) \cdot h_{\mathscr{C}}(z)$ . Hence if we could find a  $\mathscr{C}$  that partitioned  $L = \cup \mathscr{C}$ , we would have proved the theorem—without incurring any additive error.

Unfortunately, there are a few obstacles standing in the way of finding a perfect partition  $\mathscr{C}$ . One unavoidable issue is that we cannot multiplicatively approximate a tiny rectangle L with a low-degree conical junta. This is why we allow a small additive error and only multiplicatively approximate the acceptance probabilities of those z that have large enough  $\operatorname{acc}_L(z)$ . Indeed, we set

$$Z := \{ z \in \{0, 1\}^n : \mathrm{acc}_L(z) \ge 2^{-db/20} \},$$

and look for a  $\mathscr C$  that covers most of each of the sets  $G^{-1}(z) \cap L$  for  $z \in Z$ . More precisely, suppose for a moment that we had a packing  $\mathscr C$  such that for each  $z \in Z$ ,

<span id="page-11-1"></span>
$$\mathcal{U}_z(\cup \mathscr{C} \mid L) \geq 1 - \epsilon, \tag{3}$$

where  $\mathcal{U}_z(\cup \mathscr{C} \mid L) = \mathrm{acc}_{\cup \mathscr{C}}(z)/\mathrm{acc}_L(z)$  by definition. Indeed, assuming (3) we claim that

<span id="page-11-2"></span>
$$(1 - \epsilon) \cdot h_{\mathscr{C}}(z) \leq \operatorname{acc}_{L}(z) \leq (1 + O(\epsilon)) \cdot h_{\mathscr{C}}(z) + 2^{-\Theta(db)}. \tag{4}$$

In particular,  $h_{\mathscr{C}}$  achieves the desired approximation (1). For the first inequality, since  $\cup \mathscr{C} \subseteq L$  we never multiplicatively overestimate  $\operatorname{acc}_L$ , that is, we have  $\operatorname{acc}_L \ge \operatorname{acc}_{\cup \mathscr{C}} \ge (1 - \epsilon) \cdot h_{\mathscr{C}}$ . For the second inequality, for  $z \in Z$  we have  $\operatorname{acc}_L(z) \le (1 - \epsilon)^{-1} \cdot \operatorname{acc}_{\cup \mathscr{C}}(z) \le (1 - \epsilon)^{-1} \cdot (1 + \epsilon) \cdot h_{\mathscr{C}}(z) \le (1 + O(\epsilon)) \cdot h_{\mathscr{C}}(z)$ , and for  $z \notin Z$  we have simply  $\operatorname{acc}_L(z) < 2^{-\Theta(db)}$  by the definition of Z.

Unfortunately, we do not know how to construct a packing  $\mathscr{C}$  satisfying (3) either. Instead, we show how to find a randomized packing  $\mathscr{C}$  that guarantees (3) in expectation. More precisely, our construction goes through the following primal/dual pair of statements that are equivalent by the minimax theorem.

**Primal:**  $\exists$  distribution  $\mathcal{C}$  over  $\mathscr{C}$ 's  $\forall z \in Z$   $\mathbf{E}_{\mathscr{C} \sim \mathcal{C}} \mathcal{U}_z(\cup \mathscr{C} \mid L) \geq 1 - \epsilon$ 

**Dual:**  $\forall$  distribution  $\mu$  over Z  $\exists \mathscr{C}$   $\mathbf{E}_{z \sim \mu} \mathcal{U}_z(\cup \mathscr{C} \mid L) \geq 1 - \epsilon$ 

Suppose the primal statement holds for some  $\mathcal{C}$ . Then we claim that the convex combination  $h := \mathbf{E}_{\mathscr{C} \sim \mathcal{C}} h_{\mathscr{C}}$  achieves the desired approximation. The right side of (4) can be reformulated as

<span id="page-12-2"></span>
$$h_{\mathscr{C}}(z) \ge (1 - O(\epsilon + \epsilon_z)) \cdot (\operatorname{acc}_L(z) - 2^{-\Theta(db)})$$
 (5)

where  $\epsilon_z := 1 - \mathcal{U}_z(\cup \mathscr{C} \mid L)$  is a random variable depending on  $\mathscr{C}$  (so  $\mathbf{E}_{\mathscr{C} \sim \mathcal{C}}[\epsilon_z] \leq \epsilon$ ). Applying linearity of expectation to (5) shows (along with the left side of (4)) that h satisfies (1).

Therefore, to prove Theorem 1 it remains to prove the dual statement. This will preoccupy us for the whole of Section 2.4 where, for convenience, we will prove a slightly more general claim formalized below.

**Definition 15** (Lifted distributions). A distribution  $\mathcal{D}$  on the domain of G is said to be a *lift* of a distribution  $\mu$  on the codomain of G if  $\mathcal{D}(x,y) = \mu(z)/|G^{-1}(z)|$  where z := G(x,y). Note that a lifted distribution is a convex combination of distributions of the form  $\mathcal{U}_z$ .

<span id="page-12-1"></span>**Theorem 16** (Packing with conjunctions). Assume (†). Let  $d \ge 0$  and let L be a rectangle. There is an  $\epsilon := 2^{-\Theta(b)}$  such that for any lifted distribution  $\mathcal{D}$  with  $\mathcal{D}(L) \ge 2^{-db/20}$  there exists a packing  $\mathscr{C}$  consisting of  $(d, \epsilon)$ -conjunction subrectangles of L such that  $\mathcal{D}(\cup \mathscr{C} \mid L) > 1 - \epsilon$ .

The dual statement can be derived from Theorem 16 as follows. We need to check that for any distribution  $\mu$  on Z there is some lifted distribution  $\mathcal{D}$  such that  $\mathcal{D}(L) \geq 2^{-db/20}$  and  $\mathcal{D}(\cdot \mid L) = \mathcal{E}(\cdot)$  where  $\mathcal{E}(\cdot) \coloneqq \mathbf{E}_{\mathbf{z} \sim \mu} \mathcal{U}_{\mathbf{z}}(\cdot \mid L)$  is the probability measure relevant to the dual statement. For intuition, a seemingly natural candidate would be to choose  $\mathcal{D} = \mathbf{E}_{\mathbf{z} \sim \mu} \mathcal{U}_{\mathbf{z}}$ ; however, this does not ensure  $\mathcal{D}(\cdot \mid L) = \mathcal{E}(\cdot)$  as conditioning on L may not commute with taking convex combinations of  $\mathcal{U}_z$ 's. This is why we instead define a slightly different distribution  $\mu'(z) \coloneqq \gamma \mu(z)/\mathcal{U}_z(L)$  where  $\gamma \coloneqq (\mathbf{E}_{\mathbf{z} \sim \mu} 1/\mathcal{U}_{\mathbf{z}}(L))^{-1}$  is a normalizing constant. If we now choose  $\mathcal{D} \coloneqq \mathbf{E}_{\mathbf{z} \sim \mu'} \mathcal{U}_{\mathbf{z}}$  the conditioning on L works out. Indeed, noting that  $\gamma = \mathcal{D}(L)$  we have  $\mathcal{D}(\cdot \mid L) = \mathcal{D}(L)^{-1}\mathcal{D}(\cdot \cap L) = \gamma^{-1} \sum_{z} \mu'(z) \mathcal{U}_{z}(\cdot \cap L) = \sum_{z} \mu(z) \mathcal{U}_{z}(\cdot \cap L)/\mathcal{U}_{z}(L) = \mathbf{E}_{\mathbf{z} \sim \mu} \mathcal{U}_{\mathbf{z}}(\cdot \mid L) = \mathcal{E}(\cdot)$ , as desired. Also note that  $\mathcal{D}(L) = \mathbf{E}_{\mathbf{z} \sim \mu'} \mathcal{U}_{\mathbf{z}}(L) \geq \mathbf{E}_{\mathbf{z} \sim \mu'} 2^{-db/20} = 2^{-db/20}$  since  $\mu'$  is supported on Z.

### <span id="page-12-0"></span>2.4 Solving the packing problem

In this section we prove Theorem 16. Fix an error parameter  $\epsilon := 2^{-b/100}$ .

**Notation.** In the course of the argument, for any rectangle  $R = X \times Y$ , we are going to associate a bipartition of [n] into free blocks, denoted free R, and fixed blocks, denoted fix  $R := [n] \setminus \text{free } R$ . We will always ensure that X and Y are fixed on the blocks in fix R. However, if X and Y are fixed on some block i, we may or may not put i into fix R; thus the sets fix R and free R are not predefined functions of R, but rather will be chosen during the proof of Theorem 16. We say that the free marginals of R are  $(\delta, \mathcal{D})$ -dense if for  $xy \sim (\mathcal{D} \mid R)$  we have that  $x_{\text{free } R}$  and  $y_{\text{free } R}$  are  $\delta$ -dense. Note that if  $\mathcal{D} = \mathcal{U}$  is the uniform distribution, then the definition states that  $X_{\text{free } R}$  and  $Y_{\text{free } R}$  are  $\delta$ -dense. The following is a rephrasing of Corollary 14.

<span id="page-13-3"></span>**Proposition 17.** If the free marginals of R are  $(0.6, \mathcal{U})$ -dense then R is a  $(|\operatorname{fix} R|, \epsilon)$ -conjunction.  $\square$ 

We also use the following notation: if C is a condition (e.g., of the form  $(x_I = \alpha)$  or  $(x_I \neq \alpha)$ ) we write  $X_C$  for the set of  $x \in X$  that satisfy C. For example,  $X_{(x_I = \alpha)} := \{x \in X : x_I = \alpha\}$ .

**Roadmap.** The proof is in two steps. In the first step we find a packing with subrectangles whose free marginals are  $(0.8, \mathcal{D})$ -dense. In the second step we "prune" these subrectangles so that their free marginals become  $(0.6, \mathcal{U})$ -dense. These two steps are encapsulated in the following two lemmas.

<span id="page-13-1"></span>**Lemma 18** (Core packing step). There is a packing  $\mathscr{C}'$  of subrectangles of L such that  $\mathcal{D}(\cup\mathscr{C}' \mid L) \geq 1 - \epsilon$  and for each  $R \in \mathscr{C}'$  we have  $|\operatorname{fix} R| \leq d$  and the free marginals of R are  $(0.8, \mathcal{D})$ -dense (for some choice of the sets  $\operatorname{fix} R$  and  $\operatorname{free} R$ ).

<span id="page-13-2"></span>**Lemma 19** (Pruning step). For each  $R \in \mathcal{C}'$  there is a subrectangle  $R' \subseteq R$  with fix R' = fix R such that  $\mathcal{D}(R' \mid R) \geq 1 - \epsilon$  and the free marginals of R' are  $(0.6, \mathcal{U})$ -dense.

Theorem 16 follows immediately by stringing together Lemma 18, Lemma 19, and Proposition 17. In particular, the final packing  $\mathscr{C}$  will consist of the pruned rectangles R' (which are  $(d, \epsilon)$ -conjunctions by Proposition 17) and we have  $\mathcal{D}(\cup\mathscr{C} \mid L) \geq (1-\epsilon)^2 \geq 1-2\epsilon$ . (We proved the theorem with error parameter  $2\epsilon$  instead of  $\epsilon$ .)

#### <span id="page-13-0"></span>2.4.1 Core packing step

We will now prove Lemma 18. The desired packing  $\mathscr{C}'$  of subrectangles of L will be found via a packing algorithm given in Figure 2.

**Informal overview.** The principal goal in the algorithm is to find subrectangles  $R \subseteq L$  whose free marginals are  $(0.8, \mathcal{D})$ -dense while keeping |fix R| small. To do this, we proceed in rounds. The main loop of the algorithm maintains a  $pool\ \mathscr{P}$  of disjoint subrectangles of L and in each round we inspect each  $R \in \mathscr{P}$  in the subroutine Partition. If we find that R does not have dense free marginals, we partition R further. The output of Partition(R) is a partition of R into subrectangles each labeled as either dense, live, or error. We are simply going to ignore the error rectangles, i.e., they do not re-enter the pool  $\mathscr{P}$ . For the live subrectangles  $R' \subseteq R$  we will have made progress: the subroutine will ensure that the free marginals of R' will become more dense as compared to the free marginals of R.

The subroutine Partition works as follows. If the input rectangle  $R_{\rm in}$  satisfies the density condition on its free marginals, we simply output  $R_{\rm in}$  labeled as dense. Otherwise we find some subset I of free blocks that violates the density condition on one of the marginals. Then we consider the subrectangle  $R_{\rm out} \subseteq R_{\rm in}$  that is obtained from  $R_{\rm in}$  by fixing the non-dense marginal to its overly-likely value on I and the other marginal to each of its typical values on I. Intuitively, these fixings have the effect of increasing the "relative density" in the remaining free blocks, and so we have found a single subrectangle where we have made progress. We then continue iteratively on the rest of  $R_{\rm in}$  until only a  $\delta := \epsilon/2n$  fraction of  $R_{\rm in}$  remains, which we deem as error.

Note that, at the end of n+1 rounds, each  $R \in \mathcal{C}'$  must be labeled *dense* because once a rectangle R reaches fix R = [n], the density condition on the free marginals is satisfied vacuously. It remains to argue that the other two properties in Lemma 18 hold for  $\mathcal{C}'$ .

```
Packing Algorithm for L:

1: Initialize \mathscr{P} \coloneqq \{L\} where fix L \coloneqq \emptyset and L is labeled live

2: Repeat for n+1 rounds

3: Replace each R \in \mathscr{P} by all the non-error subrectangles output by Partition(R)

4: Output \mathscr{C}' \coloneqq \mathscr{P}
```

```
Subroutine Partition (with error parameter \delta := \epsilon/2n)
Input: A rectangle R_{in}
Output: A partition of R_{in} into dense/live/error subrectangles
 5: Initialize R := R_{\mathsf{in}} with fix R := \mathsf{fix} R_{\mathsf{in}}
 6: While the following two conditions hold
          (C1): \mathcal{D}(R \mid R_{\mathsf{in}}) > \delta
                    The free marginals of R are not both (0.8, \mathcal{D})-dense
 7:
          Let xy \sim (\mathcal{D} \mid R) and let X and Y be such that R = X \times Y
          We may assume that x_{\text{free }R} is not 0.8-dense (otherwise consider y_{\text{free }R})
 8:
          Let I \subseteq \text{free } R and \alpha be such that \Pr[x_I = \alpha] > 2^{-0.8 \cdot b|I|}
 9:
          Let \mathcal{B} := \{ \beta : \Pr[y_I = \beta \mid x_I = \alpha] > \delta \cdot 2^{-b|I|} \}
10:
          For each \beta \in \mathcal{B}
11:
               Let R_{\mathsf{out}} := X_{(x_I = \alpha)} \times Y_{(y_I = \beta)} with fix R_{\mathsf{out}} := \mathrm{fix} \, R \cup I
12:
               Output R_{\text{out}} labeled as live
13:
          End for
14:
          Output X_{(x_I=\alpha)} \times Y_{(y_I \notin \mathcal{B})} labeled as error
15:
          Update R := X_{(x_I \neq \alpha)} \times Y (with the same fix R)
16:
17: End while
18: Output R labeled as dense if (C2) failed, or as error if (C1) failed
```

Figure 2: Packing algorithm.

**Error analysis.** We claim that in each run of Partition at most a fraction  $2\delta$  of the distribution  $(\mathcal{D} \mid R_{\mathsf{in}})$  gets classified as *error*. This claim implies that  $\cup \mathscr{C}'$  covers all but an  $\epsilon$  fraction of  $(\mathcal{D} \mid L)$  since the total error relative to  $(\mathcal{D} \mid L)$  can be easily bounded by the number of rounds (excluding the last round, which only labels the remaining *live* rectangles as *dense*) times the error in Partition, which is  $n \cdot 2\delta = \epsilon$  under our claim.

To prove our claim, we first note that the error rectangle output on line 18 contributes a fraction  $\leq \delta$  of error relative to  $(\mathcal{D} \mid R_{\mathsf{in}})$  by (C1). Consider then error rectangles output on line 15. Here we have (using notation from the algorithm)  $\Pr[y_I \notin \mathcal{B} \mid x_I = \alpha] \leq \delta$  by the definition of  $\mathcal{B}$  so we only incur  $\leq \delta$  fraction of error relative to  $(\mathcal{D} \mid R')$  where  $R' := X_{(x_I = \alpha)} \times Y$ . In the subsequent line we redefine  $R := R \setminus R'$ , which ensures that the errors on line 15 do not add up over the different iterations. Hence, altogether, line 15 contributes a fraction  $\leq \delta$  of error relative to  $(\mathcal{D} \mid R_{\mathsf{in}})$ . The

total error in Partition is then at most  $\delta + \delta = 2\delta$ , which was our claim.

**Number of fixed blocks.** Let  $R \in \mathcal{C}'$ . We need to show that  $|\operatorname{fix} R| \leq d$ . Let  $R_i$ ,  $i \in [n+1]$ , be the unique rectangle in the pool at the start of the *i*-th round such that  $R \subseteq R_i$ . Let  $\ell$  be the largest number such that  $R_{\ell}$  is labeled *live*. Hence  $|\operatorname{fix} R| = |\operatorname{fix} R_{\ell}|$ . Let  $Q \supseteq R_{\ell}$  consist of all the inputs that agree with  $R_{\ell}$  on the fixed coordinates fix R. We claim that

<span id="page-15-2"></span><span id="page-15-1"></span>
$$\mathcal{D}(Q) \leq 2^{-(2b-2)|\text{fix } R|},\tag{6}$$

$$\mathcal{D}(R_{\ell}) \geq 2^{-1.9 \cdot b |\operatorname{fix} R| - db/20}. \tag{7}$$

Let us first see how to conclude the proof of Lemma 18 assuming the above inequalities. Since  $\mathcal{D}(Q) \geq \mathcal{D}(R_{\ell})$  we can require that  $(6) \geq (7)$  and (taking logarithms) obtain the inequality  $-(2b-2)|\operatorname{fix} R| \geq -1.9 \cdot b|\operatorname{fix} R| - db/20$ . But this implies  $|\operatorname{fix} R| \leq d$ , as desired.

To prove (6), write  $\mathcal{D}(Q) = \mathbf{E}_{z \sim \mu} \mathcal{U}_z(Q)$  for some  $\mu$  since  $\mathcal{D}$  is a lifted distribution. Here for each fixed z we either have  $\mathcal{U}_z(Q) = 0$  in case the fixings of Q are inconsistent with z, or otherwise  $\mathcal{U}_z(Q) = \prod_{j \in \text{fix } R} 1/|g^{-1}(z_j)| \leq 2^{-(2b-2)|\text{fix } R|}$  (where we used the fact that the gadget g is approximately balanced:  $|g^{-1}(1)|, |g^{-1}(0)| \geq 2^{2b}/4$ ). Hence  $\mathcal{D}(Q)$  is a convex combination of values that satisfy (6).

To prove (7), note that  $\mathcal{D}(R_{\ell}) = \mathcal{D}(R_{\ell} \mid L) \cdot \mathcal{D}(L) \geq \mathcal{D}(R_{\ell} \mid L) \cdot 2^{-db/20}$ . Hence it suffices to show that  $\mathcal{D}(R_{\ell} \mid L) \geq 2^{-1.9 \cdot b |\text{fix } R|}$ . To this end, write  $|\text{fix } R| = \sum_{i=1}^{\ell-1} |I_i|$  where  $I_i$  is the set of blocks that were fixed to obtain  $R_{i+1} = R_{\text{out}}$  from  $R_i = R_{\text{in}}$  and use the following claim inductively.

Claim 20. Each  $R_{\text{out}}$  output labeled as live (on line 13) satisfies  $\mathcal{D}(R_{\text{out}} \mid R_{\text{in}}) \geq 2^{-1.9 \cdot b|I|}$ .

*Proof.* Using notation from the algorithm,

$$\mathcal{D}(R_{\mathsf{out}} \mid R_{\mathsf{in}}) = \mathcal{D}(R_{\mathsf{out}} \mid R) \cdot \mathcal{D}(R \mid R_{\mathsf{in}})$$

$$\geq \mathcal{D}(R_{\mathsf{out}} \mid R) \cdot \delta \qquad \qquad (\mathsf{by} \ (\mathbf{C1}))$$

$$= \mathbf{Pr}[\mathbf{x}_I = \alpha \text{ and } \mathbf{y}_I = \beta] \cdot \delta$$

$$\geq 2^{-0.8 \cdot b \mid I \mid} \cdot \delta \cdot 2^{-b \mid I \mid} \cdot \delta$$

$$= 2^{-1.8 \cdot b \mid I \mid -b/50 - 2 \log n - 2} \qquad (\mathsf{definition} \ \mathsf{of} \ \epsilon, \delta)$$

$$\geq 2^{-1.9 \cdot b \mid I \mid}.$$

#### <span id="page-15-0"></span>2.4.2 Pruning step

We will now prove Lemma 19. Let  $R = X \times Y \in \mathscr{C}'$  and  $xy \sim (\mathcal{D} \mid R)$ . For notational convenience, we assume that fix  $R = \emptyset$ , i.e., we forget about the fixed blocks and think of x and y as 0.8-dense. As will be clear from the proof, if fix R was non-empty, it would only help us in the ensuing calculations.

We want to find a "pruned" subrectangle  $R' := X' \times Y' \subseteq R$  such that

- (i)  $\Pr[xy \in X' \times Y'] \ge 1 \epsilon$ ,
- (ii) X' and Y' are 0.6-dense.

In fact, it is enough to show how to find an  $X' \subseteq X$  such that

(i') 
$$\Pr[x \in X'] \ge 1 - \epsilon/2$$
,

(ii') X' is 0.6-dense.

Indeed, we can run the argument for (i',ii') twice, once for X and once for Y in place of X. The property (i) then follows by a union bound.

We will obtain X' by forbidding some outcomes of  $X_I$  that are too likely. We build up a set C of conditions via the following algorithm. We use the notation  $X_C = \bigcap_{C \in C} X_C$  below.

```
    Initialize C := ∅
    Repeat
    If X<sub>C</sub> = ∅, then halt with a failure
    If X<sub>C</sub> is 0.6-dense, then halt with a success
    Otherwise let I and α be such that Pr[(X<sub>C</sub>)<sub>I</sub> = α] > 2<sup>-0.6·b|I|</sup>
    Add the condition (x<sub>I</sub> ≠ α) to C
    End repeat
```

This process eventually halts since  $|X_{\mathcal{C}}|$  decreases every time we add a new condition to  $\mathcal{C}$ . Let  $\mathcal{F}$  denote the set of final conditions when the process halts. We show that  $X' := X_{\mathcal{F}}$  satisfies (i',ii'). Write  $\mathcal{F} = \bigcup_{s \in [n]} \mathcal{F}_s$  where  $\mathcal{F}_s$  denotes conditions of the form  $(x_I \neq \alpha)$ , |I| = s, in  $\mathcal{F}$ .

<span id="page-16-1"></span>Claim 21. 
$$|\mathcal{F}_s| \leq 2^{0.7 \cdot bs}$$
.

Proof of claim. The effect of adding a new condition  $(x_I \neq \alpha)$ , |I| = s, to  $\mathcal{C}$  is to shrink the size of  $X_{\mathcal{C}}$  by a factor of  $\mathbf{Pr}[(X_{\mathcal{C}})_I \neq \alpha] < 1 - \delta$  where  $\delta := 2^{-0.6 \cdot bs}$ . Our initial set has size  $|X| \leq 2^{bn}$  and hence we cannot shrink it by such a condition more than  $k \geq |\mathcal{F}_s|$  times where k is the smallest number satisfying  $|X|(1-\delta)^k < 1$ . Solving for k gives  $k \leq O(bn/\delta) = O(bn \cdot 2^{0.6 \cdot bs})$ , which is at most  $2^{0.7 \cdot bs}$  given our definition of b.

We can now verify (i') by a direct calculation:

$$\mathbf{Pr}[\mathbf{x} \notin X'] = \mathbf{Pr}[\mathbf{x} \notin X_{\mathcal{F}}] \\
\leq \sum_{s} \mathbf{Pr}[\mathbf{x} \notin X_{\mathcal{F}_{s}}] \\
\leq \sum_{s} \sum_{(x_{I} \neq \alpha) \in \mathcal{F}_{s}} \mathbf{Pr}[\mathbf{x}_{I} = \alpha] \\
\leq \sum_{s} |\mathcal{F}_{s}| \cdot 2^{-0.8 \cdot bs} \qquad (\mathbf{H}_{\infty}(\mathbf{x}_{I}) \geq 0.8 \cdot b|I|) \\
\leq \sum_{s} 2^{-0.1 \cdot bs} \qquad (Claim 21) \\
\leq \epsilon/2.$$

This also proves (ii') because the calculation implies that  $X' \neq \emptyset$  which means that our process halted with a *success*. This concludes the proof of Lemma 19.

## <span id="page-16-0"></span>3 Definitions of models

In Section 3.1 we introduce our restricted-by-default communication models, justify why they can be viewed as "zero-communication" models, and explain their relationships to known lower bound techniques. In Section 3.2 we define their corresponding unrestricted versions. In Section 3.3 we describe the query complexity counterparts of our communication models.

## <span id="page-17-0"></span>3.1 Restricted communication models

We define NP protocols in a slightly nonstandard way as randomized protocols, just for stylistic consistency with the other models. The acronyms WAPP and SBP were introduced in [BGM06] (their communication versions turn out to be equivalent to the smooth rectangle bound and the corruption bound, as argued below). We introduce the acronym 2WAPP (for lack of existing notation) to correspond to a two-sided version of WAPP (which is equivalent to the zero-communication with abort model of [KLL+15]). We use the notation PostBPP [Aar05] instead of the more traditional BPP<sub>path</sub> [HHT97] as it is more natural for communication protocols.

A protocol outputs 0 or 1, and in some of these models it may also output  $\bot$  representing "abort" or "don't know". In the following definition,  $\alpha$  can be arbitrarily small and should be thought of as a function of the input size n for a family of protocols.

<span id="page-17-2"></span>**Definition 22.** For  $C \in \{\text{NP}, 2\text{WAPP}_{\epsilon}, \text{WAPP}_{\epsilon}, \text{SBP}, \text{PostBPP}\}\$ and  $F \colon \{0,1\}^n \times \{0,1\}^n \to \{0,1,*\}$  a partial function, define  $C^{cc}(F)$  as the minimum over all  $\alpha > 0$  and all " $\alpha$ -correct" public-randomness protocols for F of the communication cost plus  $\log(1/\alpha)$  (this sum is considered to be the cost), where  $\alpha$ -correctness is defined as follows.

$$\mathsf{NP} : \mathsf{If} \ F(x,y) = 1 \ \mathsf{then} \ \mathbf{Pr}[\Pi(x,y) = 1] \ge \alpha, \ \mathsf{and} \ \mathsf{if} \ F(x,y) = 0 \ \mathsf{then} \ \mathbf{Pr}[\Pi(x,y) = 1] = 0.$$

2WAPP<sub>\epsilon</sub>: The protocol may output  $\perp$ , and for all  $(x,y) \in \text{dom } F$ ,  $\Pr[\Pi(x,y) = F(x,y)] \ge (1-\epsilon)\alpha$  and  $\Pr[\Pi(x,y) \ne \perp] \le \alpha$ .

$$\mathsf{WAPP}_{\epsilon}: \text{ If } F(x,y) = 1 \text{ then } \mathbf{Pr}[\Pi(x,y) = 1] \in [(1-\epsilon)\alpha,\alpha], \text{ and if } F(x,y) = 0 \text{ then } \mathbf{Pr}[\Pi(x,y) = 1] \in [0,\epsilon\alpha].^2$$

$$\mathsf{SBP}: \text{ If } F(x,y) = 1 \text{ then } \mathbf{Pr}[\Pi(x,y) = 1] \geq \alpha, \text{ and if } F(x,y) = 0 \text{ then } \mathbf{Pr}[\Pi(x,y) = 1] \leq \alpha/2.$$

PostBPP: The protocol may output 
$$\bot$$
, and for all  $(x,y) \in \text{dom } F$ ,  $\Pr[\Pi(x,y) \neq \bot] \ge \alpha$  and  $\Pr[\Pi(x,y) = F(x,y) \mid \Pi(x,y) \neq \bot] \ge 3/4$ .

The "syntactic relationships" among the four models 2WAPP, WAPP, SBP, PostBPP is summarized in the below table. The meaning of the column and row labels is as follows. For the columns, "two-sided" means that the protocol outputs values in  $\{0,1,\bot\}$  and conditioned on not outputting  $\bot$ , the output is correct with high probability. A "one-sided" protocol outputs values in  $\{0,1\}$ , and we measure its probability of outputting 1 and compare it against the correctness parameter  $\alpha > 0$ . For the rows, "bounded" means that the *non-abort* probability—that is, the probability of not outputting  $\bot$  for two-sided models, or the probability of outputting 1 for one-sided models—is uniformly upper bounded by  $\alpha$ , whereas "unbounded" means that the non-abort probability need not be upper bounded by  $\alpha$ .

|                     | Two-sided | One-sided |
|---------------------|-----------|-----------|
| Bounded non-abort   | 2WAPP     | WAPP      |
| Unbounded non-abort | PostBPP   | SBP       |

It is straightforward to see that the relative computational power ("semantic relationships") of the models is as follows (recall Figure 1): for all F and all constants  $0 < \epsilon < 1/2$ , we have

<span id="page-17-1"></span><sup>&</sup>lt;sup>2</sup>The definition of WAPP in [BGM06] uses  $\epsilon$  in a different way:  $\frac{1}{2} + \epsilon$  and  $\frac{1}{2} - \epsilon$  instead of  $1 - \epsilon$  and  $\epsilon$ .

 $2\mathsf{WAPP}^{\mathsf{cc}}_{\epsilon}(F) \geq \mathsf{WAPP}^{\mathsf{cc}}_{\epsilon}(F) \geq \Omega(\mathsf{SBP^{\mathsf{cc}}}(F)) \geq \Omega(\mathsf{PostBPP^{\mathsf{cc}}}(F)) \text{ and } \mathsf{NP^{\mathsf{cc}}}(F) \geq \mathsf{SBP^{\mathsf{cc}}}(F).$  Furthermore, exponential separations are known for all these relationships: unique-set-intersection is easy for  $\mathsf{WAPP^{\mathsf{cc}}_{0}}$  but hard for  $2\mathsf{WAPP^{\mathsf{cc}}_{\epsilon}}$  (indeed, for  $\mathsf{coSBP^{\mathsf{cc}}}$  [Raz92, GW16]); set-intersection is easy for  $\mathsf{SBP^{\mathsf{cc}}}$  (indeed, for  $\mathsf{NP^{\mathsf{cc}}}$ ) but hard for  $\mathsf{WAPP^{\mathsf{cc}}_{\epsilon}}$  [Kla10]; set-disjointness is easy for  $\mathsf{PostBPP^{\mathsf{cc}}}$  (indeed, for  $\mathsf{coNP^{\mathsf{cc}}}$ ) but hard for  $\mathsf{SBP^{\mathsf{cc}}}$  [Raz92, GW16]; equality is easy for  $\mathsf{SBP^{\mathsf{cc}}}$  (indeed, for  $\mathsf{coRP^{\mathsf{cc}}}$ ) but hard for  $\mathsf{NP^{\mathsf{cc}}}$ . Moreover,  $\mathsf{WAPP^{\mathsf{cc}}}$  is a one-sided version of  $\mathsf{2WAPP^{\mathsf{cc}}}$  in the sense that  $\mathsf{2WAPP^{\mathsf{cc}}_{\epsilon}}(F) \leq O(\mathsf{WAPP^{\mathsf{cc}}_{\epsilon/2}}(F) + \mathsf{coWAPP^{\mathsf{cc}}_{\epsilon/2}}(F))$  (so the classes would satisfy  $\mathsf{2WAPP^{\mathsf{cc}}} = \mathsf{WAPP^{\mathsf{cc}}} \cap \mathsf{coWAPP^{\mathsf{cc}}}$  if we ignore the precise value of the constant  $\epsilon$ ).

The reason we do not include an  $\epsilon$  parameter in the SBP<sup>cc</sup> and PostBPP<sup>cc</sup> models is because standard amplification techniques could be used to efficiently decrease  $\epsilon$  in these models (rendering the exact value immaterial up to constant factors). Another subtlety concerns the behavior of correct protocols on the *undefined* inputs  $\{0,1\}^n \times \{0,1\}^n \setminus \text{dom } F$ . For example, for 2WAPP<sup>cc</sup>, the corresponding definitions in [KLL<sup>+</sup>15] also require that for every undefined input (x,y),  $\Pr[\Pi(x,y) \neq \bot] \in [(1-\epsilon)\alpha, \alpha]$ . We allow arbitrary behavior on the undefined inputs for stylistic consistency, but our results also hold for the other version. As a final remark, we mention that our definition of NP<sup>cc</sup> is only equivalent to the usual definition within an additive logarithmic term; see Remark 2 below.

Relation to zero-communication models. The following fact shows that protocols in our models can be expressed simply as distributions over (labeled) rectangles; thus these models can be considered "zero-communication" since Alice and Bob can each produce an output with no communication, and then have the output of the protocol be a simple function of their individual outputs.<sup>3</sup>

<span id="page-18-1"></span>**Fact 23.** Without loss of generality, in each of the five models from Definition 22, for each outcome of the public randomness the associated deterministic protocol is of the following form.

NP,  $WAPP_{\epsilon}$ , SBP: There exists a rectangle R such that the output is 1 iff the input is in R.

2WAPP<sub> $\epsilon$ </sub>, PostBPP: There exists a rectangle R and a bit b such that the output is b if the input is in R and is  $\perp$  otherwise.

*Proof.* Consider a protocol  $\Pi$  in one of the models from Definition 22, and suppose it has communication cost c and associated  $\alpha > 0$ , so the cost is  $c + \log(1/\alpha)$ . We may assume that each deterministic protocol has exactly  $2^c$  possible transcripts. Transform  $\Pi$  into a new protocol  $\Pi'$  that operates as follows on input (x, y): Sample an outcome of the public randomness of  $\Pi$ , then sample a uniformly random transcript with associated rectangle R and output-value b, then execute the following.

$$\text{If } (x,y) \in R \text{ then output } b \text{, otherwise output } \begin{cases} 0 & \text{if NP, WAPP}_{\epsilon}, \text{ SBP} \\ \bot & \text{if 2WAPP}_{\epsilon}, \text{ PostBPP} \end{cases}.$$

We have  $\mathbf{Pr}[\Pi'(x,y)=1]=2^{-c}\mathbf{Pr}[\Pi(x,y)=1]$ , and for  $2\mathsf{WAPP}_{\epsilon}$ , PostBPP we also have  $\mathbf{Pr}[\Pi'(x,y)=0]=2^{-c}\mathbf{Pr}[\Pi(x,y)=0]$ . Thus in all cases  $\Pi'$  is  $(2^{-c}\alpha)$ -correct. Formally, it takes two bits of communication to check whether  $(x,y)\in R$ , so the cost of  $\Pi'$  is  $2+\log(1/2^{-c}\alpha)$ , which is the cost of  $\Pi$  plus 2.

<span id="page-18-0"></span><sup>&</sup>lt;sup>3</sup>Admittedly, for Alice and Bob themselves to know the output of this simple function, they would need to use a constant amount of communication.

Relation to lower bound measures. Using Fact 23 it is straightforward to see that, ignoring the +2 cost of checking whether the input is in a rectangle,  $2\text{WAPP}_{\epsilon}^{\text{cc}}$  is exactly equivalent to the relaxed partition bound of [KLL+15] (with the aforementioned caveat about undefined inputs) and WAPP $_{\epsilon}^{\text{cc}}$  is exactly equivalent to the (one-sided) smooth rectangle bound<sup>4</sup>, denoted srec<sup>1</sup> [JK10]. For completeness, the definition of srec<sup>1</sup> and the proof of the following fact appear in Appendix A.1.

<span id="page-19-4"></span>Fact 24. 
$$\operatorname{srec}_{\epsilon}^1(F) \leq \operatorname{WAPP}_{\epsilon}^{\operatorname{cc}}(F) \leq \operatorname{srec}_{\epsilon}^1(F) + 2 \text{ for all } F \text{ and all } 0 < \epsilon < 1/2.$$

It was shown in [GW16] that SBP<sup>cc</sup> is equivalent (within constant factors) to the (one-sided) corruption bound. We remark that by a simple application of the minimax theorem, PostBPP<sup>cc</sup> also has a dual characterization analogous to the corruption bound.<sup>5</sup>

#### <span id="page-19-0"></span>3.2 Unrestricted communication models

For all the models described above, we can define their unrestricted versions, denoted by prepending U to the acronym (not to be confused with complexity classes where U stands for "unambiguous"). The distinction is that the restricted versions charge  $+\log(1/\alpha)$  in the cost, whereas the unrestricted versions do not charge anything for  $\alpha$  in the cost (and hence they are defined using private randomness; otherwise every function would be computable with constant cost.)

**Definition 25.** For  $C \in \{NP, 2WAPP_{\epsilon}, WAPP_{\epsilon}, SBP, PostBPP\}$  and  $F : \{0, 1\}^n \times \{0, 1\}^n \to \{0, 1, *\}$  a partial function, define  $UC^{cc}(F)$  as the minimum over all  $\alpha > 0$  and all " $\alpha$ -correct" private-randomness protocols for F of the communication cost, where the  $\alpha$ -correctness criteria are as in Definition 22.

Standard sparsification of randomness (à la Newman's Theorem [New91], [KN97, Theorem 3.14]) can be used to show that the unrestricted models are essentially at least as powerful as their restricted versions for all F: for  $\mathcal{C} \in \{\mathsf{NP}, \mathsf{SBP}, \mathsf{PostBPP}\}$  we have  $\mathsf{U}\mathcal{C}^{\mathsf{cc}}(F) \leq O(\mathcal{C}^{\mathsf{cc}}(F) + \log n)$ , and for  $\mathcal{C} \in \{\mathsf{2WAPP}, \mathsf{WAPP}\}$  we have  $\mathsf{U}\mathcal{C}^{\mathsf{cc}}_{\delta}(F) \leq O(\mathcal{C}^{\mathsf{cc}}_{\epsilon}(F) + \log(n/(\delta - \epsilon)))$  where  $0 < \epsilon < \delta$ . (The additive logarithmic terms come from converting public randomness to private.)

<span id="page-19-1"></span>Remark 2. We note that  $\mathsf{UNP^{cc}}$  is actually equivalent to the standard definition of nondeterministic communication complexity, while our  $\mathsf{NP^{cc}}$  from Definition 22 is only equivalent within an additive logarithmic term. It is fair to call this an abuse of notation, but it does not affect our communication-query equivalence for  $\mathsf{NP}$  since we consider block length  $b = \Omega(\log n)$  anyway.

UWAPP<sup>cc</sup> and nonnegative rank. Of particular interest to us will be UWAPP<sup>cc</sup> which turns out to be equivalent to approximate nonnegative rank. Recall that for M a nonnegative matrix, the nonnegative rank rank<sup>+</sup>(M) is defined as the minimum r such that M can be written as the sum of r nonnegative rank-1 matrices, or equivalently, M = UV for nonnegative matrices U, V with inner dimension r for the multiplication. Below, we view a partial function  $F: \{0,1\}^n \times \{0,1\}^n \to \{0,1,*\}$  as a  $2^n \times 2^n$  partial boolean matrix.

<span id="page-19-2"></span><sup>&</sup>lt;sup>4</sup>The paper that introduced this bound [JK10] defined it as the optimum value of a certain linear program, but following [KMSY14] we define it as the log of the optimum value.

<span id="page-19-3"></span><sup>&</sup>lt;sup>5</sup>PostBPP<sup>cc</sup>(F) is big- $\Theta$  of the maximum over all distributions  $\mu$  over  $\{0,1\}^n \times \{0,1\}^n$  of the minimum  $\log(1/\mu(R))$  over all rectangles R that are unbalanced in the sense that  $\mu(R \cap F^{-1}(1))$  and  $\mu(R \cap F^{-1}(0))$  are not within a factor of 2 of each other. In the corruption bound, the maximum is only over balanced  $\mu$ , and R is considered unbalanced if  $\mu(R \cap F^{-1}(1))$  is more than some constant factor greater than  $\mu(R \cap F^{-1}(0))$ .

**Definition 26** (Approximate nonnegative rank). For partial F, rank $_{\epsilon}^+(F)$  is defined as the minimum rank $_{\epsilon}^+(M)$  over all nonnegative matrices M such that  $M_{x,y} \in F(x,y) \pm \epsilon$  for all  $(x,y) \in \text{dom } F$  (in other words,  $||F - M||_{\infty} \le \epsilon$  on dom F).

For completeness, the straightforward proof of the following fact appears in Appendix A.2.

<span id="page-20-3"></span>Fact 27.  $\log \operatorname{rank}_{\epsilon}^+(F) \leq \operatorname{\sf UWAPP^{cc}_{\epsilon}}(F) \leq \lceil \log \operatorname{rank}_{\epsilon/2}^+(F) \rceil + 2 \text{ for all } F \text{ and all } 0 < \epsilon < 1/2.$ 

## <span id="page-20-0"></span>3.3 Query models

A randomized decision tree  $\mathcal{T}$  is a probability distribution over deterministic decision trees, and the query cost is the maximum height of a decision tree in the support.

<span id="page-20-1"></span>**Definition 28.** For  $C \in \{\text{NP}, 2\text{WAPP}_{\epsilon}, \text{WAPP}_{\epsilon}, \text{SBP}, \text{PostBPP}\}\$ and  $f : \{0, 1\}^n \to \{0, 1, *\}$  a partial function, define  $C^{\mathsf{dt}}(f)$  as the minimum over all  $\alpha > 0$  and all " $\alpha$ -correct" randomized decision trees for f of the query cost, where the  $\alpha$ -correctness criteria are as in Definition 22 (but where protocols  $\Pi(x,y)$  are replaced with randomized decision trees  $\mathcal{T}(z)$ ).

Completely analogously to how the zero-communication models can be viewed w.l.o.g. as distributions over (labeled) rectangles (Fact 23), their query counterparts can be viewed w.l.o.g. as distributions over (labeled) conjunctions.

<span id="page-20-2"></span>**Fact 29.** Without loss of generality, in each of the five models from Definition 28, for each outcome of the randomness the associated deterministic decision tree is of the following form.

 $\mathsf{NP},\ \mathsf{WAPP}_\epsilon,\ \mathsf{SBP}:\ \mathit{There\ exists\ a\ conjunction\ } h\ \mathit{such\ that\ the\ output\ is\ } 1\ \mathit{iff\ the\ input\ is\ } in\ h^{-1}(1).$ 

 $2WAPP_{\epsilon}$ , PostBPP: There exists a conjunction h and a bit b such that the output is b if the input is in  $h^{-1}(1)$  and is  $\perp$  otherwise.

Proof. Consider a randomized decision tree  $\mathcal{T}$  in one of the models from Definition 28, and suppose it has query cost d and associated  $\alpha > 0$ . We may assume that each deterministic decision tree has a full set of  $2^d$  leaves and the queries along each root-to-leaf path are distinct. Hence each leaf is associated with a width-d conjunction that checks whether the input is consistent with the queries made in its root-to-leaf path. Transform  $\mathcal{T}$  into a new randomized decision tree  $\mathcal{T}'$  that operates as follows on input z: Sample an outcome of the randomness of  $\mathcal{T}$ , then sample a uniformly random leaf with associated conjunction h and output-value b, then execute the following.

If 
$$h(z) = 1$$
 then output  $b$ , otherwise output 
$$\begin{cases} 0 & \text{if NP, WAPP}_{\epsilon}, \text{ SBP} \\ \bot & \text{if 2WAPP}_{\epsilon}, \text{ PostBPP} \end{cases}$$

We have 
$$\mathbf{Pr}[\mathcal{T}'(z) = 1] = 2^{-d} \mathbf{Pr}[\mathcal{T}(z) = 1]$$
, and for  $2\mathsf{WAPP}_{\epsilon}$ , PostBPP we also have  $\mathbf{Pr}[\mathcal{T}'(z) = 0] = 2^{-d} \mathbf{Pr}[\mathcal{T}(z) = 0]$ . Thus in all cases  $\mathcal{T}'$  is  $(2^{-d}\alpha)$ -correct, and  $\mathcal{T}'$  also has query cost  $d$ .

We defined our query models without charging anything for  $\alpha$ , i.e.,  $\alpha$  is unrestricted. This means that deriving communication upper bounds for  $f \circ g^n$  in restricted models from corresponding query upper bounds for f is nontrivial; this is discussed in Section 4.2. Nevertheless, we contend that Definition 22 and Definition 28 are the "right" definitions that correspond to one another. The main reason is because in the "normal forms" (Fact 23 and Fact 29), all the cost in the communication version comes from  $\alpha$ , and all the cost in the query version comes from the width of the conjunctions—and when we apply the Junta Theorem in Section 4.1, the communication  $\alpha$  directly determines the conjunction width.

## <span id="page-21-0"></span>4 Proof of the Simulation Theorem

In this section we derive the Simulation Theorem (Theorem 2) from the Junta Theorem (Theorem 1). The proof is in two parts: Section 4.1 for lower bounds and Section 4.2 for upper bounds.

### <span id="page-21-1"></span>4.1 Communication lower bounds

The Junta Theorem implies that for functions lifted with our hard gadget g, every distribution  $\mathcal{R}$  over rectangles can be transformed into a distribution  $\mathcal{H}$  over conjunctions such that for every  $z \in \{0,1\}^n$ , the acceptance probability under  $\mathcal{H}$  is related in a simple way to the acceptance probability under  $\mathcal{R}$  averaged over all two-party encodings of z. This allows us to convert zero-communication protocols (which are distributions over (labeled) rectangles by Fact 23) into corresponding decision trees (which are distributions over (labeled) conjunctions by Fact 29).

More precisely, let  $\mathcal{R}$  be a distribution over rectangles in the domain of  $G = g^n$ . First, apply the Junta Theorem to each R in the support of  $\mathcal{R}$  to get an approximating conical d-junta  $h_R$ . Now we can approximate the convex combination

$$\operatorname{acc}_{\mathcal{R}}(z) = \underset{\mathbf{R} \sim \mathcal{R}}{\mathbf{E}} \operatorname{acc}_{\mathbf{R}}(z) \in \underset{\mathbf{R} \sim \mathcal{R}}{\mathbf{E}} \left( (1 \pm o(1)) \cdot h_{\mathbf{R}}(z) \pm 2^{-\Theta(db)} \right) \subseteq (1 \pm o(1)) \cdot \left( \underset{\mathbf{R} \sim \mathcal{R}}{\mathbf{E}} h_{\mathbf{R}}(z) \right) \pm 2^{-\Theta(db)}$$

by the conical d-junta  $\mathbf{E}_{R \sim \mathcal{R}} h_R$  with the same parameters as in the Junta Theorem (we settle for multiplicative error  $(1 \pm o(1))$  since it suffices for the applications). But conical d-juntas are—up to scaling—convex combinations of width-d conjunctions. Specifically, we may write any conical d-junta as  $\mathrm{acc}_{\mathcal{H}}(z)/a$  where a > 0 is some constant of proportionality and  $\mathrm{acc}_{\mathcal{H}}(z) \coloneqq \mathbf{E}_{h \sim \mathcal{H}} h(z)$  where  $\mathcal{H}$  is a distribution over width-d conjunctions. Finally, we rearrange the approximation so the roles of  $\mathrm{acc}_{\mathcal{H}}(z)$  and  $\mathrm{acc}_{\mathcal{R}}(z)$  are swapped, since it is more convenient for the applications. Hence we arrive at the following reformulation of the Junta Theorem.

<span id="page-21-2"></span>**Corollary 30** (Junta Theorem—reformulation). Assume (†). For any  $d \ge 0$  and any distribution  $\mathcal{R}$  over rectangles in the domain of  $g^n$  there exists a distribution  $\mathcal{H}$  over width-d conjunctions and a constant of proportionality a > 0 such that, for all  $z \in \{0,1\}^n$ ,

$$\operatorname{acc}_{\mathcal{H}}(z) \in a \cdot ((1 \pm o(1)) \cdot \operatorname{acc}_{\mathcal{R}}(z) \pm 2^{-\Theta(db)}).$$
 (8)

We will now prove the lower bounds in Theorem 2. Here the error parameters for WAPP are made more explicit.

<span id="page-21-3"></span>**Theorem 31.** Assume (†). For any partial  $f: \{0,1\}^n \to \{0,1,*\}$  and constants  $0 < \epsilon < \delta < 1/2$ ,

$$\mathcal{C}^{\mathsf{cc}}(f \circ g^n) \geq \Omega(\mathcal{C}^{\mathsf{dt}}(f) \cdot b) \qquad \textit{for } \mathcal{C} \in \{\mathsf{NP}, \mathsf{SBP}, \mathsf{PostBPP}\},$$

$$\mathcal{C}^{\mathsf{cc}}_{\epsilon}(f \circ g^n) \geq \Omega(\mathcal{C}^{\mathsf{dt}}_{\delta}(f) \cdot b) \qquad \textit{for } \mathcal{C} \in \{\mathsf{2WAPP}, \mathsf{WAPP}\}.$$

*Proof.* For convenience of notation we let  $\mathcal{C}^{\mathsf{cc}} := \mathcal{C}^{\mathsf{cc}}_{\epsilon}$  and  $\mathcal{C}^{\mathsf{dt}} := \mathcal{C}^{\mathsf{dt}}_{\delta}$  in the  $\mathcal{C} \in \{\mathsf{2WAPP}, \mathsf{WAPP}\}$  cases. Given an  $\alpha$ -correct cost-c  $\mathcal{C}^{\mathsf{cc}}$  protocol  $\Pi$  for  $f \circ g^n$  assumed to be in the "normal form" given by Fact 23, we convert it into a cost-O(c/b)  $\mathcal{C}^{\mathsf{dt}}$  decision tree  $\mathcal{T}$  for f.

For  $C \in \{\text{NP}, \text{WAPP}, \text{SBP}\}$ ,  $\Pi$  is a distribution over rectangles, so applying Corollary 30 with d := O(c/b) so that  $2^{-\Theta(db)} \le o(2^{-c}) = o(\alpha)$ , there exists a distribution  $\mathcal{T}$  over width-d conjunctions and an a > 0 such that for all  $z \in \{0, 1\}^n$ ,  $\operatorname{acc}_{\mathcal{T}}(z) \in a \cdot ((1 \pm o(1)) \cdot \operatorname{acc}_{\Pi}(z) \pm o(\alpha))$ . Note that

 $\operatorname{acc}_{\Pi}(z)$  obeys the  $\alpha$ -correctness criteria of f since it obeys the  $\alpha$ -correctness criteria of  $f \circ g^n$  for each encoding of z. Hence  $\operatorname{acc}_{\mathcal{T}}(z)$  obeys the  $(a\alpha')$ -correctness criteria for some  $\alpha' \in \alpha \cdot (1 \pm o(1))$ . (For  $\mathcal{C} = \mathsf{SBP}$  slight amplification may be needed. Also, for  $\mathcal{C} = \mathsf{NP}$  we need to ensure that  $\operatorname{acc}_{\mathcal{T}}(z) = 0$  whenever  $\operatorname{acc}_{\Pi}(z) = 0$ , but this is implicit in the proof of the Junta Theorem; see the left side of (4).) In conclusion,  $\mathcal{T}$  is a cost-d  $\mathcal{C}^{\mathsf{dt}}$  decision tree for f.

For  $C \in \{2\text{WAPP}, \text{PostBPP}\}$ ,  $\Pi$  can be viewed as a convex combination  $\pi_0\Pi_0 + \pi_1\Pi_1$  where  $\Pi_0$  is a distribution over 0-labeled rectangles and  $\Pi_1$  is a distribution over 1-labeled rectangles. Applying the above argument to  $\Pi_0$  and  $\Pi_1$  separately, we may assume the scaling factor a is the same for both, by assigning some probability to a special "contradictory" conjunction that accepts nothing. We get a distribution over labeled width-d conjunctions  $\mathcal{T} := \pi_0 \mathcal{T}_0 + \pi_1 \mathcal{T}_1$  such that  $\mathbf{Pr}[\mathcal{T}(z) = 0] = \pi_0 \operatorname{acc}_{\mathcal{T}_0}(z) \in \pi_0 a \cdot ((1 \pm o(1)) \cdot \operatorname{acc}_{\Pi_0}(z) \pm o(\alpha)) \subseteq a \cdot ((1 \pm o(1)) \cdot \mathbf{Pr}[\Pi(z) = 0] \pm o(\alpha))$  where we use the shorthand  $\mathbf{Pr}[\Pi(z) = 0] := \mathbf{E}_{xy \sim \mathcal{U}_z} \mathbf{Pr}[\Pi(x, y) = 0]$ . An analogous property holds for outputting 1 instead of 0. Note that  $\mathbf{Pr}[\Pi(z) = 0]$  and  $\mathbf{Pr}[\Pi(z) = 1]$  obey the  $\alpha$ -correctness criteria since they do for each encoding of z. Hence  $\mathbf{Pr}[\mathcal{T}(z) = 0]$  and  $\mathbf{Pr}[\mathcal{T}(z) = 1]$  obey the  $(a\alpha')$ -correctness criteria for some  $\alpha' \in \alpha \cdot (1 \pm o(1))$ . (For  $\mathcal{C} = \mathbf{PostBPP}$  slight amplification may be needed.) In conclusion,  $\mathcal{T}$  is a cost-d  $\mathcal{C}^{dt}$  decision tree for f.

## <span id="page-22-0"></span>4.2 Communication upper bounds

<span id="page-22-2"></span>**Theorem 32.** Let  $C \in \{\mathsf{NP}, \mathsf{2WAPP}_{\epsilon}, \mathsf{WAPP}_{\epsilon}, \mathsf{SBP}\}$ . For any partial  $f : \{0, 1\}^n \to \{0, 1, *\}$  and any gadget  $g : \{0, 1\}^b \times \{0, 1\}^b \to \{0, 1\}$ , we have  $C^{\mathsf{cc}}(f \circ g^n) \leq O(C^{\mathsf{dt}}(f) \cdot (b + \log n))$ .

Proof. On input (x,y) the communication protocol just simulates the randomized decision tree on input  $z := g^n(x,y)$ , and when the decision tree queries the *i*-th bit of z, the communication protocol evaluates  $z_i := g(x_i, y_i)$  by brute force. This has communication cost  $\mathcal{C}^{\mathsf{dt}}(f) \cdot (b+1)$ , and it inherits the  $\alpha$  parameter from the randomized decision tree. The nontrivial part is that the query models allow arbitrarily small  $\alpha$ , which could give arbitrarily large  $+\log(1/\alpha)$  cost to the communication protocol. For these particular query models, it turns out that we can assume without loss of generality that  $\log(1/\alpha) \leq O(\mathcal{C}^{\mathsf{dt}}(f) \cdot \log n)$ . We state and prove this for SBP<sup>dt</sup> below. (The other three models are no more difficult to handle.)

<span id="page-22-3"></span>**Proposition 33.** Every partial function f admits an  $\alpha$ -correct  $\mathsf{SBP}^\mathsf{dt}$  decision tree of query cost  $d \coloneqq \mathsf{SBP}^\mathsf{dt}(f)$  where  $\alpha \ge 2^{-d} \binom{n}{d}^{-1} \ge 2^{-O(d \cdot \log n)}$ .

Proof. Consider an  $\alpha'$ -correct cost-d SBP<sup>dt</sup> decision tree for f in the "normal form" given by Fact 29. We may assume each deterministic decision tree in the support is a conjunction with exactly d literals (and there are  $2^d \binom{n}{d}$  many such conjunctions). The crucial observation is that it never helps to assign a probability larger than  $\alpha'$  to any conjunction: if some conjunction appears with probability  $p > \alpha'$ , we may replace its probability with  $\alpha'$  and assign the leftover probability  $p - \alpha'$  to a special "contradictory" conjunction that accepts nothing. This modified randomized decision tree is still  $\alpha'$ -correct for f. Finally, remove all probability from the contradictory conjunction and scale the remaining probabilities (along with  $\alpha'$ ) to sum up to 1. Let  $\alpha$  be the scaled version of  $\alpha'$ . Now we have that  $\alpha$  is greater than or equal to each of  $2^d \binom{n}{d}$  many probabilities, and hence  $\alpha$  must be at least the reciprocal of this number.

<span id="page-22-1"></span>Remark 3. In the case of PostBPP<sup>dt</sup> we cannot assume w.l.o.g. that  $\log(1/\alpha) \leq \text{poly}(d, \log n)$ . The canonical counterexample is a decision list function  $f: \{0,1\}^n \to \{0,1\}$  defined relative to a binary

vector  $(a_1, \ldots, a_n) \in \{0, 1\}^n$  so that  $f(x) := a_i$  where  $i \in [n]$  is the smallest number such that  $x_i = 1$ , or f(x) := 0 if no such i exists. Each decision list admits a cost-1 PostBPP<sup>dt</sup> decision tree, but for some decision lists the associated  $\alpha$  must be exponentially small in n; see, e.g., [BVdW07] for more details. Indeed, two-party lifts of decision lists have been used in separating unrestricted communication models from restricted ones as we will discuss in Section 6.

## <span id="page-23-0"></span>5 Applications of the Simulation Theorem

In this section we use the Simulation Theorem to derive our applications. We prove Theorem 3 and Theorem 6 in Section 5.1 and Section 5.2, respectively. Throughout this section we use o(1) to denote a quantity that is upper bounded by some sufficiently small constant, which may be different for the different instances of o(1). (For example,  $a \le o(b)$  formally means there exists a constant  $\epsilon > 0$  such that  $a \le \epsilon \cdot b$ .)

### <span id="page-23-1"></span>5.1 Nonclosure under intersection

Recall that  $f_{\wedge}(z, z') := f(z) \wedge f(z')$ . Here  $f_{\wedge}$  is *not* to be thought of as a two-party function; we study the query complexity of  $f_{\wedge}$ , whose input we happen to divide into two halves called z and z'. We start with the following lemma.

<span id="page-23-2"></span>**Lemma 34.** There exists a partial f such that  $SBP^{dt}(f) \leq O(1)$ , but  $SBP^{dt}(f_{\wedge}) \geq \Omega(n^{1/4})$ .

Let  $k := o(\sqrt{n})$  and define a partial function  $f: \{0,1\}^n \to \{0,1,*\}$  by

$$f(z) := \begin{cases} 1 & \text{if } |z| \ge k \\ 0 & \text{if } |z| \le k/2 \\ * & \text{otherwise} \end{cases}$$

where |z| denotes the Hamming weight of z.

In proving the lower bound in Lemma 34 we make use of the following duality principle for SBP<sup>dt</sup>, which we phrase abstractly in terms of a collection  $\mathscr{H}$  of "basic functions" over some finite set of inputs Z. In our concrete case  $\mathscr{H}$  consists of decision trees of height d, or equivalently width-d conjunctions by Fact 29, and  $Z \subseteq \{0,1\}^n$  is the domain of the partial function f. We state the duality principle for acceptance gap  $[0,\alpha/2)$ -vs- $(\alpha,1]$  rather than  $[0,\alpha/2]$ -vs- $[\alpha,1]$  as this implicitly ensures  $\alpha > 0$ . The slight difference in the multiplicative gap, (>2)-vs- $(\geq 2)$ , is immaterial as the gap can be efficiently amplified for SBP affecting only constant factors.

<span id="page-23-3"></span>**Fact 35.** For all  $\mathcal{H} \subseteq \{0,1\}^Z$  and non-constant  $f: Z \to \{0,1\}$ , the following are equivalent.

(i) There exists a distribution  $\mathcal{H}$  over  $\mathscr{H}$  such that for all  $(z_1, z_0) \in f^{-1}(1) \times f^{-1}(0)$ ,

$$\Pr_{\boldsymbol{h} \sim \mathcal{H}}[\boldsymbol{h}(z_1) = 1] > 2 \cdot \Pr_{\boldsymbol{h} \sim \mathcal{H}}[\boldsymbol{h}(z_0) = 1]. \tag{9}$$

(ii) For each pair of distributions  $(\mu_1, \mu_0)$  over  $f^{-1}(1)$  and  $f^{-1}(0)$  there is an  $h \in \mathcal{H}$  with

$$\Pr_{z_1 \sim \mu_1} [h(z_1) = 1] > 2 \cdot \Pr_{z_0 \sim \mu_0} [h(z_0) = 1].$$
 (10)

The direction  $(i) \Rightarrow (ii)$  is trivial and is all we need for our proof, but it is interesting that the converse direction  $(ii) \Rightarrow (i)$  also holds, by a slightly non-standard argument. We include a full proof in Appendix A.4.

We also use the following basic calculation (given in Appendix A.3 for completeness).

<span id="page-24-0"></span>**Fact 36.** Let  $h: \{0,1\}^n \to \{0,1\}$  be a width-d conjunction with i positive literals. Then h accepts a uniformly random string of Hamming weight w with probability  $\in (w/n)^i \cdot (1 \pm o(1))$  provided  $w \le o(\sqrt{n})$  and  $d \le o(\sqrt{w})$ .

Proof of Lemma 34. Let f and  $f_{\wedge}$  be as above. We have  $\mathsf{SBP}^{\mathsf{dt}}(f) = 1$  via the decision tree  $\mathcal{T}$  that picks a random coordinate and accepts iff the coordinate is 1. For the lower bound on  $\mathsf{SBP}^{\mathsf{dt}}(f_{\wedge})$ , we use the contrapositive of  $(i) \Rightarrow (ii)$ . Let  $\mathscr{H}$  consist of all conjunctions of width  $o(n^{1/4})$ . Let  $\mathcal{Z}_w$  denote the uniform distribution over n-bit strings of weight w, intended to be used as either the first input z or the second input z' to  $f_{\wedge}$ . We construct a hard pair of distributions  $(\mu_1, \mu_0)$  over  $f_{\wedge}^{-1}(1)$  and  $f_{\wedge}^{-1}(0)$ , respectively, by

$$\mu_1 := \mathcal{Z}_k \times \mathcal{Z}_k, \qquad \mu_0 := \frac{1}{2}(\mathcal{Z}_{k/2} \times \mathcal{Z}_{2k}) + \frac{1}{2}(\mathcal{Z}_{2k} \times \mathcal{Z}_{k/2}).$$

Here  $\times$  denotes concatenation of strings, e.g.,  $(z, z') \sim \mu_1$  is such that  $z, z' \sim \mathcal{Z}_k$  and z and z' are independent. For intuition why the pair  $(\mu_1, \mu_0)$  is hard, consider the natural decision tree  $\mathcal{T}_{\wedge}$  attempting to compute  $f_{\wedge}$  that runs  $\mathcal{T}$  (defined above) twice, once for z and once for z', accepting iff both runs accept. Since  $\mathcal{T}$  accepts  $\mathcal{Z}_k$  with probability k/n, we have that  $\mathcal{T}_{\wedge}$  accepts  $\mu_1$  with probability  $k^2/n^2$ . Similarly,  $\mathcal{T}_{\wedge}$  accepts  $\mu_0$  with probability  $\frac{1}{2}(k/2n) \cdot (2k/n) + \frac{1}{2}(2k/n) \cdot (k/2n) = k^2/n^2$ . Hence  $\mathcal{T}_{\wedge}$  fails to distinguish between  $\mu_1$  and  $\mu_0$ . More generally, we make a similar calculation for any width- $o(n^{1/4})$  conjunction. Indeed, let  $h: \{0,1\}^{2n} \to \{0,1\}$  be an arbitrary conjunction in  $\mathscr{H}$ , and suppose h has i positive literals in z and j positive literals in z'. Then by Fact 36 we have

$$\frac{\mathbf{Pr}_{(\boldsymbol{z},\boldsymbol{z'})\sim\mu_{1}}[h(\boldsymbol{z},\boldsymbol{z'})=1]}{\mathbf{Pr}_{(\boldsymbol{z},\boldsymbol{z'})\sim\mu_{0}}[h(\boldsymbol{z},\boldsymbol{z'})=1]} \in \frac{(k/n)^{i}\cdot(k/n)^{j}}{\frac{1}{2}\cdot(k/2n)^{i}\cdot(2k/n)^{j}+\frac{1}{2}\cdot(2k/n)^{i}\cdot(k/2n)^{j}}\cdot(1\pm o(1))$$

$$= \frac{1}{\frac{1}{2}\cdot2^{j-i}+\frac{1}{2}\cdot2^{i-j}}\cdot(1\pm o(1))$$

$$\leq 1\cdot(1\pm o(1))$$

$$\leq 2.$$

This means that  $\neg(ii)$  and hence  $\neg(i)$ . Therefore  $f_{\wedge}$  has no cost- $o(n^{1/4})$  SBP<sup>dt</sup> decision tree.

We can now prove Theorem 3, restated here from the introduction.

**Theorem 3.** SBP<sup>cc</sup> is not closed under intersection.

Proof. Let f and  $f_{\wedge}$  be as above. Define  $F := f \circ g^n$  and  $F_{\wedge} := f_{\wedge} \circ g^{2n} = (f \circ g^n)_{\wedge}$  where  $g : \{0,1\}^b \times \{0,1\}^b \to \{0,1\}, b = \Theta(\log n)$ , is our hard gadget from  $(\dagger)$ . Then by the Simulation Theorem (Theorem 2), we have  $\mathsf{SBP^{cc}}(F_{\wedge}) \ge \Omega(\mathsf{SBP^{dt}}(f_{\wedge}) \cdot b) \ge \Omega(n^{1/4} \cdot b)$  which is not polylogarithmic in the input length so that  $F_{\wedge} \notin \mathsf{SBP^{cc}}$ . Furthermore, we have  $\mathsf{SBP^{cc}}(F) \le O(\mathsf{SBP^{dt}}(f) \cdot b) \le O(b)$  which is logarithmic in the input length. Thus  $F \in \mathsf{SBP^{cc}}$ , which implies that  $F_{\wedge}$  is the intersection of two functions in  $\mathsf{SBP^{cc}}$  (one that evaluates F on the first half of the input, and one that evaluates F on the second half).

<span id="page-25-1"></span>![](_page_25_Figure_0.jpeg)

![](_page_25_Figure_1.jpeg)

**Figure 3:** Illustration for the proof of Theorem 6.

### <span id="page-25-0"></span>5.2 Unamplifiability of error

Our next application of the Simulation Theorem shows that the error parameter  $\epsilon$  for WAPP<sup>cc</sup> cannot be efficiently amplified. Combining this with the results illustrated in Figure 4 (in particular, the fact that the equivalence holds for partial functions) shows that also for approximate nonnegative rank,  $\epsilon$  cannot be efficiently amplified.

**Theorem 6.** For all constants  $0 < \epsilon < \delta < 1/2$  there exists a two-party partial function F such that  $\mathsf{WAPP}^{\mathsf{cc}}_{\delta}(F) \leq O(\log n)$  but  $\mathsf{WAPP}^{\mathsf{cc}}_{\epsilon}(F) \geq \Omega(n)$ .

*Proof.* Let c/d be a rational (expressed in lowest terms) such that  $(1-2\delta)/(1-\delta) \le c/d < (1-2\epsilon)/(1-\epsilon)$ . Note that such c,d exist (since  $\epsilon < \delta$ ) and that they are constants depending only on  $\epsilon$  and  $\delta$ . Define a partial function  $f: \{0,1\}^n \to \{0,1,*\}$  by

$$f(z) := \begin{cases} 1 & \text{if } |z| \in \{c, d\} \\ 0 & \text{if } |z| = 0 \\ * & \text{otherwise} \end{cases}$$

where |z| denotes the Hamming weight of z. By the Simulation Theorem (Theorem 31 and Theorem 32), it suffices to prove that  $\mathsf{WAPP}^{\mathsf{dt}}_{\delta}(f) \leq O(1)$  and  $\mathsf{WAPP}^{\mathsf{dt}}_{\epsilon}(f) \geq \Omega(n)$ .

Upper bound. Consider a cost-1 decision tree  $\mathcal{T}'$  that picks a random coordinate and accepts iff the coordinate is 1. Then  $\operatorname{acc}_{\mathcal{T}'}(z) = |z|/n$ . Let  $\alpha \coloneqq d/n$  and define  $\mathcal{T}$  as follows: on input z accept with probability  $\delta\alpha$ , reject with probability  $\delta(1-\alpha)$ , and run  $\mathcal{T}'(z)$  with the remaining probability  $(1-\delta)$ . Now  $\operatorname{acc}_{\mathcal{T}}(z)$  behaves as plotted on the left side of Figure 3: if |z| = 0 then  $\operatorname{acc}_{\mathcal{T}}(z) = \delta\alpha$ , if |z| = d then  $\operatorname{acc}_{\mathcal{T}}(z) = \delta\alpha + (1-\delta)d/n = \alpha$ , and if |z| = c then  $\operatorname{acc}_{\mathcal{T}}(z) = \delta\alpha + (1-\delta)c/n$  which is at most  $\alpha$  and at least  $\delta\alpha + (1-\delta)d(1-2\delta)/((1-\delta)n) = \delta\alpha + (1-2\delta)\alpha = (1-\delta)\alpha$ . In particular,  $\mathcal{T}$  is an  $\alpha$ -correct WAPP $_{\delta}^{\text{dt}}$  decision tree for f.

Lower bound. The WAPP $_{\delta}^{dt}$  decision tree designed above is "tight" for f in the following sense: If we decrease the error parameter from  $\delta$  to  $\epsilon$ , there is no longer any convex function of |z| that would correspond to the acceptance probability of an  $\alpha$ -correct WAPP $_{\epsilon}^{dt}$  decision tree for f. This is suggested on the right side of Figure 3: only a non-convex function of |z| can satisfy the  $\alpha$ -correctness

requirements for f. We show that the acceptance probability of any low-cost WAPP $_{\epsilon}^{dt}$  decision tree can indeed be accurately approximated by a convex function, which then yields a contradiction.

We now give the details. Suppose for contradiction that  $\mathcal{T}$  is a distribution over width-o(n) conjunctions (by Fact 29) forming an  $\alpha$ -correct WAPP $_{\epsilon}^{dt}$  decision tree for f, for some arbitrary  $\alpha > 0$ . Consider the function  $Q \colon \{0, c, d\} \to [0, 1]$  defined by  $Q(w) \coloneqq \mathbf{E}_{\mathbf{z} \colon |\mathbf{z}| = w} \operatorname{acc}_{\mathcal{T}}(\mathbf{z})$  where the expectation is over a uniformly random string of Hamming weight w. Note that  $Q(0) \in [0, \epsilon \alpha]$  and  $Q(w) \in [(1 - \epsilon)\alpha, \alpha]$  for  $w \in \{c, d\}$  by the correctness of  $\mathcal{T}$ . A function  $R \colon \{0, c, d\} \to \mathbb{R}$  is convex iff  $(R(c) - R(0))/c \le (R(d) - R(0))/d$ . Note that Q is non-convex since  $((1 - \epsilon)\alpha - \epsilon\alpha)/c > (\alpha - \epsilon\alpha)/d$ . In fact, this shows that there cannot exist a convex function R that point-wise multiplicatively approximates Q within  $1 \pm o(1)$ . However, we claim that there exists such an R, which provides the desired contradiction.

We now argue the claim. For a width-o(n) conjunction h, let  $Q_h: \{0, c, d\} \to [0, 1]$  be defined by  $Q_h(w) := \mathbf{Pr}_{z:|z|=w}[h(z)=1]$ , and note that  $Q = \mathbf{E}_{h \sim \mathcal{T}} Q_h$ . We show that for each such h,  $Q_h$  can be multiplicatively approximated by a convex function  $R_h$ . Hence Q is multiplicatively approximated by the convex function  $R := \mathbf{E}_{h \sim \mathcal{T}} R_h$ .

Let  $\ell \leq o(n)$  denote the number of literals in h, and let i denote the number of positive literals in h. If i > c, we have  $Q_h(0) = Q_h(c) = 0$  and thus  $Q_h$  is convex and we can take  $R_h := Q_h$ . Henceforth suppose  $i \leq c$ . Using the notation  $(t)_m$  for the falling factorial  $t(t-1)\cdots(t-m+1)$ , for  $w \in \{c,d\}$  we have  $Q_h(w) = \binom{n-\ell}{w-i}/\binom{n}{w} = (w)_i(n-\ell)_{w-i}/(n)_w$ . Suppose i = 0. Then  $Q_h(0) = 1$ , and for  $w \in \{c,d\}$  we have  $Q_h(w) = (n-\ell)_w/(n)_w \geq 0$ 

Suppose i=0. Then  $Q_h(0)=1$ , and for  $w \in \{c,d\}$  we have  $Q_h(w)=(n-\ell)_w/(n)_w \ge (1-o(1))^w \ge 1-o(1)$  (since  $\ell \le o(n)$ ). Thus we can let  $R_h$  be the constant 1 function. Now suppose  $1 \le i \le c$ . Then  $Q_h(0)=0$ , and for  $w \in \{c,d\}$  we denote the "0 to w slope" as  $s_w := (Q_h(w)-Q_h(0))/w = (w-1)_{i-1}(n-\ell)_{w-i}/(n)_w$ . We have

$$\frac{s_c}{s_d} = \frac{(c-1)_{i-1}}{(d-1)_{i-1}} \cdot \frac{(n-\ell)_{c-i}}{(n-\ell)_{d-i}} \cdot \frac{(n)_d}{(n)_c} = \frac{(c-1)_{i-1}}{(d-1)_{i-1}} \cdot \frac{(n-c)_{d-c}}{(n-\ell-c+i)_{d-c}}.$$

The second multiplicand on the right side is at least 1 and at most  $(1+o(1))^{d-c} \leq 1+o(1)$  since  $\ell \leq o(n)$ . Now we consider two subcases. If  $2 \leq i \leq c$  then the first multiplicand on the right side is at most  $1-\Omega(1)$  since c < d; hence  $s_c/s_d \leq 1$  and thus  $Q_h$  is convex and we can take  $R_h := Q_h$ . Suppose i=1. Then the first multiplicand on the right side is 1, and hence  $s_c/s_d \in 1 \pm o(1)$ . This means  $Q_h$  is approximately linear. More precisely, defining  $R_h(w) := s_c \cdot w$ , we have  $R_h(0) = Q_h(0)$ ,  $R_h(c) = Q_h(c)$ , and  $R_h(d) = Q_h(d) \cdot s_c/s_d \in Q_h(d) \cdot (1 \pm o(1))$ .

Corollary 7. For all constants  $0 < \epsilon < \delta < 1/2$  there exists a partial boolean matrix F such that  $\operatorname{rank}_{\delta}^+(F) \le n^{O(1)}$  but  $\operatorname{rank}_{\epsilon}^+(F) \ge 2^{\Omega(n)}$ .

Proof sketch. Theorem 6 together with Theorem 9 (proved in the next section) imply that for all  $0 < \epsilon < \delta < 1/2$  there is a partial F such that  $\mathsf{UWAPP}^{\mathsf{cc}}_{\delta}(F) \leq O(\log n)$  and  $\mathsf{UWAPP}^{\mathsf{cc}}_{\epsilon}(F) \geq \Omega(n)$ . Unfortunately, there is a slight problem with applying Fact 27 to conclude a similar separation for  $\mathsf{rank}^+_{\epsilon}$  as this direct simulation loses a factor of 2 in the error parameter  $\epsilon$ . This loss results from the following asymmetry between the measures  $\mathsf{UWAPP}^{\mathsf{cc}}_{\epsilon}$  and  $\mathsf{rank}^+_{\epsilon}$ : the acceptance probabilities of 1-inputs are in  $[(1-\epsilon)\alpha,\alpha]$  in the former, whereas 1-entries can be approximated with values in  $[1-\epsilon,1+\epsilon]$  in the latter. However, this annoyance is easily overcome by considering modified versions of  $\mathsf{WAPP}^{\mathsf{cc}}_{\epsilon}$  and  $\mathsf{UWAPP}^{\mathsf{cc}}_{\epsilon}$  where the acceptance probability on 1-inputs is allowed to lie in  $[(1-\epsilon)\alpha,(1+\epsilon)\alpha]$ . It can be verified that under such a definition Theorem 6, Theorem 9, and Fact 27 continue to hold, and the "new" Fact 27 does not lose the factor 2 in the error.

## <span id="page-27-0"></span>6 Unrestricted–restricted equivalences

In this section we prove our unrestricted–restricted equivalence results, [Theorem 8](#page-7-4) and [Theorem 9,](#page-7-3) restated below. In [Section 6.1](#page-27-1) we prove a key "Truncation Lemma", and in [Section 6.2](#page-29-0) we use the lemma to prove the equivalences.

As already alluded to in the introduction, Buhrman et al. [\[BVdW07\]](#page-34-9) exhibited a function F with UPostBPPcc(F) ≤ O(log n) and PPcc(F) ≥ Ω(n 1/3 ). This simultaneously gives an exponential separation between PostBPPcc and UPostBPPcc and between PPcc and UPPcc. For our other models, we will show that the unrestricted and restricted versions are essentially equivalent. We state and prove this result only for SBPcc and WAPPcc as the result for 2WAPPcc is very similar.

Theorem 8. SBPcc(F) ≤ O(USBPcc(F) + log n) for all F.

Theorem 9. WAPPcc δ (F) ≤ O(UWAPPcc (F) + log(n/(δ − ))) for all F and all 0 < < δ < 1/2.

Hence, roughly speaking, SBPcc and USBPcc are equivalent and WAPPcc and UWAPPcc are equivalent. Here "equivalence" is ignoring constant factors and additive logarithmic terms in the cost, but much more significantly it is ignoring constant factors in (for WAPPcc), which is important as we know that cannot be efficiently amplified [\(Theorem 6\)](#page-7-2).

Discussion of [Theorem 8.](#page-7-4) The equivalence of SBPcc and USBPcc implies an alternative proof of the lower bound USBPcc(Disj) ≥ Ω(n) for set-disjointness from [\[GW16\]](#page-35-1) without using information complexity. Indeed, that paper showed that SBPcc(Disj) ≥ Ω(n) follows from Razborov's corruption lemma [\[Raz92\]](#page-37-0). It was also noted in [\[GW16\]](#page-35-1) that the greater-than function Gt (defined by Gt(x, y) := 1 iff x > y as n-bit numbers) satisfies USBPcc(Gt) = Θ(1) and SBPcc(Gt) = Θ(log n), and thus the + log n gap in [Theorem 8](#page-7-4) is tight. Our proof of [Theorem 8](#page-7-4) shows, in some concrete sense, that Gt is the "only" advantage USBPcc has over SBPcc . [Theorem 8](#page-7-4) is analogous to, but more complicated than, [Proposition 33](#page-22-3) since both say that without loss of generality α is not too small in the SBP models.

Discussion of [Theorem 9.](#page-7-3) The equivalence of WAPPcc and UWAPPcc implies the equivalence of the smooth rectangle bound (see [Fact 24](#page-19-4) below) and approximate nonnegative rank (see [Fact 27](#page-20-3) below), which was already known for total functions [\[KMSY14\]](#page-36-8). Our [Theorem 9](#page-7-3) implies that the equivalence holds even for partial functions, which was crucially used in the proof of [Corollary 7.](#page-7-1) The situation is summarized in [Figure 4.](#page-28-0)

## <span id="page-27-1"></span>6.1 The Truncation Lemma

The following lemma is a key component in the proofs of [Theorem 8](#page-7-4) and [Theorem 9.](#page-7-3)

Definition 37. For a nonnegative matrix M, we define its truncation M to be the same matrix but where each entry > 1 is replaced with 1.

<span id="page-27-2"></span>Lemma 38 (Truncation Lemma). For every 2 <sup>n</sup> × 2 <sup>n</sup> nonnegative rank-1 matrix M and every d there exists a O(d + log n)-communication public-randomness protocol Π such that for every (x, y) we have accΠ(x, y) ∈ Mx,y ± 2 −d .

```
Fact 24  \text{WAPP}^{\text{cc}} \equiv \text{srec}^1  Theorem 9, all F ||| ||| ||| || || || |
```

Figure 4: Summary of equivalences.

We describe some intuition for the proof. We can write  $M_{x,y} = u_x v_y$  where  $u_x, v_y \ge 0$ . First, note that if all entries of M are at most 1, then  $\operatorname{acc}_{\Pi}(x,y) = M_{x,y}$  can be achieved in a zero-communication manner: scaling all  $u_x$ 's by some factor and scaling all  $v_y$ 's by the inverse factor, we may assume that all  $u_x, v_y \le 1$ ; then Alice can accept with probability  $u_x$  and Bob can independently accept with probability  $v_y$ . Truncation makes all the entries at most 1 but may destroy the rank-1 property. Also note that in general, for the non-truncated entries there may be no "global scaling" for which the zero-communication approach works: there may be some entries with  $u_x v_y < 1$  but  $u_x > 1$ , and other entries with  $u_x v_y < 1$  but  $v_y > 1$ . Roughly speaking, we instead think in terms of "local scaling" that depends on (x,y).

As a starting point, consider a protocol where Alice sends  $u_x$  to Bob, who then declares acceptance with probability  $\min(u_x v_y, 1)$ . We cannot afford to communicate  $u_x$  exactly, so we settle for an approximation. We express  $u_x$  and  $v_y$  in "scientific notation" with an appropriate base and round the mantissa of  $u_x$  to have limited precision. The exponent of  $u_x$ , however, may be too expensive to communicate, but since  $u_x, v_y$  are multiplied, all that matters is the sum of their exponents. Determining the sum of the exponents exactly may be too expensive, but the crux of the argument is that we only need to consider a limited number of cases. If the sum of the exponents is small, then the matrix entry is very close to 0 and we can reject without knowing the exact sum. If the sum of the exponents is large, then the matrix entry is guaranteed to be truncated and we can accept. Provided the base is large enough, there are only a few "inbetween" cases. Determining which case holds can be reduced to a greater-than problem, which can be solved with error exponentially small in d using communication  $O(d + \log n)$ .

We now give the formal proof.

Proof of Lemma 38. Let  $M_{x,y} = u_x v_y$  where  $u_x, v_y \ge 0$ , and define  $\delta := 2^{-d}/2$  and  $B := 1/\delta$ . Henceforth we fix an input (x,y). For convenience we let all notation be relative to (x,y), so we start by defining  $u := u_x$  and  $v := v_y$ , and note that  $\overline{M}_{x,y} = \min(uv,1)$ . Assuming u > 0, define  $i := \lceil \log_B u \rceil$  (so  $u \in (B^{i-1}, B^i]$ ) and  $a := u/B^i$  (so  $a \in (\delta,1]$ ). Similarly, assuming v > 0, define  $j := \lceil \log_B v \rceil$  (so  $v \in (B^{j-1}, B^j]$ ) and  $b := v/B^j$  (so  $b \in (\delta,1]$ ). Note that  $uv = abB^{i+j} \in (B^{i+j-2}, B^{i+j}]$ . The protocol  $\Pi$  is as follows. (Line 4 is underspecified but we will address that later.)

```
    If u = 0 or v = 0 then reject
    Alice sends Bob ã ∈ a ± δ² (and ensuring ã ≤ 1) using O(d) bits
    Bob computes p := ã · b
    Determine with probability at least 1 − δ which of the following four cases holds:
    If i + j < 0 then reject</li>
    If i + j = 0 then accept with probability p
    If i + j = 1 then accept with probability min(pB, 1)
    If i + j > 1 then accept
```

We first argue correctness. Assume u, v > 0. We have  $ab \in (\tilde{a} \pm \delta^2)b \subseteq p \pm \delta^2$  (using  $b \le 1$ ) and thus  $uv \in (p \pm \delta^2)B^{i+j}$ . Pretending for the moment that line 4 succeeds with probability 1, we can verify that in all four cases the acceptance probability would be  $\in \overline{M}_{x,y} \pm \delta$ :

```
5: If i+j<0 then 0\in\overline{M}_{x,y}\pm\delta since uv\leq B^{i+j}\leq\delta.

6: If i+j=0 then p\in\overline{M}_{x,y}\pm\delta since uv\in(p\pm\delta^2)B^{i+j}\subseteq p\pm\delta.

7: If i+j=1 then \min(pB,1)\in\overline{M}_{x,y}\pm\delta since uv\in(p\pm\delta^2)B^{i+j}\subseteq pB\pm\delta.

8: If i+j>1 then 1=\overline{M}_{x,y} since uv>B^{i+j-2}\geq 1.
```

The error probability of line 4 only affects the overall acceptance probability by  $\pm \delta$ , so  $\operatorname{acc}_{\Pi}(x,y) \in \overline{M}_{x,y} \pm 2\delta \subseteq \overline{M}_{x,y} \pm 2^{-d}$ .

The communication cost is O(d) except for line 4. Line 4 can be implemented with three tests:  $i+j\geq 0,\ i+j\geq 1,\ i+j\geq 2$ , each having error probability  $\delta/3$ . These tests are implemented in the same way as each other, so we just describe how to test whether  $i+j\geq 0$ . In other words, if we let T denote the indicator matrix for  $i+j\geq 0$ , then we want to compute T with error probability  $\delta/3$  and communication  $O(d+\log n)$ . If we assume the rows are sorted in decreasing order of u and the columns are sorted in decreasing order of v, then each row and each column of T consists of 1's followed by 0's. To compute T, we may assume without loss of generality it has no duplicate rows and no duplicate columns, in which case it is a greater-than matrix (of size at most  $2^n \times 2^n$ ) with the 1's in the upper-left triangle, possibly with the all-0 row deleted and/or the all-0 column deleted. The greater-than function can be computed with any error probability  $\gamma>0$  and communication  $O(\log(n/\gamma))$  by running the standard protocol [KN97, p. 170] for  $O(\log(n/\gamma))$  many steps.

Remark 4. We note that the  $O(d + \log n)$  communication bound in Lemma 38 is optimal, assuming  $n \ge d$ . Indeed, define a nonnegative rank-1 matrix M by  $M_{x,y} := (2^{-d})^{x-y}$  where x and y are viewed as nonnegative n-bit integers. Consider any protocol  $\Pi$  with  $\operatorname{acc}_{\Pi}(x,y) \in \overline{M}_{x,y} \pm 2^{-d}$ , and note that it determines with error probability  $2^{-(d-1)}$  whether  $x \le y$ . The latter is known to require  $\Omega(\log n)$  communication (even for constant d) [Vio15]. Also, by a union bound there exists an outcome of the randomness for which  $\Pi$  determines whether  $x \le y$  for all pairs  $x, y < 2^{d/2-1}$  (of which there are  $2^{d-2}$ ), which requires  $\Omega(d)$  communication by the deterministic lower bound for greater-than on (d/2-1)-bit integers.

#### <span id="page-29-0"></span>6.2 Proofs of unrestricted–restricted equivalences

We now give the (very similar) proofs of Theorem 8 and Theorem 9 using the Truncation Lemma. We make use of the following basic fact.

<span id="page-30-0"></span>**Fact 39.** Given a private-randomness protocol  $\Pi$  of communication cost c, label the accepting transcripts as  $\tau \in \{1, 2, ..., 2^c\}$ . Then for each accepting transcript  $\tau$  there exists a nonnegative rank-1 matrix  $N^{\tau}$  such that the following holds. For each (x, y), the probability of getting transcript  $\tau$  on input (x, y) is  $N_{x,y}^{\tau}$ , and thus  $\operatorname{acc}_{\Pi}(x, y) = \sum_{\tau=1}^{2^c} N_{x,y}^{\tau}$ .

For both proofs, the goal is to show that any protocol (of type USBP<sup>cc</sup> or UWAPP<sup>cc</sup><sub> $\epsilon$ </sub>) can be converted into another protocol (of type SBP<sup>cc</sup> or WAPP<sup>cc</sup><sub> $\delta$ </sub>, respectively) of comparable cost. We transform an  $\alpha$ -correct protocol of cost c, where  $\alpha$  might be prohibitively small, into a (roughly)  $2^{-c}$ -correct protocol without increasing the communication by too much. We use Fact 39 to express the acceptance probabilities as a sum of nonnegative rank-1 matrices. The basic intuition is to divide everything by  $\alpha$  to get a "1-correct" matrix sum; however, this new sum may not correspond to acceptance probabilities of a protocol. To achieve the latter, we truncate each summand (which does not hurt the correctness, and which makes each summand correspond to acceptance probabilities from the Truncation Lemma), then multiply each summand by  $2^{-c}$  (which essentially changes the correctness parameter from 1 to  $2^{-c}$ , and which corresponds to picking a uniformly random summand).

Proof of Theorem 8. Fix a cost-c USBP<sup>cc</sup> protocol  $\Pi$  for F with associated  $\alpha > 0$  and associated matrices  $N^{\tau}$  from Fact 39. Thus  $\sum_{\tau} N_{x,y}^{\tau}$  is  $\geq \alpha$  if F(x,y) = 1 and  $\leq \alpha/2$  if F(x,y) = 0. We claim that the following public-randomness protocol  $\Pi'$  witnesses  $\mathsf{SBP}^{\mathsf{cc}}(F) \leq O(c + \log n)$ :

```
1: Pick \tau \in \{1, 2, \dots, 2^c\} uniformly at random
2: Run the protocol from Lemma 38 with M^\tau \coloneqq \frac{1}{\alpha} N^\tau and d \coloneqq c + 3
```

We first argue correctness. We have  $\operatorname{acc}_{\Pi'}(x,y) \in 2^{-c} \sum_{\tau} \left(\overline{M}_{x,y}^{\tau} \pm 2^{-d}\right) = 2^{-c} \left(\sum_{\tau} \overline{M}_{x,y}^{\tau} \pm 2^{-3}\right)$ . If F(x,y) = 0 then  $\sum_{\tau} \overline{M}_{x,y}^{\tau} \leq \sum_{\tau} \frac{1}{\alpha} N_{x,y}^{\tau} \leq 1/2$  and thus  $\operatorname{acc}_{\Pi'}(x,y) \leq (5/8)2^{-c}$ . Now suppose F(x,y) = 1. If  $M_{x,y}^{\tau} \leq 1$  for all  $\tau$  then  $\sum_{\tau} \overline{M}_{x,y}^{\tau} = \sum_{\tau} \frac{1}{\alpha} N_{x,y}^{\tau} \geq 1$ , and if not then we also have  $\sum_{\tau} \overline{M}_{x,y}^{\tau} \geq \max_{\tau} \overline{M}_{x,y}^{\tau} = 1$ . In either case,  $\operatorname{acc}_{\Pi'}(x,y) \geq (7/8)2^{-c}$ . Since there is a constant factor gap between the acceptance probabilities on 1-inputs and 0-inputs, we can use and-amplification in a standard way [GW16] to bring the gap to a factor of 2 while increasing the cost by only a constant factor. Since the communication cost of  $\Pi'$  is  $O(d + \log n) = O(c + \log n)$ , and the associated  $\alpha'$  value is  $2^{-O(c)}$ , the overall cost is  $O(c + \log n)$ .

Proof of Theorem 9. Fix a cost-c UWAPP<sup>cc</sup> protocol  $\Pi$  for F with associated  $\alpha>0$  and associated matrices  $N^{\tau}$  from Fact 39. Thus  $\sum_{\tau} N_{x,y}^{\tau}$  is  $\in [(1-\epsilon)\alpha,\alpha]$  if F(x,y)=1 and  $\in [0,\epsilon\alpha]$  if F(x,y)=0. We claim that the following public-randomness protocol  $\Pi'$  witnesses WAPP $_{\delta}^{cc}(F) \leq O(c + \log(n/\Delta))$  where  $\Delta := (\delta - \epsilon)/2$ :

```
1: Pick \tau \in \{1, 2, \dots, 2^c\} uniformly at random
2: Run the protocol from Lemma 38 with M^\tau \coloneqq \frac{1}{\alpha} N^\tau and d \coloneqq c + \lceil \log(1/\Delta) \rceil
```

We first argue correctness. We have  $\operatorname{acc}_{\Pi'}(x,y) \in 2^{-c} \sum_{\tau} \left( \overline{M}_{x,y}^{\tau} \pm 2^{-d} \right) \subseteq 2^{-c} \left( \sum_{\tau} \overline{M}_{x,y}^{\tau} \pm \Delta \right)$ . Define  $\alpha' := 2^{-c} (1 + \Delta)$ . If F(x,y) = 0 then  $\sum_{\tau} \overline{M}_{x,y}^{\tau} \le \sum_{\tau} \frac{1}{\alpha} N_{x,y}^{\tau} \le \epsilon$  and thus  $\operatorname{acc}_{\Pi'}(x,y) \in [0, 2^{-c}(\epsilon + \Delta)] \subseteq [0, \delta \alpha']$ . Now suppose F(x,y) = 1. Then  $M_{x,y}^{\tau} \le 1$  for all  $\tau$  (otherwise  $\operatorname{acc}_{\Pi}(x,y) = \sum_{\tau} \alpha M_{x,y}^{\tau} > \alpha$ ). Hence  $\sum_{\tau} \overline{M}_{x,y}^{\tau} = \sum_{\tau} \frac{1}{\alpha} N_{x,y}^{\tau} \in [1 - \epsilon, 1]$ , and thus  $\operatorname{acc}_{\Pi'}(x,y) \in [2^{-c}(1 - \epsilon - \epsilon)]$ .

$$\Delta$$
),  $2^{-c}(1+\Delta)$ ]  $\subseteq [(1-\delta)\alpha', \alpha']$ . So  $\Pi'$  is a WAPP $_{\delta}^{cc}$  protocol for  $F$  of cost  $O(d+\log n) + \log(1/\alpha') \leq O(c+\log(n/\Delta))$ .

Remark 5. In the proof of Theorem 9, note that if F is total then Lemma 38 is not needed: The entries of each  $M^{\tau}$  are all bounded by 1, and thus  $M_{x,y}^{\tau}$  can be written as  $u_x v_y$  where  $u_x, v_y \in [0, 1]$ . Hence to accept with probability  $M_{x,y}^{\tau}$ , Alice can accept with probability  $u_x$  and Bob can accept with probability  $v_y$ . This incurs no loss in the  $\epsilon$  parameter and has communication cost 2, witnessing that  $\mathsf{WAPP}_{\epsilon}^{\mathsf{cc}}(F) \leq \mathsf{UWAPP}_{\epsilon}^{\mathsf{cc}}(F) + 2$  if F is total.

## <span id="page-31-0"></span>A Appendix: Additional proofs

#### <span id="page-31-1"></span>A.1 Proof of Fact 24

 $\operatorname{\mathsf{srec}}^1_{\epsilon}(F)$  is defined as the log of the optimum value of the following linear program, which has a variable  $w_R$  for each rectangle R.

$$\begin{array}{ll} \text{minimize} & \sum_R w_R \\ \text{subject to} & \sum_{R:\, (x,y)\in R} w_R \in [1-\epsilon,1] & \forall (x,y)\in F^{-1}(1) \\ & \sum_{R:\, (x,y)\in R} w_R \in [0,\epsilon] & \forall (x,y)\in F^{-1}(0) \\ & w_R > 0 & \forall R \end{array}$$

We first show the first inequality. Given a cost-c WAPP $_{\epsilon}^{\text{cc}}$  protocol for F, put it in the "normal form" given by Fact 23 so that  $\alpha=2^{-c}$  and each outcome of the randomness is a rectangle. For each rectangle R, let  $w_R \coloneqq p_R/\alpha$  where  $p_R$  is the probability of R in the normal form protocol. This is a feasible solution with objective value  $1/\alpha$ , so  $\operatorname{srec}_{\epsilon}^1(F) \le \log(1/\alpha) = c$ . We now show the second inequality. Given an optimal solution, let  $\alpha \coloneqq 1/\sum_R w_R$  and consider a protocol that selects rectangle R with probability  $\alpha w_R$ . This is an  $\alpha$ -correct WAPP $_{\epsilon}^{\text{cc}}$  protocol for F of cost  $2 + \operatorname{srec}_{\epsilon}^1(F)$ .

#### <span id="page-31-2"></span>A.2 Proof of Fact 27

We first show the first inequality. Fix a cost-c UWAPP $_{\epsilon}^{cc}$  protocol  $\Pi$  for F with associated  $\alpha > 0$  and associated matrices  $N^{\tau}$  from Fact 39. Thus  $\sum_{\tau} N_{x,y}^{\tau}$  is  $\in [(1 - \epsilon)\alpha, \alpha]$  if F(x, y) = 1 and  $\in [0, \epsilon \alpha]$  if F(x, y) = 0. Hence letting  $M := \sum_{\tau} \frac{1}{\alpha} N^{\tau}$ , we have  $M_{x,y} \in F(x,y) \pm \epsilon$  for all  $(x,y) \in \text{dom } F$  and  $\text{rank}^+(M) \leq 2^c$ .

We now show the second inequality. Suppose M is such that  $M_{x,y} \in F(x,y) \pm \epsilon/2$  for all  $(x,y) \in \text{dom } F$  and  $r := \text{rank}^+(M)$  is witnessed by M = UV, and let t be the maximum entry in U,V. We claim that the following private-randomness protocol  $\Pi$  witnesses  $\mathsf{UWAPP}^{\mathsf{cc}}_{\epsilon}(F) \leq \lceil \log r \rceil + 2$ :

- 1: Alice picks  $i \in \{1, 2, \dots, r\}$  uniformly at random and sends it to Bob
- 2: Alice accepts with probability  $U_{x,i}/t$  and sends her decision to Bob
- 3: Bob accepts with probability  $V_{i,y}/t$  and sends his decision to Alice
- 4: Accept iff both Alice and Bob accept

We have  $\operatorname{acc}_{\Pi}(x,y) = \frac{1}{r} \sum_{i} U_{x,i} V_{i,y} / t^2 = M_{x,y} / r t^2$ . Let  $\alpha := (1 + \epsilon/2) / r t^2$ . If F(x,y) = 1 then  $\operatorname{acc}_{\Pi}(x,y) \in [(1 - \epsilon/2) / r t^2, (1 + \epsilon/2) / r t^2] \subseteq [(1 - \epsilon)\alpha, \alpha]$ . If F(x,y) = 0 then  $\operatorname{acc}_{\Pi}(x,y) \in [0, (\epsilon/2) / r t^2] \subseteq [0, \epsilon \alpha]$ . Thus the protocol is correct with respect to  $\alpha$ .

### <span id="page-32-0"></span>A.3 Proof of Fact 36

We use the notation  $(t)_m$  for the falling factorial  $t(t-1)\cdots(t-m+1)$ . The acceptance probability is

$$\frac{\binom{n-d}{w-i}}{\binom{n}{w}} = \frac{(n-d)_{w-i}}{(w-i)!} \cdot \frac{w!}{(n)_w} = \frac{(w)_i}{(n)_w / (n-d)_{w-i}}.$$

We claim that

- (i)  $w^i \cdot (1 o(1)) \le (w)_i \le w^i$ ,
- (ii)  $n^w \cdot (1 o(1)) \le (n)_w \le n^w$ ,

(iii) 
$$n^{w-i} \cdot (1 - o(1)) \le (n - d)_{w-i} \le n^{w-i}$$

Then the acceptance probability is in

$$\frac{w^{i}}{n^{w}/n^{w-i}} \cdot (1 \pm o(1)) = (w/n)^{i} \cdot (1 \pm o(1)).$$

The three upper bounds are trivial. For the lower bound in (i), we have

$$(w)_{i} = w^{i} \cdot (1 - \frac{0}{w})(1 - \frac{1}{w}) \cdots (1 - \frac{i-1}{w})$$

$$\geq w^{i} \cdot 4^{-0/w} 4^{-1/w} \cdots 4^{-(i-1)/w}$$

$$= w^{i} \cdot 4^{-i(i-1)/2w}$$

$$\geq w^{i} \cdot (1 - o(1))$$

since  $i \leq d \leq o(\sqrt{w})$ . The lower bound in (ii) follows similarly using  $w \leq o(\sqrt{n})$ . For (iii), we have

$$(n-d)_{w-i} \ge (n-d)^{w-i} \cdot (1-o(1)) = n^{w-i} \cdot (1-o(1)) \cdot (1-d/n)^{w-i}$$

as above using  $w-i \le o(\sqrt{n-d})$ , and we have  $(1-d/n)^{w-i} \ge (4^{-d/n})^w \ge 1-o(1)$  since  $d < w \le o(\sqrt{n})$ .

### <span id="page-32-1"></span>A.4 Proof of Fact 35

We first prove  $(i) \Rightarrow (ii)$ . Assume (i), and consider  $\mu_1$  distributed over  $f^{-1}(1)$  and  $\mu_0$  distributed over  $f^{-1}(0)$ . We have for  $h \sim \mathcal{H}$  and  $z_i \sim \mu_i$  that

$$\begin{split} \mathbf{E}_{\pmb{h}} \, \mathbf{Pr}_{\pmb{z_1}}[\, \pmb{h}(\pmb{z_1}) = 1 \,] &= \; \mathbf{Pr}_{\pmb{h}, \pmb{z_1}}[\, \pmb{h}(\pmb{z_1}) = 1 \,] \\ &\geq \; \min_{z_1 \in f^{-1}(1)} \mathbf{Pr}_{\pmb{h}}[\, \pmb{h}(z_1) = 1 \,] \\ &> \; 2 \cdot \max_{z_0 \in f^{-1}(0)} \mathbf{Pr}_{\pmb{h}}[\, \pmb{h}(z_0) = 1 \,] \\ &\geq \; 2 \cdot \mathbf{Pr}_{\pmb{h}, \pmb{z_0}}[\, \pmb{h}(\pmb{z_0}) = 1 \,] \\ &= \; \mathbf{E}_{\pmb{h}} \; \; 2 \cdot \mathbf{Pr}_{\pmb{z_0}}[\, \pmb{h}(\pmb{z_0}) = 1 \,]. \end{split}$$

If  $\mathbf{Pr}_{z_1}[h(z_1) = 1] \leq 2 \cdot \mathbf{Pr}_{z_0}[h(z_0) = 1]$  for all h, then the above would be false.

We now prove  $(ii) \Rightarrow (i)$ . Assume (ii), and define  $\alpha_{\mu_1,\mu_0}$  to be the maximum of  $\mathbf{Pr}_{z_1 \sim \mu_1}[h(z_1) = 1]$  over all h such that  $\mathbf{Pr}_{z_1 \sim \mu_1}[h(z_1) = 1] > 2 \cdot \mathbf{Pr}_{z_0 \sim \mu_0}[h(z_0) = 1]$ . It is not difficult to see that the function  $(\mu_1, \mu_0) \mapsto \alpha_{\mu_1, \mu_0}$  is lower semi-continuous, since if we change  $(\mu_1, \mu_0)$  infinitesimally then  $\mathbf{Pr}_{z_1 \sim \mu_1}[h(z_1) = 1] > 2 \cdot \mathbf{Pr}_{z_0 \sim \mu_0}[h(z_0) = 1]$  still holds for the (previously) optimum h, and

the left side of the inequality only changes infinitesimally (but another h may become "available" and raise the value of  $\alpha_{\mu_1,\mu_0}$ , hence the function is not upper semi-continuous). It is a basic fact of analysis that a lower semi-continuous function on a compact set attains its infimum. Since the set of  $(\mu_1, \mu_0)$  pairs is compact, and since  $\alpha_{\mu_1,\mu_0} > 0$  for all  $(\mu_1, \mu_0)$ , we have  $\inf_{\mu_1,\mu_0} \alpha_{\mu_1,\mu_0} > 0$ . Let  $\alpha^*$  be any real such that  $0 < \alpha^* < \inf_{\mu_1,\mu_0} \alpha_{\mu_1,\mu_0}$ . Hence we have  $\alpha_{\mu_1,\mu_0} > \alpha^*$  for all  $(\mu_1, \mu_0)$ .

Let M be the matrix with rows indexed by Z and columns indexed by  $\mathscr{H}$ , such that  $M_{z,h} \coloneqq h(z)$ . Then for every  $(\mu_1, \mu_0)$  there exists an h such that  $\mathbf{E}_{z_1 \sim \mu_1} M_{z_1,h} > \alpha^*$  and  $\mathbf{E}_{z_1 \sim \mu_1} M_{z_1,h} > 2 \cdot \mathbf{E}_{z_0 \sim \mu_0} M_{z_0,h}$ . Let M' be the matrix with rows indexed by Z and (infinitely-many) columns indexed by  $\mathscr{H} \times [0,1]$ , such that  $M'_{z,(h,s)} \coloneqq s \cdot h(z)$ . Then for every  $(\mu_1, \mu_0)$  there exists a (h,s) such that  $\mathbf{E}_{z_1 \sim \mu_1} M'_{z_1,(h,s)} > \alpha^*$  and  $\mathbf{E}_{z_0 \sim \mu_0} M'_{z_0,(h,s)} < \alpha^*/2$  (by choosing s to be slightly greater than  $\alpha^*/\mathbf{E}_{z_1 \sim \mu_1} M_{z_1,h}$ ). Let  $A \colon \mathbb{R} \to \mathbb{R}$  be the affine transformation  $A(x) \coloneqq (1-x) \cdot \frac{\alpha^*}{1-\alpha^*/2}$ . Let M'' be the matrix indexed like M', such that  $M''_{z,(h,s)} \coloneqq M'_{z,(h,s)}$  if f(z) = 1, and  $M''_{z,(h,s)} \coloneqq A(M'_{z,(h,s)})$  if f(z) = 0. Then for every  $(\mu_1, \mu_0)$  there exists a (h, s) such that  $\mathbf{E}_{z_1 \sim \mu_1} M''_{z_1,(h,s)} > \alpha^*$  and, by linearity of expectation,  $\mathbf{E}_{z_0 \sim \mu_0} M''_{z_0,(h,s)} = A(\mathbf{E}_{z_0 \sim \mu_0} M'_{z_0,(h,s)}) > (1-\alpha^*/2) \cdot \frac{\alpha^*}{1-\alpha^*/2} = \alpha^*$ .

We claim that for every distribution  $\mu$  over Z there exists a (h,s) such that  $\mathbf{E}_{\boldsymbol{z}\sim\mu}\,M''_{\boldsymbol{z},(h,s)}>\alpha^*$ . If  $\mu(f^{-1}(1))>0$  and  $\mu(f^{-1}(0))>0$  then this follows from the above using  $\mu_1=(\mu\mid f^{-1}(1))$  and  $\mu_0=(\mu\mid f^{-1}(0))$ . Otherwise if, say,  $\mu(f^{-1}(0))=0$  (similarly if  $\mu(f^{-1}(1))=0$ ) then we can let  $\mu_1=\mu$  and  $\mu_0$  be an arbitrary distribution over  $f^{-1}(0)$ , and apply the above.

Now by the minimax theorem (a continuous version as used in [TTV09]) the two-player zero-sum game given by M'' (with payoffs to the column player) has value  $> \alpha^*$ , and thus there exists a distribution  $\mathcal{H}'$  over  $\mathscr{H} \times [0,1]$  such that for all  $z \in Z$ ,  $\mathbf{E}_{(\mathbf{h},\mathbf{s})\sim\mathcal{H}'}M''_{z,(\mathbf{h},\mathbf{s})} > \alpha^*$ . Thus for all  $z_1 \in f^{-1}(1)$  we have  $\mathbf{E}_{(\mathbf{h},\mathbf{s})\sim\mathcal{H}'}M'_{z_1,(\mathbf{h},\mathbf{s})} > \alpha^*$ , and for all  $z_0 \in f^{-1}(0)$  by linearity of expectation we have  $\mathbf{E}_{(\mathbf{h},\mathbf{s})\sim\mathcal{H}'}M'_{z_0,(\mathbf{h},\mathbf{s})} = A^{-1}(\mathbf{E}_{(\mathbf{h},\mathbf{s})\sim\mathcal{H}'}M''_{z_0,(\mathbf{h},\mathbf{s})}) < 1 - \alpha^* \cdot \frac{1-\alpha^*/2}{\alpha^*} = \alpha^*/2$ .

For  $h \in \mathcal{H}$ , if we define  $p_h$  to be the expectation under  $\mathcal{H}'$  of the function that outputs s on inputs (h,s) and outputs 0 otherwise, then for all z we have  $\mathbf{E}_{(h,s)\sim\mathcal{H}'}M'_{z,(h,s)} = \sum_h p_h \cdot M_{z,h}$ . Finally, we define the distribution  $\mathcal{H}$  over  $\mathcal{H}$  so the probability of h is  $p_h/P$  where  $P := \sum_h p_h$ . Then for all z we have  $\mathbf{Pr}_{h\sim\mathcal{H}}[h(z)=1]=\frac{1}{P}\cdot\mathbf{E}_{(h,s)\sim\mathcal{H}'}M'_{z,(h,s)}$ . Thus for all  $z_1\in f^{-1}(1)$  we have  $\mathbf{Pr}_{h\sim\mathcal{H}}[h(z_1)=1]>\alpha^*/P$ , and for all  $z_0\in f^{-1}(0)$  we have  $\mathbf{Pr}_{h\sim\mathcal{H}}[h(z_0)=1]<\alpha^*/2P$ , and hence (i) holds.

### Acknowledgements

We thank Troy Lee and Toniann Pitassi for discussions. We are also grateful to anonymous reviewers (of both STOC and SICOMP) for thoughtful comments.

## <span id="page-33-0"></span>References

<span id="page-33-1"></span>[Aar05] Scott Aaronson. Quantum computing, postselection, and probabilistic polynomial-time. Proceedings of the Royal Society A, 461(2063):3473–3482, 2005. doi:10.1098/rspa.2005. 1546.

<span id="page-33-2"></span>[ABBD<sup>+</sup>16] Anurag Anshu, Aleksandrs Belovs, Shalev Ben-David, Mika Göös, Rahul Jain, Robin Kothari, Troy Lee, and Miklos Santha. Separations in communication complexity using

- cheat sheets and information complexity. In Proceedings of the 57th Symposium on Foundations of Computer Science (FOCS). IEEE, 2016. To appear.
- <span id="page-34-3"></span>[AC08] Anil Ada and Arkadev Chattopadhyay. Multiparty communication complexity of disjointness. Technical Report TR08-002, Electronic Colloquium on Computational Complexity (ECCC), 2008. URL: <http://eccc.hpi-web.de/report/2008/002/>.
- <span id="page-34-8"></span>[Alo03] Noga Alon. Problems and results in extremal combinatorics–I. Discrete Mathematics, 273(1–3):31–53, 2003. [doi:10.1016/S0012-365X\(03\)00227-9](http://dx.doi.org/10.1016/S0012-365X(03)00227-9).
- <span id="page-34-7"></span>[AW09] Scott Aaronson and Avi Wigderson. Algebrization: A new barrier in complexity theory. ACM Transactions on Computation Theory, 1(1), 2009. [doi:10.1145/1490270.1490272](http://dx.doi.org/10.1145/1490270.1490272).
- <span id="page-34-0"></span>[BFS86] L´aszl´o Babai, Peter Frankl, and Janos Simon. Complexity classes in communication complexity theory. In Proceedings of the 27th Symposium on Foundations of Computer Science (FOCS), pages 337–347. IEEE, 1986. [doi:10.1109/SFCS.1986.15](http://dx.doi.org/10.1109/SFCS.1986.15).
- <span id="page-34-6"></span>[BGM06] Elmar B¨ohler, Christian Glaßer, and Daniel Meister. Error-bounded probabilistic computations between MA and AM. Journal of Computer and System Sciences, 72(6):1043–1076, 2006. [doi:10.1016/j.jcss.2006.05.001](http://dx.doi.org/10.1016/j.jcss.2006.05.001).
- <span id="page-34-1"></span>[BPSW06] Paul Beame, Toniann Pitassi, Nathan Segerlind, and Avi Wigderson. A strong direct product theorem for corruption and the multiparty communication complexity of disjointness. Computational Complexity, 15(4):391–432, 2006. [doi:10.1007/s00037-007-0220-2](http://dx.doi.org/10.1007/s00037-007-0220-2).
- <span id="page-34-10"></span>[BR16] Yakov Babichenko and Aviad Rubinstein. Communication complexity of approximate Nash equilibria. Technical report, arXiv, 2016.
- <span id="page-34-9"></span>[BVdW07] Harry Buhrman, Nikolai Vereshchagin, and Ronald de Wolf. On computation and communication with small bias. In Proceedings of the 22nd Conference on Computational Complexity (CCC), pages 24–32. IEEE, 2007. [doi:10.1109/CCC.2007.18](http://dx.doi.org/10.1109/CCC.2007.18).
- <span id="page-34-11"></span>[CG88] Benny Chor and Oded Goldreich. Unbiased bits from sources of weak randomness and probabilistic communication complexity. SIAM Journal on Computing, 17(2):230–261, 1988. [doi:10.1137/0217015](http://dx.doi.org/10.1137/0217015).
- <span id="page-34-4"></span>[Cha08] Arkadev Chattopadhyay. Circuits, Communication and Polynomials. PhD thesis, McGill University, 2008.
- <span id="page-34-2"></span>[CKW12] Amit Chakrabarti, Ranganath Kondapally, and Zhenghui Wang. Information complexity versus corruption and applications to orthogonality and gap-hamming. In Proceedings of the 16th International Workshop on Randomization and Computation (RANDOM), pages 483–494. Springer, 2012. [doi:10.1007/978-3-642-32512-0](http://dx.doi.org/10.1007/978-3-642-32512-0_41) 41.
- <span id="page-34-5"></span>[CLRS13] Siu On Chan, James Lee, Prasad Raghavendra, and David Steurer. Approximate constraint satisfaction requires large LP relaxations. In Proceedings of the 54th Symposium on Foundations of Computer Science (FOCS), pages 350–359. IEEE, 2013. Latest version: [arXiv:1309.0563v3](http://arxiv.org/abs/1309.0563v3). [doi:10.1109/FOCS.2013.45](http://dx.doi.org/10.1109/FOCS.2013.45).

- <span id="page-35-8"></span>[CR12] Amit Chakrabarti and Oded Regev. An optimal lower bound on the communication complexity of gap-hamming-distance. SIAM Journal on Computing, 41(5):1299–1317, 2012. [doi:10.1137/120861072](http://dx.doi.org/10.1137/120861072).
- <span id="page-35-7"></span>[Fen03] Stephen Fenner. PP-lowness and a simple definition of AWPP. Theory of Computing Systems, 36(2):199–212, 2003. [doi:10.1007/s00224-002-1089-8](http://dx.doi.org/10.1007/s00224-002-1089-8).
- <span id="page-35-12"></span>[GJ16] Mika G¨o¨os and T.S. Jayram. A composition theorem for conical juntas. In Proceedings of the 31st Computational Complexity Conference (CCC), pages 5:1–5:16. Schloss Dagstuhl, 2016. [doi:10.4230/LIPIcs.CCC.2016.5](http://dx.doi.org/10.4230/LIPIcs.CCC.2016.5).
- <span id="page-35-11"></span>[GJPW15] Mika G¨o¨os, T.S. Jayram, Toniann Pitassi, and Thomas Watson. Randomized communication vs. partition number. Technical Report TR15-169, Electronic Colloquium on Computational Complexity (ECCC), 2015. URL: <http://eccc.hpi-web.de/report/2015/169/>.
- <span id="page-35-2"></span>[GL14] Dmitry Gavinsky and Shachar Lovett. En route to the log-rank conjecture: New reductions and equivalent formulations. In Proceedings of the 41st International Colloquium on Automata, Languages, and Programming (ICALP), pages 514–524. Springer, 2014. [doi:10.1007/978-3-662-43948-7](http://dx.doi.org/10.1007/978-3-662-43948-7_43) 43.
- <span id="page-35-0"></span>[GLM+15] Mika G¨o¨os, Shachar Lovett, Raghu Meka, Thomas Watson, and David Zuckerman. Rectangles are nonnegative juntas. In Proceedings of the 47th Symposium on Theory of Computing (STOC), pages 257–266. ACM, 2015. [doi:10.1145/2746539.2746596](http://dx.doi.org/10.1145/2746539.2746596).
- <span id="page-35-3"></span>[G¨o¨o15] Mika G¨o¨os. Lower bounds for clique vs. independent set. In Proceedings of the 56th Symposium on Foundations of Computer Science (FOCS), pages 1066–1076. IEEE, 2015. [doi:10.1109/FOCS.2015.69](http://dx.doi.org/10.1109/FOCS.2015.69).
- <span id="page-35-9"></span>[GPW15] Mika G¨o¨os, Toniann Pitassi, and Thomas Watson. Deterministic communication vs. partition number. In Proceedings of the 56th Symposium on Foundations of Computer Science (FOCS), pages 1077–1088. IEEE, 2015. [doi:10.1109/FOCS.2015.70](http://dx.doi.org/10.1109/FOCS.2015.70).
- <span id="page-35-10"></span>[GPW16a] Mika G¨o¨os, Toniann Pitassi, and Thomas Watson. The landscape of communication complexity classes. In Proceedings of the 43rd International Colloquium on Automata, Languages, and Programming (ICALP), pages 86:1–86:15. Schloss Dagstuhl, 2016. [doi:10.4230/LIPIcs.ICALP.2016.86](http://dx.doi.org/10.4230/LIPIcs.ICALP.2016.86).
- <span id="page-35-6"></span>[GPW16b] Mika G¨o¨os, Toniann Pitassi, and Thomas Watson. Zero-information protocols and unambiguity in Arthur–Merlin communication. Algorithmica, 76(3):684–719, 2016. [doi:10.1007/s00453-015-0104-9](http://dx.doi.org/10.1007/s00453-015-0104-9).
- <span id="page-35-5"></span>[GR15] Tom Gur and Ran Raz. Arthur–Merlin streaming complexity. Information and Computation, 243:145–165, 2015. [doi:10.1016/j.ic.2014.12.011](http://dx.doi.org/10.1016/j.ic.2014.12.011).
- <span id="page-35-4"></span>[GS10] Dmitry Gavinsky and Alexander Sherstov. A separation of NP and coNP in multiparty communication complexity. Theory of Computing, 6(1):227–245, 2010. [doi:10.4086/toc.](http://dx.doi.org/10.4086/toc.2010.v006a010) [2010.v006a010](http://dx.doi.org/10.4086/toc.2010.v006a010).
- <span id="page-35-1"></span>[GW16] Mika G¨o¨os and Thomas Watson. Communication complexity of set-disjointness for all probabilities. Theory of Computing, 12(9):1–23, 2016. [doi:10.4086/toc.2016.v012a009](http://dx.doi.org/10.4086/toc.2016.v012a009).

- <span id="page-36-9"></span>[HHT97] Yenjo Han, Lane Hemaspaandra, and Thomas Thierauf. Threshold computation and cryptographic security. SIAM Journal on Computing, 26(1):59–78, 1997. [doi:](http://dx.doi.org/10.1137/S0097539792240467) [10.1137/S0097539792240467](http://dx.doi.org/10.1137/S0097539792240467).
- <span id="page-36-7"></span>[HJ13] Prahladh Harsha and Rahul Jain. A strong direct product theorem for the tribes function via the smooth-rectangle bound. In Proceedings of the 33rd Conference on Foundations of Software Technology and Theoretical Computer Science (FSTTCS), pages 141–152. Schloss Dagstuhl, 2013. [doi:10.4230/LIPIcs.FSTTCS.2013.141](http://dx.doi.org/10.4230/LIPIcs.FSTTCS.2013.141).
- <span id="page-36-4"></span>[JK10] Rahul Jain and Hartmut Klauck. The partition bound for classical communication complexity and query complexity. In Proceedings of the 25th Conference on Computational Complexity (CCC), pages 247–258. IEEE, 2010. [doi:10.1109/CCC.2010.31](http://dx.doi.org/10.1109/CCC.2010.31).
- <span id="page-36-1"></span>[Juk12] Stasys Jukna. Boolean Function Complexity: Advances and Frontiers, volume 27 of Algorithms and Combinatorics. Springer, 2012.
- <span id="page-36-6"></span>[JY12] Rahul Jain and Penghui Yao. A strong direct product theorem in terms of the smooth rectangle bound. Technical report, arXiv, 2012. [arXiv:1209.0263](http://arxiv.org/abs/1209.0263).
- <span id="page-36-3"></span>[Kla03] Hartmut Klauck. Rectangle size bounds and threshold covers in communication complexity. In Proceedings of the 18th Conference on Computational Complexity (CCC), pages 118–134. IEEE, 2003. [doi:10.1109/CCC.2003.1214415](http://dx.doi.org/10.1109/CCC.2003.1214415).
- <span id="page-36-12"></span>[Kla07] Hartmut Klauck. Lower bounds for quantum communication complexity. SIAM Journal on Computing, 37(1):20–46, 2007. [doi:10.1137/S0097539702405620](http://dx.doi.org/10.1137/S0097539702405620).
- <span id="page-36-5"></span>[Kla10] Hartmut Klauck. A strong direct product theorem for disjointness. In Proceedings of the 42nd Symposium on Theory of Computing (STOC), pages 77–86. ACM, 2010. [doi:10.1145/1806689.1806702](http://dx.doi.org/10.1145/1806689.1806702).
- <span id="page-36-10"></span>[Kla11] Hartmut Klauck. On Arthur Merlin games in communication complexity. In Proceedings of the 26th Conference on Computational Complexity (CCC), pages 189–199. IEEE, 2011. [doi:10.1109/CCC.2011.33](http://dx.doi.org/10.1109/CCC.2011.33).
- <span id="page-36-2"></span>[KLL+15] Iordanis Kerenidis, Sophie Laplante, Virginie Lerays, J´er´emie Roland, and David Xiao. Lower bounds on information complexity via zero-communication protocols and applications. SIAM Journal on Computing, 44(5):1550–1572, 2015. [doi:10.1137/](http://dx.doi.org/10.1137/130928273) [130928273](http://dx.doi.org/10.1137/130928273).
- <span id="page-36-8"></span>[KMSY14] Gillat Kol, Shay Moran, Amir Shpilka, and Amir Yehudayoff. Approximate nonnegative rank is equivalent to the smooth rectangle bound. In Proceedings of the 41st International Colloquium on Automata, Languages, and Programming (ICALP), pages 701–712. Springer, 2014. [doi:10.1007/978-3-662-43948-7](http://dx.doi.org/10.1007/978-3-662-43948-7_58) 58.
- <span id="page-36-0"></span>[KN97] Eyal Kushilevitz and Noam Nisan. Communication Complexity. Cambridge University Press, 1997.
- <span id="page-36-11"></span>[LS09a] Troy Lee and Adi Shraibman. An approximation algorithm for approximation rank. In Proceedings of the 24th Conference on Computational Complexity (CCC), pages 351–357. IEEE, 2009. [doi:10.1109/CCC.2009.25](http://dx.doi.org/10.1109/CCC.2009.25).

- <span id="page-37-6"></span>[LS09b] Troy Lee and Adi Shraibman. Disjointness is hard in the multiparty number-onthe-forehead model. Computational Complexity, 18(2):309–336, 2009. [doi:10.1007/](http://dx.doi.org/10.1007/s00037-009-0276-2) [s00037-009-0276-2](http://dx.doi.org/10.1007/s00037-009-0276-2).
- <span id="page-37-13"></span>[LSS08] ˇ Troy Lee, Adi Shraibman, and Robert Spalek. A direct product theorem for discrepancy. ˇ In Proceedings of the 23rd Conference on Computational Complexity (CCC), pages 71–80. IEEE, 2008. [doi:10.1109/CCC.2008.25](http://dx.doi.org/10.1109/CCC.2008.25).
- <span id="page-37-4"></span>[LZ10] Troy Lee and Shengyu Zhang. Composition theorems in communication complexity. In Proceedings of the 37th International Colloquium on Automata, Languages, and Programming (ICALP), pages 475–489. Springer, 2010. [doi:10.1007/978-3-642-14165-2](http://dx.doi.org/10.1007/978-3-642-14165-2_41) 41.
- <span id="page-37-14"></span>[New91] Ilan Newman. Private vs. common random bits in communication complexity. Information Processing Letters, 39(2):67–71, 1991. [doi:10.1016/0020-0190\(91\)90157-D](http://dx.doi.org/10.1016/0020-0190(91)90157-D).
- <span id="page-37-11"></span>[O'D14] Ryan O'Donnell. Analysis of Boolean Functions. Cambridge University Press, 2014. URL: <http://www.analysisofbooleanfunctions.org>.
- <span id="page-37-9"></span>[PS86] Ramamohan Paturi and Janos Simon. Probabilistic communication complexity. Journal of Computer and System Sciences, 33(1):106–123, 1986. [doi:10.1016/0022-0000\(86\)90046-2](http://dx.doi.org/10.1016/0022-0000(86)90046-2).
- <span id="page-37-0"></span>[Raz92] Alexander Razborov. On the distributional complexity of disjointness. Theoretical Computer Science, 106(2):385–390, 1992. [doi:10.1016/0304-3975\(92\)90260-M](http://dx.doi.org/10.1016/0304-3975(92)90260-M).
- <span id="page-37-1"></span>[Raz03] Alexander Razborov. Quantum communication complexity of symmetric predicates. Izvestiya: Mathematics, 67(1):145–159, 2003. [doi:10.1070/IM2003v067n01ABEH000422](http://dx.doi.org/10.1070/IM2003v067n01ABEH000422).
- <span id="page-37-10"></span>[RM99] Ran Raz and Pierre McKenzie. Separation of the monotone NC hierarchy. Combinatorica, 19(3):403–435, 1999. [doi:10.1007/s004930050062](http://dx.doi.org/10.1007/s004930050062).
- <span id="page-37-8"></span>[RS04] Ran Raz and Amir Shpilka. On the power of quantum proofs. In Proceedings of the 19th Conference on Computational Complexity (CCC), pages 260–274. IEEE, 2004. [doi:10.1109/CCC.2004.1313849](http://dx.doi.org/10.1109/CCC.2004.1313849).
- <span id="page-37-5"></span>[RS10] Alexander Razborov and Alexander Sherstov. The sign-rank of AC<sup>0</sup> . SIAM Journal on Computing, 39(5):1833–1855, 2010. [doi:10.1137/080744037](http://dx.doi.org/10.1137/080744037).
- <span id="page-37-7"></span>[RY15] Anup Rao and Amir Yehudayoff. Simplified lower bounds on the multiparty communication complexity of disjointness. In Proceedings of the 30th Computational Complexity Conference (CCC), pages 88–101. Schloss Dagstuhl, 2015. [doi:10.4230/LIPIcs.CCC.2015.88](http://dx.doi.org/10.4230/LIPIcs.CCC.2015.88).
- <span id="page-37-12"></span>[Sha03] Ronen Shaltiel. Towards proving strong direct product theorems. Computational Complexity, 12(12):1–22, 2003. [doi:10.1007/s00037-003-0175-x](http://dx.doi.org/10.1007/s00037-003-0175-x).
- <span id="page-37-3"></span>[She08] Alexander Sherstov. Communication lower bounds using dual polynomials. Bulletin of the EATCS, 95:5993, 2008.
- <span id="page-37-2"></span>[She09] Alexander Sherstov. Separating AC<sup>0</sup> from depth-2 majority circuits. SIAM Journal on Computing, 38(6):2113–2129, 2009. [doi:10.1137/08071421X](http://dx.doi.org/10.1137/08071421X).

- <span id="page-38-2"></span>[She11a] Alexander Sherstov. The pattern matrix method. SIAM Journal on Computing, 40(6):1969–2000, 2011. [doi:10.1137/080733644](http://dx.doi.org/10.1137/080733644).
- <span id="page-38-4"></span>[She11b] Alexander Sherstov. The unbounded-error communication complexity of symmetric functions. Combinatorica, 31(5):583–614, 2011. [doi:10.1007/s00493-011-2580-0](http://dx.doi.org/10.1007/s00493-011-2580-0).
- <span id="page-38-1"></span>[She12a] Alexander Sherstov. The communication complexity of gap hamming distance. Theory of Computing, 8(1):197–208, 2012. [doi:10.4086/toc.2012.v008a008](http://dx.doi.org/10.4086/toc.2012.v008a008).
- <span id="page-38-5"></span>[She12b] Alexander Sherstov. The multiparty communication complexity of set disjointness. In Proceedings of the 44th Symposium on Theory of Computing (STOC), pages 525–548. ACM, 2012. [doi:10.1145/2213977.2214026](http://dx.doi.org/10.1145/2213977.2214026).
- <span id="page-38-6"></span>[She14] Alexander Sherstov. Communication lower bounds using directional derivatives. Journal of the ACM, 61(6):1–71, 2014. [doi:10.1145/2629334](http://dx.doi.org/10.1145/2629334).
- <span id="page-38-3"></span>[SZ09] Yaoyun Shi and Yufan Zhu. Quantum communication complexity of block-composed functions. Quantum Information and Computation, 9(5–6):444–460, 2009.
- <span id="page-38-12"></span>[TTV09] Luca Trevisan, Madhur Tulsiani, and Salil Vadhan. Regularity, boosting, and efficiently simulating every high-entropy distribution. In Proceedings of the 24th Conference on Computational Complexity (CCC), pages 126–136. IEEE, 2009. [doi:10.1109/CCC.2009.41](http://dx.doi.org/10.1109/CCC.2009.41).
- <span id="page-38-9"></span>[Vad12] Salil Vadhan. Pseudorandomness. Foundations and Trends in Theoretical Computer Science, 7(1–3):1–336, 2012. [doi:10.1561/0400000010](http://dx.doi.org/10.1561/0400000010).
- <span id="page-38-10"></span>[Vaz86] Umesh Vazirani. Randomness, Adversaries and Computation. PhD thesis, University of California, Berkeley, 1986.
- <span id="page-38-7"></span>[Vid13] Thomas Vidick. A concentration inequality for the overlap of a vector on a large set, with application to the communication complexity of the gap-hamming-distance problem. Chicago Journal of Theoretical Computer Science, 2013(1):1–12, 2013. [doi:](http://dx.doi.org/10.4086/cjtcs.2012.001) [10.4086/cjtcs.2012.001](http://dx.doi.org/10.4086/cjtcs.2012.001).
- <span id="page-38-11"></span>[Vio15] Emanuele Viola. The communication complexity of addition. Combinatorica, 35(6):703– 747, 2015. [doi:10.1007/s00493-014-3078-3](http://dx.doi.org/10.1007/s00493-014-3078-3).
- <span id="page-38-8"></span>[Wat16] Thomas Watson. Nonnegative rank vs. binary rank. Chicago Journal of Theoretical Computer Science, 2016(2):1–13, 2016. [doi:10.4086/cjtcs.2016.002](http://dx.doi.org/10.4086/cjtcs.2016.002).
- <span id="page-38-0"></span>[Yao83] Andrew Yao. Lower bounds by probabilistic arguments. In Proceedings of the 24th Symposium on Foundations of Computer Science (FOCS), pages 420–428. IEEE, 1983. [doi:10.1109/SFCS.1983.30](http://dx.doi.org/10.1109/SFCS.1983.30).