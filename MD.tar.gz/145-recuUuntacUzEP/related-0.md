## IDEAL FORMS OF COPPERSMITH'S THEOREM AND GURUSWAMI-SUDAN LIST DECODING

### HENRY COHN AND NADIA HENINGER

Abstract. We develop a framework for solving polynomial equations with size constraints on solutions. We obtain our results by showing how to apply a technique of Coppersmith for finding small solutions of polynomial equations modulo integers to analogous problems over polynomial rings, number fields, and function fields. This gives us a unified view of several problems arising naturally in cryptography, coding theory, and the study of lattices. We give (1) a polynomial-time algorithm for finding small solutions of polynomial equations modulo ideals over algebraic number fields, (2) a faster variant of the Guruswami-Sudan algorithm for list decoding of Reed-Solomon codes, and (3) an algorithm for list decoding of algebraic-geometric codes that handles both single-point and multi-point codes. Coppersmith's algorithm uses lattice basis reduction to find a short vector in a carefully constructed lattice; powerful analogies from algebraic number theory allow us to identify the appropriate analogue of a lattice in each application and provide efficient algorithms to find a suitably short vector, thus allowing us to give completely parallel proofs of the above theorems.

# 1. Introduction

Many important problems in areas ranging from cryptanalysis to coding theory amount to solving polynomial equations with side constraints or partial information about the solutions. One of the most important cases is solving equations given size bounds on the solutions. Coppersmith's algorithm is a celebrated technique for finding small solutions to polynomial equations modulo integers, and it has many important applications in cryptography, particularly in the cryptanalysis of the RSA cryptosystem.

In this paper, we show how the ideas of Coppersmith's theorem can be extended to a more general framework encompassing the original number-theoretic problem, list decoding of Reed-Solomon and algebraic-geometric codes, and the problem of finding solutions to polynomial equations modulo ideals in rings of algebraic integers. These seemingly different problems are all perfectly analogous when viewed from the perspective of algebraic number theory.

Coppersmith's algorithm provides a key example of the power of lattice basis reduction. To extend the method beyond the integers, we examine the analogous structures for polynomial rings, number fields, and function fields. Ideals over number fields have a natural embedding into a lattice, and thus we can find a

1

Date: June 25, 2013.

An extended abstract of this paper was published in the Proceedings of the Second Symposium on Innovations in Computer Science (Beijing, January 7–9, 2011), Tsinghua University Press, pages 298–308. N.H. was supported by an internship at Microsoft Research New England and an NSF Graduate Research Fellowship.

short vector simply by applying the LLL algorithm to this canonical embedding. In contrast to integer lattices, it turns out that lattice basis reduction is much easier over a lattice of polynomials, and in fact a shortest vector can always be found in polynomial time. Recasting the list decoding problem in this framework allows us to take advantage of very efficient reduction algorithms and thus achieve the fastest known list decoding algorithm for Reed-Solomon codes.

To extend this approach to function fields, we must overcome certain technical difficulties. Along the way, we prove a more general result about finding short vectors under arbitrary non-Archimedean norms, which may have further applications beyond list decoding of algebraic-geometric codes. As an illustration of the generality of our approach, we give the first list decoding algorithm that works for all algebraicgeometric codes, not just those defined using a single-point divisor.

In the remainder of the introduction, we set up our framework with a brief review of Coppersmith's theorem, and then state our theorems on polynomial rings, number fields, and function fields.

1.1. Coppersmith's theorem. The following extension of Coppersmith's theorem [\[15\]](#page-27-0) was developed by Howgrave-Graham [\[27\]](#page-27-1) and May [\[39\]](#page-28-0).

<span id="page-1-0"></span>Theorem 1.1 ([\[15,](#page-27-0) [27,](#page-27-1) [39\]](#page-28-0)). Let f(x) be a monic polynomial of degree d with coefficients modulo an integer N > 1, and suppose 0 < β ≤ 1. In time polynomial in log N and d, one can find all integers w such that

$$|w| \le N^{\beta^2/d}$$

and

$$\gcd(f(w), N) \ge N^{\beta}.$$

Note that when β = 1, this amounts to finding all sufficiently small solutions of f(w) ≡ 0 (mod N), and the general theorem amounts to solving f(w) ≡ 0 (mod B), where B is a large, unknown factor of N.

We give a brief example to illustrate the power of this theorem in cryptography [\[15,](#page-27-0) [27\]](#page-27-1). Imagine that an adversary has obtained through a side-channel attack some knowledge about one of the prime factors p of an RSA modulus N = pq, for example some of its most significant bits. We denote this known quantity by r. Then we may write p = r + w, where the bound on w depends on how many bits of p are known. Suppose more than half of the bits have leaked, i.e., 0 ≤ w ≤ N1/4−o(1) (we assume, as is typical, that p and q are both N<sup>1</sup>/2+o(1)). Now let f(x) = x + r and β = 1/2 + o(1). Theorem [1.1](#page-1-0) tells us that we can in polynomial time learn w, and hence p, thereby factoring N.

Further applications of this theorem in cryptography include other partial key recovery attacks against RSA [\[9,](#page-26-0) [11\]](#page-26-1), attacks on stereotyped messages and improper padding [\[15\]](#page-27-0), and the proof of security for the RSA-OAEP+ padding scheme [\[46\]](#page-28-1). See [\[40\]](#page-28-2) for many other applications.

It is remarkable that Theorem [1.1](#page-1-0) allows us to solve polynomial equations modulo N without knowing the factorization of N, and this fact is critical for the cryptanalytic applications. However, even if one already has the factorization, Theorem [1.1](#page-1-0) remains nontrivial if N has many prime factors. To solve an equation modulo a composite number, one generally solves the equation modulo each prime power factor of the modulus and uses the Chinese remainder theorem to construct solutions for the original modulus. (Recall that modulo a prime, such equations can

be solved in polynomial time, and we can use Hensel's lemma to lift the solutions to prime power moduli.) The number of possible solutions can be exponential in the number of prime factors, in which case it is infeasible to enumerate all of the roots and then select those that are within the desired range. In fact, the problem of determining whether there is a root in an arbitrary given interval is NP-complete [37]. Of course, if N has only two prime factors, then there can be only  $d^2$  solutions modulo N, but our methods are incapable of distinguishing between numbers with two or many prime factors.

It is not even obvious that the number of roots modulo N of size at most  $N^{1/d}$  is polynomially bounded in terms of the number of digits of N. From this perspective, the exponent 1/d is optimal without further assumptions, because  $f(x) = x^d$  will have exponentially many roots modulo  $N = k^d$  of absolute value at most  $N^{1/d+\varepsilon}$  (specifically, the  $2N^{\varepsilon}$  such multiples of k). Theorem 1.1 can be seen as a constructive bound on the number of solutions. See [16] for further discussion of this argument and [30] for non-constructive bounds.

1.2. **A polynomial analogue.** To introduce our analogies, we will begin with the simplest and most familiar case: polynomials.

There is an important analogy in number theory between the ring  $\mathbb{Z}$  of integers and the ring F[z] of univariate polynomials over a field F. To formulate the analogue of Coppersmith's theorem, one just needs to recognize that the degree of a polynomial is the appropriate measure of its size. Thus, the polynomial version of Coppersmith's theorem should involve finding low-degree solutions of polynomial equations over F[z] modulo a polynomial p(z). That is, given a polynomial  $f(x) = \sum_{i=0}^d f_i(z)x^i$  with coefficients  $f_i(z) \in F[z]$ , we seek low-degree polynomials  $w(z) \in F[z]$  such that  $f(w(z)) \equiv 0 \pmod{p(z)}$ .

In the following theorem, we assume that we can efficiently represent and manipulate elements of F, and that we can find roots in F[z] of polynomials over F[z]. For example, that holds if we can factor bivariate polynomials over F in polynomial time. This assumption holds for many fields, including  $\mathbb{Q}$  and even number fields [32] as well as all finite fields [23] (with a randomized algorithm in the latter case).

<span id="page-2-0"></span>**Theorem 1.2.** Let f(x) be a monic polynomial in x of degree d over F[z] with coefficients modulo p(z), where  $\deg_z p(z) = n > 0$ . In polynomial time, for  $0 < \beta \le 1$ , we can find all  $w(z) \in F[z]$  such that

$$\deg_z w(z) < \beta^2 n/d$$

and

$$\deg_z \gcd(f(w(z)), p(z)) \ge \beta n.$$

In the case when p(z) factors completely into linear factors, this theorem is equivalent to the influential Guruswami-Sudan theorem on list decoding of Reed-Solomon codes [26]. See Section 4.2 for the details of the equivalence. The above statement of Theorem 1.2, as well as the extension to higher-degree irreducible factors, appear to be new.

It has long been recognized that the Coppersmith and Guruswami-Sudan theorems are in some way analogous, although we are unaware of any previous, comparably explicit statement of the analogy. Boneh used Coppersmith's theorem in work on Chinese remainder theorem codes inspired by the Guruswami-Sudan theorem [10], and in a brief aside in the middle of [6], Bernstein noted that the Guruswami-Sudan

theorem is the polynomial analogue of a related theorem of Coppersmith, Howgrave-Graham, and Nagaraj [\[17\]](#page-27-7). Alekhnovich [\[2\]](#page-26-4) formulated the problem of list-decoding of Reed-Solomon codes in terms of finding a Gr¨obner basis for a polynomial ideal, and he gave an algorithm for finding a short vector in a polynomial lattice to do so. See also [\[25\]](#page-27-8) for a general ideal-theoretic setting for coding theory, and [\[48\]](#page-28-4) for a survey of relationships between list decoding and number-theoretic codes.

1.3. Number fields. A number field is a finite extension of the field Q of rational numbers. Thus it is natural to investigate how a statement over the rationals, the simplest number field, extends to more general number fields. We extend our analogy by adapting Coppersmith's theorem to the number field case.

Every number field K is of the form

$$K = \mathbb{Q}(\alpha) = \{a_0 + a_1 \alpha + \dots + a_{n-1} \alpha^{n-1} : a_0, \dots, a_{n-1} \in \mathbb{Q}\},\$$

where α is an algebraic number of degree n (i.e., a root of an irreducible polynomial of degree n over Q). The degree of K is defined to be n. Within K, there is a ring O<sup>K</sup> called the ring of algebraic integers in K. It plays the same role within the field K as the ring Z of integers plays within Q. Sometimes O<sup>K</sup> is of the form Z[α], but sometimes it does not even have a single generator.

Recall that an ideal in a ring is a non-empty subset closed under addition and under multiplication by arbitrary elements of the ring. (Intuitively, it is a subset modulo which one can reduce elements of the ring.) For example, the multiples of any fixed element form an ideal, called a principal ideal. In Z every ideal is of that form, but that is not usually true in OK.

In OK, we study the solutions of polynomial equations modulo ideals, the analogue of such equations modulo integers in Z. To measure the size of a nonzero ideal I in OK, we will use its norm N(I) = |OK/I|, i.e., the size of the quotient ring.

A final conceptual issue that makes this case more subtle is that a number field of degree n has n absolute values | · |<sup>i</sup> corresponding to its n embeddings into C (as we will explain in Section [5\)](#page-14-0), and to obtain the theorem it is necessary to bound them all simultaneously.

The number field analogue of Coppersmith's theorem is as follows:

<span id="page-3-0"></span>Theorem 1.3. Let K be a number field of degree n with ring of integers OK, f(x) ∈ OK[x] a monic polynomial of degree d, and I ( O<sup>K</sup> an ideal in OK. Assume that we are given O<sup>K</sup> and I explicitly by integral bases. For 0 < β ≤ 1 and λ1, . . . , λ<sup>n</sup> > 0, in time polynomial in the input length and exponential in n <sup>2</sup> we can find all w ∈ O<sup>K</sup> with |w|<sup>i</sup> < λ<sup>i</sup> such that

$$N(\gcd(f(w)\mathcal{O}_K, I)) > N(I)^{\beta},$$

provided that

$$\prod_{i} \lambda_i < N(I)^{\beta^2/d}.$$

Furthermore, in polynomial time we can find all such w provided that

$$\prod_{i} \lambda_{i} < (2 + o(1))^{-n^{2}/2} N(I)^{\beta^{2}/d}.$$

Equivalently, we can find small solutions of equations f(x) ≡ 0 (mod J), where the ideal J is a large divisor of I. Using improved lattice basis reduction algorithms [\[3\]](#page-26-5) we can achieve a running time that is slightly subexponential in n 2 . Note also that  $gcd(f(w)\mathcal{O}_K, I)$  is the largest ideal that contains both the principal ideal  $f(w)\mathcal{O}_K$  and I; in other words, it is their sum  $f(w)\mathcal{O}_K + I$ .

When n is fixed, our algorithm runs in polynomial time, but the dependence on n is exponential. That appears to be unavoidable using our techniques, but it is not a serious drawback. Many number-theoretic algorithms behave poorly for high-degree number fields, and most computations are therefore done in low-degree cases. Even for a fixed number field K, Theorem 1.3 remains of interest.

Similar ideas to Theorem 1.3 were developed independently by Coxon for list decoding of number field codes [18]. His algorithm is more flexible than our theorem in allowing weighted list decoding, but he does not develop an analogue of Coppersmith's theorem. Similar results were also achieved by Biasse and Quintin [7].

Several problems over number fields have been proposed as the basis for cryptosystems; see, for example, [12] for a survey of problems over quadratic number fields. More recently, Peikert and Rosen [42] and Lyubashevsky, Peikert, and Regev [36] developed lattice-based cryptographic schemes using lattices representing the canonical embeddings of ideals in number fields. As a special case, Theorem 1.3 can be used to solve certain cases of the bounded-distance decoding problem for such lattices, and improving our approximation factor from  $(2 + o(1))^{-n^2/2}$  to  $2^{-n}\sqrt{|\Delta_K|}$ , where  $\Delta_K$  is the discriminant of K, would solve the problem in general; see Section 5.3 for more details.

In addition, number fields have many applications to purely classical problems, the most prominent example being the number field sieve factoring algorithm. All sieve algorithms require generating smooth numbers, and in this context Boneh [10] showed how to use Coppersmith's theorem to find smooth integer solutions of polynomials in short intervals. Using Theorem 1.3 analogously, one can do the same over number fields.

We prove Theorem 1.3 in Section 5.

<span id="page-4-1"></span>1.4. Function fields. Algebraic number theorists have developed a more sophisticated version of the analogy between the ring of integers and polynomial rings. In this analogy, the analogues of number fields are called function fields; they are the fields of rational functions on algebraic curves over finite fields. The parallels between number fields and function fields are truly astonishing, and this analogy has played a crucial role in the development of number theory over the last century.

We now complete our analogy in this paper by extending Coppersmith's theorem to the function field case. See Section 6 for a detailed review of the setting and notation.

<span id="page-4-0"></span>**Theorem 1.4.** Let  $\mathcal{X}$  be a smooth, projective, absolutely irreducible algebraic curve over  $\mathbb{F}_q$ , and let K be its function field over  $\mathbb{F}_q$ . Let D be a divisor on  $\mathcal{X}$  whose support  $\operatorname{supp}(D)$  is contained in the  $\mathbb{F}_q$ -rational points  $\mathcal{X}(\mathbb{F}_q)$ , let S be a subset of  $\mathcal{X}(\mathbb{F}_q)$  that properly contains  $\operatorname{supp}(D)$ , let  $\mathcal{O}_S$  be the subring of K consisting of functions with poles only in S, and let  $\mathcal{L}(D)$  be the Riemann-Roch space

$$\mathcal{L}(D) = \{0\} \cup \{f \in K^* : (f) + D \succeq 0\}.$$

Let  $f(x) \in \mathcal{O}_S[x]$  be a monic polynomial of degree d, and let I be a proper ideal in  $\mathcal{O}_S$ .

Then in probabilistic polynomial time, we can find all  $w \in \mathcal{L}(D)$  such that

$$N(\gcd(f(w)\mathcal{O}_S, I)) > N(I)^{\beta},$$

provided that

$$q^{\deg(D)} < N(I)^{\beta^2/d}.$$

In the case when S contains only a single point, the function field version of Coppersmith's theorem is equivalent to the Guruswami-Sudan theorem on list-decoding of algebraic-geometric codes, as we will outline in Section 6. The Guruswami-Sudan theorem and the earlier Shokrollahi-Wasserman theorem [45] are specialized to that case, which covers many but not all algebraic-geometric codes. Our theorem extends list decoding to the full range of such codes.

We assume that we can efficiently compute bases of Riemann-Roch spaces for divisors in  $\mathcal{X}$ . That can be done in many important cases (for example, for a smooth plane curve, or even one with ordinary multiple points [28]), and it is a reasonable assumption because even the encoding problem for algebraic-geometric codes requires a basis of a Riemann-Roch space. Note also that although our algorithm is probabilistic, it is guaranteed to give the correct solution in expected polynomial time; in other words, it is a "Las Vegas" algorithm.

Alekhnovich's polynomial module approach to list decoding has been adapted to a special class of algebraic-geometric codes by Beelen and Brander [5]. Their work is thus closer in spirit to ours than the Guruswami-Sudan and Shokrollahi-Wasserman papers are, but they focus on the process of interpolation and view modules as a means to compute interpolating polynomials.

We prove Theorem 1.4 in Section 6.

1.5. **Analogies in number theory.** The connections we have described are not isolated phenomena. Many theorems in number theory and algebraic geometry have parallel versions for the integers and for polynomial rings, or more generally for number fields and function fields, and translating statements or techniques between these settings can lead to valuable insights.

One particular advantage of this sort of arbitrage is that proving results for polynomial rings is usually easier. For example, the prime number theorem for  $\mathbb{Z}$  is a deep theorem, but the analogue for the polynomial ring  $\mathbb{F}_q[z]$  over a finite field is much simpler. It says that asymptotically a 1/n fraction of the  $q^n$  monic polynomials of degree n are irreducible, and in fact the error term is on the order of  $q^{n/2}$  (see Lemma 14.38 in [22]). Proving a similarly strong version of the prime number theorem for  $\mathbb{Z}$  would amount to proving the Riemann hypothesis. Similarly, the ABC conjecture for  $\mathbb{Z}$  is a profound unsolved problem, while for polynomials rings it has an elementary proof [38].

Thus, polynomial rings are worlds in which many of the fondest dreams of mathematicians have come true. If a result cannot be proved in such a setting, then it is probably not even worth trying to prove it in  $\mathbb{Z}$ . If it can be proved for polynomial rings, then the techniques may not apply to the integers, but they often provide inspiration for how a proof might work if technical obstacles can be overcome.

Similarly, in computer science many computational problems that appear to be difficult for integers are tractable for polynomials. For example, factoring polynomials can be done in polynomial time for many fields, while for integers the problem seems to be hard. The polynomial analogue of the shortest vector problem for lattices can be solved exactly in polynomial time [21], while for integer lattices

the problem is NP-hard [1]. This difference in the difficulty of lattice problems is at the root of the poor running time in Theorem 1.3 for number fields of high degree.

The analogies that we develop here between cryptanalysis and coding theory extend further. For example, multivariate versions of Coppersmith's theorem correspond to list decoding of Parvaresh-Vardy and Guruswami-Rudra codes [14].

#### 2. Preliminaries

One of the main steps in Coppersmith's theorem uses lattice basis reduction to find a short vector in a lattice. In this section, we review preliminaries on integral lattices and introduce the analogues that we will use in our generalizations.

2.1. **Integer lattices.** Recall that a *lattice* in  $\mathbb{R}^m$  is a discrete subgroup of rank m. Equivalently, it is the set of integer linear combinations of a basis of  $\mathbb{R}^m$ .

The determinant det(L) of a lattice L is the absolute value of the determinant of any basis matrix; it is not difficult to show that it is independent of the choice of basis. One way to see why is that the determinant is the volume of the quotient  $\mathbb{R}^m/L$ , or equivalently the volume of a fundamental parallelotope.

One of the fundamental problems in lattice theory is finding short vectors in lattices, with respect to the  $\ell_p$  norm

$$|v|_p = \left(\sum_{i=1}^m |v_i|^p\right)^{1/p}.$$

Most often we use the  $\ell_2$  norm, which is of course the usual Euclidean distance. The LLL lattice basis reduction algorithm [34] can be used to find a short vector in a lattice.

**Theorem 2.1** ([34]). Given a basis of a lattice L in  $\mathbb{Q}^m$ , a nonzero vector  $v \in L$  satisfying

$$|v|_2 \le 2^{(m-1)/4} \det(L)^{1/m}$$

can be found in polynomial time.

Note that the LLL algorithm's input is a rational lattice, and the rationality plays an important role in the running time analysis. In the proof of Theorem 1.3, we must apply it to a lattice whose basis vectors are not in  $\mathbb{Q}^m$ ; however, for our purposes using a close rational approximation suffices. Specifically, we simply approximate the given basis  $b_1, \ldots, b_m$  with rational vectors  $b'_1, \ldots, b'_m$ . It is easy to check that using a polynomial number of digits suffices to approximate the determinant. (The number of digits depends polynomially on the dimension m and the logarithmic sizes of the entries in the basis vectors.) Then we find a short vector  $\sum c_i b'_i$  with  $c_i \in \mathbb{Z}$ , where the coefficients  $c_i$  have only polynomially many digits because they are the output of the polynomial-time algorithm LLL algorithm. If  $b'_i$  approximates  $b_i$  to enough digits, then  $\sum c_i b_i$  will have essentially the same length, and again a polynomial number of digits suffices. Strictly speaking, this process makes the approximation factor slightly worse, but the difference is insignificant, and we could use a better version of the LLL algorithm to achieve the same  $2^{(m-1)/4}$  as in the theorem statement.

<span id="page-7-2"></span>2.2. Polynomial lattices. A lattice is a module over the ring Z of integers. In other words, not only is it an abelian group under addition, but we can also multiply lattice vectors by integers and thus take arbitrary integer combinations of them. More generally, a module for a ring R is an abelian group in which we can multiply by elements of R (in a way that satisfies the associative and distributive laws). In other words, an R-module is exactly like an R-vector space, except that R is not required to be a field, as it is in the definition of a vector space.

The module R<sup>m</sup> with componentwise scalar multiplication is called a free Rmodule of rank m. Every lattice is a free Z-module, and free R-modules will be the analogous structure for the ring R.

For example, if R is the polynomial ring F[z] over a field F, then we define a polynomial lattice to be a free module over F[z] of finite rank. A polynomial lattice will usually be generated by a basis of vectors whose coefficients are polynomials in z. Vectors in our polynomial lattice will be linear combinations of the basis vectors (where the coefficients are also polynomials in z).

An appropriate definition of the length (i.e., degree) of such a lattice vector is the maximum degree of its coordinates:

<span id="page-7-0"></span>(2.1) 
$$\deg_z(v_1(z), v_2(z), \dots, v_m(z)) = \max_i \deg_z v_i(z).$$

This defines a non-Archimedean norm. In fact, for lattices with a norm defined as above, it is possible to find the exact shortest vector in polynomial time (see, for example, [\[21\]](#page-27-13)).

Lattices of polynomials have been well studied because of their applications to the study of linear systems [\[29\]](#page-27-16). There are several notions of basis reduction for such lattices. A basis is column-reduced (or, as appropriate, row-reduced) if the degree of the determinant of the lattice (i.e., of a basis matrix) is equal to the sum of the degrees of its basis vectors. Such bases always contain a minimal vector for the lattice, and m-dimensional column reduction can be carried out in mω+o(1)D field operations [\[24\]](#page-27-17), where ω is the exponent of matrix multiplication and D is the greatest degree occurring in the original basis of the lattice.

In particular, for an m-dimensional lattice L with the norm [\(2.1\)](#page-7-0), the above algorithms are guaranteed to find a nonzero vector v for which

<span id="page-7-1"></span>(2.2) 
$$\deg v \le \frac{1}{m} \deg \det L,$$

where det L denotes the determinant of a lattice basis.

<span id="page-7-3"></span>2.3. Finding short vectors under general non-Archimedean norms. The above algorithms are specialized to norms defined by [\(2.1\)](#page-7-0), but there are other non-Archimedean norms, and we will need to use them in the proof of Theorem [1.4](#page-4-0) in the function field setting. In fact, we will show that for all non-Archimedean norms, one can find a vector satisfying the equivalent of [\(2.2\)](#page-7-1) in a lattice by solving a system of linear equations. Solving this system may be less efficient than a specialized algorithm, but it allows us to give a general approach that will work in polynomial time for any norm.

Let R = F[z] be a polynomial ring over a field F, and for r ∈ R define

$$|r| = C^{\deg_z(r)}$$

for some arbitrary constant C > 1; we take |0| = 0 as a special case. Note that |z| = C, and thus we can write |r| = |z| deg<sup>z</sup> (r) .

Suppose we have any norm  $|\cdot|$  on  $\mathbb{R}^m$  that satisfies the following three properties:

- (1) For all  $v \in \mathbb{R}^m$ ,  $|v| \ge 0$ , and |v| = 0 if and only if v = 0.
- (2) For all  $v, w \in R^m$ ,  $|v + w| \le \max(|v|, |w|)$ .
- (3) For all  $v \in \mathbb{R}^m$  and  $r \in \mathbb{R}$ , |rv| = |r||v|.

Note that taking

$$|(v_1(z), v_2(z), \dots, v_m(z))| = C^{\max_i \deg_z v_i(z)}$$

defines such a norm, but the extra generality will prove useful in Section 6.

Let  $M \subseteq \mathbb{R}^m$  be a submodule of rank m (so the quotient F-vector space  $\mathbb{R}^m/M$  is finite-dimensional), and let  $d = \dim_F(\mathbb{R}^m/M)$ .

<span id="page-8-0"></span>**Lemma 2.2.** For any R-basis  $b_1, \ldots, b_m$  of  $R^m$ , there exists a nonzero vector  $v \in M$  such that

$$|v| \leq \sqrt[m]{|b_1| \dots |b_m|} |z|^{d/m}$$
.

*Proof.* We will construct a nonzero vector satisfying  $|v| \leq q^c$  for some constant c to be determined, and then we will optimize the choice of c. Let  $|b_i| = |z|^{n_i}$ , and consider the space of polynomials

$$V = \left\{ \sum_{i} r_i b_i : r_i \in R \text{ and } \deg_z r_i \le c - n_i \right\}.$$

Every  $v \in V$  satisfies  $|v| \leq |z|^c$ , and V is an F-vector space. To compute its dimension, note that  $r_i$  is determined by  $\lfloor c - n_i \rfloor + 1 > c - n_i$  coefficients. Because  $b_1, \ldots, b_m$  is an R-basis,  $\dim_F V > mc - \sum_i n_i$ .

If we take  $c = (d + \sum_i n_i)/m$ , then  $\dim_F V > d$ . Thus, there exists a nonzero element v of V that maps to zero in the d-dimensional quotient space  $R^m/M$  and hence lies in M. It satisfies

$$|v| \le q^c = \sqrt[m]{|b_1| \dots |b_m|} |z|^{d/m},$$

as desired.

<span id="page-8-1"></span>Lemma 2.3. Under the hypothesis of Lemma 2.2, a vector satisfying

$$|v| \le \sqrt[m]{|b_1| \dots |b_m|} |z|^{d/m}$$

can be found in polynomial time (given an R-basis of M).

Proof. In the notation of the proof of Lemma 2.2, we will show that we can find small coefficients  $r_1, \ldots, r_m \in R$  (not all zero) such that  $\sum_i r_i b_i$  is in M. Suppose  $w_1, \ldots, w_m$  is an R-basis of M. Then the elements of M are those that can be written as  $\sum s_i w_i$  with  $s_i \in R$ . Given a polynomial bound for the degrees of  $s_1, \ldots, s_m$ , we could determine the coefficients  $r_i$  and  $s_i$  by solving linear equations over F for their coefficients. To specify these equations, we write  $w_1, \ldots, w_m$  as R-linear combinations of  $b_1, \ldots, b_m$ . Define the matrix W over R by  $w_j = \sum_i W_{ij} b_i$  for each j. Then

$$\sum_{i} r_i b_i = \sum_{j} s_j w_j$$

amounts to r = Ws, where s and r are the column vectors with entries  $s_i$  and  $r_i$ , respectively.

Thus, s determines r in a simple way, and all we need is to choose  $s_1, \ldots, s_m$  so that setting r = Ws yields  $\deg_z r_i \le c - n_i$ , with c and  $n_i$  defined as in the proof of

Lemma [2.2.](#page-8-0) It is not difficult to bound the degrees of the polynomials s<sup>i</sup> as follows. Let <sup>W</sup><sup>f</sup> be the adjoint matrix of <sup>W</sup> (so WW<sup>f</sup> = det(W)I). Then

$$\widetilde{W}r = \det(W)s.$$

It follows that for each i,

$$\deg_z \det(W) + \deg_z s_i \le \max_j \left( \deg_z \widetilde{W}_{ij} + \deg_z r_j \right).$$

However, the entries <sup>W</sup>fij of <sup>W</sup><sup>f</sup> have degree bounded by <sup>m</sup> <sup>−</sup> 1 times the maximum degree of an entry of W (because they are given by determinants of (m−1)×(m−1) submatrices of W). Thus, deg<sup>z</sup> si is polynomially bounded, and we can locate a suitable vector v by solving a system of polynomially many linear equations over F.

Note that for a rank m submodule M of R<sup>m</sup>, the degree of the determinant of a basis matrix B for M is the dimension of the quotient Rm/M. Thus, in Lemma [2.2,](#page-8-0) if |b1| = · · · = |bm| = 1, then the norm of a minimal vector is bounded by | det(B)| <sup>1</sup>/m. The exponential approximation factor that occurs in LLL lattice basis reduction does not occur here.

# 3. Coppersmith's theorem

<span id="page-9-3"></span>We now review how Coppersmith's method works over the integers, as this provides a template for the techniques we will apply later. We will follow the exposition of May [\[40\]](#page-28-2).

Let f(x) be a monic univariate polynomial of degree d, and N an integer of potentially unknown factorization. We wish to find all small integers w such that gcd(f(w), N) is large.

To do so, we will choose some positive integer k (to be determined later) and look at integer combinations of the polynomials x <sup>j</sup>f(x) <sup>i</sup>Nk−<sup>i</sup> . If B divides both N and f(w), then B<sup>k</sup> will divide w <sup>j</sup>f(w) <sup>i</sup>Nk−<sup>i</sup> and thus also any linear combination of such polynomials.

Let

<span id="page-9-2"></span><span id="page-9-1"></span>
$$Q(x) = \sum_{i,j} a_{i,j} x^j f(x)^i N^{k-i} = \sum_i q_i x^i,$$

for some coefficients ai,j and q<sup>i</sup> to be determined. We will choose Q so that the small solutions to our original congruence become actual solutions of Q(x) = 0 in the integers. This will allow us to find w by factoring Q(x) over the rationals. The construction of Q tells us that

$$(3.1) Q(w) \equiv 0 \pmod{B^k}.$$

If in addition we have a lower bound N<sup>β</sup> on the size of B, and we can show that

$$(3.2) |Q(w)| < N^{\beta k} \le B^k,$$

then Q(w) = 0 and we may find w by factoring Q. In fact, this observation tells us that we can find all such w in this way. A similar observation will appear in all of our proofs.

In the case of the integers, we introduce the bound |w| < X on our roots, and the triangle inequality tells us that

<span id="page-9-0"></span>
$$(3.3) |Q(w)| \le \sum_{i} |q_i| X^i.$$

To finish the theorem, we will show that if X is sufficiently small, then we can choose Q so that its coefficients  $q_i$  satisfy

$$(3.4) \sum_{i} |q_i| X^i < N^{\beta k}.$$

We are now ready to prove Coppersmith's theorem for the integers.

Proof of Theorem 1.1. Having outlined the general technique above, it remains to be shown that we can construct a polynomial Q(x) whose coefficients satisfy the bound in (3.4).

The polynomial Q(x) will be a linear combination of the polynomials

<span id="page-10-0"></span>
$$x^{j} f(x)^{i} N^{k-i}$$
 for  $0 \le i < k$  and  $0 \le j < d$ 

and

$$x^j f(x)^k$$
 for  $0 \le j < t$ .

The right-hand side of (3.3) is the  $\ell_1$  norm of the vector of coefficients of the polynomial Q(xX), which in turn will be a linear combination of the polynomials  $(xX)^j f(xX)^i N^{k-i}$ . Finding our desired Q(x) is thus equivalent to finding a suitably short vector in the lattice L spanned by the coefficient vectors of the polynomials  $(xX)^j f(xX)^i N^{k-i}$ . Once we find this short vector, we can divide each coefficient by the power of X introduced in the normalization to find the coefficients of Q, and test each of the roots of Q to see if it is a solution.

To compute the determinant of this lattice, we can order the basis vectors by the degrees of the polynomials they represent to obtain an upper triangular matrix whose determinant is the product of the terms on the diagonal:

$$\det(L) = \prod_{0 \leq i < dk+t} X^i \prod_{0 \leq j \leq k} N^{dj} = X^{(dk+t-1)(dk+t)/2} N^{dk(k+1)/2}.$$

Set m = dk + t. We can use the LLL algorithm [34] to find a vector v whose  $\ell_2$  norm is bounded by

$$|v|_2 \le 2^{(m-1)/4} \det(L)^{1/m}$$
.

By the Cauchy-Schwarz inequality,  $|v|_1 \leq \sqrt{m} |v|_2$ , and hence whenever |w| < X,

$$|Q(w)| \le \sqrt{m} 2^{(m-1)/4} \det(L)^{1/m}$$
.

We assume  $m \geq 7$ , and use the weaker bound

$$|Q(w)| \le 2^{(m-1)/2} \det(L)^{1/m}$$
.

To prove inequality (3.2), we must show that

<span id="page-10-1"></span>
$$2^{(m-1)/2} \left( X^{m(m-1)/2} N^{dk(k+1)/2} \right)^{1/m} < N^{\beta k}.$$

This inequality is equivalent to

$$(3.5) (2X)^{(m-1)/(2k)} N^{d(k+1)/(2m)} < N^{\beta}.$$

Applying Lemma 3.1 below with  $\ell = \log_2 2X$  and  $n = \log_2 N$ , we obtain parameters k and t such that (3.5) holds for

$$2X < N^{\beta^2/d-\varepsilon}$$
.

To eliminate  $\varepsilon$  from the statement of the theorem, take  $\varepsilon < \frac{1}{\log_2 N}$ . Then it suffices to take  $X \leq \frac{1}{4} N^{\beta^2/d}$ . We can divide the interval [-4X, 4X] into four intervals of width 2X and solve the problem for each interval by finding solutions for the

polynomials f(x-3X), f(x-X), f(x+X), and f(x+3X). Thus, we achieve a bound of  $N^{\beta^2/d}$ , as desired.

We end with a brief lemma that will tell us how to optimize our parameters in equation (3.5).

<span id="page-11-0"></span>**Lemma 3.1.** The inequality 
$$\ell \frac{m-1}{2k} + nd \frac{k+1}{2m} < n\beta$$
 is satisfied when  $\ell < n\left(\frac{\beta^2}{d} - \varepsilon\right)$ ,  $m \ge \max\left(\frac{2\beta}{\varepsilon}, \frac{2d}{\beta}\right)$ , and  $k = \left\lfloor \frac{\beta m}{d} - 1 \right\rfloor$ .

Note that for the application above, we must have  $k \geq 1$  and  $t = m - dk \geq 0$ . The hypotheses of the lemma achieve this. Furthermore, we want m and k to be polynomially bounded. Without loss of generality, we can assume that  $N^{\beta^2/d} \geq 2$ , and hence  $\beta^2 \geq d/n$ . Thus, as long as  $\varepsilon$  is not too small, m and k need not be too large.

Lemma 3.1 amounts to optimizing how large  $\ell$  can be. As intuition, note that if we set the two terms  $\ell \frac{m-1}{2k}$  and  $nd\frac{k+1}{2m}$  roughly equal to  $\frac{n\beta}{2}$ , then we have  $\ell m^2 \approx ndk^2 \approx n\beta mk$  and hence  $\ell \approx n\beta^2/d$ . The proof amounts to making this precise.

*Proof.* It suffices to show that these values of m and k satisfy  $n\left(\frac{\beta^2}{d} - \varepsilon\right) \frac{m-1}{2k} < \frac{n\beta}{2}$  and  $nd\frac{k+1}{2m} \leq \frac{n\beta}{2}$ .

The first inequality is equivalent to  $\frac{k}{m-1} > \frac{\beta}{d} - \frac{\varepsilon}{\beta}$ . Similarly, the second is equivalent to  $\frac{k+1}{m} \leq \frac{\beta}{d}$ . If we set  $k = \left\lfloor \frac{\beta m}{d} - 1 \right\rfloor$ , then  $\frac{k+1}{m} \leq \frac{\beta}{d}$ , so the second inequality is satisfied. If in addition we take  $m \geq \frac{2\beta}{\varepsilon}$ , then  $\frac{\varepsilon m}{\beta} \geq 2$  and hence  $k > \frac{\beta m}{d} - 2 \geq \frac{\beta m}{d} - \frac{\varepsilon m}{\beta}$ . It follows that  $k \frac{m}{m-1} > \frac{\beta m}{d} - \frac{\varepsilon m}{\beta}$ , which is equivalent to the first inequality.

Note that improving the approximation factor for the length of the short lattice vector that we find will only improve the constants and running time of the theorem, and will not provide an asymptotic improvement to the bound  $N^{\beta^2/d}$  on |w|.

### 4. Polynomials and Reed-Solomon list decoding

<span id="page-11-1"></span>In this section, we prove Theorem 1.2 using an approach analogous to that of the previous section. Guruswami and Sudan's technique for list decoding of Reed-Solomon codes [26] is similar in that it involves constructing a bivariate polynomial that vanishes to high order at particular points. To construct such a polynomial, they write each vanishing condition as a set of linear equations on the coefficients of the polynomial under construction. The linear equations can be solved to obtain the desired polynomial, and the polynomial factored to obtain its roots.

Similarly, the polynomials used in Coppersmith's method are constructed so as to vanish to high order, the condition ensured by equation (3.1). The conceptual difference is that this condition follows from the form of the lattice basis, rather than being imposed as linear constraints. With the right definition of lattice basis reduction in the polynomial setting, we can emulate the proof from the integer case.

We regard f(x) as a polynomial in x with coefficients that are polynomials in the variable z. To prove Theorem 1.2, we would like to construct a polynomial Q(x) over F[z] from the polynomials  $x^j f(x)^i p(z)^{k-i}$ . If b(z) divides both p(z) and f(w(z)),

then b(z) <sup>k</sup> divides w(z) <sup>j</sup>f(w(z))<sup>i</sup>p(z) <sup>k</sup>−<sup>i</sup> and thus also any linear combination of such polynomials.

Instead of an integer combination of these polynomials, we will allow coefficients that are polynomials in z. Let

$$Q(x) = \sum_{i,j} a_{i,j}(z) x^{j} f(x)^{i} p(z)^{k-i} = \sum_{i} q_{i}(z) x^{i}.$$

If we have an upper bound ` on the degree of our root w(z), then the degree of Q(w(z)) will be bounded by

$$\deg_z Q(w(z)) \le \max_i (\deg_z q_i(z) + \ell i).$$

If similarly we have a lower bound nβ on the degree of b(z), then if we know that both

<span id="page-12-0"></span>
$$Q(w(z)) \equiv 0 \pmod{b(z)^k}$$

and

(4.1) 
$$\deg_z Q(w(z)) < n\beta k \le k \deg_z b(z),$$

then we may conclude that

$$Q(w(z)) = 0.$$

4.1. Proof of Theorem [1.2.](#page-2-0) We will show how finding a short vector in a lattice of polynomials will allow us to construct a polynomial Q(x) satisfying [\(4.1\)](#page-12-0).

Let ` be the upper bound on the degree of the roots w(z) we would like to find. Using the same idea to bound the length of the vector as in the integer case, we will form a lattice of the coefficient vectors of

$$(z^{\ell}x)^{j}f(z^{\ell}x)^{i}p(z)^{k-i}$$
 for  $0 \le j < d$  and  $0 \le i < k$ 

and

$$(z^{\ell}x)^j f(z^{\ell}x)^k$$
 for  $0 \le j < t$ .

As always, we view them as polynomials in powers of x with coefficients that are polynomials in z. Once we find this short vector, we can divide each coefficient by the power of z ` introduced in the normalization to find the coefficients of Q, and test each of the roots of Q to see if it is a solution.

Let M be the F[z]-module spanned by the coefficient vectors of these polynomials, with the degree of a vector defined by [\(2.1\)](#page-7-0).

The matrix of coefficient vectors of the basis is upper triangular, so its determinant is the product of the diagonal entries. Set m = kd + t. Then

$$\deg \det M = \ell \sum_{i=0}^{m-1} i + nd \sum_{i=0}^{k} i$$
$$= \ell \frac{m(m-1)}{2} + nd \frac{k(k+1)}{2}.$$

Since the dimension of our lattice is m, by Theorem [2.3](#page-8-1) we can find a vector of degree at most

$$\frac{1}{m}\left(\ell\frac{m(m-1)}{2} + nd\frac{k(k+1)}{2}\right).$$

To prove (4.1), we would like this bound to be less than  $\beta kn$ . By Lemma 3.1, we can achieve any  $\ell \leq n \left(\frac{\beta^2}{d} - \varepsilon\right)$ . If we take  $\varepsilon < \frac{1}{n^2d}$  then this becomes  $\ell < \frac{\beta^2 n}{d}$ , as desired, because  $\beta$  can be taken to have denominator n.

Note that we cannot achieve degree equal to  $\beta^2 n/d$  (as opposed to strict inequality): for the equation  $x^d \equiv 0 \pmod{p(z)^d}$ , there are infinitely many solutions x = c p(z) if the field F is infinite, so it is impossible to list them all in polynomial time.

<span id="page-13-0"></span>4.2. Reed-Solomon list decoding and noisy polynomial interpolation. A Reed-Solomon code is determined by evaluating a polynomial  $w(z) \in \mathbb{F}_q[z]$  of degree at most  $\ell$  at a collection of distinct points  $(x_1, \ldots, x_n)$  to obtain a codeword  $(w(x_1), \ldots, w(x_n))$ . In the Reed-Solomon decoding problem, we are provided with  $(y_1, \ldots, y_n)$ , where at most e entries in the codeword have changed, and we wish to recover w(z) by finding a polynomial of degree at most  $\ell$  that fits at least n-e points  $(x_i, y_i)$ . Guruswami and Sudan [26] showed how to correct up to  $e = n - \sqrt{n\ell}$  errors by providing a list of all possible decodings.

In the noisy polynomial interpolation problem, at each  $x_i$  a set  $\{y_{i1}, \ldots, y_{id}\}$  of values is specified, and the goal is to find a low-degree polynomial passing through a point from each set. This problem has been proposed as a cryptographic primitive, for example by Naor and Pinkas [41], and studied by Bleichenbacher and Nguyen [8].

We can use Theorem 1.2 to solve both problems, and in particular recover the exact decoding rates of Guruswami and Sudan. The input to our problem is a collection of points

$$\{(x_i, y_{ij}) : 1 \le i \le n, 1 \le j \le d\}.$$

We set  $p(z) = \prod_i (z - x_i)$ , and we define a monic polynomial f(x) of degree d in x by

$$f(x) = \sum_{i=1}^{n} \prod_{j=1}^{d} (x - y_{ij}) \prod_{\substack{k=1\\k \neq i}}^{n} \frac{z - x_k}{x_i - x_k}.$$

We have constructed f(x) by interpolation so that  $f(x) \equiv \prod_j (x - y_{ij}) \pmod{(z - x_i)}$ . Thus,  $f(y_{ij}) = 0$  whenever  $z = x_i$ .

To correct e errors, we seek a polynomial w(z) of degree at most  $\ell$  such that for at least n-e values of i, there exists a j such that  $w(x_i)=y_{ij}$ . In other words, f(w(z)) must be divisible by at least n-e factors  $z-x_i$ , which is equivalent to

$$\deg_z \gcd(f(w(z)), p(z)) \ge n - e.$$

By Theorem 1.2, we can solve this problem in polynomial time if  $\ell < n(1-e/n)^2/d$  (since  $\beta = 1 - e/n$  in the notation of the theorem). That is equivalent to the Guruswami-Sudan bound  $e < n - \sqrt{n\ell d}$ .

4.3. Running time. The Guruswami-Sudan algorithm consists of two parts: constructing the polynomial Q(x), and finding the roots of Q(x) in  $\mathbb{F}_q[z]$ . In this paper, we do not address the second part, but we improve the running time of the first part, which has been the bottleneck in the algorithm.

The time to construct Q is dominated by the lattice basis reduction step, which depends on the dimension m of the lattice and the maximum degree D of a coefficient polynomial. In our construction, we have D = O(nk).

Using the fastest row reduction algorithm (see Section 2.2), the running time is

$$O(Dm^{\omega+o(1)}) = O(nkm^{\omega+o(1)}).$$

With cubic-time matrix multiplication we achieve  $O(nkm^3)$ , and with fast matrix multiplication [49] we achieve  $O(nkm^{2.3727})$ .

The fastest previous algorithm proposed for this problem from Beelen and Brander [4] runs in time  $O(m^4kn\log^2 n\log\log n)$ .

### 5. Number fields

<span id="page-14-0"></span>5.1. Background on number fields. See [33] for a beautiful introduction to computational algebraic number theory, or [13] for a more comprehensive treatment.

Recall that number fields are finite extensions of the field  $\mathbb{Q}$  of rational numbers. Each number field K is generated by some algebraic number  $\alpha$ , and the elements of the number field are polynomials in  $\alpha$  with rational coefficients. If the minimal polynomial p(x) of  $\alpha$  (the lowest-degree polynomial over  $\mathbb{Q}$ , not identically zero, for which  $\alpha$  is a root) has degree n, then every element of  $K = \mathbb{Q}(\alpha)$  will be a polynomial in  $\alpha$  of degree at most n-1. In other words,

$$\mathbb{Q}(\alpha) = \{ a_0 + a_1 \alpha + \dots + a_{n-1} \alpha^{n-1} : a_0, \dots, a_{n-1} \in \mathbb{Q} \}.$$

The degree of K is defined to be n. It is the dimension of K as a  $\mathbb{Q}$ -vector space.

The minimal polynomial p(x) must be irreducible over  $\mathbb{Q}$ , and thus it has n distinct complex roots  $\alpha_1, \ldots, \alpha_n$  (one of which is  $\alpha$ ). Not all of these roots will necessarily be in the field  $K = \mathbb{Q}(\alpha)$ . For example, the field  $\mathbb{Q}(\sqrt[3]{2})$  is contained in  $\mathbb{R}$  and thus does not contain either of the complex roots of  $x^3 - 2$ .

For each i from 1 to n, we can define an embedding  $\sigma_i$  of K into  $\mathbb{C}$  by mapping  $\alpha$  to  $\alpha_i$  and extending by additivity and multiplicativity. All embeddings into  $\mathbb{C}$  arise in this way. If p has  $r_1$  real roots and  $r_2$  pairs of complex conjugate (non-real) roots, then there will be  $r_1$  real embeddings and  $2r_2$  complex embeddings.

The Archimedean absolute values on K are defined by

$$|\gamma|_i = |\sigma_i(\gamma)|$$

(where  $|\cdot|$  on the right side is the familiar absolute value on  $\mathbb{C}$ , and  $|\cdot|_i$  does not denote the  $\ell_i$  norm). For each i, this valuation has all the usual properties of the absolute value on  $\mathbb{Q}$ . These absolute values are not necessarily distinct, since they coincide for complex conjugate roots of p(x): if  $\alpha_i = \overline{\alpha_j}$ , then  $|\gamma|_i = |\gamma|_j$  for all  $\gamma$ . Otherwise, the absolute values are all distinct.

The ring of algebraic integers  $\mathcal{O}_K$  in K consists of all the elements of K that are roots of monic polynomials over  $\mathbb{Z}$ . It is the natural analogue of  $\mathbb{Z}$  in K (note that  $\mathcal{O}_{\mathbb{Q}} = \mathbb{Z}$ ). In simple cases,  $\mathcal{O}_K$  may equal  $\mathbb{Z}[\alpha]$ , but that is not always true. When  $K = \mathbb{Q}(\sqrt{5})$ , we have  $\mathcal{O}_K = \mathbb{Z}[(1+\sqrt{5})/2]$ , and for some number fields the ring of integers cannot even be generated by a single element.

The norm of an element  $\gamma \in K$  is defined as the product

$$N(\gamma) = \sigma_1(\gamma) \dots \sigma_n(\gamma)$$

in  $\mathbb{C}$ . (In fact,  $N(\gamma)$  is rational for  $\gamma \in K$ , and it is integral for  $\gamma \in \mathcal{O}_K$ .) If  $\gamma \in \mathcal{O}_K$  and  $\gamma \neq 0$ , then  $|N(\gamma)| = |\mathcal{O}_K/\gamma \mathcal{O}_K|$ . More generally, for any nonzero ideal I in  $\mathcal{O}_K$ , we define its norm N(I) to be  $|\mathcal{O}_K/I|$ . The norm is multiplicative; i.e., N(IJ) = N(I)N(J).

The norm is a natural measure of size for both ideals and individual elements in  $\mathcal{O}_K$ . It might be tempting to use the norm as our measure of the size of the roots of the polynomial in Theorem 1.3. However, that does not work, because  $\mathcal{O}_K$  typically has infinitely many units (elements of norm 1). For example, the powers of  $(1+\sqrt{5})/2$  are units in  $\mathbb{Z}[(1+\sqrt{5})/2]$ , which means the equation  $x^2\equiv 0\pmod 4$  has infinitely many solutions of norm at most  $N(4)^{1/2}=N(2)=4$ , namely the numbers  $2((1+\sqrt{5})/2)^k$  for  $k\in\mathbb{Z}$ . Thus, bounding the norm alone is insufficient even to guarantee that there will be only finitely many solutions, but bounding all the absolute values suffices.

The ring  $\mathcal{O}_K$  has an integral basis  $\omega_1, \ldots, \omega_n$  (i.e., a basis such that every element of  $\mathcal{O}_K$  can be expressed uniquely in the form  $\sum_i a_i \omega_i$  with  $a_i \in \mathbb{Z}$ ). We assume we are given such a basis, because finding one is computationally difficult (see Theorem 4.4 in [33]). Any reasonably explicit description of  $\mathcal{O}_K$  will yield an integral basis. Fortunately, such a description is known for many concrete examples of number fields, such as cyclotomic fields. Furthermore, if we are working with a fixed number field, finding an integral basis for  $\mathcal{O}_K$  can be done with only a fixed amount of preprocessing. We also assume that ideals in  $\mathcal{O}_K$  are given in terms of integral bases. It is not difficult to convert any other description of an ideal (such as generators over  $\mathcal{O}_K$ ) to an integral basis.

If we do not know the full ring  $\mathcal{O}_K$  of integers, we could nevertheless work with an order in K, i.e., a finite-index subring of  $\mathcal{O}_K$ . Everything we need works just as well for orders, with one exception, namely that the norm is no longer multiplicative for ideals. Fortunately, it remains multiplicative for invertible ideals (see Proposition 4.6.8 in [13]), and Coppersmith's theorem generalizes to invertible ideals. Specifically, we can find small roots of polynomial equations modulo an invertible ideal I, or modulo any invertible ideal B that contains I and satisfies  $N(B) \geq N(I)^{\beta}$ .

Polynomials over number fields can be factored in polynomial time [31].

5.1.1. Modules and canonical embeddings. The analogue of a lattice for  $\mathcal{O}_K$  is a finitely generated  $\mathcal{O}_K$ -submodule of the r-dimensional K-vector space  $K^r$ . Recall that an  $\mathcal{O}_K$ -submodule is a non-empty subset that is closed under addition and under multiplication by any element in  $\mathcal{O}_K$ .

Unlike the case of  $\mathbb{Z}$ -lattices,  $\mathcal{O}_K$ -lattices may not have bases over  $\mathcal{O}_K$ . However, an  $\mathcal{O}_K$ -lattice  $\Lambda$  always has a pseudo-basis, i.e., a collection of vectors  $v_1, \ldots, v_s \in \Lambda$  and ideals  $I_1, \ldots, I_s \subseteq \mathcal{O}_K$  such that

$$\Lambda = I_1 v_1 + \dots + I_s v_s.$$

The key difference from  $\mathbb{Z}$  is that the ideals may not be principal (i.e., they may not simply be the multiples of single elements of  $\mathcal{O}_K$ ).

A natural approach to finding a short vector in an  $\mathcal{O}_K$ -lattice would be to find an algorithm to reduce a pseudo-basis. Fieker and Pohst [19] developed an  $\mathcal{O}_K$ -analogue of the LLL lattice basis reduction algorithm, but they were unable to prove that their algorithm runs in polynomial time. More recently, Fieker and Stehlé [20] have given a polynomial-time algorithm to find a reduced pseudo-basis in an  $\mathcal{O}_K$ -module. Their algorithm runs in two parts. The first applies LLL to an embedding of the  $\mathcal{O}_K$ -module as a  $\mathbb{Z}$ -lattice to find a full-rank set of short module elements, and the second uses this collection of module elements to reduce the pseudo-basis.

As our application only requires finding a short vector in the module, we do not need the second step of the Fieker-Stehlé algorithm. The remainder of this section describes how to use LLL to find a short vector in an  $\mathcal{O}_K$ -lattice.

Although  $\mathcal{O}_K$ -lattices are an algebraic analogue of  $\mathbb{Z}$ -lattices, their geometry is not as easy to see directly from the definition. It might seem natural simply to use one of the absolute values to define the  $\ell_2$  norm for vectors, but that breaks the symmetry between them. Instead, it is important to treat each absolute value on an equal footing, and the canonical embedding (defined below) allows us to do so.

We will describe the embedding in several steps. First, we embed  $\mathcal{O}_K$  itself as an n-dimensional lattice in  $\mathbb{R}^{r_1} \oplus \mathbb{C}^{2r_2}$  by mapping  $\gamma \in \mathcal{O}_K$  to  $(\sigma_1(\gamma), \ldots, \sigma_n(\gamma))$ . An integral basis  $\omega_1, \ldots, \omega_n$  of  $\mathcal{O}_K$  is mapped to the rows of the matrix

$$\sigma(\omega) = \begin{pmatrix} \sigma_1(\omega_1) & \sigma_2(\omega_1) & \cdots & \sigma_n(\omega_1) \\ \sigma_1(\omega_2) & \ddots & & \sigma_n(\omega_2) \\ \vdots & & \ddots & \vdots \\ \sigma_1(\omega_n) & \sigma_2(\omega_n) & \cdots & \sigma_n(\omega_n) \end{pmatrix},$$

so  $\mathcal{O}_K$  is mapped to the  $\mathbb{Z}$ -linear combinations of the rows

The discriminant  $\Delta_K$  of K is defined by

$$\Delta_K = \det \sigma(\omega)^2$$
.

It is an integer that measures the size of the ring of integers in K.

The canonical embedding of the principal ideal generated by an element  $\gamma$  is generated by the rows of the matrix product

$$\begin{pmatrix} \sigma_1(\omega_1) & \sigma_2(\omega_1) & \cdots & \sigma_n(\omega_1) \\ \sigma_1(\omega_2) & \ddots & & \sigma_n(\omega_2) \\ \vdots & & \ddots & \vdots \\ \sigma_1(\omega_n) & \sigma_2(\omega_n) & \cdots & \sigma_n(\omega_n) \end{pmatrix} \begin{pmatrix} \sigma_1(\gamma) & & & \\ & \sigma_2(\gamma) & & \\ & & \ddots & \\ & & & \sigma_n(\gamma) \end{pmatrix}.$$

More generally, suppose we have an ideal B generated by an integral basis  $b_1, \ldots, b_n$ . Let  $M_B$  be the matrix defined by

$$b_i = \sum_{i} (M_B)_{ij} \omega_j.$$

The canonical embedding of B is generated by the rows of

$$\sigma(b) = \begin{pmatrix} \sigma_1(b_1) & \sigma_2(b_1) & \cdots & \sigma_n(b_1) \\ \sigma_1(b_2) & \ddots & & \sigma_n(b_2) \\ \vdots & & \ddots & \vdots \\ \sigma_1(b_n) & \sigma_2(b_n) & \cdots & \sigma_n(b_n) \end{pmatrix} = M_B \begin{pmatrix} \sigma_1(\omega_1) & \sigma_2(\omega_1) & \cdots & \sigma_n(\omega_1) \\ \sigma_1(\omega_2) & \ddots & & \sigma_n(\omega_2) \\ \vdots & & \ddots & \vdots \\ \sigma_1(\omega_n) & \sigma_2(\omega_n) & \cdots & \sigma_n(\omega_n) \end{pmatrix}.$$

Note that the absolute value of the determinant of  $\sigma(b)$  equals  $|\det M_B| \sqrt{|\Delta_K|}$ , and  $|\det M_B| = |\mathcal{O}_K/B| = N(B)$ .

Finally, we can easily extend the canonical embedding from  $\mathcal{O}_K$  to  $\mathcal{O}_K^r$  by embedding each of the r coordinates independently. Given a pseudo-basis  $v_1, \ldots, v_r$  with corresponding ideals  $I_1, \ldots, I_r$ , the canonical embedding of the lattice is

generated by the rows of the block matrix whose ij block of size  $n \times n$  is equal to

$$M_{I_i}\sigma(\omega)\begin{pmatrix} \sigma_1(v_{ij}) & & & \\ & \sigma_2(v_{ij}) & & \\ & & \ddots & \\ & & & \sigma_n(v_{ij}) \end{pmatrix},$$

where  $v_{ij}$  is the j-th component of  $v_i$ .

The inner product on  $\mathbb{R}^{r_1} \oplus \mathbb{C}^{2r_2}$  is given by the usual dot product on  $\mathbb{R}$  and the Hermitian inner product on  $\mathbb{C}$  (i.e.,  $\langle x, y \rangle = x\overline{y}$  for  $x, y \in \mathbb{C}$ ). Thus, it is positive definite.

The canonical embedding's image lies within an n-dimensional real subspace, because the complex embeddings come in conjugate pairs. In fact, we can transform it into a simple real embedding. To do so, consider the  $r_2$  pairs of complex embeddings. For each pair  $(\sigma_j(\gamma), \sigma_k(\gamma))$  of complex embeddings that are conjugates of each other, we can map the pair  $(\sigma_j(\gamma), \sigma_k(\gamma))$  to  $(\sqrt{2}\operatorname{Re}(\sigma_j(\gamma)), \sqrt{2}\operatorname{Im}(\sigma_j(\gamma)))$ . The reason for the factor of  $\sqrt{2}$  is to ensure that the inner product is preserved. Furthermore, the absolute value of the determinant is preserved.

Once we have a real embedding of our  $\mathcal{O}_K$ -lattice, we can apply the LLL algorithm to find a short vector in the real embedded lattice, which will correspond to a short vector in the original  $\mathcal{O}_K$ -lattice. Unfortunately, using LLL in the canonical embedding does not preserve the  $\mathcal{O}_K$ -structure, so it does not produce a reduced pseudo-basis over  $\mathcal{O}_K$ , but a short vector is sufficient for our purposes here.

5.2. **Proof of Theorem 1.3.** The following lemma is the analogue of the statement over the integers that a multiple of n that is strictly less than n in absolute value must be zero.

**Lemma 5.1.** For a nonzero ideal I in  $\mathcal{O}_K$  and an element  $\gamma \in I$ , if  $|N(\gamma)| < N(I)$  then  $\gamma = 0$ .

*Proof.* Consider the principal ideal  $\gamma \mathcal{O}_K$  generated by a nonzero element  $\gamma$  of I. The ideal I contains  $\gamma \mathcal{O}_K$ , and thus  $|\mathcal{O}_K/I| \leq |\mathcal{O}_K/\gamma \mathcal{O}_K|$ . Because  $N(I) = |\mathcal{O}_K/I|$  and  $|N(\gamma)| = |\mathcal{O}_K/\gamma \mathcal{O}_K|$ , we have  $|N(\gamma)| \geq N(I)$ , as desired.

Proof of Theorem 1.3. As in the previous proofs, we will construct a polynomial Q(x) in the  $\mathcal{O}_K$ -module generated by

$$x^j f(x)^i I^{k-i}$$
 for  $0 \le i < k$  and  $0 \le j < d$ 

and

$$x^j f(x)^k$$
 for  $0 \le j < t$ .

Note that because of the ideals  $I^{k-i}$ , this is really a pseudo-basis rather than a basis.

Let m = dk + t. To represent this module, we will write down an  $nm \times nm$  matrix whose rows are a  $\mathbb{Z}$ -basis for a weighted version of the module's canonical embedding. Finding a short vector in this lattice will correspond to finding a Q that satisfies our bounds.

Our lattice is constructed much as before, except that in place of a single entry for each coefficient of  $x^j f(x)^i I^{k-i}$ , we will have an  $n \times n$  block matrix. Let  $f_{sij}$  be the coefficient of  $x^s$  in  $x^j f(x)^i$ . Then we form the ideal  $f_{sij} I^{k-i}$ , which has an

integral basis  $b_1, \ldots, b_n$ . We incorporate the bounds  $\lambda_i$  on each absolute value into our canonical embedding for the s-th coefficient of  $x^j f(x)^i I^{k-i}$  by using

$$\begin{pmatrix} \lambda_1^s \sigma_1(b_1) & \lambda_2^s \sigma_2(b_1) & \cdots & \lambda_n^s \sigma_n(b_1) \\ \lambda_1^s \sigma_1(b_2) & \ddots & & \lambda_n^s \sigma_n(b_2) \\ \vdots & & \ddots & \vdots \\ \lambda_1^s \sigma_1(b_n) & \lambda_2^s \sigma_2(b_n) & \cdots & \lambda_n^s \sigma_n(b_n) \end{pmatrix}.$$

This is equal to the product of the matrix with  $\lambda_1^s, \ldots, \lambda_n^s$  on the diagonal with the canonical embedding  $\sigma(b)$ , so the absolute value of the determinant of the block is

$$\lambda_1^s \dots \lambda_n^s \sqrt{|\Delta_K|} |N(f_{sij})| N(I)^{k-i}$$

Now consider a vector v in this lattice and the polynomial  $Q(x) = \sum_j q_j x^j$  that it represents. If  $|w|_i < \lambda_i$  for all i, then we can bound |N(Q(w))| using the  $\ell_1$  norm by applying the arithmetic mean-geometric mean inequality. We have

$$|N(Q(w))| = \prod_{i} \left| \sum_{j} q_{j} w^{j} \right|_{i},$$

and hence

$$|N(Q(w))|^{1/n} \le \frac{1}{n} \sum_{i} \left| \sum_{j} q_{j} w^{j} \right|_{i}$$
$$\le \frac{1}{n} \sum_{i} \sum_{j} |q_{j}|_{i} \lambda_{i}^{j}.$$

Thus,

$$|N(Q(w))| \le \left(\frac{1}{n}|v|_1\right)^n.$$

As in the integer case, LLL produces a nonzero vector v whose  $\ell_1$  norm is bounded by

$$\sum_{i} \sum_{j} |v_i|_j \le \sqrt{nm} 2^{(nm-1)/4} |\det(M)|^{\frac{1}{nm}}.$$

Note that here,  $|v_i|_j$  denotes the j-th number field norm applied to the i-th entry of v.

Now it remains to compute the determinant of our weighted canonical embedding. The lattice basis we produced in our construction is block upper triangular, so the determinant is the product of the blocks on the diagonal. Letting  $\prod_i \lambda_i = X$ , we get

$$|\det M| = \prod_{0 \le i < m} \left( X^i \sqrt{|\Delta_K|} \right) \prod_{0 \le j \le k} N(I)^{dj}$$
$$= \sqrt{|\Delta_K|}^m X^{m(m-1)/2} N(I)^{dk(k+1)/2}.$$

Thus, we have

$$|v|_1 < \sqrt{nm} 2^{(nm-1)/4} \sqrt{|\Delta_K|}^{\frac{1}{n}} \left( X^{m(m-1)/2} N(I)^{dk(k+1)/2} \right)^{\frac{1}{nm}}$$

Recall that if  $|w|_i < \lambda_i$  for all i, then

$$|N(Q(w))| \le \frac{1}{n^n} |v|_1^n.$$

We will compute a c so that

$$\left(\frac{1}{n^n} \left(\sqrt{nm} 2^{(nm-1)/4}\right)^n \sqrt{|\Delta_K|}\right)^{\frac{2}{m-1}} < c.$$

Then by the same analysis as in the proof of Theorem 1.1, we can prove the theorem with a bound of

$$\frac{1}{c}N(I)^{\beta^2/d-\varepsilon}$$

on the product  $\prod_i \lambda_i$ . A simple asymptotic analysis shows that we can take  $c = (2 + o(1))^{n^2/2}$  as  $m \to \infty$ . Thus, we achieve a bound of

$$(2+o(1))^{-n^2/2}N(I)^{\beta^2/d-\varepsilon}.$$

As before, we can take  $\varepsilon = 1/\log N(I)$  to achieve in fact  $(2+o(1))^{-n^2/2}N(I)^{\beta^2/d}$ . Note that so far, everything runs in polynomial time, with no exponential dependence on n. Unfortunately, removing the factor of  $(2+o(1))^{-n^2/2}$  is computationally expensive. We can use the same trick as in Theorem 1.1. In the canonical embedding of  $\mathcal{O}_K$ , the region we would like to cover is a box of dimensions  $2\lambda_1 \times \cdots \times 2\lambda_n$  (the factor of 2 comes from including positive and negative signs). The proof so far shows that we can deal with a box that is a factor of  $(2+o(1))^{-n/2}$  smaller in each coordinate. We can cover the large box with  $(2+o(1))^{n^2/2}$  of the smaller ones and compute the solutions in each smaller box in polynomial time, but the total running time becomes exponential in  $n^2$ .

<span id="page-19-0"></span>5.3. Solving the closest vector problem in ideal lattices. In [42], Peikert and Rosen proposed using the closest vector problem for ideal lattices as a hard problem for use in constructing lattice-based cryptosystems. In [36], Lyubashevsky, Peikert, and Regev gave hardness reductions for such cryptosystems via the bounded-distance decoding problem, defined for the  $\ell_{\infty}$  norm as follows. Given an ideal I in  $\mathcal{O}_K$ , a distance  $\delta$ , and an element  $y \in K$ , find  $y + w \in I$  such that  $|w|_{\infty} < \delta$ , where  $|\cdot|_{\infty}$  denotes the  $\ell_{\infty}$  norm on K (i.e., the maximum of the n absolute values).

If  $y \in \mathcal{O}_K$ , then we can define f(x) = x + y and find the roots w of  $f(x) \equiv 0 \pmod{I}$  satisfying

$$|w|_{\infty} < (2 + o(1))^{-n/2} N(I)^{1/n}.$$

This amounts to taking d=1,  $\beta=1$ , and  $\lambda_1=\cdots=\lambda_n=(2+o(1))^{-n/2}N(I)^{1/n}$ . Because we are using the  $\ell_{\infty}$  norm, the minimal nonzero norm of I is at most  $\left(\sqrt{|\Delta_K|}N(I)\right)^{1/n}$ . Thus, our algorithm can handle distances  $\delta$  less than  $(2+o(1))^{-n/2}|\Delta_K|^{-1/(2n)}$  times the minimal norm of I. (Of course, this is somewhat worse than using LLL directly.) Note also that if  $y \notin \mathcal{O}_K$ , then we can rescale y and I by a positive integer to reduce to the previous case.

If the  $(2 + o(1))^{-n^2/2}$  could be improved to  $2^{-n}\sqrt{|\Delta_K|}$ , then we could solve the bounded-distance decoding problem up to half the minimal distance, by the same argument as above with  $\lambda_1 = \cdots = \lambda_n = |\Delta_K|^{1/(2n)} N(I)^{1/n}/2$ . This suggests that it will be difficult to remove the multiplicative factor entirely.

### 6. Function Fields

<span id="page-19-1"></span>Much as number fields are finite extensions of  $\mathbb{Q}$ , function fields are finite extensions of the field  $\mathbb{F}_q(x)$  of rational functions over a finite field  $\mathbb{F}_q$ . They arise naturally from algebraic curves over  $\mathbb{F}_q$ , as the field of rational functions on

the curve. For example, for a plane curve defined by the polynomial equation f(x,y) = 0, the function field will be  $\mathbb{F}_q(x,y)/(f(x,y))$  (i.e., rational functions of x and y, where the variables satisfy f(x,y) = 0). See [47] and [43] for background on function fields, and [35] for a beautiful account of the analogies between number fields and function fields.

More generally, let  $\mathcal{X}$  be an algebraic curve over  $\mathbb{F}_q$ . Specifically, it must be a smooth, projective curve that remains irreducible over the algebraic closure of  $\mathbb{F}_q$ . Our function field K will be the field of rational functions on  $\mathcal{X}$  defined over  $\mathbb{F}_q$ . (Note that we are assuming  $\mathbb{F}_q$  is the full field of constants in K; in other words, each element of K is either in  $\mathbb{F}_q$  or transcendental over  $\mathbb{F}_q$ .)

Let  $\mathcal{X}(\mathbb{F}_q)$  be the set of points on  $\mathcal{X}$  with coordinates in  $\mathbb{F}_q$ . Every point  $p \in \mathcal{X}(\mathbb{F}_q)$  gives a valuation  $v_p$  on K, which measures the order of vanishing at that point. Poles are treated as zeros of negative order. The corresponding absolute value on K is defined by

$$|f|_p = q^{-v_p(f)}.$$

(Note that this is not the  $\ell_p$  norm on a vector; in this section, the  $\ell_p$  norm will not be used.) In other words, high-order zeros make a function small, while poles make it large. Not every absolute value on K is of this form—there is a slight generalization that corresponds to points defined over finite extensions of  $\mathbb{F}_q$  (more precisely, Galois orbits of such points). For our purposes we can restrict our attention to the absolute values defined above, but in fact all our results generalize naturally to places of degree greater than 1.

In the number field case, the Archimedean absolute values (which come from the complex embeddings) play a special role, although there are infinitely many non-Archimedean absolute values as well, namely the p-adic absolute values measuring divisibility by primes. In the function field case, there are no Archimedean absolute values, and any set of absolute values can play that role.

Let S be a nonempty subset of  $\mathcal{X}(\mathbb{F}_q)$ , and let  $\mathcal{O}_S$  be the subring of K consisting of all rational functions whose poles are confined to the set S. The ring  $\mathcal{O}_S$  is analogous to the ring of algebraic integers in a number field; in this analogy, the condition of having no poles outside S amounts to the condition that an algebraic integer has no primes in its denominator, because the valuations from points outside S correspond to the p-adic valuations.

For example, if  $\mathcal{X}$  is the projective line (i.e., the ordinary line completed with a point at infinity), then K is simply the field  $\mathbb{F}_q(z)$  of rational functions in one variable. If we let  $S = \{\infty\}$  be the set consisting solely of the point at infinity, then  $\mathcal{O}_S$  is the set of rational functions that have poles only at infinity. In other words, it is the polynomial ring  $\mathbb{F}_q[z]$ . (A polynomial of degree d has a pole of order d at infinity.)

The norm of an element  $f \in \mathcal{O}_S$  is defined by

$$N(f) = \prod_{p \in S} |f|_p,$$

and the norm of a nonzero ideal I is defined by  $N(I) = |\mathcal{O}_S/I|$ . As in the number field case, the norm of the principal ideal  $f\mathcal{O}_S$  is N(f).

6.1. Background on algebraic-geometric codes. Algebraic-geometric codes are a natural generalization of Reed-Solomon codes. They are of great importance in coding theory, because for certain finite fields they beat the Gilbert-Varshamov

bound (which is the performance of a random code, and which aside from algebraic-geometric codes is the best bound known). See Section 8.4 in [47].

To define an algebraic-geometric code on  $\mathcal{X}$ , we specify for each point in S the maximum allowable order of a pole there, and we allow no poles outside of S. The space of functions satisfying these restrictions is a finite-dimensional  $\mathbb{F}_q$ -vector space, and we can produce an error-correcting code by looking at the evaluations of these functions at a fixed set of points (disjoint from S).

This is typically described using the language of algebraic geometry. A divisor D on  $\mathcal{X}$  is a formal  $\mathbb{Z}$ -linear combination of finitely many points on  $\mathcal{X}$ ; the support of D is the set of points with nonzero coefficients. (We will restrict our attention to divisors supported at points in  $\mathcal{X}(\mathbb{F}_q)$ .) The divisor D is called effective, denoted  $D \succeq 0$ , if all its coefficients are nonnegative. For every function  $f \in K^*$ , the principal divisor (f) is the sum of the zeros and poles of f, with their orders as coefficients. (The identically zero function does not define a principal divisor, since it has a zero of infinite order at every point.) The degree  $\deg(D)$  of D is the sum of its coefficients, and the degree of a principal divisor is always zero.

Given a divisor D, the Riemann-Roch space  $\mathcal{L}(D)$  is defined by

$$\mathcal{L}(D) = \{0\} \cup \{f \in K^* : (f) + D \succeq 0\}.$$

In other words, if the coefficient of p in D is k, then f can have a pole of order at most k at the point p. The space  $\mathcal{L}(D)$  is a finite-dimensional  $\mathbb{F}_q$ -vector space, and the famous Riemann-Roch theorem describes its dimension:

$$\dim_{\mathbb{F}_a} \mathcal{L}(D) = \deg(D) - g + 1 + \dim_{\mathbb{F}_a} \mathcal{L}(W - D),$$

where g is a nonnegative integer called the genus of the curve and W is a particular divisor called the canonical divisor. It follows that  $\dim_{\mathbb{F}_q} \mathcal{L}(D) \ge \deg(D) - g + 1$ , and equality holds if  $\deg(D) > 2g - 2$ .

To translate the definition of an algebraic-geometric code to this language, let D be the divisor with support in S whose coefficients specify the allowed order of a pole at each point, and let  $p_1, \ldots, p_n$  be distinct points in  $\mathcal{X}(\mathbb{F}_q)$  but not in S. Then the corresponding algebraic-geometric code consists of the codewords  $(w(p_1), \ldots, w(p_n))$  for  $w \in \mathcal{L}(D)$ .

In the case of the projective line, let  $S = \{\infty\}$ , so  $\mathcal{O}_S = \mathbb{F}_q[z]$ , and let  $D = d\infty$ . Then  $\mathcal{L}(D)$  is the space of polynomials in  $\mathbb{F}_q[z]$  of degree at most d. Thus, this construction yields Reed-Solomon codes as a special case.

Theorem 1.4 corresponds to list decoding of algebraic-geometric codes in much the same way as Theorem 1.2 does for Reed-Solomon codes. The evaluation points  $p_1, \ldots, p_n$  correspond to prime ideals  $P_1, \ldots, P_n$  in  $\mathcal{O}_S$ , where  $P_i$  consists of the functions vanishing at  $p_i$ , and we can let I be the product  $P_1 \ldots P_n$ . If the received codeword is  $(y_1, \ldots, y_n) \in \mathbb{F}_q^n$ , then we define the linear polynomial f so that  $f(x) \equiv x - y_i \pmod{P_i}$  for all i. (The Chinese remainder theorem lets us solve this interpolation problem.) Thus, for  $w \in \mathcal{O}_S$ , f(w) is in the ideal  $P_i$  if and only if  $w(p_i) = y_i$ . We have  $N(I) = q^n$ , and  $\gcd(f(w)\mathcal{O}_S, I)$  is divisible by  $P_i$  exactly when  $w(p_i) = y_i$ . Therefore the inequality

$$N(\gcd(f(w)\mathcal{O}_S, I)) \ge N(I)^{\beta}$$

simply means that  $w(p_i) = y_i$  for at least  $\beta n$  values of i. Thus, Theorem 1.4 solves the list decoding problem.

6.2. **Proof of Theorem 1.4.** The first obstacle to proving Theorem 1.4 is identifying the right sort of lattice to consider. For comparison, in the number field case, we use the canonical embedding to reduce from  $\mathcal{O}_K$ -lattices to  $\mathbb{Z}$ -lattices, because  $\mathbb{Z}$  is a principal ideal domain and hence  $\mathbb{Z}$ -lattices are structurally simpler. In the function field case,  $\mathbb{F}_q[z]$ -lattices are the analogous structures, but  $\mathbb{F}_q[z]$  has infinitely many embeddings as a subring of  $\mathcal{O}_S$ , while  $\mathbb{Z}$  has only one embedding into  $\mathcal{O}_K$ . We must identify an embedding of a special sort, namely one that treats all the absolute values from points in S evenhandedly. Lemma 6.1 accomplishes this.

One we have identified a suitable embedding of  $\mathbb{F}_q[z]$  into  $\mathcal{O}_S$ , we are faced with two more difficulties. The first is that we must consider lattices with more general non-Archimedean norms than those studied in the literature, because we must take into account all the absolute values from S, and the known algorithms for basis reduction no longer apply. However, we can prove the needed results in our more general framework (Lemma 2.3).

The final difficulty comes from attempting to control the zeros and poles of functions in K. In the simplest function field, namely the rational function field  $\mathbb{F}_q(z)$ , we can specify the (finitely many) zeros and poles arbitrarily, subject to just one constraint, that the total order of all the zeros must equal that of the poles. For example,  $z^2/(z-1)$  has a zero of order two at 0, a pole of order one at 1, and a pole of order one at  $\infty$  (because the function grows linearly as z becomes large).

In more complicated function fields, there are additional subtle constraints on the zeros and poles, which interfere with our ability to construct auxiliary functions in the proof (specifically, the placeholder X that measures the size of the desired solution of the equation). We circumvent this difficulty in Lemma 6.2, using a technique based on the strong approximation theorem. This allows us to control the behavior of a function at all the points in S except one, if we are willing to allowed uncontrolled behavior at that single point. Furthermore, we can uniformly bound the bad behavior at the uncontrolled point in terms of the genus of the function field. This approach introduces error terms into our bounds, but they are small enough that they disappear entirely in the final result.

We now turn to the details of the proof. To identify an appropriate embedding of  $\mathbb{F}_q[z]$  into  $\mathcal{O}_S$ , we would like to choose  $z \in \mathcal{O}_S$  so that  $|z|_p$  is independent of p for  $p \in S$ . In that case, the absolute values  $|\cdot|_p$  with  $p \in S$  will all restrict to the same absolute value on the ring  $R = \mathbb{F}_q[z]$ , which we will denote  $|\cdot|$ .

When |S| = 1, we can choose any nonconstant element z of  $\mathcal{O}_S$ . When |S| > 1, it is not as trivial, but fortunately there is always such an element:

<span id="page-22-0"></span>**Lemma 6.1.** There exists an integer  $a \ge 1$  and an element  $z \in \mathcal{O}_S$  such that  $v_p(z) = -a$  for all  $p \in S$ , and we can find such an element in probabilistic polynomial time.

*Proof.* Let  $\Delta_a$  be the divisor

$$\sum_{p \in S} ap$$

with coefficient a for each  $p \in S$ , and let g be the genus of the curve  $\mathcal{X}$ . If a|S| > 2g - 2, then by the Riemann-Roch theorem,

$$\dim_{\mathbb{F}_a} \mathcal{L}(\Delta_a) = a|S| - (g-1).$$

Furthermore, if a|S| > 2g - 1, then for each  $p \in S$ ,

$$\dim_{\mathbb{F}_q} \mathcal{L}(\Delta_a - p) = a|S| - g.$$

Thus, if |S| < q, then  $\mathcal{L}(\Delta_a)$  cannot be contained in the union of  $\mathcal{L}(\Delta_a - p)$  over all  $p \in S$ , and therefore there exists a function with poles of order exactly a at each point in S. If |S| < q/2, then it is easy to find such a function by random sampling, since at least half the elements in  $\mathcal{L}(\Delta_a)$  will work. (Recall that as mentioned in Section 1.4, we assume that we can efficiently compute bases of Riemann-Roch spaces.)

This proof requires |S| < q, but the same idea works if we pass to a finite extension  $\mathbb{F}_{q^i}$  of  $\mathbb{F}_q$ , and  $|S| < q^i$  then suffices. Thus, if we take i large enough, there exists a function defined over  $\mathbb{F}_{q^i}$  with poles of equal order a at the points in S (and no poles elsewhere). Now multiplying the i conjugates of this function over  $\mathbb{F}_q$  produces such a function over  $\mathbb{F}_q$ , as desired, with poles of order ai. Taking  $q^i > 2|S|$  gives an efficient algorithm as well.

For the rest of this section, let z be such a function and let  $R = \mathbb{F}_q[z]$ . Then the ring  $\mathcal{O}_S$  is a free R-module of rank a|S| by Theorem 1.4.11 in [47], as is every nonzero ideal in  $\mathcal{O}_S$ .

As in the previous proofs, we will construct a polynomial Q(x) in the  $\mathcal{O}_S$ -module  $\mathcal{M}$  generated by

$$x^{j} f(x)^{i} I^{k-i}$$
 for  $0 \le i < k$  and  $0 \le j < d$ 

and

$$x^j f(x)^k$$
 for  $0 \le j < t$ .

Let m = dk + t.

The module  $\mathcal{M}$  is a submodule of the  $\mathcal{O}_S$ -module  $\mathcal{P}$  of polynomials of degree less than m, which is a free  $\mathcal{O}_S$ -module of rank m and hence a free R-module of rank ma|S|. Thus, as in the setting of Lemmas 2.2 and 2.3, we are working with an R-module contained in a free R-module.

We want Q(x) to have the property that for  $w \in \mathcal{L}(D)$ ,

$$N(Q(w)) < N(I)^{\beta k}$$
.

In fact, we will bound N(Q(w)) by

$$N(Q(w)) = \prod_{p \in S} |Q(w)|_p \le \left(\max_{p \in S} |Q(w)|_p\right)^{|S|},$$

and we will ensure that

$$\left(\max_{p \in S} |Q(w)|_p\right)^{|S|} < N(I)^{\beta k}.$$

Let  $q_0, \ldots, q_{m-1}$  denote the coefficients of Q, so

$$Q(x) = \sum_{i=0}^{m-1} q_i x^i.$$

Then

$$|Q(w)|_p \le \max_i |q_i|_p |w|_p^i.$$

Suppose the divisor D is given by

$$D = \sum_{p \in S} \lambda_p p.$$

Then  $|w|_p \leq q^{\lambda_p}$  for  $w \in \mathcal{L}(D)$ , and thus

$$|Q(w)|_p \le \max_i |q_i|_p q^{i\lambda_p}.$$

To emulate the analysis from Sections 3 and 4, we would like to find  $X \in \mathcal{O}_S$  such that  $v_p(X) = -\lambda_p$  for all  $p \in S$ . However, such an element does not always exist. Instead, we will construct an element with the desired valuations at all but one point in S. This approach is a special case of the strong approximation theorem (Theorem 1.6.5 in [47] or Theorem 6.13 in [43]), but as we need only a weaker conclusion and must consider computational feasibility, we will give a direct proof along the same lines as Lemma 6.1.

<span id="page-24-0"></span>**Lemma 6.2.** Suppose  $q \geq 2|S|$ . Then for any point  $p_0 \in S$  and each divisor  $\sum_{p \in S} \mu_p p$  satisfying  $\sum_{p \in S} \mu_p \geq 0$  and  $\mu_{p_0} = 0$ , there exists an element  $X \in \mathcal{O}_S$  such that  $v_p(X) = -\mu_p$  for all  $p \in S \setminus \{p_0\}$ , and  $v_{p_0}(X) = -2g$ , where g is the genus of  $\mathcal{X}$ . Furthermore, we can construct such an X in probabilistic polynomial time.

Proof. Let  $\Delta = \sum_{p \in S} \mu_p p + 2gp_0$ . Then  $\deg(\Delta) \geq 2g$ , and it follows from Riemann-Roch that  $\dim_{\mathbb{F}_q} \mathcal{L}(\Delta) = \deg(\Delta) - (g-1)$  and that  $\dim_{\mathbb{F}_q} \mathcal{L}(\Delta-p) = \dim_{\mathbb{F}_q} \mathcal{L}(\Delta) - 1$  for all  $p \in S$ . We are looking for an element X in  $\mathcal{L}(\Delta)$  but not  $\mathcal{L}(\Delta-p)$  for any  $p \in S$ . By assumption we can construct these Riemann-Roch spaces, and because  $|S| \leq q/2$  at least half the elements of X will have the desired property, so we can find one by random sampling.

The assumption that  $q \geq 2|S|$  will hold in most applications: most algebraic-geometric codes use a small set S, and in fact |S| cannot be much larger than q because  $S \subseteq \mathcal{X}(\mathbb{F}_q)$  and  $|\mathcal{X}(\mathbb{F}_q)| \leq q + 2g\sqrt{q} + 1$  (see Theorem 5.2.3 in [47]). However, if |S| > q/2, then we can simply pass to a finite extension of  $\mathbb{F}_q$ . Thus, without loss of generality we can assume that  $q \geq 2|S|$ .

By assumption in Theorem 1.4, the support of D is a proper subset of S, so we can let  $p_0 \in S$  be a point such that  $\lambda_{p_0} = 0$ . Because of the limitations of the strong approximation theorem, we require such a point to make the remainder of the proof work. This is not an obstacle to the applicability of the theorem, because algebraic-geometric codes will generally not use every point in  $\mathcal{X}(\mathbb{F}_q)$  for poles or evaluation points, and if they do we can pass to a finite extension of  $\mathbb{F}_q$  to generate more points. Note also that we can assume  $\deg(D) \geq 0$ , because otherwise  $\mathcal{L}(D)$  is the empty set.

Now, Lemma 6.2 lets us construct an element  $X \in \mathcal{O}_S$  such that  $v_p(X) = -\lambda_p$  for  $p \in S \setminus \{p_0\}$ . This element has the property that  $v_p(X^i) = -i\lambda_p$  for  $p \in S \setminus \{p_0\}$ . Unfortunately, the valuation at  $p_0$  grows linearly with i as well, and that will damage our bounds. However, we can avoid that problem by applying Lemma 6.2 to construct elements  $X_i$  so that  $v_p(X_i) = -i\lambda_p$  for  $p \in S \setminus \{p_0\}$  while maintaining  $v_{p_0}(X_i) = -2g$ . Of course we set  $X_0 = 1$ .

In terms of the elements  $X_i$ , we have

$$|Q(w)|_p \le \max_i |q_i X_i|_p$$

for  $p \in S \setminus \{p_0\}$ . Furthermore, this inequality holds for  $p = p_0$  because  $v_{p_0}(w) \ge 0 \ge v_{p_0}(X_i)$ .

Define the norm of a polynomial  $\sum_i c_i x^i \in \mathcal{P}$  (with  $c_i \in \mathcal{O}_S$ ) by

$$\left| \sum_{i} c_i x^i \right| = \max_{i} \max_{p \in S} |c_i|_p.$$

Note that this defines a non-Archimedean norm on the free R-module  $\mathcal{P}$  satisfying all three properties required in Section 2.3 (with the absolute value  $|\cdot|$  on R). Here, we crucially use the fact that we have only one absolute value on R; if that were not the case, then property 3 would fail.

Let  $T: \mathcal{P} \to \mathcal{P}$  be the linear transformation that multiplies the degree i term by  $X_i$ . Then

$$\max_{p \in S} |Q(w)|_p \le \max_{p \in S} \max_i |q_i X_i|_p = |TQ|.$$

Thus, it will suffice to construct a nonzero polynomial  $Q \in \mathcal{M}$  such that  $|TQ|^{|S|} < N(I)^{\beta k}$ .

Now we can apply Lemma 2.3. We need to determine two things: the geometric mean C of the norms of an R-basis of  $\mathcal{P}$  and the dimension of the quotient  $\mathcal{P}/T\mathcal{M}$ . Then there exists a nonzero  $Q \in \mathcal{M}$  such that

$$|TQ| \le C|z|^{\dim_{\mathbb{F}_q}(\mathcal{P}/T\mathcal{M})/(a|S|m)} = Cq^{\dim_{\mathbb{F}_q}(\mathcal{P}/T\mathcal{M})/(|S|m)},$$

because these R-modules have rank a|S|m and  $|z|=q^a$ .

Let  $b_1, \ldots, b_{a|S|}$  be any R-basis of  $\mathcal{O}_S$ , and let

$$C = \left(\prod_{i=1}^{a|S|} \max_{p \in S} |b_i|_p\right)^{\frac{1}{a|S|}}.$$

Then the elements  $b_i x^j \in \mathcal{P}$  (with  $1 \leq i \leq a|S|$  and  $0 \leq j < m$ ) form an R-basis of  $\mathcal{P}$ , and the geometric mean of their norms is C because  $|b_i x^j|$  is independent of the degree j.

To compute the dimension of  $\mathcal{P}/T\mathcal{M}$ , note that the generators of  $\mathcal{M}$  are triangular (i.e., given by polynomials of each degree). Thus, we merely need to add the dimensions of the quotients of  $\mathcal{O}_S$  by the ideals of leading coefficients. From the polynomials  $X_{di+j}x^jf(x)^iI^{k-i}$ , we see that the leading coefficients form the ideal  $X_{di+j}I^{k-i}$ . Thus,

$$\begin{split} q^{\dim_{\mathbb{F}_q} \mathcal{P}/T\mathcal{M}} &= |\mathcal{P}/T\mathcal{M}| \\ &= N(I)^{dk(k+1)/2} \prod_{i=0}^{m-1} N(X_i) \\ &= N(I)^{dk(k+1)/2} \bigg( \prod_{n \in S} q^{\lambda_p m(m-1)/2} \bigg) \prod_{i=0}^{m-1} |X_i|_{p_0}. \end{split}$$

In other words,

$$q^{\dim_{\mathbb{F}_q} \mathcal{P}/T\mathcal{M}} \leq N(I)^{dk(k+1)/2} q^{\deg(D)m(m-1)/2} q^{2mg}.$$

Now applying Lemma 2.3 shows that we can find a nonzero polynomial  $Q \in \mathcal{M}$  such that

$$|TQ|^{|S|} \le Cq^{2g}q^{\deg(D)(m-1)/2}N(I)^{dk(k+1)/(2m)}$$

We want to achieve  $|TQ|^{|S|} < N(I)^{\beta k}$ . Let  $N(I) = q^n$  and

$$\ell = \deg(D) + \frac{2}{m-1} \log_q \left( Cq^{2g} \right).$$

Then Lemma 3.1 applies, and shows that we can achieve  $|TQ|^{|S|} < N(I)^{\beta k}$  whenever  $\ell < n\left(\frac{\beta^2}{d} - \varepsilon\right)$ , which is equivalent to

$$(Cq^{2g})^{\frac{2}{m-1}} q^{\deg(D)} < N(I)^{\frac{\beta^2}{d} - \varepsilon}.$$

We can take the denominator of  $\beta$  to be a divisor of n (because  $N(I) = q^n$ ). Thus,  $N(I)^{\beta^2/d}$  is an integral power of  $q^{1/(nd)}$ , as of course is  $q^{\deg(D)}$ , and to prove the bound in Theorem 1.4 it suffices to prove it to within a factor of less than  $q^{1/(nd)}$ .

Now let  $\varepsilon < 1/(2n^2d)$  and  $m > 1 + 4nd(2g + \log_q C)$ . Then  $N(I)^{\varepsilon}$  and  $(Cq^{2g})^{\frac{2}{m-1}}$  are both strictly less than  $q^{1/(2nd)}$ . Thus, our algorithm works as long as

$$q^{\deg(D)} < N(I)^{\beta^2/d}.$$

This completes the proof of Theorem 1.4.

#### ACKNOWLEDGEMENTS

We are grateful to Amanda Beeson, Keith Conrad, Abhinav Kumar, Victor Miller, Vincent Neiger, Chris Peikert, Bjorn Poonen, Nigel Smart, and Madhu Sudan for helpful conversations, comments, and references.

#### References

- <span id="page-26-8"></span> M. Ajtai, The shortest vector problem in L<sub>2</sub> is NP-hard for randomized reductions, Proceedings of the Thirtieth Annual ACM Symposium on Theory of Computing (Dallas, Texas, United States, May 24–26, 1998), Association for Computing Machinery, New York, NY, 1998, pp. 10–19.
- <span id="page-26-4"></span> M. Alekhnovich, Linear Diophantine equations over polynomials and soft decoding of Reed-Solomon codes, IEEE Trans. Inform. Theory 51 (2005), 2257–2265.
- <span id="page-26-5"></span>[3] M. Ajtai, R. Kumar, and D. Sivakumar, A sieve algorithm for the shortest lattice vector problem, Proceedings of the Thirty-Third Annual ACM Symposium on Theory of Computing (Hersonissos, Greece, July 6–8, 2001), Association for Computing Machinery, New York, NY, 2001, pp. 601–610.
- <span id="page-26-10"></span>[4] P. Beelen and K. Brander, Key equations for list decoding of Reed-Solomon codes and how to solve them, J. Symbolic Computation 45 (2010), 773–786.
- <span id="page-26-7"></span>[5] \_\_\_\_\_, Efficient list decoding of a class of algebraic-geometry codes, Adv. Math. Commun. 4 (2010), 485–518.
- <span id="page-26-3"></span>[6] D. J. Bernstein, List decoding for binary Goppa codes, Coding and Cryptology, Lecture Notes in Computer Science, vol. 6639, Springer-Verlag, Berlin, Heidelberg, 2011, pp. 62–80.
- <span id="page-26-6"></span> J.-F. Biasse and G. Quintin, An algorithm for list decoding number field codes, 2012 IEEE International Symposium on Information Theory Proceedings, IEEE, 2012, pp. 91–95.
- <span id="page-26-9"></span>[8] D. Bleichenbacher and P. Q. Nguyen, Noisy polynomial interpolation and noisy Chinese remaindering, Advances in Cryptology – EUROCRYPT 2000, Lecture Notes in Computer Science, vol. 1807, Springer-Verlag, Berlin, Heidelberg, 2000, pp. 53–69.
- <span id="page-26-0"></span>[9] J. Blömer and A. May, New partial key exposure attacks on RSA, Advances in Cryptology

   CRYPTO 2003, Lecture Notes in Computer Science, vol. 2729, Springer-Verlag, Berlin,
   Heidelberg, 2003, pp. 27–43.
- <span id="page-26-2"></span>[10] D. Boneh, Finding smooth integers in short intervals using CRT decoding, Proceedings of the Thirty-Second Annual ACM Symposium on Theory of Computing (Portland, Oregon, United States, May 21–23, 2000), Association for Computing Machinery, New York, NY, 2000, pp. 265–272.
- <span id="page-26-1"></span>[11] D. Boneh, G. Durfee, and Y. Frankel, An attack on RSA given a small fraction of the private key bits, Advances in Cryptology – ASIACRYPT '98, Lecture Notes in Computer Science, vol. 1514, Springer-Verlag, Berlin, Heidelberg, 1998, pp. 25–34.

- <span id="page-27-10"></span>[12] J. Buchmann, T. Takagi, and U. Vollmer, Number field cryptography, High Primes and Misdemeanours: Lectures in Honour of the 60th Birthday of Hugh Cowie Williams, Fields Institute Communications, vol. 41, American Mathematical Society, Providence, RI, 2004, pp. 111–121.
- <span id="page-27-19"></span>[13] H. Cohen, A Course in Computational Algebraic Number Theory, Graduate Texts in Mathematics, vol. 138, Springer-Verlag, Berlin, Heidelberg, 1993.
- <span id="page-27-14"></span>[14] H. Cohn and N. Heninger, Approximate common divisors via lattices, to appear in Proceedings of ANTS 2012, arXiv:1108.2714.
- <span id="page-27-0"></span>[15] D. Coppersmith, Small solutions to polynomial equations, and low exponent RSA vulnerabilities, J. Cryptology 10 (1997), 233–260.
- <span id="page-27-2"></span>[16] , Finding small solutions to small degree polynomials, Cryptography and Lattices, Lecture Notes in Computer Science, vol. 2146, Springer-Verlag, Berlin, Heidelberg, 2001, pp. 20–31.
- <span id="page-27-7"></span>[17] D. Coppersmith, N. Howgrave-Graham, and S. V. Nagaraj, Divisors in residue classes, constructively, Math. Comp. 77 (2008), 531–545.
- <span id="page-27-9"></span>[18] N. Coxon, List decoding of number field codes, Des. Codes Cryptogr., to appear (published online with doi[:10.1007/s10623-013-9803-x\)](http://dx.doi.org/10.1007/s10623-013-9803-x).
- <span id="page-27-21"></span>[19] C. Fieker and M. E. Pohst, On lattices over number fields, Algorithmic Number Theory, Lecture Notes in Computer Science, vol. 1122, Springer-Verlag, Berlin, Heidelberg, 1996, pp. 133–139.
- <span id="page-27-22"></span>[20] C. Fieker and D. Stehl´e, Short bases of lattices over number fields, Algorithmic Number Theory, Lecture Notes in Computer Science, vol. 6197, Springer-Verlag, Berlin, Heidelberg, 2010, pp. 157–173.
- <span id="page-27-13"></span>[21] J. von zur Gathen, Hensel and Newton methods in valuation rings, Math. Comp. 42 (1984), 637–661.
- <span id="page-27-12"></span>[22] J. von zur Gathen and J. Gerhard, Modern Computer Algebra, second edition, Cambridge University Press, Cambridge, England, 2003.
- <span id="page-27-5"></span>[23] J. von zur Gathen and E. Kaltofen, Factorization of multivariate polynomials over finite fields, Math. Comp. 45 (1985).
- <span id="page-27-17"></span>[24] P. Giorgi, C.-P. Jeannerod, and G. Villard, On the complexity of polynomial matrix computations, Proceedings of the 2003 International Symposium on Symbolic and Algebraic Computation (Philadelphia, Pennsylvania, United States, August 3–6, 2003), Association for Computing Machinery, New York, NY, 2003, pp. 135–142.
- <span id="page-27-8"></span>[25] V. Guruswami, A. Sahai, and M. Sudan, "Soft-decision" decoding of Chinese remainder codes, Proceedings of the 41st Annual Symposium on Foundations of Computer Science (Redondo Beach, California, United States, November 12–14, 2000), IEEE Computer Society, Los Alamitos, CA, 2000, pp. 159–168.
- <span id="page-27-6"></span>[26] V. Guruswami and M. Sudan, Improved decoding of Reed-Solomon and algebraic-geometry codes, IEEE Trans. Inform. Theory 45 (1999), 1757–1767.
- <span id="page-27-1"></span>[27] N. Howgrave-Graham, Approximate integer common divisors, Cryptography and Lattices, Lecture Notes in Computer Science, vol. 2146, Springer-Verlag, Berlin, Heidelberg, 2001, pp. 51–66.
- <span id="page-27-11"></span>[28] M.-D. Huang and D. Ierardi, Efficient algorithms for the Riemann-Roch problem and for addition in the Jacobian of a curve, J. Symb. Comput. 18 (1994), 519–539.
- <span id="page-27-16"></span>[29] T. Kailath, Linear Systems, Prentice-Hall, Inc., Upper Saddle River, NJ, 1980.
- <span id="page-27-3"></span>[30] S. V. Konyagin and T. Steger, On polynomial congruences, Math. Notes 55 (1994), 596–600.
- <span id="page-27-20"></span>[31] A. K. Lenstra, Factoring polynomials over algebraic number fields, Computer Algebra, Lecture Notes in Computer Science, vol. 162, Springer-Verlag, Berlin, Heidelberg, 1983, pp. 245–254.
- <span id="page-27-4"></span>[32] , Factoring multivariate polynomials over algebraic number fields, SIAM J. Comput. 16 (1987), 591–598.
- <span id="page-27-18"></span>[33] H. W. Lenstra, Algorithms in algebraic number theory, Bull. Amer. Math. Soc. 26 (1992), 211–24.
- <span id="page-27-15"></span>[34] A. K. Lenstra, H. W. Lenstra, and L. Lov´asz, Factoring polynomials with rational coeficients, Math. Ann. 261 (1982), 515–534.
- <span id="page-27-23"></span>[35] D. Lorenzini, An invitation to arithmetic geometry, Graduate Studies in Mathematics, vol. 9, American Mathematical Society, Providence, RI, 1996.

- <span id="page-28-6"></span>[36] V. Lyubashevsky, C. Peikert, and O. Regev, On ideal lattices and learning with errors over rings, Advances in Cryptology – EUROCRYPT 2010, Lecture Notes in Computer Science, vol. 6110, Springer-Verlag, Berlin, Heidelberg, 2010, pp. 1–23.
- <span id="page-28-3"></span>[37] K. Manders and L. Adleman, NP-complete decision problems for quadratic polynomials, Proceedings of the Eighth Annual ACM Symposium on Theory of Computing (Hershey, Pennsylvania, United States, May 3–5, 1976), Association for Computing Machinery, New York, NY, 1976, pp. 23–29.
- <span id="page-28-8"></span>[38] R. C. Mason, Diophantine Equations over Function Fields, London Mathematical Society Lecture Note Series, vol. 96, Cambridge University Press, Cambridge, England, 1984.
- <span id="page-28-0"></span>[39] A. May, New RSA vulnerabilities using lattice reduction methods, Ph.D. thesis, University of Paderborn, 2003.
- <span id="page-28-2"></span>[40] A. May., Using LLL-reduction for solving RSA and factorization problems, The LLL Algorithm (P. Q. Nguyen and B. Vall´ee, eds.), Springer-Verlag, Berlin, Heidelberg, 2010, pp. 315–348.
- <span id="page-28-9"></span>[41] M. Naor and B. Pinkas, Oblivious transfer and polynomial evaluation, Proceedings of the Thirty-First Annual ACM Symposium on Theory of Computing (Atlanta, Georgia, United States, May 1–4, 1999), Association for Computing Machinery, New York, NY, 1999, pp. 245– 254.
- <span id="page-28-5"></span>[42] C. Peikert and A. Rosen, Lattices that admit logarithmic worst-case to average-case connection factors, Proceedings of the Thirty-Ninth Annual ACM Symposium on Theory of Computing (San Diego, California, United States, June 11–13, 2007), Association for Computing Machinery, New York, NY, 2007, pp. 478–487.
- <span id="page-28-12"></span>[43] M. Rosen, Number Theory in Function Fields, Graduate Texts in Mathematics, vol. 210, Springer-Verlag, New York, 2002.
- [44] R. M. Roth and G. Ruckenstein, Efficient decoding of Reed-Solomon codes beyond half the minimum distance, IEEE Trans. Inform. Theory 46 (2000), 246–257.
- <span id="page-28-7"></span>[45] M. A. Shokrollahi and H. Wasserman, List decoding of algebraic-geometric codes, IEEE Trans. Inform. Theory 45 (1999), 432–437.
- <span id="page-28-1"></span>[46] V. Shoup, OAEP reconsidered, Advances in Cryptology – CRYPTO 2001, Lecture Notes in Computer Science, vol. 2139, Springer-Verlag, Berlin, Heidelberg, 2001, pp. 239–259.
- <span id="page-28-11"></span>[47] H. Stichtenoth, Algebraic Function Fields and Codes, second edition, Graduate Texts in Mathematics, vol. 254, Springer-Verlag, Berlin, Heidelberg, 2010.
- <span id="page-28-4"></span>[48] M. Sudan, Ideal error-correcting codes: Unifying algebraic and number-theoretic algorithms, Applied Algebra, Algebraic Algorithms and Error-Correcting Codes, Lecture Notes in Computer Science, vol. 2227, Springer-Verlag, Berlin, Heidelberg, 2001, pp. 36–45.
- <span id="page-28-10"></span>[49] V. Vassilevska Williams, Multiplying matrices faster than Coppersmith-Winograd, Proceedings of the Fourty-Fourth ACM Symposium on Theory of Computing (New York, New York, United States, May 20–22, 2012), Association for Computing Machinery, New York, NY, 2012, pp. 887–898.

Microsoft Research New England, One Memorial Drive, Cambridge, MA 02142 E-mail address: cohn@microsoft.com

Department of Computer and Information Science, University of Pennsylvania, Philadelphia, PA 19104

E-mail address: nadiah@cs.princeton.edu