# Query-to-Communication Lifting for BPP

Mika Göös Harvard University and Simons Institute Toniann Pitassi University of Toronto Thomas Watson\*
University of Memphis

March 23, 2017

#### Abstract

For any n-bit boolean function f, we show that the randomized communication complexity of the composed function  $f \circ g^n$ , where g is an index gadget, is characterized by the randomized decision tree complexity of f. In particular, this means that many query complexity separations involving randomized models (e.g., classical vs. quantum) automatically imply analogous separations in communication complexity.

## 1 Introduction

A query-to-communication lifting theorem (a.k.a. communication-to-query simulation theorem) translates lower bounds on some type of query complexity (a.k.a. decision tree complexity) [Ver99, BdW02, Juk12] of a boolean function f into lower bounds on a corresponding type of communication complexity [KN97, Juk12, RY17] of a two-party version of f. See Table 1 for a list of several known results in this vein. In this work, we show a lifting theorem for bounded-error randomized (i.e., BPP-type) query/communication complexity. Such a theorem had been conjectured by [ABB+16b, BK16, CKLM17, WYY17] and (ad nauseam) by the current authors.

#### 1.1 Our result

For a function  $f: \{0,1\}^n \to \{0,1\}$  (called the *outer function*) and a two-party function  $g: \mathcal{X} \times \mathcal{Y} \to \{0,1\}$  (called the *gadget*), their composition  $f \circ g^n: \mathcal{X}^n \times \mathcal{Y}^n \to \{0,1\}$  is defined by

$$(f \circ g^n)(x,y) := f(g(x_1,y_1),\ldots,g(x_n,y_n)).$$

Here, Alice holds  $x \in \mathcal{X}^n$  and Bob holds  $y \in \mathcal{Y}^n$ . Our result is proved for the popular index gadget  $IND_m : [m] \times \{0,1\}^m \to \{0,1\}$  mapping  $(x,y) \mapsto y_x$ . We use  $\mathsf{BPP}^\mathsf{dt}$  and  $\mathsf{BPP}^\mathsf{cc}$  to denote the usual bounded-error randomized query and communication complexities. That is,  $\mathsf{BPP}^\mathsf{dt}(f)$  is the minimum cost of a randomized decision tree (distribution over deterministic decision trees) which, on each input z, outputs f(z) with probability at least 2/3, where the cost is the maximum number of queries over all inputs and outcomes of the randomness;  $\mathsf{BPP}^\mathsf{cc}(F)$  is defined similarly but with communication protocols instead of decision trees.

<span id="page-0-0"></span>**Theorem 1** (Lifting for BPP). Let  $m = m(n) := n^{256}$ . For every  $f : \{0,1\}^n \to \{0,1\}$ ,

$$\mathsf{BPP}^{\mathsf{cc}}(f \circ \mathsf{IND}_m^n) \ = \ \mathsf{BPP}^{\mathsf{dt}}(f) \cdot \Theta(\log n).$$

<sup>\*</sup>Supported by NSF grant CCF-1657377.

<span id="page-1-0"></span>

| Class                                                                        | Query model                                                                    | Communication model                                      | References                                                                                              |
|------------------------------------------------------------------------------|--------------------------------------------------------------------------------|----------------------------------------------------------|---------------------------------------------------------------------------------------------------------|
| Р                                                                            | deterministic                                                                  | deterministic                                            | [RM99, GPW15, dRNV16,<br>HHL16, WYY17, CKLM17]                                                          |
| $egin{aligned} NP \\ \mathit{many} \\ \mathit{many} \\ P^{NP} \end{aligned}$ | nondeterministic<br>polynomial degree<br>conical junta degree<br>decision list | nondeterministic rank nonnegative rank rectangle overlay | [GLM <sup>+</sup> 16, Göö15]<br>[SZ09, She11, RS10, RPRC16]<br>[GLM <sup>+</sup> 16, KMR17]<br>[GKPW17] |
|                                                                              | Sherali–Adams<br>sum-of-squares                                                | LP extension complexity<br>SDP extension complexity      | [CLRS16, KMR17]<br>[LRS15]                                                                              |

**Table 1:** Query-to-communication lifting theorems. The first five are formulated in the language of boolean functions (as in this paper); the last two are formulated in the language of combinatorial optimization.

#### 1.2 What does it mean?

The upshot of our lifting theorem is that it *automates* the task of proving randomized communication lower bounds: we only need to show a problem-specific query lower bound for f (which is often relatively simple), and then invoke the general-purpose lifting theorem to completely characterize the randomized communication complexity of  $f \circ \text{IND}_m^n$ .

**Separation results.** The lifting theorem is especially useful for constructing examples of two-party functions that have large randomized communication complexity, but low complexity in some other communication model. For example, one of the main results of Anshu et al. [ABB+16b] is a nearly 2.5-th power separation between randomized and quantum (BQP<sup>cc</sup>) communication complexities for a total function F:

<span id="page-1-1"></span>
$$\mathsf{BPP^{cc}}(F) \ge \mathsf{BQP^{cc}}(F)^{2.5 - o(1)}. \tag{1}$$

Previously, a quadratic separation was known (witnessed by set-disjointness). The construction of F (and its ad hoc analysis) in [ABB<sup>+</sup>16b] was closely modeled after an analogous query complexity separation,  $\mathsf{BPP}^{\mathsf{dt}}(f) \geq \mathsf{BQP}^{\mathsf{dt}}(f)^{2.5-o(1)}$ , shown earlier by [ABK16]. Our lifting theorem can reproduce the separation (1) by simply taking  $F := f \circ \mathsf{IND}_m^n$  and using the query result of [ABK16] as a black-box. Here we only note that  $\mathsf{BQP}^{\mathsf{cc}}(F)$  is at most a logarithmic factor larger than  $\mathsf{BQP}^{\mathsf{dt}}(f)$ , since a protocol can always efficiently simulate a decision tree.

In a similar fashion, we can unify (and in some cases simplify) several other existing results in communication complexity [Raz99, GJPW15, ABB+16b, BR17], including separations between BPP<sup>cc</sup> and the log of the partition number; see Section 5 for details. At the time of the writing, we are not aware of any *new* applications implied by our lifting theorem.

Gadget size. A drawback with our lifting theorem is that it assumes gadget size m = poly(n), which limits its applicability. For example, we are not able to reproduce tight randomized lower bounds for important functions such as set-disjointness [KS92, Raz92, BJKS04] or gap-Hamming [CR12, She12, Vid13]. It remains an open problem to prove a lifting theorem for m = O(1) even for the models studied in [GLM<sup>+</sup>16, KMR17].

## 2 Reformulation

Our lifting theorem holds for all f, even if f is a partial function or a general relation (search problem). Thus the theorem is not really about the outer function at all; it is about the obfuscating ability of the index gadget Ind<sup>m</sup> to hide information about the input bits of f. To focus on what is essential, let us reformulate the lifting theorem in a more abstract way that makes no reference to f.

#### 2.1 Slices

Write G := g n for g := Indm. We view G's input domain [m] <sup>n</sup> × ({0, 1} m) <sup>n</sup> as being partitioned into slices G−<sup>1</sup> (z) = {(x, y) : G(x, y) = z}, one for each z ∈ {0, 1} n ; see (a) below. We will eventually consider randomized protocols, but suppose for simplicity that we are given a deterministic protocol Π of communication cost |Π|. The most basic fact about Π is that it induces a partition of the input domain into at most 2|Π<sup>|</sup> rectangles (sets of the form X × Y where X ⊆ [m] n , Y ⊆ ({0, 1} m) n ); see (b) below. The rectangles are in 1-to-1 correspondence with the leaves of the protocol tree, which are in 1-to-1 correspondence with the protocol's transcripts (root-to-leaf paths; each path is a concatenation of messages). Fixing some z ∈ {0, 1} n , we are interested in the distribution over transcripts that is generated when Π is run on a uniform random input from the slice G−<sup>1</sup> (z); see (c) below.

![](_page_2_Picture_4.jpeg)

## 2.2 The reformulation

We devise a randomized decision tree that on input z outputs a random transcript distributed close (in total variation distance) to that generated by Π on input (x, y) ∼ G−<sup>1</sup> (z). (We always use boldface letters for random variables.)

<span id="page-2-0"></span>Theorem 2. Let Π be a deterministic protocol with inputs from the domain of G = g n . There is a randomized decision tree of cost O(|Π|/ log n) that on input z ∈ {0, 1} n samples a random transcript (or outputs ⊥ for failure) such that the following two distributions are o(1)-close:

tz := output distribution of the randomized decision tree on input z,

t 0 z := transcript generated by Π when run on a random input (x, y) ∼ G −1 (z).

Moreover, the simulation has "one-sided error": supp(tz) ⊆ supp(t 0 z ) ∪ {⊥} for every z.

The lifting theorem [\(Theorem 1\)](#page-0-0) follows as a simple consequence of the above reformulation. For the easy direction ("≤"), any randomized decision tree for f making c queries can be converted into a randomized protocol for f ◦ g n communicating c · O(log n) bits, where the O(log n) factor is the deterministic communication complexity of the gadget. For the nontrivial direction ("≥"), suppose we have a randomized protocol Π (viewed as a probability distribution over deterministic protocols) that computes f ◦ g n (with error ≤ 1/3, say) and each Π ∼ Π communicates at most |Π| ≤ c bits. We convert this into a randomized decision tree for f of query cost O(c/ log n) as follows.

On input z:

- (1) Pick a deterministic Π ∼ Π (using random coins of the decision tree).
- (2) Run the randomized decision tree for Π from [Theorem 2](#page-2-0) that samples a transcript t ∼ tz(Π).
- (3) Output the value of the leaf reached in t.

The resulting decision tree has bounded error on input z:

$$\begin{aligned} \mathbf{Pr}[\text{ output of decision tree} &\neq f(z)] &= &\mathbf{E}_{\Pi \sim \mathbf{\Pi}} \big[ \mathbf{Pr}_{t \sim t_z(\Pi)} [\text{ value of leaf in } t \neq f(z)] \big] \\ &= &\mathbf{E}_{\Pi \sim \mathbf{\Pi}} \big[ \mathbf{Pr}_{t \sim t_z'(\Pi)} [\text{ value of leaf in } t \neq f(z)] \pm o(1) \big] \\ &= &\mathbf{E}_{\Pi \sim \mathbf{\Pi}} \big[ \mathbf{Pr}_{(\boldsymbol{x}, \boldsymbol{y}) \sim G^{-1}(z)} [\Pi(\boldsymbol{x}, \boldsymbol{y}) \neq f(z)] \big] \pm o(1) \\ &= &\mathbf{E}_{(\boldsymbol{x}, \boldsymbol{y}) \sim G^{-1}(z)} \big[ \mathbf{Pr}_{\mathbf{\Pi}} [\Pi(\boldsymbol{x}, \boldsymbol{y}) \neq f(z)] \big] \pm o(1) \\ &\leq &\mathbf{E}_{(\boldsymbol{x}, \boldsymbol{y}) \sim G^{-1}(z)} [1/3] \pm o(1) \\ &\leq &1/3 + o(1). \end{aligned}$$

#### 2.3 Extensions

The correctness of our simulation hinged on the property of BPP-type algorithms that the mixture of correct output distributions is correct. In fact, the "moreover" part in [Theorem 2](#page-2-0) allows us to get a lifting theorem for one-sided error (RP-type) and zero-sided error (ZPP-type) query/communication complexity: if the randomized protocol Π on every input (x, y) ∈ G−<sup>1</sup> (z) outputs values in {f(z), ⊥}, so does our decision tree simulation on input z. Funnily enough, it was previously known that the existence of a query-to-communication lifting theorem for ZPP (for index gadget) implies the existence of a lifting theorem for BPP in a black-box fashion [\[BK16\]](#page-18-0). We also mention that [Theorem 2](#page-2-0) in fact holds with 1/poly(n)-closeness (instead of o(1)) for an arbitrarily high degree polynomial, provided m is chosen to be a correspondingly high enough degree polynomial in n.

## 3 Simulation

We now prove [Theorem 2.](#page-2-0) Fix a deterministic protocol Π henceforth. We start with a high-level sketch of the simulation, and then fill in the details.

#### 3.1 Executive summary

The randomized decision tree will generate a random transcript of Π by taking a random walk down the protocol tree of Π, guided by occasional queries to the bits of z. The design of our random walk is dictated by one (and only one) property of the slice sets G−<sup>1</sup> (z):

#### Uniform marginals lemma (informal):

For every z ∈ {0, 1} <sup>n</sup> and every rectangle X × Y where X is "dense" and Y is "large", the uniform distribution on G−<sup>1</sup> (z)∩X×Y has both of its marginal distributions close to uniform on X and Y , respectively.

![](_page_3_Figure_15.jpeg)

This immediately suggests a way to begin the randomized simulation. Each node of  $\Pi$ 's protocol tree is associated with a rectangle  $X \times Y$  of all inputs that reach that node. We start at the root where, initially,  $X \times Y = [m]^n \times (\{0,1\}^m)^n$ . Suppose Alice communicates the first bit  $b \in \{0,1\}$ . This induces a partition  $X = X^0 \cup X^1$  where  $X^b$  consists of those inputs where Alice sends b. When  $\Pi$  is run on a random input  $(\boldsymbol{x},\boldsymbol{y}) \sim G^{-1}(z)$ , the above lemma states that  $\boldsymbol{x}$  is close to uniform on X and hence the branch  $X^b$  is taken with probability roughly  $|X^b|/|X|$ . Our idea for a simulation is this: we pretend that  $\boldsymbol{x} \sim X$  is perfectly uniform so that our simulation takes the branch  $X^b$  with probability exactly  $|X^b|/|X|$ . It follows that the first bit sent in the two scenarios  $(\boldsymbol{t}_z \text{ and } \boldsymbol{t}_z')$  is distributed close to each other. We can continue the simulation in the same manner, updating  $X \leftarrow X^b$  (and similarly  $Y \leftarrow Y^b$  when Bob speaks), as long as  $X \times Y$  remains "dense  $\times$  large".

**Largeness.** A convenient property of the index gadget is that Bob's nm-bit input is much longer than Alice's  $n \log m$ -bit input. Consequently, the simulation will not need to go out of its way to maintain the "largeness" of Bob's set Y—we will argue that it naturally remains "large" enough with high probability throughout the simulation.

**Density.** The interesting case is when Alice's set X ceases to be "dense". Our idea is to promptly restore "density" by computing a *density-restoring* partition  $X = \bigcup_i X^i$  with the property that each  $X^i$  is fixed on some subset of blocks  $I_i \subseteq [n]$  (which "caused" a density violation), and such that  $X^i$  is again "dense" on the remaining blocks  $[n] \setminus I_i$ . Moreover,  $|I_i|$  will typically be bounded in terms of the number of bits communicated so far.

After Alice has partitioned  $X = \bigcup_i X^i$  we will follow the branch  $X^i$  (updating  $X \leftarrow X^i$ ) with probability  $|X^i|/|X|$ ; this random choice is justified by the uniform marginals lemma, since it imitates what would happen on a uniform random input from  $G^{-1}(z)$ . Since we made Alice's pointers  $X^i_{I_i}$  fixed, say, to value  $\alpha \in [m]^{I_i}$ , we need to fix the corresponding pointed-to bits on Bob's side so as to make the output of the gadgets  $g^n(X^i,Y)$  consistent with z on the fixed coordinates. At this point, our decision tree queries all the bits  $z_{I_i} \in \{0,1\}^{I_i}$  and we argue that we can indeed typically restrict Bob's set to some still-"large"  $Y^i \subseteq Y$  to ensure  $g^{I_i}(X^i_{I_i} \times Y^i_{I_i}) = \{z_{I_i}\}$ . Now that we have recovered "density" on the unfixed blocks, we may continue the simulation as before (relativized to unfixed blocks).

#### 3.2 Tools

Let us make the notions of "dense" and "large" precise. Let  $\mathbf{H}_{\infty}(x) := \min_{x} \log(1/\mathbf{Pr}[x=x])$  denote the usual min-entropy of a random variable x. Supposing x is distributed over a set X, we define the *deficiency* of x as the nonnegative quantity  $\mathbf{D}_{\infty}(x) := \log |X| - \mathbf{H}_{\infty}(x)$ . A basic property, which we use freely and repeatedly throughout the proof, is that marginalizing x to some coordinates (assuming X is a product set) cannot increase the deficiency. For a set X we use the boldface X to denote a random variable uniformly distributed on X.

<span id="page-4-1"></span>**Definition 1** (Blockwise-density [GLM<sup>+</sup>16]). A random variable  $\mathbf{x} \in [m]^J$  (where J is some index set) is called  $\delta$ -dense if for every nonempty  $I \subseteq J$ , the blocks  $\mathbf{x}_I$  have min-entropy rate at least  $\delta$ , that is,  $\mathbf{H}_{\infty}(\mathbf{x}_I) \geq \delta \cdot |I| \log m$ . (Note that  $\mathbf{x}_I$  is marginally distributed over  $[m]^I$ .)

<span id="page-4-0"></span>**Lemma 3** (Uniform marginals; simple version). Suppose X is 0.9-dense and  $\mathbf{D}_{\infty}(Y) \leq n^3$ . Then for any  $z \in \{0,1\}^n$ , the uniform distribution on  $G^{-1}(z) \cap X \times Y$  (which is nonempty) has both of its marginal distributions  $1/n^2$ -close to uniform on X and Y, respectively.

We postpone the proof of the lemma to Section 4, and instead concentrate here on the simulation itself—its correctness will mostly rely on this lemma. Actually, we need a slightly more generallooking statement that we can easily apply when some blocks in X have become fixed during the simulation. To this end, we introduce terminology for such rectangles  $X \times Y$ . Note that Lemma 4 below specializes to Lemma 3 by taking  $\rho = *^n$ .

**Definition 2** (Structured rectangles). For a partial assignment  $\rho \in \{0, 1, *\}^n$ , define its *free* positions as free  $\rho := \rho^{-1}(*) \subseteq [n]$ , and its fixed positions as fix  $\rho := [n] \setminus \text{free } \rho$ . A rectangle  $X \times Y$  is called  $\rho$ -structured if  $\mathbf{X}_{\text{free }\rho}$  is 0.9-dense,  $\mathbf{X}_{\text{fix }\rho}$  is fixed, and each output in  $G(X\times Y)$  is consistent with  $\rho$ .

<span id="page-5-0"></span>**Lemma 4** (Uniform marginals; general version). Suppose  $X \times Y$  is  $\rho$ -structured and  $\mathbf{D}_{\infty}(Y) \leq n^3$ . Then for any  $z \in \{0,1\}^n$  consistent with  $\rho$ , the uniform distribution on  $G^{-1}(z) \cap X \times Y$  (which is nonempty) has both of its marginal distributions  $1/n^2$ -close to uniform on X and Y, respectively.

![](_page_5_Figure_3.jpeg)

Illustration of  $x \sim X$  and  $y \sim Y$  where  $X \times Y$  is  $\rho$ -structured for  $\rho := 10**$ 

#### <span id="page-5-1"></span>3.3 Density-restoring partition

Fix some set  $X \subseteq [m]^J$ . (In our application,  $J \subseteq [n]$  will correspond to the set of free blocks during the simulation.) We describe a procedure that takes X and outputs a density-restoring partition  $X = \bigcup_i X^i$  such that each  $X^i$  is fixed on some subset of blocks  $I_i \subseteq J$  and 0.9-dense on  $J \setminus I_i$ . The procedure associates a label of the form " $x_{I_i} = \alpha_i$ " with each part  $X_i$ , recording which blocks we fixed and to what value. If X is already 0.9-dense, the procedure outputs just one part: X itself.

While X is nonempty:

- (1) Let  $I \subseteq J$  be a maximal subset (possibly  $I = \emptyset$ ) such that  $X_I$  has min-entropy rate < 0.9, and let  $\alpha \in [m]^I$  be an outcome witnessing this:  $\mathbf{Pr}[X_I = \alpha] > m^{-0.9|I|}$ .

  (2) Output part  $X^{(x_I = \alpha)} := \{x \in X : x_I = \alpha\}$  with label " $x_I = \alpha$ ".
- (3) Update  $X \leftarrow X \setminus X^{(x_I = \alpha)}$ .

![](_page_5_Figure_11.jpeg)

We collect below the key properties of the partition  $X = \bigcup_i X^i$  output by the procedure. Firstly, the partition indeed restores blockwise-density for the unfixed blocks. Secondly, the deficiency (relative to unfixed blocks) typically decreases proportional to the number of blocks we fixed.

<span id="page-6-1"></span>**Lemma 5.** Each  $X^i$  (labeled " $x_{I_i} = \alpha_i$ ") in the density-restoring partition satisfies the following.

(Density): 
$$\mathbf{X}_{J \setminus I_i}^i$$
 is 0.9-dense  
(Deficiency):  $\mathbf{D}_{\infty}(\mathbf{X}_{J \setminus I_i}^i) \leq \mathbf{D}_{\infty}(\mathbf{X}) - 0.1|I_i|\log m + \delta_i$  where  $\delta_i \coloneqq \log(|X|/|\cup_{j \geq i} X^j|)$ 

*Proof.* Write  $X^{\geqslant i} := \bigcup_{j \geq i} X^j$  so that  $X^i = (X^{\geqslant i} \mid X_{I_i}^{\geqslant i} = \alpha_i)$ . Suppose for contradiction that some part  $X^i$  was not 0.9-dense on  $J \setminus I_i$ . Then there is some nonempty  $K \subseteq J \setminus I_i$  and an outcome  $\beta \in [m]^K$  violating the min-entropy condition:  $\Pr[X_K^i = \beta] > m^{-0.9|K|}$ . But this contradicts the maximality of  $I_i$  since the larger set  $I_i \cup K$  now violates the min-entropy condition for  $X^{\geqslant i}$ :

$$\mathbf{Pr}[\boldsymbol{X}_{I_{i}\cup K}^{\geqslant i} = \alpha_{i}\beta] = \mathbf{Pr}[\boldsymbol{X}_{I_{i}}^{\geqslant i} = \alpha_{i}] \cdot \mathbf{Pr}[\boldsymbol{X}_{K}^{i} = \beta] > m^{-0.9|I_{i}|} \cdot m^{-0.9|K|} = m^{-0.9|I_{i}\cup K|}.$$

This proves the first part. The second part is a straightforward calculation (intuitively, going from X to  $X^{\geqslant i}$  causes a  $\delta_i$  increase in deficiency, going from  $X^{\geqslant i}$  to  $X^i$  causes a  $\leq 0.9|I_i|\log m$  increase, and restricting from J to  $J \setminus I_i$  causes a  $|I_i|\log m$  decrease):

$$\mathbf{D}_{\infty}(\boldsymbol{X}_{J \setminus I_{i}}^{i}) = |J \setminus I_{i}|\log m - \log |X^{i}|$$

$$\leq (|J|\log m - |I_{i}|\log m) - \log(|X^{\geqslant i}| \cdot 2^{-0.9|I_{i}|\log m})$$

$$= (|J|\log m - \log |X|) - 0.1|I_{i}|\log m + \log(|X|/|X^{\geqslant i}|)$$

$$= \mathbf{D}_{\infty}(\boldsymbol{X}) - 0.1|I_{i}|\log m + \delta_{i}.$$

#### 3.4 The simulation

To describe our simulation in a convenient language, we modify the deterministic protocol  $\Pi$  into a refined deterministic protocol  $\overline{\Pi}$ ; see Figure 1. Namely, we insert two new rounds of communication whose sole purpose is to restore density for Alice's free blocks by fixing some other blocks and Bob's corresponding bits. In short, we maintain the rectangle  $X \times Y$  as  $\rho$ -structured for some  $\rho$ . Each communication round of  $\Pi$  is thus replaced with a whole iteration in  $\overline{\Pi}$ . The new communication rounds do not affect the input/output behavior of the original protocol: any transcript of  $\overline{\Pi}$  can be projected back to a transcript of  $\Pi$  (by ignoring messages sent on lines 14, 16). One way to think about  $\overline{\Pi}$  is that it induces a partition of the communication matrix that is a refinement of the one  $\Pi$  induces. Therefore, for the purpose of proving Theorem 2, we can concentrate on simulating  $\overline{\Pi}$  in place of  $\Pi$ . The randomized decision tree becomes simple to describe relative to  $\overline{\Pi}$ ; see Figure 2.

Next, we proceed to show that our randomized decision tree is (1) correct: on input z it samples a transcript distributed close to that of  $\overline{\Pi}$  when run on  $(x, y) \sim G^{-1}(z)$ , and (2) efficient: the number of queries it makes is bounded in terms of  $|\Pi|$  (the number of iterations in  $\overline{\Pi}$ ).

#### 3.5 Correctness: Transcript distribution

We show that for every  $z \in \{0,1\}^n$  the following distributions are o(1)-close:

 $t := \text{transcript generated by our simulation of } \overline{\Pi} \text{ with query access to } z,$ 

 $t' := \text{transcript generated by } \overline{\Pi} \text{ when run on a random input from } G^{-1}(z).$ 

The following is the heart of the argument.

<span id="page-6-0"></span>**Lemma 6.** Consider a node v at the beginning of an iteration in  $\overline{\Pi}$ 's protocol tree, such that z is consistent with the associated  $\rho$ . Suppose  $X \times Y$  is the  $\rho$ -structured rectangle at v, and assume that  $\mathbf{D}_{\infty}(Y) \leq n^3$ . Let m and m' denote the messages sent in this iteration under t and t' respectively (conditioned on reaching v). Then

```
Refined protocol \overline{\Pi} on input (x,y):
  1: initialize: v = \text{root of } \Pi, X \times Y = [m]^n \times (\{0,1\}^m)^n, \rho = *^n
 2: while v is not a leaf [invariant: X \times Y is \rho-structured]
          let v_0, v_1 be the children of v
          if Bob sends a bit at v then
 4:
               let Y = Y^0 \cup Y^1 be the partition according to Bob's function at v
 5:
               let b be such that y \in Y^b
 6:
            \triangleright Bob sends b and we update Y \leftarrow Y^b, v \leftarrow v_b
 7:
          else Alice sends a bit at v
 8:
               let X = X^0 \cup X^1 be the partition according to Alice's function at v
 9:
               let b be such that x \in X^b
10:
            \triangleright Alice sends b and we update X \leftarrow X^b, v \leftarrow v_b
11:
               let X = \bigcup_i X^i be such that X_{\operatorname{free}\rho} = \bigcup_i X^i_{\operatorname{free}\rho} is a density-restoring partition let i be such that x \in X^i and suppose X^i_{\operatorname{free}\rho} is labeled "x_I = \alpha", I \subseteq \operatorname{free}\rho
            \triangleright Alice sends i and we update X \leftarrow X^i
14:
               let s = g^{I}(\alpha, y_{I}) \in \{0, 1\}^{I}
15:
            ▶ Bob sends s and we update Y \leftarrow \{y' \in Y : g^I(\alpha, y_I') = s\}, \rho_I \leftarrow s
17:
          end if
18: end while
19: output the value of the leaf v
```

**Figure 1:** The refined (deterministic) protocol  $\overline{\Pi}$ . The protocol explicitly keeps track of a rectangle  $X \times Y$  consisting of all inputs that reach the current node (i.e., produce the same transcript so far). The original protocol  $\Pi$  can be recovered by simply ignoring lines 12–16 and text in **red**. The purpose of lines 12–16 is to maintain the invariant; they do not affect the input/output behavior.

#### <span id="page-7-1"></span>Randomized decision tree on input z:

To generate a transcript of  $\overline{\Pi}$  we take a random walk down  $\overline{\Pi}$ 's protocol tree, guided by queries to the bits of z. The following defines the distribution of messages to send at each underlined line.

**Lines marked** ' $\triangleright$ ': We simulate an iteration of the protocol  $\overline{\Pi}$  pretending that  $x \sim X$  and  $y \sim Y$  are uniformly distributed over their domains. Namely, in line 7, we send b with probability  $|Y^b|/|Y|$ ; in line 11, we send b with probability  $|X^b|/|X|$ ; in line 14 (after having updated  $X \leftarrow X^b$ ), we send i with probability  $|X^i|/|X|$ .

**Line marked '>':** Here we query  $z_I$  and send deterministically the message  $s = z_I$ ; except if this message is impossible to send (because  $z_I \notin g^I(\alpha, Y_I)$ ), we output  $\bot$  and halt the simulation with failure.

Figure 2: The randomized decision tree with query access to z. Its goal is to generate a random transcript of  $\overline{\Pi}$  that is o(1)-close to the transcript generated by  $\overline{\Pi}$  on a random input  $(x, y) \sim G^{-1}(z)$ .

- (i)  $\mathbf{m}$  and  $\mathbf{m}'$  are  $1/n^2$ -close,
- (ii) with probability at least  $1 4/n^2$  over m, at least a  $2^{-(n \log m + 2)}$  fraction of Y is retained.

Before proving the lemma, let us use it to show that t and t' are o(1)-close. For this, it suffices to exhibit a coupling such that  $\mathbf{Pr}[t=t'] \geq 1 - o(1)$ . Our coupling works as follows:

Begin at the root, and for each iteration of  $\overline{\Pi}$ :

- (1) Sample this iteration's messages m and m' according to an optimal coupling.
- (2) If  $m \neq m'$ , or if m results in  $< 2^{-(n \log m + 2)}$  fraction of Y being retained (this includes the simulation's failure case), then proceed to sample the rest of t and t' independently.

It follows by induction on k that after the k-th iteration, with probability at least  $1 - k \cdot 5/n^2$ ,

- (I) t and t' match so far,
- (II)  $\mathbf{D}_{\infty}(Y) \leq k \cdot (n \log m + 2) \leq n^3$  where Y is Bob's set under t so far.

This trivially holds for k = 0. For k > 0, conditioned on (I) and (II) for iteration k - 1, the assumptions of Lemma 6 are met and hence  $\Pr[\mathbf{m} = \mathbf{m}'] \ge 1 - 1/n^2$  and

$$\Pr[\mathbf{D}_{\infty}(Y) \le (k-1) \cdot (n \log m + 2) + (n \log m + 2) = k \cdot (n \log m + 2)] \ge 1 - 4/n^2$$

By a union bound, with probability  $\geq 1 - 5/n^2$ , (I) and (II) continue to hold. Thus,

$$\mathbf{Pr}[\mathrm{(I) \ and \ (II) \ hold \ after \ the \ } k\text{-th iteration}] \ \geq \ (1-(k-1)\cdot 5/n^2)\cdot (1-5/n^2) \ \geq \ 1-k\cdot 5/n^2.$$

Since there are at most  $n \log m$  iterations, we indeed always have  $k \cdot (n \log m + 2) \le n^3$  (in (II)), and in the end we have  $\Pr[t = t'] \ge 1 - (n \log m) \cdot 5/n^2 \ge 1 - o(1)$  and thus t and t' are o(1)-close.

*Proof of Lemma 6.* Let  $\mathbf{x} := \mathbf{X}$  be uniform over X, and  $\mathbf{y} := \mathbf{Y}$  be uniform over Y, and  $(\mathbf{x}', \mathbf{y}')$  be uniform over  $G^{-1}(z) \cap X \times Y$ . By Lemma 4,  $\mathbf{x}$  and  $\mathbf{x}'$  are  $1/n^2$ -close, and  $\mathbf{y}$  and  $\mathbf{y}'$  are  $1/n^2$ -close.

First assume Bob sends a bit at v. Then m is some deterministic function of y, and m' is the same deterministic function of y' (the bit sent on line 7); thus m and m' are  $1/n^2$ -close since y and y' are. Also, the second property in the lemma statement trivially holds.

Henceforth assume Alice sends a bit at v. Write m = bis (jointly distributed with x) and m' = b'i's' (jointly distributed with (x', y')) as the concatenation of the three messages sent (on lines 11, 14, 16). Then bis is some deterministic function of x, and b'i's' is the same deterministic function of x' (s and s' depend on s, which is fixed); thus s and s' are  $1/n^2$ -close since s and s' are. A subtlety here is that there may be outcomes of s for which s is not defined (there is no corresponding child in  $\overline{\Pi}$ 's protocol tree, since Bob's set would become empty), in which case our randomized decision tree fails and outputs s. But such outcomes have 0 probability under s is still safe to say s and s are s and s if it is undefined.

We turn to verifying the second property. Define  $X^{bi} \times Y^{bi} \subseteq X \times Y$  as the rectangle at the end of the iteration if Alice sends b and i, and note that  $\boldsymbol{x} \in X^{bi}$  and  $\boldsymbol{x}' \in X^{b'i'}$ . There is a coupling of  $\boldsymbol{y}$  and  $\boldsymbol{y}'$  such that  $\Pr[\boldsymbol{y} \neq \boldsymbol{y}'] \leq 1/n^2$ ; we may imagine that  $\boldsymbol{y}$  is jointly distributed with  $(\boldsymbol{x}', \boldsymbol{y}')$ : sample  $(\boldsymbol{x}', \boldsymbol{y}')$  and then conditioned on the outcome of  $\boldsymbol{y}'$ , sample  $\boldsymbol{y}$  according to the coupling. Note that for each bi,

$$\mathbf{Pr}[\boldsymbol{y} \in Y^{bi}] \geq \mathbf{Pr}[\boldsymbol{y} \in Y^{bi} \mid \boldsymbol{x}' \in X^{bi}] \cdot \mathbf{Pr}[\boldsymbol{x}' \in X^{bi}] \geq \mathbf{Pr}[\boldsymbol{y} = \boldsymbol{y}' \mid \boldsymbol{x}' \in X^{bi}] \cdot \mathbf{Pr}[\boldsymbol{x}' \in X^{bi}]$$
(since  $\boldsymbol{x}' \in X^{bi}$  implies  $\boldsymbol{y}' \in Y^{bi}$ ), and so

<span id="page-8-0"></span>
$$\mathbf{Pr}_{bi \sim b'i'} \left[ \mathbf{Pr} [\boldsymbol{y} \in \boldsymbol{Y}^{bi}] < \mathbf{Pr} [\boldsymbol{x}' \in \boldsymbol{X}^{bi}] / 2 \right] \leq \mathbf{Pr}_{bi \sim b'i'} \left[ \mathbf{Pr} [\boldsymbol{y} \neq \boldsymbol{y}' \mid \boldsymbol{x}' \in \boldsymbol{X}^{bi}] \geq 1 / 2 \right] \leq 2 / n^2. \quad (2)$$

It is also straightforward to check that

<span id="page-9-0"></span>
$$\mathbf{Pr}_{bi \sim b'i'} \left[ \mathbf{Pr}[\mathbf{x}' \in X^{bi}] < \mathbf{Pr}[\mathbf{x} \in X^{bi}]/2 \right] \le 1/n^2.$$
 (3)

Since trivially Pr[x ∈ Xbi] ≥ 1/|X| ≥ 2 <sup>−</sup><sup>n</sup> log <sup>m</sup>, combining [\(2\)](#page-8-0) and [\(3\)](#page-9-0) we have

$$\begin{aligned}
&\mathbf{Pr}_{bi\sim bi}\big[\mathbf{Pr}[\boldsymbol{y}\in Y^{bi}] < 2^{-(n\log m + 2)}\big] \\
&\leq \mathbf{Pr}_{bi\sim b'i'}\big[\mathbf{Pr}[\boldsymbol{y}\in Y^{bi}] < 2^{-(n\log m + 2)}\big] + 1/n^{2} \\
&\leq \mathbf{Pr}_{bi\sim b'i'}\big[\mathbf{Pr}[\boldsymbol{y}\in Y^{bi}] < \mathbf{Pr}[\boldsymbol{x}\in X^{bi}]/4\big] + 1/n^{2} \\
&\leq \mathbf{Pr}_{bi\sim b'i'}\big[\mathbf{Pr}[\boldsymbol{y}\in Y^{bi}] < \mathbf{Pr}[\boldsymbol{x}'\in X^{bi}]/2 \text{ or } \mathbf{Pr}[\boldsymbol{x}'\in X^{bi}] < \mathbf{Pr}[\boldsymbol{x}\in X^{bi}]/2\big] + 1/n^{2} \\
&\leq 2/n^{2} + 1/n^{2} + 1/n^{2}.
\end{aligned}$$

"One-sided error". One more detail to iron out is the "moreover" part in the statement of [Theorem 2.](#page-2-0) The simulation we described does not quite satisfy this condition, but this is simple to fix: instead of halting with failure only when Y becomes empty, we actually halt with failure when D∞(Y ) > n<sup>3</sup> . This does not affect the correctness or efficiency analysis at all, but it ensures that we only output a transcript if X × Y is ρ-structured and D∞(Y ) ≤ n <sup>3</sup> at the end, which by [Lemma 4](#page-5-0) guarantees that the transcript's rectangle intersects the slice G−<sup>1</sup> (z) and thus t ∈ supp(t 0 ).

#### 3.6 Efficiency: Number of queries

We show that our randomized decision tree makes O(|Π|/ log n) queries with high probability. If we insist on a decision tree that always makes this many queries (to match the statement of [Theorem 2\)](#page-2-0), we may terminate the execution early (with output ⊥) whenever we exceed the threshold. This would incur only a small additional loss in the closeness of transcript distributions.

Lemma 7. The simulation makes O(|Π|/ log n) queries with probability ≥ 1 − min(2−|Π<sup>|</sup> , 1/nΩ(1)).

Proof. During the simulation, we view the quantity D∞(Xfree <sup>ρ</sup>) ≥ 0 as a nonnegative potential function. Consider a single iteration where lines 11, 14, 16 modify the sets X and free ρ.

- − In line 11, we shrink X = X<sup>0</sup> ∪ X<sup>1</sup> down to X<sup>b</sup> where Pr[b = b] = |X<sup>b</sup> |/|X|. Hence the increase in the potential function is γ<sup>b</sup> := log(|X|/|X<sup>b</sup> |).
- − In line 14 (after X ← X<sup>b</sup> ), we shrink X = S <sup>i</sup> X<sup>i</sup> down to X<sup>i</sup> where Pr[i = i] = |X<sup>i</sup> |/|X|. Moreover, in line 16, |free ρ| decreases by the number of bits we query. [Lemma 5](#page-6-1) says that the potential changes by δ<sup>i</sup> −Ω(log n)·#(queries in this iteration) where δ<sup>i</sup> := log(|X|/|∪j≥<sup>i</sup> X<sup>j</sup> |).

We will see later that for any iteration, E[γb], E[δ<sup>i</sup> ] ≤ O(1).

For j = 1, . . . , |Π|, letting γ<sup>j</sup> , δ<sup>j</sup> be the random variables γb, δ<sup>i</sup> respectively in the j-th iteration (and letting γ<sup>j</sup> = δ<sup>j</sup> = 0 for outcomes in which Alice does not communicate in the j-th iteration), the potential function at the end of the simulation is P j (γ<sup>j</sup> +δ<sup>j</sup> )−Ω(log n)·#(queries in total) ≥ 0 and hence

$$\mathbf{E}[\#(\text{queries in total})] \leq O(1/\log n) \cdot \sum_{j} (\mathbf{E}[\gamma_j] + \mathbf{E}[\boldsymbol{\delta}_j]) \leq O(|\Pi|/\log n).$$

By Markov's inequality, this already suffices to show that with probability ≥ 0.9 (say), the simulation uses O(|Π|/ log n) queries. To get a better concentration bound, we would like for the γ<sup>j</sup> , δ<sup>j</sup> variables (over all j) to be mutually independent, which they unfortunately generally are not. However, there is a trick to overcome this: we will define mutually independent random variables c<sup>j</sup> , d<sup>j</sup> (for all

- j) and couple them with the  $\gamma_j$ ,  $\delta_j$  variables in such a way that each  $\gamma_j \leq c_j$  and  $\delta_j \leq d_j$  with probability 1, and show that  $\sum_j (c_j + d_j)$  is bounded with very high probability, which implies the same for  $\sum_j (\gamma_j + \delta_j)$ . For each j, do the following.
  - Sample a uniform real  $\mathbf{p}_j \in [0,1)$  and define  $\mathbf{c}_j \coloneqq \log(1/\mathbf{p}_j) + \log(1/(1-\mathbf{p}_j))$  and let  $\gamma_j \coloneqq \gamma_b$  where  $\mathbf{b} = 0$  if  $\mathbf{p}_j \in [0, |X^0|/|X|)$  and  $\mathbf{b} = 1$  if  $\mathbf{p}_j \in [|X^0|/|X|, 1)$  (where  $X, X^0, X^1$  are the sets that arise in the first half of the j-th iteration, conditioned on the outcomes of previous iterations). Note that  $\gamma_j$  is correctly distributed, and that  $\gamma_j \leq \mathbf{c}_j$  with probability 1 (specifically, if  $\mathbf{b} = 0$  then  $\gamma_j = \log(|X|/|X^0|) \leq \log(1/\mathbf{p}_j) \leq \mathbf{c}_j$  and if  $\mathbf{b} = 1$  then  $\gamma_j = \log(|X|/|X^1|) \leq \log(1/(1-\mathbf{p}_j)) \leq \mathbf{c}_j$ . Also note that, as claimed earlier,  $\mathbf{E}[\gamma_j] \leq \mathbf{E}[\mathbf{c}_j] = \int_0^1 (\log(1/p) + \log(1/(1-p))) \, \mathrm{d}p = 2/\ln 2 \leq O(1)$ . For future use, note that  $\mathbf{E}[2^{\mathbf{c}_j/2}] = \int_0^1 (p(1-p))^{-1/2} \, \mathrm{d}p = \pi \leq O(1)$ .
  - Sample a uniform real  $\mathbf{q}_j \in [0,1)$  and define  $\mathbf{d}_j \coloneqq \log(1/(1-\mathbf{q}_j))$  and let  $\mathbf{\delta}_j \coloneqq \delta_i$  where i is such that  $\mathbf{q}_j$  falls in the i-th interval, assuming we have partitioned [0,1) into half-open intervals with lengths  $|X^i|/|X|$  in the natural left-to-right order (where  $X, X^1, X^2, \ldots$  are the sets that arise in the second half of the j-th iteration, conditioned on the outcomes of the first half and previous iterations). Note that  $\mathbf{\delta}_j$  is correctly distributed, and that  $\mathbf{\delta}_j \leq \mathbf{d}_j$  with probability 1 (specifically, if  $\mathbf{i} = i$  then  $\mathbf{\delta}_j = \log(|X|/|\cup_{j\geq i} X^j|) \leq \log(1/(1-\mathbf{q}_j)) = \mathbf{d}_j$ ). Also note that, as claimed earlier,  $\mathbf{E}[\mathbf{\delta}_j] \leq \mathbf{E}[\mathbf{d}_j] \leq \mathbf{E}[\mathbf{c}_j] \leq O(1)$ . For future use, note that  $\mathbf{E}[2^{\mathbf{d}_j/2}] \leq \mathbf{E}[2^{\mathbf{c}_j/2}] \leq O(1)$ .

Now for some sufficiently large constants C, C' we have

$$\begin{aligned} \mathbf{Pr} \big[ \# (\text{queries in total}) > C' \cdot |\Pi| / \log n \big] & \leq & \mathbf{Pr} \big[ \sum_{j} (\gamma_{j} + \boldsymbol{\delta}_{j}) > C \cdot |\Pi| \big] \\ & \leq & \mathbf{Pr} \big[ \sum_{j} (\boldsymbol{c}_{j} + \boldsymbol{d}_{j}) > C \cdot |\Pi| \big] \\ & = & \mathbf{Pr} \Big[ 2^{\sum_{j} (\boldsymbol{c}_{j} + \boldsymbol{d}_{j})/2} > 2^{C \cdot |\Pi|/2} \Big] \\ & \leq & \mathbf{E} \big[ 2^{\sum_{j} (\boldsymbol{c}_{j} + \boldsymbol{d}_{j})/2} \big] / 2^{C \cdot |\Pi|/2} \\ & = & \Big( \prod_{j} \mathbf{E} \big[ 2^{\boldsymbol{c}_{j}/2} \big] \cdot \mathbf{E} \big[ 2^{\boldsymbol{d}_{j}/2} \big] \Big) / 2^{C \cdot |\Pi|/2} \\ & \leq & (O(1)/2^{C/2})^{|\Pi|} \\ & \leq & 2^{-|\Pi|}. \end{aligned}$$

If  $|\Pi| \le o(\log n)$  then a similar calculation shows that  $\Pr[\#(\text{queries in total}) \ge 1] \le 1/n^{\Omega(1)}$ .  $\square$ 

## <span id="page-10-0"></span>4 Uniform Marginals Lemma

**Lemma 4** (Uniform marginals; general version). Suppose  $X \times Y$  is  $\rho$ -structured and  $\mathbf{D}_{\infty}(Y) \leq n^3$ . Then for any  $z \in \{0,1\}^n$  consistent with  $\rho$ , the uniform distribution on  $G^{-1}(z) \cap X \times Y$  (which is nonempty) has both of its marginal distributions  $1/n^2$ -close to uniform on X and Y, respectively.

We prove a slightly stronger statement formulated in Lemma 8 below. For terminology, we say a distribution  $\mathcal{D}_1$  is  $\varepsilon$ -pointwise-close to a distribution  $\mathcal{D}_2$  if for every outcome, the probability under  $\mathcal{D}_1$  is within a factor  $1 \pm \varepsilon$  of the probability under  $\mathcal{D}_2$ . As a minor technicality (for the purpose of deriving Lemma 4 from Lemma 8), we say that a random variable  $\mathbf{x} \in [m]^J$  is  $\delta$ -essentially-dense if for every nonempty  $I \subseteq J$ ,  $\mathbf{H}_{\infty}(\mathbf{x}_I) \ge \delta \cdot |I| \log m - 1$  (the difference from Definition 1 is the "-1"); we also define  $\rho$ -essentially-structured in the same way as  $\rho$ -structured but requiring  $\mathbf{X}_{\text{free }\rho}$  to be

only 0.9-essentially-dense instead of 0.9-dense. The following strengthens a lemma from [GKPW17], which implied that G(X, Y) has full support over the set of all z consistent with  $\rho$ .

<span id="page-11-0"></span>**Lemma 8** (Pointwise uniformity). Suppose  $X \times Y$  is  $\rho$ -essentially-structured and  $\mathbf{D}_{\infty}(\mathbf{Y}) \leq n^3 + 1$ . Then  $G(\mathbf{X}, \mathbf{Y})$  is  $1/n^3$ -pointwise-close to the uniform distribution over the set of all z consistent with  $\rho$ .

Proof of Lemma 4. Let (x, y) be uniformly distributed over  $G^{-1}(z) \cap X \times Y$ . We show that x is  $1/n^2$ -close to X; a completely analogous argument works to show that y is  $1/n^2$ -close to Y. Let  $E \subseteq X$  be any test event. Replacing E by  $X \setminus E$  if necessary, we may assume  $|E| \ge |X|/2$ . Since  $X \times Y$  is  $\rho$ -structured,  $E \times Y$  is  $\rho$ -essentially-structured. Hence we can apply Lemma 8 in both the rectangles  $E \times Y$  and  $E \times Y$ :

$$\mathbf{Pr}[\mathbf{x} \in E] = \frac{|G^{-1}(z) \cap E \times Y|}{|G^{-1}(z) \cap X \times Y|} = \frac{(1 \pm 1/n^3) \cdot 2^{-|\text{free }\rho|} \cdot |E \times Y|}{(1 \pm 1/n^3) \cdot 2^{-|\text{free }\rho|} \cdot |X \times Y|} \\
= (1 \pm 3/n^3) \cdot |E|/|X| = |E|/|X| \pm 1/n^2. \qquad \Box$$

#### 4.1 Overview for Lemma 8

A version of Lemma 8 (for the inner-product gadget) was proved in [GLM+16, §2.2] under the assumption that X and Y had low deficiencies:  $\mathbf{D}_{\infty}(X_I), \mathbf{D}_{\infty}(Y_I) \leq O(|I| \log n)$  for free blocks I. The key difference is that we only assume  $\mathbf{D}_{\infty}(Y_I) \leq n^3 + 1$ . We still follow the general plan from [GLM+16] but with a new step that allows us to reduce the deficiency of Y.

Fourier perspective. The idea in [GLM<sup>+</sup>16] to prove that z := G(X, Y) is pointwise-close to uniform is to study z in the Fourier domain, and show that z's Fourier coefficients (corresponding to free blocks) decay exponentially fast. That is, for every nonempty  $I \subseteq \text{free } \rho$  we want to show that the bias of  $\oplus(z_I)$  (parity of the output bits  $z_I$ ) is exponentially small in |I|. Tools tailor-made for this situation exist: various "XOR lemmas" are known to hold for communication complexity (e.g., [Sha03]) that apply as long as  $X_I$  and  $Y_I$  have low deficiencies. All this is recalled in Section 4.2. This suggests that all that remains is to reduce our case of high deficiency (of  $Y_I$ ) to the case of low deficiency.

Reducing deficiency via buckets. For the moment assume I = [n] for simplicity of discussion. Our idea for reducing the deficiency of  $\mathbf{Y}_I = \mathbf{Y}$  is as follows. We partition each m-bit string in  $\mathbf{Y} \in (\{0,1\}^m)^n$  into  $m^{1/2}$  many buckets each of length  $m^{1/2}$ . We argue that  $\mathbf{Y}$  can be expressed as a mixture of distributions  $\mathbf{y}$ , where  $\mathbf{y}$  has few of its buckets fixed in each string  $\mathbf{y}_i$ , and for any way of choosing an unfixed bucket for each  $\mathbf{y}_i$ , the marginal distribution of  $\mathbf{y}$  on the union T of these buckets has deficiency as low as  $\mathbf{D}_{\infty}(\mathbf{y}_T) \leq 1$ . Correspondingly, we argue that  $\mathbf{X}$  may be expressed as a mixture of distributions  $\mathbf{x}$  that have a nice form:

![](_page_11_Figure_8.jpeg)

Here each pointer  $x_i$  ranges over a single bucket  $T_i$ . Moreover, for a large subset  $I' \subseteq [n]$  of coordinates,  $T_i$  is unfixed in  $y_i$  for  $i \in I'$ , and hence y has deficiency  $\leq 1$  on the union of these unfixed buckets. The remaining few  $i \in [n] \setminus I'$  are associated with fixed pointers  $x_i = x_i$  pointing into fixed buckets in y. Consequently, we may interpret (x, y) as a random input to  $IND_{m^{1/2}}^n$  by identifying each bucket  $T_i$  with  $[m^{1/2}]$ . In this restricted domain, we can show that  $(\oplus \circ g^n)(x, y)$  is indeed very unbiased: the fixed coordinates do not contribute to the bias of the parity, and  $(x_{I'}, y_{I'})$  is a pair of low-deficiency variables for which an XOR lemma type calculation applies. The heart of the proof will be to find a decomposition of  $X \times Y$  into such distributions  $x \times y$ .

In the remaining subsections, we carry out the formal proof of Lemma 8.

#### <span id="page-12-0"></span>4.2 Fourier perspective

Henceforth we abbreviate  $J := \text{free } \rho$ . We employ the following calculation from [GLM<sup>+</sup>16], whose proof is reproduced in Section 4.6 for completeness. Here  $\chi(z) := (-1)^{\oplus(z)}$ .

**Lemma 9** (Pointwise uniformity from parities). If a random variable  $z_J$  over  $\{0,1\}^J$  satisfies  $|\mathbf{E}[\chi(z_I)]| \leq 2^{-5|I| \log n}$  for every nonempty  $I \subseteq J$ , then  $z_J$  is  $1/n^3$ -pointwise-close to uniform.

To prove Lemma 8, it suffices to take  $z_J = g^J(X_J, Y_J)$  above and show for every  $\emptyset \neq I \subseteq J$ ,

<span id="page-12-1"></span>
$$\left| \mathbf{E} \left[ \chi(g^I(\boldsymbol{X}_I, \boldsymbol{Y}_I)) \right] \right| \leq 2^{-5|I| \log n}. \tag{4}$$

In our high-deficiency case, we have

- (i)  $\mathbf{D}_{\infty}(X_I) \leq 0.1 |I| \log m + 1$ ,
- (ii)  $\mathbf{D}_{\infty}(\mathbf{Y}_I) < n^3 + 1$ .

**Low-deficiency case.** As a warm-up, let us see how to obtain (4) by imagining that we are in the low-deficiency case, i.e., replacing assumption (ii) by

(ii') 
$$\mathbf{D}_{\infty}(\mathbf{Y}_I) \leq 1$$
.

We present a calculation that is a very simple special case of, e.g., Shaltiel's [Sha03] XOR lemma for discrepancy (relative to uniform distribution).

Let M be the communication matrix of  $g := \text{IND}_m$  but with  $\{+1, -1\}$  instead of  $\{0, 1\}$  entries. The operator 2-norm of M is  $||M|| = 2^{m/2}$  since the rows are orthogonal and each has 2-norm  $2^{m/2}$ . The |I|-fold tensor product of M then satisfies  $||M^{\otimes |I|}|| = 2^{|I|m/2}$  by the standard fact that the 2-norm behaves multiplicatively under tensor product. Here  $M^{\otimes |I|}$  is the communication matrix of the 2-party function  $\chi \circ g^I$ . We think of the distribution of  $X_I$  as an  $m^{|I|}$ -dimensional vector  $\mathcal{D}_{X_I}$ , and of the distribution of  $Y_I$  as a  $(2^m)^{|I|}$ -dimensional vector  $\mathcal{D}_{Y_I}$ . Letting  $\mathbf{H}_2$  ( $\geq \mathbf{H}_{\infty}$ ) denote Rényi 2-entropy, by (i) we have

$$\|\mathcal{D}_{\boldsymbol{X}_I}\| \ = \ 2^{-\mathbf{H}_2(\boldsymbol{X}_I)/2} \ \le \ 2^{-\mathbf{H}_\infty(\boldsymbol{X}_I)/2} \ \le \ 2^{-(|I|\log m - 0.1|I|\log m - 1)/2} \ = \ 2^{-0.45|I|\log m + 1/2}.$$

Similarly, by (ii') we would have

<span id="page-12-2"></span>
$$\|\mathcal{D}_{\mathbf{Y}_I}\| \le 2^{-(|I|m-1)/2} = 2^{-|I|m/2+1/2}.$$

The left side of (4) is now

$$\left| \mathcal{D}_{\boldsymbol{X}_{I}}^{\top} M^{\otimes |I|} \mathcal{D}_{\boldsymbol{Y}_{I}} \right| \leq \left\| \mathcal{D}_{\boldsymbol{X}_{I}} \right\| \cdot \left\| M^{\otimes |I|} \right\| \cdot \left\| \mathcal{D}_{\boldsymbol{Y}_{I}} \right\| \leq 2^{-0.45|I| \log m + 1/2} \cdot 2^{|I| m/2} \cdot 2^{-|I| m/2 + 1/2} \\
= 2^{-0.45|I| \log m + 1} \leq 2^{-5|I| \log n}.$$
(5)

Therefore our goal becomes to reduce (via buckets) from case (ii) to case (ii').

#### 4.3 Buckets

We introduce some bucket terminology for random  $(\boldsymbol{x}, \boldsymbol{y}) \in [m]^I \times (\{0, 1\}^m)^I$ .

- Each string  $y_i$  is partitioned into  $m^{1/2}$  buckets each of length  $m^{1/2}$ .
- We think of  $x_i$  as a pair  $\ell_i r_i$  where  $\ell_i$  specifies which bucket and  $r_i$  specifies which element of the bucket. (Or, viewing  $x_i \in \{0,1\}^{\log m}$ ,  $\ell_i \in \{0,1\}^{(\log m)/2}$  would be the left half and  $r_i \in \{0,1\}^{(\log m)/2}$  would be the right half.) Thus  $x = \ell r$  where the random variable  $\ell \in [m^{1/2}]^I$  picks a bucket for each coordinate, and the random variable  $r \in [m^{1/2}]^I$  picks an element from each of the buckets specified by  $\ell$ . Every outcome  $\ell$  of  $\ell$  has an associated bucket union (one bucket for each string) given by  $T_\ell := \bigcup_{i \in I} (\{i\} \times T_{\ell_i})$  where  $T_{\ell_i} \subseteq [m]$  is the bucket specified by  $\ell_i$ . Here a bit index  $(i,j) \in I \times [m]$  refers to the j-th bit of the string  $y_i$ .

#### 4.4 Focused decompositions

Our goal is to express the product distribution  $X_I \times Y_I$  as a convex combination of product distributions  $x \times y$  that are *focused*, which informally means that many pointers in x point into buckets that collectively have low deficiency in y, and the remaining pointers produce constant gadget outputs. A formal definition follows.

**Definition 3.** A product distribution  $\boldsymbol{x} \times \boldsymbol{y}$  over  $[m]^I \times (\{0,1\}^m)^I$  is called *focused* if there is a partial assignment  $\sigma \in \{0,1,*\}^I$  such that, letting  $I' := \text{free } \sigma$ , we have:  $|I'| \ge |I|/2$ , and  $g^I(\boldsymbol{x},\boldsymbol{y})$  is always consistent with  $\sigma$ , and for each  $i \in I'$ ,  $\boldsymbol{x}_i = \ell_i \boldsymbol{r}_i$  is always in a specific bucket  $T_{\ell_i} \subseteq [m]$ , and

- (i\*)  $\mathbf{D}_{\infty}(\boldsymbol{x}_{I'}) \leq 0.6 |I'| \log m^{1/2}$  with respect to  $\boldsymbol{\times}_{i \in I'} T_{\ell_i}$ ,
- (ii\*)  $\mathbf{D}_{\infty}(\mathbf{y}_T) \leq 1$  where  $T := \bigcup_{i \in I'} (\{i\} \times T_{\ell_i})$ .

We elaborate on this definition. Since  $g^I(\boldsymbol{x}, \boldsymbol{y})$  is always consistent with  $\sigma$ , the coordinates fix  $\sigma = I \setminus I'$  are irrelevant to the bias of the parity of  $g^I(\boldsymbol{x}, \boldsymbol{y})$ . For each  $i \in I'$ , we might as well think of the domain of  $\boldsymbol{x}_i$  as  $T_{\ell_i}$  instead of [m], and of the domain of  $\boldsymbol{y}_i$  as  $\{0,1\}^{T_{\ell_i}}$  instead of  $\{0,1\}^m$ . Hence, out of the |I'|m bits of  $\boldsymbol{y}_{I'}$ , the only relevant ones are the  $|I'|m^{1/2}$  bits indexed by T. We may thus interpret  $(\boldsymbol{x}_{I'}, \boldsymbol{y}_T)$  as a random input to  $IND_{m^{1/2}}^{I'}$ . In summary,

<span id="page-13-0"></span>
$$\left| \mathbf{E} \left[ \chi(g^{I}(\boldsymbol{x}, \boldsymbol{y})) \right] \right| = \left| \mathbf{E} \left[ \chi(g^{I'}(\boldsymbol{x}_{I'}, \boldsymbol{y}_{I'})) \right] \right| = \left| \mathbf{E} \left[ \chi(\operatorname{IND}_{m^{1/2}}^{I'}(\boldsymbol{x}_{I'}, \boldsymbol{y}_{T})) \right] \right|.$$
 (6)

If  $\boldsymbol{x} \times \boldsymbol{y}$  is focused, then the calculation leading to (5) can be applied to  $\boldsymbol{x}_{I'} \times \boldsymbol{y}_T$  with m replaced by  $m^{1/2}$ , |I| replaced by  $|I'| \ge |I|/2$ , and min-entropy rate 0.9 replaced by 0.4, to show that

value of (6) 
$$\leq 2^{-0.2|I'|\log m^{1/2}+1} \leq 2^{-(0.2/4)|I|\log m+1} \leq 2^{-5|I|\log n-1}$$
. (using  $m = n^{256}$ )

<span id="page-13-1"></span>**Lemma 10.** The product distribution  $\mathbf{X}_I \times \mathbf{Y}_I$  can be decomposed into a mixture of product distributions  $\mathbf{E}_{d \sim \mathbf{d}}[\mathbf{x}^d \times \mathbf{y}^d]$  over  $[m]^I \times (\{0,1\}^m)^I$  (d stands for "data") such that  $\mathbf{x}^d \times \mathbf{y}^d$  is focused with probability at least  $1 - 2^{-5|I| \log n - 1}$  over  $d \sim \mathbf{d}$ .

Using Lemma 10, which we prove in the following subsection, we can derive (4):

$$\begin{aligned} \left| \mathbf{E} \left[ \chi(g^{I}(\boldsymbol{X}_{I}, \boldsymbol{Y}_{I})) \right] \right| &\leq \mathbf{E}_{d \sim \boldsymbol{d}} \left| \mathbf{E} \left[ \chi(g^{I}(\boldsymbol{x}^{d}, \boldsymbol{y}^{d})) \right] \right| \\ &\leq \mathbf{Pr}[\boldsymbol{d} \text{ is not focused}] + \max_{\text{focused } \boldsymbol{d}} \left| \mathbf{E} \left[ \chi(g^{I}(\boldsymbol{x}^{d}, \boldsymbol{y}^{d})) \right] \right| \\ &\leq 2^{-5|I| \log n - 1} + 2^{-5|I| \log n - 1} = 2^{-5|I| \log n}. \end{aligned}$$

#### 4.5 Finding a focused decomposition

We now prove Lemma 10. By assumption,  $X_I = \ell r$  is 0.9-essentially-dense (since  $X_J$  is) and  $\mathbf{D}_{\infty}(Y_I) \leq \mathbf{D}_{\infty}(Y) \leq n^3 + 1$ . We carry out the decomposition in the following three steps. Define  $\varepsilon := 2^{-5|I|\log n - 1}$ .

<span id="page-14-5"></span>Claim 11.  $Y_I$  can be decomposed into a mixture of distributions  $\mathbf{E}_{c \sim c}[\mathbf{y}^c]$  over  $(\{0,1\}^m)^I$  such that with probability at least  $1 - \varepsilon/3$  over  $c \sim c$ ,

- <span id="page-14-0"></span>(P1) each string in  $y^c$  has at most  $2n^3$  fixed buckets,
- <span id="page-14-4"></span>(P2) each bucket union  $T_{\ell}$  not containing fixed buckets has  $\mathbf{D}_{\infty}(\boldsymbol{y}_{T_{\ell}}^{c}) \leq 1$ .

<span id="page-14-6"></span>Claim 12. For any c satisfying (P1), with probability at least  $1 - \varepsilon/3$  over  $\ell \sim \ell$ ,

- <span id="page-14-1"></span>(Q1) the bucket union  $T_{\ell}$  contains at most |I|/2 fixed buckets of  $\boldsymbol{y}^{c}$ ,
- <span id="page-14-2"></span>(Q2)  $\mathbf{D}_{\infty}(r \mid \ell = \ell) \le 0.25 |I| \log m^{1/2}$ .

<span id="page-14-3"></span>Claim 13. For any c and  $\ell$  satisfying (Q1), (Q2), letting

$$I^* := \{i \in I : the \ \ell_i \ bucket \ of \ \mathbf{y}_i^c \ is \ fixed\} \quad and \quad I' := I \setminus I^*,$$

with probability at least  $1 - \varepsilon/3$  over  $r_{I^*} \sim (\boldsymbol{r}_{I^*} \mid \boldsymbol{\ell} = \ell)$ , we have  $\mathbf{D}_{\infty}(\boldsymbol{r}_{I'} \mid \boldsymbol{\ell} = \ell, \boldsymbol{r}_{I^*} = r_{I^*}) \leq 0.6|I'|\log m^{1/2}$ .

We now finish the proof of Lemma 10 assuming these three claims. Take  $\mathbf{d} \coloneqq (\mathbf{c}, \ell, r_{I^*})$ ; that is, the data  $d \sim \mathbf{d}$  is sampled by first sampling  $c \sim \mathbf{c}$ , then  $\ell \sim \ell$ , then  $r_{I^*} \sim (r_{I^*} \mid \ell = \ell)$ , where  $I^*$  implicitly depends on c and  $\ell$ . Take  $\mathbf{y}^d \coloneqq \mathbf{y}^c$  and  $\mathbf{x}^d \coloneqq (\mathbf{X}_I \mid \ell = \ell, r_{I^*} = r_{I^*})$ , and note that  $\mathbf{E}_{d \sim \mathbf{d}}[\mathbf{x}^d \times \mathbf{y}^d]$  indeed forms a decomposition of  $\mathbf{X}_I \times \mathbf{Y}_I$ . By a union bound, with probability at least  $1 - \varepsilon$  over  $d \sim \mathbf{d}$ , the properties of all three claims hold, in which case we just need to check that  $\mathbf{x}^d \times \mathbf{y}^d$  is focused.

Since for each  $i \in I^*$ ,  $\boldsymbol{x}_i^d \in T_{\ell_i}$  and  $\boldsymbol{y}_{i,T_{\ell_i}}^d$  are both fixed, we have that  $g^{I^*}(\boldsymbol{x}_{I^*}^d,\boldsymbol{y}_{I^*}^d)$  is fixed and hence  $g^I(\boldsymbol{x}^d,\boldsymbol{y}^d)$  is always consistent with some partial assignment  $\sigma$  with fix  $\sigma = I^*$  and free  $\sigma = I'$ . We have  $|I'| \geq |I|/2$  by (Q1). For each  $i \in I'$ , note that  $\boldsymbol{x}_i^d$  is always in  $T_{\ell_i}$  since we conditioned on  $\ell = \ell$ . Note that (i\*) for  $\boldsymbol{x}^d$  holds by Claim 13. To see that (ii\*) for  $\boldsymbol{y}^d$  holds, pick any  $\ell'$  that agrees with  $\ell$  on I' and such that for every  $i \in I^*$ , the  $\ell'_i$  bucket of  $\boldsymbol{y}_i^d$  is not fixed—thus, the bucket union  $T_{\ell'}$  contains no fixed buckets of  $\boldsymbol{y}^d$ —and note that  $\mathbf{D}_{\infty}(\boldsymbol{y}_T^d) \leq \mathbf{D}_{\infty}(\boldsymbol{y}_{T_{\ell'}}^d) \leq 1$  by (P2).

*Proof of Claim 11.* We use a process highly reminiscent of the "density-restoring partition" process described in Section 3.3. We maintain an event E which is initially all of  $(\{0,1\}^m)^I$ .

While  $\Pr[Y_I \in E] > \varepsilon/3$ :

- (1) Choose a maximal set of pairwise disjoint bucket unions  $\mathcal{T} = \{T_{\ell^1}, \dots, T_{\ell^k}\}$  with the property that  $\mathbf{D}_{\infty}(\mathbf{Y}_{\cup \mathcal{T}} \mid E) > k$  (possibly  $\mathcal{T} = \emptyset$ ) and let  $\beta \in \{0, 1\}^{\cup \mathcal{T}}$  be an outcome witnessing this:  $\mathbf{Pr}[\mathbf{Y}_{\cup \mathcal{T}} = \beta \mid E] > 2^{-(k|I|m^{1/2} k)}$ .
- (2) Output the distribution  $(\mathbf{Y}_I \mid \mathbf{Y}_{\cup \mathcal{T}} = \beta, E)$  with associated probability  $\mathbf{Pr}[\mathbf{Y}_{\cup \mathcal{T}} = \beta, E] > 0$ .
- (3) Update  $E \leftarrow \{y_I \in E : y_{\cup T} \neq \beta\}$ .

Output the distribution  $(Y_I \mid E)$  with associated probability  $\Pr[Y_I \in E]$  if the latter is nonzero.

The distributions output throughout the process are the  $y^c$ 's; note that with the associated probabilities, they indeed form a decomposition of  $Y_I$ . Each time (1) is executed, we have

$$k < \mathbf{D}_{\infty}(\mathbf{Y}_{\cup \mathcal{T}} \mid E) \le \mathbf{D}_{\infty}(\mathbf{Y}_I) + \log(1/\mathbf{Pr}[\mathbf{Y}_I \in E]) \le n^3 + 1 + \log(3/\varepsilon) \le 2n^3.$$

Also, any  $\mathbf{y}^c = (\mathbf{Y}_I \mid \mathbf{Y}_{\cup \mathcal{T}} = \beta, E)$  output in (2) has the property that for any bucket union  $T_\ell$  not containing fixed buckets,  $\mathbf{D}_{\infty}(\mathbf{y}_{T_\ell}^c) \leq 1$ . To see this, first note that  $T_\ell$  is disjoint from  $\cup \mathcal{T}$  since the latter buckets are fixed to  $\beta$ . If  $\mathbf{D}_{\infty}(\mathbf{y}_{T_\ell}^c) > 1$  were witnessed by some  $\gamma \in \{0, 1\}^{T_\ell}$ , then

$$\mathbf{Pr}[Y_{(\cup \mathcal{T}) \cup T_{\ell}} = \beta \gamma \mid E] = \mathbf{Pr}[Y_{\cup \mathcal{T}} = \beta \mid E] \cdot \mathbf{Pr}[Y_{T_{\ell}} = \gamma \mid Y_{\cup \mathcal{T}} = \beta, E]$$

$$> 2^{-(k|I|m^{1/2} - k)} \cdot 2^{-(|I|m^{1/2} - 1)} = 2^{-((k+1)|I|m^{1/2} - (k+1))}$$

and so  $\mathbf{D}_{\infty}(\mathbf{Y}_{(\cup \mathcal{T})\cup T_{\ell}} \mid E) > k+1$ , which would contradict the maximality of k since  $\{T_{\ell^1}, \dots, T_{\ell^k}, T_{\ell}\}$  is a set of pairwise disjoint bucket unions.

Proof of Claim 12. Assume that for each coordinate  $i \in I$ ,  $\mathbf{y}_i^c$  has at most  $2n^3$  fixed buckets. Since  $\mathbf{X}_I$  is 0.9-essentially-dense,  $\boldsymbol{\ell}$  is 0.8-essentially-dense (for each nonempty  $H \subseteq I$ , we have  $\mathbf{D}_{\infty}(\boldsymbol{\ell}_H) \leq \mathbf{D}_{\infty}(\mathbf{X}_H) \leq 0.1|H|\log m+1=0.2|H|\log m^{1/2}+1$ ). Thus, the probability that  $T_{\ell}$  hits fixed buckets in all coordinates in some set  $H \subseteq I$  is at most the number of ways of choosing a fixed bucket from each of those coordinates  $(\leq (2n^3)^{|H|})$  times the maximum probability that  $T_{\ell}$  hits all the chosen buckets  $(\leq 2^{-(0.8|H|\log m^{1/2}-1)})$  since  $\ell$  is 0.8-essentially-dense). We can now calculate

$$\begin{split} \mathbf{Pr}[T_{\ell} \text{ hits} & \geq |I|/2 \text{ fixed buckets}] & \leq \sum_{H \subseteq I, |H| = |I|/2} \mathbf{Pr}[T_{\ell} \text{ hits fixed buckets in coordinates } H] \\ & \leq \binom{|I|}{|I|/2} \cdot (2n^3)^{|I|/2} \cdot 2^{-(0.8(|I|/2)\log m^{1/2} - 1)} \\ & \leq 2^{|I|} \cdot 2^{1.5|I|\log n + 1} \cdot 2^{-(51.2|I|\log n - 1)} \\ & \leq 2^{|I| - 49.7|I|\log n + 2} \\ & \leq \varepsilon/6 \end{split} \tag{using } m = n^{256})$$

For convenience, we assumed above that |I| is even; if |I| is odd (including the case |I| = 1), the same calculation works with  $\lceil |I|/2 \rceil$  instead of |I|/2.

(Q2) follows by a direct application of the chain rule for min-entropy [Vad12, Lemma 6.30]: with probability at least  $1 - \varepsilon/6$  over  $\ell \sim \ell$ , we have

$$\mathbf{D}_{\infty}(r \mid \ell = \ell) \leq \mathbf{D}_{\infty}(X_I) + \log(6/\varepsilon) \leq (0.1|I|\log m + 1) + (5|I|\log n + 4) \leq 0.25|I|\log m^{1/2}.$$

By a union bound, with probability at least  $1 - \varepsilon/3$  over  $\ell$ , (Q1) and (Q2) hold simultaneously.  $\square$ 

Proof of Claim 13. This is again a direct application of the chain rule for min-entropy: with probability at least  $1 - \varepsilon/3$  over  $r_{I^*} \sim (r_{I^*} \mid \ell = \ell)$ , we have

$$\mathbf{D}_{\infty}(\mathbf{r}_{I'} \mid \ell = \ell, \, \mathbf{r}_{I^*} = r_{I^*}) \leq \mathbf{D}_{\infty}(\mathbf{r} \mid \ell = \ell) + \log(3/\varepsilon)$$

$$\leq (0.25|I|\log m^{1/2}) + (5|I|\log n + 3) \leq 0.6|I'|\log m^{1/2}$$

where the middle inequality uses (Q2), and the last inequality uses (Q1) ( $|I'| \ge |I|/2$ ) and  $m = n^{256}$ .

#### <span id="page-15-0"></span>4.6 Pointwise uniformity from parities

**Lemma 9** (Pointwise uniformity from parities). If a random variable  $z_J$  over  $\{0,1\}^J$  satisfies  $|\mathbf{E}[\chi(z_I)]| \leq 2^{-5|I|\log n}$  for every nonempty  $I \subseteq J$ , then  $z_J$  is  $1/n^3$ -pointwise-close to uniform.

Proof (from [GLM+16, §2.2]). We let  $\varepsilon := 1/n^3$  and write  $\mathbf{z}_J$  as  $\mathbf{z}$  throughout the proof. We think of the distribution of  $\mathbf{z}$  as a function  $\mathcal{D}: \{0,1\}^J \to [0,1]$  and write it in the Fourier basis as

$$\mathcal{D}(z) = \sum_{I \subseteq J} \widehat{\mathcal{D}}(I) \chi_I(z)$$

where  $\chi_I(z) := (-1)^{\oplus (z_I)}$  and  $\widehat{\mathcal{D}}(I) := 2^{-|J|} \sum_z \mathcal{D}(z) \chi_I(z) = 2^{-|J|} \cdot \mathbf{E}[\chi_I(z)]$ . Note that  $\widehat{\mathcal{D}}(\emptyset) = 2^{-|J|}$  because  $\mathcal{D}$  is a distribution. Our assumption says that for all nonempty  $I \subseteq J$ ,  $2^{|J|} \cdot |\widehat{\mathcal{D}}(I)| \le 2^{-5|I| \log n}$ , which is at most  $\varepsilon 2^{-2|I| \log |J|}$ . Hence,

$$2^{|J|} \sum_{I \neq \emptyset} |\widehat{\mathcal{D}}(I)| \ \leq \ \varepsilon \sum_{I \neq \emptyset} 2^{-2|I|\log |J|} \ = \ \varepsilon \sum_{k=1}^{|J|} {|J| \choose k} 2^{-2k\log |J|} \ \leq \ \varepsilon \sum_{k=1}^{|J|} 2^{-k\log |J|} \ \leq \ \varepsilon.$$

We use this to show that  $|\mathcal{D}(z) - 2^{-|J|}| \le \varepsilon 2^{-|J|}$  for all  $z \in \{0,1\}^J$ , which proves the lemma. To this end, let  $\mathcal{U}$  denote the uniform distribution (note that  $\widehat{\mathcal{U}}(I) = 0$  for all nonempty  $I \subseteq J$ ) and let  $\mathbb{1}_z$  denote the indicator for z defined by  $\mathbb{1}_z(z) = 1$  and  $\mathbb{1}_z(z') = 0$  for  $z' \ne z$  (note that  $|\widehat{\mathbb{1}}_z(I)| = 2^{-|J|}$  for all I). We can now calculate

$$\begin{array}{lll} \left| \mathcal{D}(z) - 2^{-|J|} \right| &= \left| \langle \mathbbm{1}_z, \mathcal{D} \rangle - \langle \mathbbm{1}_z, \mathcal{U} \rangle \right| &= \left| \langle \mathbbm{1}_z, \mathcal{D} - \mathcal{U} \rangle \right| &= 2^{|J|} \cdot \left| \langle \widehat{\mathbbm{1}}_z, \widehat{\mathcal{D}} - \widehat{\mathcal{U}} \rangle \right| \\ &\leq 2^{|J|} \cdot \sum_{I \neq \emptyset} |\widehat{\mathbbm{1}}_z(I)| \cdot |\widehat{\mathcal{D}}(I)| &= \sum_{I \neq \emptyset} |\widehat{\mathcal{D}}(I)| &\leq \varepsilon 2^{-|J|}. \end{array}$$

## <span id="page-16-0"></span>5 Applications

In this section, we collect some recent results in communication complexity, which we can derive (often with simplifications) from our lifting theorem.

Classical vs. quantum. Anshu et al. [ABB<sup>+</sup>16b] gave a nearly 2.5-th power total function separation between quantum and classical randomized protocols. Our lifting theorem can reproduce this separation by lifting an analogous separation in query complexity due to Aaronson, Ben-David, and Kothari [ABK16]. Let us also mention that Aaronson and Ambainis [AA15] have conjectured that a slight generalization of FORRELATION witnesses an  $O(\log n)$ -vs- $\tilde{\Omega}(n)$  quantum/classical query separation. If true, our lifting theorem implies that "2.5" can be improved to "3" above; see [ABK16] for a discussion. (Such an improvement is not black-box implied by the techniques of Anshu et al. [ABB<sup>+</sup>16b].)

Raz [Raz99] gave an exponential partial function separation between quantum and classical randomized protocols. Our lifting theorem can reproduce this separation by lifting, say, the FORRELATION partial function [AA15], which witnesses a 1-vs- $\tilde{\Omega}(\sqrt{n})$  separation for quantum/classical query complexity. However, qualitatively stronger separations are known [KR11, Gav16] where the quantum protocol can be taken to be *one-way* or even *simultaneous*.

**Partition numbers.** Anshu et al.  $[ABB^+16b]$  gave a nearly quadratic separation between (the log of) the *two-sided partition number* (number of monochromatic rectangles needed to partition the domain of F) and randomized communication complexity. This result now follows by lifting an analogous separation in query complexity due to Ambainis, Kokainis, and Kothari [AKK16].

In [GJPW15], a nearly quadratic separation was shown between (the log of) the one-sided partition number (number of rectangles needed to partition  $F^{-1}(1)$ ) and randomized communication complexity. This separation question can be equivalently phrased as proving randomized lower bounds for the Clique vs. Independent Set game [Yan91]. This result now follows by lifting an analogous separation in query complexity, obtained in several papers [GJPW15, ABB<sup>+</sup>16a, ABK16]; it was previously shown using the lifting theorem of [GLM<sup>+</sup>16], which requires a query lower bound in a model stronger than BPP<sup>dt</sup>.

Approximate Nash equilibria. Babichenko and Rubinstein [\[BR17\]](#page-18-9) showed a randomized communication lower bound for finding an approximate Nash equilibrium in a two-player game. Their approach was to show a lower bound for a certain query version of the PPAD-complete End-of-Line problem, and then lift this lower bound into communication complexity using [\[GLM](#page-18-4)+16]. However, as in the above Clique vs. Independent Set result, the application of [\[GLM](#page-18-4)+16] here requires that the query lower bound is established for a model stronger than BPPdt, which required some additional busywork. Our lifting theorem can be used to streamline their proof.

### Acknowledgements

Thanks to Shalev Ben-David and Robin Kothari for quantum references. Thanks to Anurag Anshu, Rahul Jain, Raghu Meka, Aviad Rubinstein, and Henry Yuen for discussions.

## References

- <span id="page-17-4"></span>[AA15] Scott Aaronson and Andris Ambainis. Forrelation: A problem that optimally separates quantum from classical computing. In Proceedings of the 47th Symposium on Theory of Computing (STOC), pages 307–316. ACM, 2015. [doi:10.1145/2746539.2746547](http://dx.doi.org/10.1145/2746539.2746547).
- <span id="page-17-6"></span>[ABB+16a] Andris Ambainis, Kaspars Balodis, Aleksandrs Belovs, Troy Lee, Miklos Santha, and Juris Smotrovs. Separations in query complexity based on pointer functions. In Proceedings of the 48th Symposium on Theory of Computing (STOC), pages 800–813. ACM, 2016. [doi:10.1145/2897518.2897524](http://dx.doi.org/10.1145/2897518.2897524).
- <span id="page-17-1"></span>[ABB+16b] Anurag Anshu, Aleksandrs Belovs, Shalev Ben-David, Mika G¨o¨os, Rahul Jain, Robin Kothari, Troy Lee, and Miklos Santha. Separations in communication complexity using cheat sheets and information complexity. In Proceedings of the 57th Symposium on Foundations of Computer Science (FOCS), pages 555–564. IEEE, 2016. [doi:10.1109/](http://dx.doi.org/10.1109/FOCS.2016.66) [FOCS.2016.66](http://dx.doi.org/10.1109/FOCS.2016.66).
- <span id="page-17-2"></span>[ABK16] Scott Aaronson, Shalev Ben-David, and Robin Kothari. Separations in query complexity using cheat sheets. In Proceedings of the 48th Symposium on Theory of Computing (STOC), pages 863–876. ACM, 2016. [doi:10.1145/2897518.2897644](http://dx.doi.org/10.1145/2897518.2897644).
- <span id="page-17-5"></span>[AKK16] Andris Ambainis, Martins Kokainis, and Robin Kothari. Nearly optimal separations between communication (or query) complexity and partitions. In Proceedings of the 31st Computational Complexity Conference (CCC), pages 4:1–4:14. Schloss Dagstuhl, 2016. [doi:10.4230/LIPIcs.CCC.2016.4](http://dx.doi.org/10.4230/LIPIcs.CCC.2016.4).
- <span id="page-17-0"></span>[BdW02] Harry Buhrman and Ronald de Wolf. Complexity measures and decision tree complexity: A survey. Theoretical Computer Science, 288(1):21–43, 2002. [doi:10.1016/S0304-3975\(01\)](http://dx.doi.org/10.1016/S0304-3975(01)00144-X) [00144-X](http://dx.doi.org/10.1016/S0304-3975(01)00144-X).
- <span id="page-17-3"></span>[BJKS04] Ziv Bar-Yossef, T.S. Jayram, Ravi Kumar, and D. Sivakumar. An information statistics approach to data stream and communication complexity. Journal of Computer and System Sciences, 68(4):702–732, 2004. [doi:10.1016/j.jcss.2003.11.006](http://dx.doi.org/10.1016/j.jcss.2003.11.006).

- <span id="page-18-0"></span>[BK16] Shalev Ben-David and Robin Kothari. Randomized query complexity of sabotaged and composed functions. In Proceedings of the 43rd International Colloquium on Automata, Languages, and Programming (ICALP), pages 60:1–60:14. Schloss Dagstuhl, 2016. [doi:10.4230/LIPIcs.ICALP.2016.60](http://dx.doi.org/10.4230/LIPIcs.ICALP.2016.60).
- <span id="page-18-9"></span>[BR17] Yakov Babichenko and Aviad Rubinstein. Communication complexity of approximate Nash equilibria. In Proceedings of the 49th Symposium on Theory of Computing (STOC). ACM, 2017. To appear. [arXiv:1608.06580](http://arxiv.org/abs/1608.06580).
- <span id="page-18-1"></span>[CKLM17] Arkadev Chattopadhyay, Michal Kouck´y, Bruno Loff, and Sagnik Mukhopadhyay. Composition and simulation theorems via pseudo-random properties. Technical Report TR17-014, Electronic Colloquium on Computational Complexity (ECCC), 2017. URL: <https://eccc.weizmann.ac.il/report/2017/014/>.
- <span id="page-18-7"></span>[CLRS16] Siu On Chan, James Lee, Prasad Raghavendra, and David Steurer. Approximate constraint satisfaction requires large LP relaxations. Journal of the ACM, 63(4):34:1– 34:22, 2016. [doi:10.1145/2811255](http://dx.doi.org/10.1145/2811255).
- <span id="page-18-10"></span>[CR12] Amit Chakrabarti and Oded Regev. An optimal lower bound on the communication complexity of gap-hamming-distance. SIAM Journal on Computing, 41(5):1299–1317, 2012. [doi:10.1137/120861072](http://dx.doi.org/10.1137/120861072).
- <span id="page-18-3"></span>[dRNV16] Susanna de Rezende, Jakob Nordstr¨om, and Marc Vinyals. How limited interaction hinders real communication (and what it means for proof and circuit complexity). In Proceedings of the 57th Symposium on Foundations of Computer Science (FOCS), pages 295–304. IEEE, 2016. [doi:10.1109/FOCS.2016.40](http://dx.doi.org/10.1109/FOCS.2016.40).
- <span id="page-18-11"></span>[Gav16] Dmitry Gavinsky. Entangled simultaneity versus classical interactivity in communication complexity. In Proceedings of the 48th Symposium on Theory of Computing (STOC), pages 877–884. ACM, 2016. [doi:10.1145/2897518.2897545](http://dx.doi.org/10.1145/2897518.2897545).
- <span id="page-18-8"></span>[GJPW15] Mika G¨o¨os, T.S. Jayram, Toniann Pitassi, and Thomas Watson. Randomized communication vs. partition number. Technical Report TR15-169, Electronic Colloquium on Computational Complexity (ECCC), 2015. URL: <http://eccc.hpi-web.de/report/2015/169/>.
- <span id="page-18-6"></span>[GKPW17] Mika G¨o¨os, Pritish Kamath, Toniann Pitassi, and Thomas Watson. Query-tocommunication lifting for P NP. Technical Report TR17-024, Electronic Colloquium on Computational Complexity (ECCC), 2017. URL: [https://eccc.weizmann.ac.il/report/2017/](https://eccc.weizmann.ac.il/report/2017/024/) [024/](https://eccc.weizmann.ac.il/report/2017/024/).
- <span id="page-18-4"></span>[GLM+16] Mika G¨o¨os, Shachar Lovett, Raghu Meka, Thomas Watson, and David Zuckerman. Rectangles are nonnegative juntas. SIAM Journal on Computing, 45(5):1835–1869, 2016. [doi:10.1137/15M103145X](http://dx.doi.org/10.1137/15M103145X).
- <span id="page-18-5"></span>[G¨o¨o15] Mika G¨o¨os. Lower bounds for clique vs. independent set. In Proceedings of the 56th Symposium on Foundations of Computer Science (FOCS), pages 1066–1076. IEEE, 2015. [doi:10.1109/FOCS.2015.69](http://dx.doi.org/10.1109/FOCS.2015.69).
- <span id="page-18-2"></span>[GPW15] Mika G¨o¨os, Toniann Pitassi, and Thomas Watson. Deterministic communication vs. partition number. In Proceedings of the 56th Symposium on Foundations of Computer Science (FOCS), pages 1077–1088. IEEE, 2015. [doi:10.1109/FOCS.2015.70](http://dx.doi.org/10.1109/FOCS.2015.70).

- <span id="page-19-4"></span>[HHL16] Hamed Hatami, Kaave Hosseini, and Shachar Lovett. Structure of protocols for XOR functions. In Proceedings of the 57th Symposium on Foundations of Computer Science (FOCS), pages 282–288. IEEE, 2016. [doi:10.1109/FOCS.2016.38](http://dx.doi.org/10.1109/FOCS.2016.38).
- <span id="page-19-0"></span>[Juk12] Stasys Jukna. Boolean Function Complexity: Advances and Frontiers, volume 27 of Algorithms and Combinatorics. Springer, 2012.
- <span id="page-19-8"></span>[KMR17] Pravesh Kothari, Raghu Meka, and Prasad Raghavendra. Approximating rectangles by juntas and weakly-exponential lower bounds for LP relaxations of CSPs. In Proceedings of the 49th Symposium on Theory of Computing (STOC). ACM, 2017. To appear. [arXiv:1610.02704](http://arxiv.org/abs/1610.02704).
- <span id="page-19-1"></span>[KN97] Eyal Kushilevitz and Noam Nisan. Communication Complexity. Cambridge University Press, 1997.
- <span id="page-19-14"></span>[KR11] Bo'az Klartag and Oded Regev. Quantum one-way communication can be exponentially stronger than classical communication. In Proceedings of the 43rd Symposium on Theory of Computing (STOC), pages 31–40. ACM, 2011. [doi:10.1145/1993636.1993642](http://dx.doi.org/10.1145/1993636.1993642).
- <span id="page-19-11"></span>[KS92] Bala Kalyanasundaram and Georg Schnitger. The probabilistic communication complexity of set intersection. SIAM Journal on Discrete Mathematics, 5(4):545–557, 1992. [doi:10.1137/0405044](http://dx.doi.org/10.1137/0405044).
- <span id="page-19-9"></span>[LRS15] James Lee, Prasad Raghavendra, and David Steurer. Lower bounds on the size of semidefinite programming relaxations. In Proceedings of the 47th Symposium on Theory of Computing (STOC), pages 567–576. ACM, 2015. [doi:10.1145/2746539.2746599](http://dx.doi.org/10.1145/2746539.2746599).
- <span id="page-19-12"></span>[Raz92] Alexander Razborov. On the distributional complexity of disjointness. Theoretical Computer Science, 106(2):385–390, 1992. [doi:10.1016/0304-3975\(92\)90260-M](http://dx.doi.org/10.1016/0304-3975(92)90260-M).
- <span id="page-19-10"></span>[Raz99] Ran Raz. Exponential separation of quantum and classical communication complexity. In Proceedings of the 31st Symposium on Theory of Computing (STOC), pages 358–367. ACM, 1999. [doi:10.1145/301250.301343](http://dx.doi.org/10.1145/301250.301343).
- <span id="page-19-3"></span>[RM99] Ran Raz and Pierre McKenzie. Separation of the monotone NC hierarchy. Combinatorica, 19(3):403–435, 1999. [doi:10.1007/s004930050062](http://dx.doi.org/10.1007/s004930050062).
- <span id="page-19-7"></span>[RPRC16] Robert Robere, Toniann Pitassi, Benjamin Rossman, and Stephen Cook. Exponential lower bounds for monotone span programs. In Proceedings of the 57th Symposium on Foundations of Computer Science (FOCS), pages 406–415. IEEE, 2016. [doi:10.1109/](http://dx.doi.org/10.1109/FOCS.2016.51) [FOCS.2016.51](http://dx.doi.org/10.1109/FOCS.2016.51).
- <span id="page-19-6"></span>[RS10] Alexander Razborov and Alexander Sherstov. The sign-rank of AC<sup>0</sup> . SIAM Journal on Computing, 39(5):1833–1855, 2010. [doi:10.1137/080744037](http://dx.doi.org/10.1137/080744037).
- <span id="page-19-2"></span>[RY17] Anup Rao and Amir Yehudayoff. Communication Complexity. In preparation, 2017.
- <span id="page-19-13"></span>[Sha03] Ronen Shaltiel. Towards proving strong direct product theorems. Computational Complexity, 12(12):1–22, 2003. [doi:10.1007/s00037-003-0175-x](http://dx.doi.org/10.1007/s00037-003-0175-x).
- <span id="page-19-5"></span>[She11] Alexander Sherstov. The pattern matrix method. SIAM Journal on Computing, 40(6):1969–2000, 2011. [doi:10.1137/080733644](http://dx.doi.org/10.1137/080733644).

- <span id="page-20-3"></span>[She12] Alexander Sherstov. The communication complexity of gap hamming distance. Theory of Computing, 8(1):197–208, 2012. [doi:10.4086/toc.2012.v008a008](http://dx.doi.org/10.4086/toc.2012.v008a008).
- <span id="page-20-2"></span>[SZ09] Yaoyun Shi and Yufan Zhu. Quantum communication complexity of block-composed functions. Quantum Information and Computation, 9(5–6):444–460, 2009.
- <span id="page-20-5"></span>[Vad12] Salil Vadhan. Pseudorandomness. Foundations and Trends in Theoretical Computer Science, 7(1–3):1–336, 2012. [doi:10.1561/0400000010](http://dx.doi.org/10.1561/0400000010).
- <span id="page-20-0"></span>[Ver99] Nikolai Vereshchagin. Relativizability in complexity theory. In Provability, Complexity, Grammars, volume 192 of AMS Translations, Series 2, pages 87–172. American Mathematical Society, 1999.
- <span id="page-20-4"></span>[Vid13] Thomas Vidick. A concentration inequality for the overlap of a vector on a large set, with application to the communication complexity of the gap-hamming-distance problem. Chicago Journal of Theoretical Computer Science, 2013(1):1–12, 2013. [doi:](http://dx.doi.org/10.4086/cjtcs.2012.001) [10.4086/cjtcs.2012.001](http://dx.doi.org/10.4086/cjtcs.2012.001).
- <span id="page-20-1"></span>[WYY17] Xiaodi Wu, Penghui Yao, and Henry Yuen. Raz–McKenzie simulation with the inner product gadget. Technical Report TR17-010, Electronic Colloquium on Computational Complexity (ECCC), 2017. URL: <https://eccc.weizmann.ac.il/report/2017/010/>.
- <span id="page-20-6"></span>[Yan91] Mihalis Yannakakis. Expressing combinatorial optimization problems by linear programs. Journal of Computer and System Sciences, 43(3):441–466, 1991. [doi:10.1016/0022-0000\(91\)](http://dx.doi.org/10.1016/0022-0000(91)90024-Y) [90024-Y](http://dx.doi.org/10.1016/0022-0000(91)90024-Y).