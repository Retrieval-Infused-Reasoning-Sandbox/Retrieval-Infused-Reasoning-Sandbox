# COMMUNICATION COMPLEXITY AND APPLICATIONS **ANUP RAO AMIR YEHUDAYOFF**

# Communication Complexity

Communication complexity is the mathematical study of scenarios where several parties need to communicate to achieve a common goal, a situation that naturally appears during computation. This introduction presents the most recent developments in an accessible form, providing the language to unify several disjointed research subareas. Written as a guide for a graduate course on communication complexity, it will interest a broad audience in computer science, from advanced undergraduates to researchers in areas ranging from theory to algorithm design to distributed computing.

Part I presents basic theory in a clear and illustrative way, offering beginners an entry into the field. Part II describes applications, including circuit complexity, proof complexity, streaming algorithms, extension complexity of polytopes, and distributed computing. Proofs throughout the text use ideas from a wide range of mathematics, including geometry, algebra, and probability. Each chapter contains numerous examples, figures, and exercises to aid understanding.

ANUP RA O is an associate professor at the School of Computer Science, University of Washington. He received his PhD in Computer Science from the University of Texas at Austin and was a researcher at the Institute for Advanced Study, Princeton. His research interests are primarily in theoretical computer science.

AMIR YEHUDAYOFF is Associate Professor of Mathematics at Technion – Israel Institute of Technology. He is interested in mathematical questions that are motivated by theoretical computer science and machine learning. He was a member of the Institute for Advanced Study in Princeton and served as the secretary of the Israel Mathematical Union. He has won several prizes, including the Cooper Prize and the Krill Prize for excellence in scientific research, and the Kurt Mahler Prize for excellence in mathematics.

# **Communication Complexity and Applications**

Anup Rao

*University of Washington*

Amir Yehudayoff

*Technion – Israel Institute of Technology*

![](_page_4_Picture_5.jpeg)

University Printing House, Cambridge CB2 8BS, United Kingdom

One Liberty Plaza, 20th Floor, New York, NY 10006, USA

477 Williamstown Road, Port Melbourne, VIC 3207, Australia

314–321, 3rd Floor, Plot 3, Splendor Forum, Jasola District Centre, New Delhi – 110025, India

79 Anson Road, #06–04/06, Singapore 079906

Cambridge University Press is part of the University of Cambridge.

It furthers the University's mission by disseminating knowledge in the pursuit of education, learning, and research at the highest international levels of excellence.

<www.cambridge.org>

Information on this title: www.cambridge.org/9781108497985

DOI: [10.1017/9781108671644](http://dx.doi.org/10.1017/9781108671644)

© Anup Rao and Amir Yehudayoff 2020

This publication is in copyright. Subject to statutory exception and to the provisions of relevant collective licensing agreements, no reproduction of any part may take place without the written permission of Cambridge University Press.

First published 2020

Printed in the United Kingdom by TJ International Ltd., Padstow Cornwall

*A catalogue record for this publication is available from the British Library.*

*Library of Congress Cataloging-in-Publication Data*

Names: Rao, Anup, 1980– author. | Yehudayoff, Amir, author.

Title: Communication complexity and applications / Anup Rao, Amir Yehudayoff.

Description: Cambridge ; New York, NY : Cambridge University Press, 2020. |

Includes bibliographical references and index.

Identifiers: LCCN 2019038156 (print) | LCCN 2019038157 (ebook) |

ISBN 9781108497985 (hardback) | ISBN 9781108671644 (epub)

Subjects: LCSH: Computational complexity.

Classification: LCC QA267.7 .R37 2020 (print) | LCC QA267.7 (ebook) |

DDC 511.3/52–dc23

LC record available at https://lccn.loc.gov/2019038156

LC ebook record available at https://lccn.loc.gov/2019038157

ISBN 978-1-108-49798-5 Hardback

Cambridge University Press has no responsibility for the persistence or accuracy of URLs for external or third-party internet websites referred to in this publication and does not guarantee that any content on such websites is, or will remain, accurate or appropriate.

![](_page_6_Picture_0.jpeg)

# Contents

| Preface |                                                    | xi   |
|---------|----------------------------------------------------|------|
|         | Conventions and Preliminaries                      | xiii |
|         | Introduction                                       | 1    |
|         |                                                    |      |
| Part    | I<br>Communication                                 |      |
| 1       | Deterministic Protocols                            | 9    |
|         | Rectangles                                         | 11   |
|         | Balancing Protocols                                | 13   |
|         | From Rectangles to Protocols                       | 14   |
|         | Lower Bounds                                       | 15   |
|         | Rectangle Covers                                   | 26   |
|         | Direct-Sums in Communication Complexity            | 28   |
| 2       | Rank                                               | 33   |
|         | Communication Complexity and Rank                  | 34   |
|         | Properties of Rank                                 | 35   |
|         | Lower Bounds Based on Rank                         | 36   |
|         | Nonnegative Rank                                   | 38   |
|         | Better Upper Bounds Using Rank                     | 40   |
| 3       | Randomized Protocols                               | 46   |
|         | Some Protocols                                     | 46   |
|         | Randomized Communication Complexity                | 50   |
|         | Public Coins versus Private Coins                  | 53   |
|         | Nearly Monochromatic Rectangles                    | 54   |
| 4       | Numbers on Foreheads                               | 57   |
|         | Some Protocols                                     | 57   |
|         | Defining Protocols in the Number-on-Forehead Model | 61   |
|         | Cylinder Intersections                             | 61   |
|         | Lower Bounds from Ramsey Theory                    | 62   |
| 5       | Discrepancy                                        | 67   |
|         | Definitions                                        | 67   |
|         | Discrepancy and Communication                      | 68   |
|         | Convexity in Combinatorics                         | 69   |
|         |                                                    |      |

vii

|      | Lower Bounds for Inner-Product                     | 71  |
|------|----------------------------------------------------|-----|
|      | Disjointness and Discrepancy                       | 74  |
|      | Concentration of Measure                           | 80  |
| 6    | Information                                        | 93  |
|      | Entropy                                            | 93  |
|      | Chain Rule and Conditional Entropy                 | 96  |
|      | Divergence and Mutual Information                  | 105 |
|      | Lower Bound for Indexing                           | 107 |
|      | The Power of Interaction                           | 111 |
|      | Randomized Complexity of Disjointness              | 115 |
| 7    | Compressing Communication                          | 121 |
|      | Simulations                                        | 123 |
|      | Compressing Protocols with No Private Randomness   | 124 |
|      | Correlated Sampling                                | 126 |
|      | Compressing a Single Round                         | 128 |
|      | Internal Compression of Protocols                  | 136 |
|      | Direct Sums in Randomized Communication Complexity | 139 |
|      | Other Methods to Compress Protocols                | 141 |
| 8    | Lifting                                            | 144 |
|      | Decision Trees                                     | 144 |
|      | The Lifting Theorem                                | 145 |
|      | Separating Rank and Communication                  | 151 |
| Part | II<br>Applications                                 |     |
| 9    | Circuits and Proofs                                | 157 |
|      | Boolean Circuits                                   | 157 |
|      | Karchmer-Wigderson Games                           | 158 |
|      | Monotone Circuit-Depth Lower Bounds                | 159 |
|      | Monotone Circuit-Depth Hierarchy                   | 161 |
|      | Boolean Formulas                                   | 162 |
|      | Boolean Depth Conjecture                           | 165 |
|      | Proof Systems                                      | 166 |
|      | Resolution Refutations                             | 166 |
|      | Cutting Planes                                     | 170 |
| 10   | Memory Size                                        | 175 |
|      | Lower Bounds for Streaming Algorithms              | 178 |
|      | Lower Bounds for Branching Programs                | 183 |
| 11   | Data Structures                                    | 187 |
|      | Dictionaries                                       | 187 |
|      | Ordered Sets                                       | 188 |
|      | Lower Bounds on Static Data Structures             | 194 |

| Contents | ix |
|----------|----|
|----------|----|

|       | Lower Bounds on Dynamic Data Structures | 199 |
|-------|-----------------------------------------|-----|
|       | Graph Connectivity                      | 203 |
| 12    | Extension Complexity of Polytopes       | 210 |
|       | Transformations of Polytopes            | 212 |
|       | Algorithms from Polytopes               | 216 |
|       | Extension Complexity                    | 218 |
|       | Slack Matrices                          | 225 |
|       | Lower Bounds on Extension Complexity    | 229 |
| 13    | Distributed Computing                   | 239 |
|       | Some Protocols                          | 239 |
|       | Lower Bounds                            | 240 |
|       | Computing the Girth                     | 242 |
|       | Bibliography                            | 244 |
| Index |                                         | 250 |

# Preface

COMMUNICATION IS AN ESSENTIAL part of our lives and plays a central role in our technology. Communication complexity is a mathematical theory that addresses a basic question:

If two or more parties want to compute something about the information they jointly possess, how long does their conversation need to be?

It provides a systematic framework for measuring, discussing, and understanding communication.

The fundamental nature of communication complexity leads to many deep connections with the study of *computation* in general. This is not surprising – it is hard to imagine a computing machine that does not include communicating components. Moreover, the costs associated with communication are often the most significant costs involved in carrying out the computation. For example, in the human brain, most of the mass consists of *white matter* rather than *gray matter*. It is the white matter that facilitates communication between different regions of the brain.

In the years following the basic definitions by Yao,<sup>1</sup> communication <sup>1</sup> Yao, 1979. complexity has become a standard tool for identifying the limitations of computation. The theory is general enough that it captures something important about many computational processes, yet simple and elegant enough that beautiful ideas from a wide range of mathematical disciplines can be used to understand it. In this book, we guide the reader through the theory along a path that includes many exquisite highlights of mathematics – including from geometry, probability theory, matrix analysis, algebra, and combinatorics. We will apply the theory to discover basic truths about Boolean circuits, proofs, data structures, linear programs, distributed systems, and streaming algorithms. Communication complexity is simultaneously beautiful and widely applicable.

The main protagonist of our story is the *disjointness* problem. Here Alice and Bob each have access to their own set and want to figure out whether or not these sets are disjoint. For example, imagine that Two sets are disjoint if they Alice and Bob want to know if there is a movie that they would both have no common elements. enjoy. Alice knows the collection of movies that she would like to see, and Bob knows the movies he would like to see. How long does their conversation need to be? Set disjointness appears in many applications

of communication complexity, and it helps to illustrate many techniques applicable to understanding communication.

Our exposition is in two parts. The first part, entitled *Communication*, focuses on communication complexity per se. Here communication protocols are rigorously defined and the foundations of the theory are built. The second part, entitled *Applications*, uses the theory to derive conclusions about a variety of different models of computation. In the first part, disjointness serves as a litmus test to see how the ideas we develop are progressing. In the second part, results about disjointness help to determine the limits of other models of computation.

We intend to present the key ideas in the field in the most elegant form possible. This is a textbook of basic concepts, and not a survey of the latest research results. The reader is encouraged to discover the wider body of work that forms the theory of communication complexity by following the many references that are cited in the book.

Each page of the book has a large margin, where one can find references to the relevant literature, diagrams, and additional explanations of arguments in the main text.

### **Acknowledgments**

THANKS TO Noga Alon, Anil Ananthaswamy, Arkadev Chattopadhyay, Morgan Dixon, Yaniv Elchayani, Yuval Filmus, Abe Friesen, Mika Göös, Jeff Heer, Pavel Hrubeš, Weston Karnes, Guy Kindler, Vincent Liew, Venkatesh Medabalimi, Or Meir, Shay Moran, Aram Odeh, Rotem Oshman, Sebastian Pokutta, Kayur Patel, Sivaramakrishnan Natarajan Ramamoorthy, Cyrus Rashtchian, Thomas Rothvoß, Makrand Sinha, and Avi Wigderson for many contributions to this book.

We thank the National Science Foundation, the Israel Science Foundation, the Simons Institute for the Theory of Computing, the Technion-IIT, and the University of Washington for their support.

Like this.

## Conventions and Preliminaries

In this section, we set up notation and recall some standard facts that are used throughout the book.

### Sets, Numbers, and Functions

[a,b] denotes the set of real numbers x in the interval  $a \le x \le b$ . For a positive integer n, we use [n] to denote the set  $\{1,2,\ldots,n\}$ . Following the convention in computer science, we often refer to the numbers 0 and 1 as bits. All logarithms in this book are computed in base 2, unless otherwise specified.

There is a natural identification between the subsets of [n] and binary strings  $\{0,1\}^n$ . Every set  $X \subseteq [n]$  corresponds to its indicator vector  $x \in \{0,1\}^n$ , defined by  $x_i = 1$  if and only if  $i \in X$  for all  $i \in [n]$ .

Given a vector  $x = (x_1, x_2, ..., x_n)$ , we write  $x_{\leq i}$  to denote  $(x_1, ..., x_i)$ . We define  $x_{\leq i}$  similarly. We write  $x_S$  to denote the projection of x to the coordinates specified by the set  $S \subseteq [n]$ .

A function  $f: D \to R$  is an object that maps every element x in the set D to a unique element f(x) of the set R. A Boolean function is a function that evaluates to a bit, namely  $R = \{0, 1\}$ .

Given two functions f,g that map natural numbers to real numbers, we write  $f(n) \leq O(g(n))$  if there are numbers  $n_0, c > 0$ , such that if  $n > n_0$  then  $f(n) \leq cg(n)$ . We write  $g(n) \geq \Omega(f(n))$  when  $f(n) \leq O(g(n))$ . We write  $f(n) \leq o(g(n))$  if  $\lim_{n \to \infty} \frac{f(n)}{g(n)} = 0$ .

### Graphs

A graph is a pair G = (V, E), where V is a set and E is a collection of subsets of V of size 2. The elements of V are called vertices and the elements of E are called edges. The size of the graph G is the number of vertices in it. A clique  $C \subseteq V$  in the graph is a subset of the vertices such that every subset of E of size 2 is an edge of the graph. An independent set E in the graph is a set that does not contain any edges. A path in the graph is a sequence of vertices E in that E is an edge for each E is a path whose first and last vertices are the same. A cycle is called simple if all of its edges are distinct. A graph is said to be connected if there is a path between every two distinct vertices in the graph. A graph is called a tree if it is connected and

We mostly use standard notation. The reader is advised to only skim through this section, and come back to it when necessary.

bit = binary digit.

D is the domain and R is the range of the function.

has no simple cycles. The *degree* of a vertex in a graph is the number of edges it is contained in. A *leaf* in a tree is a vertex of degree one. Every tree has at least one leaf. It follows by induction on n that every tree of size n has exactly n-1 edges.

### **Probability**

Throughout this book, we consider only finite probability spaces, or uniform distributions on compact sets of real numbers.

Let p be a probability distribution on a finite set  $\Omega$ . That is, p is a function  $p:\Omega\to [0,1]$  and  $\sum_{a\in\Omega}p(a)=1$ . Let A be a random variable chosen according to p. That is, for each  $a\in\Omega$ , we have  $\Pr[A=a]=\Pr_p[A=a]=p(a)$ . We use the notation p(a) to denote both the distribution of the variable A and the number  $\Pr[A=a]$ . The meaning is clear from the context. For example, if  $\Omega=\{0,1\}^2$  and A is uniformly distributed in  $\Omega$ , then p(a) denotes the uniform distribution on  $\Omega$ . However if a=(0,0), then p(a) denotes the number 1/4. Random variables are denoted by capital letters (like A) and values they attain are denoted by lowercase letters (like a). An event  $\mathcal E$  is a subset of  $\Omega$ . The probability of the event  $\mathcal E$  is  $\Pr[\mathcal E]=\sum_{a\in\mathcal E}p(a)$ . Events are denoted by calligraphic letters.

Given a distribution on 4-tuples p(a,b,c,d), we write p(a,b,c) to denote the marginal distribution on the variables a,b,c (or the corresponding probability). We often write p(ab) instead of p(a,b), for conciseness of notation. We also write p(a|b) to denote either the distribution of A conditioned on the event B = b, or the number Pr[A = a|B = b]. In the preceding example, if  $B = A_1 + A_2$ , and b = 1, then p(a|b) denotes the uniform distribution on  $\{(0,1), (1,0)\}$  when a is a free variable. When a = (0,1) then p(a|b) = 1/2.

Given  $g: \Omega \to \mathbb{R}$ , we write  $\mathbb{E}_{p(a)}[g(a)]$  to denote the expected value of g(a) with respect to p. So,  $\mathbb{E}_{p(a)}[g(a)] = \sum_{a \in \Omega} p(a)g(a)$ .

The *statistical distance*, also known as *total variational distance*, between two probability distributions p(a) and q(a) is defined to be

$$|p-q| = \frac{1}{2} \sum_{a} |p(a) - q(a)| = \max_{\mathcal{E}} p(\mathcal{E}) - q(\mathcal{E}),$$

where the maximum is taken over all events  $\mathcal{E}$ . For example, if p is uniform on  $\Omega = \{0,1\}^2$  and q is uniform on  $\{(0,1),(1,0)\} \subset \Omega$ , then when a is a free variable |p(a)-q(a)| denotes the statistical distance between the distributions, which is 1/2, and when a=(0,0), we have |p(a)-q(a)|=1/4.

We sometimes write  $p(x) \stackrel{\epsilon}{\approx} q(x)$  to indicate that  $|p(x) - q(x)| \le \epsilon$ . Suppose A, B are two random variables in a probability space p. For ease of notation, we write  $p(a|b) \stackrel{\epsilon}{\approx} p(a)$  for average b to mean that

$$\mathbb{E}_{p(b)}[|p(a|b) - p(a)|] \le \epsilon.$$

This notation is similar to how f(x) is often used to refer to the function f, when x is a variable, and a fixed value when x is fixed. This notation makes many equations more succinct. We shall encounter complicated scenarios where there are several random variables with a complicated conditioning structure. In those cases, it is helpful to use as succinct a notation as possible.

The proof of the second equality is a good exercise.

### Some Useful Inequalities

### Markov

Suppose X is a nonnegative random variable, and  $\gamma > 0$  is a number. Markov's inequality bounds the probability that X exceeds  $\gamma$  in terms of the expected value of X:

$$\mathbb{E}\left[X\right] > p(X > \gamma) \cdot \gamma \ \Rightarrow \ p(X > \gamma) < \frac{\mathbb{E}\left[X\right]}{\gamma}.$$

### Concentration

A sum of independently distributed bits concentrates around its expectation. Namely, the value of the sum is close to its expected value with high probability. The Chernoff-Hoeffding bound controls this concentration. Suppose  $X_1, \ldots, X_n$  are independent identically distributed bits. Let  $\mu = \mathbb{E}\left[\sum_{i=1}^n X_i\right]$ . The bound says that for any  $0 < \delta < 1$ ,

$$\Pr\left[\left|\sum_{i=1}^{n} X_i - \mu\right| > \delta\mu\right] \le e^{-\delta^2\mu/3}.$$

When  $\delta \geq 1$ , the following bound applies

$$\Pr\left[\sum_{i=1}^{n} X_i > (1+\delta)\mu\right] \le e^{-\delta\mu/3}.$$

The binomial coefficient  $\binom{n}{k}$  is the number of subsets of [n] of size k.

These bounds give estimates on binomial coefficients. The idea is to consider  $X_1, \ldots, X_n$  that are uniformly distributed and independent random bits. For a number  $0 \le a \le n/2$ , we have

$$\sum_{k \in [n]: |k-n/2| > a} \binom{n}{k} \le 2^n \cdot e^{-\frac{2a^2}{3n}}.$$

The following upper bounds on binomial coefficients is also useful: for all  $k \in [n]$ ,

$$\binom{n}{k} \le \frac{2^{n+1}}{\sqrt{\pi n}}.$$

### Approximations

We will often need to approximate linear functions with exponentials. The following inequalities are useful:  $e^{-x} \ge 1 - x$  for all real x, and  $1 - x \ge 2^{-2x}$  when  $0 \le x \le 1/2$ .

# Cauchy-Schwartz Inequality

The Cauchy-Schwartz inequality says that for two vectors  $x, y \in \mathbb{R}^n$ , their inner product is at most the products of their norms.

![](_page_16_Figure_20.jpeg)

$$\left|\sum_{i=1}^n x_i y_i\right| = \left|\langle x,y\rangle\right| \leq \|x\|\cdot\|y\| = \sqrt{\sum_{i=1}^n x_i^2} \cdot \sqrt{\sum_{i=1}^n y_i^2}.$$

### Convexity

A function  $f:[a,b] \to \mathbb{R}$  is said to be *convex* if

$$\frac{f(x) + f(y)}{2} \ge f\left(\frac{x + y}{2}\right),$$

for all x, y in the domain. It is said to be concave if

$$\frac{f(x) + f(y)}{2} \le f\left(\frac{x + y}{2}\right).$$

Some convex functions:  $x^2$ ,  $e^x$ ,  $x \log x$ . Some concave functions:  $\log x$ ,  $\sqrt{x}$ . Note that f is convex if and only if -f is concave.

Jensen's inequality says if a function f is convex, then

$$\mathbb{E}\left[f(X)\right] \geq f(\mathbb{E}\left[X\right]),$$

for any random variable  $X \in [a, b]$ . Similarly, if f is concave, then

$$\mathop{\mathbb{E}}\left[f(X)\right] \leq f(\mathop{\mathbb{E}}\left[X\right]).$$

In this book, we often say that an inequality follows by convexity when we mean that it can be derived by applying Jensen's inequality to a convex or concave function.

A consequence of Jensen's inequality is the Arithmetic-Mean Geometric-Mean inequality:

$$\frac{\sum_{i=1}^n a_i}{n} \ge \left(\prod_{i=1}^n a_i\right)^{1/n},\,$$

which can be proved using the concavity of the log function:

$$\log\left(\frac{\sum_{i=1}^n a_i}{n}\right) \ge \frac{\sum_{i=1}^n \log a_i}{n} = \log\left(\prod_{i=1}^n a_i^{1/n}\right).$$

![](_page_17_Figure_18.jpeg)

![](_page_17_Figure_19.jpeg)

Try to prove the Cauchy-Schwartz inequality using convexity.

### **Basic Facts from Algebra**

A few places in this book require knowledge about polynomials and finite fields. We cannot give a comprehensive introduction to these topics here, but we state some basic facts that are relevant to this book.

A field  $\mathbb{F}$  is a set containing 0 and 1 that is endowed with the operations of addition, multiplication, subtraction, and division. If  $a, b \in \mathbb{F}$ , then a + b, ab, a - b must also be elements of  $\mathbb{F}$ , and a/b is an element of  $\mathbb{F}$  as long as  $b \neq 0$ . We require that a - a = 0 for all  $a \in \mathbb{F}$ , and

a/a = 1 for all  $a \neq 0$ . Several other requirements should be met, like commutativity and distributivity.

The simplest example of a field is the field of *rational numbers*. In applications, however, it is often useful to consider fields that have a finite number of elements. The simplest example of a finite field is a prime field. For a prime number p, there is a unique field  $\mathbb{F}_p$  containing the p elements  $0,1,2,\ldots,p-1$ . These numbers can be added, subtracted, and multiplied modulo p to get the corresponding field operations. One can define division as well, using the property that p is prime. See Figure 1 for an example.

### **Vector Spaces**

Given a field  $\mathbb{F}$ , the set  $\mathbb{F}^n$  can be viewed as a vector space over  $\mathbb{F}$ . The elements of  $\mathbb{F}^n$  are called vectors. Addition of vectors is defined coordinate-wise, so  $(v+w)_i=v_i+w_i$ , for all i, and multiplication by a scalar  $c\in\mathbb{F}$  is defined as  $c\cdot(v_1,v_2,\ldots,v_n)=(cv_1,cv_2,\ldots,cv_n)$ , for  $c\in\mathbb{F}$ .

Linear combinations of vectors are taken using scalar coefficients from the field  $\mathbb{F}$ . The usual notions of dimension, linear dependence, and linear independence make sense here. A subspace V of  $\mathbb{F}^n$  is a set that is closed under additions and multiplications by scalars. Given a subspace  $V \subseteq \mathbb{F}$ , we define its dual subspace

$$V^{\perp} = \left\{ w \in \mathbb{F}^n : \sum_{i=1}^n v_i w_i = 0 \text{ for all } v \in V \right\}.$$

The following fact is useful: If  $V \subseteq \mathbb{F}^n$  is a subspace, the sum of the dimensions of V and  $V^{\perp}$  is always exactly n.

### **Polynomials**

A *polynomial* over the variables  $X_1, X_2, \dots, X_n$  is an expression of the form

$$aX_1X_2X_3^2 + bX_3X_7^3X_5 - cX_1X_4^4$$
.

It is a linear combination of monomials, where the coefficients a,b,c are elements of a field. Every polynomial corresponds to a function that can be computed by evaluation, and every function  $f: \mathbb{F}^n \to \mathbb{F}$  can be described by a polynomial.

A polynomial is called *multilinear* if every monomial is a product of distinct variables. For example: the polynomial

$$X_1X_2X_3 + 3X_3X_7X_5 - 2X_1X_4$$

is multilinear, and the polynomial  $X_1^2$  is not. A useful fact is that every function  $f: \{0,1\}^n \to \mathbb{F}$  can be *uniquely* represented as multilinear polynomial of n variables with coefficients from  $\mathbb{F}$ .

![](_page_18_Figure_16.jpeg)

![](_page_18_Figure_17.jpeg)

![](_page_18_Figure_18.jpeg)

Figure 1 The addition, multiplication, and division tables of  $\mathbb{F}_5$ .

THE CONCEPT OF A CONVERSATION is universal. In this book, we develop methods to determine the most efficient conversations for specific tasks. We start by exploring some examples that illustrate how such conversations arise, and why they are worthy of study.

We begin the story with one of the earliest applications of communication complexity: proving lower bounds on the area required for digital chips.1 A chip design specifies how to compute a function *<sup>f</sup>* (*x*1, ... , *<sup>x</sup>*n) <sup>1</sup> Thompson, 1979. by laying out the components of the chip on a flat grid, as in Figure I.1. Each component either stores one of the inputs to the function, or performs some computation on the values coming from adjacent components. It is vital to minimize the area used in the design because this affects the cost, power consumption, reliability, and speed of the chip.

Because there are *n* inputs, we need area of at least *n* to compute functions that depend on all of their inputs. Can we always find chip designs with area proportional to *n*? The framework of communication complexity can be used to show that many functions require area proportional to *n*2, *no matter what chip design is used*!

The crucial insight is that the layout of the chip yields a conversation whose outcome is the value of *f* . If a chip design has area *A*, one can argue that there must be a way to cut the chip into two parts, each containing a similar number of the inputs, so that only <sup>≈</sup> <sup>√</sup> *A* wires are cut. Imagine that each part of the chip represents a person. The chip design describes how *f* can be computed by two people, each of whom knows roughly half of the input to *f* , with a conversation whose length is proportional to the number of wires that were cut. So, if we can show that computing *f* requires a conversation of length *t*, we can conclude that area *A* must be at least ≈ *t* 2, no matter how the components of the chip are laid out. In this book, we will develop a wide variety of tools for proving that functions require conversations whose length is proportional to *n*. The area of any chip for such a function must be proportional to *n*2.

A second example comes from a classical result about *Turing machines*. Turing machines are widely regarded as a universal model of computation – the extended Church-Turing thesis says that anything

![](_page_20_Figure_7.jpeg)

**Figure I.1** Any chip can be broken into two pieces while cutting few wires.

that is efficiently computable is efficiently computable by a Turing machine. A Turing machine can be thought of as a program written for a computer that has access to one or more *tapes*. Each tape has a *head* that points at a location on the tape. In each step of computation, the machine can read or write a single symbol at the location corresponding to a head, or move the head to an adjacent location. A Turing machine with more tapes is more powerful than a Turing machine with fewer tapes, but how much more powerful?

A classic result<sup>2</sup> shows that one can simulate a Turing machine that has access to two tapes with a Turing machine that has access to just one tape. However, the simulation may increase the number of steps of the computation by a factor of t, where t is the running-time of the machine. One can use communication complexity to show that this loss is unavoidable.<sup>3</sup>

To see why this is the case, we use the communication complexity of the *disjointness* function. Imagine that Alice knows a set  $X \subseteq [n]$ , and Bob knows a set  $Y \subseteq [n]$ . Their common goal is to compute whether or not the sets are disjoint – namely whether or not there is an element that is in both sets (see Figure I.2). Later in the book, we prove that Alice and Bob must communicate  $\Omega(n)$  bits in order to achieve this goal.

Now, a Turing machine with access to two tapes can compute disjointness in O(n) steps. If the sets are represented by their indicator vectors  $x, y \in \{0, 1\}^n$ , then the machine can copy y to the second tape and scan both x and y, searching for an index i with  $x_i = 1 = y_i$ . All of these operations can be carried out in O(n) steps.

However, one can use communication complexity to prove that a Turing machine with one tape must take at least  $\Omega(n^2)$  steps to compute disjointness. The idea is that a machine that computes disjointness in T steps can be used by Alice and Bob to compute disjointness using  $\approx \frac{T}{n}$  bits of communication. Intuitively, Alice and Bob can write down the input (x, y) on the single tape of the machine and try to simulate the execution of the machine. Neither of them knows the contents of the whole tape, but they can still simulate the execution of the machine with a small amount of communication. Every time the machine transitions from Alice's part of the tape to Bob's part, she sends him a short message to indicate the line of code that should be executed next. Bob then continues the execution. One can show that this simulation can be carried out in such a way that each message sent between Alice and Bob corresponds to  $\Omega(n)$  steps of the Turing machine. So, if we start with a one-tape machine that runs in time  $\ll n^2$ , we end up with a protocol of length  $\ll n$  bits that computes disjointness. This is impossible.

The two examples we have discussed give some feel for communication problems and why we are interested in studying them. Next, we continue this informal introduction with several other interesting examples of communication problems and protocols.

Strictly speaking, the simulation increases by a factor of  $\max\{n, t\}$ , where n is the length of the input. However, for any computation that depends on the whole input, this maximum is t.

Figure I.2 looks very similar to the famous Sierpinski gasket, which is a well-known fractal in the plane. The gasket's area is zero, and its Hausdorff dimension is ≈ 1.585. The properties of disjointness we establish in this text imply analogous statements for the Sierpinski gasket.

<sup>&</sup>lt;sup>2</sup> Hartmanis and Stearns, 1965.

<sup>&</sup>lt;sup>3</sup> Hennie, 1965.

![](_page_22_Picture_1.jpeg)

**Figure I.2** Disjointness when n = 8. Each row corresponds to a set X ⊆ [8], and each column corresponds to a set Y ⊆ [8]. The X,Y entry is black if and only if X and Y are disjoint.

### **Some Protocols**

A *communication protocol* specifies a way for a set of people to have a conversation. Each person has access to a different source of information, which is modeled as an *input* to the protocol. The protocol itself is assumed to be known to all the people that are involved in executing it. Their goal is to learn some feature of all the information that they collectively know.

**Equality** Suppose Alice and Bob are given two *n*-bit strings. Alice is given *x* and Bob is given y, and they want to know if *x* = y. There is a trivial solution: Alice can send her input *x* to Bob, and Bob can let her know if *x* = y. This is a *deterministic* protocol that takes The terms *deterministic* and *n* + 1 bits of communication. Interestingly, we shall prove that no deterministic protocol is more efficient. On the other hand, for every See Chapter 3. number *k*, there is a *randomized* protocol that uses only *k* + 1 bits of communication and errs with probability at most 2−<sup>k</sup> – the parties can use randomness to hash their inputs and compare the hashes. More on this in Chapter 3.

**Median** Suppose Alice is given a list of numbers from [*n*] and Bob is given a different list of numbers from [*n*]. They want to compute the median element of the list that is obtained by combining these lists. If *t* is the total number of elements in their lists, this is the *t*/2th element after the lists are combined and sorted. There is a simple For example, the median of protocol that takes *O*(log *n* · log *t*) bits of communication. In the first step, Alice and Bob each announce the number of their elements that are at most *n*/2. This takes *O*(log *t*) bits of communication. If there

*randomized* will be formally defined later in the book.

(1, 2, 3) and (2, 3, 4) is 2, the third element in the list (1, 2, 2, 3, 3, 4).

are k elements that are at most n/2 and  $k \ge \lceil t/2 \rceil$ , then Alice and Bob can safely discard all the elements that are larger than n/2 and recurse on the numbers that remain. If  $k < \lceil t/2 \rceil$ , then Alice and Bob can recurse after throwing out all the numbers that are at most n/2, and replacing  $\lceil t/2 \rceil$  by  $\lceil t/2 \rceil - k$ . There can be at most  $O(\log n)$  steps before all of their elements must come from a set of size 1. This single number is the median.

Cliques and Independent Sets Here Alice and Bob are given a graph G on n vertices. In addition, Alice knows a clique C in the graph, and Bob knows an independent set I in the graph. They want to know whether C and I share a common vertex or not, and they want to determine this using a short conversation. Describing C or I takes about n bits, because in general the graph may have  $2^n$  cliques or  $2^n$  independent sets. So, if Alice and Bob try to tell each other what C or I is, that will lead to a very long conversation.

Here we discuss a clever interactive protocol allowing Alice and Bob to have an extremely short conversation for this task. They will send at most  $O(\log^2 n)$  bits. If C contains a vertex v with degree less than n/2, Alice sends Bob the name of v. This takes just  $O(\log n)$ bits of communication. See Figure I.3 for an illustration. Now, either  $v \in I$ , or Alice and Bob can safely discard all the nonneighbors of v because these cannot be a part of C. This eliminates at least n/2vertices from the graph. Similarly, if I contains a vertex v of degree at least n/2, Bob sends Alice the name of v. Again, either  $v \in C$ , or Alice and Bob can safely delete all the neighbors of v from the graph, which eliminates about n/2 vertices. If all the vertices in C have degree more than n/2, and all the vertices in I have degree less than n/2, then C and I do not share a vertex. The conversation can safely terminate. So, in each round of communication, either the parties know that  $C \cap I = \emptyset$ , or the number of vertices is reduced by a factor of 2. After k rounds, the number of vertices is at most  $n/2^k$ . If k exceeds log n, the number of vertices left will be less than 1, and Alice and Bob will know if C and I share a vertex or not. This means that at most log n vertices can be announced before the protocol ends, proving that at most  $O(\log^2 n)$  bits will be exchanged before Alice and Bob learn what they wanted to know.

One can show that if the conversation involves only one message from each party, then at least  $\Omega(n)$  bits must be revealed for the parties to discover what they want to know. So, interaction is vital to bringing down the length of the conversation.

**Disjointness with Sets of Size** k Alice and Bob are given two sets  $A, B \subseteq [n]$ , each of size  $k \ll n$ , and want to know if the sets share a common element. Alice can send her set to Bob, which takes  $\log \binom{n}{k} \approx k \log(n/k)$  bits of communication. There is a randomized

A clique is a set of vertices that are all connected to each other. An independent set is a set of vertices that contains no edges. The degree of a vertex is the number of its neighbors.

![](_page_23_Picture_7.jpeg)

Figure I.3 The vertices that are not neighbors of  $\nu$  cannot be involved in any intersection between C and I.

protocol that uses only *O*(*k*) bits of communication. Alice and Bob sample a random sequence of sets in the universe and Alice announces the name of the first set that contains *A*. If *A* and *B* are disjoint, this eliminates half of *B*. In Chapter 3, we prove that repeating this procedure gives a protocol with *O*(*k*) bits of communication.

**Disjointness with <sup>k</sup> Parties** The input is *<sup>k</sup>* sets *<sup>A</sup>*1, ... , *<sup>A</sup>*<sup>k</sup> <sup>⊆</sup> [*n*], and there are *k* parties. The *i*th party knows all the sets *except for* the *i*th one. The parties want to know if there is a common element in all sets. We know of a clever deterministic protocol with *O*(*n*/2<sup>k</sup> ) bits of communication, and we know that Ω(*n*/4<sup>k</sup> ) bits of communication are See Chapters 4 and 5. In required. We do not know of any randomized protocol with communication better than the deterministic protocol discussed eariler, but we do know every randomized protocol must have communication at least Ω( √ *n*/2<sup>k</sup> ).

**Summing Three Numbers** The input is three numbers *x*, y, *z* ∈ [*n*]. Alice knows (*x*, y), Bob knows (y, *z*), and Charlie knows (*x*, *z*). The parties want to know whether or not *x* + y + *z* = *n*. Alice can tell Bob *x*, which would allow Bob to announce the answer. This takes *O*(log *n*) bits of communication. There is a clever deterministic proto- See Chapter 4. col that communicates  log *n* bits, and one can show that the length of any deterministic conversation must increase with *n*. In contrast, there is a randomized protocol that solves the problem with a conversation whose length is a constant.

**Pointer Chasing** The input consists of two functions *f* , g : [*n*] → [*n*], where Alice knows *<sup>f</sup>* and Bob knows <sup>g</sup>. Let *<sup>a</sup>*0, *<sup>a</sup>*1, ... , *<sup>a</sup>*<sup>k</sup> <sup>∈</sup> [*n*] be defined by setting *a*<sup>0</sup> = 1, and *a*<sup>i</sup> = *f* (g(*a*i−1)). The goal is to compute *a*<sup>k</sup> . There is a simple *k* round protocol with communication See Chapter 6. *O*(*k* log *n*) that solves this problem, but any protocol with fewer than *k* rounds requires Ω(*n*) bits of communication.

Chapter 4, we prove that when <sup>k</sup> > log <sup>n</sup>, it is enough for each party to announce the number of elements in [n] that are in i of the sets visible to her for <sup>i</sup> <sup>=</sup> 0, 1, ... , <sup>k</sup>.

# **Part I**

# **Communication**