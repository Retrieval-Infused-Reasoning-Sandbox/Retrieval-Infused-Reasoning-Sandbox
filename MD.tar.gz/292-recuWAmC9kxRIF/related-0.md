# **A Universal Density Profile from Hierarchical Clustering**

Julio F. Navarro 11affiliation: Bart J. Bok Fellow. E-mail: jnavarro@as.arizona.edu Steward Observatory, University of Arizona, Tucson, AZ, 85721, USA. Carlos S. Frenk 22affiliation: E-mail: C.S.Frenk@durham.ac.uk Physics Department, University of Durham, Durham DH1 3LE, England. Simon D.M. White 33affiliation: E-mail: swhite@mpa-garching.mpg.de Max Planck Institut für Astrophysik, Karl-Schwarzschild Strasse 1, D-85740, Garching, Germany.

#### **Abstract**

We use high-resolution N-body simulations to study the equilibrium density profiles of dark matter halos in hierarchically clustering universes. We find that all such profiles have the same shape, independent of halo mass, of initial density fluctuation spectrum, and of the values of the cosmological parameters. Spherically averaged equilibrium profiles are well fit over two decades in radius by a simple formula originally proposed to describe the structure of galaxy clusters in a cold dark matter universe. In any particular cosmology the two scale parameters of the fit, the halo mass and its characteristic density, are strongly correlated. Low-mass halos are significantly denser than more massive systems, a correlation which reflects the higher collapse redshift of small halos. The characteristic density of an equilibrium halo is proportional to the density of the universe at the time it was assembled. A suitable definition of this assembly time allows the same proportionality constant to be used for all the cosmologies that we have tested. We compare our results to previous work on halo density profiles and show that there is good agreement. We also provide a step-by-step analytic procedure, based on the Press-Schechter formalism, which allows accurate equilibrium profiles to be calculated as a function of mass in any hierarchical model.

cosmology: theory – dark matter – galaxies: halos – methods: numerical

# **1 Introduction**

It is twenty-five years since the discovery that galaxies are surrounded by extended massive halos of dark matter. A variety of observational probes – disk rotation curves, stellar kinematics, gas rings, motions of globular clusters, planetary nebulae and satellite galaxies, hot gaseous atmospheres, gravitational lensing effects – are now making it possible to map halo mass distributions in some detail. These distributions are intimately linked to the nature of the dark matter, to the way halos formed, and to the cosmological context of halo formation.

Insight into these links came first from analytic studies. Building on the early work of Gunn & Gott (1972), similarity solutions were obtained by Fillmore & Goldreich (1984) and Bertschinger (1985) for the self-similar collapse of spherical perturbations in an Einstein-de Sitter universe. Such solutions necessarily resemble power laws in the virialized regions. Hoffman & Shaham (1985) and Hoffman (1988) extended this analysis by considering open universes, and by modeling as scale-free spherical perturbations the objects which form by hierarchical clustering from power-law initial density perturbation spectra (P(k)∝knproportional-tosuperscriptP(k)\propto k^{n}). They argued that isothermal structure (ρ∝r−2proportionaltosuperscript2\rho\propto r^{-2}) should be expected in an Einstein-de Sitter universe if n≤−22n\leq-2, and that steeper profiles should be expected for larger nn and in open universes.

Despite the schematic nature of these arguments, their general predictions were verified as numerical data became available from NN-body simulations of hierarchical cosmologies. Power-law fits to halo density profiles in a variety of simulations all showed a clear steepening as nn increases or the density of the universe decreases (Frenk et al. 1985, 1988; Quinn et al. 1986; Efstathiou et al. 1988; Zurek, Quinn & Salmon 1988; Warren et al. 1992; Crone, Evrard & Richstone 1994). An apparent exception was the work of West et al. (1987), who found that galaxy cluster density profiles show no clear dependence on nn.

Significant departures from power-law behaviour were first reported by Frenk et al. (1988), who noted that halo profiles in cold dark matter (CDM) simulations steepen progressively with increasing radius. Efstathiou et al. (1988) found similar departures – at odds with the analytic predictions – in their simulations of scale-free hierarchical clustering. They also noted that these departures were most obvious in their best resolved halos. Similar effects were noted by Dubinski & Carlberg (1991) in a high resolution simulation of a galaxy-sized CDM halo. These authors found their halo to be well described by a density profile with a gently changing logarithmic slope, specifically that proposed by Hernquist (1990).

In earlier papers of this series we used high-resolution simulations to study the formation of CDM halos with masses spanning about four orders of magnitude, ranging from dwarf galaxy halos to those of rich galaxy clusters (Navarro, Frenk & White 1995, 1996). This work showed that the equilibrium density profiles of CDM halos of all masses can be accurately fit over two decades in radius by the simple formula,

ρ(r)ρcrit=δc(r/rs)(1+r/rs)2,subscriptsubscriptsubscriptsuperscript1subscript2{\rho(r) \over\rho\_{crit}}={\delta\_{c}\over(r/r\_{s})(1+r/r\_{s})^{2}}, (1)1

where rssubscriptr\_{s} is a scale radius, δcsubscript\delta\_{c} is a characteristic (dimensionless) density, and ρcrit=3H2/8πGsubscript3superscript28\rho\_{crit}=3H^{2}/8\pi G is the critical density for closure. This profile differs from the Hernquist (1990) model only in its asymptotic behaviour at r≫rsmuch-greaterthansubscriptr\gg r\_{s} (it tends to r−3superscript3r^{-3} instead of r−4superscript4r^{-4}). Power-law fits over a restricted radial range have

slopes which depend on the range fitted, steepening from −11-1 near the center to −33-3 at large r/rssubscriptr/r\_{s}.

This similarity between CDM halos of widely differing mass is surprising in view of the strong dependence on power spectrum shape reported in earlier studies. The effective slope of the CDM power spectrum varies from neff≈−2subscripteff2n\_{\rm eff}\approx-2 on galactic scales to neff≈−1subscripteff1n\_{\rm eff}\approx-1 on cluster scales, so one might have expected shallower profiles in galaxy halos than in clusters. In fact, the opposite is true; low-mass halos are denser, i.e. have higher values of δcsubscript\delta\_{c}, than high-mass halos. This property reflects the higher collapse redshift of the smaller systems. Power-law fits actually yield steeper slopes for less massive halos both when carried out at a fixed radius and when carried out at a fixed fraction of the virial radius (see Figures 3 and 4 of Navarro, Frenk & White 1996).

We argue below that the apparent relationship between profile shape and initial power spectrum seen in earlier work results from systematic differences in the characteristic density of the halos chosen when comparing different models. This interpretation is reinforced by the recent work of Cole & Lacey (1996) and Tormen, Bouchet & White (1996), who find that the profiles of massive halos formed from power-law spectra are well described by eq. 1. They also confirm the strong correlation between δcsubscript\delta\_{c} and halo mass seen in our earlier work, and they find that, at a given mass, halos are denser when nn is larger. Thus, the spectral index nn seems to control the exact relationship between characteristic density and halo mass, rather than the effective slope of the density profile.

It is clear from this discussion that a comprehensive study of this problem needs to consider the role of at least three factors: the halo mass, the power spectrum of initial density fluctuations, and the values of the cosmological parameters. In this paper we present the results of a large set of N-body simulations specifically designed to address these issues. We consider a variety of hierarchical clustering models, including CDM and power-law initial fluctuation spectra, as well as different values of the cosmological parameters Ω0subscriptΩ0\Omega\_{0} and ΛΛ\Lambda. In each cosmology we study halos spanning a large range in mass, carefully choosing numerical parameters so that all systems are simulated with comparable numerical resolution.

The plan of the paper is as follows. Our numerical experiments are described in §2. In §3 we present our results and in §4 we discuss them in the context of earlier work. In §5 we summarize our main conclusions. An appendix lays out the formulae necessary to calculate analytically the density profile of an equilibrium halo of any mass in any hierarchical cosmology.

# **2 The Numerical Experiments**

### **2.1 The Cosmological Models**

We analyze the structure of dark matter halos in 8 different cosmologies. Five are Einstein-de Sitter (Ω0=1subscriptΩ01\Omega\_{0}=1) models with various power spectra: the standard biased CDM spectrum (SCDM model: Ω0=1subscriptΩ01\Omega\_{0}=1, h=0.5ℎ0.5h=0.5, σ8=0.63subscript80.63\sigma\_{8}=0.63) and four power-law or "scale-free" spectra with indices n=00n=0, −0.50.5-0.5, −11-1, and −1.51.5-1.5. Two further models also have power-law spectra (n=00n=0 and −11-1) but in an open universe (Ω0=0.1subscriptΩ00.1\Omega\_{0}=0.1). The last model we consider is a low-density CDM model with a flat geometry (CDMΛΛ\Lambda: Ω0=0.25subscriptΩ00.25\Omega\_{0}=0.25, Λ=0.75Λ0.75\Lambda=0.75, h=0.75ℎ0.75h=0.75, σ8=1.3subscript81.3\sigma\_{8}=1.3). (Here and throughout this paper we express the cosmological constant ΛΛ\Lambda in units of 3H023superscriptsubscript023H\_{0}^{2}, so that a low-density universe with a flat geometry has Ω0+Λ=1subscriptΩ0Λ1\Omega\_{0}+ \Lambda=1. We also adopt the standard convention of writing the present Hubble constant as H0=100hsubscript0100ℎH\_{0}=100~{}h~{}km s-1 Mpc-1.)

The normalization of the CDM models is specified by σ8subscript8\sigma\_{8}, the rms mass fluctuation in spheres of radius 8h−18superscriptℎ18\,h^{-1} Mpc. Because of self-similarity, the normalization of the scale-free models is arbitrary. The evolutionary state of these models may be fully specified by a single parameter, the current value of the "nonlinear mass", M⋆(z)subscript⋆M\_{\star}(z). This mass scale is defined by requiring that the variance of the linear overdensity field at redshift z=00z=0, smoothed with a top-hat filter enclosing a mass M=M⋆subscript⋆M=M\_{\star}, should equal the square of the critical density threshold for spherical collapse by redshift zz: Δ02(M⋆(z))=δcrit2 (z,Ω0,Λ)superscriptsubscriptΔ02subscript⋆superscriptsubscript2subscriptΩ0Λ\Delta\_{0} ^{2}(M\_{\star}(z))=\delta\_{crit}^{2}(z,\Omega\_{0},\Lambda). (See the Appendix for details on the computation of δcritsubscript\delta\_{crit}). This definition provides a "natural" way to scale the scale-free simulations to physical units and to compare different cosmological models. In scale-free models the mass scale defined by M⋆(z)subscript⋆M\_{\star}(z) is the only physical scale, and therefore the structure of halos can depend on mass only through the ratio M/M⋆subscript⋆M/M\_{\star}.

### **2.2 The Simulations**

Large cosmological N–body simulations are required to simulate the evolution of dark matter halos in their full cosmological context. However, such simulations are not generally well suited to explore a large range of halo masses. This is because systems of differing mass formed in a single simulation are resolved to differing degrees. More massive systems are better resolved because they contain more particles and because the gravitational softening is a smaller fraction of the virial radius. These systematic

differences can introduce insidious numerical artifacts in the mass trends that we wish to investigate. We circumvent this problem by using the procedure outlined by Navarro, Frenk & White (1996). Halos are first identified in cosmological N-body simulations of large periodic boxes and then resimulated individually at higher resolution. During the resimulation the remainder of the original simulation is treated only to the accuracy needed to model tidal effects on the halo of interest. The advantage of this procedure is that numerical parameters can be tuned so that all halos are simulated with comparable resolution. Its main disadvantage is that only one halo is modeled per simulation, so that many simulations are needed to compile a representative halo sample.

#### **2.2.1 The cosmological simulations**

The cosmological simulations were carried out using the P3M code of Efstathiou et al. (1985). The desired initial power spectrum was generated by using the Zel'dovich approximation to displace particles from a uniform initial load. The uniform load we used was either a "glass" configuration (White 1996) or a cubic grid. For simulations with power-law power spectra, the amplitude of the initial displacements was chosen by setting the power of the perturbed density field to the white-noise level at the Nyquist frequency of the particle grid. These simulations followed 106superscript10610^{6} particles on a 1283superscript1283128^{3} mesh and were stopped when the nonlinear mass, M⋆subscript⋆M\_{\star}, corresponded to 1,00010001,000-2,00020002,000 particles. We identify this time with the present (z=00z=0). Since clustering evolves faster for more negative values of nn, an expansion factor of 9.59.59.5 was sufficient for n=−1.51.5n=-1.5 whereas an expansion factor of 90 was required for n=00n=0 (Ω0=1subscriptΩ01\Omega\_{0}=1). Open models require even longer integrations, an expansion factor exceeding 150 for n=00n=0 and Ω0=0.1subscriptΩ00.1\Omega\_{0}=0.1. These simulations used the timestepping and numerical scheme described in Efstathiou et al (1988). (Note, however, that the definition of M⋆subscript⋆M\_{\star} in that paper differs from the one we use here.)

We ran two P3M simulations for each of our CDM models. The SCDM runs followed 643superscript64364^{3} particles in periodic boxes of 180h−1180superscriptℎ1180\,h^{-1} and 15h−115superscriptℎ115\,h^{-1} Mpc and were stopped when σ8=0.63subscript80.63\sigma\_{8}=0.63 (M⋆≈1.6×1013h−1M⊙subscript⋆1.6superscript1013superscriptℎ1subscriptdirectproductM\_{\star}\approx 1.6\times 10^{13}h^{-1}\,M\_{\odot}), the time which we identify with the present. The CDMΛΛ\Lambda runs followed 106superscript10610^{6} particles in boxes of 140h−1140superscriptℎ1140\,h^{-1} and 46.67h−146.67superscriptℎ146.67\,h^{-1} Mpc, until σ8=1.3subscript81.3\sigma\_{8}=1.3 (M⋆≈4.1×1013h−1M⊙subscript⋆4.1superscript1013superscriptℎ1subscriptdirectproductM\_{\star}\approx 4.1\times 10^{13}h^{-1}\,M\_{\odot}).

### **2.2.2 The individual halo simulations**

Halos to be resimulated at higher resolution were selected randomly at z=00z=0 from a list of clumps identified using a friends-of-friends group finder with linking length set to 10%percent1010\% of the mean interparticle separation. We chose masses in the range 0.10.10.1– 10M⋆10subscript⋆10M\_{\star} for the power-law models and 0.010.010.01– 100M⋆100subscript⋆100M\_{\star} for the CDM models. (The mass range is larger for the CDM models because in this case halos were chosen from two parent cosmological simulations with different box sizes.) Because we are interested the structure of equilibrium halos we were careful not to choose for analysis any halo which is far from virial equilibrium. In practice, we analyze each resimulated halo at the time between redshifts 0.05 and 0 when it is closest to dynamical equilibrium, defined as the time when the ratio of kinetic to potential energy is closest to 0.5 for material within the virial radius. [Throughout this paper, we measure halo masses, M200subscript200M\_{200}, within a virial radius, r200subscript200r\_{200}, defined as the radius of a sphere of mean interior density 200ρcrit200subscript200\,\rho\_{crit}. Halo circular speeds, V200=(GM200/r200)1/2subscript200superscriptsubscript200subscript20012V\_{200} =(GM\_{200}/r\_{200})^{1/2}, are also measured at this radius unless otherwise specified. Numerical experiments show that for Ω=1Ω1\Omega=1 this radius approximately separates the virialized and infall regions (Cole & Lacey 1996). For convenience we continue to use these definitions when Ω0≠1subscriptΩ01\Omega\_{0}\neq 1.]

Once a halo is chosen for resimulation, the particles within its virial radius are traced back to the initial conditions, where a small box containing all of them is drawn. This box is filled with ∼323similar-toabsentsuperscript323\sim 32^{3} particles on a cubic grid which are then perturbed using the waves of the original P3M simulation, together with extra high-frequency waves added to fill out the power spectrum between the Nyquist frequencies of the old and new particle grids. The regions beyond the "high-resolution" box are coarsely sampled with a few thousand particles of radially increasing mass in order to account for the large-scale tidal fields present in the original simulation.

This procedure ensures the formation of a clump similar in all respects to the one selected in the P3M run, except for the improved numerical resolution. The size of the high-resolution box scales naturally with the total mass of each system and, as a result, all resimulated halos have about the same number of particles within the virial radius at z=00z=0, typically between 5, 00050005,000 and 10,0001000010,000. The extensive tests presented in Navarro, Frenk & White (1996) indicate that this number of particles is adequate to resolve the structure of a halo over approximately two decades in radius. We therefore choose the gravitational softening, hgsubscriptℎh\_{g}, to be 1%percent11\% of the virial radius in all cases. (This is the scale-length of a spline softening; see Navarro & White 1993 for a definition.) The tree-code carries out simulations in physical, rather than comoving, coordinates, and uses individual timesteps for each particle. The minimum timestep depends on the maximum density resolved in each case,

but was typically 10−5H0−1superscript105superscriptsubscript0110^{-5} H\_{0}^{-1}.

As discussed in Navarro, Frenk & White (1996), numerically convergent results require that the initial redshift of each run, zinitsubscriptz\_{init}, should be high enough that all resolved scales in the initial box are still in the linear regime. In order to satisfy this condition, we chose zinitsubscriptz\_{init} so that the median initial displacement of particles in the high-resolution box was always less than the mean interparticle separation. Problems with this procedure may arise if zinitsubscriptz\_{init} is so high that the gravitational softening (which is kept fixed in physical coordinates) becomes significantly larger that the mean initial interparticle separation. We found this to be a problem only for the smallest masses, M∼<M⋆∼<subscript⋆M\lower 3.22916pt\hbox{\$\sim\$} \hbox to0.0pt{\hss\raise 1.1625pt\hbox{\$<\$}}M\_{\star}, in the n=00n=0, Ω0=0.1subscriptΩ00.1\Omega\_{0}=0.1 model. In this case the initial redshift prescribed by the median displacement condition is zinit>700subscript700z\_{init}>700 and the gravitational softening is then a significant fraction of the initial box. This can affect the collapse of the earliest progenitors of these systems and so introduce spurious effects. We therefore limit our investigation to M∼>M⋆∼>subscript⋆M\lower 3.22916pt\hbox{\$\sim\$}\hbox to0.0pt{\hss\raise 1.1625pt\hbox{\$>\$}} M\_{\star} in this particular cosmological model. Further tests of the effects of particle number, timestep size, and gravitational softening are given by Tormen et al. (1996). Their results confirm that the numerical parameters chosen here are adequate to give stable and accurate results.

# **3 Results**

### **3.1 Time Evolution**

Figure 1 illustrates the time evolution of halos of different mass selected from the Ω0=1subscriptΩ01\Omega\_{0}=1, n=−11n=-1 series. Time runs from top to bottom and mass increases from left to right. The box size in each column is chosen so as to contain always approximately the same number of particles. The redshifts of each snapshot have been chosen so that the nonlinear mass M⋆subscript⋆M\_{\star} increases by factors of 444 from z2subscript2z\_{2} to z1subscript1z\_{1} and from z1subscript1z\_{1} to z0=0subscript00z\_{0}=0. This figure illustrates convincingly that low-mass halos complete their assembly earlier than more massive systems.

### **3.2 Density Profiles**

Figure 2 shows spherically averaged density profiles at z=00z=0 for one of the least and one of the most massive halos for each set of cosmological parameters. These halos span almost four orders of magnitude in mass in the case of the CDM models, and about two orders of magnitude in mass in the power-law models. Radial units are kpc for CDM models (scale at the top), and are arbitrary in the power-law panels. Density is in units of 1010M⊙/ 10^{10}M\_{\odot}/kpc<sup>3</sup> in the CDM models and in arbitrary units in the

others. Solid lines are fits to each halo profile using eq. 1. This simple formula provides a good fit to the structure of all halos over about two decades in radius, from the gravitational softening (indicated by arrows in Figure 2) to about the virial radius. The quality of the fit is essentially independent of halo mass or cosmological model and implies a remarkable uniformity in the equilibrium structure of dark matter halos in different hierarchical clustering models.

The solid and dashed lines in Figure 3 show the profile fits of Figure 2 but with the radius scaled to the virial radius of each halo. This scaling removes the intrinsic dependence of size on mass (more massive halos are bigger) and allows a meaningful comparison between halos of different mass. From the definition of virial radius, the "concentration" of a halo, c=r200/rssubscript200subscriptc=r\_{200}/r\_{s}, and the characteristic density, δcsubscript\delta\_{c}, are linked by the relation

```
δc=2003c3[ln(1+c)−c/(1+c)].subscript2003superscript3delimited-
[]11\delta_{c}={200\over 3}{c^{3}\over\bigl{[}\ln(1+c)-c/(1+c)
\bigr{]}}.
                                                                   (2)2
```

Thus at given halo mass (specified by M200subscript200M\_{200}), there is a single free parameter in eq. 1, which may be expressed either as the characteristic density, δcsubscript\delta\_{c}, or as the concentration parameter, cc. This free parameter varies systematically with mass; Figure 3 shows that cc and δcsubscript\delta\_{c} decrease with increasing halo mass.

A universal density profile implies a universal circular velocity profile, Vc(r)=(GM(r)/r)1/2subscriptsuperscript12V\_{c}(r)=(GM(r)/r)^{1/2}. This is illustrated in Figure 4, where we plot VcsubscriptV\_{c}-profiles for the same systems shown in Figure 2. As in Figure 3, radii are plotted in units of the virial radius; circular speeds have been normalized to the value at the virial radius, V200subscript200V\_{200}. The circular velocity curve implied by eq. 1 is

```
(Vc(r)V200)2=1xln(1+cx)−(cx)/(1+cx)ln(1+c)−c/(1+c),superscriptsubscriptsubscript200211111\biggl{(}
{V_{c}(r)\over V_{200}}\biggr{)}^{2}={1\over x}{\ln(1+cx)-(cx)/
(1+cx)\over\ln(1+c)-c/(1+c)},
                                                                 (3)3
```

where x=r/r200subscript200x=r/r\_{200} is the radius in units of the virial radius. Circular velocities rise near the center, reach a maximum (VmaxsubscriptV\_{max}) at xmax∼2/csimilar-tosubscript2x\_{max} \sim 2/c, and decline near the virial radius. More centrally concentrated halos (higher δcsubscript\delta\_{c} or higher cc) are characterized by higher values of Vmax/V200subscriptsubscript200V\_{max}/V\_{200}. The dashed lines in Figure 4 show plots of eq. 3 with parameter values derived from the fits to the density profiles of Figure 2. The dotted lines are fits using a Hernquist (1990) model constrained to match the location of the maximum of the VcsubscriptV\_{c}-curve. The two fits are indistinguishable near the center, but the Hernquist model underestimates VcsubscriptV\_{c} near the virial radius. This disagreement becomes more pronounced in lower mass

systems, for which δcsubscript\delta\_{c} and Vmax/V200subscriptsubscript200V\_{max}/V\_{200} are larger.

### **3.3 The mass dependence of halo structure**

The mass-density dependence pointed out above is further illustrated in Figure 5, where we plot δcsubscript\delta\_{c} versus mass (expressed in units of M⋆subscript⋆M\_{\star}) for all the systems in each series. An equivalent plot, illustrating the mass dependence of the concentration, cc, is shown in Figure 6. (The panel on the upper-left, corresponding to the SCDM model, is equivalent to Figure 7 of Navarro, Frenk & White 1996). The characteristic density of a halo increases towards lower masses in all the cosmological models considered. This result supports the idea that the M200subscript200M\_{200}-δcsubscript\delta\_{c} relation is a direct result of the higher redshift of collapse of less massive systems, and suggests a simple model to describe the mass-density relation. This model assigns to each halo of mass MM (identified at z=00z=0) a collapse redshift, zcoll(M,f)subscriptz\_{coll}(M,f), defined as the time at which half the mass of the halo was first contained in progenitors more massive than some fraction ff of the final mass. With this definition, zcollsubscriptz\_{coll} can be computed simply using the Press-Schechter formalism (e.g. Lacey & Cole 1993),

erfc(δcrit(zcoll)−δcrit02(Δ02(fM)−Δ02(M)))=12,erfcsubscriptsubscriptsuperscriptsubscript02subscriptsuperscriptΔ20subscriptsuperscriptΔ2012{\rm erfc}\biggl{(}{\delta\_{crit}(z\_{coll})-\delta\_{crit}^{0}\over\sqrt{2(\Delta^{2}\_{0}(fM)-\Delta^{2}\_{0}(M))}}\biggr{)} ={1\over 2},

where Δ02(M)superscriptsubscriptΔ02\Delta\_{0}^{2}(M) is the linear variance of the power spectrum at z=00z=0 smoothed with a top-hat filter of mass MM, δcrit(z)subscript\delta\_{crit}(z) is the density threshold for spherical collapse by redshift zz, and δcrit0=δcrit(0)superscriptsubscript0subscript0\delta\_{crit}^{0} =\delta\_{crit}(0). [This definition can be extended to halos identified at any redshift z0subscript0z\_{0} by replacing δcrit0superscriptsubscript0\delta\_{crit}^{0} by δcrit(z0)subscriptsubscript0\delta\_{crit}(z\_{0}) in eq. 4.] Assuming the characteristic density of a halo to be proportional to the density of the universe at the corresponding zcollsubscriptz\_{coll} then implies

δc(M|f)=CΩ0(1+zcoll(M,f))3subscriptconditionalsubscriptΩ0superscript1subscript3\delta\_{c} (M|f)=C\,\Omega\_{0}\,\bigl{(}1+z\_{coll}(M,f)\bigr{)}^{3} (5)5

where CC is a proportionality constant which might, in principle, depend on ff and on the power spectrum.

We will see below that f≪1much-less-than1f\ll 1 is needed for this argument to give a good fit to our simulation data. In this limit Δ02(fM)≫Δ02(M)muchgreater-thansubscriptsuperscriptΔ20subscriptsuperscriptΔ20\Delta^{2} \_{0}(fM)\gg\Delta^{2}\_{0}(M) and eq. 4 reduces to

δcrit(zcoll)=δcrit0+C′Δ0(fM),subscriptsubscriptsuperscriptsubscript0superscript′subscriptΔ0\delta\_{crit} (z\_{coll})=\delta\_{crit}^{0}+C^{\prime}\Delta\_{0}(fM),

where C′≈0.7superscript′0.7C^{\prime}\approx 0.7. For f≪1much-lessthan1f\ll 1, δcrit(zcoll)≫δcrit0much-greater-

thansubscriptsubscriptsuperscriptsubscript0\delta\_{crit}(z\_{coll}) \gg\delta\_{crit}^{0} for all masses in the range of interest, so that δcrit (zcoll)∝Δ0(fM)proportional-

tosubscriptsubscriptsubscriptΔ0\delta\_{crit}(z\_{coll})

\propto\Delta\_{0}(fM). Since M⋆(zcoll)subscript⋆subscriptM\_{\star} (z\_{coll}) is defined by

Δ0(M⋆(zcoll))=δcrit(zcoll)subscriptΔ0subscript⋆subscriptsubscriptsubscript\Delta\_{0} (M\_{\star}(z\_{coll}))=\delta\_{crit}(z\_{coll}), this equation implies that the characteristic density of a halo is proportional to the mean density of the universe at the time when M⋆≈fMsubscript⋆M\_{\star}\approx fM, ie. when the characteristic non-linear mass is a fixed small fraction of the final halo mass. For scale-free models this implies δc∝M−(n+3)/2proportionaltosubscriptsuperscript32\delta\_{c}\propto M^{-(n+3)/2}, the same scaling that links M⋆(z)subscript⋆M\_{\star}(z) and the mean cosmic density at redshift zz.

Figure 5 shows the correlations predicted from eq. 5 for three values of the parameter ff: 0.50.50.5, 0.10.10.1, and 0.010.010.01. The value of the proportionality constant, C(f)C(f), is chosen in each case in order to match the results of the Einstein-de Sitter simulations for M=M⋆subscript⋆M=M\_{\star}. These values are given in Table 1. The same values of C(f)C(f) are used to plot the curves in the panels corresponding to the low-density models. Some interesting results emerge from inspection of Figure 5 and Table 1.

- (i) The agreement between the mass-density dependence predicted by eq. 5 and the results of the Einstein-de Sitter simulations improves for smaller values of ff. This is also true for the low-density models. Once C(f)C(f) is fixed by matching the results of the Einstein-de Sitter models, the same value of C(f)C(f) provides a good match to the low density models only if f∼<0.01∼<0.01f\lower 3.22916pt\hbox{\$\sim\$}\hbox to0.0pt{\hss\raise 1.1625pt\hbox{\$<\$}}0.01. Interestingly, for f=0.010.01f=0.01 approximately the same value of the proportionality constant, C≈3×1033superscript103C\approx 3\times 10^{3}, seems to fit all our simulations.
- (ii) The characteristic density of M⋆subscript⋆M\_{\star} halos decreases systematically for more negative values of the spectral index nn. At M=M⋆subscript⋆M=M\_{\star}, SCDM halos are the least dense in our Ω0=1subscriptΩ01\Omega\_{0}=1 series, less concentrated still than those corresponding to n=−1.51.5n=-1.5. This is consistent with the general trend because, according to eqs. 4 and 5, the characteristic density of a halo of mass M⋆subscript⋆M\_{\star} is controlled by the shape of the power spectrum on scales ∼fM⋆similar-toabsentsubscript⋆\sim fM\_{\star}. This is about ∼1011M⊙similar-toabsentsuperscript1011subscriptdirect-product\sim 10^{11}M\_{\odot} for f≈0.010.01f\approx 0.01 and the effective slope of

the CDM spectrum on this mass scale is neff∼−2similartosubscripteff2n\_{\rm eff}\sim-2.

- (iii) For the power-law models with n=00n=0 and −11-1 the characteristic density at a given M/M⋆subscript⋆M/M\_{\star} increases as Ω0subscriptΩ0\Omega\_{0} decreases. Such a trend is plausible since we expect the collapse redshift of halos of a given mass to increase as Ω0subscriptΩ0\Omega\_{0} decreases. On the other hand, halos formed in the low-density CDMΛΛ\Lambda universe are actually less dense than those formed in the standard biased CDM model because δcsubscript\delta\_{c} depends not only on collapse redshift but also on Ω0subscriptΩ0\Omega\_{0} (see eq. 5). Although reducing Ω0subscriptΩ0\Omega\_{0} increases the collapse redshift, the increase in δcsubscript\delta\_{c} from the (1+zcoll)3superscript1subscript3(1+z\_{coll})^{3} factor can be outweighed by the change in Ω0subscriptΩ0\Omega\_{0}. In the CDMΛΛ\Lambda model the two effects can combine to give a reduction in δcsubscript\delta\_{c} as Ω0subscriptΩ0\Omega\_{0} decreases. (We remind the reader that δcsubscript\delta\_{c} is defined relative to the critical density rather than the mean density.)
- (iv) Each halo has a characteristic maximum circular speed, VmaxsubscriptV\_{max} (see eq. 3), which is strongly correlated with its mass. This is shown in Figure 7, where we also plot least squares fits of the form M200∝Vmaxαproportionaltosubscript200superscriptsubscriptM\_{200}\propto V\_{max} ^{\alpha} to the data in each series. Consistent with the trends shown in Figures 5 and 6, the correlation steepens as nn increases; we find α∼3.2similar-to3.2\alpha\sim 3.2 – 3.33.33.3 for CDM models and α>55\alpha>5 for n=00n=0. Note also that the correlations are extremely tight; the rms scatter in logM200subscript200\log M\_{200} is less than ∼0.1similar-toabsent0.1\sim 0.1 in all cases. This is in part a consequence of the generally good fit of the density profile of eq. 1. The ratio Vmax/V200subscriptsubscript200V\_{max}/V\_{200} increases only logarithmically with the central concentration of the halo, and changes only by about a factor of two as δcsubscript\delta\_{c} varies by four orders of magnitude between 103superscript10310^{3} and 107superscript10710^{7}. As a result, the M200subscript200M\_{200}-Vma xsubscriptV\_{max} relation does not deviate much from the M200subscript200M\_{200}-V200subscript200V\_{200} relation which, by definition, has zero scatter. This has important consequences for the expected tightness of empirical correlations between mass and characteristic velocity, such as the Tully-Fisher relation. We intend to return to this issue in future work.

The results in Figures 5–7 support our conclusion that the characteristic density of a halo is controlled mainly by the mean matter density of the universe at a suitably defined time of collapse. One important test of this interpretation is to measure zcollsubscriptz\_{coll} directly in the simulations and to compare the result to eq. 5. To do this we identify clumps at every output time using our friends-of-friends group-finder with linking length set to 20%percent2020\% of the current mean interparticle

separation. We then trace the particles in the most massive clump identified at z=00z=0 (which typically has a mean overdensity of ∼200similartoabsent200\sim 200) and, at each redshift, add up the total mass in clumps which contain any of these particles and which are individually more massive than 10%percent1010\% of the final mass. We identify zcollsubscriptz\_{coll} with the redshift at which this mass first exceeds half of the final mass. This is roughly equivalent to the analytic procedure outlined in eq. 4 for f=0.10.1f=0.1. (We decided to use f=0.10.1f=0.1 rather than f=0.010.01f=0.01 because the smaller value results in very high collapse redshifts, often before the first output in the simulation.) The main difference is that some of the mass from the high redshift progenitors ends up outside the virial radius at z=00z=0. This causes a slight bias of the measured collapse redshifts towards higher values than the Press-Schechter predictions.

The correlation between δc/Ω0subscriptsubscriptΩ0\delta\_{c}/\Omega\_{0} and (1+zcoll)3superscript1subscript3(1+z\_{coll})^{3} obtained using this procedure is shown in Figure 8. All halos in Einstein-de Sitter models are shown with filled circles; those in open universes with open circles; and those in the CDMΛΛ\Lambda model with starred symbols. The solid line is the relation predicted by eq. 5 for C=5×1035superscript103C=5\times 10^{3}. This is clearly an excellent approximation to the results of the numerical simulations, and confirms that the mean matter density of the universe at the time of collapse is the main factor determining the characteristic density of a halo. Note that the value of the proportionality constant is slightly lower than the values given in Table 1 for f=0.10.1f=0.1. This difference compensates for the slight bias towards higher collapse redshifts introduced by our numerical procedure.

A summary of our results is presented in Figure 9. The panels on the left compile the fits (for f=0.010.01f=0.01) to the mass dependence of δcsubscript\delta\_{c} and cc in the Einstein-de Sitter models. The panels on the right compare the Einstein-de Sitter results with those for low-density models. As noted above, the typical density of M⋆subscript⋆M\_{\star}-halos increases with nn. However, the difference between models becomes less pronounced at higher masses, and is almost negligible at M∼> 10 M⋆∼>10subscript⋆M\,\lower 3.22916pt\hbox{\$\sim\$}\hbox to0.0pt{\hss\raise 1.1625pt\hbox{\$>\$}}\,10M\_{\star}. Halos of a given M/M⋆subscript⋆M/M\_{\star} in low density universes can have either lower or higher characteristic densities than their Einstein-de Sitter counterparts, depending on the competing effects of the collapse redshift and the value of Ω0subscriptΩ0\Omega\_{0}. Note that all the curves in Figure 9 use the same value, f=0.010.01f=0.01, and essentially the same value of the proportionality constant C≈3×1033superscript103C\approx 3\times 10^{3} (see eq. 5). Thus, once calibrated for an Einstein-de Sitter model, it is possible to apply eqs. 4 and 5 to predict the characteristic density of halos formed in other hierarchically clustering models. In the Appendix we provide a detailed description of how to compute δc(M)subscript\delta\_{c}(M) numerically for a variety of cosmologies.

### **3.4 The scatter in the correlations**

We examine now the origin of the scatter in the correlations presented above. In particular, we explore whether at fixed mass the dispersion in the measured values of δcsubscript\delta\_{c} is due to variations either in the collapse redshift or in the global angular momentum of the system. As shown by Figures 10 and 11, the bulk of the scatter in δcsubscript\delta\_{c} at a given M/M⋆subscript⋆M/M\_{\star} can be attributed to small differences in the redshift of collapse. Figure 10 shows that the δcsubscript\delta\_{c} deviations from the solid-line fits in Figure 5 (i.e. those for f=0.010.01f=0.01) correlate strongly with deviations in the redshift of collapse. (The latter are measured from least-square fits to the M200subscript200M\_{200} vs (1+zc oll)1subscript(1+z\_{coll}) correlations measured directly from the simulations.) Furthermore, the two residuals seem to correlate just as expected from eq. 5, i.e.

Δlogδc=3Δlog(1+zcoll)Δsubscript3Δ1subscript\Delta\log\delta\_{c} =3\Delta\log(1+z\_{coll}). (We note that the magnitude of this scatter may not be fully representative of the dispersion in halo properties corresponding to each cosmological model, since the sample has been selected so as to minimize departures from equilibrium.) This relation is indicated by the solid line and is seen to reproduce very well the trend observed in Figure 10. Figure 11 shows the same δcsubscript\delta\_{c}-residuals of Figure 10, but now as a function of the scatter in the mass–rotation parameter (M200subscript200M\_{200} vs λ\lambda) correlation. (The rotation parameter is defined by

λ=J|E|1/2/GM5/2superscript12superscript52\lambda=J|E|^{1/2}/ GM^{5/2}, where JJ is the angular momentum and EE is the binding energy of the halo. The median λ\lambda in our series is ∼0.04similartoabsent0.04\sim 0.04, in good agreement with previous studies.) We find no discernible correlation between M/M⋆subscript⋆M/M\_{\star} and λ\lambda or between the δcsubscript\delta\_{c}- and λ\lambda-residuals (Figure 11). This provides further evidence supporting our contention that the redshift of collapse is the primary factor determining the characteristic density of a halo.

# **4 Comparison with previous work**

The main conclusion of our study, that the shape of halo density profiles is independent of cosmological context, appears to contradict previous work on this subject. As discussed in §1, a strong dependence of the slope of the density profile on the spectral index nn and the density parameter Ω0subscriptΩ0\Omega\_{0} has been established by a number of analytic and numerical studies. We now show that our results actually include and extend those of previous workers, and we offer an attractive explanation for some discrepancies found in the literature.

We first address the claim by Quinn et al. (1986), Efstathiou et al (1988), Zurek et al. (1988), and Warren et al. (1992) that halo density profiles steepen with increasing values of the spectral index nn in an Einstein-de Sitter universe. This claim is based on the discovery that circular velocity

profiles of galaxy-sized halos are relatively flat for n≈−22n\approx-2 (or for SCDM; Frenk et al. 1985) but decline progressively faster at large rr for larger nn. Figure 12 shows that we find the same trend if we analyze our data in the same fashion as these authors. In this figure we plot, in linear units, the VcsubscriptV\_{c}-profile of an M⋆subscript⋆M\_{\star} halo for different values of nn. Each curve has been computed using eq. 3 and the values of cc obtained from the fits presented in Figure 999. Since all these halos have the same mass, they also have the same virial radius and circular speed, r200subscript200r\_{200} and V200subscript200V\_{200}, respectively, which we have used as normalizing factors. The linear units in Figure 12 obscure the fact that the form of the curves is the same in all cases, and encourage one to conclude, as did previous authors, that halo rotation curves steepen with increasing nn. In fact this trend is present because M⋆subscript⋆M\_{\star} halos collapse earlier, and so are denser, for larger values of nn.

We note that the trend with nn in Figure 12 is sensitive to the choice of halo mass. Had we used halos with M<M⋆subscript⋆M<M\_{\star} the trend would have been stronger. On the other hand, very massive halos (M∼>10M⋆∼>10subscript⋆M\,\lower 3.22916pt\hbox{\$\sim\$}\hbox to0.0pt{\hss\raise 1.1625pt\hbox{\$>\$}}10\,M\_{\star}) have similar characteristic densities, irrespective of nn (see Figure 9). Thus, had we plotted very massive halos in Figure 12 we would have concluded that the density profile depends only weakly on nn (at least for Ω0=1subscriptΩ01\Omega\_{0}=1). This is reminiscent of the claim by West et al. (1987) that the structure of galaxy cluster halos is independent of nn in Einstein-de Sitter universes. Our analysis suggests an explanation for this apparently discrepant result. By considering only the most massive systems in their simulations, West et al. focused on a mass range where the dependence of δcsubscript\delta\_{c} on nn is minimal, and so concluded (correctly) that cluster profiles depend very weakly on initial power spectrum.

A similar explanation accounts for the weak dependence of halo density profile on spectral index nn and on Ω0subscriptΩ0\Omega\_{0} reported by Crone et al. (1994). These authors chose to combine the 35 most massive clumps in each of their cosmological simulations in order to produce an "average" density profile for each value of nn and Ω0subscriptΩ0\Omega\_{0}. They then fitted power laws of the form ρ(r)∝rγproportional-tosuperscript\rho(r)\propto r^{\gamma} to these profiles in the radial range corresponding to density contrasts between 100 and 3000. For Ω0=1subscriptΩ01\Omega\_{0}=1, this procedure yielded γ\gamma values that decrease from −2.22.2-2.2 to −2.52.5-2.5 as nn increases from −22-2 to 00 (see the curve labeled "EdS" in their Figure 4). Our results show this weak trend to be a consequence of the averaging procedure they adopted. The shape of the halo mass function depends strongly on nn and is increasingly peaked around M≈M⋆subscript⋆M\approx M\_{\star} for larger values of nn. Thus, combining the 35 most massive clumps in a simulation results in different "effective" masses for different values of nn, with a bias towards larger values of M/M⋆subscript⋆M/M\_{\star} for more negative values of nn. Applying the same selection procedure as Crone et al. to our own

cosmological simulations we find that the median mass of these halo ensembles increases from ∼M⋆similar-toabsentsubscript⋆\sim M\_{\star} for n=00n=0 to ∼ 6M⋆similar-toabsent6subscript⋆\sim\,6M\_{\star} for n=−1.51.5n=-1.5. As illustrated in Figure 13, fitting power-laws to the density profiles of these "average" halos results in a weak steepening with nn similar to the trend reported by Crone et al. The slopes of γ∼−3similarto3\gamma\sim-3 which they found for low density models are also easily understood, since in these cases they fit a radial range which extends well outside our nominal virial radius r200subscript200r\_{200}.

Our results are also in agreement with recent work by Cole & Lacey (1996) and Tormen et al. (1996), who analyzed the structure of massive halos (M>M⋆subscript⋆M>M\_{\star}) in scale-free universes. The general correlations with mass which they report (more massive halos tend to be less centrally concentrated than less massive halos) agree well with the results we present in §3. At a given halo mass, however, Cole & Lacey's halos are significantly less concentrated than ours. For example, for M⋆subscript⋆M\_{\star} halos they find c∼12similar-to12c\sim 12 and ∼17similar-toabsent17\sim 17 for n=−11n=-1 and 00, respectively (Ω0=1subscriptΩ01\Omega\_{0}=1), compared with c∼17similar-to17c\sim 17 and ∼30similar-toabsent30\sim 30 in our simulations (see connected symbols in the lower-right panel of Figure 9). On the other hand, the results of Tormen et al. (1996) are in very good agreement with ours; they find c∼10similar-to10c\sim 10 for a 10M⋆10subscript⋆10M\_{\star} halo formed in an n=−11n=-1, Ω0=1subscriptΩ01\Omega\_{0}=1 universe, which compares well with c∼9similar-to9c\sim 9 that we find for a similar system.

As discussed in detail by Tormen et al, the discrepancy between our results and those of Cole & Lacey is likely to be due in part to the poorer numerical resolution of their simulations. Indeed, their simulations used gravitational softenings that are 222-333 times larger than ours and timesteps which are also significantly longer than the typical values in our simulations. Both of these effects can artificially lower the central concentration of a halo. A concurrent factor may be the averaging procedure adopted by Cole & Lacey. These authors constructed average density profiles by co-adding all halos of similar mass identified in their cosmological simulations, regardless of their dynamical state. This sample contains a number of unrelaxed systems and ongoing mergers where substructure and double centers can bias the results of the fitting procedure towards lower concentrations.

We can test directly for the effects of these various factors by applying the averaging procedure of Cole & Lacey to halos identified in our own P3Msuperscript3P^{3}M cosmological simulations (see §2.2.1) and comparing with the results of the individual halo runs. We restrict this comparison to the most massive halos in each run, M∼> 10 M⋆∼>10subscript⋆M\,\lower 3.22916pt\hbox{\$\sim\$}\hbox to0.0pt{\hss\raise 1.1625pt\hbox{\$>\$}}\,10M\_{\star}, since these systems have a large number of particles and comparable numerical resolution to that of Cole & Lacey. The comparison confirms that the central concentration of halos can be significantly underestimated as a result of the factors mentioned above. The magnitude of the effect is sensitive to nn and

Ω0subscriptΩ0\Omega\_{0}; the concentration cc can be underestimated by up to a factor of ∼3similar-toabsent3\sim 3 for n=00n=0 and Ω0=0.1subscriptΩ00.1\Omega\_{0}=0.1, but by less than ∼1.5similartoabsent1.5\sim 1.5 for n=−11n=-1 and Ω0=1subscriptΩ01\Omega\_{0}=1. We conclude that the disagreement between our results and those of Cole & Lacey is likely to be the result of the combined effect of their halo selection and averaging procedures and their poorer numerical resolution.

# **5 Discussion**

Our results suggest that equilibrium dark halos formed through dissipationless hierarchical clustering have density profiles with a universal shape which does not depend on their mass, on the power spectrum of initial fluctuations, or on the cosmological parameters Ω0subscriptΩ0\Omega\_{0} and ΛΛ\Lambda. It appears that mergers and collisions act during halo formation as a "relaxation" mechanism to produce an equilibrium which is largely independent of initial conditions. This mechanism must operate rapidly since the similarity between profiles extends to the virial radius. These properties are characteristic of the "violent relaxation" process proposed by Lynden-Bell (1967) to explain the regularities observed in the structure of elliptical galaxies, and it is interesting that our universal profile is similar to the Hernquist profile which gives a good description of elliptical galaxy photometry. The two differ significantly only at large radii, perhaps because ellipticals are relatively isolated systems whereas dark halos are not. Syer & White (1996) suggest that a universal profile may be understood as a fixed point for a process of repeated mergers between unequal objects. Their analysis of this process predicts a dependence on initial power spectrum which seems stronger, however, than that seen in our numerical data.

Our simulations suggest that the density profile of an isolated equilibrium halo can be specified quite accurately by giving two parameters; halo mass and halo characteristic density. Furthermore, in any particular hierarchical model these parameters are related in such a way that the characteristic density is proportional to the mean cosmic density at the time when the mass of typical nonlinear objects was some fixed small fraction of the halo mass. The characteristic density thus reflects the density of the universe at the collapse time of the objects which merge to form the halo core. With this interpretation we are able to fit the mass-density relation for equilibrium halos in all the cosmological models we have considered. In addition, it is possible to calculate the mass-density relation in any other hierarchical model (see Appendix). It is difficult to imagine a simpler situation – halos of all masses in all hierarchical cosmologies look the same, and their characteristic densities are just proportional to the cosmic density at the time they "formed".

Our results extend the radial range over which dark halo structure can reliably be determined to more than two decades. The central regions of our models have densities of order

106ρcritsuperscript106subscript10^{6}\rho\_{crit}, comparable to those in the luminous parts of galaxies and in the central cores of galaxy clusters. As a result a variety of direct observational tests of our predictions are

available. In Navarro et al. (1996) we discussed several of these in the context of the standard CDM cosmogony – rotation curves of giant and dwarf galaxies, satellite galaxy dynamics, hot gaseous atmospheres around galaxies and in clusters, strong and weak gravitational lensing – all provide interesting constraints. We will not pursue these issues here, however, because they would take us too far from our primary goal, namely the presentation of a simple and apparently general theoretical result: hierarchical clustering leads to a universal halo density profile just as it leads to universal distributions of halo axial ratios and halo spins; none of these properties depends strongly on power spectrum, on ΩΩ\Omega, or on ΛΛ\Lambda [see Cole & Lacey (1996) and references therein]. Comparison of the predicted halo structure with observation should, of course, provide strong constraints on the parameters which define particular hierarchical cosmogonies, and perhaps on the hierarchical clustering paradigm itself. We expect to come back to these issues in future work.

We are grateful for the hospitality of the Institute for Theoretical Physics of the University of California at Santa Barbara, where some of the work presented here was carried out. JFN is also grateful for the hospitality of the Max Planck Institut für Astrophysik in Garching, where this project was started. In addition he would like to acknowledge useful discussions with Cedric Lacey. Special thanks are due to Shaun Cole for making the data shown in Figure 9 available in electronic form. This work was supported in part by the PPARC and by the NSF under grant No. PHY94-07194 to the Institute for Theoretical Physics of the University of California at Santa Barbara.

# **Appendix A Step-by-step calculation of the density profile of a dark matter halo**

In this Appendix we describe in detail the calculation of the parameters that specify the density profile of a dark halo of mass MM. This calculation is applicable to Einstein-de Sitter (Ω0=1subscriptΩ01\Omega\_{0}=1, Λ=0Λ0\Lambda=0), open (Ω0<1subscriptΩ01\Omega\_{0}<1, Λ=0Λ0\Lambda=0), and flat (Ω0+Λ=1subscriptΩ0Λ1\Omega\_{0}+ \Lambda=1) universes. We provide approximate fitting formulae that are valid for power-law and CDM initial density fluctuation spectra.

A halo of mass MM identified at z=z0subscript0z=z\_{0} can be characterized by its virial radius,

r200=1.63×10−2(Mh−1M⊙)1/3(Ω0Ω(z0))−1/3(1+z0)−1h−1kpc,subscript2001.63superscript102superscriptsuperscriptℎ1subscriptdirectproduct13superscriptsubscriptΩ0Ωsubscript013superscript1subscript01superscriptℎ1kpcr\_{200} =1.63\times 10^{-2}\biggl{(}{M\over h^{-1}M\_{\odot}}\biggr{)}^{1/3}\biggl{(} {\Omega\_{0}\over\Omega(z\_{0})}\biggr{)}^{-1/3}(1+z\_{0})^{-1}\,h^{-1}{\rm kpc},

or by its circular velocity,

```
V200=(GMr200)1/2=(r200h−1kpc)(Ω0Ω(z0))1/2(1+z0)3/2km/s.subscript200superscriptsubscript20012subscript200superscriptℎ1kpcsuperscriptsubscriptΩ0Ωsubscript012superscript1subscript032kmsV_{200}
=\biggl{(}{GM\over r_{200}}\biggr{)}^{1/2}=\biggl{(}{r_{200}\over h^{-1}{\rm kpc}}\biggr{)}\,\biggl{(}{\Omega_{0}\over\Omega(z_{0})}
\biggr{)}^{1/2}(1+z_{0})^{3/2}\,{\rm km/s}.
```

The density profile of this system is fully specified by its characteristic density δcsubscript\delta\_{c} and is given by (see eq.1)

```
ρ(r)=3H028πG(1+z0)3Ω0Ω(z0)δccx(1+cx)2,3superscriptsubscript028superscript1subscript03subscriptΩ0Ωsubscript0subscriptsuperscript12\rho(r)={3H_{0}
^{2}\over 8\pi G}\,(1+z_{0})^{3}\,{\Omega_{0}\over\Omega(z_{0})}\,{\delta_{c}\over cx(1+cx)^{2}}, (A3)3
```

where x=r/r200subscript200x=r/r\_{200} and cc is the concentration parameter, a function of δcsubscript\delta\_{c} given in eq. 2. The corresponding circular velocity profile, Vc(r)subscriptV\_{c}(r), is given by

```
(Vc(r)V200)2=1xln(1+cx)−(cx)/(1+cx)ln(1+c)−c/(1+c),superscriptsubscriptsubscript200211111\biggl{(}
{V_{c}(r)\over V_{200}}\biggr{)}^{2}={1\over x}{\ln(1+cx)-(cx)/
(1+cx)\over\ln(1+c)-c/(1+c)},
                                                                (A4)4
```

using the concentration cc as a parameter.

The characteristic density is determined by the collapse redshift zcollsubscriptz\_{coll}, which is given by (see eq. 4)

```
δcrit(zcoll)δcrit(z0)=δcrit0(Ω(zcoll),Λ)δcrit0(Ω(z0),Λ)D(z0,Ω0,Λ)D(zcoll,Ω0,Λ)=1+0.477δcrit(z0)2(Δ02(fM)−Δ02(M))subscriptsubscriptsubscriptsubscript0superscriptsubscript0ΩsubscriptΛsuperscriptsubscript0Ωsubscript0Λsubscript0subscriptΩ0ΛsubscriptsubscriptΩ0Λ10.477subscriptsubscript02superscriptsubscriptΔ02superscriptsubscriptΔ02{\delta_{crit}
(z_{coll})\over\delta_{crit}(z_{0})}={\delta_{crit}^{0}(\Omega(z_{coll}),\Lambda)\over\delta_{crit}^{0}(\Omega(z_{0}),\Lambda)}{D(z_{0},\Omega_{0},\Lambda)\over D(z_{coll},\Omega_{0},\Lambda)}=1+{0.477\over\delta_{crit}(z_{0})}\sqrt{2(\Delta_{0}^{2}(fM)-
\Delta_{0}^{2}(M))}
```

Here D(z,Ω0,Λ)subscriptΩ0ΛD(z,\Omega\_{0},\Lambda) is an ΩΩ\Omegadependent linear growth factor that can be written as

```
D(z,Ω0,Λ)={1/(1+z)if Ω0=1 and Λ=0,F1(w)/F1(w0)if Ω0<1 and Λ=0,F2(y)F3(y)/F2(y0)F3(y0)if Ω0+Λ=1,subscriptΩ0Λcases11if Ω0=1 and Λ=0,subscript1subscript1subscript0if Ω0<1 and Λ=0,subscript2subscript3subscript2subscript0subscript3subscript0if Ω0+Λ=1,D(z,
\Omega_{0},\Lambda)=\cases{{1/(1+z)}&if $\Omega_{0}=1$ and $\Lambda=0$,\cr{F_{1}(w)/F_{1}(w_{0})}&if $\Omega_{0}<1$ and $\Lambda=0$,\cr{F_{2}(y)F_{3}(y)/F_{2}(y_{0})F_{3}
(y_{0})}&if $\Omega_{0}+\Lambda=1$,\cr}
```

where we have used the following auxiliary definitions,

```
w0=1Ω0−1,subscript01subscriptΩ01w_{0}
={1\over\Omega_{0}}-1, (A7)7
w=w01+z,subscript01w={w_{0}\over 1+z}, (A8)8
F1(u)=1+3u+3(1+u)1/2u3/2ln[(1+u)1/2−u1/2],subscript1133superscript112superscript32superscript112superscript12F_{1}
(u)=1+{3\over u}+{3(1+u)^{1/2}\over u^{3/2}}\ln{\bigl{[}(1+u)^{1/2}-
u^{1/2}\bigr{]}},
y0=(2w0)1/3,subscript0superscript2subscript013y_{0}
=(2w_{0})^{1/3}, (A10)10
y=y01+z,subscript01y={y_{0}\over 1+z}, (A11)11
F2(u)=(u3+2)1/2u3/2,subscript2superscriptsuperscript3212superscript32F_{2}
(u)={(u^{3}+2)^{1/2}\over u^{3/2}}, (A12)12
```

and

```
F3(u)=∫0u(u′u′3+2)3/2u′.subscript3superscriptsubscript0superscriptsuperscript′superscript′3232differential-
dsuperscript′F_{3}(u)=\int_{0}^{u}\biggl{(}{u^{\prime}\over u^{\prime
3}+2}\biggr{)}^{3/2}du^{\prime}.
```

A good numerical approximation to the ΩΩ\Omega-dependence of the critical threshold for spherical collapse is given by

```
δcrit0(Ω,Λ)={0.15(12π)2/3if Ω=1 and Λ=0,0.15(12π)2/3Ω0.0185if Ω0<1 and Λ=0,0.15(12π)2/3Ω0.0055if Ω0+Λ=1,superscriptsubscript0ΩΛcases0.15superscript1223if Ω=1 and Λ=0,
0.15superscript1223superscriptΩ0.0185if Ω0<1 and Λ=0,0.15superscript1223superscriptΩ0.0055if Ω0+Λ=1,\delta_{crit}^{0}(\Omega,\Lambda)=\cases{0.15\,(12\pi)^{2/3}&if $\Omega=1$ and $\Lambda=0$,
\cr 0.15\,(12\pi)^{2/3}\,\Omega^{0.0185}&if $\Omega_{0}<1$ and $\Lambda=0$,\cr 0.15\,(12\pi)^{2/3}\,\Omega^{0.0055}&if $\Omega_{0}+\Lambda=1$,\cr}
```

which can be used to compute

δcrit(z0)=δcrit0(Ω(z0))/D(z0,Ω0,Λ)subscriptsubscript0superscriptsubscript0Ωsubscript0subscript0subscriptΩ0Λ\delta\_{crit} (z\_{0})=\delta\_{crit}^{0}(\Omega(z\_{0}))/D(z\_{0},\Omega\_{0},\Lambda). Finally, eq. A5 requires Δ02(M)superscriptsubscriptΔ02\Delta\_{0}^{2}(M), the variance of the power spectrum on mass scale MM, extrapolated linearly to z=00z=0. In the case of a power-law spectrum of initial density fluctuations, P(k)∝knproportional-tosuperscriptP(k)\propto k^{n}, this is simply

```
Δ02(M)=δcrit0(MM⋆(z=0))−(n+3)/6,superscriptsubscriptΔ02superscriptsubscript0superscriptsubscript⋆036\Delta_{0}
^{2}(M)=\delta_{crit}^{0}\biggl{(}{M\over M_{\star}(z=0)}\biggr{)}^{-(n+3)/6}, (A15)15
```

where we have normalized the spectrum by M⋆(z=0)subscript⋆0M\_{\star} (z=0), the present nonlinear mass. A CDM spectrum is usually normalized by σ8subscript8\sigma\_{8}, the rms mass fluctuations within a sphere of radius 8h−18superscriptℎ18h^{-1} Mpc, and its variance can be approximated by,

Δ0(M)=σ8F4(M8)/F4(Mh),subscriptΔ0subscript8subscript4subscript8subscript4subscriptℎ\Delta\_{0} (M)=\sigma\_{8}F\_{4}(M\_{8})/F\_{4}(M\_{h}), (A16)<sup>16</sup>

where we have used the following definitions,

```
M8=6.005×1014(hΩ0)3,subscript86.005superscript1014superscriptℎsubscriptΩ03M_{8}
=6.005\times 10^{14}(h\,\Omega_{0})^{3}, (A17)17
Mh=(Mh−1M⊙)h3Ω02subscriptℎsuperscriptℎ1subscriptdirect-
productsuperscriptℎ3superscriptsubscriptΩ02M_{h}=\biggl{(}
{M\over h^{-1}M_{\odot}}\biggr{)}h^{3}\Omega_{0}^{2}
                                                        (A18)18
```

and

```
F4(u)=A1u0.67[1+(A2u−0.1+A3u−0.63)p]1/p,subscript4subscript1superscript0.67superscriptdelimited-
[]1superscriptsubscript2superscript0.1subscript3superscript0.631F_{4}
(u)=A_{1}u^{0.67}\bigl{[}1+(A_{2}u^{-0.1}+A_{3}u^{-0.63})^{p}
\bigr{]}^{1/p},
                                                                      (A19)19
```

```
with A1=8.6594×10−12subscript18.6594superscript1012A_{1}
=8.6594\times 10^{-12}, A2=3.5subscript23.5A_{2}=3.5, 
A3=1.628×109subscript31.628superscript109A_{3}=1.628\times 10^{9},
and p=0.2550.255p=0.255.
```

Eqs. A6-A19 can be used to solve eq. A5 and find the collapse redshift, zcollsubscriptz\_{coll}, corresponding to a halo of mass MM. As noted when discussing Fig. 5, we recommend using f=0.010.01f=0.01 when solving eq. A5, since this value seems to reproduce well the results of all our numerical experiments.

Once zcoll(M)subscriptz\_{coll}(M) has been found, the characteristic density of the halo (expressed in units of the critical density at z=z0subscript0z=z\_{0}) can be computed from (see eq.5 and Table 1),

δc(M,z0)∼3×103Ω(z0)(1+zcoll1+z0)3,similartosubscriptsubscript03superscript103Ωsubscript0superscript1subscript1subscript03\delta\_{c} (M,z\_{0})\sim 3\times 10^{3}\,\Omega(z\_{0})\biggl{(}{1+z\_{coll}\over 1+z\_{0}}\biggr{)}^{3},

where we have assumed f=0.010.01f=0.01. A FORTRAN subroutine that implements the procedure described here and returns δc(M,z0)subscriptsubscript0\delta\_{c}(M,z\_{0}) for all the cosmologies we discuss is available from the authors upon request.

| P(k)𝑃𝑘P(k)       | Ω0subscriptΩ0\Omega_{0} | ΛΛ\Lambda | f𝑓f  | C(f)𝐶𝑓C(f)                                     |
|------------------|-------------------------|-----------|------|------------------------------------------------|
| CDM              | 1.0                     | 0.0       | 0.5  | 1.75×1041.75superscript1041.75\times<br>10^{4} |
|                  | 1.0                     | 0.0       | 0.1  | 7.44×1037.44superscript1037.44\times<br>10^{3} |
|                  | 1.0                     | 0.0       | 0.01 | 3.41×1033.41superscript1033.41\times<br>10^{3} |
| CDMΛΛ\Lambda     | 0.25                    | 0.75      | 0.5  | 1.75×1041.75superscript1041.75\times<br>10^{4} |
|                  | 0.25                    | 0.75      | 0.1  | 7.44×1037.44superscript1037.44\times<br>10^{3} |
|                  | 0.25                    | 0.75      | 0.01 | 3.41×1033.41superscript1033.41\times<br>10^{3} |
| n=−1.5𝑛1.5n=-1.5 | 1.0                     | 0.0       | 0.5  | 3.00×1043.00superscript1043.00\times<br>10^{4} |
|                  | 1.0                     | 0.0       | 0.1  | 1.08×1041.08superscript1041.08\times<br>10^{4} |
|                  | 1.0                     | 0.0       | 0.01 | 3.15×1033.15superscript1033.15\times<br>10^{3} |
| n=−1.0𝑛1.0n=-1.0 | 1.0                     | 0.0       | 0.5  | 5.00×1045.00superscript1045.00\times<br>10^{4} |
|                  | 1.0                     | 0.0       | 0.1  | 1.38×1041.38superscript1041.38\times<br>10^{4} |
|                  | 1.0                     | 0.0       | 0.01 | 2.50×1032.50superscript1032.50\times<br>10^{3} |
|                  | 0.1                     | 0.0       | 0.5  | 5.00×1045.00superscript1045.00\times<br>10^{4} |
|                  | 0.1                     | 0.0       | 0.1  | 1.38×1041.38superscript1041.38\times           |

10^{4}

|                  | 0.1 | 0.0 | 0.01 | 2.50×1032.50superscript1032.50\times<br>10^{3} |
|------------------|-----|-----|------|------------------------------------------------|
| n=−0.5𝑛0.5n=-0.5 | 1.0 | 0.0 | 0.5  | 1.25×1051.25superscript1051.25\times<br>10^{5} |
|                  | 1.0 | 0.0 | 0.1  | 2.81×1042.81superscript1042.81\times<br>10^{4} |
|                  | 1.0 | 0.0 | 0.01 | 2.81×1032.81superscript1032.81\times<br>10^{3} |
| n=0.0𝑛0.0n=0.0   | 1.0 | 0.0 | 0.5  | 4.00×1054.00superscript1054.00\times<br>10^{5} |
|                  | 1.0 | 0.0 | 0.1  | 6.66×1046.66superscript1046.66\times<br>10^{4} |
|                  | 1.0 | 0.0 | 0.01 | 4.00×1034.00superscript1034.00\times<br>10^{3} |
|                  | 0.1 | 0.0 | 0.5  | 4.00×1054.00superscript1054.00\times<br>10^{5} |
|                  | 0.1 | 0.0 | 0.1  | 6.66×1046.66superscript1046.66\times<br>10^{4} |
|                  | 0.1 | 0.0 | 0.01 | 4.00×1034.00superscript1034.00\times<br>10^{3} |
|                  |     |     |      |                                                |

Table 1: Parameters in eq. 5 used to plot the fits in Figure 5.

# **References**

- (1) Bertschinger, E. 1985, ApJS, 58, 39. •
- (2) Cole, S.M., & Lacey, C., 1996, MNRAS, in press (astro-ph 9510147). •
- (3) Crone, M., Evrard, A.E., & Richstone, D.O. 1994, ApJ, 434, 402. •
- (4) Dubinski, J. & Carlberg, R. 1991, ApJ, 378, 496. •
- (5) Efstathiou, G.P., Davis, M., Frenk, C.S., & White, S.D.M. 1985, ApJS, 57, 241. •
- (6) Efstathiou, G.P., Frenk, C.S., White, S.D.M., & Davis, M. 1988, MNRAS, 235, 715. •
- (7) Fillmore, J.A., & Goldreich, P. 1984, ApJ, 281, 1. •
- (8) Frenk, C.S., White, S.D.M., Efstathiou, G.P., and Davis, M. 1985, Nature, 317, 595. •
- (9) Frenk, C.S., White, S.D.M., Davis, M., and Efstathiou, G.P. 1988, ApJ, 327, 507. •
- (10) Gunn, J., & Gott, J.R. 1972, ApJ, 176,1. •
- (11) Hernquist, L. 1990, ApJ, 356, 359. •
- (12) Hoffman, Y. 1988, ApJ, 328, 489. •
- (13) Hoffman, Y., & Shaham, J. 1985, ApJ, 297, 16. •
- (14) Lacey, C.G., & Cole, S.M. 1993, MNRAS, 262, 627. •
- (15) Lynden-Bell, D., 1967, MNRAS, 136, 101. •
- (16) Navarro, J.F., & White, S.D.M. 1993, MNRAS, 265, 271. •
- (17) Navarro, J.F., Frenk, C.S., & White, S.D.M. 1995, MNRAS, 275, 720. •
- (18) Navarro, J.F., Frenk, C.S., & White, S.D.M. 1996, ApJ, 462, 563. •
- (19) Quinn, P.J., Salmon, J.K., & Zurek, W.H. 1986, Nature, 322, 329. •
- (20) Syer, D., & White, S.D.M. 1996, MNRAS, submitted (astro-ph 9611065). •

- (21) Tormen, G., Bouchet, F., & White, S.D.M., 1996, MNRAS, submitted (astro-ph 9603132). •
- (22) Warren, M.S., Quinn, P.J., Salmon, J.K., & Zurek, W.H. 1992, ApJ, 399, 405. •
- (23) West, M.J., Dekel, A., & Oemler, A., 1987, ApJ, 316, 1. •
- (24) White, S.D.M. 1996, in Les Houches Session LX: Cosmology and Large-scale Structure, ed. Schaeffer, R. Silk, J., Spiro, M., Zinn-Justin, J., North Holland, p. 349. •
- (25) Zurek, W.H., Quinn, P.J., & Salmon, J.K. 1988, ApJ, 330, 519. •

#### Refer to caption

Figure 1: Particle plots illustrating the time evolution of halos of different mass in an Ω0=1subscriptΩ01\Omega\_{0}=1, n=−11n=-1 cosmology. Box sizes of each column are chosen so as to include approximately the same number of particles. At z0=0subscript00z\_{0}=0 the box size corresponds to about 6×r2006subscript2006\times r\_{200}. Time runs from top to bottom. Each snapshot is chosen so that M⋆subscript⋆M\_{\star} increases by a factor of 444 between each row. Low mass halos assemble earlier than their more massive counterparts. This is true for every cosmological scenario in our series.

### Refer to caption

Figure 2: Density profiles of one of the most and one of the least massive halos in each series. In each panel the low-mass system is represented by the leftmost curve. In the SCDM and CDMΛΛ\Lambda models radii are given in kpc (scale at the top) and densities are in units of 1010M⊙superscript1010subscriptdirectproduct10^{10}M\_{\odot}/kpc<sup>3</sup> . In all other panels units are arbitrary. The density parameter, Ω0subscriptΩ0\Omega\_{0}, and the value of the spectral index, nn is given in each panel. Solid lines are fits to the density profiles using eq. (1). The arrows indicate the value of the gravitational softening. The virial radius of each system is in all cases two orders of magnitude larger than the gravitational softening.

#### Refer to caption

Figure 3: The fits to the density profiles of Figure 2, scaled to the virial radius, r200subscript200r\_{200}, of each system and to the critical density of the universe at z=00z=0. Solid and dashed lines correspond to the low- and high-mass systems, respectively. Note that low-mass systems are denser than high-mass systems near the center, indicating that the characteristic density of a halo increases as the halo mass decreases.

#### Refer to caption

Figure 4: The circular velocity profiles of the halos shown in Figure 2. Radii are in units of the virial radius and circular speeds are normalized to the value at the virial radius. The thin solid line shows the data from the simulations. All curves have the same shape: they rise near the center until they reach a maximum and then decline at the outer edge. Low mass systems have higher

maximum circular velocities in these scaled units because of their higher central concentrations. Dashed lines are fits using eq.(3). The dotted lines are the fit to the low-mass halo in each panel using a Hernquist profile. Note that this model fits rather well the inner regions of the halos, but underestimates the circular velocity near the virial radius.

### Refer to caption

Figure 5: The correlation between the mass of a halo and its characteristic density. Masses are given in units of the nonlinear mass scale M⋆subscript⋆M\_{\star} (see text for a definition). Densities are relative to the critical value. Three curves are shown in each panel for different values of the parameter ff (see eq. 5). The fits are normalized to intersect at M200=M∗subscript200subscriptM\_{200}=M\_{\*} in the case Ω=1Ω1\Omega=1. This normalization is then used for the lowdensity models (Ω0<1subscriptΩ01\Omega\_{0}<1). Note that for f=0.010.01f=0.01 this procedure results in good fits to the results of the simulations in all cases.

### Refer to caption

Figure 6: As Figure 5, but for the concentration parameter cc.

#### Refer to caption

Figure 7: The mass dependence of the maximum circular velocity of a halo. Velocity units are arbitrary in the power-law panels and km s -1 in the CDM models (scale at top). Mass is in units of 1010M⊙superscript1010subscriptdirect-product10^{10} M\_{\odot} for CDM halos and in units of M⋆subscript⋆M\_{\star} in the other panels. Power law fits of the form M∝VmaxαproportionaltosuperscriptsubscriptM\propto V\_{max}^{\alpha} are shown. The value of α\alpha and the rms scatter in the mass about the fit are indicated in each panel. Note that the MM-VmaxsubscriptV\_{max} dependence steepens for larger values of the spectral index nn. The effect of the cosmological parameters on α\alpha seems to be rather small.

### Refer to caption

Figure 8: The characteristic density of all halos in our series as a function of the redshift at which half of the final mass is in collapsed progenitors more massive than 10%percent1010\% of the final mass. Solid circles correspond to all our runs with Ω0=1subscriptΩ01\Omega\_{0}=1, open circles to our runs with Ω0=0.1subscriptΩ00.1\Omega\_{0}=0.1 and Λ=0Λ0\Lambda=0, and starred symbols to the CDMΛΛ\Lambda runs (Ω0=0.25subscriptΩ00.25\Omega\_{0}=0.25, Λ=0.75Λ0.75\Lambda=0.75). The solid line shows the "natural" scaling, δc∝Ω0(1+z)3proportionaltosubscriptsubscriptΩ0superscript13\delta\_{c} \propto\Omega\_{0}(1+z)^{3} expected if the characteristic

density of a halo is directly proportional to the mean matter density of the universe at the time of collapse.

### Refer to caption

Figure 9: A summary of the mass dependence of δcsubscript\delta\_{c} and cc in our different cosmological models. Mass is given in units of the nonlinear mass scale M⋆subscript⋆M\_{\star}. Curves are labeled in the upper plots and the same line types are used in the bottom plots. The symbols in the lower-right panel show the correlation between cc and mass found by Cole & Lacey (1996), with open squares for n=−11n=-1, Ω0=1subscriptΩ01\Omega\_{0}=1 and solid squares for n=00n=0, Ω0=1subscriptΩ01\Omega\_{0}=1. These results should be compared to the lower dashed and lower dot-dashed curves in the same panel, respectively. Because of their poorer numerical resolution, Cole & Lacey's halos are significantly less concentrated than the ones in our study.

### Refer to caption

Figure 10: The δcsubscript\delta\_{c}-deviation from the fits shown in Figure 5 (for f=0.010.01f=0.01) plotted versus the deviation from the mean relation between the collapse redshift, 1+zcoll1subscript1+z\_{coll} (Figure 8), and the mass of a system. Note that systems assembled earlier (later) than the average tend to have characteristic densities above (below) the mean. The correlation between the δcsubscript\delta\_{c} and 1+zcoll1subscript1+z\_{coll} residuals follows the "natural" scaling,

Δlogδc=3Δlog(1+zcoll)Δsubscript3Δ1subscript\Delta\log\delta\_{c} =3\Delta\log(1+z\_{coll}), as shown by the solid line. Only the results corresponding to Ω0=1subscriptΩ01\Omega\_{0}=1 are shown.

### Refer to caption

Figure 11: The δcsubscript\delta\_{c}-residuals in Figure 5 relative to the solid curve fit (f=0.010.01f=0.01) plotted versus the residuals in the M200subscript200M\_{200}–λ\lambda correlation. This figure shows that the scatter in δcsubscript\delta\_{c} at a given mass cannot be attributed to the effects of rotation. All halos with Ω0=1subscriptΩ01\Omega\_{0}=1 are included in this plot.

#### Refer to caption

Figure 12: Circular velocity profiles of M⋆subscript⋆M\_{\star} halos formed in simulations with different power spectra in an Einstein-de Sitter universe. The curves were computed using eq. 3 and the values of the concentration cc obtained from the fits in Figure 9. Radii are in units of the virial radius and circular speeds in units of the circular velocity at the virial radius. Note that, because of the use of linear units, the fact that all curves have the same shape (eq. 3) is not immediately apparent.

### Refer to caption

Figure 13: A comparison between our density profiles and the power-law fits of Crone et al. (1994). The region fitted by these authors, corresponding to densities between 100100100 and 300030003000, is shown by the dotted lines. Over this region our results (solid lines) and the power-law parameterization adopted by Crone et al. (dashed lines) are consistent. The profiles shown by the solid curves correspond to M=6M∗6subscriptM=6M\_{\*} (n=−1.51.5n=-1.5), M=4M∗4subscriptM=4M\_{\*} (n=−11n=-1), M=2M∗2subscriptM=2M\_{\*} (n=−0.50.5n=-0.5), and M=M∗subscriptM=M\_{\*} (n=00n=0), as discussed in the text.

[◄](javascript:%20void(0)) [Feeling](file:///feeling_lucky) [lucky?](file:///feeling_lucky) [Conversion](file:///log/astro-ph/9611107) [report](file:///log/astro-ph/9611107) [Report](https://github.com/dginev/ar5iv/issues/new?template=improve-article--arxiv-id-.md&title=Improve+article+astro-ph/9611107) [an issue](https://github.com/dginev/ar5iv/issues/new?template=improve-article--arxiv-id-.md&title=Improve+article+astro-ph/9611107) [View original](https://arxiv.org/abs/astro-ph/9611107) [on arXiv](https://arxiv.org/abs/astro-ph/9611107)[►](javascript:%20void(0)) [Copyright](https://arxiv.org/help/license) [Privacy Policy](https://arxiv.org/help/policies/privacy_policy) [ar5iv homepage](file:///)

Generated on Thu Feb 29 10:49:11 2024 by L [T](http://dlmf.nist.gov/LaTeXML/) [a](http://dlmf.nist.gov/LaTeXML/) [e](http://dlmf.nist.gov/LaTeXML/)[XML](http://dlmf.nist.gov/LaTeXML/)