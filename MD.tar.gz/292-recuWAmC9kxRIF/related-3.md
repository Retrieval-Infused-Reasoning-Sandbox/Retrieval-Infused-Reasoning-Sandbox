### [DLMF](file:///map-vepfs/shuang/EDR/PDF/292-recuWAmC9kxRIF/)

- [Index](file:///map-vepfs/shuang/EDR/PDF/292-recuWAmC9kxRIF/idx/) •
- [Notations](file:///map-vepfs/shuang/EDR/PDF/292-recuWAmC9kxRIF/not/) •
- •

### Search

- [Help?](file:///map-vepfs/shuang/EDR/PDF/292-recuWAmC9kxRIF/help/) •
- [Citing](file:///map-vepfs/shuang/EDR/PDF/292-recuWAmC9kxRIF/help/cite) •
- [Customize](file:///map-vepfs/shuang/EDR/PDF/292-recuWAmC9kxRIF/help/customize) •
- Annotate •
- UnAnnotate •

### [About the Project](file:///map-vepfs/shuang/EDR/PDF/292-recuWAmC9kxRIF/about/)

[4 Elementary Functions](file:///map-vepfs/shuang/EDR/PDF/292-recuWAmC9kxRIF/4)[Logarithm, Exponential, Powers](file:///map-vepfs/shuang/EDR/PDF/292-recuWAmC9kxRIF/4#PT2)[4.5 Inequalities](file:///map-vepfs/shuang/EDR/PDF/292-recuWAmC9kxRIF/4.5)[4.7](file:///map-vepfs/shuang/EDR/PDF/292-recuWAmC9kxRIF/4.7) [Derivatives and Differential Equations](file:///map-vepfs/shuang/EDR/PDF/292-recuWAmC9kxRIF/4.7)

# **§4.6 Power Series**

ⓘ

Permalink:

[http://dlmf.nist.gov/4.6](file:///map-vepfs/shuang/EDR/PDF/292-recuWAmC9kxRIF/4.6)

See also:

Annotations for [Ch.4](file:///map-vepfs/shuang/EDR/PDF/292-recuWAmC9kxRIF/4#info)

### **Contents**

- [§4.6\(i\) Logarithms](#page-0-0) 1.
- [§4.6\(ii\) Powers](#page-2-0) 2.

## <span id="page-0-0"></span>**§4.6(i) Logarithms**

![](_page_0_Picture_22.jpeg)

Keywords:

[logarithm function,](file:///map-vepfs/shuang/EDR/PDF/292-recuWAmC9kxRIF/search/search?q=logarithm%20function) [power series](file:///map-vepfs/shuang/EDR/PDF/292-recuWAmC9kxRIF/search/search?q=power%20series)

Notes:

See Hardy ([1952,](file:///map-vepfs/shuang/EDR/PDF/292-recuWAmC9kxRIF/bib/H#bib1043) pp. 471–473) for [\(4.6.1\)](file:///map-vepfs/shuang/EDR/PDF/292-recuWAmC9kxRIF/4.6#E1). The other equations are variations of this.

Permalink:

[http://dlmf.nist.gov/4.6.i](file:///map-vepfs/shuang/EDR/PDF/292-recuWAmC9kxRIF/4.6.i)

See also:

Annotations for [§4.6](file:///map-vepfs/shuang/EDR/PDF/292-recuWAmC9kxRIF/4.6#info) and [Ch.4](file:///map-vepfs/shuang/EDR/PDF/292-recuWAmC9kxRIF/4#info)

4.6.1 
$$ln(1+z)=z-12z2+13z3-\cdots$$
,  $|z| \le 1$ ,  $z \ne -1$ ,  $\bigcirc$ 

Symbols:

```
lnz: principal branch of logarithm function and z: complex variable
A&S Ref:
    4.1.24
Referenced by:
    §4.45(i), §4.6(i), (8.15.2)
Permalink:
    http://dlmf.nist.gov/4.6.E1
Encodings:
    TeX, pMML, png
See also:
    Annotations for §4.6(i), §4.6 and Ch.4
4.6.2 lnz=(z−1z)+12(z−1z)2+13(z−1z)3+⋯,
ℜz≥12,
ⓘ
Symbols:
    lnz: principal branch of logarithm function, ℜ: real part and z: complex
    variable
A&S Ref:
    4.1.25
Permalink:
    http://dlmf.nist.gov/4.6.E2
Encodings:
    TeX, pMML, png
See also:
    Annotations for §4.6(i), §4.6 and Ch.4
4.6.3 lnz=(z−1)−12(z−1)2+13(z−1)3−⋯,
|z−1|≤1, z≠0,
ⓘ
Symbols:
    lnz: principal branch of logarithm function and z: complex variable
A&S Ref:
    4.1.26
Permalink:
    http://dlmf.nist.gov/4.6.E3
Encodings:
    TeX, pMML, png
See also:
    Annotations for §4.6(i), §4.6 and Ch.4
4.6.4 lnz=2((z−1z+1)+13(z−1z+1)3+15(z−1z+1)5+⋯),
ℜz≥0, z≠0,
ⓘ
Symbols:
    lnz: principal branch of logarithm function, ℜ: real part and z: complex
    variable
```

```
A&S Ref:
     4.1.27
Permalink:
     http://dlmf.nist.gov/4.6.E4
Encodings:
     TeX, pMML, png
See also:
     Annotations for §4.6(i), §4.6 and Ch.4
4.6.5 ln(z+1z−1)=2(1z+13z3+15z5+⋯),
|z|≥1, z≠±1,
ⓘ
Symbols:
     lnz: principal branch of logarithm function and z: complex variable
A&S Ref:
     4.1.28
Permalink:
     http://dlmf.nist.gov/4.6.E5
Encodings:
     TeX, pMML, png
See also:
     Annotations for §4.6(i), §4.6 and Ch.4
4.6.6 ln(z+a)=lna+2((z2a+z)+13(z2a+z)3+15(z2a+z)5+⋯),
a>0, ℜz≥−a, z≠−a.
ⓘ
Symbols:
     lnz: principal branch of logarithm function, ℜ: real part, a: real or
     complex constant and z: complex variable
A&S Ref:
     4.1.29
Permalink:
     http://dlmf.nist.gov/4.6.E6
Encodings:
     TeX, pMML, png
See also:
     Annotations for §4.6(i), §4.6 and Ch.4
§4.6(ii) Powers
ⓘ
Notes:
    See Hardy (1952, pp. 476–477).
Referenced by:
    Erratum (V1.0.11) for Clarifications
Permalink:
```

```
http://dlmf.nist.gov/4.6.ii
```

Addition (effective with 1.0.11):

A sentence was added after ([4.6.7](file:///map-vepfs/shuang/EDR/PDF/292-recuWAmC9kxRIF/4.6#E7)) to explain that it is a generalization of [\(1.2.2\)](file:///map-vepfs/shuang/EDR/PDF/292-recuWAmC9kxRIF/1.2#E2) using [\(1.2.6\)](file:///map-vepfs/shuang/EDR/PDF/292-recuWAmC9kxRIF/1.2#E6)

See also:

Annotations for [§4.6](file:///map-vepfs/shuang/EDR/PDF/292-recuWAmC9kxRIF/4.6#info) and [Ch.4](file:///map-vepfs/shuang/EDR/PDF/292-recuWAmC9kxRIF/4#info)

## **Binomial Expansion**

ⓘ

Keywords:

[binomial expansion](file:///map-vepfs/shuang/EDR/PDF/292-recuWAmC9kxRIF/search/search?q=binomial%20expansion)

See also:

Annotations for [§4.6\(ii\),](file:///map-vepfs/shuang/EDR/PDF/292-recuWAmC9kxRIF/4.6#ii.info) [§4.6](file:///map-vepfs/shuang/EDR/PDF/292-recuWAmC9kxRIF/4.6#info) and [Ch.4](file:///map-vepfs/shuang/EDR/PDF/292-recuWAmC9kxRIF/4#info)

4.6.7 
$$(1+z)a=1+a1!z+a(a-1)2!z2+a(a-1)(a-2)3!z3+\cdots$$
,

ⓘ

Symbols:

[!: factorial \(as in n!\)](file:///map-vepfs/shuang/EDR/PDF/292-recuWAmC9kxRIF/front/introduction#common.t1.r15), [a: real or complex constant](file:///map-vepfs/shuang/EDR/PDF/292-recuWAmC9kxRIF/4.1#t1.r2) and [z: complex](file:///map-vepfs/shuang/EDR/PDF/292-recuWAmC9kxRIF/4.1#t1.r4) [variable](file:///map-vepfs/shuang/EDR/PDF/292-recuWAmC9kxRIF/4.1#t1.r4)

Referenced by:

[§4.6\(ii\),](file:///map-vepfs/shuang/EDR/PDF/292-recuWAmC9kxRIF/4.6#Px1.p1) [§4.6\(ii\)](file:///map-vepfs/shuang/EDR/PDF/292-recuWAmC9kxRIF/4.6#ii.info)

Permalink:

[http://dlmf.nist.gov/4.6.E7](file:///map-vepfs/shuang/EDR/PDF/292-recuWAmC9kxRIF/4.6.E7)

Encodings:

[TeX](file:///map-vepfs/shuang/EDR/PDF/292-recuWAmC9kxRIF/4.6.E7.tex), [pMML](file:///map-vepfs/shuang/EDR/PDF/292-recuWAmC9kxRIF/4.6.E7.pmml), [png](file:///map-vepfs/shuang/EDR/PDF/292-recuWAmC9kxRIF/4.6.E7.png)

See also:

Annotations for [§4.6\(ii\),](file:///map-vepfs/shuang/EDR/PDF/292-recuWAmC9kxRIF/4.6#Px1.info) [§4.6\(ii\),](file:///map-vepfs/shuang/EDR/PDF/292-recuWAmC9kxRIF/4.6#ii.info) [§4.6](file:///map-vepfs/shuang/EDR/PDF/292-recuWAmC9kxRIF/4.6#info) and [Ch.4](file:///map-vepfs/shuang/EDR/PDF/292-recuWAmC9kxRIF/4#info)

valid when a is any real or complex constant and |z|<1. If a=0,1,2,…, then the series terminates and z is unrestricted. Note that [\(4.6.7](file:///map-vepfs/shuang/EDR/PDF/292-recuWAmC9kxRIF/4.6#E7)) is a generalization of the binomial expansion ([1.2.2](file:///map-vepfs/shuang/EDR/PDF/292-recuWAmC9kxRIF/1.2#E2)) with the binomial coefficients defined in ([1.2.6](file:///map-vepfs/shuang/EDR/PDF/292-recuWAmC9kxRIF/1.2#E6)).

[4.5 Inequalities](file:///map-vepfs/shuang/EDR/PDF/292-recuWAmC9kxRIF/4.5)[4.7 Derivatives and Differential Equations](file:///map-vepfs/shuang/EDR/PDF/292-recuWAmC9kxRIF/4.7) [© 2010–2025 NIST](file:///map-vepfs/shuang/EDR/PDF/292-recuWAmC9kxRIF/about/notices) / [Disclaimer](file:///map-vepfs/shuang/EDR/PDF/292-recuWAmC9kxRIF/about/notices#S2) / [Feedback](file:///cdn-cgi/l/email-protection#37737b7a711a515252535556545c77595e444319505841); Version 1.2.4; Release date 2025-03-15.

[NIST](http://www.nist.gov/)

[Site Privacy](https://www.nist.gov/privacy-policy) [Accessibility](https://www.nist.gov/oism/accessibility) [Privacy Program](https://www.nist.gov/privacy) [Copyrights](https://www.nist.gov/oism/copyrights) [Vulnerability Disclosure](https://www.commerce.gov/vulnerability-disclosure-policy) [No Fear Act Policy](https://www.nist.gov/no-fear-act-policy) [FOIA](https://www.nist.gov/foia) [Environmental Policy](https://www.nist.gov/environmental-policy-statement) [Scientific Integrity](https://www.nist.gov/summary-report-scientific-integrity) [Information](https://www.nist.gov/nist-information-quality-standards) [Quality Standards](https://www.nist.gov/nist-information-quality-standards) [Commerce.gov](https://www.commerce.gov/) [Science.gov](http://www.science.gov/) [USA.gov](http://www.usa.gov/)