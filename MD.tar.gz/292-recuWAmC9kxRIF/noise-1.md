## Luminosity of accretion disks in compact objects with quadrupole

Kuantay Boshkayev, $^{1,2,*}$  Talgar Konysbayev, $^{1,2,\dagger}$  Ergali Kurmanov, $^{1,2,\ddagger}$  Orlando Luongo, $^{1,2,3,4,\$}$  Daniele Malafarina, $^{5,\P}$  and Hernando Quevedo $^{2,6,7,**}$ 

<sup>1</sup>National Nanotechnology Laboratory of Open Type, Almaty 050040, Kazakhstan.

<sup>2</sup>Al-Farabi Kazakh National University, Al-Farabi av. 71, 050040 Almaty, Kazakhstan.

<sup>3</sup>Dipartimento di Matematica, Università di Pisa, Largo B. Pontecorvo 5, Pisa, 56127, Italy.

<sup>4</sup>Divisione di Fisica, Università di Camerino, Via Madonna delle Carceri, 9, 62032, Italy.

<sup>5</sup>Department of Physics, Nazarbayev University, Kabanbay Batyr 53, 010000 Nur-Sultan, Kazakhstan.

<sup>6</sup>Instituto de Ciencias Nucleares, Universidad Nacional Autònoma de Mèxico, Mexico.

<sup>7</sup>Dipartimento di Fisica and ICRA, Università di Roma "La Sapienza", Roma, Italy.

(Dated: June 10, 2021)

We consider the circular motion of test particles in the gravitational field of a static and axially-symmetric compact object described by the q-metric. To this end, we calculate orbital parameters of test particles on accretion disks such as angular velocity  $(\Omega)$ , total energy (E), angular momentum (L), and radius of the innermost stable circular orbit  $(r_{ISCO})$  as functions of the mass (m) and quadrupole (q) parameters of the source. The radiative flux, differential, and spectral luminosity of the accretion disk, which are quantities that can be experimentally measured, are then explored in detail. The obtained results are compared with the corresponding ones for the Schwarzschild and Kerr black holes in order to establish whether black holes may be distinguished from the q-metric via observations of the accretion disk's spectrum.

PACS numbers:

Keywords: accretion disk, differential and spectral luminosity, q-metric

#### I. INTRODUCTION

The spectra of accretion disks surrounding massive compact objects are routinely observed in astrophysics. Such observations provide invaluable information about the nature of the accreting central object and for extremely condensed sources one must necessarily use general relativity to describe both the source as well as the accreting matter. The accretion disk luminosity of compact objects can be modeled for many solutions to Einstein's field equations. In particular, these solutions may describe the gravitational field of neutral black holes [1] or they may describe the field outside of massive compact objects, some realistic like white dwarfs and neutron stars, and others more exotic, such as for example boson stars [2, 3] or gravastars [4].

As of now, we can not rule out the possible existence of exotic compact objects in the universe as most observations of black hole candidates are still not able to probe the geometry in the vicinity of such astrophysical sources. Such observations include gravitational waves emitted from the inspiral of binary black holes [5, 6], the motion of stars near the galactic center [7–9], the shadow of the supermassive black hole candidate at the core of the galaxy M87 [10], spectra from x-ray binary systems

[11], and light spectra from accretion disks surrounding

Generally speaking, relativistic compact objects are modeled by assuming a space-time metric fulfilling given conditions of symmetry for the exterior and solving the equations for hydrodynamic equilibrium for the matter content in the interior. Often "exotic" matter can be used to describe hypothetical objects that are massive, compact, and stable. This speculation has proven helpful to provide either black hole alternatives or dark matter candidates, also leading to the suggestion that such massive objects may be dark matter condensates [15, 16]<sup>1</sup>.

Nevertheless, we know that general relativity is an incomplete theory and therefore the classical description of the geometry and/or the matter models may fail when the field becomes sufficiently strong [18–21]. The limits of the theory are signalled by the appearance of singularities. For example, vacuum, static, and axially symmetric solutions (known as Weyl's class [22, 23]) generically exhibit curvature singularities at the infinitely redshifted surface which corresponds to the horizon in the black hole case [24, 25]. Such solutions may be considered as

supermassive black hole candidates at the core of galaxies [12, 13]. The last two sets of observations are the most abundant ones and both rely on the measurement of the accretion disk's spectra. As it is well known, some features of the accretion disk depend on the space-time geometry and therefore can in principle be used to obtain constraints on the geometry from observations [14].

<span id="page-0-0"></span><sup>\*</sup>kuantay@mail.ru

<span id="page-0-1"></span><sup>†</sup>talgar\_777@mail.ru

<span id="page-0-2"></span><sup>‡</sup>kurmanov.yergali@kaznu.kz

<span id="page-0-3"></span><sup>§</sup>orlando.luongo@unicam.it

<span id="page-0-4"></span><sup>¶</sup>daniele.malafarina@nu.edu.kz

<span id="page-0-5"></span><sup>\*\*</sup>quevedo@nucleares.unam.mx

<sup>&</sup>lt;sup>1</sup> For a different perspective on the nature of dark matter and dark energy see e.g. [17].

describing the exterior field of static and axially symmetric exotic compact objects whose boundary is located at a distance outside the singularity.

In this paper, we consider one of such solutions describing a static deformed compact object, the so-called q-metric [26, 27]. In the literature, the metric is also known as the Zipoy-Voorhees metric,  $\delta$ -metric and  $\gamma$ -metric. Despite the different nomenclature, it is practically the same metric, which here we prefer to denote with q-metric to stress the importance of the quadrupole parameter q [28].

The line element of the q-metric is particularly suitable to study the exterior field of exotic compact objects and its relation to the Schwarzschild space-time because it involves only two parameters of clear physical interpretation: m which is related to the mass of the source and q which relates to the quadrupole and hence describes the departure of the object from spherical symmetry [29].

It is worth noticing that relativistic matter sources for metrics of Weyl's class do exist [30, 31]. In particular some early attempts to develop interiors for the q-metric were made in [32, 33], and, more recently, a complete solution has been proposed in [34] and an approximate solution in [35], which satisfy all the conditions to be considered physically meaningful. Furthermore, several studies of the physical features of the q-metric can be found in the literature, e.g. shadows around the q-metric [36–38], geodesics [28, 39, 40], quasinormal modes [41, 42], motion of charged particles [43] and spinning particles [44], neutrino oscillations [45], particle's collisions [46], etc.

However, in order to study how the features of the qmetric deviate from those of a black hole geometry, it is important to consider quantities that can be measured via observations. Assuming that the compact source is surrounded by an accretion disk, the direct measurement of the innermost stable circular orbit (ISCO) of the disc is practically impossible. On the other hand, the accretion spectrum of the disk, which does depend on the ISCO, is a quantity that can be observed with modern telescopes. Hence, we here investigate the luminosity of thin accretion disks in the space-time described by the q-metric employing the widely-consolidated model proposed by Novikov and Thorne, Page and Thorne [47, 48]. In so doing, we first calculate the orbital parameters of test particles and then numerically construct the simulated radiative flux, spectral and differential luminosities of the disk as functions of the radial distance from the source and the frequency of the emitted radiation. In order to establish whether observations of accretion disk spectra would be able to constraint the value of the mass quadrupole, we then compare the results obtained for the q-metric with the ones for the Kerr metric. It is worth noticing that models of accretion disks' spectra are commonly used to investigate the observational properties of hypothetical compact objects (see for example [15, 49, 50]).

The paper is organized as follows. In Sect. II, we describe the main features of the q-metric and briefly re-

view the formalism for the motion of test particles on accretion disks, while in Sect. III the same discussion is briefly reviewed for the Kerr space-time. In Sect. IV, we review the thin accretion disks formalism using the Novikov-Thorne and Page-Thorne models and in Sect. IV A we apply it to the q-metric and compare the results with the corresponding ones for the Kerr space-time. Finally, in Sect. V we present the conclusions and perspectives of our work. Throughout the paper we make use of geometrized units setting G = c = 1.

#### <span id="page-1-0"></span>II. PARTICLE MOTION IN THE Q-METRIC

It is well-known that the most general axisymmetric and static solution of the vacuum field equations is represented by the Weyl line element [51] which describes an infinite number of solutions. Among them the so-called q-metric is considered to be the simplest generalization of the Schwarzschild metric containing a quadrupole parameter [52, 53]. Other solutions that generalize the Schwarzschild metric to include a quadrupole moment have also been proposed [54–56]. Here we focus on the q-metric which is given by the line element

$$ds^{2} = \left(1 - \frac{2m}{r}\right)^{1+q} dt^{2} - \left(1 - \frac{2m}{r}\right)^{-q} \times \left[\left(1 + \frac{m^{2}\sin^{2}\theta}{r^{2} - 2mr}\right)^{-q(2+q)} \left(\frac{dr^{2}}{1 - \frac{2m}{r}} + r^{2}d\theta^{2}\right) + r^{2}\sin^{2}\theta d\phi^{2}\right], \tag{1}$$

where m and q are the mass and dimensionless quadrupole parameters respectively and the allowed values for q are 1+q>0. It is easy to notice that for vanishing q one recovers the Schwarzschild metric while values of q>0 (q<0) describe the exterior field of an oblate (prolate) source. Also it is well known that the q-metric exhibits a curvature singularity at r=2m for all values of  $q\neq 0$  implying that the matter source must have a boundary  $r_b>2m$ .

Furthermore the total gravitational mass of the source, as measured by faraway observers, can be easily obtained, for example from the evaluation of Komar's integral, and it is given by  $M_T = m(1+q)$ . It is therefore interesting to model the exterior field of compact objects with this metric and to check the effects that the quadrupole parameter q has on the observable features such as accretion disks. To do so, we need to first compute circular geodesics and the innermost stable circular orbit (ISCO).

### A. Circular orbits in the q-metric

We limit our attention to the equatorial plane, where  $\theta = \pi/2$  and consider particles on circular orbits. The

main orbital quantities for particles on a circular orbit at a radius r are then given by

<span id="page-2-1"></span>
$$\Omega^2 = \left(1 - \frac{2m}{r}\right)^{1+2q} \frac{(1+q)m}{r^2(r-(2+q)m)},\tag{2}$$

$$E^{2} = \left(1 - \frac{2m}{r}\right)^{1+q} \frac{r - (2+q)m}{r - (3+2q)m},\tag{3}$$

$$L^{2} = \left(1 - \frac{2m}{r}\right)^{-q} \frac{(1+q)mr^{2}}{r - (3+2q)m},\tag{4}$$

where  $\Omega = \Omega(r)$  is the orbital angular velocity, E = E(r) is the energy per unit mass and L = L(r) is the orbital angular momentum per unit mass of the test particle. As stressed above, these quantities reduce to the corresponding values for the Schwarzschild metric as  $q \to 0$ . The orbital parameters for particles in the q-metric have been studied by several authors (see for example [39, 57]).

The ISCO is the closest stable circular orbit that massive test particles can have around a compact object. In astrophysics it usually determines the inner edge of the accretion disk and its value depends on the parameters characterizing the source, namely the mass, angular momentum and higher mass multipoles. Its role in investigating astrophysical compact objects turns out to be essential since, by observing accretion disks, one can obtain an estimate of the ISCO and consequently constrain the values of the corresponding parameters for the source. For example, for a Kerr black hole, if an independent measure of the mass is available, then a measurement of the ISCO allows to estimate the value of the angular momentum (in practice things are more complicated, see for example [58]). Similarly for the q-metric, in principle, knowing the active gravitational mass of the source, by measuring the ISCO one could obtain an estimate of the mass quadrupole moment. It is important to notice that different geometries may mimic each other. For example, a static solution such as the q-metric with a given value of q may produce the same ISCO as the Kerr metric for a given value of the angular momentum thus requiring more than one measurement in order to be able to distinguish the two geometries.

The radius of the innermost stable circular orbit  $r_{ISCO}$  is defined via the condition dL/dr = 0 [28]. So, for the q-metric, taking Eq. (4), we get the quadratic equation

<span id="page-2-2"></span>
$$r^{2} - 2m(4+3q)r + 2m^{2}(6+7q+2q^{2}) = 0,$$
 (5)

and thus two solutions for the ISCO given by

$$r_{ISCO}^{\pm} = m \left( 4 + 3q \pm \sqrt{5q^2 + 10q + 4} \right),$$
 (6)

where  $\pm$  signs indicate the inner and outer radii, respectively. The solution  $r_{ISCO}^+$  is the physical one corresponding to the edge of the accretion disk and it is the solution that we will consider hereafter. This solution exists for  $q \geq 1/\sqrt{5}-1$ . The inner solution  $r_{ISCO}^-$  is

not physical since for most values of q it is situated either below the singularity, i.e.  $r_{ISCO}^{-} < 2m$  or below the photon capture radius, i.e.  $r_{ISCO}^{-} < m(3+2q)$ . It is nevertheless worth noticing that there exists a range of values of  $q \in [1/\sqrt{5}-1,-1/2]$  for which the inner ISCO may be considered physical. In this case there exist two separate regions outside the singularity where stable circular orbits are allowed, one for  $r > r_{ISCO}^{+}$  and one for  $r < r_{ISCO}^{-}$ . For  $q = 1/\sqrt{5}-1$  the two solutions for the ISCO radius coincide  $r_{ISCO}^{+} = r_{ISCO}^{-}$  while for  $q < 1/\sqrt{5}-1$  equation (5) has no real solutions and stable circular orbits exist all the way from spatial infinity to the singularity (see [59]).

Notice that in order to compare the ISCO with that of the Kerr space-time we must consider the two geometries with the source of the same active gravitational mass. The total mass of the q-metric may be evaluated via Komar's integral and it is given by  $M_T = m(1+q)$  and therefore the ISCO radius as a function of q in units of total mass  $M_T$  is given by

$$\frac{r_{ISCO}}{M_T} = 3 + \frac{1}{1+q} + \sqrt{5 - \frac{1}{(1+q)^2}},\tag{7}$$

and it is shown in the left panel of Fig. 1. The right panel of Fig. 1 shows the degeneracy between the ISCO radius in the q-metric as a function of q and that of the Kerr metric as a function of the dimensionless angular momentum j.

# <span id="page-2-0"></span>III. PARTICLE MOTION IN THE KERR METRIC

The Kerr space-time [60] is a vacuum geometry describing a rotating uncharged axially-symmetric black hole. The line element for the Kerr metric in Boyer-Lindquist coordinates is

$$ds^{2} = \left(1 - \frac{2Mr}{\Sigma}\right)dt^{2} - \frac{\Sigma}{\Delta}dr^{2} + \frac{4Mra}{\Sigma}\sin^{2}\theta d\phi dt$$
$$- \Sigma d\theta^{2} - \left(r^{2} + a^{2} + \frac{2Mra^{2}}{\Sigma}\sin^{2}\theta\right)d\phi^{2}, \quad (8)$$

where we have set  $\Sigma = r^2 + a^2 \cos^2 \theta$  and  $\Delta = r^2 - 2Mr + a^2$ . The total gravitational mass of the source is given by  $M_T = M$  and its dimensionless angular momentum is j = a/M. Therefore, also the Kerr metric is fully characterized by two parameters only and Schwarzschild is obtained for vanishing angular momentum, i.e. a = 0.

The Kerr space-time is the paradigm for describing the exterior of astrophysical black hole candidates, however as of now no precise measurement of the actual geometry of such objects is available. For this reason it is important to keep an open mind and allow for the possibility that such objects may be described by more exotic solutions such as the q-metric. Therefore it is worth considering

![](_page_3_Figure_1.jpeg)

<span id="page-3-1"></span>FIG. 1: Left panel: The ISCO radii for the q-metric in units of total mass  $M_T$  as a function of the quadrupole parameter q as compared to the ISCO for the Kerr space-time as a function of the dimensionless angular momentum j. Right panel: Degeneracy for the value of the ISCO between the q-metric and the Kerr space-time. Namely for each allowed value of q there is a corresponding value of q for which the two sources with the same active mass q-produce the same ISCO.

what kinds of observations may allow to distinguish the two sources. As mentioned earlier, most of the existing black hole candidates are observed through the spectra of their accretion disks and therefore in the following we shall review circular orbits and ISCO for the Kerr solution with the aim of comparing the results with the corresponding ones in the q-metric.

#### A. Circular orbits in the Kerr metric

The specific angular velocity, angular momentum and energy of the particle moving on a circular orbit around a Kerr black hole are derived, respectively as

$$\Omega^2 = \frac{M}{r^3 \pm 2ar^2\sqrt{M/r} + a^2M},\tag{9}$$

$$E^{2} = \frac{\left(\sqrt{r}\left(r - 2M\right) \pm a\sqrt{M}\right)^{2}}{r^{2}\left(r \pm 2a\sqrt{M/r} - 3M\right)},\tag{10}$$

$$L^{2} = \frac{M\left(r^{2} \mp 2a\sqrt{M/r} + a^{2}\right)^{2}}{r^{2}\left(r \pm 2a\sqrt{M/r} - 3M\right)},$$
 (11)

where the + and - signs correspond to co-rotating and counter-rotating particles with respect to the direction of rotation of the black hole.

Analogously to the q-metric, we write the radius of the ISCO for the Kerr metric as [61]

$$\frac{r_{ISCO}^{\pm}}{M_T} = \left(3 + Z_2 \mp \sqrt{(3 - Z_1)(3 + Z_1 + 2Z_2)}\right), \quad (12)$$

where we have defined

$$Z_1 \equiv 1 + (1 - j^2)^{\frac{1}{3}} \left( (1 + j)^{\frac{1}{3}} + (1 - j)^{\frac{1}{3}} \right),$$
 (13a)

$$Z_2 \equiv \left(3j^2 + Z_1^2\right)^{\frac{1}{2}}.\tag{13b}$$

Having obtained circular orbits and the ISCO in both space-times (see Fig. 1 for details) we are now able to consider the true observables that may be obtained from astrophysical black hole candidates, namely the spectra of light emitted from the accretion disks.

## <span id="page-3-0"></span>IV. SPECTRA OF THIN ACCRETION DISKS

In order to study the luminosity and spectrum of the accretion disk in the q-metric we follow the model proposed by Novikov-Thorne and Page-Thorne in [47, 48].

Accordingly, the radiative flux  $\mathcal{F}$  (i.e. the energy radiated per unit area per unit time) emitted by the accretion disk is given by

$$\mathcal{F}(r) = -\frac{\dot{\mathbf{m}}}{4\pi\sqrt{g}} \frac{\Omega_{,r}}{\left(E - \Omega L\right)^2} \int_{r_{ISCO}}^{r} \left(E - \Omega L\right) L_{,\tilde{r}} d\tilde{r},\tag{14}$$

where  $\dot{\mathbf{m}}$  is the mass accretion rate of the disk, which is assumed to be constant and g is the determinant of the metric tensor of the three-dimensional sub-space  $(t, r, \varphi)$ , i.e.  $\sqrt{g} = \sqrt{g_{tt}g_{rr}g_{\varphi\varphi}}$ .

Furthermore, it must be noticed that  $\mathcal{F}$  is not directly observable since it is a local quantity that is measured in the rest frame of the disk. Therefore a more interesting quantity from the observational perspective is the differential luminosity (i.e. the energy per unit time that reaches an observer at infinity)  $\mathcal{L}_{\infty}$  which can be esti-

![](_page_4_Figure_1.jpeg)

<span id="page-4-2"></span>FIG. 2: Color online. Left panel: Angular velocity of test particles versus radial distance r normalized in units of total mass  $M_T$  in the oblate q-metric. Right panel: Angular velocity of test particles versus radial distance r normalized in units of total mass  $M_T$  in the Kerr space-time.

mated from the flux  $\mathcal{F}$  via the following relation [47, 48]

<span id="page-4-1"></span>
$$\frac{d\mathcal{L}_{\infty}}{d\ln r} = 4\pi r \sqrt{g} E \mathcal{F}(r). \tag{15}$$

Both of these quantities describe the amount of radiation emitted by the disk at a given radius r. However, what is measured in practice is the spectrum of the light emitted as a function of the frequency. Therefore, another characteristic quantity of the accretion disk that is worth considering is the spectral luminosity distribution observed at infinity  $\mathcal{L}_{\nu,\infty}$ . Under the assumption of black body emission from the accretion disk  $\mathcal{L}_{\nu,\infty}$  is given by [15]

<span id="page-4-3"></span>
$$\nu \mathcal{L}_{\nu,\infty} = \frac{60}{\pi^3} \int_{r_{ISCO}}^{\infty} \frac{\sqrt{g}E}{M_T^2} \frac{(u^t y)^4}{\exp\left[u^t y/\mathcal{F}^{*1/4}\right] - 1} dr, \quad (16)$$

where  $u^t$  is the co-variant time component of the four velocity, defined by

$$u^{t}(r) = \frac{1}{\sqrt{g_{tt} + 2\Omega g_{t\varphi} + \Omega^{2} g_{\varphi\varphi}}},$$
 (17)

and  $y = h\nu/kT_*$ , h is the Planck constant,  $\nu$  is the frequency of the emitted radiation, k is the Boltzmann constant,  $T_*$  is the characteristic temperature as defined from Stefan-Boltzmann law as  $\sigma T_* = \dot{m}/4\pi M_T^2$ , with  $\sigma$  being Stefan-Boltzmann constant. Notice that to keep the argument of the exponential dimensionless we have normalized the flux with respect to total mass  $M_T$  and defined  $\mathcal{F}^*(r) = M_T^2 \mathcal{F}(r)$ .

Finally, another quantity of interest related to the radiation emitted by the accretion disk is the net luminosity that reaches observers at infinity  $\mathcal{L}_{\infty}$ , which is given by the integral of equation (15). This quantity represents the amount of rest mass energy of the accreting matter that is converted into radiation and can also be expressed as  $\mathcal{L}_{\infty} = (1 - E_{ISCO})\dot{m}$ , or, in other words, the efficiency of the source in converting infalling mass into emitted

radiation. For Schwarzschild, taking unit mass accretion rate it is known that  $(1-E_{ISCO})=0.0572$ , meaning that an accretion disk around a Schwarzschild black hole converts matter into radiation with an efficiency of 5.72%,

#### <span id="page-4-0"></span>A. Numerical results

In the limit of negligible rotation, the space-time in the exterior of a compact object may be approximated as static. At the same time the deformation effects on the source would introduce some oblateness. Therefore, in the following we have considered only oblate sources (i.e. q > 0) as they are more physically relevant in describing the shape of a rotating object. Also, it must be mentioned that, in order to carry out the numerical analysis, it is useful to introduce dimensionless quantities defined as  $\Omega^*(r) = M_T \Omega(r)$ ,  $L^*(r) = L(r)/M_T$  and  $E^*(r) = E(r)$ .

In Fig. 2 (left panel) we show the orbital angular velocity  $\Omega^*(r)$  of test particles as a function of the normalized radial coordinate  $r/M_T$  in the q-metric. It can be seen that the inclusion of the quadrupole moment for oblate sources noticeably decreases  $\Omega^*(r)$  with respect to the Schwarzschild (q=0) case. For comparison we plot  $\Omega^*(r)$  in the Kerr space-time [60] on the right panel of Fig. 2. Notice that in the plots of particles on circular orbits in the Kerr metric we have used the dimensionless angular momentum or spin parameter defined by  $j=a/M_T$ , where a is the rotation Kerr parameter and  $M_T$  is the total mass of the Kerr metric as mentioned above. Obviously, for vanishing j one recovers the Schwarzschild metric.

In Fig. 3 (left panel) we constructed the dimensionless orbital angular momentum  $L^*(r)$  of test particles as a function of the normalized radial coordinate in the q-metric. We see that for different values of q angular momentum is always larger than the Schwarzschild q=0 case and a similar behavior is observed in the Kerr met-

![](_page_5_Figure_1.jpeg)

<span id="page-5-0"></span>FIG. 3: Color online. Angular momentum  $L^*$  of test particles versus radial distance r normalized in units of total mass  $M_T$ . Left panel:  $L^*$  in the q-metric for oblate sources (q > 0). Right panel: in the Kerr space-time.

![](_page_5_Figure_3.jpeg)

<span id="page-5-1"></span>FIG. 4: Color online. Energy  $E^*$  of test particles versus radial distance r normalized in units of total mass  $M_T$ . Left panel:  $E^*$  in the oblate q-metric. Right panel:  $E^*$  in the Kerr space-time.

ric for counter-rotating particles, i.e j < 0 (right panel).

In Fig. 4 (left panel) we constructed the energy per unit mass  $E^*$  of test particles as a function of the normalized radial coordinate in the q-metric. Here  $E^*$  is always larger than in the Schwarzschild case and again the behavior is mimicked in the Kerr space-time by counterrotating particles (right panel).

It is easily noticed that the motion of counter-rotating (j < 0) particles on circular orbits in the Kerr metric is mimicked by the effects of the oblateness (q > 0) of the q-metric. Similarly one could see that co-rotating particles are mimicked by prolate sources of the q-metric [59].

Due to the differences in  $\Omega^*$ ,  $L^*$  and  $E^*$  between the oblate sources of the q-metric and the Kerr metric with co-rotating disk, we expect that the radiative flux emitting from the accretion disks will be different. However, we expect accretion disks around the oblate q-metric to mimic the counter-rotating disk in the Kerr space-time. In order to check this, we plotted the radiative flux versus normalized radial coordinate in Fig. 5 (left panel) in the q-metric. Some noticeable differences appear in the vicinity of the ISCO as  $\mathcal{F}^*$  in the q-metric is larger than

than the Schwarzschild case for small radii due to the fact that the ISCO radius is smaller, while for the Kerr space-time we have smaller flux for counter-rotating disk at all radii (right panel).

On the other hand, as expected, for the co-rotating disk in the Kerr metric (right panel) the flux is everywhere larger than in the Schwarzschild metric. This suggests that accretion flux may be able to distinguish disks surrounding static oblate sources from co-rotating disks around a Kerr black hole.

In Fig. 6 (left panel) we show the differential luminosity versus normalized radial coordinate in the oblate q-metric and compare it with the corresponding quantity in the Kerr metric (right panel). Since the differential luminosity is defined via the flux we see that the behavior observed in Fig. 5 translates into the differential luminosity. More precisely, the differential luminosity for the oblate q-metric is larger than that of Schwarzschild only for small radii and becomes smaller at larger distances from the source, while for the Kerr case the differential luminosity is everywhere smaller (larger) than Schwarzschild's for the counter-rotating (co-rotating) case.

![](_page_6_Figure_1.jpeg)

<span id="page-6-1"></span>FIG. 5: Color online. Radiative flux  $\mathcal{F}^*$  multiplied by  $10^5$  of the accretion disk versus radial distance r normalized in units of total mass  $M_T$ . Left panel:  $\mathcal{F}^*$  in the oblate q-metric. Right panel:  $\mathcal{F}^*$  in the Kerr space-time. Notice that for the Kerr metric the change in j causes the flux to increase or decrease everywhere, while for the oblate q-metric the flux increases at small radii and decreases at large radii with respect to Schwarzschild.

![](_page_6_Figure_3.jpeg)

<span id="page-6-2"></span>FIG. 6: Color online. Differential luminosity multiplied by  $10^2$  of the accretion disk versus radial distance r normalized in units of total mass  $M_T$ . Left panel: Differential luminosity in the oblate q-metric. Right panel: Differential luminosity in the Kerr space-time.

In Fig. 7 (left panel) we plotted the spectral luminosity  $\mathcal{L}_{\nu,\infty}$  as defined by Eq. (16) as a function of the frequency of radiation emitted by the accretion disk in the q-metric. For small frequencies the spectral luminosity is larger than in the Schwarzschild case and vice versa. In the Kerr metric (right panel) the spectral luminosity is always larger (smaller) than in the Schwarzschild metric for co-rotating (counter-rotating) disks.

Finally in Fig. 8 we calculate the efficiency of accretion disks in the q-metric to convert mas into radiation. We notice that oblate sources (q > 0) are less efficient than Schwarzschild, while prolate sources (q < 0) are more efficient (left panel). Also we can see that there always exist a value of q > 0 for which an oblate static source can produce the same efficiency as that of a Kerr black hole with counter-rotating disk (right panel).

#### <span id="page-6-0"></span>V. FINAL OUTLOOKS AND PERSPECTIVES

We considered the q-metric, a static and axially symmetric vacuum solution of Einstein's equations, as the possible exterior field of an exotic compact object and considered the eventuality that such a source may be distinguished from a Kerr black hole from the observation of the accretion disk's spectrum.

To do so, we derived the orbital parameters of test particles in the equatorial plane of the q-metric for oblate (i.e. positive q) sources, calculated  $r_{ISCO}/M_T$  and obtained the expression of measurable quantities such as the radiative flux, differential luminosity and efficiency of the accretion disk.

We showed that the appearance of oblate sources may be mimicked by a Kerr space-time with counter-rotating disk (j < 0). However, the flux emitted by the q-metric appears to be larger at very small radii (i.e. close to

![](_page_7_Figure_1.jpeg)

<span id="page-7-0"></span>FIG. 7: Color online. Spectral luminosity versus frequency of the emitted radiation for blackbody emission of the accretion disk. Left panel: Spectral luminosity in the oblate q-metric. Right panel: Spectral luminosity in the Kerr space-time.

![](_page_7_Figure_3.jpeg)

<span id="page-7-1"></span>FIG. 8: Left panel: Radiative efficiency for the oblate q-metric. Notice that the oblate q-metric is less efficient in converting accreting mass into radiation with respect to Schwarzschild. Right panel: Degeneracy between the radiative efficiency in the q-metric and the Kerr metric. For each value of the deformation parameter q there exist a value of the angular momentum j in the Kerr space-time for which the accretion disks in two geometries have the same efficiency.

the ISCO) with respect to Schwarzschild and Kerr with negative j, thus suggesting the possibility that the spectral features of the two kinds of accretion disks may be distinguished.

Further, under the assumption of black body emission from the disk, we constructed the spectral luminosity as a function of the frequency of emitted radiation in the q-metric and compared it with the one in the Kerr metric. Whereas for the the Kerr metric we see the luminosity increasing (decreasing) with respect to Schwarzschild for all the frequencies with j>0 (j<0), the q-metric shows a different behavior with the luminosity being larger (smaller) at smaller (larger) frequencies. This suggesting the possibility that spectral features of accretion disks around compact objects may be used to distinguish the two geometries.

Of course the features of the spectra emitted by real accretion disks surrounding compact objects in the universe

are much more complicated than the simple toy models employed here. For this reason such simple models can not be used to practically determine the actual geometry in the proximity of astrophysical black hole candidates. However, we believe that the general considerations obtained here do indicate a road towards the possibility in the future of experimentally constraining geometric quantities, such as mass quadrupole moment, of compact sources and thus answer the question whether astrophysical black holes are indeed described by the Kerr metric.

## Acknowledgments

KB, TK, EK and OL acknowledge the Ministry of Education and Science of the Republic of Kazakhstan, Grant: IRN AP08052311.

- <span id="page-8-0"></span>[1] P. T. Chru´sciel, J. L. Costa, and M. Heusler, Living Reviews in Relativity 15, 7 (2012), 1205.6112.
- <span id="page-8-1"></span>[2] V. Cardoso and P. Pani, Living Reviews in Relativity 22, 4 (2019), 1904.05363.
- <span id="page-8-2"></span>[3] S. Beheshti and E. Gasper´ın, Phys. Rev. D 94, 024015 (2016), 1512.08707.
- <span id="page-8-3"></span>[4] P. O. Mazur and E. Mottola, Proceedings of the National Academy of Science 101, 9545 (2004), gr-qc/0407075.
- <span id="page-8-4"></span>[5] B. P. Abbott, R. Abbott, T. D. Abbott, M. R. Abernathy, F. Acernese, K. Ackley, C. Adams, T. Adams, P. Addesso, R. X. Adhikari, et al., Phys. Rev. Lett. 116, 061102 (2016), 1602.03837.
- <span id="page-8-5"></span>[6] B. P. Abbott, R. Abbott, T. D. Abbott, M. R. Abernathy, F. Acernese, K. Ackley, C. Adams, T. Adams, P. Addesso, R. X. Adhikari, et al., Phys. Rev. Lett. 116, 221101 (2016), 1602.03841.
- <span id="page-8-6"></span>[7] Gravity Collaboration, R. Abuter, A. Amorim, N. Anugu, M. Baub¨ock, M. Benisty, J. P. Berger, N. Blind, H. Bonnet, W. Brandner, et al., Astron. Astrophys. 615, L15 (2018), 1807.09409.
- [8] A. M. Ghez, B. L. Klein, M. Morris, and E. E. Becklin, Astrophys. J. 509, 678 (1998), astro-ph/9807210.
- <span id="page-8-7"></span>[9] A. M. Ghez, M. Morris, E. E. Becklin, A. Tanner, and T. Kremenek, Nature 407, 349 (2000), astro-ph/0009339.
- <span id="page-8-8"></span>[10] Event Horizon Telescope Collaboration, K. Akiyama, A. Alberdi, W. Alef, K. Asada, R. Azulay, A.-K. Baczko, D. Ball, M. Balokovi´c, J. Barrett, et al., Astrophys. J. Lett. 875, L1 (2019), 1906.11238.
- <span id="page-8-9"></span>[11] R. A. Remillard and J. E. McClintock, Annual Rev. of Astron. Astrophys. 44, 49 (2006), astro-ph/0606352.
- <span id="page-8-10"></span>[12] L. C. Ho, A. V. Filippenko, and W. L. W. Sargent, Astrophys. J. 487, 568 (1997), astro-ph/9704108.
- <span id="page-8-11"></span>[13] D. Richstone, E. A. Ajhar, R. Bender, G. Bower, A. Dressler, S. M. Faber, A. V. Filippenko, K. Gebhardt, R. Green, L. C. Ho, et al., Nature 385, A14 (1998), astroph/9810378.
- <span id="page-8-12"></span>[14] M. A. Abramowicz and P. C. Fragile, Living Reviews in Relativity 16, 1 (2013), 1104.5499.
- <span id="page-8-13"></span>[15] K. Boshkayev, A. Idrissov, O. Luongo, and D. Malafarina, Mon. Not. Roy. Astr. Soc. 496, 1115 (2020), 2006.01269.
- <span id="page-8-14"></span>[16] E. A. Becerra-Vergara, C. R. Arg¨uelles, A. Krut, J. A. Rueda, and R. Ruffini, Mon. Not. Roy. Astr. Soc. (2021), 2105.06301.
- <span id="page-8-21"></span>[17] O. Luongo and M. Muccino, Phys. Rev. D 98, 103520 (2018), 1807.00180.
- <span id="page-8-15"></span>[18] T. Johannsen, A. E. Broderick, P. M. Plewa, S. Chatzopoulos, S. S. Doeleman, F. Eisenhauer, V. L. Fish, R. Genzel, O. Gerhard, and M. D. Johnson, Phys. Rev. Lett. 116, 031101 (2016), 1512.02640.
- [19] C. Barcel´o, R. Carballo-Rubio, and L. Garay, Universe 2, 7 (2016), 1510.04957.
- [20] S. B. Giddings, Classical and Quantum Gravity 33, 235010 (2016), 1602.03622.
- <span id="page-8-16"></span>[21] D. Malafarina, Universe 3, 48 (2017), 1703.04138.
- <span id="page-8-17"></span>[22] H. Weyl, Annalen der Physik 359, 117 (1917).
- <span id="page-8-18"></span>[23] H. Weyl, Annalen der Physik 364, 185 (1919).
- <span id="page-8-19"></span>[24] H. Quevedo, Fortschritte der Physik 38, 733 (1990).
- <span id="page-8-20"></span>[25] J. L. Hern´andez-Pastora and J. Mart´ın, General Relativity and Gravitation 26, 877 (1994).
- <span id="page-8-22"></span>[26] D. M. Zipoy, Journal of Mathematical Physics 7, 1137

- (1966).
- <span id="page-8-23"></span>[27] B. H. Voorhees, Phys. Rev. D 2, 2119 (1970).
- <span id="page-8-24"></span>[28] K. Boshkayev, E. Gasper´ın, A. C. Guti´errez-Pi˜neres, H. Quevedo, and S. Toktarbay, Phys. Rev. D 93, 024024 (2016), 1509.03827.
- <span id="page-8-25"></span>[29] D. Papadopoulos, B. Stewart, and L. Witten, Phys. Rev. D 24, 320 (1981).
- <span id="page-8-26"></span>[30] W. C. Hernandez, Phys. Rev. 153, 1359 (1967).
- <span id="page-8-27"></span>[31] W. B. Bonnor, General Relativity and Gravitation 45, 1403 (2013).
- <span id="page-8-28"></span>[32] B. W. Stewart, D. Papadopoulos, L. Witten, R. Berezdivin, and L. Herrera, General Relativity and Gravitation 14, 97 (1982).
- <span id="page-8-29"></span>[33] L. Herrera, G. Magli, and D. Malafarina, General Relativity and Gravitation 37, 1371 (2005), gr-qc/0407037.
- <span id="page-8-30"></span>[34] J. L. Hernandez-Pastora, L. Herrera, and J. Martin, Classical and Quantum Gravity 33, 235005 (2016), 1607.02315.
- <span id="page-8-31"></span>[35] M. Abishev, F. Belissarova, K. Boshkayev, H. Quevedo, S. Toktarbay, A. Mansurova, and A. Muratkhan, arXiv e-prints arXiv:1902.03485 (2019), 1902.03485.
- <span id="page-8-32"></span>[36] J. A. Arrieta-Villamizar, J. M. Vel´asquez-Cadavid, O. M. Pimentel, F. D. Lora-Clavijo, and A. C. Guti´errez-Pi˜neres, Classical and Quantum Gravity 38, 015008 (2021), 2007.13600.
- [37] R. Shaikh, S. Paul, P. Banerjee, and T. Sarkar, arXiv e-prints arXiv:2105.12057 (2021), 2105.12057.
- <span id="page-8-33"></span>[38] A. B. Abdikamalov, A. A. Abdujabbarov, D. Ayzenberg, D. Malafarina, C. Bambi, and B. Ahmedov, Phys. Rev. D 100, 024014 (2019), 1904.06207.
- <span id="page-8-34"></span>[39] A. N. Chowdhury, M. Patil, D. Malafarina, and P. S. Joshi, Phys. Rev. D 85, 104031 (2012), 1112.2522.
- <span id="page-8-35"></span>[40] S. Faraji, arXiv e-prints arXiv:2010.15723 (2020), 2010.15723.
- <span id="page-8-36"></span>[41] A. Allahyari, H. Firouzjahi, and B. Mashhoon, Phys. Rev. D 99, 044005 (2019), 1812.03376.
- <span id="page-8-37"></span>[42] C. A. Benavides-Gallego, A. Abdujabbarov, D. Malafarina, and C. Bambi, Phys. Rev. D 101, 124024 (2020), 2005.07554.
- <span id="page-8-38"></span>[43] C. A. Benavides-Gallego, A. Abdujabbarov, D. Malafarina, B. Ahmedov, and C. Bambi, Phys. Rev. D 99, 044012 (2019), 1812.04846.
- <span id="page-8-39"></span>[44] B. Toshmatov and D. Malafarina, Phys. Rev. D 100, 104052 (2019), 1910.11565.
- <span id="page-8-40"></span>[45] K. Boshkayev, O. Luongo, and M. Muccino, European Physical Journal C 80, 964 (2020), 2010.08254.
- <span id="page-8-41"></span>[46] D. Malafarina and S. Sagynbayeva, arXiv e-prints arXiv:2009.12839 (2020), 2009.12839.
- <span id="page-8-42"></span>[47] I. D. Novikov and K. S. Thorne, in Black Holes (Les Astres Occlus) (1973), pp. 343–450.
- <span id="page-8-43"></span>[48] D. N. Page and K. S. Thorne, Astrophys. J. 191, 499 (1974).
- <span id="page-8-44"></span>[49] Z. Kov´acs and T. Harko, Phys. Rev. D 82, 124047 (2010), 1011.4127.
- <span id="page-8-45"></span>[50] P. S. Joshi, D. Malafarina, and R. Narayan, Classical and Quantum Gravity 31, 015002 (2014), 1304.7331.
- <span id="page-8-46"></span>[51] H. Stephani, D. Kramer, M. MacCallum, C. Hoenselaers, and E. Herlt, Exact solutions of Einstein's field equations (Cambridge University Press, 2003).
- <span id="page-8-47"></span>[52] H. Quevedo, International Journal of Modern Physics D 20, 1779 (2011), 1012.4030.

- <span id="page-9-0"></span>[53] F. Frutos-Alfaro, H. Quevedo, and P. A. Sanchez, Royal Society Open Science 5, 170826 (2018), 1704.06734.
- <span id="page-9-1"></span>[54] I. M. Mej´ıa, V. S. Manko, and E. Ruiz, Phys. Rev. D 100, 124021 (2019), 1909.09952.
- [55] G. Erez and N. Rosen, Bulletin of the Research Council of Israel 8F, 47 (1959).
- <span id="page-9-2"></span>[56] T. I. Gutsunayev, T. I. Gutsunaev, and V. S. Manko, General Relativity and Gravitation 17, 1025 (1985).
- <span id="page-9-3"></span>[57] L. Herrera, F. M. Paiva, N. O. Santos, and V. Ferrari, International Journal of Modern Physics D 9, 649 (2000),
- gr-qc/9812023.
- <span id="page-9-4"></span>[58] R. Shafee, J. E. McClintock, R. Narayan, S. W. Davis, L.-X. Li, and R. A. Remillard, Astrophys. J. Lett. 636, L113 (2006), astro-ph/0508302.
- <span id="page-9-5"></span>[59] B. Toshmatov, D. Malafarina, and N. Dadhich, Phys. Rev. D 100, 044001 (2019), 1905.01088.
- <span id="page-9-6"></span>[60] R. P. Kerr, Phys. Rev. Lett. 11, 237 (1963).
- <span id="page-9-7"></span>[61] J. M. Bardeen, W. H. Press, and S. A. Teukolsky, Astrophys. J. 178, 347 (1972).