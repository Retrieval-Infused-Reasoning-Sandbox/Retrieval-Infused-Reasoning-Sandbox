# Properties of spherical galaxies and clusters with an NFW density profile

Ewa L. Łokas¹★ and Gary A. Mamon<sup>2,3★</sup>

Accepted 2000 September 5. Received 2000 August 14; in original form 2000 February 25

#### ABSTRACT

Using the standard dynamical theory of spherical systems, we calculate the properties of spherical galaxies and clusters whose density profiles obey the universal form first obtained in high-resolution cosmological N-body simulations by Navarro, Frenk & White (NFW). We adopt three models for the internal kinematics: isotropic velocities, constant anisotropy and increasingly radial Osipkov-Merritt anisotropy. Analytical solutions are found for the radial dependence of the mass, gravitational potential, velocity dispersion, energy and virial ratio and we test their variability with the concentration parameter describing the density profile and amount of velocity anisotropy. We also compute structural parameters, such as halfmass radius, effective radius and various measures of concentration. Finally, we derive projected quantities, the surface mass density and line-of-sight as well as aperture-velocity dispersion, all of which can be directly applied in observational tests of current scenarios of structure formation. On the mass scales of galaxies, if constant mass-to-light is assumed, the NFW surface density profile is found to fit Hubble-Reynolds laws well. It is also well fitted by Sérsic  $R^{1/m}$  laws, for  $m \approx 3$ , but in a much narrower range of m and with much larger effective radii than are observed. Assuming in turn reasonable values of the effective radius, the mass density profiles imply a mass-to-light ratio that increases outwards at all radii.

**Key words:** methods: analytical – galaxies: clusters: general – large-scale structure of Universe.

## 1 INTRODUCTION

A universal profile of dark-matter haloes was introduced as a result of high-resolution N-body simulations performed by Navarro, Frenk & White (1995, 1996, 1997, hereinafter NFW123) for power-law as well as CDM initial power spectra of density fluctuations. NFW123 found that in a large range of masses the density profiles of dark haloes can be fitted by a simple formula with only one fitting parameter. The density profile steepens from  $r^{-1}$  near the centre of the halo to  $r^{-3}$  at large distances. The NFW profile has been confirmed in cosmological simulations by Cole & Lacey (1996), Tormen, Bouchet & White (1997), Huss, Jain & Steinmetz (1999a), Jing (1999) and Bullock et al. (1999), while Huss, Jain & Steinmetz (1999b) have shown that the NFW profile also arises from non-cosmological initial conditions. It is worthwhile noting that some (but not all) recent very high-resolution cosmological simulations produce steeper density profiles, with inner slopes  $\simeq -1.5$  (Fukushige & Makino 1997; Moore et al. 1998; Ghigna et al. 1999; see also Jing & Suto 2000). The density profiles in the cosmological simulations also display considerable scatter (Avila-Reese et al. 1999; Bullock et al. 1999) and Avila-Reese et al. find that the outer slopes of galaxy size haloes are steeper than the NFW slope of -3 when selected within clusters (-4) and slightly shallower within groups (-2.7). Although the exact properties of dark-matter haloes are still under debate, the NFW profile is presently considered to provide the reference frame for any further numerical research on density profiles of dark haloes.

Simple cosmological derivations of the density profiles of bound objects are difficult, essentially because one needs to work in the non-linear regime of the growth of gravitational instabilities. Nevertheless, using the spherical top-hat model of Gunn & Gott (1972), density profiles typically varying as  $r^{-9/4}$  were derived by Gott (1975), Gunn (1977), Fillmore & Goldreich (1984) and Bertschinger (1985). Hoffman & Shaham (1985) applied the spherical infall model to the hierarchical clustering scenario and predicted that the density profiles of haloes should depend on  $\Omega$  as well as the initial power spectrum of density fluctuations. However, for  $\Omega = 1$  they obtained power-law profiles in contradiction with the steepening slopes found in the current N-body simulations described above. In a recent study, Łokas (2000) has improved the model of Hoffman & Shaham (1985) by a generalization of the initial density distribution, the introduction of a cut-off in this distribution at half the inter-peak

<sup>&</sup>lt;sup>1</sup>Copernicus Astronomical Center, Bartycka 18, 00-716 Warsaw, Poland

<sup>&</sup>lt;sup>2</sup>Institut d'Astrophysique de Paris (CNRS UPR 341), 98 bis Bd Arago, F-75014 Paris, France

<sup>&</sup>lt;sup>3</sup>DAEC (CNRS UMR 8631), Observatoire de Paris, Place Jules Janssen, F-92195 Meudon, France

<sup>\*</sup>E-mail: lokas@camk.edu.pl (ELL); gam@iap.fr (GAM)

separation and by a proper calculation of the collapse factor. The improved model reproduces the changing slope of the density profile and its dependence on halo mass and the type of cosmological power spectrum found by NFW123. The NFW profile is also reproduced in studies taking into account the merging mechanism (see Lacey & Cole 1993) in the halo formation scenario (e.g. Salvador-Solé, Solanes & Manrique 1998; Avila-Reese, Firmani & Hernandez 1998). Therefore the numerical and analytical considerations seem to converge on the statement that the density profiles of dark-matter haloes are indeed well described by the universal formula proposed by NFW123.

The ultimate test of both the analytical and numerical results must come from the observations of density profiles of galaxies and galaxy clusters. Three recent studies of clusters (Carlberg et al. 1997; Adami et al. 1998; van der Marel et al. 2000) claim good agreement between cluster observations and the NFW mass density profile. But for galaxies, the situation is less satisfying. Flores & Primack (1994) show that the NFW profile is incompatible with the rotation curves of spiral galaxies, while Kravtsov et al. (1998) estimate that the inner slope of the density profile of dwarf irregular and LSB galaxies is -0.3 instead of -1. However, these conclusions were obtained with a number of assumptions and approximations concerning the very unclear issues of biasing, non-sphericity of objects and so on. Besides, as pointed out by van den Bosch et al. (2000), Swaters, Madore & Trewhella (2000) and van den Bosch & Swaters (2000), the observed rotation curves of these galaxies are too uncertain to discriminate between cores and cusps.

The main motivation for this research is to explore analytically the physical properties of objects with NFW density profiles. The aim is to check whether these properties are acceptable from the physical point of view and thus to test the validity of density profiles obtained in cosmological *N*-body simulations. Additionally, this paper presents formulae for observable quantities that can be used for comparisons between the theoretical predictions (such as the NFW profile) and observations.

The paper is organized as follows: after a short presentation of the universal formula for the density profile proposed by NFW123, in Section 2 we describe physical properties of spherical systems following from this density profile. Section 3 is devoted to a simple comparison between the projected NFW density profile and the surface brightness of elliptical galaxies. A more thorough comparison is beyond the scope of the present paper and will be given elsewhere (Mamon & Łokas, in preparation). A discussion follows in Section 4.

## 2 PROPERTIES OF THE NFW MODEL

## 2.1 Basic properties

NFW123 established that the density profiles of dark-matter haloes in high-resolution cosmological simulations for a wide range of masses and for different initial power spectra of density fluctuations are well fitted by the formula

$$\frac{\rho(r)}{\rho_c^0} = \frac{\delta_{\text{char}}}{(r/r_{\text{s}})(1 + r/r_{\text{s}})^2}$$
 (1)

with a single fitting parameter  $\delta_{\text{char}}$ , the characteristic density. The so-called scale radius  $r_s$  is defined by

$$r_{\rm S} = \frac{r_{\rm v}}{c},\tag{2}$$

where  $r_{\rm v}$  is the virial radius, usually defined as the distance from the centre of the halo within which the mean density is v times the present critical density,  $\rho_c^0$ . The value of the virial overdensity v is often assumed to be v=178, a number predicted by the simplest version of the spherical model for  $\Omega=1$ . For other cosmological models it can be lower by a factor of 2 or more (Lacey & Cole 1993; Eke, Cole & Frenk 1996). However, according to the improved spherical infall model (Łokas 2000), v can be as low as 30 even for v = 1. In the following, v is kept as a free parameter.

The quantity c introduced in equation (2) is the concentration parameter, which is related to the characteristic density by

$$\delta_{\text{char}} = \frac{vc^3 g(c)}{3},\tag{3}$$

where

$$g(c) = \frac{1}{\ln(1+c) - c/(1+c)}. (4)$$

The concentration parameter will be used hereafter as the only parameter describing the shape of density profile. From cosmological *N*-body simulations (Navarro et al. 1997; Bullock et al. 1999; Jing 2000; Jing & Suto 2000), extended Press–Schechter theory (Navarro et al. 1997; Salvador-Solé, Solanes & Manrique 1998) and the spherical infall model (Łokas 2000), we know that c depends on the mass of object and the form of the initial power spectrum of density fluctuations. For all initial power spectra, the observed trend is for lower concentration parameter in higher mass objects, with 4 < c < 22 in cosmological simulations with CDM initial power spectra and c up to 90 for the less realistic scale-free power spectra. More precisely, in the  $\Delta$ CDM cosmology, c = 5 corresponds to the masses of clusters of galaxies, while c = 10 corresponds to the masses of bright galaxies.

It is convenient to express the distance from the centre of the object in units of the virial radius  $r_v$ :

$$s = \frac{r}{r_{c}} \tag{5}$$

and the density profile of equation (1) then becomes

$$\frac{\rho(s)}{\rho_c^0} = \frac{vc^2g(c)}{3s(1+cs)^2},\tag{6}$$

The mass of the halo is usually defined as the mass within the virial radius:

$$M_{\rm v} = \frac{4}{3} \pi r_{\rm v}^3 v \rho_c^0. \tag{7}$$

The distribution of mass in units of the virial mass follows from equation (6):

$$\frac{M(s)}{M_{\rm v}} = g(c) \left[ \ln(1+cs) - \frac{cs}{1+cs} \right] \tag{8}$$

and we see that it diverges at large s, which is a disadvantage of the model from a physical point of view.

The gravitational potential associated with the density distribution (6) is

$$\frac{\Phi(s)}{V_{v}^{2}} = -g(c)\frac{\ln(1+cs)}{s},\tag{9}$$

where  $V_{\rm v}$  is the circular velocity at  $r = r_{\rm v}$ :

$$V_{\rm v}^2 = V^2(r_{\rm v}) = \frac{GM_{\rm v}}{r_{\rm v}} = \frac{4}{3}\pi G r_{\rm v}^2 v \rho_c^0.$$
 (10)

Hence, from equation (9) we see that the gravitational potential at the centre,  $\Phi(0) = -cg(c)V_v^2$ , is finite.

Equations (8) and (10) lead to a circular velocity that obeys

$$\frac{V^2(s)}{V_v^2} = \frac{g(c)}{s} \left[ \ln(1+cs) - \frac{cs}{1+cs} \right]. \tag{11}$$

Equations (8), (9) and (11) were first derived by Cole & Lacey (1996).

The radial velocity dispersion  $\sigma_r(r)$  can be obtained by solving the Jeans equation

$$\frac{1}{\rho} \frac{\mathrm{d}}{\mathrm{d}r} (\rho \sigma_{\mathrm{r}}^2) + 2\beta \frac{\sigma_{\mathrm{r}}^2}{r} = -\frac{\mathrm{d}\Phi}{\mathrm{d}r},\tag{12}$$

where  $\beta = 1 - \sigma_{\theta}^2(r)/\sigma_{\rm r}^2(r)$  is a measure of the anisotropy in the velocity distribution. In the simplest case of isotropic orbits,  $\sigma_{\theta}(r) = \sigma_{\rm r}(r)$  and  $\beta = 0$ . This value of  $\beta$  is also close to the results of *N*-body simulations: Cole & Lacey (1996) and Thomas et al. (1998) show that, in a variety of cosmological models, the ratio  $\sigma_{\theta}/\sigma_{\rm r}$  is not far from unity and decreases slowly with distance from the centre to reach  $\approx 0.8$  at the virial radius. However, Huss, Jain & Steinmetz (1999a) find  $\sigma_{\theta}/\sigma_{\rm r} \approx 0.6$  at  $r_v$ .

First we consider the case of  $\beta = \text{const.}$  Then the solution to the equation (12) with the condition  $\sigma_r \to 0$  at  $s \to \infty$  is

$$\frac{\sigma_r^2}{V_v^2}(s, \beta = \text{const}) = g(c)(1 + cs)^2 s^{1-2\beta}$$

$$\times \left[ \int_0^\infty \left[ \frac{s^{2\beta - 3} \ln(1 + cs)}{(1 + cs)^2} - \frac{cs^{2\beta - 2}}{(1 + cs)^3} \right] ds.$$
 (13)

For  $\beta = 0, 0.5$  and 1, reasonably simple analytical solutions to this equation can be found:

$$\frac{\sigma_{\rm r}^2}{V_{\rm v}^2}(s,\beta=0) = \frac{1}{2}c^2g(c)s(1+cs)^2 \left[\pi^2 - \ln(cs) - \frac{1}{cs}\right] 
- \frac{1}{(1+cs)^2} - \frac{6}{1+cs} + \left(1 + \frac{1}{c^2s^2} - \frac{4}{cs} - \frac{2}{1+cs}\right) 
\times \ln(1+cs) + 3\ln^2(1+cs) + 6\text{Li}_2(-cs)\right], \qquad (14)$$

$$\frac{\sigma_{\rm r}^2}{V_{\rm v}^2}(s,\beta=0.5) = cg(c)(1+cs)^2 \left[-\frac{\pi^2}{3} + \frac{1}{2(1+cs)^2} + \frac{2}{1+cs}\right] 
+ \frac{\ln(1+cs)}{cs} + \frac{\ln(1+cs)}{1+cs} - \ln^2(1+cs) - 2\text{Li}_2(-cs)\right], \qquad (15)$$

$$\frac{\sigma_{\rm r}^2}{V_{\rm v}^2}(s,\beta=1) = g(c)(1+cs)^2 \frac{1}{s} \left[ \frac{\pi^2}{6} - \frac{1}{2(1+cs)^2} - \frac{1}{1+cs} - \frac{\ln(1+cs)}{1+cs} + \frac{\ln^2(1+cs)}{2} + \text{Li}_2(-cs) \right].$$
(16)

In the above expressions  $\text{Li}_2(x)$  is the dilogarithm, a special function that can be conveniently dealt with using MATHEMATICA packages. Otherwise, it can be approximated by

$$\operatorname{Li}_{2}(x) = \int_{x}^{0} \frac{\ln(1-t) \, \mathrm{d}t}{t} \simeq x[1+10^{-0.5}(-x)^{0.62/0.7}]^{-0.7}.$$
 (17)

The fit is accurate to better than 1.5 per cent in the range -100 < x < 0.

We included the predictions for  $\beta=1$  just as a limiting case. In fact such a model with purely radial orbits and NFW density profile is not physical since its distribution function is not everywhere non-negative. As pointed out by e.g. Richstone & Tremaine (1984, see also Łokas & Hoffman 2000), such velocity anisotropy requires the inner density profile to be  $r^{-2}$  or steeper for the model to be physical.

A more realistic description of velocity anisotropy is provided by a model proposed by Osipkov (1979) and Merritt (1985) with  $\beta$ -dependence on distance from the centre of the object:

$$\beta_{\rm OM} = \frac{s^2}{s^2 + s^2},\tag{18}$$

where  $s_a$  is the anisotropy radius determining the transition from isotropic orbits inside to radial orbits outside. As mentioned above, the results of *N*-body simulations suggest  $\sigma_{\theta}/\sigma_{\rm r} \simeq 0.8$  and therefore  $\beta \simeq 0.36$  at s=1, which gives  $s_a \simeq 4/3$ , a value that we adopt here for all numerical calculations.

For the Osipkov-Merritt model, the solution to the Jeans equation (with the same boundary condition as before) reads

$$\frac{\sigma_{\rm r}^2}{V_{\rm v}^2}(s, \beta_{\rm OM}) = \frac{g(c)s(1+cs)^2}{s^2 + s_{\rm a}^2} \times \int_{s}^{\infty} \left[ \frac{(s^2 + s_{\rm a}^2)\ln(1+cs)}{s^3(1+cs)^2} - \frac{c(s^2 + s_{\rm a}^2)}{s^2(1+cs)^3} \right] ds \quad (19)$$

and the integration gives

$$\frac{\sigma_{\rm r}^2}{V_{\rm v}^2}(s, \beta_{\rm OM}) = \frac{g(c)s(1+cs)^2}{2(s^2+s_{\rm a}^2)} \left\{ -\frac{cs_{\rm a}^2}{s} - c^2s_{\rm a}^2 \ln(cs) + c^2s_{\rm a}^2 \ln(1+cs) \left( 1 + \frac{1}{c^2s^2} - \frac{4}{cs} \right) - (1+c^2s_{\rm a}^2) \right. \\
\left. \times \left[ \frac{1}{(1+cs)^2} + \frac{2\ln(1+cs)}{1+cs} \right] + (1+3c^2s_{\rm a}^2) \right. \\
\left. \times \left[ \frac{\pi^2}{3} - \frac{2}{1+cs} + \ln^2(1+cs) + 2\text{Li}_2(-cs) \right] \right\}. \tag{20}$$

Fig. 1 shows the radial dependence of the radial velocity dispersion. The upper panel of the figure presents how the results depend on the concentration parameter in the isotropic case, while the lower panel compares predictions for different anisotropy models with c=10.

## 2.2 The energy distributions

The potential energy associated with the mass distribution of equation (8) is

$$W(s) = -\frac{1}{r_{\rm v}} \int_0^s \frac{GM(s)}{s} \frac{dM(s)}{ds} ds$$
  
=  $-W_{\infty} \left[ 1 - \frac{1}{(1+cs)^2} - \frac{2\ln(1+cs)}{1+cs} \right],$  (21)

where

$$W_{\infty} = -\lim_{s \to \infty} W(s) = \frac{cg^2(c)GM_{\nu}^2}{2r_{\nu}}.$$
 (22)

![](_page_3_Figure_2.jpeg)

**Figure 1.** Radial velocity dispersion profile (in units of the circular velocity at the virial radius), given by in isotropic model, equation (14), for three different values of the concentration parameter c (upper panel) and for the four considered anisotropy models with c=10 (lower panel).

The kinetic energy for arbitrary  $\beta$  is given by

$$T(s,\beta) = 2\pi r_{\rm v}^3 \int_0^s (3 - 2\beta) \rho(s) \sigma_{\rm r}^2(s,\beta) s^2 \, \mathrm{d}s. \tag{23}$$

For the three cases of  $\beta = 0$ , 0.5 and 1, we obtain, respectively,

$$T(s, \beta = 0) = \frac{1}{2} W_{\infty} \left\{ -3 + \frac{3}{1+cs} - 2\ln(1+cs) + cs[5+3\ln(1+cs)] - c^2 s^2 [7+6\ln(1+cs)] + c^3 s^3 [\pi^2 - \ln c - \ln s + \ln(1+cs)] + 3\ln^2(1+cs) + 6\text{Li}_2(-cs)] \right\},$$
(24)

![](_page_3_Figure_8.jpeg)

**Figure 2.** The radial dependence of the virial ratio in the isotropic model (equations 21 and 24) for three different values of the concentration parameter (upper panel) and for the four considered anisotropy models with c=10 (lower panel).

$$T(s, \beta = 0.5) = \frac{1}{3} W_{\infty} \left\{ -3 + \frac{3}{1+cs} - 3\ln(1+cs) + 6cs[1 + \ln(1+cs)] - c^2 s^2 [\pi^2 + 3\ln^2(1+cs) + 6\text{Li}_2(-cs)] \right\}, \quad (25)$$

$$T(s, \beta = 1) = \frac{1}{2} W_{\infty} \left\{ -2\ln(1+cs) + 4\ln^2(1+cs) + 2\text{Li}_2(-cs) \right\}, \quad (26)$$

where we have used in each case the corresponding expression for  $\sigma_{\rm r}^2(s,\beta)$  from equations (14)–(16). For the Osipkov–Merritt model the calculation has to be done numerically.

The results for the potential and kinetic energy (21)-(26) lead

to a virial ratio  $\lim_{s\to\infty} 2T/|W|=1$  for any value of c, in agreement with the virial theorem. Fig. 2 shows how the virial ratio depends on distance for three different values of the concentration parameter in the isotropic case (upper panel) and compares the ratios obtained for different  $\beta$  with c=10 (lower panel). At low radii, the virial ratio is large, especially for low concentration parameters and models with much anisotropy. However, as demonstrated by Fig. 3, at the virial radius  $r_v(s=1)$ , 2T/|W| is still greater than unity and grows with the amount of anisotropy in the model. We see that the virial theorem is better satisfied at s=1 for objects with larger concentration parameters, as  $\lim_{c\to\infty} 2T/|W|(s=1)=1$ . Since objects of smaller mass have larger concentration parameters, they are closer to dynamical equilibrium.

The scalar virial theorem we referred to above is expected to be satisfied for self-gravitating systems in the steady state. In more realistic situations, the system is never isolated and experiences an external gravitational field; there is also continuous infall of matter. We may conclude from the results above that objects with NFW density profiles and different velocity distributions are close to dynamical equilibrium. However, the virial ratio cannot be used to define the boundary of the virialized object.

#### 2.3 Structural parameters

A useful quantity is the half-mass radius. Unfortunately, the divergence of the mass of the NFW profile forces one to define the half-mass radius within a cut-off radius  $r_{\rm cut}$ . The most natural choice is  $r_{\rm cut}=r_{\rm v}$ , since the density distribution is only reliable out to the virial radius. With  $r_{\rm cut}=r_{\rm v}$ , the half-mass radius  $r_{\rm h}$  satisfies the following relation for the mass of the dimensionless radius:

$$M\left(\frac{r_{\rm h}}{r_{\rm v}}\right) = \frac{M(1)}{2}.\tag{27}$$

Numerical values of  $r_h/r_v$  are easily obtained using equation (8) and over the range 1 < c < 100 they can be approximated to better than 2 per cent accuracy by

$$\frac{r_{\rm h}}{r_{\rm v}} = 0.6082 - 0.1843 \log c - 0.1011 \log^2 c + 0.03918 \log^3 c.$$

![](_page_4_Figure_9.jpeg)

**Figure 3.** Dependence on the concentration parameter of the virial ratio at the virial radius for the four considered anisotropy models.

The lowest thick solid line in Fig. 4 shows how  $r_h/r_v$  decreases with increasing concentration parameter.

It is useful to estimate the concentration  $\gamma$  of a dynamical system, such that

$$\langle \sigma^2 \rangle = \gamma \frac{GM}{r_{\rm h}},$$
 (29)

where  $\langle \sigma^2 \rangle = \langle \sigma_{\rm r}^2 + \sigma_{\theta}^2 + \sigma_{\phi}^2 \rangle$  is the mass weighted mean-square velocity dispersion. As first noted by Spitzer (1969) for polytropes, many realistic density profiles have  $\gamma = 0.4$ . For example, it is easy to show that for the Hernquist (1990) model with  $\beta = 0$ ,  $\gamma = (1 + \sqrt{2})/6 \approx 0.403$  (Mamon 2000).

Using equation (29) and limiting again the mass to  $r_{\rm cut}=r_{\rm v},$  we define  $\gamma$  with

$$\gamma = \frac{r_{\rm h} \langle \sigma^2 \rangle_{r \leq r_{\rm v}}}{GM(1)} = 2 \frac{r_{\rm h} T(1, \beta)}{GM^2(1)},\tag{30}$$

where we made use of

$$T(x,\beta) = \frac{1}{2}M(x)\langle \sigma^2 \rangle_{r \leq xr_y}.$$
 (31)

The values of  $\gamma$  for different velocity anisotropy models, derived from equations (7), (8), (22), (22)–(26), (28) and (30), are shown in Fig. 4 and in the case of  $\beta=0$  yield numbers closest to 0.4:  $\gamma=0.56$  for c=5 and  $\gamma=0.51$  for c=10. Thus the NFW model produces  $\gamma$ s that are higher than the canonical value of 0.4, especially if more velocity anisotropy is assumed. This may be caused by the ill-defined cut-off radius.

In models with homogeneous cores, the central density, the core radius  $r_{\rm c}$  and the central 3-D velocity dispersion  $\sigma^2(0)$  are related through

$$4\pi G\rho(0)r_c^2 = \frac{1}{3}\eta\sigma^2(0). \tag{32}$$

King (1966) models have  $\eta = 9$ . In models with cuspy cores, we propose the scaling relation

$$4\pi G\rho(r_s)r_s^2 = \frac{1}{2}\eta\langle\sigma^2\rangle_{r < r_s}.$$
 (33)

Using equations (2), (6) and (7), one has  $4\pi G\rho(r_s)r_s^2 = cg(c)V_v^2/4$ 

![](_page_4_Figure_25.jpeg)

**Figure 4.** Dependence on the concentration parameter of the half-mass radius, scaled to the virial radius (thicker lower solid line, see equation 28) and  $\gamma$  for the four anisotropy models (equation 30, four upper lines).

and from equation (31) for x = 1/c one obtains

$$\eta = \frac{3cg(c)V_{\rm v}^2M(1/c)}{8T(1/c,\beta)}. (34)$$

For different velocity anisotropy models we then have

$$\eta(\beta = 0) = \frac{3(2\ln 2 - 1)}{2(\pi^2 - 7 - 8\ln 2 + 6\ln^2 2)} \approx 2.797,\tag{35}$$

$$\eta(\beta = 0.5) = \frac{9(1 - 2\ln 2)}{4(\pi^2 - 9 - 6\ln 2 + 6\ln^2 2)} \approx 2.138,\tag{36}$$

$$\eta(\beta = 1) = \frac{9(2\ln 2 - 1)}{2(\pi^2 - 3 - 12\ln 2 + 6\ln^2 2)} \approx 1.212,\tag{37}$$

where we have used equations (8) and (24)–(26), and the fact that  $\text{Li}_2(-1) = -\pi^2/12$ . Note that  $\eta$  is independent of c in all cases with  $\beta = \text{const.}$  For the Osipkov–Merritt model  $\eta$  is no longer a constant but we find  $1.902 < \eta < 2.797$  in the range 1 < c < 100 with the limiting cases of  $\eta \to \eta(\beta = 1)$  for  $c \to 0$  and  $\eta \to \eta(\beta = 0)$  for  $c \to \infty$ . Such limiting behaviour is due to the fact that for large c the integration of  $T(1/c,\beta)$ , equation (23), probes only the range of c where c is close to zero, while for small c the integral is dominated by the contribution from large c where c is close to unity.

Finally, we consider the structural parameter

$$WUM = \frac{W(s)}{M(s)\Phi(0)}$$
(38)

brought forward by Seidov & Skvirsky (2000) with the motivation of WUM being constant for different self-gravitating objects of simple geometry. Using equations (8), (9) and (21) we find that for the NFW model

$$WUM = \frac{cs(2+cs) - 2(1+cs)\ln(1+cs)}{2(1+cs)[-cs + (1+cs)\ln(1+cs)]}$$
(39)

so the parameter turns out to be a function of  $cs = r/r_s$  only. It grows with s from zero at  $s \to 0$  reaching a maximum value of 0.196 at  $r/r_s = 4.62$  and decreases to zero again as  $s \to \infty$ . The values of this parameter at the virial radius are 0.196, 0.187 and 0.125, respectively, for c = 5, 10 and 100.

#### 2.4 The distribution function

A quantity of great dynamical importance is the distribution function. For a spherical system with an isotropic velocity tensor, the distribution function depends on the phase-space coordinates only through the energy (e.g. Binney & Tremaine 1987), and can be derived through the Eddington (1916) formula (e.g. Binney & Tremaine 1987):

$$f(\mathcal{E}) = \frac{1}{\sqrt{8}\pi^2} \left[ \int_0^{\mathcal{E}} \frac{\mathrm{d}^2 \rho}{\mathrm{d}\Psi^2} \frac{\mathrm{d}\Psi}{\sqrt{\mathcal{E} - \Psi}} + \frac{1}{\mathcal{E}^{1/2}} \left( \frac{\mathrm{d}\rho}{\mathrm{d}\Psi} \right)_{\Psi = 0} \right],\tag{40}$$

where  $\mathcal{E}$  and  $\Psi$  are the conventionally defined relative energy and potential; here  $\mathcal{E} = -E$ , where E is the total energy per unit mass and  $\Psi = -\Phi$ , where  $\Phi$  is given by equation (9).

It is easy to show that, given equations (6) and (9), the second term in brackets in equation (40) is zero. The simplest way to perform the integration of the first term is to introduce dimensionless variables  $\tilde{\Psi} = \Psi/C_1$  and  $\tilde{\rho} = \rho/C_2$ , where  $C_1 = g(c)V_v^2$  and  $C_2 = c^2g(c)M_v/(4\pi r_v^3)$ . Then the integration variable should be changed to s and the limit of integration corresponding

![](_page_5_Figure_18.jpeg)

**Figure 5.** The distribution function for isotropic model (equation 40) for three different values of the concentration parameter.

to  $\mathcal{E}$  found numerically for each  $\mathcal{E}$  by solving the equation  $\Psi(s) = \mathcal{E}$ . Otherwise, with a few per cent accuracy, the integration in equation (40) can be done directly with an approximation  $s_{\rm apx} = -1.75 \ln(\tilde{\Psi}/c)/\tilde{\Psi}$ .

The calculations of the distribution function are usually performed in units such that  $G = M = R_e = 1$  (Binney & Tremaine 1987), where M is the total mass of the system and  $R_e$  is its effective radius. Since in the case of the NFW profile the total mass is infinite, a reasonable choice seems to be to put  $M_v = 1$ . The effective radius is not well defined either but can be approximated as  $r_v/2$  (see the next section). Therefore we choose the units so that  $G = M_v = r_v/2 = 1$  and arrive at the numerical results shown in Fig. 5. This choice of normalization is equivalent to measuring f in units of  $\sqrt{8}M_v/(r_vV_v)^3$  and E in units of  $V_v^2$ .

Fig. 5 proves that the distribution function turns out to be similar to the distribution functions obtained from other density profiles (see e.g. figs 4–12 in Binney & Tremaine 1987), except that the NFW distribution functions do not display the cut-off at nearly unbound energies characteristic of King (1966) models. The results shown in Fig. 5 indicate a proper behaviour of the distribution function (it is nowhere negative). Quantitative comparisons with other models should, however, be made with caution because of the aforementioned problem with normalization. Distribution functions for more realistic velocity dispersion models, like the Osipkov–Merritt model, were recently considered in detail by Widrow (2000).

## 2.5 Projected distributions

Of primary importance for comparisons with observations are the projected distributions. The surface mass density of an object is obtained by integrating the density along the line of sight:

$$\Sigma_{M}(R) = 2 \int_{R}^{\infty} \frac{r \rho(r)}{(r^{2} - R^{2})^{1/2}} dr$$

$$= \frac{c^{2} g(c)}{2\pi} \frac{M_{v}}{r_{v}^{2}} \frac{1 - |c^{2} \tilde{R}^{2} - 1|^{-1/2} C^{-1} [1/(c\tilde{R})]}{(c^{2} \tilde{R}^{2} - 1)}, \tag{41}$$

where

$$C^{-1}(x) = \begin{cases} \cos^{-1}(x) & \text{if } R > r_{s} \\ \cosh^{-1}(x) & \text{if } R < r_{s}, \end{cases}$$
(42)

In the above expressions, R is the projected radius and  $\tilde{R} = R/r_v$ . For the singular case  $R = r_s$ , the  $\tilde{R}$ -dependent expression in equation (41) equals 1/3 and we have  $\Sigma_M(R) = c^2 g(c) M_v/(6\pi r_v^2)$ . An analytical formula equivalent to equation (41) was derived independently by Bartelmann (1996).

The projected mass is then given by

$$M_{\rm p}(R) = 2\pi \int_0^R R \Sigma_M(R) \, \mathrm{d}R = g(c) M_{\rm v} \left[ \frac{C^{-1} [1/(c\tilde{R})]}{|c^2 \tilde{R}^2 - 1|^{1/2}} + \ln \left( \frac{c\tilde{R}}{2} \right) \right], \tag{43}$$

which is logarithmically divergent at large  $\tilde{R}$ .  $C^{-1}(x)$  is again given by equation (42).

Another important projected quantity is the line-of-sight velocity dispersion, which for a spherical non-rotating system, is (Binney & Mamon 1982)

$$\sigma_{\log}^{2}(R) = \frac{2}{\Sigma_{M}(R)} \int_{R}^{\infty} \left( 1 - \beta \frac{R^{2}}{r^{2}} \right) \frac{\rho \sigma_{r}^{2}(r, \beta) r}{\sqrt{r^{2} - R^{2}}} dr, \tag{44}$$

where  $\Sigma_M(R)$  is given by equation (41) and the radial velocity dispersions  $\sigma_r(r, \beta)$  for our four models are given by equations (14)–(16) and (20). For circular orbits,  $\sigma_r = 0$ , and one has

$$\sigma_{\log}^{2}(R) = \frac{1}{\Sigma_{M}(R)} \int_{R}^{\infty} \left(\frac{R}{r}\right)^{2} \frac{\rho V^{2} r}{\sqrt{r^{2} - R^{2}}} dr,$$
(45)

where V is the circular velocity given by equations (10) and (11). The upper panel of Fig. 6 shows the profiles of line-of-sight velocity dispersion (with isotropic orbits), obtained through numerical integration of equation (44) for different concentration parameters. The lower panel of Fig. 6 compares the radial profiles of line-of-sight velocity dispersions obtained for c=10 for different velocity anisotropy models.

For more distant or intrinsically small galaxies, as well as for groups and clusters, spectroscopic observations are often limited to a single large aperture centred on the object. The mean velocity dispersion within an aperture (hereafter, aperture-velocity dispersion) is

$$\sigma_{\rm ap}^2(R) = \frac{S^2(R)}{M_{\rm p}(R)},$$
 (46)

where

$$S^{2}(R) = 2\pi \int_{0}^{R} \Sigma_{M}(P)\sigma_{\log}^{2}(P)P \,dP. \tag{47}$$

In the above expressions R is the radius of the aperture,  $\Sigma_M(P)$  is the surface mass distribution, equation (41), and  $M_p(R)$  is the projected mass given by equation (43).

Inserting the expression for  $\sigma_{los}$  (equation 44) into equation (47), we obtain a double integral, which after inversion of the order of integration is reduced to an easily computable single integral:

$$S^{2}(R) = c^{2}g(c)M_{v} \left\{ \int_{0}^{\infty} \frac{\sigma_{r}^{2}(s,\beta)s}{(1+cs)^{2}} \left(1 - \frac{2\beta}{3}\right) ds + \int_{\tilde{R}}^{\infty} \frac{\sigma_{r}^{2}(s,\beta)(s^{2} - \tilde{R}^{2})^{1/2}}{(1+cs)^{2}} \left[ \frac{\beta(\tilde{R}^{2} + 2s^{2})}{3s^{2}} - 1 \right] ds \right\}, \quad (48)$$

![](_page_6_Figure_20.jpeg)

**Figure 6.** Upper panel: radial dependence of the line-of-sight velocity dispersion for isotropic orbits (equation 44) on the projected radius for three values of the concentration parameter. Lower panel: comparison of the line-of-sight velocity dispersion profiles for four anisotropy models calculated with c=10.

where as before,  $\tilde{R} = R/r_v$ ,  $s = r/r_v$  and  $\sigma_r^2(s,\beta)$  for different  $\beta$  are given by equations (14)–(16) and (20). Analogous expression for circular orbits can be obtained from equation (48) by replacing  $\sigma_r^2$  by  $V^2$ , keeping only the terms proportional to  $\beta$  and dividing by  $(-2\beta)$ .

Fig. 7 displays the radial profiles of aperture-velocity dispersion, computed numerically from equation (48). From the upper panel of the figure we see that in the isotropic case the dependence of the results on the concentration parameter is rather strong and monotonic for a given *R*. The lower panel of the Figure compares the predictions for different velocity anisotropy models.

## 3 COMPARISON WITH OBSERVATIONS

Comparisons of the surface-mass-density with surface-brightness observations are usually performed with the assumption of constant mass-to-light ratio  $\Upsilon={\rm const.}$  This assumption is not likely to be physical, because of the different physics involved in

![](_page_7_Figure_2.jpeg)

Figure 7. Upper panel: radial profiles of the aperture-velocity dispersion in the isotropic model for three concentration parameters. Lower panel: comparison of the aperture-velocity dispersions for four anisotropy models calculated with c=10.

the assemblies of the dark matter and baryonic components of galaxies. In particular, the baryons in elliptical galaxies may well settle at an early epoch, within a radius that is the lower of the radius with virial overdensity  $v \approx 200$  and the radius at which gas can cool to form molecular clouds and later stars. The baryons in ellipticals will then sit today in a region of overdensity  $v \gg 200$  and one then expects Y to rise with r, at least at large radii.

Nevertheless, for simplicity, we check whether the observations of elliptical galaxies are consistent with the idea that stars are distributed within elliptical galaxies according to the NFW density profile, characterized by a virial radius where the mean overdensity is 200. Such a situation may arise if the dark matter were negligible within elliptical galaxies or distributed precisely like the luminous matter. In a forthcoming paper (Mamon & Łokas, in preparation), we will check in more detail whether the observations of elliptical galaxies are compatible or not with NFW density profiles for the mass distribution.

For constant mass-to-light ratio we have  $\Sigma_M(R) = YI(R)$ , where I is the surface brightness. The radial profiles of  $I = \Sigma_M/Y$  and

![](_page_7_Figure_7.jpeg)

**Figure 8.** Radial profiles of the surface mass density given by equation (41) (upper panel) and the projected mass given by equation (43) (lower panel) for three different values of the concentration parameter. Hubble–Reynolds fits from equation (49) are shown as thin curves  $(R_{\rm HR}/r_{\rm v}=0.119,\,0.0640$  and 0.00743 for  $c=5,\,10$  and 100, respectively). For c=100, the NFW surface mass density is virtually indistinguishable from the best-fitting Hubble–Reynolds law.

 $M_{\rm p}$  are shown in Fig. 8. Both quantities are normalized to their values at the virial radius. Fig. 8 shows that the surface mass density depends weakly on the concentration parameter, especially at larger distances from the centre.

Since the surface mass density (equation 41) behaves as  $1/R^2$  at large distances, one may therefore compare it with the Hubble–Reynolds formula (Reynolds 1913), which was the first model used to describe the surface-brightness profiles of elliptical galaxies:

$$I_{\rm HR}(R) = \frac{I_0}{(1 + R/R_{\rm HR})^2}.$$
 (49)

 $R_{\rm HR}$  is the characteristic radius of the distribution, where the surface brightness falls to one-quarter of its central value. The thin curves of Fig. 8 show that the surface mass density of the NFW model (equation 41) is very well fitted by equation (49) and the best-fit values of  $\tilde{R}_{\rm HR} = R_{\rm HR}/r_{\rm v}$  are 0.119, 0.0640 and 0.00743, respectively, for c = 5, 10 and 100.

The surface-brightness profiles of astrophysical objects are often scaled with the effective radius, which we denote  $R_{\rm e}$ , where the projected luminosity is half the total luminosity. Given the divergence of the projected mass, we are forced again to introduce

![](_page_8_Figure_2.jpeg)

**Figure 9.** The dependence of the effective radius, defined in equation (50), on the concentration parameter, with various choices of  $\tilde{R}_{\text{cut}}$ .

a cut-off at some scale  $R_{\rm cut} = \tilde{R}_{\rm cut} r_{\rm v}$ . We then have

$$M_{\rm p}(R_{\rm e}) = M_{\rm p}(R_{\rm cut})/2.$$
 (50)

Fig. 9 shows the effective radius, calculated numerically from equations (43) and (50). For  $\tilde{R}_{\text{cut}} = 1$ , a useful approximation, good to better than 2 per cent relative accuracy, is:

$$R_{\rm e}/r_{\rm v} = 0.5565 - 0.1941 \log c - 0.0756 \log^2 c + 0.0331 \log^3 c. \tag{51}$$

The prediction for the surface brightness  $I = \Sigma_M/Y$  with  $\Sigma_M$  given by equation (41) expressed in terms of the effective radius and the corresponding effective brightness  $I_e = I(R_e)$  is shown in the upper panel of Fig. 10 for different values of the concentration parameter c. For comparison, we also show the de Vaucouleurs (1948)  $R^{1/4}$  law describing the observed surface-brightness distribution in giant elliptical galaxies:

$$I(R) = I_{e} \exp\{-b[(R/R_{e})^{1/4} - 1]\},$$
(52)

where b = 7.67. Clearly, the NFW surface-brightness profiles are poorly fitted by the  $R^{1/4}$  law, when using  $R_{\rm cut} = r_{\rm v}$  to define the effective radius of the NFW profile.

The lower panel of Fig. 10 shows how the results depend on the choice of cut-off for c=10 and  $\tilde{R}_{\rm cut}=3,3.5,4,4.5$  and 5. At first glance, it seems that the NFW profile is well fitted by the  $R^{1/4}$  law, especially for  $\tilde{R}_{\rm cut}\simeq 4$ . However, the range of surface mass densities where the fit is excellent is roughly  $10^2$  and the fit is adequate for a range smaller than  $10^3$ . In contrast, the surface-brightness profile of the nearby giant elliptical galaxy NGC 3379 (M 105) follows the  $R^{1/4}$  law in a range of 10 mag (de Vaucouleurs & Capaccioli 1979), i.e. a factor  $10^4$  in intensity.

In order to see how good is the de Vaucouleurs's fit in this case, in both panels of Fig. 10 we plotted a number of data points equally spaced in  $R^{1/4}$ . Since de Vaucouleurs & Capaccioli (1979) do not provide the error bars for their data, the error bars shown in the figure were taken from Goudfrooij et al. (1994). The excess of the data above the  $R^{1/4}$  law for small R was already noted by de Vaucouleurs & Capaccioli (1979). The error bars are negligible for  $R < R_e$  and smaller than 15 per cent out to 2.5 $R_e$ , the maximum

distance from the centre reached in the data of Goudfrooij et al. (1994).

According to de Vaucouleurs & Capaccioli (1979), in this galaxy the  $R^{1/4}$  surface-brightness profile extends to  $R_{lim} =$  $7.5R_e = 26.4 \,\mathrm{kpc}$ , given a distance of 12.4 Mpc to NGC 3379 (Salaris & Cassisi 1998). Within  $R_{lim}$ , de Vaucouleurs & Capaccioli (1979) report a blue magnitude, corrected for galactic extinction of B = 10.10, yielding a total blue luminosity of  $2.2 \times$  $10^{10} \, \mathrm{L}_{\odot}$ , hence a blue luminosity density of  $2.8 \times 10^5 \, \mathrm{L}_{\odot} \, \mathrm{kpc}^{-3}$ . Since the mass within  $R_{lim}$  must be greater than the mass in stars, we infer that within this radius,  $Y_B > 8$  (the typical mass-to-blueluminosity ratio for old stellar populations), yielding an overdensity of the galaxy, relative to the critical density  $ho_c$  of v> $1.6 \times 10^4 / (H_0 / 70 \,\mathrm{km \, s^{-1} \, Mpc^{-1}})^2$ . Therefore, since  $v \ge 100$  (the value at  $r_v$ ), we conclude that  $R_{lim} \ll r_v$ , hence  $R_e \ll r_v/7.5$ . In contrast, with  $\tilde{R}_{cut} = 1$ , the effective radius of the NFW model (c=10) is  ${\simeq}0.3r_{\rm v}$  (Fig. 9). This discrepancy in  $R_{\rm e}/r_{\rm v}$  between NFW and  $R^{1/4}$  law gets even worse if one adopts  $\tilde{R}_{\text{cut}} = 4$ , which provides the best fits of the NFW surface mass density to the  $R^{1/4}$ law: indeed, Fig. 9 indicates  $R_e \simeq 0.8r_v$  for the NFW model.

In summary, the NFW surface mass density profile resembles an  $R^{1/4}$  law in a fairly wide range of radii, but (1) one has to resort to an abnormally large effective radius, very close to the virial radius, and assume that the effective radius measures half the projected light (or mass) within 4 times the virial radius, and (2) the fit is good in a considerably smaller range of radii than is observed in the nearby giant elliptical NGC 3379.

The generalization of the  $R^{1/4}$  law into an  $R^{1/m}$  law, first proposed by Sérsic (1968), is known to fit the surface-brightness profiles of elliptical galaxies within a much larger mass range than the de Vaucouleurs law (Caon, Capaccioli & D'Onofrio 1993). The surface brightness of the Sérsic profile is

$$I(R) = I_{e} \exp\{-b(m)[(R/R_{e})^{1/m} - 1]\},$$
(53)

where b(m) is tabulated by Ciotti (1991), who gives the empirical relation  $b(m) \approx 2m - 0.324$ , good to 0.1 per cent relative accuracy. The de Vaucouleurs law is reproduced for m = 4, while m = 1 corresponds to an exponential law as in spiral disc.

In Fig. 11, we plot the NFW surface brightness  $I = \Sigma_M/Y$ , with  $\Sigma_M$  given by equation (41) and c = 10, as a function of  $(R/R_e)^{1/m}$  for various values of the Sérsic parameter m. We compare them to the Sérsic profiles given by the straight dashed lines. The agreement is good for all values of m, within ranges of  $I/I_e$  that increase with increasing m. Comparison of the plots for different m shows that the Sérsic models with lower m generally agree better with the NFW surface brightness for smaller radii, while those with larger m are in better agreement at larger radii, closer to the virial radius. Overall, the NFW profile matches best the m = 3 Sérsic law, over a factor of  $10^3$  in intensity (7.5 mag).

For a more quantitative comparison, we performed two-parameter fits of the Sérsic models (53) to the projected NFW formula (41). The NFW profile was sampled in the range  $0.01 < \tilde{R} < 1$  with a given c. The fitted Sérsic parameters 1/m and  $R_e/r_v$  obtained for different c are shown in Fig. 12. Fig. 13 compares the two projected profiles for c = 10. The best-fit parameters of the Sérsic model in this case are m = 3.07 and  $R_e/r_v = 0.55$ .

While Caon et al. (1993) find similar ranges of agreement between observed profiles and Sérsic laws, this range in intensity is still smaller than the range of 10<sup>4</sup> found for NGC 3379 by de Vaucouleurs & Capaccioli (1979). Moreover, while Caon et al. (1993) find that the best fitting Sérsic models for elliptical

![](_page_9_Figure_2.jpeg)

Figure 10. Upper panel: surface-brightness profiles (equation 41) for three concentration parameters and  $\tilde{R}_{\text{cut}} = 1$ . Lower panel: the dependence of the surface brightness profiles on the cut-off  $\tilde{R}_{\text{cut}}$  for c = 10 and  $\tilde{R}_{\text{cut}} = 3$ , 3.5, 4, 4.5 and 5 (bottom to top curves). In both panels, the  $R^{1/4}$  law (equation 52) is shown as long dashed lines. The vertical lines represent the virial radius (for the three concentration parameters in the upper panel and for the 5 values of  $\tilde{R}_{\text{cut}}$  in the lower panel, with  $\tilde{R}_{\text{cut}}$  increasing from right to left). The circles are the data points for the galaxy NGC 3379.

galaxies have indices spanning a wide range, from m=2 for faint ellipticals to m=10 for bright ellipticals, the Sérsic laws that match the NFW models span a much smaller range, roughly  $m=3\pm0.5$  (2.71 < m < 3.41 for 5 < c < 15, see Fig. 12). Moreover, the problem of very high values of  $R_{\rm e}/r_{\rm v}$  (0.46  $< R_{\rm e}/r_{\rm v} < 0.81$  for 5 < c < 15, see Fig. 12), remains in the fits of Sérsic profiles to projected NFW models.

## 4 DISCUSSION

The main disadvantage of the NFW model is the logarithmic divergence of its mass (and luminosity for constant mass-to-light

ratio). In contrast, the Jaffe (1983) and Hernquist (1990) models converge in mass, and their properties can be expressed in units of their asymptotic mass. For the NFW model, one is restricted to a mass at a physical radius such as the virial radius. This mass divergence also complicates the analysis of surface-brightness profiles, which involve the effective radius where the aperture luminosity is half its asymptotic value. However, independently of the radial cut-off introduced to define the effective radius, the projected NFW density profile is consistent with constant mass-to-light ratio, given the observed Sérsic profiles of elliptical galaxies, but only in a limited range of radii, with unusually high values of  $R_{\rm e}$  and in a smaller interval of Sérsic shape parameters than observed. On the other hand, the Hernquist (1990) model, whose

![](_page_10_Figure_2.jpeg)

Figure 11. Comparisons of c=10 projected NFW models (using equation 41) to Sérsic models (equation 41). The curves represent the NFW models (for equally spaced values of  $\tilde{R}_{\text{cut}}$  within the interval indicated in each plot, with  $\tilde{R}_{\text{cut}}$  increasing upwards on the left portion of each plot). The Sérsic law is shown as long dashed lines. The vertical lines represent the virial radius (with  $\tilde{R}_{\text{cut}}$  increasing from right to left).

![](_page_10_Figure_4.jpeg)

**Figure 12.** The best fitting parameters of the Sérsic law, equation (53), as functions of concentration: 1/m (dashed line) and  $R_c/r_v$  (solid line).

density profile scales as  $r^{-4}$  at large radii, produces better fits to the  $R^{1/4}$  law.

The upper panel of Fig. 10 suggests that, for reasonable effective radii, if indeed dark matter follows the NFW profile, the mass-to-light ratio, Y, is not constant but increases with radius, not only in the outer regions, as is inferred from the commonly

accepted picture of galaxies embedded in more spatially extended dark haloes, but also in the inner regions. This is at odds with the observed kinematics of ellipticals that Bertola et al. (1993) inferred from observations of ionized and neutral gas around specific ellipticals. Moreover, increasing Y throughout the galaxy implies radial velocity anisotropy throughout elliptical galaxies, whereas violent relaxation should cause isotropic cores. Thus it appears difficult to reconcile the photometry and kinematics of elliptical galaxies with NFW models. In a forthcoming paper (Mamon & Łokas, in preparation), we will omit the assumption of mass follows light in a more detailed assessment of the compatibility of the observations of elliptical galaxies with the NFW model.

The results presented in this paper can be directly applied to the analysis of the mass and light distribution in clusters of galaxies. A standard procedure to do it is to measure the surface brightness and the line-of-sight velocity dispersion and assuming some form of velocity distribution or mass-to-light ratio calculate the luminosity density and the velocity dispersion by solving the Abel integral equations (41) and (44) and the Jeans equation (Binney & Mamon 1982; Tonry 1983; Solanes & Salvador-Solé 1990; Dejonghe & Merritt 1992). The results of this procedure are

<sup>1</sup> Note that recent state-of-the-art observations and modelling by Saglia et al. (2000) and Gebhardt et al. (2000) do not strongly constrain the gravitational potentials of elliptical galaxies, although NFW potentials may turn out to be inconsistent with the current data. On the other hand, Kronawitter et al. (2000) are able to rule out constant Y for some elliptical galaxies.

![](_page_11_Figure_2.jpeg)

Figure 13. Comparison of the projected NFW density profile, equation (41), and the best fitting SeÂrsic law, equation (53).

uncertain because it involves derivatives of observed quantities that are usually noisy. One also experiences a degeneracy because different models fit the data equally well (Merritt 1987). Instead of solving the Abel equations one can also model the luminosity density and velocity dispersion with simple functions and fit their parameters so that they reproduce their projected counterparts (Carlberg et al. 1997).

Our results are useful for the simpler approach of assuming realistic forms of the density distribution, velocity distribution and mass-to-light ratio. Here we provide the tools for modelling the NFW density profile with different velocity distributions and constant mass-to-light ratio Y const; and obtain exact predictions for the surface-brightness and the line-of-sight as well as aperture-velocity dispersion that can be directly compared with observations.

## ACKNOWLEDGMENTS

We thank Daniel Gerbal and Bernard Fort for useful conversations, and an anonymous referee for helpful comments. ELè acknowledges hospitality of Institut d'Astrophysique de Paris, where part of this work was done. This research was partially supported by Polish State Committee for Scientific Research Grant Nos 2P03D00813 and 2P03D02319 as well as the Jumelage program Astronomie France Pologne of CNRS/PAN.

# REFERENCES

Adami C., Mazure A., Katgert P., Biviano A., 1998, A&A, 336, 63 Avila-Reese V., Firmani C., Hernandez X., 1998, ApJ, 505, 37

Avila-Reese V., Firmani C., Klypin A., Kravtsov A. V., 1999, MNRAS, 310, 527

Bartelmann M., 1996, A&A, 313, 697

Bertola F., Pizzella A., Persic M., Salucci P., 1993, ApJ, 416, L45 Bertschinger E., 1985, ApJS, 58, 39

Binney J., Mamon G. A., 1982, MNRAS, 200, 361

Binney J., Tremaine S., 1987, Galactic Dynamics. Princeton Univ. Press, Princeton, chap. 4.4.3

Bullock J. S., Kolatt T. S., Sigad Y., Somerville R. S., Kravtsov A. V., Klypin A. A., Primack J. R., Dekel A., 1999, MNRAS, in press (astroph/9908159)

Caon N., Capaccioli M., D'Onofrio M., 1993, MNRAS, 265, 1013

Carlberg R. G. et al., 1997, ApJ, 485, L13

Ciotti L., 1991, A&A, 249, 99

Cole S., Lacey C., 1996, MNRAS, 281, 716

Dejonghe H., Merritt D., 1992, ApJ, 391, 531

de Vaucouleurs G., 1948, Ann. Ap., 11, 247

de Vaucouleurs G., Capaccioli M., 1979, ApJS, 40, 699

Eddington A. S., 1916, MNRAS, 76, 572

Eke V. R., Cole S., Frenk C. S., 1996, MNRAS, 282, 263

Fillmore J. A., Goldreich P., 1984, 281, 1

Flores R. A., Primack J. R., 1994, ApJ, 427, L1

Fukushige T., Makino J., 1997, ApJ, 477, L9

Gebhardt K., et al., 2000, AJ, 119, 1157

Ghigna S., Moore B., Governato F., Lake G., Quinn T., Stadel J., 1999, ApJ, in press (astro-ph/9910166)

Gott J. R., 1975, ApJ, 201, 296

Goudfrooij P., Hansen L., Jùrgensen H. E., Nùrgaard-Nielsen H. U., de Jong T., van den Hoek L. B., 1994, A&AS, 104, 179

Gunn J. E., 1977, ApJ, 218, 592

Gunn J. E., Gott J. R., 1972, ApJ, 176, 1

Hernquist L., 1990, ApJ, 356, 359

Hoffman Y., Shaham J., 1985, ApJ, 297, 16

Huss A., Jain B., Steinmetz M., 1999a, MNRAS, 308, 1011

Huss A., Jain B., Steinmetz M., 1999b, ApJ, 517, 64

Jaffe W., 1983, MNRAS, 202, 995

Jing Y. P., 2000, ApJ, 535, 30

Jing Y. P., Suto Y., 2000, ApJ, 529, L69

King I. R., 1966, AJ, 71, 64

Kravtsov A. V., Klypin A. A., Bullock J. S., Primack J. R., 1998, ApJ, 502, 48

Kronawitter A., Saglia R. P., Gerhard O., Bender R., 2000, A&AS, 144, 53

Lacey C., Cole S., 1993, MNRAS, 262, 627

èokas E. L., 2000, MNRAS, 311, 423

èokas E. L., Hoffman Y., 2000, ApJ, 542, L139 Mamon G. A., 2000, in Combes F., Mamon G. A., Charmandaris V., eds, ASP Conf. Ser. Vol. 197, Proc. XVth IAP Meeting, Dynamics of Galaxies: From the Early Universe to the Present. Astron. Soc. Pac., San Francisco, p. 377

Merritt D., 1985, AJ, 90, 1027

Merritt D., 1987, ApJ, 313, 121

Moore B., Governato F., Quinn T., Stadel J., Lake G., 1998, ApJ, 499, L5 Navarro J. F., Frenk C. S., White S. D. M., 1995, MNRAS, 275, 720 (NFW1)

Navarro J. F., Frenk C. S., White S. D. M., 1996, ApJ, 462, 563 (NFW2)

Navarro J. F., Frenk C. S., White S. D. M., 1997, ApJ, 490, 493 (NFW3)

Osipkov L. P., 1979, PAZh, 5, 77

Reynolds J. H., 1913, MNRAS, 74, 132

Richstone D. O., Tremaine S., 1984, ApJ, 286, 27

Saglia R. P., Kronawitter A., Gerhard O., Bender R., 2000, AJ, 119, 153

Salaris M., Cassisi S., 1998, MNRAS, 298, 166

Salvador-SoleÂ E., Solanes J. M., Manrique A., 1998, ApJ, 499, 542

Seidov Z. F., Skvirsky P. I., 2000, preprint (astro-ph/0003064)

SeÂrsic J. L., 1968, Atlas de Galaxies Australes. Observatorio Astronomico, Cordoba

Solanes J. M., Salvador-SoleÂ E., 1990, A&A, 234, 93

Spitzer L., 1969, ApJ, 158, L139

Swaters R. A., Madore B. F., Trewhella M., 2000, ApJ, 531, L107

Thomas P. A. et al., 1998, MNRAS, 296, 1061

Tonry J. L., 1983, ApJ, 266, 58

Tormen G., Bouchet F. R., White S. D. M., 1997, MNRAS, 286, 865

van den Bosch F. C., Swaters R. A., 2000, AJ, submitted (astro-ph/0006048) van den Bosch F. C., Robertson B. E., Dalcanton J. J., de Blok W. J. G., 2000, AJ, 119, 1579

van der Marel R. P., Magorrian J., Carlberg R. G., Yee H. K. C., Ellingson E., 2000, AJ, 119, 2038

Widrow L. M., 2000, ApJ, submitted (astro-ph/0003302)

This paper has been typeset from a TEX/LATEX file prepared by the author.