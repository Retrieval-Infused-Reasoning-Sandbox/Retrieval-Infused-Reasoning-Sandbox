# New constructions of optimal linear codes from simplicial complexes

Zhao Hu, Yunge Xu, Nian Li, Xiangyong Zeng, Lisha Wang and Xiaohu Tang

#### **Abstract**

In this paper, we construct a large family of projective linear codes over  $\mathbb{F}_q$  from the general simplicial complexes of  $\mathbb{F}_q^m$  via the defining-set construction, which generalizes the results of [IEEE Trans. Inf. Theory 66(11):6762-6773, 2020]. The parameters and weight distribution of this class of codes are completely determined. By using the Griesmer bound, we give a necessary and sufficient condition such that the codes are Griesmer codes and a sufficient condition such that the codes are distance-optimal. For a special case, we also present a necessary and sufficient condition for the codes to be near Griesmer codes. Moreover, by discussing the cases of simplicial complexes with one, two and three maximal elements respectively, the parameters and weight distributions of the codes are given more explicitly, which shows that the codes are at most 2-weight, 5-weight and 19-weight respectively. By studying the optimality of the codes for the three cases in detail, many infinite families of optimal linear codes with few weights over  $\mathbb{F}_q$  are obtained, including Griesmer codes, near Griesmer codes and distance-optimal codes.

#### **Index Terms**

Optimal linear code, Simplicial complex, Griesmer code, Near Griesmer code, Weight distribution

#### I. Introduction

Let  $\mathbb{F}_{q^m}$  be the finite field with  $q^m$  elements and  $\mathbb{F}_{q^m}^* = \mathbb{F}_{q^m} \setminus \{0\}$ , where q is a power of a prime p and m is a positive integer. An [n,k,d] linear code C over  $\mathbb{F}_q$  is a k-dimensional subspace of  $\mathbb{F}_q^n$  with minimum (Hamming) distance d. An [n,k,d] linear code C over  $\mathbb{F}_q$  is called distance-optimal if no [n,k,d+1] code exists (i.e., C has the largest minimum distance for given n and k) and it is called almost distance-optimal if there exists an [n,k,d+1] distance-optimal code. An [n,k,d] linear code C is called optimal (resp. almost optimal) if its parameters n, k and d (resp. d+1) meet any bound on linear codes with equality [24]. The Griesmer bound [18], [40] for an [n,k,d] linear code C over  $\mathbb{F}_q$  is given by

$$n \ge g(k,d) := \sum_{i=0}^{k-1} \lceil \frac{d}{q^i} \rceil,$$

where  $\lceil \cdot \rceil$  denotes the ceiling function. An [n,k,d] linear code  $\mathcal C$  is called a Griesmer code (resp. near Griesmer code) if its parameters n (resp. n-1), k and d achieve the Griesmer bound. Griesmer codes have been an interesting topic of study for many years due to not only their optimality but also their geometric applications [7], [8]. It's worth noting that Griesmer codes are always distance-optimal, and an [n,k,d] near Griesmer code over  $\mathbb F_q$  with k>1 is distance-optimal if  $q\mid d$  and almost distance-optimal otherwise [22]. In coding theory, it's a fundamental problem to construct (distance-)optimal codes. We refer the readers to [20]–[22], [25]–[27], [30], [32], [45], [46] and references therein for recent works on the construction of optimal linear codes.

Let  $A_i$  denote the number of codewords with Hamming weight i in a code C of length n. The weight enumerator of C is defined by  $1 + A_1z + A_2z^2 + ... + A_nz^n$ . The sequence  $(1, A_1, A_2, ..., A_n)$  is called the

Z. Hu, Y. Xu, X. Zeng and X. Tang are with the Hubei Key Laboratory of Applied Mathematics, Faculty of Mathematics and Statistics, Hubei University, Wuhan, 430062, China. N. Li and L. Wang are with the Hubei Key Laboratory of Applied Mathematics, School of Cyber Science and Technology, Hubei University, Wuhan, 430062, China. X. Tang is also with the Information Coding & Transmission Key Lab of Sichuan Province, CSNMT Int. Coop. Res. Centre (MoST), Southwest Jiaotong University, Chengdu, 610031, China. Email: zhao.hu@aliyun.com, xuy@hubu.edu.cn, nian.li@hubu.edu.cn, xiangyongzeng@aliyun.com, wangtaolisha@163.com, xhutang@swjtu.edu.cn

weight distribution of C. The weight distribution not only contains crucial information about the error correcting capability of the code, but also allows the computation of the error probability of error detection and correction of a given code [28]. A code is said to be a t-weight code if the number of nonzero  $A_i$  in the sequence  $(A_1, A_2, \ldots, A_n)$  is equal to t. Linear codes with few weights have applications in secret sharing schemes [2], [5], authentication codes [13], [16], association schemes [4], strongly regular graphs and some other fields. Thus the study of weight distribution and the construction of linear codes with few weights have attracted much attention in coding theory, and some nice works have focused on the topics (see, for example, [10], [12], [14], [34]–[37], [41], [50]).

Recently, constructing optimal or good linear codes from mathematical objects attracts much attention and many attempts have been made in this direction. Some linear codes with good parameters have been constructed by using different mathematical objects such as cryptographic functions [9], [10], [12], [23], [37], [41], [42], [50], combinatorial t-designs [10], [15], (almost) difference sets [7], [21], [49], simplicial complexes (also called down-sets) [6], [25], [27], [45], [46], posets [26] and maximal arcs [20]. In these various kinds of mathematical objects, simplicial complexes (which are certain subsets of  $\mathbb{F}_q^m$  with good algebraic structure) are really useful to construct optimal or good linear codes. The investigation of constructing linear codes from simplicial complexes, to the best of our knowledge, first appeared in [6] (in 2018), where the authors Chang and Hyun [6] constructed the first infinite family of binary minimal linear codes violating the Ashikhmin-Barg condition [3] by employing simplicial complexes of  $\mathbb{F}_2^m$  with two maximal elements. In 2020, Hyun et al. [27] constructed infinite families of optimal binary linear codes from the general simplicial complexes of  $\mathbb{F}_2^m$  via the defining-set approach proposed by Ding and Niederreiter [14]. Later, by using simplicial complexes of  $\mathbb{F}_2^m$  with one maximal element, several classes of optimal or good binary linear codes with few weights were derived in [29], [44], [46] via different construction approaches. Shortly after, simplicial complexes of  $\mathbb{F}_2^m$  with one and two maximal elements were utilized to construct quaternary optimal linear codes in [45], [51] by studying new defining sets of  $\mathbb{F}_4^m$ . Recently, some researchers also concentrated on linear codes constructed from simplicial complexes of  $\mathbb{F}_q^m$  with q>2. Hyun et al. [25] first defined the simplicial complexes of  $\mathbb{F}_p^m$  for an odd prime p in 2019, and after that several classes of optimal p-ary few-weight linear codes were constructed in [25], [39], [43] by using different simplicial complexes of  $\mathbb{F}_p^m$  with one maximal element. Later, Pan and Liu [38] defined the simplicial complexes of  $\mathbb{F}_3^m$  in another way and presented three classes of few-weight ternary codes with good parameters from their defined simplicial complexes of  $\mathbb{F}_3^m$  with one and two maximal elements.

As can be seen from the previous works, there are only few known results on constructing optimal linear codes over  $\mathbb{F}_q$  by making use of simplicial complexes of  $\mathbb{F}_q^m$  with q>2 and actually no result associated with the general simplicial complexes of  $\mathbb{F}_q^m$  except the results in [27] for the case q=2, where "general" means that there is no restriction on the number of maximal elements of the employed simplicial complexes. Moreover, it's worth noting that in [27] the weight distributions of the binary linear codes constructed from the general simplicial complexes of  $\mathbb{F}_2^m$  were discussed only for the case of simplicial complexes with two maximal elements. Naturally, one has the following interesting question:

Question: Can we obtain more infinite families of optimal linear codes over  $\mathbb{F}_q$  from the general simplicial complexes of  $\mathbb{F}_q^m$  for any prime power q and determine their weight distributions?

The question above is the major motivation of this paper. In this paper, we first define the simplicial complexes of  $\mathbb{F}_q^m$  for any prime power q (see the details in next section) in a different way from the definitions given by [25], [38] for a prime p and q=3 resepctively. Then we employ the general simplicial complexes of  $\mathbb{F}_q^m$  to construct projective linear codes  $\mathcal{C}$  over  $\mathbb{F}_q$  via the defining-set construction. With detailed computation on certain exponential sums and by using the principle of inclusion-exclusion, we completely determine the parameters and weight distribution of  $\mathcal{C}$ . We give a necessary and sufficient condition such that  $\mathcal{C}$  is a Griesmer code, which is indeed the Solomon-Stiffler code, and provide an explicit computable criterion for  $\mathcal{C}$  to be distance-optimal, which can be easily satisfied (see Remark 1). In addition, for a special case of the general simplicial complexes of  $\mathbb{F}_q^m$ , we give a necessary and sufficient condition such that  $\mathcal{C}$  is a near Griesmer code. This shows that many (distance-)optimal codes

can be produced from this construction. Moreover, for the three cases of simplicial complexes of  $\mathbb{F}_q^m$  with one, two and three maximal elements respectively, we give their parameters and weight distributions more explicitly and show that  $\mathcal{C}$  is at most 2-weight, 5-weight and 19-weight, respectively. In these three cases, infinite families of optimal linear codes with few weights are produced, including Griesmer codes, near Griesmer codes and distance-optimal codes.

Note that our results extend those of [27] from  $\mathbb{F}_2$  to  $\mathbb{F}_q$ , and thus it answers the second question in [22]. Most notably, the main technique of this paper is quite different from that of all previous works on construction of linear codes from simplicial complexes (including the work [27]), where the main technique used in the previous works is the so-called generating functions. Furthermore, it's worth noting that by the definition of simplicial complexes of  $\mathbb{F}_q^m$  and the main technique of this paper, the results in the previous works [6], [29], [44]–[46], [51], where the simplicial complexes of  $\mathbb{F}_2^m$  with one or two maximal elements were employed, can also be generalized to a general q.

The rest of this paper is organized as follows. Section II introduces the concept of the simplicial complexes of  $\mathbb{F}_q^m$ , recalls the defining-set construction of linear codes and the projective Solomon-Stiffler codes, and presents some useful auxiliary results. In Section III, we investigate the projective linear codes constructed from the general simplicial complexes of  $\mathbb{F}_q^m$ . Their parameters and weight distributions are completely determined and the optimality of these codes is characterized. Furthermore, in Section IV, we deeply discuss these codes for the cases of the simplicial complexes of  $\mathbb{F}_q^m$  with one, two and three maximal elements respectively, and consequently many infinite families of optimal linear codes with few weights can be obtained. Section V makes a comparison of our codes to the known ones in the previous works. Section VI concludes this paper.

#### II. PRELIMINARIES

<span id="page-2-0"></span>In this section, we present some preliminaries which will be used for the subsequent sections.

Here we first recall the relation between the finite field  $\mathbb{F}_{q^m}$  and the vector space  $\mathbb{F}_q^m$ . Let  $\{\alpha_1, \ldots, \alpha_m\}$  be a basis of  $\mathbb{F}_{q^m}$  over  $\mathbb{F}_q$  and  $\{\beta_1, \ldots, \beta_m\}$  be its dual basis, which implies

$$\operatorname{Tr}_q^{q^m}(\alpha_i\beta_j) = \begin{cases} 0, & \text{if } i \neq j; \\ 1, & \text{if } i = j, \end{cases}$$

where  $\operatorname{Tr}_q^{q^m}(\cdot)$  is the trace function from  $\mathbb{F}_{q^m}$  to  $\mathbb{F}_q$ . Then every element  $x \in \mathbb{F}_{q^m}$  can be uniquely represented as  $x = \sum_{i=1}^m x_i \alpha_i$  where  $x_i = \operatorname{Tr}_q^{q^m}(\beta_i x) \in \mathbb{F}_q$ , and  $\mathbb{F}_q^m$  is isomorphic to  $\mathbb{F}_{q^m}$  under the mapping

$$(x_1, x_2, \dots, x_m) \in \mathbb{F}_q^m \mapsto x = \sum_{i=1}^m x_i \alpha_i \in \mathbb{F}_{q^m}.$$

Throughout this paper, we identify  $x \in \mathbb{F}_{q^m}$  with  $(x_1, x_2, \dots, x_m) \in \mathbb{F}_q^m$  with respect to the basis  $\{\alpha_1, \dots, \alpha_m\}$  and hence  $\mathbb{F}_{q^m}$  is identical to  $\mathbb{F}_q^m$ .

## A. Simplicial Complexes of $\mathbb{F}_q^m$

Here we introduce the concept of simplicial complexes of  $\mathbb{F}_q^m$ , where q can be any prime power. For two vectors  $u=(u_1,u_2,\ldots,u_m)$  and  $v=(v_1,v_2,\ldots,v_m)$  in  $\mathbb{F}_q^m$ , we say that u covers v, denoted  $v \leq u$ , if  $\mathrm{Supp}(v) \subseteq \mathrm{Supp}(u)$ , where  $\mathrm{Supp}(u) = \{1 \leq i \leq m : u_i \neq 0\}$  is the support of u. A subset  $\Delta$  of  $\mathbb{F}_q^m$  is called a simplicial complex if  $u \in \Delta$  and  $v \leq u$  imply  $v \in \Delta$ . An element u in  $\Delta$  with entries 0 or 1 is said to be maximal if there is no element  $v \in \Delta$  such that  $\mathrm{Supp}(u)$  is a proper subset of  $\mathrm{Supp}(v)$ . For a simplicial complex  $\Delta \subseteq \mathbb{F}_q^m$ , let  $\mathcal{F} = \{F_1, F_2, \ldots, F_h\}$  be the set of maximal elements of  $\Delta$ , where h is the number of maximal elements in  $\Delta$  and  $F_i$ 's are maximal elements of  $\Delta$ . Let  $A_i = \mathrm{Supp}(F_i)$  for  $1 \leq i \leq h$ , which implies  $A_i \subseteq [m] := \{1, 2, \ldots, m\}$ . Note that  $A_i \setminus A_j \neq \emptyset$  for any  $1 \leq i \neq j \leq h$  by the definition. Let  $\mathcal{A} = \{A_1, A_2, \ldots, A_h\}$  be the set of supports of maximal elements of  $\Delta$ , and  $\mathcal{A}$  be called the support of  $\Delta$ , denoted  $\mathrm{Supp}(\Delta) = \mathcal{A}$ . Then one can see that a simplicial complex  $\Delta$  is uniquely generated by  $\mathcal{A}$ , denoted

 $\Delta = \langle \mathcal{A} \rangle$ . Notice that both the set of maximal elements  $\mathcal{F}$  and the support  $\mathcal{A}$  of  $\Delta$  are unique for a fixed simplicial complex  $\Delta$ . For any set  $\mathcal{B}$  consisting of some subsets of [m], we say that a simplicial complex  $\Delta$  of  $\mathbb{F}_q^m$  is generated by  $\mathcal{B}$ , denoted  $\Delta = \langle \mathcal{B} \rangle$ , if  $\Delta$  is the smallest simplicial complex of  $\mathbb{F}_q^m$  containing every element in  $\mathbb{F}_q^m$  with the support  $B \in \mathcal{B}$ .

Notice that the above definition of simplicial complexes of  $\mathbb{F}_q^m$  is a generalization of the original definition of simplicial complexes of  $\mathbb{F}_2^m$  [1], [27], and it is different from the two definitions presented in [25] for  $\mathbb{F}_p^m$  and in [38] for  $\mathbb{F}_3^m$ .

From another point of view, one can observe that the simplicial complex  $\Delta$  with the support  $\mathcal{A} = \{A_1, A_2, \ldots, A_h\}$  is indeed the union of h vector subspaces of dimensions  $|A_i|$  of the vector space  $\mathbb{F}_q^m$ , where |S| denotes the cardinality of a set S. Specially,  $\Delta = \langle \{A\} \rangle$  with exactly one maximal element is an |A|-dimensional subspace of  $\mathbb{F}_q^m$ , where  $A \subseteq [m]$  is the support of the maximal element.

#### B. The Defining-Set Construction of Linear Codes

In 2007, Ding and Niederreiter [14] introduced a nice and generic way to construct linear codes via trace functions. Let  $D \subset \mathbb{F}_{q^m}$  and define

<span id="page-3-0"></span>
$$C_D = \{c_a = (\operatorname{Tr}_q^{q^m}(ax))_{x \in D} : a \in \mathbb{F}_{q^m}\}.$$
(1)

Then  $C_D$  is a linear code over  $\mathbb{F}_q$  of length n := |D|. The set D is called the defining set of  $C_D$  and the above construction is accordingly called the defining-set construction. The defining-set construction is fundamental since every linear code over  $\mathbb{F}_q$  can be expressed as  $C_D$  for some defining set D (possibly multiset) [11]. If the defining set D is well chosen, then  $C_D$  may have optimal or good parameters. Recently, the defining-set construction of linear codes has attracted a lot of attention and many attempts have been made in this direction to obtain good or optimal linear codes.

It's known that  $C_D$  in (1) is equivalent to

$$C_{\mathbf{D}} = \{c_{\mathbf{a}} = (\mathbf{a} \cdot \mathbf{x})_{\mathbf{x} \in \mathbf{D}} : \mathbf{a} \in \mathbb{F}_q^m\},\$$

where  $\mathbf{D} \subseteq \mathbb{F}_q^m$  is identical to  $D \subseteq \mathbb{F}_{q^m}$  with respect to a basis of  $\mathbb{F}_{q^m}$  over  $\mathbb{F}_q$ , see its detailed proof for the binary case in [33]. Let  $\mathbf{D} = \{\mathbf{d}_1, \mathbf{d}_2, \dots, \mathbf{d}_n\} \subseteq \mathbb{F}_q^m$  and G be an  $m \times n$  matrix with  $\mathbf{d}_i$ 's as its columns, i.e.,

$$G=[\mathbf{d}_1,\mathbf{d}_2,\ldots,\mathbf{d}_n].$$

Then the rows of G generate the linear code  $C_D = C_D$  [47], and G is the generator matrix of  $C_D$  if the rank of G is m. This gives the generator matrix of  $C_D$ .

#### C. The Projective Solomon-Stiffler Codes

The dual code of an [n,k,d] linear code  $\mathcal{C}$  over  $\mathbb{F}_q$  is defined by  $\mathcal{C}^\perp = \{x \in \mathbb{F}_q^n \mid x \cdot y = 0 \text{ for all } y \in \mathcal{C}\}$ , where  $x \cdot y$  denotes the Euclidean inner product of x and y. A linear code  $\mathcal{C}$  is called projective if its dual code has minimum distance at least 3. Thus the dual of a projective code has better error correcting capability compared to that of a nonprojective code. By definition, it can be readily verified that the code  $\mathcal{C}_D$  defined by (1) is projective if and only if any two elements of D are linearly independent over  $\mathbb{F}_q$ .

Here we recall the concept of projective space to introduce the projective Solomon-Stiffler code smoothly. The projective space (also called projective geometry) PG(m-1,q) is the set of all the 1-dimensional subspaces (called points) of the vector space  $\mathbb{F}_q^m$ . Let  $m \geq 2$ . A point of PG(m-1,q) is given in homogeneous coordinates by  $\mathbf{x} = (x_0, x_1, \dots, x_{m-1}) \in \mathbb{F}_q^m$  where all  $x_i$ 's are not all zero (which implies  $\mathbf{0} \notin PG(m-1,q)$ ); each point has q-1 coordinate representations, since  $\mathbf{x}$  and  $\lambda \mathbf{x}$  yield the same 1-dimensional subspace of  $\mathbb{F}_q^m$  for any  $\lambda \in \mathbb{F}_q^*$ . Thus any two points of PG(m-1,q) are linearly independent over  $\mathbb{F}_q$ . Note that  $\mathbb{F}_{q^m}^*$  can be expressed as

$$\mathbb{F}_{q^m}^* = \mathbb{F}_q^* \overline{\mathbb{F}_{q^m}^*} = \{yz : y \in \mathbb{F}_q^* \text{ and } z \in \overline{\mathbb{F}_{q^m}^*}\}$$

where  $z_i/z_j \notin \mathbb{F}_q^*$  for each pair of distinct elements  $z_i$  and  $z_j$  in  $\overline{\mathbb{F}_{q^m}^*}$ . This defines the set  $\overline{\mathbb{F}_{q^m}^*}$ . Then the set of all points in PG(m-1,q) can be identified with the set  $\overline{\mathbb{F}_{q^m}^*}$  since  $\mathbb{F}_q^m$  is identical to  $\mathbb{F}_{q^m}$ . Therefore, the code  $C_D$  defined by (1) is projective if  $D \subseteq PG(m-1,q)$ . In addition, it should be noted that the projective dimension of a projective subspace in PG(m-1,q) is one less than that of the corresponding subspace in the vector space  $\mathbb{F}_q^m$ .

The well-known Solomon-Stiffler codes [40] are not only projective codes but also Griesmer codes. The Solomon-Stiffler codes are originally defined as follows: Let  $S_{m,q}$  be the set of all distinct points in PG(m-1,q) and  $F = \bigcup_{i=1}^h U_i$  be a union of h disjoint projective subspaces of dimensions  $u_i - 1$ , where  $1 \le u_1 \le u_2 \le \cdots \le u_h < m$  and at most q-1 of the subspaces  $U_i$  have the same dimension. Then the matrix  $G = [S_{m,q} \setminus F]$  whose columns correspond to all points in  $S_{m,q} \setminus F$  generates a  $[(q^m - 1 - \sum_{i=1}^h (q^{u_i} - 1))/(q - 1), m, q^{m-1} - \sum_{i=1}^h q^{u_i-1}]$  Griesmer code, called the Solomon-Stiffler code over  $\mathbb{F}_q$ . By the definition, one can notice that the Solomon-Stiffler code can also be constructed by the defining-set construction as in (1) if D is the set of  $S_{m,q} \setminus F$ , that is,  $D = PG(m-1,q) \setminus F$ . In addition, it's interesting that the matrix  $[S_{m,q}]$  generates the well-known Simplex code with parameters  $[(q^m-1)/(q-1), m, q^{m-1}]$ , which is also a projective Griesmer code.

To the best of our knowledge, the weight distribution of the Solomon-Stiffler codes still remains unknown. We will partially answer this interesting question in this paper.

#### D. Useful Auxiliary Results

Let q be a power of a prime p and denote the canonical additive character of  $\mathbb{F}_q$  by

$$\chi(x) = \zeta_p^{\operatorname{Tr}_p^q(x)},$$

where  $\zeta_p$  is a primitive complex p-th root of unity and  $\operatorname{Tr}_p^q(\cdot)$  is the trace function from  $\mathbb{F}_q$  to  $\mathbb{F}_p$ . For an r-dimensional  $\mathbb{F}_q$ -subspace H of  $\mathbb{F}_{q^m}$ , the dual of H is defined by

$$H^{\perp} = \{ v \in \mathbb{F}_{q^m} : \operatorname{Tr}_q^{q^m}(uv) = 0 \text{ for all } u \in H \}.$$

The dual  $H^{\perp}$  is an (m-r)-dimensional  $\mathbb{F}_q$ -subspace of  $\mathbb{F}_{q^m}$ . Recall that  $\{\alpha_1,\ldots,\alpha_m\}$  is a basis of  $\mathbb{F}_{q^m}$  over  $\mathbb{F}_q$  and  $\{\beta_1,\ldots,\beta_m\}$  is its dual basis. If H is an r-dimensional  $\mathbb{F}_q$ -subspace of  $\mathbb{F}_{q^m}$  spanned by the set  $\{\alpha_{i_1},\ldots,\alpha_{i_r}\}$ , denoted  $H=\operatorname{span}\{\alpha_{i_1},\ldots,\alpha_{i_r}\}$ , then  $H^{\perp}=\operatorname{span}\{\beta_i:i\in[m]\setminus\{i_1,\ldots,i_r\}\}$ .

The following lemma regarding the exponential sum on the subspace H of  $\mathbb{F}_{q^m}$  will be helpful to prove our main result.

<span id="page-4-0"></span>**Lemma 1.** ([48]) Let H be an r-dimensional  $\mathbb{F}_q$ -subspace of  $\mathbb{F}_{q^m}$ . Then for  $y \in \mathbb{F}_{q^m}$  we have

$$\sum_{x \in H} \zeta_p^{\operatorname{Tr}_p^{q^m}(yx)} = \left\{ \begin{array}{ll} q^r, & \text{if } y \in H^{\perp}; \\ 0, & \text{otherwise.} \end{array} \right.$$

Let  $0 \le T < q^{m-1}$  be an integer. Then T can be uniquely written as  $T = \sum_{j=0}^{m-2} t_j q^j$ , where  $0 \le t_j \le q-1$  is an integer for  $0 \le j \le m-2$ . Let v(T) (resp. u(T)) denote the smallest (resp. largest) integer in the set  $\{0 \le j \le m-2 : t_j \ne 0\}$  and  $\ell(T) = \sum_{j=0}^{m-1} t_j$ . Then for any integer  $0 \le T < q^{m-1}$ , we have the following result (see the binary case in [27, Lemma IV.4]).

<span id="page-4-1"></span>**Lemma 2.** Let  $0 \le T < q^{m-1}$  be an integer. Let notation be defined as above. Then we have

$$\sum_{i=0}^{m-1} \lceil \frac{q^{m-1} - T}{q^i} \rceil = \frac{1}{q-1} (q^m - 1 - qT + \ell(T))$$

and

$$\sum_{i=0}^{m-1} \lceil \frac{q^{m-1}-T+1}{q^i} \rceil = \frac{1}{q-1} (q^m-1-qT+\ell(T)) + v(T) + 1.$$

*Proof.* We first write T as  $T = \sum_{j=0}^{m-2} t_j q^j = \sum_{j=\nu(T)}^{u(T)} t_j q^j$ , where  $0 \le t_j \le q-1$  is an integer for  $0 \le j \le m-2$ . A direct computation gives

$$\lceil \frac{q^{m-1} - T}{q^i} \rceil = \begin{cases} q^{m-i-1} - \sum_{j=v(T)}^{u(T)} t_j q^{j-i}, & \text{if } 0 \le i \le v(T); \\ q^{m-i-1} - \sum_{j=i}^{u(T)} t_j q^{j-i} + \lceil \frac{-\sum_{j=v(T)}^{i-1} t_j q^j}{q^i} \rceil, & \text{if } v(T) < i \le u(T); \\ q^{m-i-1} + \lceil \frac{-\sum_{j=v(T)}^{u(T)} t_j q^j}{q^i} \rceil, & \text{if } u(T) < i \le m-1. \end{cases}$$

Notice that  $\sum_{j=v(T)}^{i-1} t_j q^j \leq (q-1)(q^{v(T)}+\cdots+q^{i-1}) = q^i-q^{v(T)}$  for  $v(T) < i \leq u(T)$  and  $\sum_{j=v(T)}^{u(T)} t_j q^j \leq (q-1)(q^{v(T)}+\cdots+q^{u(T)}) = q^{u(T)+1}-q^{v(T)}$  for  $u(T) < i \leq m-1$ , which implies that  $\lceil \frac{-\sum_{j=v(T)}^{i-1} t_j q^j}{q^i} \rceil = 0$  for  $v(T) < i \leq u(T)$  and  $\lceil \frac{-\sum_{j=v(T)}^{u(T)} t_j q^j}{q^i} \rceil = 0$  for  $u(T) < i \leq m-1$  respectively. Thus we have

$$\begin{split} \sum_{i=0}^{m-1} \lceil \frac{q^{m-1}-T}{q^i} \rceil &= \sum_{i=0}^{m-1} q^{m-i-1} - \sum_{i=0}^{v(T)} \sum_{j=v(T)}^{u(T)} t_j q^{j-i} - \sum_{i=v(T)+1}^{u(T)} \sum_{j=i}^{u(T)} t_j q^{j-i} \\ &= \frac{q^m-1}{q-1} - \sum_{i=0}^{u(T)} \sum_{j=i}^{u(T)} t_j q^{j-i} = \frac{q^m-1}{q-1} - \sum_{j=0}^{u(T)} t_j \sum_{i=0}^{j} q^i \\ &= \frac{q^m-1}{q-1} - \sum_{i=0}^{u(T)} t_j \frac{q^{j+1}-1}{q-1} = \frac{1}{q-1} (q^m-1-qT+\ell(T)). \end{split}$$

The second assertion can be similarly proved and thus we omit the details of its proof here. This completes the proof.  $\Box$ 

## <span id="page-5-0"></span>III. The projective linear codes over $\mathbb{F}_q$ from the general simplicial complexes

Let  $\Delta$  be a simplicial complex of  $\mathbb{F}_{q^m}$ , and  $\Delta^c$  be the complement of  $\Delta$ , namely,  $\Delta^c = \mathbb{F}_q^m \setminus \Delta$ . Notice that if  $x \in \Delta$ , then  $yx \in \Delta$  for any  $y \in \mathbb{F}_q^*$  due to the definition of simplicial complexes. Hence for any simplicial complex  $\Delta$ ,  $\Delta^c$  can be expressed as

$$\Delta^c = \mathbb{F}_q^* \overline{\Delta}^c = \{ yz : y \in \mathbb{F}_q^* \text{ and } z \in \overline{\Delta}^c \}$$

where  $z_i/z_j \notin \mathbb{F}_q^*$  for distinct elements  $z_i$  and  $z_j$  in  $\overline{\Delta}^c$ , and clearly  $|\overline{\Delta}^c| = |\Delta^c|/(q-1)$ . This defines  $\overline{\Delta}^c$  and  $\overline{\Delta}^c$  can be viewed as a subset of PG(m-1,q).

In this section, we investigate the projective codes  $C_{\overline{\Delta}^c}$  defined as in (1). Even though  $C_{\overline{\Delta}^c}$  can also be extended to the nonprojective codes  $C_{\Delta^c}$ , we restrict our discussion to the projective case in this paper.

<span id="page-5-1"></span>**Theorem 1.** Let  $\Delta$  be a simplicial complex of  $\mathbb{F}_{q^m}$  with the support  $\mathcal{A} = \{A_1, A_2, \dots, A_h\}$ , where  $1 \leq |A_1| \leq |A_2| \leq \dots \leq |A_h| < m$ . Assume that  $A_i \setminus (\bigcup_{1 \leq j \leq h, j \neq i} A_j) \neq \emptyset$  for any  $1 \leq i \leq h$  and  $q^m > \sum_{1 \leq i \leq h} q^{|A_i|}$ . Denote  $T = \sum_{1 \leq i \leq h} q^{|A_i|-1}$ . Let  $C_{\overline{\Delta}^c}$  be defined as in (1). Then

- 1)  $C_{\overline{\Delta}^c}$  has parameters  $[(q^m |\Delta|)/(q-1), m, q^{m-1} T]$ , where  $|\Delta| = \sum_{\emptyset \neq S \subseteq \mathcal{A}} (-1)^{|S|-1} q^{|\cap S|}$  and  $\cap S$  is defined as  $\cap S = \bigcap_{A \in S} A$ .
- 2)  $C_{\overline{\Delta}^c}$  is a Griesmer code if and only if  $|A_i \cap A_j| = 0$  for any  $1 \le i < j \le h$  and at most q-1 of  $|A_i|$ 's are the same.
- 3)  $C_{\overline{\Delta}^c}$  is distance-optimal if  $|\Delta| 1 + (q-1)(v(T)+1) > qT \ell(T)$ .
- 4)  $C_{\Lambda^c}^{\Delta}$  has the following weight enumerator

$$\sum_{\emptyset \neq R \subseteq \Omega} |\Psi_R| z^{q^{m-1} - \sum_{S \in R} (-1)^{|S|-1} q^{|\cap S|-1}} + (q^{m-|\cup_{i=1}^h A_i|} - 1) z^{q^{m-1}} + 1$$

where  $\Omega = \{S : S \subseteq \mathcal{A}, S \neq \emptyset\}$  and

$$|\Psi_R| = q^{m-|\cup_{S \in \Omega \setminus R}(\cap S)|} - \sum_{\emptyset \neq E \subseteq R} (-1)^{|E|-1} q^{m-|(\cup_{L \in E}(\cap L)) \cup (\cup_{S \in \Omega \setminus R}(\cap S))|}.$$

*Proof.* 1). Let  $\Delta_{A_i} := \langle \{A_i\} \rangle$  be the simplicial complex of  $\mathbb{F}_q^m$  with exactly one maximal element for  $1 \le i \le h$ . Clearly, one has  $\Delta = \bigcup_{i=1}^h \Delta_{A_i}$ . Notice that  $\Delta_{A_i}$  is indeed a  $|A_i|$ -dimensional  $\mathbb{F}_q$ -subspace of  $\mathbb{F}_q^m$  for any  $1 \leq i \leq h$ , which implies  $|\Delta_{A_i}| = q^{|A_i|}$ . Let  $S = \{A_i : i \in J\}$  be a nonempty subset of  $\mathcal{A}$  for  $J\subseteq [h]:=\{1,2,\ldots,h\}$  and  $J\neq\emptyset$ . Then  $\cap_{i\in J}\Delta_{A_i}=\Delta_{\cap S}$ , where  $\cap S=\cap_{A\in S}A\subseteq [m]$  and  $\Delta_{\cap S}$  denotes the simplicial complex with exactly one maximal element generated by  $\{\cap S\}$ . This implies that  $|\cap_{i\in J}\Delta_{A_i}|=$  $|\Delta_{\cap S}| = q^{|\cap S|}.$ 

Using the principle of inclusion-exclusion, it follows that

<span id="page-6-0"></span>
$$|\Delta| = |\cup_{i=1}^{h} \Delta_{A_i}| = \sum_{1 \le i \le h} |\Delta_{A_i}| - \sum_{1 \le i < j \le h} |\Delta_{A_i} \cap \Delta_{A_j}| + \dots + (-1)^{h-1} |\cap_{i=1}^{h} \Delta_{A_i}| = \sum_{\emptyset \ne S \subseteq \mathcal{A}} (-1)^{|S|-1} q^{|\cap S|}. \quad (2)$$

Then the length of  $C_{\overline{\Delta}^c}$  is  $n = |\overline{\Delta}^c| = |\Delta^c|/(q-1) = (q^m - |\Delta|)/(q-1)$ . Now we compute the possible Hamming weights  $wt(c_a)$  of the codewords  $c_a$  in  $C_{\overline{\Delta}^c}$ . If a = 0, we immediately have  $wt(c_a) = 0$ . For  $a \in \mathbb{F}_{q^m}^*$ , one has  $wt(c_a) = n - N_a$ , where  $N_a = |\{x \in \overline{\Delta}^c : \operatorname{Tr}_q^{q^m}(ax) = 0\}|$  $|0| = \frac{1}{q-1} |\{x \in \Delta^c : \operatorname{Tr}_q^{q^m}(ax) = 0\}|$ . Using the orthogonal property of nontrivial additive characters, for  $a \in \mathbb{F}_{q^m}^{*}$ , it gives

$$N_{a} = \frac{1}{q(q-1)} \sum_{x \in \Delta^{c}} \sum_{u \in \mathbb{F}_{q}} \chi(u \operatorname{Tr}_{q}^{q^{m}}(ax)) = \frac{1}{q-1} (q^{m-1} - \frac{1}{q} \sum_{x \in \Delta} \sum_{u \in \mathbb{F}_{q}} \chi(u \operatorname{Tr}_{q}^{q^{m}}(ax))) = \frac{1}{q-1} (q^{m-1} - \Theta),$$

where  $\Theta := \frac{1}{q} \sum_{x \in \Delta} \sum_{u \in \mathbb{F}_q} \chi(u \operatorname{Tr}_q^{q^m}(ax))$ . Then for  $a \in \mathbb{F}_{q^m}^*$  it leads to

<span id="page-6-4"></span>
$$wt(c_a) = q^{m-1} - (|\Delta| - \Theta)/(q-1).$$
 (3)

To determine the minimum distance of  $C_{\overline{\Delta}^c}$ , it is equivalent to determining the maximum value of  $|\Delta| - \Theta$  as a runs through  $\mathbb{F}_{q^m}^*$ . For a simplicial complex  $\Delta_A = \langle \{A\} \rangle$  with exactly one maximal element, where  $A \subseteq [m]$ , we define

$$\Phi(\Delta_A) := \frac{1}{q} \sum_{u \in \mathbb{F}_q} \sum_{x \in \Delta_A} \chi(u \operatorname{Tr}_q^{q^m}(ax)).$$

Since  $\Delta_A$  can be viewed as a |A|-dimensional  $\mathbb{F}_q$ -subspace of  $\mathbb{F}_{q^m}$ , it follows from Lemma 1 that

<span id="page-6-3"></span>
$$\Phi(\Delta_A) = \begin{cases}
q^{|A|}, & \text{if } a \in \Delta_A^{\perp}; \\
q^{|A|-1}, & \text{otherwise,} 
\end{cases}$$
(4)

where  $\Delta_A^{\perp}$  is the dual of  $\Delta_A$ . In particular,  $\Delta_A = \{0\} \subseteq \mathbb{F}_{q^m}$  and  $\Phi(\Delta_A) = 1$  if  $A = \emptyset$ . Again using the principle of inclusion-exclusion gives

$$\Theta = \sum_{1 \leq i \leq h} \Phi(\Delta_{A_i}) - \sum_{1 \leq i < j \leq h} \Phi(\Delta_{A_i} \cap \Delta_{A_j}) + \dots + (-1)^{h-1} \Phi(\cap_{i=1}^h \Delta_{A_i}) = \sum_{\emptyset \neq S \subseteq \mathcal{A}} (-1)^{|S|-1} \Phi(\Delta_{\cap S}),$$

where  $\Delta_{\cap S} = \langle \{ \cap S \} \rangle$ . This together with (2) leads to

<span id="page-6-1"></span>
$$|\Delta| - \Theta = \sum_{\emptyset \neq S \subseteq \mathcal{A}} (-1)^{|S|-1} (q^{|\cap S|} - \Phi(\Delta_{\cap S})) = \sum_{\emptyset \neq S \subseteq \mathcal{A}} (-1)^{|S|-1} f_a(S), \tag{5}$$

where  $f_a(S) := q^{|\cap S|} - \Phi(\Delta_{\cap S})$ . Next we express  $|\Delta| - \Theta$  in another way. Define  $\mathcal{A}_i := \{A_1 \cap A_i, A_2 \cap A_i\}$  $A_i, \ldots, A_{i-1} \cap A_i$  for  $2 \le i \le h$ . From (5), one can further derive

<span id="page-6-2"></span>
$$|\Delta| - \Theta = \sum_{\emptyset \neq S \subset \mathcal{A}} (-1)^{|S|-1} f_a(S) = \sum_{i=1}^h f_a(\{A_i\}) - \sum_{i=2}^h \sum_{\emptyset \neq S \subset \mathcal{A}_i} (-1)^{|S|-1} f_a(S), \tag{6}$$

where the second equality can be verified by using the mathematical induction as follows:

(a). For h = 2, it can be readily verified that

$$\sum_{\emptyset \neq S \subseteq \{A_1,A_2\}} (-1)^{|S|-1} f_a(S) = \sum_{i=1}^2 f_a(\{A_i\}) - \sum_{\emptyset \neq S \subseteq A_2} (-1)^{|S|-1} f_a(S).$$

(b). Suppose that (6) holds for h = s where  $s \ge 2$  is an integer. Then we have

$$\begin{split} & \sum_{\emptyset \neq S \subseteq \{A_1, A_2, \dots, A_{s+1}\}} (-1)^{|S|-1} f_a(S) \\ &= \sum_{\emptyset \neq S \subseteq \{A_1, A_2, \dots, A_s\}} (-1)^{|S|-1} f_a(S) + f_a(\{A_{s+1}\}) - \sum_{\emptyset \neq S \subseteq \mathcal{A}_{s+1}} (-1)^{|S|-1} f_a(S) \\ &= \sum_{i=1}^{s+1} f_a(\{A_i\}) - \sum_{i=2}^{s+1} \sum_{\emptyset \neq S \subseteq \mathcal{A}_i} (-1)^{|S|-1} f_a(S), \end{split}$$

which implies that (6) also holds for h = s + 1. This proves (6).

Now we claim that

<span id="page-7-0"></span>
$$\sum_{\emptyset \neq S \subset \mathcal{A}_i} (-1)^{|S|-1} f_a(S) \ge 0 \tag{7}$$

for any  $2 \leq i \leq h$ . Let the linear code  $\mathcal{C}_{\Delta_{\mathcal{A}_i}}$  be defined by  $\mathcal{C}_{\Delta_{\mathcal{A}_i}} = \{\tilde{c}_a = (\operatorname{Tr}_q^{q^m}(ax))_{x \in \Delta_{\mathcal{A}_i}} : a \in \mathbb{F}_{q^m}\}$  where  $\Delta_{\mathcal{A}_i} := \langle \mathcal{A}_i \rangle$  is the simplicial complex generated by the set  $\mathcal{A}_i$ . For  $a \in \mathbb{F}_{q^m}^*$ , the Hamming weight of the codeword  $\tilde{c}_a$  in  $\mathcal{C}_{\Delta_{\mathcal{A}_i}}$  is

$$wt(\tilde{c}_a) = |\Delta_{\mathcal{A}_i}| - |\{x \in \Delta_{\mathcal{A}_i} : \operatorname{Tr}_q^{q^m}(ax) = 0\}| = |\Delta_{\mathcal{A}_i}| - \frac{1}{q} \sum_{x \in \Delta_{\mathcal{A}_i}} \sum_{u \in \mathbb{F}_q} \chi(u\operatorname{Tr}_q^{q^m}(ax)).$$

Similar to the computation of (5), we have

$$wt(\tilde{c}_a) = \sum_{\emptyset \neq S \subset \mathcal{A}_i} (-1)^{|S|-1} f_a(S) \ge 0.$$

This proves that (7) holds.

Therefore, by (6), (7) and (4), we conclude that

<span id="page-7-1"></span>
$$|\Delta| - \Theta \le \sum_{i=1}^{h} f_a(\{A_i\}) \le (q-1) \sum_{1 \le i \le h} q^{|A_i|-1}.$$
(8)

Next we show that there exists some  $a \in \mathbb{F}_{q^m}^*$  such that  $|\Delta| - \Theta = (q-1)\sum_{1 \leq i \leq h} q^{|A_i|-1}$  under the assumption that  $A_i \setminus (\cup_{1 \leq j \leq h, j \neq i} A_j) \neq \emptyset$  for any  $1 \leq i \leq h$ . Notice that by (5),  $|\Delta| - \Theta = \sum_{i=1}^h f_a(\{A_i\})$  if  $\Phi(\Delta_{\cap S}) = q^{|\cap S|}$  for any  $S \subseteq \mathcal{A}$  with  $|S| \geq 2$ , that is,  $a \in \Delta_{\cap S}^{\perp}$  for any  $S \subseteq \mathcal{A}$  with  $|S| \geq 2$  due to (4). Moreover, by (4),  $\sum_{i=1}^h f_a(\{A_i\}) = (q-1)\sum_{1 \leq i \leq h} q^{|A_i|-1}$  if  $a \notin \Delta_{A_i}^\perp$  for any  $1 \leq i \leq h$ . Therefore, one has  $|\Delta| - \Theta = (q-1)\sum_{1 \leq i \leq h} q^{|A_i|-1}$  if  $a \notin \Delta_{A_i}^\perp$  for any  $1 \leq i \leq h$  and  $1 \leq i \leq h$ . Therefore, one has  $|\Delta| - \Theta = (q-1)\sum_{1 \leq i \leq h} q^{|A_i|-1}$  if  $1 \leq i \leq h$  and  $1 \leq i \leq h$  and  $1 \leq i \leq h$ . Therefore, one has  $|\Delta| - \Theta = (q-1)\sum_{1 \leq i \leq h} q^{|A_i|-1}$  if  $1 \leq i \leq h$  and  $1 \leq i \leq h$  and  $1 \leq i \leq h$ . Therefore, one has  $|\Delta| - \Theta = (q-1)\sum_{1 \leq i \leq h} q^{|A_i|-1}$  if  $1 \leq i \leq h$  and  $1 \leq i \leq h$  and  $1 \leq i \leq h$ . Therefore, one has  $|\Delta| - \Theta = (q-1)\sum_{1 \leq i \leq h} q^{|A_i|-1}$  if  $1 \leq i \leq h$  and  $1 \leq i \leq h$ . Therefore, one has  $1 \leq i \leq h$  and  $1 \leq i \leq h$ . Therefore, one has  $1 \leq i \leq h$  and  $1 \leq i \leq h$ . Therefore, one has  $1 \leq i \leq h$  and  $1 \leq i \leq h$ . Therefore, one has  $1 \leq i \leq h$  and  $1 \leq i \leq h$ . Therefore, one has  $1 \leq i \leq h$ . Therefore, one has  $1 \leq i \leq h$ . Therefore, one has  $1 \leq i \leq h$ . Therefore, one has  $1 \leq i \leq h$ . Therefore, one has  $1 \leq i \leq h$ . Therefore, one has  $1 \leq i \leq h$ . Therefore, one has  $1 \leq i \leq h$ . Therefore, one has  $1 \leq i \leq h$ . Therefore, one has  $1 \leq i \leq h$ . Therefore, one has  $1 \leq i \leq h$ . Therefore, one has  $1 \leq i \leq h$ . Therefore, one has  $1 \leq i \leq h$ . Therefore, one has  $1 \leq i \leq h$ . Therefore, one has  $1 \leq i \leq h$ . Therefore, one has  $1 \leq i \leq h$ . Therefore, one has  $1 \leq i \leq h$ . Therefore, one has  $1 \leq i \leq h$ . Therefore, one has  $1 \leq i \leq h$ . Therefore, one has  $1 \leq i \leq h$ . Therefore, one has  $1 \leq i \leq h$ . Therefore, one has  $1 \leq i \leq h$ . Therefore, one has  $1 \leq i \leq h$ . Therefore, one has  $1 \leq i \leq h$ . Therefore, one has  $1 \leq i \leq h$ . Therefore, one has  $1 \leq i \leq h$ . Therefore, one

With above detailed computation on  $|\Delta| - \Theta$ , we conclude that the maximum value of  $|\Delta| - \Theta$  as a runs through  $\mathbb{F}_{q^m}^*$  is  $(q-1)\sum_{1\leq i\leq h}q^{|A_i|-1}$  by (8). Therefore, it follows from (3) that the minimum distance of  $\mathcal{C}_{\overline{\Delta}^c}$  is  $q^{m-1} - \sum_{1\leq i\leq h}q^{|A_i|-1}$ , which is greater than 0 since  $q^m > \sum_{1\leq i\leq h}q^{|A_i|}$ . This shows that the dimension of  $\mathcal{C}_{\overline{\Delta}^c}$  is m. Then the parameters of  $\mathcal{C}_{\Delta^c}$  are obtained.

2). Denote the minimum distance of  $C_{\overline{\Delta}^c}$  by d, i.e,  $d = q^{m-1} - T$ , where  $T = \sum_{1 \le i \le h} q^{|A_i|-1}$ . Using Lemma 2, we have

<span id="page-8-0"></span>
$$g(m,d) = \sum_{i=0}^{m-1} \lceil \frac{q^{m-1} - T}{q^i} \rceil = \frac{1}{q-1} (q^m - 1 - qT + \ell(T))$$
 (9)

and

<span id="page-8-2"></span>
$$g(m,d+1) = \sum_{i=0}^{m-1} \left\lceil \frac{q^{m-1} - T + 1}{q^i} \right\rceil = \frac{1}{q-1} (q^m - 1 - qT + \ell(T)) + \nu(T) + 1$$
 (10)

where  $\ell(T)$  and  $\nu(T)$  are defined as before.

Recall that the length of  $C_{\overline{\Delta}^c}$  is  $n = (q^m - |\Delta|)/(q-1)$ . Now we prove that n = g(m,d) if and only if  $|A_i \cap A_j| = 0$  for any  $1 \le i < j \le h$  and at most q-1 of  $|A_i|$ 's are the same. Similar to the computation of (6),  $|\Delta|$  in (2) can be represented as

<span id="page-8-1"></span>
$$|\Delta| = \sum_{\emptyset \neq S \subset \mathcal{A}} (-1)^{|S|-1} q^{|\cap S|} = \sum_{i=1}^{h} q^{|A_i|} - \sum_{i=2}^{h} \sum_{\emptyset \neq S \subset \mathcal{A}_i} (-1)^{|S|-1} q^{|\cap S|} = qT - \sum_{i=2}^{h} |\Delta_{\mathcal{A}_i}|, \tag{11}$$

where  $\Delta_{\mathcal{A}_i} = \langle \mathcal{A}_i \rangle$  and  $\mathcal{A}_i$  is defined as before. Then  $n-g(m,d) = \frac{1}{q-1}(qT+1-|\Delta|-\ell(T)) = \frac{1}{q-1}(\sum_{i=2}^h |\Delta_{\mathcal{A}_i}| - \ell(T)+1)$  by (9) and (11). Thus n=g(m,d) if and only if  $\sum_{i=2}^h |\Delta_{\mathcal{A}_i}| = \ell(T)-1$ . Note that  $|\Delta_{\mathcal{A}_i}| \geq 1$  since 0 is always in  $\Delta_{\mathcal{A}_i}$ , and  $\ell(T) \leq h$  by the definition of  $\ell(T)$ . Thus  $\sum_{i=2}^h |\Delta_{\mathcal{A}_i}| = \ell(T)-1$  if and only if  $|\Delta_{\mathcal{A}_i}| = 1$  for  $2 \leq i \leq h$  and  $\ell(T) = h$ , which are equivalent to  $|A_i \cap A_j| = 0$  for any  $1 \leq i < j \leq h$  and at most q-1 of  $|A_i|$ 's are the same. Therefore,  $\mathcal{C}_{\overline{\Delta}^c}$  is a Griesmer code if and only if  $|A_i \cap A_j| = 0$  for any  $1 \leq i < j \leq h$  and at most q-1 of  $|A_i|$ 's are the same.

- 3). By (10),  $C_{\overline{\Delta}^c}$  is distance-optimal if g(m, d+1) > n, i.e.,  $|\Delta| 1 + (q-1)(v(T)+1) > qT \ell(T)$ .
- 4). It follows from (3) and (5) that the Hamming weight of  $c_a$  in  $\mathcal{C}_{\overline{\Delta}^c}$  for  $a \in \mathbb{F}_{q^m}^*$  is

<span id="page-8-3"></span>
$$wt(c_a) = q^{m-1} - \frac{1}{q-1} \sum_{0 \neq S \subset \mathcal{A}} (-1)^{|S|-1} (q^{|\cap S|} - \Phi(\Delta_{\cap S})).$$
 (12)

By (4), it leads to

$$q^{|\cap S|} - \Phi(\Delta_{\cap S}) = \left\{ \begin{array}{ll} 0, & \text{if } a \in \Delta_{\cap S}^{\perp}; \\ (q-1)q^{|\cap S|-1}, & \text{if } a \notin \Delta_{\cap S}^{\perp}. \end{array} \right.$$

Denote the set of all nonempty subsets of  $\mathcal{A}$  by  $\Omega$ , that is,  $\Omega = \{S : S \subseteq \mathcal{A}, S \neq \emptyset\}$ . Let R be a subset of  $\Omega$ . Then it follows from (12) that for  $a \in \mathbb{F}_{q^m}^*$ ,  $wt(c_a) = q^{m-1} - \sum_{S \in R} (-1)^{|S|-1} q^{|\cap S|-1}$  if  $a \in \Psi_R$ , where

<span id="page-8-4"></span>
$$\Psi_R := \{ a \in \mathbb{F}_{q^m}^* : a \in \Delta_{\cap S}^{\perp} \text{ for any } S \in \Omega \setminus R \text{ and } a \notin \Delta_{\cap S}^{\perp} \text{ for any } S \in R \}.$$
 (13)

Next we compute the value of  $|\Psi_R|$ . Note that for  $S \in \Omega$ ,  $\Delta_{\cap S}^{\perp}$  is a  $|\cap S|$ -dimensional  $\mathbb{F}_q$ -subspace of  $\mathbb{F}_{q^m}$  spanned by  $\{\beta_i : i \in [m] \setminus \cap S\}$ , i.e.,  $\Delta_{\cap S}^{\perp} = \operatorname{span}\{\beta_i : i \in [m] \setminus \cap S\}$ , and the intersection of some subspaces of  $\mathbb{F}_{q^m}$  is also a subspace of  $\mathbb{F}_{q^m}$ . When  $R = \emptyset$ ,  $wt(c_a) = q^{m-1}$  if  $a \in \Psi_R$ , and we have

<span id="page-8-5"></span>
$$|\Psi_{R}| = |\{a \in \mathbb{F}_{q^{m}} : a \in \Delta_{\cap S}^{\perp} \text{ for any } S \in \Omega\}| - 1 = |\cap_{S \in \Omega} \Delta_{\cap S}^{\perp}| - 1$$

$$= |\Delta_{\cup_{S \in \Omega}(\cap S)}^{\perp}| - 1 = q^{m - |\cup_{S \in \Omega}(\cap S)|} - 1 = q^{m - |\cup_{i=1}^{h} A_{i}|} - 1$$
(14)

<span id="page-9-1"></span>

since  $\cap_{S \in \Omega} \Delta_{\cap S}^{\perp} = \operatorname{span}\{\beta_i : i \in [m] \setminus \bigcup_{S \in \Omega} (\cap S)\} = \Delta_{\bigcup_{S \in \Omega} (\cap S)}^{\perp}$ . When  $R \neq \emptyset$ , by (13) and the fact that  $\cap_{S\in\Omega\setminus R}\Delta_{\cap S}^{\perp}=\Delta_{\cup_{S\in\Omega\setminus R}(\cap S)}^{\perp}, \text{ it gives }$ 

$$\Psi_{R} = \bigcap_{S \in \Omega \setminus R} \Delta_{\cap S}^{\perp} \setminus \bigcup_{L \in R} ((\bigcap_{S \in \Omega \setminus R} \Delta_{\cap S}^{\perp}) \cap \Delta_{\cap L}^{\perp}) 
= \Delta_{\bigcup_{S \in \Omega \setminus R} (\cap S)}^{\perp} \setminus \bigcup_{L \in R} (\Delta_{\cap L}^{\perp} \cap \Delta_{\bigcup_{S \in \Omega \setminus R} (\cap S)}^{\perp}) 
= \Delta_{\bigcup_{S \in \Omega \setminus R} (\cap S)}^{\perp} \setminus \bigcup_{L \in R} (\Delta_{(\cap L) \cup (\bigcup_{S \in \Omega \setminus R} (\cap S))}^{\perp}).$$
(15)

Notice that  $\bigcup_{L \in R} (\Delta^{\perp}_{(\cap L) \cup (\bigcup_{S \in \Omega \setminus R} (\cap S))})$  is in fact the union of some subspaces  $\Delta^{\perp}_{(\cap L) \cup (\bigcup_{S \in \Omega \setminus R} (\cap S))}$ Then, similar to the computation of  $\Delta$  in (2), it follows from (15) that

<span id="page-9-3"></span>
$$|\Psi_R| = q^{m-|\cup_{S \in \Omega \setminus R}(\cap S)|} - \sum_{\emptyset \neq E \subset R} (-1)^{|E|-1} q^{m-|(\cup_{L \in E}(\cap L)) \cup (\cup_{S \in \Omega \setminus R}(\cap S))|}, \tag{16}$$

since  $\cap_{L\in E}\Delta^{\perp}_{(\cap L)\cup(\cup_{S\in\Omega\setminus R}(\cap S))}=\Delta^{\perp}_{(\cup_{L\in E}(\cap L))\cup(\cup_{S\in\Omega\setminus R}(\cap S))}$  for any nonempty subset E of R. Then, as R runs through all the subsets of  $\Omega$ , we get the weight enumerator of  $\mathcal{C}_{\overline{\Delta}^c}$  as follows:

$$\sum_{\emptyset \neq R \subset \Omega} |\Psi_R| z^{q^{m-1} - \sum_{S \in R} (-1)^{|S|-1} q^{|\cap S|-1}} + (q^{m-|\cup_{i=1}^h A_i|} - 1) z^{q^{m-1}} + 1.$$

This completes the proof.

<span id="page-9-0"></span>**Remark 1.** Here we show that the given condition  $|\Delta| - 1 + (q-1)(v(T)+1) > qT - \ell(T)$  in 3) of Theorem 1 for  $C_{\overline{\Delta}^c}$  to be distance-optimal can be easily satisfied and consequently many distance-optimal linear codes over  $\mathbb{F}_q$  can be produced from  $\mathcal{C}_{\overline{\Delta}^c}$ . Note that  $qT - |\Delta| = \sum_{S \subseteq \mathcal{A}, |S| \ge 2} (-1)^{|S|-1} q^{|\cap S|}$  whose value heavily relies on those of  $|A_i \cap A_j|$  for  $1 \le i < j \le h$ . By the definition,  $v(T) \ge |A_1|$  and  $\ell(T) \le h$ . Thus  $|\Delta| - 1 + (q-1)(v(T) + 1) > qT - \ell(T)$  can be easily satisfied if  $|A_1|$  is large enough and  $|A_i \cap A_j|$ 's are small enough. This also can be verified by the discussion for the cases h = 1, 2, 3 in Section IV.

**Remark 2.** The given formula in 4) of Theorem 1 to compute the weight distribution of  $\mathcal{C}_{\Lambda}^c$  is completely computable for a given  $\Delta$  with support  $\mathcal{A} = \{A_1, A_2, \dots, A_h\}$  although the expression seems not so simple. This can be verified in Section IV in which we completely determine the weight distributions of  $\mathcal{C}_{\overline{\Lambda}^c}$  for the three cases of the simplicial complexes with one, two and three maximal elements according to this formula. Thus we say that the weight distribution of  $\mathcal{C}_{\overline{\Lambda}^c}$  is completely determined in Theorem 1. Moreover, the weight distribution of  $C_{\overline{\Delta}^c}$  can be computed efficiently by the formula given in 4) of Theorem 1 with the following property: for  $S_1 \in \Omega$  and  $S_2 \in R \subseteq \Omega$ , one has  $|\Psi_R| = 0$  if  $S_1 \notin R$  for some  $S_1 \subseteq S_2$ , since  $a \in \Delta_{\cap S_1}^{\perp}$  implies  $a \in \Delta_{\cap S_2}^{\perp}$  if  $S_1 \subseteq S_2$ .

In the following corollary, we take a more in-depth discussion on the case that  $|A_i \cap A_j| = 0$  for all  $1 \le i < j \le h$  for the code  $C_{\overline{\Delta}^c}$  in Theorem 1. As a result, a more simple expression for the weight distribution of  $C_{\overline{\Delta}^c}$  is given and a necessary and sufficient condition for  $C_{\overline{\Delta}^c}$  to be a near Griesmer code is derived in this case.

<span id="page-9-2"></span>**Corollary 1.** Let  $\Delta$  be a simplicial complex of  $\mathbb{F}_{q^m}$  with the support  $\mathcal{A} = \{A_1, A_2, \dots, A_h\}$ , where  $1 \leq 1$  $|A_1| \le |A_2| \le \cdots \le |A_h| < m$ . Assume that  $|A_i \cap A_j| = 0$  for  $1 \le i < j \le h$ . Denote  $T = \sum_{1 \le i \le h} q^{|A_i|-1}$ . Let  $\mathcal{C}_{\overline{\Delta}^c}$  be defined as in (1). Then  $\mathcal{C}_{\overline{\Delta}^c}$  is an at most  $2^h$ -weight  $[(q^m - \sum_{i=1}^h q^{|A_i|} + h - 1)/(q - 1), m, q^{m-1} - T]$ linear code with weight enumerator

$$\sum_{\emptyset \neq R \subseteq [h]} (q^{m - \sum_{i \in [h] \setminus R} |A_i|} - \sum_{\emptyset \neq E \subseteq R} (-1)^{|E| - 1} q^{m - \sum_{i \in E} |A_i| - \sum_{i \in [h] \setminus R} |A_i|}) z^{q^{m - 1} - \sum_{i \in R} q^{|A_i| - 1}} + (q^{m - \sum_{i = 1}^h |A_i|} - 1) z^{q^{m - 1}} + 1.$$

Moreover, we have the followings:

- 1)  $C_{\overline{\Delta}^c}$  is a Griesmer code if and only if at most q-1 of  $|A_i|$ 's are the same;
- 2)  $C_{\Lambda^c}$  is a near Griesmer code if and only if  $\ell(T) = h (q-1)$ ; and

3)  $C_{\overline{\Delta}^c}$  is distance-optimal if  $\ell(T) + (q-1)(v(T)+1) > h$ . Specially, when  $|A_i| = \varepsilon$  for  $1 \le i \le h$ , where  $\varepsilon$  is a positive integer, it is distance-optimal if  $\ell(h) + (q-1)(v(h)+\varepsilon) > h$ .

Proof. Clearly, the conditions  $A_i \setminus (\cup_{1 \leq j \leq h, j \neq i} A_j) \neq \emptyset$  and  $q^m > \sum_{1 \leq i \leq h} q^{|A_i|}$  in Theorem 1 are always satisfied under the assumption that  $|A_i \cap A_j| = 0$  for  $1 \leq i < j \leq h$ . Recall that  $|\Delta| = |\cup_{i=1}^h \Delta_{A_i}|$  where  $\Delta_{A_i} = \langle \{A_i\} \rangle$ . Since  $\Delta_{A_i} \cap \Delta_{A_j} = \{0\}$  due to  $|A_i \cap A_j| = 0$ , we have  $|\Delta| = \sum_{i=1}^h q^{|A_i|} - h + 1$ . Then the parameters of  $\mathcal{C}_{\overline{\Delta}^c}$  follow directly from 1) of Theorem 1. Moreover, by 2) and 3) of Theorem 1,  $\mathcal{C}_{\overline{\Delta}^c}$  is a Griesmer code if and only if at most q-1 of  $|A_i|$ 's are the same and it is distance-optimal if  $\ell(T) + (q-1)(v(T)+1) > h$ . By Lemma 2, one can check that n-g(m,d)=1 if and only if  $\ell(T)=h-(q-1)$ , where  $n=(q^m-\sum_{i=1}^h q^{|A_i|}+h-1)/(q-1)$  and  $d=q^{m-1}-T$ . Specially, when  $|A_i|=\epsilon$  for  $1\leq i \leq h$ , which implies  $T=hq^{\epsilon-1}$ , it can be verified that  $\ell(T)=\ell(h)$  and  $\nu(T)=\nu(h)+\epsilon-1$ . Thus, when  $|A_i|=\epsilon$  for  $1\leq i \leq h$ ,  $\mathcal{C}_{\overline{\Delta}^c}$  is distance-optimal if  $\ell(h)+(q-1)(\nu(h)+\epsilon)>h$ . This proves 1), 2) and 3). Next we compute the weight enumerator of  $\mathcal{C}_{\overline{\Delta}^c}$  according to the proof of 4) of Theorem 1.

Recall from the proof of 4) of Theorem 1 that for  $a \in \mathbb{F}_{q^m}^*$ ,  $wt(c_a) = q^{m-1} - \sum_{S \in R} (-1)^{|S|-1} q^{|\cap S|-1}$  if  $a \in \Psi_R$ , where  $\Omega = \{S : S \subseteq \mathcal{A}, S \neq \emptyset\}$ , R is a subset of  $\Omega$  and  $\Psi_R$  is defined as in (13). Notice that for  $S \in \Omega$  with  $|S| \geq 2$ , one has  $\Delta_{\cap S}^{\perp} = \mathbb{F}_{q^m}$  since  $\cap S = \emptyset$  and  $\Delta_{\cap S} = \{0\}$ . If there is some S with  $|S| \geq 2$  in R, then  $|\Psi_R| = 0$ . Thus we can rewrite simply that for  $a \in \mathbb{F}_{q^m}^*$ ,  $wt(c_a) = q^{m-1} - \sum_{i \in R} q^{|A_i|-1}$  if  $a \in \Psi_R$ , where R is a subset of [h],  $\Psi_R = \{a \in \mathbb{F}_{q^m}^* : a \in \Delta_{A_i}^{\perp} \text{ for any } i \in [h] \setminus R \text{ and } a \notin \Delta_{A_i}^{\perp} \text{ for any } i \in R\}$  and  $\Delta_{A_i} = \langle \{A_i\} \rangle$ . Specially, when  $R = \emptyset$ , similar to the computation in the proof of 4) of Theorem 1, we also have  $wt(c_a) = q^{m-1}$  if  $a \in \Psi_R$  and  $|\Psi_R| = q^{m-|\bigcup_{i=1}^h A_i|} - 1$ . When  $R \neq \emptyset$ , similar to the computation of  $|\Psi_R|$  in the proof of 4) of Theorem 1, we have

$$|\Psi_R| = q^{m-\sum_{i \in [h] \setminus R} |A_i|} - \sum_{\emptyset \neq E \subseteq R} (-1)^{|E|-1} q^{m-\sum_{i \in E} |A_i| - \sum_{i \in [h] \setminus R} |A_i|}.$$

Therefore, as R runs through all subsets of [h], the weight enumerator of  $\mathcal{C}_{\overline{\Lambda}^c}$  can be expressed as

$$\sum_{\emptyset \neq R \subset [h]} |\Psi_R| z^{q^{m-1} - \sum_{i \in R} q^{|A_i| - 1}} + (q^{m - \sum_{i=1}^h |A_i|} - 1) z^{q^{m-1}} + 1.$$

Due to the  $2^h$  choices of the subset R of [h],  $\mathcal{C}_{\Lambda}^c$  is at most  $2^h$ -weight. This completes the proof.

**Remark 3.** The Griesmer codes in Corollary 1 (or Theorem 1) are indeed the Solomon-Stiffler codes, since  $\overline{\Delta}^c$  can be viewed as the complement of the union of h disjoint projective subspaces of dimensions  $|A_i|-1$  of PG(m-1,q) when  $|A_i\cap A_j|=0$  for any  $1\leq i < j \leq h$ . Definitely, for the other cases (not the Griesmer codes), our codes  $C_{\overline{\Delta}^c}$  in Corollary 1 and Theorem 1 are different from the Solomon-Stiffler codes.

**Remark 4.** Notice that the necessary and sufficient condition  $\ell(T) = h - (q-1)$  for  $\mathcal{C}_{\overline{\Delta}^c}$  to be a near Griesmer code in Corollary 1 can be easily satisfied by selecting proper  $A_i$ 's. Moreover, the sufficient condition  $\ell(T) + (q-1)(v(T)+1) > h$  for  $\mathcal{C}_{\overline{\Delta}^c}$  to be distance-optimal can be easily satisfied if  $|A_1|$  is large enough since  $1 \le \ell(T) \le h$  and  $v(T) \ge |A_1|$ , and consequently many distance-optimal linear codes can be produced in Corollary 1 besides (near) Griesmer codes.

Here we will investigate the parameters and weight distribution of the projective linear code  $C_{\overline{\Delta}^*}$  defined by (1), where  $\Delta^* = \Delta \setminus \{0\}$  and  $\overline{\Delta}^*$  is defined by  $\Delta^* = \mathbb{F}_q^* \overline{\Delta}^* = \{yz : y \in \mathbb{F}_q^* \text{ and } z \in \overline{\Delta}^*\}$  in which  $z_i/z_j \notin \mathbb{F}_q^*$  for distinct  $z_i$  and  $z_j$  in  $\overline{\Delta}^*$ .

<span id="page-10-1"></span>**Proposition 1.** Let  $\Delta$  be a simplicial complex of  $\mathbb{F}_{q^m}$  with the support  $\mathcal{A} = \{A_1, A_2, \dots, A_h\}$ , where  $1 \leq |A_1| \leq |A_2| \leq \dots \leq |A_h| < m$ . Assume that  $A_i \setminus (\bigcup_{1 \leq j \leq h, j \neq i} A_j) \neq \emptyset$  for any  $1 \leq i \leq h$  and  $q^m > \sum_{1 \leq i \leq h} q^{|A_i|}$ . Let the multiset  $\{*wt(c_a) : a \in \mathbb{F}_{q^m}^* *\} \cup \{*0 *\}$  be the weight distribution of  $\mathcal{C}_{\overline{\Delta}^c}$  given as in Theorem 1 and define the multiset

<span id="page-10-0"></span>
$$\{* q^{m-1} - wt(c_a) : a \in \mathbb{F}_{q^m}^* *\} \cup \{* 0 *\}. \tag{17}$$

Let  $C_{\overline{\Delta}^*}$  be defined as in (1). Then  $C_{\overline{\Delta}^*}$  has parameters  $[(|\Delta|-1)/(q-1), |\cup_{i=1}^h A_i|, q^{|A_1|-1}]$ , where  $|\Delta| = \sum_{\emptyset \neq S \subset \mathcal{A}} (-1)^{|S|-1} q^{|\cap S|}$ , and its weight distribution is given by

$$q^{m-1} - wt(c_a)$$
 with multiplicity  $e_a/q^{m-|\bigcup_{i=1}^h A_i|}$ 

for all  $q^{m-1} - wt(c_a)$  in (17), where  $e_a$  is the multiplicity of  $q^{m-1} - wt(c_a)$  in the multiset of (17).

*Proof.* It's obvious that  $C_{\overline{\Delta}^*}$  has length  $n' = (|\Delta| - 1)/(q - 1)$  where  $|\Delta|$  is given as in (2). Next we study the Hamming weight of the codewords  $c'_a$  in  $C_{\overline{\Delta}^*}$  according to the proof of Theorem 1 and the relation between  $C_{\overline{\Delta}^*}$  and  $C_{\overline{\Delta}^c}$ . It can be readily verified that  $wt(c'_a) + wt(c_a) = q^{m-1}$  for  $a \in \mathbb{F}_{q^m}^*$ , where  $wt(c'_a)$  (resp.  $wt(c_a)$ ) denotes the Hamming weight of the codeword  $c'_a$  (resp.  $c_a$ ) in  $C_{\overline{\Delta}^*}$  (resp.  $C_{\overline{\Delta}^c}$ ). Clearly, the weight distribution of  $C_{\overline{\Delta}^c}$  is given by the multiset  $\{*wt(c_a): a \in \mathbb{F}_{q^m}^**\} \cup \{*0*\}$  which can be obtained by 4) of Theorem 1 and then the multiset  $\{*wt(c'_a): a \in \mathbb{F}_{q^m}^**\} \cup \{*0*\}$  on the code  $C_{\overline{\Delta}^*}$  is given by (17).

Now we need to compute the multiplicity of 0 in (17) and the minimum nonzero value in the set (17) to determine the dimension and minimum distance of  $\mathcal{C}_{\overline{\Lambda}^*}$ .

Due to (3) in the proof of 1) of Theorem 1, one has  $wt(c_a') = (|\Delta| - \Theta)/(q-1)$ , where  $|\Delta| - \Theta$  is defined as in the proof of Theorem 1. Moreover, according to the proof of 4) of Theorem 1, we also have  $wt(c_a') = \sum_{0 \neq S \in R} (-1)^{|S|-1} q^{|\Omega S|-1}$  if  $a \in \Psi_R$ , where R is a subset of  $\Omega$ ,  $\Omega = \{S : S \subseteq \mathcal{A}, S \neq \emptyset\}$  and  $\Psi_R$  is defined as in (13). Observe that  $wt(c_a') = 0$  if  $a \in \Psi_R$  with  $R = \emptyset$ . Note that for  $S_1, S_2 \in \Omega$ , one can verify that  $a \in \Delta_{\Omega S_1}^{\perp}$  implies  $a \in \Delta_{\Omega S_2}^{\perp}$  if  $S_1 \subseteq S_2$ . Thus, when  $R \neq \emptyset$ , we conclude that there must exist some  $A_i$  for  $1 \leq i \leq h$  such that  $\{A_i\} \in R$  if  $|\Psi_R| \neq 0$ . Since it's meaningless for  $|\Psi_R| = 0$ , we always assume that  $|\Psi_R| \neq 0$  for the subsequent proof. We first consider the case that  $a \in \Psi_R$  and  $\{A_1\} \in R$ , which implies that  $a \notin \Delta_{A_1}^{\perp}$  where  $\Delta_{A_1} = \langle \{A_1\} \rangle$ . It follows from (6) that

$$wt(c_a') = (|\Delta| - \Theta)/(q - 1) = \frac{1}{q - 1}(f_a(\{A_1\}) + \sum_{i=2}^{h}(f_a(\{A_i\}) - \sum_{\emptyset \neq S \subseteq \mathcal{A}_i}(-1)^{|S| - 1}f_a(S))).$$
(18)

Here  $f_a(\{A_1\}) = (q-1)q^{|A_1|-1}$  due to  $a \notin \Delta_{A_1}^{\perp}$ . Moreover, similar to the computation of (3) and (5), one can check that  $f_a(\{A_i\}) - \sum_{0 \neq S \subseteq \mathcal{A}_i} (-1)^{|S|-1} f_a(S)$  is the Hamming weight of the codeword  $\widehat{c}_a$  in the code  $\mathcal{C}_{\Delta_{A_i} \setminus \Delta_{\mathcal{A}_i}}$  defined by  $\mathcal{C}_{\Delta_{A_i} \setminus \Delta_{\mathcal{A}_i}} = \{\widehat{c}_a = (\operatorname{Tr}_q^{q^m}(ax))_{x \in \Delta_{A_i} \setminus \Delta_{\mathcal{A}_i}} : a \in \mathbb{F}_{q^m}\}$ . This implies that  $f_a(\{A_i\}) - \sum_{0 \neq S \subseteq \mathcal{A}_i} (-1)^{|S|-1} f_a(S) \geq 0$  for  $2 \leq i \leq h$ . Thus we have  $wt(c_a') \geq q^{|A_1|-1}$  if  $a \in \Psi_R$  and  $\{A_1\} \in R$ . Similarly, we can prove that  $wt(c_a') \geq q^{|A_i|-1}$  if  $a \in \Psi_R$  and  $\{A_i\} \in R$  for  $2 \leq i \leq h$  since the condition  $1 \leq |A_1| \leq |A_2| \leq \cdots \leq |A_h| < m$  has no effect on the above computation. Then one has  $wt(c_a') \geq q^{|A_1|-1} > 0$  for any  $a \in \Psi_R$  with  $R \neq \emptyset$  and  $|\Psi_R| \neq 0$  due to  $1 \leq |A_1| \leq |A_2| \leq \cdots \leq |A_h| < m$ . This accordingly proves that  $wt(c_a') = 0$  if and only if  $a \in \Psi_R$ ,  $a \in \mathbb{F}_R$  or  $a \in \mathbb{F}_R$  which implies the multiplicity of 0 in the multiset of (17) is  $a \in \mathbb{F}_R$  follows from (17). In addition, it can be readily verified that  $wt(c_a') = q^{|A_1|-1}$  if  $a \in \Psi_R$  and  $a \in \mathbb{F}_R$  follows from (17). In addition, it can be readily verified that  $a \in \mathbb{F}_R$  and  $a \in \mathbb{F}_R$  and  $a \in \mathbb{F}_R$  is  $a \in \mathbb{F}_R$  and  $a \in \mathbb{F}_R$  in  $a \in \mathbb{F}_R$  in  $a \in \mathbb{F}_R$  and  $a \in \mathbb{F}_R$  for  $a \in \mathbb{F}_R$  and  $a \in \mathbb{F}_R$  for  $a \in \mathbb{F}_R$  and  $a \in \mathbb{F}_R$  and  $a \in \mathbb{F}_R$  for  $a \in \mathbb{F}_R$  for  $a \in \mathbb{F}_R$  for  $a \in \mathbb{F}_R$  for  $a \in \mathbb{F}_R$  for  $a \in \mathbb{F}_R$  for  $a \in \mathbb{F}_R$  for  $a \in \mathbb{F}_R$  for  $a \in \mathbb{F}_R$  for  $a \in \mathbb{F}_R$  for  $a \in \mathbb{F}_R$  for  $a \in \mathbb{F}_R$  for  $a \in \mathbb{F}_R$  for  $a \in \mathbb{F}_R$  for  $a \in \mathbb{F}_R$  for  $a \in \mathbb{F}_R$  for  $a \in \mathbb{F}_R$  for  $a \in \mathbb{F}_R$  for  $a \in \mathbb{F}_R$  for  $a \in \mathbb{F}_R$  for  $a \in \mathbb{F}_R$  for  $a \in \mathbb{F}_R$  for  $a \in \mathbb{F}_R$  for  $a \in \mathbb{F}_R$  for  $a \in \mathbb{F}_R$  for  $a \in \mathbb{F}_R$  for  $a \in \mathbb{F}_R$  for  $a \in \mathbb{F}_R$  for  $a \in \mathbb{F}_R$  for  $a \in \mathbb{F}_R$  for  $a \in \mathbb{F}_R$  for  $a \in \mathbb{F}_R$  for  $a \in \mathbb{F}_R$  for  $a \in \mathbb{F}_R$  for  $a \in \mathbb{F}_R$  for  $a \in$ 

**Remark 5.**  $C_{\overline{\Delta}^*}$  in Proposition 1 is a trivial code with parameters [h,h,1] (the full vector space  $\mathbb{F}_q^h$ ) if  $|A_h|=1$  and it is the well-known simplex code with parameters  $[(q^{|A_1|}-1)/(q-1),|A_1|,q^{|A_1|-1}]$  if h=1. With some detailed computation, when  $|A_h|>1$  and h>1, one can verify that  $C_{\overline{\Delta}^*}$  cannot be a Griesmer code, i.e.,  $n\neq g(k,d)$ , and n< g(k,d+1) only if (q,h)=(2,2) and  $|A_1|=|A_2|=2$ , which implies that  $C_{\overline{\Delta}^*}$  is distance-optimal if (q,h)=(2,2) and  $|A_1|=|A_2|=2$ .

#### IV. EXPLICIT CONSTRUCTIONS OF OPTIMAL LINEAR CODES FOR h = 1, 2, 3

<span id="page-11-0"></span>In this section, we take a more in-depth discussion on the cases h = 1,2,3 of Theorem 1 in order to show that many infinite families of optimal linear codes can be obtained from Theorem 1, including

Griesmer codes, near Griesmer codes and distance-optimal codes. Moreover, for these three cases, we will present the parameters and weight distributions of  $C_{\overline{\Delta}^c}$  more explicitly and characterize the optimality of  $C_{\overline{\Delta}^c}$  in detail. Notice that the cases h = 1, 2, 3 correspond exactly to the cases of simplicial complexes  $\Delta$  with one, two and three maximal elements, respectively.

<span id="page-12-0"></span>**Theorem 2.** Let  $\Delta$  be a simplicial complex of  $\mathbb{F}_{q^m}$  with exactly one maximal element and its support is  $\{A\}$  with  $A \subseteq [m]$  and  $1 \le |A| < m$ . Then  $\mathcal{C}_{\overline{\Delta}^c}$  defined by (1) is a 2-weight  $[(q^m - q^{|A|})/(q-1), m, q^{m-1} - q^{|A|-1}]$  linear code with weight distribution

| Weight w              | Multiplicity $A_w$ |
|-----------------------|--------------------|
| 0                     | 1                  |
| $q^{m-1}$             | $q^{m- A }-1$      |
| $q^{m-1} - q^{ A -1}$ | $q^m - q^{m- A }$  |

and it is a Griesmer code.

*Proof.* By Corollary 1, the parameters of  $\mathcal{C}_{\overline{\Delta}^c}$  follow directly and it is a Griesmer code. Moreover, its weight enumerator is given by  $1+(q^{m-|A|}-1)z^{q^{m-1}}+(q^m-q^{m-|A|})z^{q^{m-1}-q^{|A|-1}}$  due to Corollary 1. This completes the proof.

**Example 1.** Let q = 3, m = 5,  $A = \{1,2\}$ . Magma experiments show that  $C_{\overline{\Delta}^c}$  is a [117,5,78] linear code over  $\mathbb{F}_3$  with weight enumerator  $1 + 216z^{78} + 26z^{81}$ , which is consistent with our result in Theorem 2. This code is a Griesmer code by the Griesmer bound and is optimal due to [17].

<span id="page-12-1"></span>**Theorem 3.** Let  $\Delta$  be a simplicial complex of  $\mathbb{F}_{q^m}$  with the support  $\mathcal{A} = \{A_1, A_2\}$ , where  $1 \leq |A_1| \leq |A_2| < m$ . Assume that  $q^m > q^{|A_1|} + q^{|A_2|}$ . Let  $T = q^{|A_1|-1} + q^{|A_2|-1}$ . Then  $C_{\overline{\Delta}^c}$  defined by (1) is an at most 5-weight  $[(q^m - q^{|A_1|} - q^{|A_2|} + q^{|A_1 \cap A_2|})/(q-1), m, q^{m-1} - q^{|A_1|-1} - q^{|A_2|-1}]$  linear code and its weight distribution is given by

| Weight w                                                     | Multiplicity $A_w$                                                      |
|--------------------------------------------------------------|-------------------------------------------------------------------------|
| 0                                                            | 1                                                                       |
| $q^{m-1}$                                                    | $q^{m- A_1\cup A_2 }-1$                                                 |
| $q^{m-1} - q^{ A_2 -1}$                                      | $q^{m- A_1 } - q^{m- A_1 \cup A_2 }$                                    |
| $q^{m-1} - q^{ A_1 -1}$                                      | $q^{m- A_2 } - q^{m- A_1 \cup A_2 }$                                    |
| $q^{m-1} - q^{ A_1 -1} - q^{ A_2 -1}$                        | $q^{m- A_1\cap A_2 } - q^{m- A_1 } - q^{m- A_2 } + q^{m- A_1\cup A_2 }$ |
| $q^{m-1} - q^{ A_1 -1} - q^{ A_2 -1} + q^{ A_1 \cap A_2 -1}$ | $q^m - q^{m- A_1 \cap A_2 }$                                            |

Moreover, we have the followings:

- 1) When  $|A_1 \cap A_2| = 0$  and  $|A_1| = |A_2|$ ,  $C_{\overline{\Delta}^c}$  is a near Griesmer code (also distance-optimal) if q = 2 and it is a Griesmer code if q > 2. It reduces to a 3-weight code in this case.
- 2) When  $|A_1 \cap A_2| = 0$  and  $|A_1| < |A_2|$ ,  $C_{\overline{\Lambda}^c}$  is a Griesmer code and it reduces to a 4-weight code.
- 3) When  $|A_1 \cap A_2| > 0$  and  $|A_1| = |A_2|$ ,  $C_{\overline{\Delta}^c}$  is distance-optimal if  $\ell(T) + (q-1)(\nu(T)+1) > q^{|A_1 \cap A_2|} + 1$  and it reduces to a 4-weight code. Specially,  $C_{\overline{\Delta}^c}$  is a near Griesmer code if q > 2 and  $|A_1 \cap A_2| = 1$ .
- 4) When  $|A_1 \cap A_2| > 0$  and  $|A_1| < |A_2|$ ,  $\mathcal{C}_{\overline{\Lambda}^c}$  is distance-optimal if  $(q-1)|A_1| + 1 > q^{|A_1 \cap A_2|}$ . Specially,  $\mathcal{C}_{\overline{\Lambda}^c}$  is a near Griesmer code if  $|A_1 \cap A_2| = 1$ .

*Proof.* By the definition of simplicial complexes, the condition  $A_i \setminus (\cup_{1 \leq j \leq h, j \neq i} A_j) \neq \emptyset$  in Theorem 1 always holds for h = 2. Then the parameters of  $\mathcal{C}_{\overline{\Delta}^c}$  follow directly from 1) of Theorem 1. Due to 4) of Theorem 1, we can determine each possible Hamming weight of the codewords in  $\mathcal{C}_{\overline{\Delta}^c}$  and its corresponding multiplicity as R runs through all subsets of  $\Omega = \{S : S \subseteq \mathcal{A}, S \neq \emptyset\} = \{\{A_1\}, \{A_2\}, \{A_1, A_2\}\}$ . Then the weight distribution can be obtained by some careful computation. Next we discuss the optimality of  $\mathcal{C}_{\overline{\Delta}^c}$  case by case.

Note that the length of  $C_{\overline{\Delta}^c}$  is  $n = \frac{1}{q-1}(q^m - q^{|A_1|} - q^{|A_2|} + q^{|A_1 \cap A_2|})$  and the minimum distance of  $C_{\overline{\Delta}^c}$  is  $d = q^{m-1} - q^{|A_1|-1} - q^{|A_2|-1}$ . Then by Lemma 2 we have

$$g(m,d) = \frac{1}{q-1}(q^m - q^{|A_1|} - q^{|A_2|} + \ell(T) - 1)$$
(19)

and

<span id="page-13-1"></span>
$$g(m,d+1) = \frac{1}{q-1}(q^m - q^{|A_1|} - q^{|A_2|} + \ell(T) - 1) + \nu(T) + 1, \tag{20}$$

where  $T = q^{|A_1|-1} + q^{|A_2|-1}$ . As for  $\ell(T)$  and  $\nu(T)$ , one can easily verify that

<span id="page-13-0"></span>
$$\ell(T) = \begin{cases} 1, & \text{if } q = 2 \text{ and } |A_1| = |A_2|; \\ 2, & \text{otherwise,} \end{cases}$$
 (21)

and

<span id="page-13-2"></span>
$$v(T) = \begin{cases} |A_1|, & \text{if } q = 2 \text{ and } |A_1| = |A_2|; \\ |A_1| - 1, & \text{otherwise.} \end{cases}$$
 (22)

Therefore we have the followings:

- 1). In the case  $|A_1 \cap A_2| = 0$  and  $|A_1| = |A_2|$ , we have  $n g(m, d) = \frac{1}{q-1}(2 \ell(T))$ . This together with (21) implies that  $\mathcal{C}_{\overline{\Delta}^c}$  is a near Griesmer code if q = 2 and it is a Griesmer code if q > 2. Moreover,  $\mathcal{C}_{\overline{\Delta}^c}$  is always distance-optimal since  $g(m, d+1) n = \frac{1}{q-1}(\ell(T) 2) + \nu(T) + 1 > 0$ . Notice that it reduces to a 3-weight code.
- 2). In the case  $|A_1 \cap A_2| = 0$  and  $|A_1| < |A_2|$ ,  $\mathcal{C}_{\overline{\Delta}^c}$  is a Griesmer code since  $n g(m, d) = \frac{1}{q-1}(2 \ell(T)) = 0$ . Observe that it reduces to a 4-weight code.
- 3). In the case  $|A_1 \cap A_2| > 0$  and  $|A_1| = |A_2|$ , we have  $n g(m,d) = \frac{1}{q-1}(q^{|A_1 \cap A_2|} + 1 \ell(T)) > 0$ . Specially, if q > 2 and  $|A_1 \cap A_2| = 1$ , it gives n g(m,d) = 1, which implies that  $\mathcal{C}_{\overline{\Delta}^c}$  is a near Griesmer code. By (20),  $\mathcal{C}_{\overline{\Delta}^c}$  is distance-optimal if  $g(m,d+1) n = \frac{1}{q-1}(\ell(T) 1 q^{|A_1 \cap A_2|}) + \nu(T) + 1 > 0$  which is equivalent to  $\ell(T) + (q-1)(\nu(T)+1) > q^{|A_1 \cap A_2|} + 1$ . Notice that it reduces to a 4-weight code.
- 4). In the case  $|A_1 \cap A_2| > 0$  and  $|A_1| < |A_2|$ , we have  $n g(m,d) = \frac{1}{q-1}(q^{|A_1 \cap A_2|} 1) > 0$ . Clearly,  $\mathcal{C}_{\overline{\Delta}^c}$  is a near Griesmer code if  $|A_1 \cap A_2| = 1$ . By (20),  $\mathcal{C}_{\overline{\Delta}^c}$  is distance-optimal if g(m,d+1) n > 0, i.e.,  $(q-1)|A_1| + 1 > q^{|A_1 \cap A_2|}$ . This completes the proof.
- **Remark 6.** The conditions  $\ell(T) + (q-1)(v(T)+1) > q^{|A_1 \cap A_2|} + 1$  and  $(q-1)|A_1| + 1 > q^{|A_1 \cap A_2|}$  in 3) and 4) of Theorem 3 for  $\mathcal{C}_{\overline{\Delta}^c}$  to be distance-optimal can be easily satisfied if  $|A_1|$  is large enough and  $|A_1 \cap A_2|$  is small enough due to (21) and (22) in the proof of Theorem 3. Thus many distance-optimal linear codes can be obtained since such  $A_1$  and  $A_2$  are abundant.
- **Example 2.** Let q = 3, m = 5,  $A_1 = \{1,2\}$ ,  $A_2 = \{3,4\}$ . Magma experiments show that  $C_{\overline{\Delta}^c}$  is a [113,5,75] linear code over  $\mathbb{F}_3$  with weight enumerator  $1 + 192z^{75} + 48z^{78} + 2z^{81}$ , which is consistent with our result in Theorem 3. This code is a Griesmer code by the Griesmer bound and is optimal due to [17].
- **Example 3.** Let q = 3, m = 5,  $A_1 = \{1,2\}$ ,  $A_2 = \{2,3,4\}$ . Magma experiments show that  $\mathcal{C}_{\overline{\Delta}^c}$  is a [105,5,69] linear code over  $\mathbb{F}_3$  with weight enumerator  $1 + 48z^{69} + 162z^{70} + 24z^{72} + 6z^{78} + 2z^{81}$ , which is consistent with our result in Theorem 3. This code is optimal due to [17].
- <span id="page-13-3"></span>**Theorem 4.** Let  $\Delta$  be a simplicial complex of  $\mathbb{F}_{q^m}$  with the support  $\mathcal{A} = \{A_1, A_2, A_3\}$ , where  $1 \leq |A_1| \leq |A_2| \leq |A_3| < m$ . Assume that  $A_i \setminus (\bigcup_{1 \leq j \leq 3, j \neq i} A_j) \neq \emptyset$  for any  $1 \leq i \leq 3$ , and  $q^m > \sum_{1 \leq i \leq 3} q^{|A_i|}$ . Let  $T = \sum_{1 \leq i \leq 3} q^{|A_i|-1}$ . Then  $C_{\overline{\Delta}^c}$  defined by (1) is an at most 19-weight  $[(q^m - |\Delta|)/(q-1), m, q^{m-1} - T]$  linear code with weight distribution in Table I, where  $|\Delta| = \sum_{i=1}^3 q^{|A_i|} - \sum_{1 \leq i < j \leq 3} q^{|A_i \cap A_j|} + q^{|A_1 \cap A_2 \cap A_3|}$ . Moreover, we have the followings:
  - 1)  $C_{\overline{\Delta}^c}$  is a Griesmer code if and only if  $|A_i \cap A_j| = 0$  for  $1 \le i < j \le 3$  and at most q-1 of  $|A_i|$ 's are the same (which always holds for q > 3).

<span id="page-14-0"></span>

| Weight w                                                                                                                                                                                                                 | Multiplicity $A_w$                                                                                                                                              |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 0                                                                                                                                                                                                                        | 1                                                                                                                                                               |
| $q^{m-1}$                                                                                                                                                                                                                | $q^{m- A_1\cup A_2\cup A_3 }-1$                                                                                                                                 |
| $q^{m-1} - q^{ A_1 -1}$                                                                                                                                                                                                  | $q^{m- A_2\cup A_3 }-q^{m- A_1\cup A_2\cup A_3 }$                                                                                                               |
| $q^{m-1} - q^{ A_2 -1}$                                                                                                                                                                                                  | $q^{m- A_1\cup A_3 }-q^{m- A_1\cup A_2\cup A_3 }$                                                                                                               |
| $q^{m-1} - q^{ A_3 -1}$                                                                                                                                                                                                  | $q^{m- A_1\cup A_2 }-q^{m- A_1\cup A_2\cup A_3 }$                                                                                                               |
| $q^{m-1} - q^{ A_1 -1} - q^{ A_2 -1}$                                                                                                                                                                                    | $q^{m- A_3\cup(A_1\cap A_2) }-q^{m- A_1\cup A_3 }-q^{m- A_2\cup A_3 }+q^{m- A_1\cup A_2\cup A_3 }$                                                              |
| $q^{m-1} - q^{ A_1 -1} - q^{ A_2 -1} + q^{ A_1 \cap A_2 -1}$                                                                                                                                                             | $q^{m- A_3 } - q^{m- A_3 \cup (A_1 \cap A_2) }$                                                                                                                 |
| $q^{m-1} - q^{ A_1 -1} - q^{ A_3 -1}$                                                                                                                                                                                    | $q^{m- A_2\cup(A_1\cap A_3) }-q^{m- A_1\cup A_2 }-q^{m- A_2\cup A_3 }+q^{m- A_1\cup A_2\cup A_3 }$                                                              |
| $q^{m-1} - q^{ A_1 -1} - q^{ A_3 -1} + q^{ A_1 \cap A_3 -1}$                                                                                                                                                             | $q^{m- A_2 } - q^{m- A_2 \cup (A_1 \cap A_3) }$                                                                                                                 |
| $q^{m-1} - q^{ A_2 -1} - q^{ A_3 -1}$                                                                                                                                                                                    | $q^{m- A_1\cup (A_2\cap A_3) }-q^{m- A_1\cup A_2 }-q^{m- A_1\cup A_3 }+q^{m- A_1\cup A_2\cup A_3 }$                                                             |
| $q^{m-1} - q^{ A_2 -1} - q^{ A_3 -1} + q^{ A_2 \cap A_3 -1}$                                                                                                                                                             | $q^{m- A_1 } - q^{m- A_1 \cup (A_2 \cap A_3) }$                                                                                                                 |
| $q^{m-1} - \sum_{i=1}^{3} q^{ A_i -1}$                                                                                                                                                                                   | $q^{m- (A_1\cap A_2)\cup(A_1\cap A_3)\cup(A_2\cap A_3) }-q^{m- A_1\cup(A_2\cap A_3) }-q^{m- A_2\cup(A_1\cap A_3) }-q^{m- A_3\cup(A_1\cap A_2) }$                |
|                                                                                                                                                                                                                          | $+q^{m- A_1\cup A_2 }+q^{m- A_1\cup A_3 }+q^{m- A_2\cup A_3 }-q^{m- A_1\cup A_2\cup A_3 }$                                                                      |
| $q^{m-1} - \sum_{i=1}^{3} q^{ A_i -1} + q^{ A_2 \cap A_3 -1}$                                                                                                                                                            | $ q^{m- (A_1\cap A_2)\cup(A_1\cap A_3) }-q^{m- A_1 }-q^{m- (A_1\cap A_2)\cup(A_1\cap A_3)\cup(A_2\cap A_3) }+q^{m- A_1\cup(A_2\cap A_3) }$                      |
| $q^{m-1} - \sum_{i=1}^{3} q^{ A_i -1} + q^{ A_1 \cap A_3 -1}$                                                                                                                                                            | $ q^{m- (A_1\cap A_2)\cup (A_2\cap A_3) }-q^{m- A_2 }-q^{m- (A_1\cap A_2)\cup (A_1\cap A_3)\cup (A_2\cap A_3) }+q^{m- A_2\cup (A_1\cap A_3) }$                  |
| $\begin{array}{c} q^{m-1} - \sum_{i=1}^{3} q^{ A_i -1} + q^{ A_2 \cap A_3 -1} \\ q^{m-1} - \sum_{i=1}^{3} q^{ A_i -1} + q^{ A_1 \cap A_3 -1} \\ q^{m-1} - \sum_{i=1}^{3} q^{ A_i -1} + q^{ A_1 \cap A_2 -1} \end{array}$ | $ q^{m- (A_1\cap A_3)\cup (A_2\cap A_3) }-q^{m- A_3 }-q^{m- (A_1\cap A_2)\cup (A_1\cap A_3)\cup (A_2\cap A_3) }+q^{m- A_3\cup (A_1\cap A_2) }$                  |
| $q^{m-1} - \sum_{i=1}^{3} q^{ A_i -1} + q^{ A_1 \cap A_3 -1} + q^{ A_2 \cap A_3 -1}$                                                                                                                                     | $q^{m- A_1\cap A_2 }-q^{m- (A_1\cap A_2)\cup (A_1\cap A_3) }-q^{m- (A_1\cap A_2)\cup (A_2\cap A_3) }+q^{m- (A_1\cap A_2)\cup (A_1\cap A_3)\cup (A_2\cap A_3) }$ |
| $q^{m-1} - \sum_{i=1}^{3} q^{ A_i -1} + q^{ A_1 \cap A_2 -1} + q^{ A_2 \cap A_3 -1}$                                                                                                                                     | $q^{m- A_1\cap A_3 }-q^{m- (A_1\cap A_2)\cup (A_1\cap A_3) }-q^{m- (A_1\cap A_3)\cup (A_2\cap A_3) }+q^{m- (A_1\cap A_2)\cup (A_1\cap A_3)\cup (A_2\cap A_3) }$ |
| $q^{m-1} - \sum_{i=1}^{3} q^{ A_i -1} + q^{ A_1 \cap A_2 -1} + q^{ A_1 \cap A_3 -1}$                                                                                                                                     | $q^{m- A_2\cap A_3 }-q^{m- (A_1\cap A_2)\cup (A_2\cap A_3) }-q^{m- (A_1\cap A_3)\cup (A_2\cap A_3) }+q^{m- (A_1\cap A_2)\cup (A_1\cap A_3)\cup (A_2\cap A_3) }$ |
| $q^{m-1} - \sum_{i=1}^{3} q^{ A_i -1} + \sum_{1 \le i < j \le 3} q^{ A_i \cap A_j -1}$                                                                                                                                   | $q^{m- A_1\cap A_2\cap A_3 }-q^{m- A_1\cap A_2 }-q^{m- A_1\cap A_3 }-q^{m- A_2\cap A_3 }+q^{m- (A_1\cap A_2)\cup (A_1\cap A_3) }$                               |
| $q - \sum_{i=1}^{q} q^{i-1} + \sum_{1 \leq i < j \leq 3} q^{i-j-1}$                                                                                                                                                      | $+q^{m- (A_1\cap A_2)\cup(A_2\cap A_3) }+q^{m- (A_1\cap A_3)\cup(A_2\cap A_3) }-q^{m- (A_1\cap A_2)\cup(A_1\cap A_3)\cup(A_2\cap A_3) }$                        |
| $m-1$ $-1$ $+\mathbf{A}$ $+$                                                                                                                                                                                             | $m = M - A_1 \cap A_2 \cap A_2$                                                                                                                                 |

Weight distribution of  $\mathcal{C}_{\overline{\Lambda}^c}$  in Theorem 4

- 2)  $C_{\Lambda^c}$  is a near Griesmer code if one of the followings holds: i)  $|A_i \cap A_j| = 1$  for only one element (i,j) in the set  $\{(i,j): 1 \le i < j \le 3\}$  and  $|A_i \cap A_j| = 0$  for the other two (i,j)'s, and at most q-1of  $|A_i|$ 's are the same; ii) q = 3,  $|A_i \cap A_j| = 0$  for  $1 \le i < j \le 3$ , and  $|A_1| = |A_2| = |A_3|$ ; and iii) q = 2,  $|A_i \cap A_j| = 0$  for  $1 \le i < j \le 3$ , and  $|A_1| = |A_2| < |A_3| - 1$  or  $|A_1| \le |A_2| = |A_3|$ . 3)  $C_{\overline{\Lambda}^c}$  is distance-optimal if  $(q - 1)(v(T) + 1) + \ell(T) - 1 > \sum_{1 \le i < j \le 3} q^{|A_i \cap A_j|} - q^{|A_1 \cap A_2 \cap A_3|}$ .

*Proof.* The parameters of  $C_{\overline{\Delta}^c}$  follow directly from 1) of Theorem 1. By using the formula given in 4) of Theorem 1, the weight distribution of  $C_{\overline{\Lambda}^c}$  can be obtained as R runs through all subsets of  $\Omega = \{S : S \subseteq A\}$  $\mathcal{A}, S \neq \emptyset$  = { { $A_1$ }, { $A_2$ }, { $A_3$ }, { $A_1, A_2$ },  $\overline{\{A_1, A_3\}}$ , { $A_2, A_3$ }, { $A_1, A_2, A_3$ } }. Then the weight distribution of  $\mathcal{C}_{\overline{\Lambda}^c}$  is given as in Table I by a routine computation step by step. Next we discuss the optimality of  $\mathcal{C}_{\overline{\Lambda}^c}$ . Note that the length of  $\mathcal{C}_{\overline{\Delta}^c}$  is  $n = \frac{1}{q-1}(q^m - |\Delta|)$  and the minimum distance of  $\mathcal{C}_{\overline{\Delta}^c}$  is  $d = q^{m-1} - q^m$  $\sum_{1 < i < 3} q^{|A_i|-1}$ . By Lemma 2, we have

<span id="page-14-1"></span>
$$g(m,d) = \frac{1}{q-1} (q^m - \sum_{1 \le i \le 3} q^{|A_i|} + \ell(T) - 1), \tag{23}$$

where  $T = \sum_{1 \le i \le 3} q^{|A_i|-1}$ . It can be readily verified that when q > 3,  $\ell(T) = 3$ ; when q = 3,  $\ell(T) = 1$  if  $|A_1| = |A_2| = |\overline{A_3}|$  and  $\ell(T) = 3$  otherwise; and when q = 2, it gives

$$\ell(T) = \begin{cases} 1, & \text{if } |A_1| = |A_2| = |A_3| - 1; \\ 2, & \text{if } |A_1| = |A_2| < |A_3| - 1 \text{ or } |A_1| \le |A_2| = |A_3|; \\ 3, & \text{otherwise.} \end{cases}$$

According to 2) of Theorem 1, it proves part 1). If one of the conditions i), ii) and iii) in part 2) is satisfied, one has n-g(m,d)=1 by (23) and the values of n and  $\ell(T)$ , which implies that  $\mathcal{C}_{\overline{\Delta}^c}$  is a near Griesmer code. This proves part 2). Part 3) follows directly from 3) of Theorem 1. This completes the proof.

**Remark 7.** To the best of our knowledge, our result in Theorem 4 is the first to construct linear codes by employing simplicial complexes with more than two maximal elements in the literature.

**Remark 8.** Note that  $v(T) \ge |A_1| - 1$  and  $1 \le \ell(T) \le 3$  in Theorem 4 by the definition. Therefore, the sufficient condition  $(q-1)(v(T)+1) + \ell(T) - 1 > \sum_{1 \le i < j \le 3} q^{|A_i \cap A_j|} - q^{|A_1 \cap A_2 \cap A_3|}$  in 3) of Theorem 4 such that  $C_{\overline{\Delta}^c}$  is distance-optimal can be easily satisfied if  $|A_1|$  is large enough and  $|A_i \cap A_j|$ 's for  $1 \le i < j \le 3$  are small enough. Hence many distance-optimal linear codes can be obtained from Theorem 4.

**Example 4.** Let q = 3, m = 5,  $A_1 = \{1\}$ ,  $A_2 = \{2\}$  and  $A_3 = \{3\}$ . Magma experiments show that  $C_{\overline{\Delta}^c}$  is a [118, 5, 78] linear code over  $\mathbb{F}_3$  with weight enumerator  $1 + 72z^{78} + 108z^{79} + 54z^{80} + 8z^{81}$ , which is consistent with our result in Theorem 4. This code is a near Griesmer code by the Griesmer bound and is optimal due to [17].

**Example 5.** Let q = 3, m = 5,  $A_1 = \{1,2\}$ ,  $A_2 = \{1,3\}$  and  $A_3 = \{4\}$ . Magma experiments show that  $C_{\overline{\Delta}^c}$  is a [113,5,74] linear code over  $\mathbb{F}_3$  with weight enumerator  $1 + 24z^{74} + 120z^{75} + 54z^{76} + 24z^{77} + 12z^{78} + 6z^{80} + 2z^{81}$ , which is consistent with our result in Theorem 4. This code is a near Griesmer code by the Griesmer bound and is almost optimal due to [17].

**Example 6.** Let q = 2, m = 12,  $A_1 = \{1,2,3,4,5\}$ ,  $A_2 = \{1,2,6,7,8,9\}$  and  $A_3 = \{1,3,4,6,7,8,10,11\}$ . Magma experiments show that  $C_{\overline{\Delta}^c}$  is a [3770,12,1872] linear code over  $\mathbb{F}_2$  with weight enumerator  $1 + 6z^{1872} + 24z^{1874} + 48z^{1876} + 96z^{1878} + 112z^{1880} + 224z^{1882} + 672z^{1884} + 2048z^{1885} + 672z^{1886} + 6z^{1888} + 112z^{1896} + 6z^{1904} + 48z^{1908} + 6z^{1920} + 2z^{2000} + 8z^{2002} + 2z^{2016} + 2z^{2032} + z^{2048}$ , which is consistent with our result in Theorem 4. This is actually a 19-weight code, which means that every possible Hamming weight of  $C_{\overline{\Delta}^c}$  in Table I can be achieved. In addition, by the Griesmer bound, an upper bound of the minimum distance for a [3770,12] code over  $\mathbb{F}_q$  is given by 1884 which is quite close to 1872 due to 1872/1884  $\approx 0.99363$ .

### V. A COMPARISON TO THE PREVIOUS WORKS

<span id="page-15-0"></span>Note that infinite families of (distance-)optimal codes over  $\mathbb{F}_q$  can be produced from our codes  $\mathcal{C}_{\overline{\Delta}^c}$  and the parameters of  $\mathcal{C}_{\overline{\Delta}^c}$  over  $\mathbb{F}_q$  are very flexible. Now we compare our codes  $\mathcal{C}_{\overline{\Delta}^c}$  with the known (distance-)optimal linear codes in the previous works. At first, it can be readily checked that our codes  $\mathcal{C}_{\overline{\Delta}^c}$  constructed in this paper have different parameters to the optimal linear codes in [20], [21], [25], [29], [30], [38], [39], [43], [51]. Next, we make the comparison of our optimal codes to the known ones with similar parameters (see their parameters in Table II) as follows:

- Our codes  $C_{\overline{\Delta}^c}$  over  $\mathbb{F}_q$  are new for q>2 compared to the binary linear codes of [27] since our results extend those of [27] from  $\mathbb{F}_2$  to  $\mathbb{F}_q$ . Moreover, when q=2, compared to [27], we further investigate the weight distribution of  $C_{\overline{\Delta}^c}$  for the general case and take a more in-depth discussion on the case of simplicial complexes with three maximal elements.
- Our codes  $\mathcal{C}_{\overline{\Delta}^c}$  over  $\mathbb{F}_q$  are different from the well-known Solomon-Stiffler codes [40] over  $\mathbb{F}_q$  except when  $|A_i \cap A_j| = 0$  for any  $1 \leq i < j \leq h$  and at most q-1 of  $|A_i|$ 's are the same, in which case  $\mathcal{C}_{\overline{\Delta}^c}$  is a Griesmer code (see Theorem 1). Viewed from the construction approach, the Solomon-Stiffler codes are constructed from the complement of the union of disjoint projective subspaces of PG(m-1,q) where at most q-1 of these subspaces have the same dimension, while our codes  $\mathcal{C}_{\overline{\Delta}^c}$  are constructed from  $\overline{\Delta}^c$  which can be viewed as the complement of the union of projective subspaces of PG(m-1,q) without the restriction "disjoint" and that on the number of subspaces with the same dimension. This is their crucial difference.
- Our codes  $C_{\overline{\Delta}^c}$  over  $\mathbb{F}_q$  are different from those of [22] in general even though our codes have the same parameters as those of [22] in some special cases. Note that the codes of [22, Theorem 1] were constructed from the complement of the union of some distinct subfields  $\mathbb{F}_{q^{r_i}}$  of  $\mathbb{F}_{q^m}$ , where  $r_i$ 's divide m and any two subfields  $\mathbb{F}_{q^{r_{i1}}}$  and  $\mathbb{F}_{q^{r_{i2}}}$  must intersect in the subfield  $\mathbb{F}_{q^r}$  of  $\mathbb{F}_{q^m}$  with  $r = \gcd(r_{i1}, r_{i2})$ . However, our  $|A_i|$ 's in  $\overline{\Delta}^c$  are not necessary to divide m and any two distinct projective subspaces

- of  $\operatorname{PG}(m-1,q)$  with fixed dimensions in  $\overline{\Delta}^c$  can be disjoint or intersect in some projective subspace with any dimension. Therefore, the parameters of our codes  $\mathcal{C}_{\overline{\Delta}^c}$  are more flexible than those of [22, Theorem 1] in the projective case even though their parameters have the same form (see Table II). When  $|A_1| = \cdots = |A_h| = \ell$  and  $\ell$  divides m, our codes  $\mathcal{C}_{\overline{\Delta}^c}$  have the same parameters as those of [22, Theorem 3] in the projective case. When h=2, our codes  $\mathcal{C}_{\overline{\Delta}^c}$  (see Theorem 3) have more flexible parameters than those of [22, Theorem 4] and [22, Theorem 5] in the projective case even though their parameters have the same form in this case; in addition, they have different weight distributions.
- Our codes  $C_{\overline{\Delta}^c}$  over  $\mathbb{F}_q$  are different from these (distance-)optimal codes in [6], [26], [32], [45], [46] since the parameters of our codes are more flexible. However, our codes have the same parameters with these codes in some special cases. When h=1 and  $|A_1|=1$ , h=2 and  $|A_1|=|A_2|=1$ , and (q,h)=(2,2),  $|A_1|=2$ ,  $|A_2|=m-1$  and  $|A_1\cap A_2|=1$ , our codes  $C_{\overline{\Delta}^c}$  have the same parameters with those of [32, Thm. 18], [32, Thm. 19] and [32, Thm. 22], respectively. When (q,h)=(2,1) and m is even, our code  $C_{\overline{\Delta}^c}$  has the same parameters with that of [45, Thm. 5.2] and it reduces to the code of [46, Thm. 4.3] if  $|A_1|=m-1$ . When (q,h)=(2,2),  $|A_1|=1$  and  $|A_2|=m-1$ , our code  $C_{\overline{\Delta}^c}$  has the same parameters as the optimal binary codes in [6], [32]. When (q,h)=(2,2),  $|A_1|=1$  (resp. (q,h)=(2,2),  $|A_1|=2$  and  $|A_1\cap A_2|=1$ ), our code  $C_{\overline{\Delta}^c}$  has the same parameters with that of [26, Thm. 6.1] (resp. [26, Thm. 6.2]).

TABLE II The parameters [n,k,d] of some (distance-)optimal linear codes over  $\mathbb{F}_q$ 

<span id="page-16-1"></span>

| No. | q   | n                                                                          | k          | d                                            | Remarks                       |
|-----|-----|----------------------------------------------------------------------------|------------|----------------------------------------------|-------------------------------|
| 1   | 2   | $2^{m}-1$                                                                  | m+1        | $2^{m-1}-1$                                  | m > 1, [6], [32]              |
| 2   | 2   | $2^{m}-2$                                                                  | m+1        | $2^{m-1}-2$                                  | $m \ge 3$ , [32, Thm. 22]     |
| 3   | 2   | $2^{2m-1}$                                                                 | 2 <i>m</i> | $2^{2m-2}$                                   | [46, Thm. 4.3]                |
| 4   | 2   | $2^n - 2^m - 1$                                                            | n          | $2^{n-1} - 2^{m-1} - 1$                      | 2 < m < n, [26, Thm. 6.1]     |
| 5   | 2   | $2^n - 2^m - 2$                                                            | n          | $2^{n-1}-2^{m-1}-2$                          | 1 < m < n - 1, [26, Thm. 6.2] |
| 6   | 2   | $2^{2m} - 2^{ A  +  B }$                                                   | 2 <i>m</i> | $2^{2m-1} - 2^{ A + B -1}$                   | [45, Thm. 5.2]                |
| 7   | 2   | $2^n - \sum_{0 \neq S \subseteq \mathcal{F}} (-1)^{ S -1} 2^{ S }$         | n          | $2^{n-1} - \sum_{i=1}^{s} 2^{ A_i -1}$       | [27]                          |
| 8   | any | $(q^m - q)/(q - 1) - 1$                                                    | m          | $q^{m-1}-1$                                  | [32, Thm. 18]                 |
| 9   | any | $(q^m - 2q + 1)/(q - 1)$                                                   | m          | $q^{m-1}-2$                                  | $m \ge 2$ , [32, Thm. 19]     |
| 10  | any | $q^m - \sum_{\emptyset \neq S \subseteq \Upsilon} (-1)^{ S -1} q^{r_S}$    | m          | $(q-1)(q^{m-1}-\sum_{i=1}^{h}q^{r_i-1})$     | [22, Thm. 1]                  |
| 11  | any | $q^m - (h+1)q^r$                                                           | m          | $(q-1)(q^{m-1}-(h+1)q^{r-1})$                | $h+1 \le q$ , [22, Thm. 2]    |
| 12  | any | $q^m - (h+1)q^r$                                                           | m          | $(q-1)q^{m-1} - hq^r$                        | h+1 > q, [22, Thm. 2]         |
| 13  | any | $q^m - hq^r + h - 1$                                                       | m          | $(q-1)(q^{m-1}-hq^{r-1})$                    | [22, Thm. 3]                  |
| 14  | any | $(q^m - q^r)(q^k - q^s)$                                                   | m+k        | $(q-1)(q^{m+k-1}-q^{m+s-1}-q^{k+r-1})$       | [22, Thm. 4]                  |
| 15  | any | $q^{m+k} - q^m - q^k + 1$                                                  | m+k        | $(q-1)(q^{m+k-1}-q^{m-1}-q^{k-1})$           | [22, Thm. 5]                  |
| 16  | any | $(q^m - 1 - \sum_{i=1}^h (q^{u_i} - 1))/(q - 1)$                           | m          | $q^{m-1} - \sum_{i=1}^{h} q^{u_i-1}$         | Solomon-Stiffler code [40]    |
| 17  | any | $(q^m - \sum_{0 \neq S \subseteq \mathcal{A}} (-1)^{ S -1} q^{ S })/(q-1)$ | m          | $q^{m-1} - \sum_{1 \le i \le h} q^{ A_i -1}$ | This paper                    |

#### VI. CONCLUDING REMARKS

<span id="page-16-0"></span>The main contributions of this paper are summarized as follows:

- We constructed a large family of projective linear codes  $C_{\overline{\Delta}^c}$  over  $\mathbb{F}_q$  from the general simplicial complexes  $\Delta$  of  $\mathbb{F}_q^m$  via the defining-set construction. This totally extends the results of [27] from  $\mathbb{F}_2$  to  $\mathbb{F}_q$ . To the best of our knowledge, this paper is the first to study linear codes over  $\mathbb{F}_q$  constructed from the general simplicial complexes of  $\mathbb{F}_q^m$  for a prime power q > 2.
- from the general simplicial complexes of F<sub>q</sub><sup>m</sup> for a prime power q > 2.
  The parameters and weight distribution of C<sub>∆</sub><sup>c</sup> were completely determined (see Theorem 1) in this paper. Thus this paper also determines the weight distribution of the binary codes constructed from the general simplicial complexes of F<sub>2</sub><sup>m</sup> in [27, Theorem IV.6], in which the weight distribution of the binary codes were studied only for the case of simplicial complexes of F<sub>2</sub><sup>m</sup> with two maximal elements. Moreover, as a byproduct, the weight distributions of the Solomon-Stiffler codes are determined in

Corollary 1 for the case that the corresponding subspaces in  $\mathbb{F}_q^m$  of the projective subspaces  $U_i$  are spanned by some subsets of a certain basis of  $\mathbb{F}_q^m$ .

- By using the Griesmer bound, we gave a necessary and sufficient condition such that  $C_{\overline{\Delta}^c}$  is a Griesmer code and a sufficient condition such that  $C_{\overline{\Delta}^c}$  is distance-optimal. In addition, we also presented a necessary and sufficient condition for  $C_{\overline{\Delta}^c}$  to be a near Griesmer code in a special case. This shows that many infinite families of (distance-)optimal linear codes can be produced from our construction.
- By studying the cases of the simplicial complexes  $\Delta$  with one, two and three maximal elements respectively, we presented the parameters and weight distributions of these codes  $\mathcal{C}_{\overline{\Delta}^c}$  more explicitly, and derived infinite families of optimal linear codes with few weights over  $\mathbb{F}_q$  including Griesmer codes, near Griesmer codes and distance-optimal codes (see Theorems 2, 3 and 4).
- Most notably, the definition of simplicial complexes of \( \mathbb{F}\_q^m \) of this paper and the main technique used to prove the results in this paper can also be employed to extend the previous results of [6], [29], [44]–[46], [51], where simplicial complexes of \( \mathbb{F}\_2^m \) with one and two maximal elements were utilized to constructed optimal few-weight binary or quaternary linear codes.

The construction of optimal linear codes is an interesting problem. The reader is cordially invited to construct more new optimal linear codes.

#### REFERENCES

- <span id="page-17-26"></span><span id="page-17-10"></span>[1] M. Adamaszek, Face numbers of down-sets, Amer. Math. Monthly 122(4) (2015), pp. 367-370.
- <span id="page-17-24"></span>[2] R. Anderson, C. Ding, T. Hellsesth, T. Kløve, How to build robust shared control systems, Des. Codes Cryptogr. 15(2) (1998), pp. 111-124.
- <span id="page-17-14"></span>[3] A. Ashikhmin, A. Barg, Minimal vectors in linear codes, IEEE Trans. Inf. Theory 44(5) (1998), pp. 2010-2017.
- <span id="page-17-11"></span>[4] A. R. Calderbank, J. Goethals, Three-weight codes and association schemes, Philips J. Res. 39(4-5) (1984), pp. 143-152.
- [5] C. Carlet, C. Ding, J. Yuan, Linear codes from perfect nonlinear mappings and their secret sharing schemes, IEEE Trans. Inf. Theory 51(6) (2005), pp. 2089-2102.
- <span id="page-17-22"></span><span id="page-17-2"></span>[6] S. Chang, J.Y. Hyun, Linear codes from simplicial complexes, Des. Codes Cryptogr. 86 (2018), pp. 2167-2181.
- <span id="page-17-3"></span>[7] C. Ding, Codes from Difference Sets, World Scientific, Singapore (2015).
- <span id="page-17-18"></span>[8] C. Ding, Designs from Linear Codes, World Scientific, Singapore (2018).
- <span id="page-17-15"></span>[9] C. Ding, A construction of binary linear codes from Boolean functions, Discrete Math. 339(9) (2016), pp. 2288-2303.
- <span id="page-17-27"></span>[10] C. Ding, Linear codes from some 2-designs, IEEE Trans. Inf. Theory 61(6) (2015), pp. 3265-3275.
- <span id="page-17-16"></span>[11] C. Ding, The construction and weight distributions of all projective binary linear codes, 2020, arXiv:2010.03184v2.
- [12] K. Ding, C. Ding, A class of two-weight and three-weight codes and their applications in secret sharing, IEEE Trans. Inf. Theory 61(11) (2015), pp. 5835-5842.
- <span id="page-17-12"></span>[13] C. Ding, T. Helleseth, T. Kløve, X. Wang, A generic construction of cartesian authentication codes, IEEE Trans. Inf. Theory 53(6) (2007), pp. 2229-2235.
- <span id="page-17-20"></span><span id="page-17-17"></span>[14] C. Ding, H. Niederreiter, Cyclotomic linear codes of order 3, IEEE Trans. Inf. Theory 53(6) (2007), pp. 2274-2277.
- <span id="page-17-13"></span>[15] C. Ding, C. Tang, The linear codes of *t*-designs held in the Reed-Muller and Simplex codes, Cryptogr. Commun. 13 (2021), pp. 927-949.
- <span id="page-17-28"></span>[16] C. Ding, X. Wang, A coding theory construction of new systematic authentication codes, Theor. Comput. Sci. 330(1) (2005), pp. 81-99.
- <span id="page-17-1"></span>[17] M. Grassl, Bounds on the minimum distance of linear codes, Online available at http://www.codetables.de, Accessed on 2022-10-11.
- [18] J.H. Griesmer, A bound for error correcting codes, IBM J. Res. Dev. 4 (1960), pp. 532-542.
- <span id="page-17-5"></span>[19] T. Helleseth, Projective codes meeting the Griesmer bound, Discrete Math. 106/107 (1992), pp. 265-271.
- <span id="page-17-21"></span>[20] Z. Heng, C. Ding, W. Wang, Optimal binary linear codes from maximal arcs, IEEE Trans. Inf. Theory 66(9) (2020), pp. 5387-5394.
- <span id="page-17-4"></span>[21] Z. Heng, Projective linear codes from some almost difference sets, IEEE Trans. Inf. Theory, 2022, doi: 10.1109/TIT.2022.3203380.
- [22] Z. Hu, N. Li, X. Zeng, L. Wang, X. Tang, A subfield-based construction of optimal linear codes over finite fields, IEEE Trans. Inf. Theory 68(7) (2022), pp. 4408-4421.
- <span id="page-17-19"></span>[23] Z. Hu, L. Wang, N. Li, X. Zeng, Several classes of linear codes with few weights from the closed butterfly structure, Finite Fields Appl. 76 (2021), 101926.
- <span id="page-17-6"></span><span id="page-17-0"></span>[24] W. Huffman, V. Pless, Fundamentals of error-correcting codes, Cambridge University Press (1997).
- [25] J.Y. Hyun, H.K. Kim, M. Na, Optimal non-projective linear codes constructed from down-sets, Discrete Appl. Math. 254 (2019), pp. 135-145.
- <span id="page-17-23"></span><span id="page-17-7"></span>[26] J.Y. Hyun, H.K. Kim, Y. Wu, Q. Yue, Optimal minimal linear codes from posets, Des. Codes Cryptogr. 88 (2020), pp. 2475-2492.
- [27] J.Y. Hyun, J. Lee, Y. Lee, Infinite families of optimal linear codes constructed from simplicial complexes, IEEE Trans. Inf. Theory 66(11) (2020), pp. 6762-6773.
- <span id="page-17-25"></span><span id="page-17-9"></span>[28] T. Kløve, Codes for Error Detection, World Scientfic: Singapore, 2007.
- [29] X. Li, M. Shi, A new family of optimal binary few-weight codes from simplicial complexes, IEEE Communications Letters 25(4) (2021), pp. 1048-1051.
- <span id="page-17-8"></span>[30] X. Li, Q. Yue, D. Tang, A family of linear codes from constant dimension subspace codes, Des. Codes Cryptogr. 90 (2022), pp. 1-15.
- [31] R. Lidl, H. Niederreiter, Finite Fields, Encyclopedia of Mathematics, vol. 20, Cambridge University Press, Cambridge (1983).

- <span id="page-18-15"></span><span id="page-18-1"></span>[32] Y. Liu, C. Ding, C. Tang, Shortened linear codes over finite fields, IEEE Trans. Inf. Theory 67(8) (2021), pp. 5119-5132.
- <span id="page-18-4"></span>[33] G. Luo, X. Cao, Constructions of optimal binary locally recoverable codes via a general construction of linear codes, IEEE Trans. Commun. 69(8) (2021), pp. 4987-4997.
- [34] S. Mesnager, Linear codes with few weights from weakly regular bent functions based on a generic construction, Cryptogr. Commun. 9 (2017), pp. 71-84.
- [35] S. Mesnager, F. Ozbudak, A. Sınak, Linear codes from weakly regular plateau ¨ ed functions and their secret sharing schemes, Des. Codes Cryptogr. 87(2-3) (2019), pp. 463-480.
- <span id="page-18-5"></span>[36] S. Mesnager, Y. Qi, H. Ru, C. Tang, Minimal linear codes from characteristic functions, IEEE Trans. Inf. Theory 66(9) (2020), pp. 5404-5413.
- [37] S. Mesnager, A. Sınak, Several classes of minimal linear codes with few weights from weakly regular plateaued functions, IEEE Trans. Inf. Theory 66(4) (2020), pp. 2296-2310.
- <span id="page-18-14"></span><span id="page-18-12"></span>[38] Y. Pan, Y. Liu, New classes of few-weight ternary codes from simplicial complexes, AIMS Math. 7(3) (2022), pp. 4315-4325.
- <span id="page-18-0"></span>[39] M. Shi, X. Li, Two classes of optimal *p*-ary few-weight codes from down-sets, Discret. Appl. Math. 290 (2021), pp. 60-67.
- <span id="page-18-6"></span>[40] G. Solomon, J.J. Stiffler, Algebraically punctured cyclic codes, Inform. and Control 8 (1965), pp. 170-179.
- [41] C. Tang, N. Li, Y. Qi, Z. Zhou, T. Helleseth, Linear codes with two or three weights from weakly regular bent functions, IEEE Trans. Inf. Theory 62(3) (2016), pp. 1166-1176.
- <span id="page-18-8"></span>[42] C. Tang, C. Xiang, K. Feng, Linear codes with few weights from inhomogeneous quadratic functions, Des. Codes Cryptogr. 83 (2017), pp. 691-714.
- <span id="page-18-13"></span>[43] Y. Wu, J.Y. Hyun, Few-weight codes over F*<sup>p</sup>* +*u*F*<sup>p</sup>* associated with down sets and their distance optimal Gray image, Discret. Appl. Math. 283 (2020), pp. 315-322.
- <span id="page-18-10"></span>[44] Y. Wu, Y. Lee, Binary LCD codes and self-orthogonal codes via simplicial complexes, IEEE Communications Letters 24(6) (2020), pp. 1159-1162.
- <span id="page-18-3"></span><span id="page-18-2"></span>[45] Y. Wu, C. Li, F. Xiao, Quaternary linear codes and related binary subfield codes, IEEE Trans. Inf. Theory 68(5) (2022), pp. 3070-3080.
- <span id="page-18-16"></span>[46] Y. Wu, X. Zhu, Q. Yue, Optimal few-weight codes from simplicial complexes, IEEE Trans. Inf. Theory 66(6) (2020), pp. 3657-3663.
- <span id="page-18-17"></span>[47] C. Xiang, It is indeed a fundamental construction of all linear codes, 2016, [arXiv:1610.06355.](http://arxiv.org/abs/1610.06355)
- [48] M. Yang, J. Li, K. Feng, D. Lin, Generalized Hamming weights of irreducible cyclic codes, IEEE Trans. Inf. Theory 61(9) (2015), pp. 4905-4913.
- <span id="page-18-9"></span><span id="page-18-7"></span>[49] Z. Zhou, Three-weight ternary linear codes from a family of cyclic difference sets, Des. Codes Cryptogr. 86 (2018), pp. 2513-2523.
- [50] Z. Zhou, N. Li, C. Fan, T. Helleseth, Linear codes with two or three weights from quadratic Bent functions, Des. Codes Cryptogr. 81 (2016), pp. 283-295.
- <span id="page-18-11"></span>[51] X. Zhu, Y. Wei, Few-weight quaternary codes via simplicial complexes, AIMS Math. 6(5) (2021), pp. 5124-5132.