#### Two-Weight and a Few Weights Trace Codes over F<sup>q</sup> + uF<sup>q</sup> ∗

#### Hongwei Liu<sup>1</sup> , Youcef Maouche<sup>1</sup>,<sup>2</sup>

1 School of Mathematics and Statistics, Central China Normal University,Wuhan, Hubei, 430079, China <sup>2</sup>Department of Mathematics, University of Sciences and Technology HOUARI BOUMEDIENE, Alger, Algeria

> Abstract. Let p be a prime number, q = p s for a positive integer s. For any positive divisor e of q − 1, we construct an infinite family codes of size q <sup>2</sup><sup>m</sup> with few Lee-weight. These codes are defined as trace codes over the ring R = F<sup>q</sup> + uFq, u <sup>2</sup> = 0. Using Gauss sums, their Lee weight distributions are provided. When gcd(e, m) = 1, we obtain an infinite family of two-weight codes over the finite field F<sup>q</sup> which meet the Griesmer bound. Moreover, when gcd(e, m) = 2, 3 or 4 we construct new infinite family codes with at most five-weight.

> Keywords. Two-weight codes; Three-weight codes; Codes over rings; Trace codes; Gauss sums.

2010 Mathematics Subject Classification. 94B05, 94B15.

# 1 Introduction

Let F<sup>q</sup> be the finite field of order q, where q = p s is a power of a prime p for some integer s. A [n, k, d] linear code C of length n over F<sup>q</sup> is a k-dimensional subspace of F n <sup>q</sup> with minimum Hamming distance d. Let A<sup>i</sup> denote the number of codewords with Hamming weight i in a code C of length n. The weight enumerator of a linear code C is defined to be the polynomial A(z) = 1 + A1z + A2z <sup>2</sup> + ... + Anz <sup>n</sup>. The sequence (1, A1, ..., An) is called the weight distribution of the code, and it is an important research topic to determine the weight distribution of a linear code in coding theory, since the weight distributions of codes contain crucial information, such as to estimate the error correcting capability and the probability of error detection and correction of codes with respect to some decoding algorithms. A code C is said to be a t-weight code if the number of nonzero A<sup>i</sup> in the sequence (A1, A2, ..., An) is equal to t. The class of codes with few weights are an important class in coding theory, and they have been studied in many articles, see for instance [\[1,](#page-14-0) [3,](#page-14-1) [15\]](#page-14-2).

<sup>∗</sup>E-Mail addresses: hwliu@mail.ccnu.edu.cn (H. Liu), m.youcef@mails.ccnu.edu.cn (Y. Maouche).

Let  $r = q^m$  for some positive integer m, and let  $Tr_{r/q}(\cdot)$  denote the trace function from  $\mathbb{F}_r$  to  $\mathbb{F}_q$ . Let  $D = \{d_1, d_2, ..., d_n\} \subseteq \mathbb{F}_r^*$  be a subset of  $\mathbb{F}_r^*$ , where  $\mathbb{F}_r^* = \mathbb{F}_r - \{0\}$ , we define a linear code of length n over  $\mathbb{F}_q$  by

$$C_D = \{(Tr_{r/q}(xd_1), Tr_{r/q}(xd_2), ..., Tr_{r/q}(xd_n)) | x \in \mathbb{F}_r \}.$$

The code  $C_D$  is called a trace code over  $\mathbb{F}_q$ , and the set D is called defining set of the code. It is well-known that many linear codes could be produced by selecting the defining set (see for instance [1, 4, 2, 7]). In a series of papers [12, 13], the notion of trace codes has been extended from finite fields to finite rings as follows. Let R be a finite commutative ring, and  $R_m$  an extension of R of degree m, a trace code with a defining set  $L = \{d_1, d_2, ..., d_n\} \subseteq R_m^*$  is defined by the following formula

<span id="page-1-0"></span>
$$C_L = \{ (Tr(xd_1), Tr(xd_2), ..., Tr(xd_n)) \mid x \in R_m \},$$
(1)

where  $R_m^*$  is the multiplicative group of units of  $R_m$ , and  $Tr(\cdot)$  is a linear function from  $R_m$  to R.

The class of finite rings of the form  $R = \mathbb{F}_q + u\mathbb{F}_q$ ,  $u^2 = 0$ , has been used widely as alphabets in certain codes. Throughout this paper we let  $R = \mathbb{F}_q + u\mathbb{F}_q$  and  $\mathcal{R} = \mathbb{F}_r + u\mathbb{F}_r$  be an extension of R. The Lee weight distribution of the trace code  $C_L$  define by Equation (1) is settled for a few special cases and is quite complex in general. The following special cases of trace codes have been studied in the literature.

- (i)  $R = \mathbb{F}_2 + u\mathbb{F}_2, u^2 = 0$ ;  $\mathcal{R} = \mathbb{F}_{2^m} + u\mathbb{F}_{2^m}, L = \mathcal{R}^* = \mathbb{F}_{2^m}^* + u\mathbb{F}_{2^m}$ . Then the code  $C_L$  is a two-weight code respect to Lee weight (see [12]).
- (ii)  $R = \mathbb{F}_p + u\mathbb{F}_p, u^2 = 0$ ;  $\mathcal{R} = \mathbb{F}_{p^m} + u\mathbb{F}_{p^m}, L = \mathcal{Q} + u\mathbb{F}_{p^m} \subsetneq \mathcal{R}^*$ , where p is an odd prime and  $\mathcal{Q}$  is the set of all square elements of  $\mathbb{F}_{p^m}^*$ , then  $C_L$  is a two-weight or three-weight code respect to Lee weight (see [13]).

In this paper, we let  $R = \mathbb{F}_q + u\mathbb{F}_q$ ,  $u^2 = 0$ , where  $q = p^s$ , p is a prime. Let  $\mathcal{R} = \mathbb{F}_r + u\mathbb{F}_r$ , and  $L = C_0^{(e,r)} + u\mathbb{F}_r \subseteq \mathcal{R}^*$ , where e is a divisor of q-1 and  $C_0^{(e,r)}$  is the cyclotomic class of order e. The purpose of this paper is to investigate the Lee weight distribution of the trace code  $C_L$  with defining set L. We show that our main results include the results of [12] as a special case when p=2 and s=1. When e=2 and q is odd, then  $C_0^{(2,r)}=\mathcal{Q}$ . Therefore, our results also include the results of [13] as special cases. Furthermore, by taking  $\gcd(e,m)=3$  or 4 we construct new infinite family codes with at most five-weight.

This paper is organized as follows. In Section 2, we introduce some basic notations and definitions which will be used later. In this section, we also construct the code  $C_q(m, e)$  defined in Equation (4) (in Section 3) for any positive divisor e of q-1. Section 3 shows that the Lee weight distribution of the codes  $C_q(m, e)$  is related to the value of gcd(e, m). When gcd(e, m) = 1, we show that the codes defined and investigated in [12] are just special cases for q = 2 (see Corollary 3.4). Moreover, if gcd(e, m) = 1, our constructed codes achieve the Griesmer bound, and these codes are optimal for given length and dimension in few cases. We also investigate the cases where gcd(e, m) = 2 and gcd(e, m) = 1 and show that this cases are a generalization of the codes investigated in [13]. Furthermore, if gcd(e, m) = 3 or gcd(e, m) = 4, we construct new infinite families of codes with at most five-weight.

### 2 Preliminaries

Let  $R = \mathbb{F}_q + u\mathbb{F}_q$ , where  $u^2 = 0$ . A linear code C of length n over R is an R-submodule of  $R^n$ . Let  $\mathbf{x} = (x_1, x_2, ..., x_n)$  and  $\mathbf{y} = (y_1, y_2, ..., y_n)$  be two vectors of  $R^n$ , the inner product of  $\mathbf{x}$  and  $\mathbf{y}$  is defined by  $\langle \mathbf{x}, \mathbf{y} \rangle = \sum_{i=1}^n x_i y_i$ , where the operation is performed in R. The dual code  $C^{\perp}$  of C is defined as

$$C^{\perp} = \{ \mathbf{y} \in \mathbb{R}^n \mid \langle \mathbf{x}, \mathbf{y} \rangle = 0, \forall \, \mathbf{x} \in \mathbb{C} \}.$$

It is easy to verify that  $C^{\perp}$  is also a linear code over R.

For any  $a + ub \in R$ , where  $a, b \in \mathbb{F}_q$ , the *Gray map*  $\phi$  from R to  $\mathbb{F}_q^2$  is defined by

$$\phi: R \to \mathbb{F}_q^2, a + ub \mapsto (b, a + b).$$

Let  $\mathbf{x} \in R^n$ , then  $\mathbf{x}$  can be written as  $\mathbf{x} = \mathbf{a} + u\mathbf{b}$ , where  $\mathbf{a}, \mathbf{b} \in \mathbb{F}_q^n$ . The map  $\phi$  is a bijection, which can be extended naturally from  $R^n$  to  $\mathbb{F}_q^{2n}$  as follows.

$$\phi: \mathbb{R}^n \to \mathbb{F}_q^{2n}, \mathbf{x} = \mathbf{a} + u\mathbf{b} \mapsto (\mathbf{b}, \mathbf{a} + \mathbf{b}).$$

The Lee weight of a vector  $\mathbf{a} + u\mathbf{b}$  of length n over R is defined to be the Hamming weight of its Gray image as follows:

$$w_L(\mathbf{a} + u\mathbf{b}) = w_H(\mathbf{b}) + w_H(\mathbf{a} + \mathbf{b}),$$

where  $\mathbf{a}, \mathbf{b} \in \mathbb{F}_q^n$ . The *Lee distance* of  $\mathbf{x}, \mathbf{y} \in \mathbb{R}^n$  is defined as  $w_L(\mathbf{x} - \mathbf{y})$ . Thus the Gray map by construction is a linear isometry from  $(\mathbb{R}^n, d_L)$  to  $(\mathbb{F}_q^{2n}, d_H)$ .

Let  $\mathcal{R} = \mathbb{F}_r + u\mathbb{F}_r$ ,  $u^2 = 0$ , where  $r = q^m$  for some integer m, be the extension of the ring R. It is easy to see that the ring  $\mathcal{R}$  is a local ring with maximal ideal  $M = \langle u \rangle$ . The residue field  $\mathcal{R}/M$  is isomorphic to  $\mathbb{F}_r$ . The multiplicative group  $\mathcal{R}^*$  of all units in R, is isomorphic to the product of a cyclic group of order r-1 and an elementary abelian group of order r.

**Definition 2.1.** Let F be the Frobenius operator over  $\mathcal{R}$  defined by  $F(a+ub)=a^q+ub^q$ . The trace function, denoted by Tr is then defined by

$$Tr = \sum_{j=0}^{m-1} F^j : \mathcal{R} \to R, a + ub \mapsto \sum_{j=0}^{m-1} F^j(a + ub) = \sum_{j=0}^{m-1} (a^{q^j} + ub^{q^j}).$$

By the definition, it is easy to check that for any  $a+ub \in \mathcal{R}$ , where  $a,b \in \mathbb{F}_r$ , we have  $Tr(a+ub) \in \mathcal{R}$ , and in particular, we have

$$Tr(a+ub) = Tr_{r/q}(a) + uTr_{r/q}(b),$$

where  $Tr_{r/q}(\cdot)$  denotes the trace function from  $\mathbb{F}_r$  to  $\mathbb{F}_q$ .

**Definition 2.2.** An additive character of  $\mathbb{F}_q$  is a group homomorphism  $\chi$  from  $(\mathbb{F}_q, +)$  to the multiplicative group  $(\mathbb{C}^*, \cdot)$ , where  $\mathbb{C}^*$  is the set of all nonzero complex numbers.

Let  $Tr_{q/p}(\cdot)$  denote the trace function from  $\mathbb{F}_q$  to  $\mathbb{F}_p$ , and let  $i=\sqrt{-1}$  be the imaginary unit. It is easy to verify that for each  $b\in\mathbb{F}_q$ , the function

$$\chi_b(c) = e^{2i\pi T r_{q/p}(bc)/p}, \quad \text{for all } c \in \mathbb{F}_q,$$

defines an additive character of  $\mathbb{F}_q$ . When b = 0,  $\chi_0(c) = 1$  for all  $c \in \mathbb{F}_q$ , and it is called the trivial additive character of  $\mathbb{F}_q$ . The character  $\chi_1(c)$  is called the canonical additive character of  $\mathbb{F}_q$ .

**Definition 2.3.** A multiplicative character of  $\mathbb{F}_q$  is a group homomorphism  $\psi$  from  $(\mathbb{F}_q^*, \cdot)$  to the multiplicative group  $(\mathbb{C}^*, \cdot)$ , where  $\mathbb{C}^*$  is the set of all nonzero complex numbers.

Let g be a fixed primitive element of  $\mathbb{F}_q^*$ . For each j=0,1,...,q-2, the function  $\psi_j$  with

<span id="page-3-0"></span>
$$\psi_j(g^k) = e^{2i\pi jk/(q-1)}$$
 for  $k = 1, ..., q-1,$  (2)

is a multiplicative character of  $\mathbb{F}_q$ . In particular, if j=0, then  $\psi_0(x)=1$  for all  $x\in\mathbb{F}_q^*$ , and this character is called the *trivial multiplicative character* of  $\mathbb{F}_q$ .

Let q be odd and j = (q - 1)/2 in Equation (2), then we get a multiplicative character such that

$$\eta(g^k) = \psi_{\frac{q-1}{2}}(g^k) = \begin{cases} 1, & \text{if } k \text{ is even,} \\ -1, & \text{otherwise.} \end{cases}$$

This multiplicative character  $\eta$  is called the quadratic character of  $\mathbb{F}_q$ .

**Definition 2.4.** Let  $\psi$  be a multiplicative character and  $\chi$  an additive character of  $\mathbb{F}_q$  respectively. The Gaussian sum  $G(\psi, \chi)$  is defined as follows:

$$G(\psi, \chi) = \sum_{c \in \mathbb{F}_a^*} \psi(c) \chi(c).$$

**Remark 2.5.** In general, it is difficult to compute the value of the Gaussian sum  $G(\psi, \chi)$ . If  $\psi \neq \psi_0$  and  $\chi \neq \chi_0$ , then the absolute value of  $G(\psi, \chi)$  is  $q^{1/2}$  ([9]). If  $q = p^s$ , where p is an odd prime and s is a positive integer, then

<span id="page-3-2"></span>
$$G(\eta, \chi_1) = \begin{cases} (-1)^{s-1} q^{1/2}, & \text{if } p \equiv 1 \pmod{4}, \\ (-1)^{s-1} i^s q^{1/2}, & \text{if } p \equiv 3 \pmod{4}. \end{cases}$$
 (3)

The following result (see [9]) gives a relation between the Gaussian sum and the additive character and the multiplicative character of  $\mathbb{F}_q$ , which is also useful in the sequel.

<span id="page-3-1"></span>**Lemma 2.6.** Let  $\chi$  be a nontrivial additive character of  $\mathbb{F}_q$  with q being odd, and let  $f(x) = a_2 x^2 + a_1 x + a_0 \in \mathbb{F}_q[x]$  with  $a_2 \neq 0$ . Then

$$\sum_{c \in \mathbb{F}_a} \chi(f(c)) = \chi(a_0 - a_1^2 (4a_2)^{-1}) \eta(a_2) G(\eta, \chi).$$

In the following of this section, we shall introduce the notions of cyclotomy and Gaussian periods, and also give some known results on periods polynomials.

Let r-1=nN, where n>1 and N>1, and suppose  $\mathbb{F}_r^*=\langle\alpha\rangle$ . The cosets  $C_i^{(N,r)}=\alpha^i\langle\alpha^N\rangle$  for i=0,1,...,N-1 are called the *cyclotomic classes* of order N in  $\mathbb{F}_r$ . In particular, if i=0, then  $C_0^{(N,r)}=\langle\alpha^N\rangle$  is just the subgroup of  $\mathbb{F}_r^*$  generated by  $\alpha^N$ .

<span id="page-4-0"></span>**Lemma 2.7** ([10]). Let e be a positive divisor of q-1. Then we have the following multiset equality:

$$\left\{ xy \mid y \in C_0^{(e,r)}, x \in \mathbb{F}_q^* \right\} = \frac{q-1}{e} \gcd(m,e) * C_0^{(\gcd(m,e),r)},$$

where  $\frac{q-1}{e} \gcd(m,e) * C_0^{(\gcd(m,e),r)}$  denotes the multiset in which each element in the set  $C_0^{(\gcd(m,e),r)}$  appears in the multiset with multiplicity  $\frac{q-1}{e} \gcd(m,e)$ .

**Definition 2.8.** (i) Let  $\kappa$  be the canonical additive character of  $\mathbb{F}_r$ . The Gaussian periods  $\eta_i^{(N,r)}$ , where  $i = 0, 1, \dots, N-1$ , are defined to be

$$\eta_i^{(N,r)} = \sum_{x \in C_i^{(N,r)}} \kappa(x).$$

(ii) The period polynomials  $\psi_{(N,r)}(X)$  are defined by

$$\psi_{(N,r)}(X) = \prod_{i=0}^{N-1} \left( X - \eta_i^{(N,r)} \right).$$

In general, the values of the Gaussian periods are very hard to determine. However, they can be computed in a few cases. The following lemma is well-known, and also can be obtained from Lemma 2.6 and Equation (3).

<span id="page-4-1"></span>**Lemma 2.9.** If N=2, then the Gaussian periods are given by the following

$$\eta_0^{(2,r)} = \begin{cases} \frac{-1 + (-1)^{sm-1}r^{1/2}}{2}, & \text{if } p \equiv 1 \pmod{4}, \\ \frac{-1 + (-1)^{sm-1}i^{sm}r^{1/2}}{2}, & \text{if } p \equiv 3 \pmod{4}, \end{cases}$$

and 
$$\eta_1^{(2,r)} = -1 - \eta_0^{(2,r)}$$
.

It is known that  $\psi^{(N,r)}(X)$  is a polynomial with integer coefficients (see [11]). When N is small, for example, N = 3, 4, the following four lemmas (see [11]) give a precise characterizations for these special periods polynomials which will be used in the next section.

**Lemma 2.10.** Let N=3. Let c and d be defined by  $4r=c^2+27d^2$ ,  $c\equiv 1\pmod 3$ , and, if  $p\equiv 1\pmod 3$ , then  $\gcd(c,p)=1$ . These restrictions determine c uniquely, and d up to sign. Then we have

$$\psi_{(3,r)}(X) = X^3 + X^2 - \frac{r-1}{3}X - \frac{(c+3)r-1}{27}.$$

Recall that  $q = p^s, r = q^m$ , and r - 1 = nN. For the decomposition of the period polynomial  $\psi_{(3,r)}(X)$ , we have

<span id="page-4-2"></span>**Lemma 2.11.** Let N=3. We have the following results on the factorization of  $\psi_{(3,r)}(X)$ . Then

(a) If  $p \equiv 2 \pmod{3}$ , then sm is even, and

$$\psi_{(3,r)}(X) = \begin{cases} 3^{-3}(3X+1+2\sqrt{r})(3X+1-\sqrt{r})^2, & \text{if } sm/2 \text{ even,} \\ 3^{-3}(3X+1-2\sqrt{r})(3X+1+\sqrt{r})^2, & \text{if } sm/2 \text{ odd.} \end{cases}$$

- (b) If  $p \equiv 1 \pmod{3}$ , and  $sm \not\equiv 0 \pmod{3}$ , then  $\psi_{(3,r)}(X)$  is irreducible over the rationals.
- (c) If  $p \equiv 1 \pmod{3}$ , and  $sm \equiv 0 \pmod{3}$ , then

$$\psi_{(3,r)}(X) = \frac{1}{27}(3X + 1 - c_1r^{1/3})(3X + 1 + \frac{1}{2}(c_1 + 9d_1)r^{1/3}) \cdot (3X + 1 + \frac{1}{2}(c_1 - 9d_1)r^{1/3}),$$

where  $c_1$  and  $d_1$  are given by  $4p^{m/3} = c_1^2 + 27d_1^2$ ,  $c_1 \equiv 1 \pmod{3}$  and  $\gcd(c_1, p) = 1$ .

<span id="page-5-0"></span>**Lemma 2.12.** Let N=4. Let u and v be defined by  $r=u^2+4v^2, u\equiv 1\pmod 4$ , and, if  $p\equiv 1\pmod 4$ , then  $\gcd(u,p)=1$ . These restrictions determine u uniquely, and v up to sign. If n is even, then

$$\psi_{(4,r)}(X) = X^4 + X^3 - \frac{3r-3}{8}X^2 + \frac{(2u-3)r+1}{16}X + \frac{r^2 - (4u^2 - 8u + 6)r + 1}{256}.$$

If n is odd, then

$$\psi_{(4,r)}(X) = X^4 + X^3 + \frac{r+3}{8}X^2 + \frac{(2u+1)r+1}{16}X + \frac{9r^2 - (4u^2 - 8u - 2)r + 1}{256}.$$

**Lemma 2.13.** Let N=4. We have the following results on the factorization of  $\psi_{(4,r)}(X)$ .

(a) If  $p \equiv 3 \pmod{4}$ , then sm is even, and

$$\psi_{(4,r)}(X) = \begin{cases} 4^{-4}(4X+1+3\sqrt{r})(4X+1-\sqrt{r})^3, & \text{if } sm/2 \text{ even,} \\ 4^{-4}(4X+1-3\sqrt{r})(4X+1+\sqrt{r})^3, & \text{if } sm/2 \text{ odd.} \end{cases}$$

- (b) If  $p \equiv 1 \pmod{4}$ , and sm is odd, then  $\psi_{(4,r)}(X)$  is irreducible over the rationals.
- (c) If  $p \equiv 1 \pmod{4}$ , and  $sm \equiv 2 \pmod{4}$ , then

$$\psi_{(4,r)}(X) = 4^{-4}((4X+1)^2 + 2\sqrt{r}(4X+1) - r - 2u\sqrt{r})((4X+1)^2 - 2\sqrt{r}(4X+1) - r + 2u\sqrt{r}),$$

the quadratics being irreducible, the u is defined in Lemma 2.12.

(d) If  $p \equiv 1 \pmod{4}$ , and  $sm \equiv 0 \pmod{4}$ , then

$$\psi_{(4,r)}(X) = 4^{-4}((4X+1) + \sqrt{r} + 2r^{1/4}u_1)((4X+1) + \sqrt{r} - 2r^{1/4}u_1)$$

$$\times ((4X+1) - \sqrt{r} + 4r^{1/4}v_1)((4X+1) - \sqrt{r} - 4r^{1/4}v_1),$$

where  $u_1$  and  $v_1$  are given by  $p^{m/2} = u_1^2 + 4v_1^2, u_1 \equiv 1 \pmod{4}$  and  $\gcd(u_1, p) = 1$ .

## 3 The Lee weight distributions of trace codes over R

Recall  $\mathcal{R} = \mathbb{F}_r + u\mathbb{F}_r$ , where  $r = q^m$  for some integer m, and  $R = \mathbb{F}_q + u\mathbb{F}_q$ . Let e be a positive divisor of q - 1, let  $L = C_0^{(e,r)} + u\mathbb{F}_r$ , then L is a subgroup of  $\mathcal{R}^*$  of index e. For any  $a \in \mathcal{R}$ , we define the evaluation map from  $\mathcal{R}$  to R as follows.

$$ev : \mathcal{R} \to R, a \mapsto ev(a) = (Tr(ax))_{x \in L}$$

Accordingly, A trace code  $C_q(m,e)$  of length  $n=|L|=\frac{r^2-r}{e}$  over R is defined by

<span id="page-6-0"></span>
$$C_a(m, e) = \{ev(a) \mid a \in \mathcal{R}\}. \tag{4}$$

In this section, we shall study the Lee weight distribution of the code  $C_q(m, e)$ .

Let  $\chi$  and  $\kappa$  be the canonical characters of  $\mathbb{F}_q$  and  $\mathbb{F}_r$  respectively. For any  $y \in \mathbb{F}_q$ , the following is a well-known property of additive characters of  $\mathbb{F}_q$ .

<span id="page-6-1"></span>
$$\sum_{x \in \mathbb{F}_q} \chi(xy) = \begin{cases} q, & \text{if } y = 0, \\ 0, & \text{if } y \neq 0. \end{cases}$$
 (5)

Let N be a positive integer. For any  $\mathbf{y}=(y_1,y_2,...,y_N)\in\mathbb{F}_q^N$  , let

$$\Theta(\mathbf{y}) = \sum_{j=1}^{N} \chi(y_j).$$

For simplicity, we let  $\theta(a) = \Theta(\phi(ev(a)))$ , where  $a \in \mathcal{R}$ , and  $\phi$  is the Gray map from R to  $\mathbb{F}_q^2$ . By linearity of the Gray map, and the evaluation map, we see that  $\theta(sa) = \Theta(\phi(ev(sa)))$ , for any  $s \in \mathbb{F}_q$ .

<span id="page-6-3"></span>**Proposition 3.1.** Let N be a positive integer and let  $\mathbf{y} = (y_1, y_2, ..., y_N) \in \mathbb{F}_q^N$ . Then

$$\sum_{s \in \mathbb{F}_q^*} \Theta(s\mathbf{y}) = (q-1)N - qw_H(\mathbf{y}).$$

*Proof.* By the definition of  $\Theta$  and Equation (5), we get

$$\sum_{s \in \mathbb{F}_q} \Theta(s\mathbf{y}) = \sum_{s \in \mathbb{F}_q} \sum_{j=1}^N \chi(sy_j) = q \sum_{j=1}^N \frac{1}{q} \sum_{s \in \mathbb{F}_q} \chi(sy_j) = q(N - w_H(\mathbf{y})) = qN - qw_H(\mathbf{y}).$$

Note that

$$\Theta(\mathbf{0}) = \sum_{j=1}^{N} \chi(0) = N.$$

Hence, the result follows.

<span id="page-6-2"></span>**Proposition 3.2.** Let  $a \in \mathcal{R}$  such that  $a = u\beta \in M \setminus \{0\}$  where  $M = \langle u \rangle$ , then we have

$$\sum_{s \in \mathbb{F}_q^*} \theta(sa) = 2r \frac{q-1}{e} \gcd(e,m) \sum_{s \in C_0^{(\gcd(e,m),r)}} \kappa(\beta s).$$

Proof. We have that

$$\sum_{s \in \mathbb{F}_q^*} \theta(sa) = \sum_{s \in \mathbb{F}_q^*} \Theta\left(\phi\left(ev(as)\right)\right) = \sum_{s \in \mathbb{F}_q^*} \Theta\left(\phi\left(Tr(asx)\right)_{x \in L}\right).$$

Note that x = t + ut′ , where t ∈ C (e,r) 0 and t ′ <sup>∈</sup> <sup>F</sup>q. Therefore, ax <sup>=</sup> uβt and

$$Tr(ax) = Tr(u\beta t) = uTr_{r/q}(\beta t).$$

Let s ∈ F ∗ q , taking Gray map yields

$$\phi(ev(as)) = \phi((Tr(asx))_{x \in L}) = (Tr_{r/q}(\beta st), Tr_{r/q}(\beta st))_{t,t'}.$$

This implies that

$$\begin{split} \sum_{s \in \mathbb{F}_q^*} \theta(sa) &= \sum_{s \in \mathbb{F}_q^*} \Theta(\phi(ev(as))) = \sum_{s \in \mathbb{F}_q^*} \Theta((Tr_{r/q}(\beta st), Tr_{r/q}(\beta st))_{t,t'}) \\ &= 2 \sum_{s \in \mathbb{F}_q^*} \sum_{t \in C_0^{(e,r)}} \sum_{t' \in \mathbb{F}_r} \chi(Tr_{r/q}(\beta st)) \\ &= 2r \sum_{s \in \mathbb{F}_q^*} \sum_{t \in C_0^{(e,r)}} \kappa(\beta st). \end{split}$$

Using Lemma [2.7](#page-4-0) we get

$$\sum_{s \in \mathbb{F}_q^*} \theta(sa) = 2r \frac{q-1}{e} gcd(m,e) \sum_{t \in C_0^{(\gcd(e,m),r)}} \kappa(\beta t).$$

In the following, we will determine the Lee weight distribution of the code C<sup>q</sup> (m, e) when gcd(m, e) = 1, 2, 3, 4. In particular, we will show that there exist optimal codes over the finite field F<sup>q</sup> which are the Gray image of these class of trace codes.

<span id="page-7-0"></span>Theorem 3.3. Let <sup>a</sup> ∈ R and gcd(e, m) = 1, then <sup>C</sup>q(m, e) is a code of length (<sup>r</sup> <sup>2</sup>−r) e , size r 2 , and its Lee weight enumerator is determined by

$$A_{C_q(m,e)}(z) = 1 + (r^2 - r) z^{2\frac{q-1}{eq}(r^2 - r)} + (r-1) z^{2\frac{q-1}{eq}r^2}.$$

In particular, the code Cq(m, e) is a two-weight code.

Proof. If a = 0, then T r(ax) = 0. So wL(ev(a)) = 0.

If a = uβ with β ∈ F ∗ r , using Proposition [3.2](#page-6-2) we get

$$\sum_{s \in \mathbb{F}_q^*} \theta(sa) = 2r \frac{q-1}{e} \sum_{s \in C_0^{(1,r)}} \kappa(\beta s) = 2r \frac{q-1}{e} \sum_{s \in \mathbb{F}_r^*} \kappa(\beta s) = -2r \frac{q-1}{e}.$$

Note that ev(a) <sup>∈</sup> <sup>R</sup>n, hence <sup>φ</sup>(ev(a)) <sup>∈</sup> <sup>F</sup> 2n q . By Proposition [3.1](#page-6-3) we get

$$-2r\frac{q-1}{e} = 2(q-1)N - qw_H(\phi(ev(a))),$$

which implies that

$$w_L(ev(a)) = 2\frac{q-1}{eq}r^2.$$

If <sup>a</sup> ∈ R<sup>∗</sup> and <sup>x</sup> <sup>=</sup> <sup>t</sup> <sup>+</sup> ut′ <sup>∈</sup> <sup>L</sup>, then <sup>a</sup> can be expressed as <sup>a</sup> <sup>=</sup> <sup>α</sup> <sup>+</sup> uβ. Therefore, ax <sup>=</sup> αt <sup>+</sup> <sup>u</sup>(αt′ <sup>+</sup> βt), and

$$Tr(ax) = Tr_{r/q}(\alpha t) + uTr_{r/q}(\alpha t' + \beta t),$$

which gives that

$$\phi(ev(a)) = \phi((Tr(ax))_{x \in L}) = (Tr_{r/q}(\alpha t' + \beta t), Tr_{r/q}(\alpha t' + \beta t) + Tr_{r/q}(\alpha t))_{t,t'}.$$

Taking character sum yields

$$\theta(a) = \sum_{t \in C_0^{(e,r)}} \chi(Tr_{r/q}(\beta t)) \sum_{t' \in \mathbb{F}_r} \chi(Tr_{r/q}(\alpha t')) + \sum_{t \in C_0^{(e,r)}} \chi(Tr_{r/q}((\alpha + \beta)t)) \sum_{t' \in \mathbb{F}_r} \chi(Tr_{r/q}(\alpha t'))$$

$$= \sum_{t \in C_0^{(e,r)}} \kappa(\beta t) \sum_{t' \in \mathbb{F}_r} \kappa(\alpha t') + \sum_{t \in C_0^{(e,r)}} \kappa((\alpha + \beta)t) \sum_{t' \in \mathbb{F}_r} \kappa(\alpha t').$$

Since P t ′∈F<sup>r</sup> κ(αt′ ) = 0, then θ(a) = 0. Using Proposition [3.1](#page-6-3) we get

$$w_L(ev(a)) = 2\frac{q-1}{q}n = 2\frac{q-1}{eq}(r^2 - r).$$

<span id="page-8-0"></span>Corollary 3.4. Take q = 2, then the code C2(m, e) is a two-weight code with the weights 2<sup>2</sup><sup>m</sup> and 2 <sup>2</sup><sup>m</sup> <sup>−</sup> <sup>2</sup> <sup>m</sup>, of frequencies 2<sup>m</sup> <sup>−</sup> 1 and 2<sup>2</sup><sup>m</sup> <sup>−</sup> <sup>2</sup> <sup>m</sup> respectively.

Proof. If <sup>q</sup> = 2 then <sup>e</sup> = 1, by Theorem [3.3](#page-7-0) and the sizes of <sup>M</sup> and <sup>R</sup><sup>∗</sup> , the proof can be easily achieved.

Let C be an [n, k, d] code over F<sup>q</sup> with k ≥ 1. The following bound is called the Griesmer bound:

$$\sum_{j=0}^{k-1} \left\lceil \frac{d}{q^j} \right\rceil \le n.$$

We show that, in the following, the image of the code Cq(m, e) under Gray map can reach the Griesmer bound in some cases. That means we can obtain some optimal codes from trace codes.

Theorem 3.5. Assume gcd(m, e) = 1, and let Cq(m, e) be the code over R. Then we have

- If <sup>e</sup> = 1, then for the code <sup>φ</sup>(C<sup>q</sup> (m, e)), we have <sup>P</sup>k−<sup>1</sup> <sup>j</sup>=0 <sup>l</sup> d q j m = n − 1.
- If e ≥ 2, then the code φ(C<sup>q</sup> (m, e)) meets the Griesmer bound with equality.

Proof. If gcd(m, e) = 1, the code φ(C<sup>q</sup> (m, e)) have the parameters

$$n = \frac{2}{e}(q^{2m} - q^m), \quad k = 2m, \quad d = \frac{2(q-1)}{eq}(r^2 - r) = \frac{2(q-1)}{eq}(q^{2m} - q^m).$$

If e ≥ 2 the ceiling function takes two values depending on j.

- $0 \le j \le m-1$ . In this case,  $\left\lceil \frac{d}{q^j} \right\rceil = \frac{2(q-1)}{e} (q^{2m-j-1} q^{m-j-1}),$
- $m \le j \le 2m 1$ . In this case,  $\left\lceil \frac{d}{q^j} \right\rceil = \frac{2(q-1)q^{2m-j-1}}{e}$ .

Therefore,

$$\sum_{j=0}^{2m-1} \left\lceil \frac{d}{q^j} \right\rceil = \sum_{j=0}^{m-1} \frac{2(q-1)}{e} (q^{2m-j-1} - q^{m-j-1}) + \sum_{j=m}^{2m-1} \frac{2(q-1)q^{2m-j-1}}{e}$$

$$= \frac{2(q-1)}{e} \left( \sum_{j=0}^{2m-1} q^{2m-j-1} - \sum_{j=0}^{m-1} q^{m-j-1} \right)$$

$$= \frac{2}{e} (q^{2m} - q^m) = n.$$

If e = 1 the ceiling function takes three values depending on j.

- $0 \le j \le m-1$ . In this case,  $\left\lceil \frac{d}{q^j} \right\rceil = \frac{2(q-1)}{e} (q^{2m-j-1} q^{m-j-1}),$
- j = m. In this case,  $\left\lceil \frac{d}{q^j} \right\rceil = \frac{2(q-1)q^{m-1}}{e} 1$ ,
- $m+1 \le j \le 2m-1$ . In this case,  $\left\lceil \frac{d}{q^j} \right\rceil = \frac{2(q-1)q^{2m-j-1}}{e}$ .

Similarly as the case  $e \geq 2$ , the result can be obtained for e = 1.

**Remark 3.6.** Theorem 4.3 of [12] and Theorem 2 of [13] are just a special cases of Theorem 3.3. When gcd(e, m) = 1, most of the codes  $\phi(C_q(m, e))$  are optimal or nearly optimal for given length and dimension [5]. We list some examples in Table IV.

Table IV: Numeral examples of the code  $C_q(m,e)$  in Theorem 3.3

| q | m | e | [n,k,d]       | Weight distribution          | Optimality     |
|---|---|---|---------------|------------------------------|----------------|
| 2 | 3 | 1 | [112, 6, 56]  | $1 + 56z^{56} + 7z^{64}$     | Optimal        |
| 3 | 2 | 1 | [144, 4, 96]  | $1 + 72z^{96} + 8z^{108}$    | Optimal        |
| 4 | 2 | 3 | [160, 4, 120] | $1 + 240z^{120} + 15z^{128}$ | Optimal        |
| 5 | 1 | 1 | [40, 2, 32]   | $1 + 20z^{32} + 4z^{40}$     | Nearly Optimal |
| 7 | 1 | 2 | [42, 2, 36]   | $1 + 42z^{36} + 6z^{42}$     | Optimal        |
| 9 | 1 | 2 | [72, 2, 64]   | $1 + 72z^{64} + 8z^{72}$     | Optimal        |

<span id="page-9-0"></span>**Theorem 3.7.** Let e be a positive divisor of q-1. If gcd(e,m)=2 then the code  $C_q(m,e)$  is a three-weight code of length  $\frac{(r^2-r)}{e}$ , size  $r^2$ , and its Lee weight enumerator is determined by

$$A_{C_q(m,e)}(z) = 1 + \frac{r-1}{2}z^{2\frac{q-1}{eq}(r^2-r^{3/2})} + (r^2-r)z^{2\frac{q-1}{eq}(r^2-r)} + \frac{r-1}{2}z^{2\frac{q-1}{eq}(r^2+r^{3/2})}.$$

Proof. Since gcd(m, e) = 2, then m is even and q is odd. If a = 0, then Tr(ax) = 0. So  $w_L(ev(a)) = 0$ . If  $a \in \mathbb{R}^*$  then a can be expressed as  $a = \alpha + u\beta$ , let  $x = t + ut' \in L$ . So  $ax = \alpha t + u(\alpha t' + \beta t)$ , and

$$Tr(ax) = Tr_{r/q}(\alpha t) + uTr_{r/q}(\alpha t' + \beta t),$$

which implies that

$$\phi(ev(a)) = \phi((Tr(ax))_{x \in L}) = (Tr_{r/q}(\alpha t' + \beta t), Tr_{r/q}(\alpha t' + \beta t) + Tr_{r/q}(\alpha t))_{t,t'}$$

Taking character sum vields

$$\begin{split} \theta(a) &= \sum_{t \in C_0^{(e,r)}} \chi(Tr_{r/q}(\beta t)) \sum_{t' \in \mathbb{F}_r} \chi(Tr_{r/q}(\alpha t')) + \sum_{t \in C_0^{(e,r)}} \chi(Tr_{r/q}((\alpha + \beta)t)) \sum_{t' \in \mathbb{F}_r} \chi(Tr_{r/q}(\alpha t')) \\ &= \sum_{t \in C_0^{(e,r)}} \kappa(\beta t) \sum_{t' \in \mathbb{F}_r} \kappa(\alpha t') + \sum_{t \in C_0^{(e,r)}} \kappa((\alpha + \beta)t) \sum_{t' \in \mathbb{F}_r} \kappa(\alpha t'). \end{split}$$

Since  $\sum_{t' \in \mathbb{F}} \kappa(\alpha t') = 0$ , then  $\theta(a) = 0$ . Using Proposition 3.1 we get

$$w_L(ev(a)) = 2\frac{q-1}{q}n = 2\frac{q-1}{eq}(r^2 - r).$$

If  $a \in M \setminus \{0\}$ , then  $a = \beta u$  with  $\beta \in \mathbb{F}_r^*$ . By Proposition 3.2 we get

$$\sum_{s \in \mathbb{F}_q^*} \theta(sa) = 4r \frac{q-1}{e} \sum_{t \in C_0^{(2,p^m)}} \kappa(\beta t).$$

If  $\beta \in C_i^{(2,r)}$ , then we have that

$$\sum_{s \in \mathbb{F}_{+}^{*}} \theta(sa) = 4r \frac{q-1}{e} \eta_{i}^{(2,r)}.$$

Note that  $ev(a) \in \mathbb{R}^n$ , then  $\phi(ev(a)) \in \mathbb{F}_q^{2n}$ , By Proposition 3.1 we get

$$4r\frac{q-1}{e}\eta_i^{(2,r)} = 2(q-1)n - qw_H(\phi(ev(a))),$$

which implies that

$$w_L(ev(a)) = 2\frac{q-1}{eq}\left(en - 2r\eta_i^{(2,r)}\right) = 2\frac{q-1}{eq}\left(r^2 - r(1+2\eta_i^{(2,r)})\right).$$

Note that  $|C_0^{(2,r)}| = |C_1^{(2,r)}| = \frac{r-1}{2}$ . The weight distribution of the code follows from the Lemma 2.9 and the discussion above. This completes the proof.

**Remark 3.8.** If we take e = 2, then Theorem 1 of [13] is just a special cases of our Theorem 3.7.

The following is a numeral example.

Table II: Lee weight distribution of the code  $C_q(m, e)$ : gcd(m, e) = 3

$$p \equiv 1 \pmod{3}$$

| Lee weight                                              | Frequency       |
|---------------------------------------------------------|-----------------|
| 0                                                       | 1               |
| $2\frac{q-1}{eq}(r^2-r)$                                | $r^2 - r$       |
| $2\frac{q-1}{eq}(r^2-c_1r^{4/3})$                       | $\frac{r-1}{3}$ |
| $2\frac{q-1}{eq}(r^2 + \frac{1}{2}(c_1 + 9d_1)r^{4/3})$ | $\frac{r-1}{3}$ |
| $2\frac{q-1}{eq}(r^2+\frac{1}{2}(c_1-9d_1)r^{4/3})$     | $\frac{r-1}{3}$ |

$$p \equiv 2 \pmod{3}$$
 and  $sm \equiv 2 \pmod{4}$ 

| Lee weight                      | Frequency        |
|---------------------------------|------------------|
| 0                               | 1                |
| $2\frac{q-1}{eq}(r^2-r)$        | $r^2 - r$        |
| $2\frac{q-1}{eq}(r^2+2r^{3/2})$ | $\frac{r-1}{3}$  |
| $2\frac{q-1}{eq}(r^2-r^{3/2})$  | $2\frac{r-1}{3}$ |

**Example 3.9.** Let q=3 and m=2 and e=2. Then  $\phi(C_3(2,2))$  is a three-weight ternary code of parameters [72, 4, 36] with the weight enumerator

$$1 + 4z^{36} + 72z^{48} + 4z^{72}$$

<span id="page-11-0"></span>**Theorem 3.10.** Let e be a divisor of q-1. When gcd(m,e)=3 the code  $C_q(m,e)$  is with the Lee weight distribution given in Table II, where  $c_1$  and  $d_1$  are uniquely given by  $4p^{m/3}=c_1^2+27d_1^2$ ,  $c_1\equiv 1\pmod 3$  and  $gcd(c_1,p)=1$ .

*Proof.* If a = 0, then Tr(ax) = 0. So  $w_L(ev(a)) = 0$ .

If  $a \in \mathbb{R}^*$  then a can be expressed as  $a = \alpha + u\beta$ , where  $\alpha \neq 0$ , let  $x = t + ut' \in L$ . Then  $ax = \alpha t + u(\alpha t' + \beta t)$ , and

$$Tr(ax) = Tr_{r/q}(\alpha t) + uTr_{r/q}(\alpha t' + \beta t),$$

which implies that

$$\phi(ev(a)) = \phi((Tr(ax))_{x \in L}) = (Tr_{r/q}(\alpha t' + \beta t), Tr_{r/q}(\alpha t' + \beta t) + Tr_{r/q}(\alpha t))_{t,t'}.$$

Taking character sum yields

$$\begin{split} \theta(a) &= \sum_{t \in C_0^{(e,r)}} \chi(Tr_{r/q}(\beta t)) \sum_{t' \in \mathbb{F}_r} \chi(Tr_{r/q}(\alpha t')) + \sum_{t \in C_0^{(e,r)}} \chi(Tr_{r/q}((\alpha + \beta)t)) \sum_{t' \in \mathbb{F}_r} \chi(Tr_{r/q}(\alpha t')) \\ &= \sum_{t \in C_0^{(e,r)}} \kappa(\beta t) \sum_{t' \in \mathbb{F}_r} \kappa(\alpha t') + \sum_{t \in C_0^{(e,r)}} \kappa((\alpha + \beta)t) \sum_{t' \in \mathbb{F}_r} \kappa(\alpha t'). \end{split}$$

Since  $\sum_{t' \in \mathbb{F}_r} \kappa(\alpha t') = 0$ , then  $\theta(a) = 0$ . Using Lemma 3.1 we get

$$w_L(ev(a)) = 2\frac{q-1}{a}n = 2\frac{q-1}{eq}(r^2 - r).$$

If  $a \in M \setminus \{0\}$ , then  $a = \beta u$  with  $\beta \in \mathbb{F}_{p^m}^*$ . By the assumption gcd(m, e) = 3. It then follows from Proposition 3.2 that

$$\sum_{s \in \mathbb{F}_q^*} \theta(sa) = 6r \frac{q-1}{e} \sum_{t \in C_0^{(3,r)}} \kappa(\beta t).$$

If  $\beta \in C_i^{(3,r)}$ 

$$\sum_{s \in \mathbb{F}_q^*} \theta(sa) = 6r \frac{q-1}{e} \eta_i^{(3,r)}.$$

We have that  $ev(a) \in \mathbb{R}^n$ , then  $\phi(ev(a)) \in \mathbb{F}_q^{2n}$ , By Proposition 3.1 we get

$$6r\frac{q-1}{e}\eta_i^{(3,r)} = 2(q-1)n - qw_H(\phi(ev(a))),$$

which implies that

$$w_L(ev(a)) = 2\frac{q-1}{eq} \left( en - 3r\eta_i^{(3,r)} \right) = 2\frac{q-1}{eq} \left( r^2 - r(1+3\eta_i^{(3,r)}) \right).$$

Since gcd(m, e) = 3, then  $m \equiv 0 \pmod{3}$ . If  $p \equiv 1 \pmod{3}$  by Lemma 2.11 the Gaussian periods  $\eta_i^{(3,r)}$  take only the following three distinct values:

$$\frac{-1+c_1r^{1/3}}{3}, \quad \frac{-1-\frac{1}{2}(c_1+9d_1)r^{1/3}}{3}, \quad \frac{-1-\frac{1}{2}(c_1-9d_1)r^{1/3}}{3}$$

If  $p \equiv 2 \pmod{3}$  the Gaussian periods  $\eta_i^{(3,r)}$  take only two distinct values. Note that  $|C_0^{(3,r)}| = |C_1^{(3,r)}| = |C_2^{(3,r)}| = \frac{r-1}{3}$ . The weight distribution of the code follows. This completes the proof.

**Example 3.11.** Let q = 7 and m = 3 and e = 6. Then  $\phi(C_7(3, 6))$  is a four-weight code of parameters [39102, 6, 329] with the weight enumerator

$$1 + 117306z^{33516} + 144z^{329} + 144z^{37044} + 144z^{30870}$$
.

**Example 3.12.** Let q = 4 and m = 3 and e = 3. Then  $\phi(C_4(3,3))$  is a three-weight code of parameters [2688, 6, 1536] over  $\mathbb{F}_4$  with the weight enumerator

$$1 + 12z^{1536} + 4032z^{2016} + 24z^{2304}$$

The last theorem of this section is the weight distribution of the code  $C_q(m,e)$ , where gcd(m,e) = 4.

**Theorem 3.13.** Let e be a divisor of q-1. Suppose that gcd(m,e)=4, then the code  $C_q(m,e)$  is with Lee weight distribution given in Table III.

Table III: Lee weight distribution of the code  $C_q(m, e)$ : gcd(e, m) = 4

$$p \equiv 1 \pmod{4}$$

| Lee weight                                 | Frequency       |
|--------------------------------------------|-----------------|
| 0                                          | 1               |
| $2\frac{q-1}{eq}(r^2-r)$                   | $r^2 - r$       |
| $2\frac{q-1}{eq}(r^2-r^{3/2}-2u_1r^{5/4})$ | $\frac{r-1}{4}$ |
| $2\frac{q-1}{eq}(r^2-r^{3/2}+2u_1p^{5/4})$ | $\frac{r-1}{4}$ |
| $2\frac{q-1}{eq}(r^2+r^{3/2}-4v_1r^{5/4})$ | $\frac{r-1}{4}$ |
| $2\frac{q-1}{eq}(r^2+r^{3/2}+4v_1r^{5/4})$ | $\frac{r-1}{4}$ |

$$p \equiv 3 \pmod{4}$$

| Lee weight                       | Frequency        |
|----------------------------------|------------------|
| 0                                | 1                |
| $2\frac{q-1}{eq}(r^2-r)$         | $r^2 - r$        |
| $2\frac{q-1}{eq}(r^2-3r^{3/2})$  | $\frac{r-1}{4}$  |
| $2\frac{q-1}{eq}(r^2 + r^{3/2})$ | $3\frac{r-1}{4}$ |

*Proof.* Because  $\gcd(m,e)=4$ , then  $m\equiv 0\pmod 4$ . If  $p\equiv 1\pmod 4$ , then the Gaussian periods  $\eta_i^{(4,p^m)}$  take only the following distinct values:

$$\frac{\left(1+r^{1/2}+2u_1r^{1/4}\right)}{4},\quad \frac{\left(1+r^{1/2}-2u_1r^{1/4}\right)}{4},$$

and

$$\frac{\left(1-r^{1/2}+4v_1r^{1/4}\right)}{4},\quad \frac{\left(1-r^{1/2}-4v_1r^{1/4}\right)}{4}.$$

Using a similar proof of Theorem 3.10, the proof can be easily achieved.

**Example 3.14.** Let q = 5 and m = 4 and e = 4. Then  $\phi(C_5(4, 4))$  is a four-weight code of parameters [195000, 8, 142500] with the weight enumerator

$$1 + 390000z^{156000} + 156z^{142500} + 156z^{157500} + 156z^{152500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^{172500} + 156z^$$

## 4 Conclusion

In this paper, we characterize the Lee weight distribution of the code  $C_q(m,e)$  for all e with  $1 \le \gcd(e,m) \le 4$ . The period polynomial  $\psi_{(N,r)}(X)$  and its factorization were determined for N=5 by Hoshi [8], and for those dividing 8 and 12 by Gurak [6]. This means that the Lee weight distribution of the code  $C_q(m,e)$  for  $\gcd(e,m) \in \{5,6,8,12\}$  also can be determined. However, the weight formulas will be messy. This demonstrates that the Lee weight distribution of the codes  $C_q(m,e)$  is indeed very complicated.

On the other hand, the codes constructed in this paper are a generalization of those studied in [13, 12]. In particular, If q = 2 our result coincide with [12] and with [13] if e = 2. Furthermore, our technique can be used to generalize other results such as in [14].

Acknowledgement. This work was supported by NSFC under Grant No. 11171370.

# <span id="page-14-0"></span>References

- <span id="page-14-4"></span>[1] Ding, C. Linear codes from some 2-designs. IEEE Transactions on Information Theory, 2015, vol. 61, no 6, 3265-3275.
- <span id="page-14-1"></span>[2] Ding, K., Ding, C. Binary linear codes with three weights. IEEE Communications Letters, 2014, vol. 18, no 11, 1879-1882.
- <span id="page-14-3"></span>[3] Ding, C., Li, C., Li, N., Zhou, Z. Three-weight cyclic codes and their weight distributions. Discrete Mathematics, 2016, vol. 339, no 2, 415-427.
- <span id="page-14-11"></span>[4] Ding, C., Luo, J., Niederreiter, H. Two-weight codes punctured from irreducible cyclic codes. In : Proc. of the First International Workshop on Coding Theory and Cryptography. 2008. 119-124.
- <span id="page-14-13"></span>[5] Grassl, M. Bounds on the minimum distance of linear codes and quantum codes. Online available at [http://www.codetables.de.](http://www.codetables.de)
- <span id="page-14-5"></span>[6] Gurak, S. J. Period polynomials for F<sup>q</sup> of fixed small degree. CRM Proc. and Lect. Notes, 2004, vol. 36, 127-145.
- <span id="page-14-12"></span>[7] Heng, Z., Yue, Q. A class of binary linear codes with at most three weights. IEEE Communications Letters, 2015, vol. 19, no 9, 1488-1491.
- [8] Hoshi, A. Explicit lifts of quintic Jacobi sums and period polynomials for Fq. Proceedings of the Japan Academy, Series A, Mathematical Sciences, 2006, vol. 82, no 7, 87-92.
- <span id="page-14-9"></span><span id="page-14-8"></span>[9] Lidl, R., Niederreiter, H. Finite fields. Cambridge university press, 1997.
- <span id="page-14-10"></span>[10] Ma, C., Zeng, L., Liu, Y., Feng, D., Ding, C. The weight enumerator of a class of cyclic codes. IEEE Transactions on Information Theory, 2011, vol. 57, no 1, 397-402.
- <span id="page-14-6"></span>[11] Myerson, G. Period polynomials and Gauss sums for finite fields. Acta Arithmetica, 1981, vol. 39, no 3, 251-264.
- <span id="page-14-7"></span>[12] Shi, M., Liu, Y., Sol´e, P. Optimal two-weight codes from trace codes over F<sup>2</sup> + uF2. IEEE Communications Letters, 2016, vol. 20, no 12, 2346-2349.
- <span id="page-14-14"></span>[13] Shi, M., Wu, R., Liu, Y., Sol´e, P. Two and three weight codes over F<sup>p</sup> + uFp. Cryptography and Communications, 2017, vol. 9, no 5, 637-646.
- <span id="page-14-2"></span>[14] Shi, M., Wu, R., Qian, L., Sok, L., Sol´e, P. New classes of p-ary few weights codes, [arXiv:1612.00915v](http://arxiv.org/abs/1612.00915)2.
- [15] Yu, L., Liu, H. The weight distribution of a family of p-ary cyclic codes. Designs, Codes and Cryptography, 2016, vol. 78, no 3, 731-745.