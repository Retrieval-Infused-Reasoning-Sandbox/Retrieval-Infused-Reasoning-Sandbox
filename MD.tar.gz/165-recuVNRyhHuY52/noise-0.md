# A Class of Quantum Error-Correcting Codes Saturating the Quantum Hamming Bound

#### Daniel Gottesman ∗

California Institute of Technology, Pasadena, CA 91125

## Abstract

I develop methods for analyzing quantum error-correcting codes, and use these methods to construct an infinite class of codes saturating the quantum Hamming bound. These codes encode k = n − j − 2 qubits in n = 2 <sup>j</sup> qubits and correct t = 1 error. 03.65.Bz,89.80.+h

Typeset using REVTEX

<sup>∗</sup>gottesma@theory.caltech.edu

#### I. INTRODUCTION

Since Shor[[1\]](#page-21-0) showed that it was possible to create quantum error-correcting codes, there has been a great deal of work on trying to create efficient codes. Calderbank and Shor [\[2\]](#page-21-0) and Steane [\[3](#page-21-0)] demonstrated a method of converting certain classical error-correcting codes into quantum ones, and Laflamme et al. [\[4](#page-21-0)] and Bennett et al. [\[5](#page-21-0)] produced codes to correct one error that encode 1 qubit in 5 qubits.

Suppose we want to encode k qubits in n qubits. The space of code words is then some 2 k -dimensional subspace of the full 2<sup>n</sup> -dimensional Hilbert space. The encodings |ψii of the original 2<sup>k</sup> basis states form a basis for the space of code words. When a coherent error occurs, the code states are altered by some linear transformation M:

$$|\psi_i\rangle \longmapsto M|\psi_i\rangle.$$
 (1)

We do not require that M be unitary, which will allow us to also correct incoherent errors.

Typically, we only consider the possibility of errors that act on no more than t qubits. An error that acts non-trivially on exactly t qubits will be said to have length t. An error of length 1 only acts on a 2-dimensional Hilbert space, so the space of 1-qubit errors is M2, the space of 2 × 2 matrices.

An error-correction process can be modeled by a unitary linear transformation that entangles the erroneous states M|ψii with an ancilla |Ai and transforms the combination to a corrected state

$$(M|\psi_i\rangle)\otimes|A\rangle\longmapsto|\psi_i\rangle\otimes|A_M\rangle.$$
 (2)

Note that the map M 7→ |AMi must be linear, but not necessarily one-to-one. If the map is injective, I will call the code non-degenerate, and if it is not, I will call the code degenerate. A degenerate code has linearly independent matrices that act in a linearly dependent way on the code words, while in a non-degenerate code, all of the errors acting on the code words produce linearly independent states. Note that Shor's original code[[1\]](#page-21-0) is a degenerate code (phase errors within a group of 3 qubits act the same way), while the k=1, n=5 codes [4,5] are non-degenerate.

At this point, we can measure the ancilla preparatory to restoring it to its original state without disturbing the states  $|\psi_i\rangle$ . This process will correct the error even if the original state is a superposition of the basis states:

$$\left(M\sum_{i=1}^{2^k} c_i |\psi_i\rangle\right) \otimes |A\rangle \longmapsto \left(\sum_{i=1}^{2^k} c_i |\psi_i\rangle\right) \otimes |A_M\rangle \tag{3}$$

An incoherent error can be modeled as an ensemble of coherent errors. Since the above process corrects all coherent errors, it will therefore also correct incoherent errors. After the ancilla is measured and restored to its original state, the system will once again be in a pure state. Sufficient and necessary conditions for the system to form a quantum error-correcting code are given in [5] and [6]. While errors acting on different code words must produce orthogonal results, different errors acting on the same code word can produce non-orthogonal states, even in the non-degenerate case.

We can use the definition of non-degenerate quantum error-correcting codes to derive the quantum Hamming bound [7] on their possible efficiency. It is not known whether the quantum Hamming bound applies to degenerate codes, although some recent evidence suggests that it does not [8,9]. However, the breeding and hashing protocol presented by Shor and Smolin [8] and the random matrix encodings mentioned by Lloyd [9] do not give a 100% chance of successful decoding, even if only a fixed finite number of errors occur. There are no known degenerate codes that guarantee success that violate the quantum Hamming bound. I show in appendix A that a certain class of degenerate codes to correct 1 error are, in fact, limited by the quantum Hamming bound. The question for fully general degenerate codes remains open, although Knill and Laflamme [6] showed that at least 5 qubits are necessary to correct 1 error. Below, I will assume the code is non-degenerate.

Since there are 3 possible non-trivial 1-qubit errors, the number of possible errors M of length l on an n-qubit code is  $3^l \binom{n}{l}$ . Each of the states  $M|\psi_i\rangle$  must be linearly

<span id="page-3-0"></span>independent, and all of these different errors must fit into the 2<sup>n</sup> -dimensional Hilbert space of the n qubits. Thus, for a code that can correct up to t errors,

$$2^k \sum_{l=0}^t 3^l \binom{n}{l} \le 2^n. \tag{4}$$

For large n, this becomes

$$\frac{k}{n} \le 1 - \frac{t}{n} \log_2 3 - H(t/n),\tag{5}$$

where H(x) = −x log<sup>2</sup> x − (1 − x) log<sup>2</sup> (1 − x).

It is an interesting question whether it is generally possible to attain this bound, or whether some more restrictive upper bound holds. Breeding and hashing methods [\[10,5](#page-21-0)] can asymptotically saturate the quantum Hamming bound for large blocks, but have a small but non-zero probability of failure, even for only one error. For t = 1 and k = 1, the quantum Hamming bound (4) implies n ≥ 5, so the known 5-qubit code does saturate the bound. Below, in section [III](#page-9-0), I will give a class of codes saturating the bound for t = 1 and n = 2<sup>j</sup> (so k = n − j − 2). For large n, the efficiency k/n of these codes approaches 1. In this sense, they are the analog of the classical Hamming codes. To aid in the construction, in section II, I will present some methods for analyzing quantum error-correcting codes. The method I present of using code stabilizers to describe codes is also given, using slightly different language, in [\[11\]](#page-21-0).

Throughout this paper, I will assume the basis of M<sup>2</sup> is

$$I = \begin{pmatrix} 1 & 0 \\ 0 & 1 \end{pmatrix}, \ X = \begin{pmatrix} 0 & 1 \\ 1 & 0 \end{pmatrix}, \ Y = \begin{pmatrix} 0 & -1 \\ 1 & 0 \end{pmatrix}, \ Z = \begin{pmatrix} 1 & 0 \\ 0 & -1 \end{pmatrix}. \tag{6}$$

Some of the results will hold for other bases, but many will not. This basis has two important properties: all of the matrices either commute or anticommute, and X<sup>2</sup> = −Y <sup>2</sup> = Z <sup>2</sup> = I.

#### II. CODE STABILIZERS

Suppose we have an n-qubit system. Let us write the matrices X, Y , and Z as X<sup>i</sup> , Y<sup>i</sup> , and Z<sup>i</sup> when they act on the ith qubit. Let G be the group generated by all 3n of these matrices.<sup>1</sup> Since  $(X_i)^2 = (Z_i)^2 = I$  and  $Y_i = Z_i X_i = -X_i Z_i$ ,  $\mathcal{G}$  has order  $2^{2n+1}$  (for each i, we can have I,  $X_i$ ,  $Y_i$ , or  $Z_i$ , plus a possible overall factor of -1). The group  $\mathcal{G}$  has a few other useful features: every element in  $\mathcal{G}$  squares to  $\pm 1$  and if  $A, B \in \mathcal{G}$ , then either [A, B] = 0 or  $\{A, B\} = 0$ .

The code words of the quantum error-correcting code span a subspace T of the Hilbert space. The group  $\mathcal{G}$  acts on the vectors in T. Let  $\mathcal{H}$  be the stabilizer of T — i.e.,

$$\mathcal{H} = \{ M \in \mathcal{G} \text{ s.t. } M | \psi \rangle = | \psi \rangle \ \forall \, | \psi \rangle \in T \}. \tag{7}$$

Now suppose  $E \in \mathcal{G}$  and  $\exists M \in \mathcal{H}$  s.t.  $\{E, M\} = 0$ . Then  $\forall |\psi\rangle, |\phi\rangle \in T$ ,

$$\langle \phi | E | \psi \rangle = \langle \phi | EM | \psi \rangle = -\langle \phi | ME | \psi \rangle = -\langle \phi | E | \psi \rangle \tag{8}$$

so  $\langle \phi | E | \psi \rangle = 0$ .

The implications of this are profound. Suppose E and F are two errors, both of length t or less. Then  $E|\psi\rangle$  and  $F|\phi\rangle$  are orthogonal for all  $|\psi\rangle$ ,  $|\phi\rangle \in T$  whenever  $F^{\dagger}E$  anticommutes with anything in  $\mathcal{H}$ . This is the requirement for a non-degenerate code, so to find such a code, we just need to pick T and corresponding  $\mathcal{H}$  so that every non-trivial matrix in  $\mathcal{G}$  of length less than or equal to 2t anticommutes with some member of  $\mathcal{H}$ .

It is unclear whether every quantum error-correcting code in the X, Y, Z basis can be completely described by its stabilizer  $\mathcal{H}$ . Certainly, a large class of codes can be described in this way, and I do not know of any quantum error-correcting codes that cannot be so described.

Given T, we can figure out  $\mathcal{H}$ , but it will be much easier to find codes using the above property if we can pick  $\mathcal{H}$  and deduce a space T of code words. First I will discuss what properties  $\mathcal{H}$  must have in order for it to be the stabilizer of a space T, then I will discuss how to choose  $\mathcal{H}$  so that the matrices of length 2t or less anticommute with one of its elements.

<sup>&</sup>lt;sup>1</sup>For  $n=1, \mathcal{G}$  is just  $D_4$ , the symmetry group of a square. For larger  $n, \mathcal{G}$  is  $(D_4)^n/(\mathbf{Z}_2)^{n-1}$ .

Clearly, H must be a subgroup of G. Also, if M ∈ H, then M<sup>2</sup> |ψi = M|ψi = |ψi for |ψi ∈ T, so M cannot square to -1. Finally, if M, N ∈ H, then

$$MN|\psi\rangle = |\psi\rangle$$
 (9)

$$NM|\psi\rangle = |\psi\rangle \tag{10}$$

$$[M, N]|\psi\rangle = 0 \tag{11}$$

If {M, N} = 0, then [M, N] = 2MN, but M and N are unitary, and cannot have 0 eigenvalues. Thus, [M, N] = 0, and H must be abelian.

Thus, H must be abelian and every element of H must square to 1, so H is isomorphic to (Z2) a for some a. It turns out that these are sufficient conditions for there to exist non-trivial T with stabilizer H, as long as H is not too big. The largest subspace T with stabilizer H will have dimension 2<sup>n</sup>−<sup>a</sup> . To show this, I will give an algorithm for constructing a basis for T. Intuitively, it is unsurprising that this should be the dimension of T, since each generator of H has eigenvalues ±1 and splits the Hilbert space in half.

Consider a state that can be written as a tensor product of 0s and 1s. This sort of state is analogous to one word of a classical code, so I will call it a quasi-classical state. Sometimes I will distinguish between quasi-classical states that differ by a phase and sometimes I will not. Now, given a quasi-classical state |φi, then

$$|\psi\rangle = \sum_{M \in \mathcal{H}} M|\phi\rangle \tag{12}$$

is in T, 2 since applying an element of H to it will just rearrange the sum. I will call |φi the seed of the code word |ψi. By the same argument, if M ∈ H, M|φi acts as the seed for the same quantum code word as |φi. Not every possible seed will produce a non-zero code word. For instance, suppose H = {I, Z1Z2} and we use |01i as our seed. Then |ψi = I|01i + Z1Z2|01i = 0.

<sup>2</sup> In fact, |φi does not need to be a quasi-classical state for |ψi to be in T. Any state will do, but it is easiest to use quasi-classical states.

To find elements of T, we try quasi-classical states until we get one that produces nonzero |ψi, call it |ψ1i. I will show later that such a state will always exist. We can write |ψ1i as a sum of quasi-classical states, any of which could act as its seed. Pick a quasi-classical state that does not appear in |ψ1i and does not produce 0, and use it as the seed for a second state |ψ2i. Continue this process for all possible quasi-classical states. The states |ψii will then form a basis for T. None of them share a quasi-classical state.

To see that {|ψii} is a basis, imagine building up the elements of H by adding generators one by one. Suppose H = hM1, M2, . . .Mai (i.e., H is generated by M<sup>1</sup> through Ma). Let H<sup>r</sup> be the group generated by M<sup>1</sup> through Mr, and look at the set S<sup>r</sup> of quasi-classical states produced by acting with the elements of H<sup>r</sup> on some given quasi-classical seed |φi. The phases of these quasi-classical states will matter. The next generator Mr+1 can do one of three things:

- 1. it can map the seed to some new quasi-classical state not in Sr,
- 2. it can map the seed to plus or minus itself, or
- 3. it can map the seed to plus or minus times some state in S<sup>r</sup> other than the seed.

I will call a generator that satisfies case 1 a type 1 generator, and so on.

In the first case, all of the elements of Hr+1 − H<sup>r</sup> will also map the seed outside of Sr: If N ∈ Hr+1 − Hr, then N = MMr+1 for some M ∈ Hr. Then if ±N|φi ∈ Sr, N|φi = ±M′ |φi for some M′ ∈ Hr. Then Mr+1|φi = ±M<sup>−</sup><sup>1</sup>M′ |φi ∈ Sr, which contradicts the assumption. Thus, S = S<sup>a</sup> will always have size 2<sup>b</sup> , where b is the number of type 1 generators.

In the second case, the new generator must act on each qubit as the identity I, as −I, or as Z<sup>i</sup> , so type 2 generators can be written as the product of Z's. In principle, a type 2 generator could be -1 times the product of Z's, but the factor of -1 slightly complicates the process of picking seeds, so for simplicity I will assume it is not present. The method of choosing H that I give below will always create generators without such factors of -1.

In the third case, when |φ ′ i = ±Mr+1|φi is already in Sr, then there exists N ∈ H<sup>r</sup> with N|φi = |φ ′ i. We can then use N <sup>−</sup><sup>1</sup>Mr+1 as a new generator instead of Mr+1, and since N <sup>−</sup><sup>1</sup>Mr+1|φi = ±|φi, we are back to case two. After adding all of the generators, changing any of type 3 into type 2, we are left with b generators of type 1 and a − b generators of type 2.

If one of the type 2 generators M<sup>i</sup> gives a factor of -1 acting on the seed, the final state is 0:

$$\sum_{M \in \mathcal{H}} M |\phi\rangle = \left(\sum_{M \in \mathcal{H}} M\right) M_i |\phi\rangle = -\sum_{M \in \mathcal{H}} M |\phi\rangle = 0.$$
 (13)

Otherwise |ψi is non-zero. We can simplify the computation of |ψi by only summing over products of the type 1 generators, since the type 2 generators will only give us additional copies of the same sum. Then |ψi will be the sum of 2<sup>b</sup> quasi-classical states (with the appropriate signs).

Is this classification of generators going to be the same for all possible seeds? Anything that is a product of Z's has all quasi-classical states as eigenstates, and anything that is not a product of Z's has no quasi-classical states as eigenstates. Thus if a generator is type 2 for one seed, it is type 2 for all seeds. Type 1 generators cannot become type 3 generators because then the matrix M<sup>−</sup><sup>1</sup>N would be type 2 for some states but not others. Thus, all of the states |ψii are the sum of 2<sup>b</sup> quasi-classical states, and a − b of the generators of H are the product of Z's. Note that this also shows that the classification of generators into type 1 and type 2 generators does not depend on their order.

Since a seed produces a non-trivial final state if and only if it has an eigenvalue of +1 for all of the type 2 generators, all of the states |ψii live in the joint +1 eigenspace of the a − b type 2 generators, which has dimension 2<sup>n</sup>−(a−b) . We can partition the quasi-classical basis states of this eigenspace into classes based on the |ψii in which they appear. Each partition has size 2<sup>b</sup> , so there are 2<sup>n</sup>−<sup>a</sup> partitions, proving the claimed dimension of T. The states |ψii form a basis of T.

We can simplify the task of finding seeds for a basis of quantum code words. First, note that |0i = |00 . . . 0i is always in the +1 eigenspace of any type 2 generator, so it can always provide our first seed. Any other quasi-classical seed  $|\phi\rangle$  can be produced from  $|\mathbf{0}\rangle$  by operating with some  $N \in \mathcal{G}$  that is a product of X's. For  $N|\mathbf{0}\rangle$  to act as the seed for a non-trivial state, N must commute with every type 2 generator in  $\mathcal{H}$ : If  $M_i$  is a type 2 generator, and  $\{N, M_i\} = 0$ , then

$$M_i(N|\mathbf{0}\rangle) = -NM_i|\mathbf{0}\rangle = -N|\mathbf{0}\rangle.$$
 (14)

But only quasi-classical states which have eigenvalue +1 give non-trivial code words, so N must commute with the type 2 generators. Two such operators N and N' will produce seeds for the same quantum code word iff they differ by an element of  $\mathcal{H}$  — i.e.,  $N^{-1}N' \in \mathcal{H}$ . This provides a test for when two seeds will produce different code words, and also implies that the product of two operators producing different code words will also be a new code word. Thus, we can get a full set of  $2^{n-a}$  seeds by taking products of n-a operators  $N_1, \ldots, N_{n-a}$ . I will call the  $N_i$  seed generators. I do not know of any efficient method for determining the  $N_i$ .

Once we have determined the generators  $M_i$  of  $\mathcal{H}$  and the seed generators  $N_i$ , we can define a unitary transformation to perform the encoding by

$$|c_1 c_2 \dots c_k\rangle \longmapsto \frac{1}{2^{b/2}} \prod_{M_i \text{ type } 1} (I + M_i) \ N_1^{c_1} N_2^{c_2} \dots N_k^{c_k} |\mathbf{0}\rangle.$$
 (15)

However, I do not know of an efficient way to implement this tranformation.

Now I turn to the next question: how can we pick  $\mathcal{H}$  so that all of the errors up to length 2t anti-commute with some element of it? Given  $M \in \mathcal{G}$ , consider the function  $f_M : \mathcal{G} \to \mathbf{Z}_2$ ,

$$f_M(N) = \begin{cases} 0 & \text{if } [M, N] = 0\\ 1 & \text{if } \{M, N\} = 0 \end{cases}$$
 (16)

Then  $f_M$  is a homomorphism. If  $\mathcal{H} = \langle M_1, M_2, \dots M_a \rangle$ , then define a homomorphism  $f: \mathcal{G} \to (\mathbf{Z}_2)^a$  by

$$f(N) = (f_{M_1}(N), f_{M_2}(N), \dots f_{M_a}(N)).$$
(17)

Below, I will actually write f(N) as an a-bit binary string. With this definition of f, f(N) = 00...0 iff N commutes with everything in  $\mathcal{H}$ . We therefore wish to pick  $\mathcal{H}$  so that

<span id="page-9-0"></span>f(E) is non-zero for all E up to length 2t. We can write any such E as the product of F and G, each of length t or less, and f(E) 6= 0 iff f(F) 6= f(G). Therefore, we need to pick H so that f(F) is different for each F of length t or less.

We can thus find a quantum error-correcting code by first choosing a different a-bit binary number for each X<sup>i</sup> and Z<sup>i</sup> . These numbers will be the values of f(Xi) and f(Zi) for some H which we can then determine. We want to pick these binary numbers so that the corresponding values of f(Yi) and errors of length 2 or more (if t > 1) are all different. While this task is difficult in general, it is tractable for t = 1. In addition, even if all of the f(E) are different, we still need to make sure that H fixes a non-trivial space of code words T by checking that H is abelian and that its elements square to +1.

#### III. THE CODES

Now I will use the method described in section [II](#page-3-0) to construct an optimal non-degenerate quantum error-correcting code for n = 2<sup>j</sup> . The quantum Hamming bound [\(4\)](#page-3-0) tells us that k ≤ n−j −2, so we take a = j + 2 and j ≥ 3. I will also show explicitly the construction for n = 8. Steane [\[12](#page-21-0)] has found the same k = 3, n = 8 code following inspiration from classical error-correcting codes, and Calderbank et al.[[11\]](#page-21-0) have found a different k = 3, n = 8 code.

We want to pick different (j + 2)-bit binary numbers for X<sup>i</sup> and Z<sup>i</sup> (i = 1 . . .n) so that the numbers for Y<sup>i</sup> , which are given by the bitwise XOR of the numbers for X<sup>i</sup> and Z<sup>i</sup> , are also all different. The numbers for n = 8 are shown in table [I.](#page-10-0) In order to distinguish between the X's, the Y 's, and the Z's, we will devote the first two bits to encoding which of the three it is, and the remaining j bits will encode which qubit i the error acts on (although this encoding will depend on whether it is an X, a Y , or a Z).

The first two bits are 01 for an X, 10 for a Z, and 11 for a Y , as required to make f a homomorphism. For the X<sup>i</sup> 's, the last j bits will just form the binary number for i − 1, so X<sup>1</sup> is 0100 . . . 0, and X<sup>n</sup> is 0111 . . . 1. The encoding for the last j bits for the Z<sup>i</sup> 's is more complicated. We cannot use the same pattern, or all of the Y<sup>i</sup> 's would just have all 0s for

<span id="page-10-0"></span>

| X1 | 01000 | X2 | 01001 | X3 | 01010 | X4 | 01011 |
|----|-------|----|-------|----|-------|----|-------|
| Z1 | 10111 | Z2 | 10000 | Z3 | 10110 | Z4 | 10001 |
| Y1 | 11111 | Y2 | 11001 | Y3 | 11100 | Y4 | 11010 |
| X5 | 01100 | X6 | 01101 | X7 | 01110 | X8 | 01111 |
| Z5 | 10010 | Z6 | 10101 | Z7 | 10011 | Z8 | 10100 |
| Y5 | 11110 | Y6 | 11000 | Y7 | 11101 | Y8 | 11011 |

TABLE I. The values of f(Xi), f(Yi), and f(Zi) for n = 8.

the last j bits. Instead of counting 0, 1, 2, 3, . . . , we instead count 0, 0, 1, 1, 2, 2, . . . . Writing this in binary will not make all of the numbers for the Z's different, so what we do instead is to write them in binary and then take the bitwise NOT of one of each pair. This does make all of the Z's different. We then determine what the numbers for Y<sup>i</sup> are.

How we pick which member of the pair to invert will determine whether all of the numbers for Y<sup>i</sup> are different. For even j, we can just take the NOT for all odd i; but for odd j, we must take the NOT for odd i when i ≤ 2 j−1 and for even i when i > 2 j−1 . A general proof that this method will give different numbers for all the Y<sup>i</sup> 's is given in appendix [B.](#page-15-0)

Now that we have the numbers for all of the 1-qubit errors, we need to determine the generators M<sup>1</sup> . . .M<sup>a</sup> of H. Recall that the first digit of the binary numbers corresponds to the first generator. Since the first digit of the number for X<sup>1</sup> is 0, M<sup>1</sup> commutes with X1; the first digit of the numbers for Y<sup>1</sup> and Z<sup>1</sup> are both 1, so M<sup>1</sup> anticommutes with Y<sup>1</sup> and Z1. Therefore, M<sup>1</sup> is X<sup>1</sup> times the product of matrices which only act on the other qubits. Similarly, the first digit of the number for each X<sup>i</sup> is 0 and the first digits for Y<sup>i</sup> and Z<sup>i</sup> are both 1, so M<sup>1</sup> = X1X<sup>2</sup> . . .X<sup>n</sup> (this is true even for j > 3). Using the same principle, we can work out all of the generators.

The results for n = 8 are summarized in table [II.](#page-11-0) Note that all of these generators square to +1 and that they all commute with each other. A proof of this fact for j > 3 is given in appendix [C.](#page-17-0) Thus we have a code that encodes 3 qubits in 8 qubits, or more generally n−j −2 qubits in 2<sup>j</sup> qubits. For these codes, there is 1 type 2 generator M2. The remaining

<span id="page-11-0"></span>

| M1 | X1 | X2 | X3 | X4 | X5 | X6 | X7 | X8 |
|----|----|----|----|----|----|----|----|----|
| M2 | Z1 | Z2 | Z3 | Z4 | Z5 | Z6 | Z7 | Z8 |
| M3 | X1 | I  | X3 | I  | Z5 | Y6 | Z7 | Y8 |
| M4 | X1 | I  | Y3 | Z4 | X5 | I  | Y7 | Z8 |
| M5 | X1 | Z2 | I  | Y4 | I  | Y6 | X7 | Z8 |
| N1 | X1 | X2 | I  | I  | I  | I  | I  | I  |
| N2 | X1 | I  | X3 | I  | I  | I  | I  | I  |
| N3 | X1 | I  | I  | I  | X5 | I  | I  | I  |

TABLE II. The generators of H and seed generators for n = 8.

#### j + 1 generators are type 1.

Table II also gives seed generators for n = 8. We can see immediately that they all commute with M2, the type 2 generator. It is less obvious that they all produce seeds for different states, but using them produces 8 different quantum codes words, listed in table [III,](#page-12-0) so they do, in fact, form a complete list of seed generators. This partly answers the question of how often we can saturate the quantum Hamming bound by showing that for 1 error, it can be saturated for arbitrarily large n. Although the methods given above may help somewhat, finding optimal codes to correct more than one error remains a difficult task.

I would like to thank John Preskill for helpful discussions. This work was supported in part by the U.S. Department of Energy under Grant No. DE-FG03-92-ER40701.

# APPENDIX A: PROOF THAT CERTAIN DEGENERATE CODES CANNOT DEFEAT THE QUANTUM HAMMING BOUND FOR t = 1

While there is no known proof that degenerate quantum error-correcting codes cannot beat the quantum Hamming bound for arbitrary t and n, I will present a proof that codes to correct just 1 error are, in fact, limited by that bound, so long as the only source of degeneracies is when linearly independent error matrices map a code word into a one-dimensional

```
|ψ0i = |00000000i + |11111111i + |10100101i + |10101010i + |10010110i + |01011010i
       + |01010101i + |01101001i + |00001111i + |00110011i + |00111100i
       + |11110000i + |11001100i + |11000011i + |10011001i + |01100110i
|ψ1i = |11000000i + |00111111i + |01100101i + |01101010i − |01010110i + |10011010i
       + |10010101i − |10101001i + |11001111i − |11110011i − |11111100i
       + |00110000i − |00001100i − |00000011i − |01011001i − |10100110i
|ψ2i = |10100000i + |01011111i + |00000101i − |00001010i + |00110110i + |11111010i
       − |11110101i + |11001001i − |10101111i + |10010011i − |10011100i
       − |01010000i + |01101100i − |01100011i − |00111001i − |11000110i
|ψ3i = |01100000i + |10011111i + |11000101i − |11001010i − |11110110i + |00111010i
       − |00110101i − |00001001i − |01101111i − |01010011i + |01011100i
       − |10010000i − |10101100i + |10100011i + |11111001i + |00000110i
|ψ4i = |10001000i + |01110111i − |00101101i + |00100010i + |00011110i − |11010010i
       + |11011101i + |11100001i − |10000111i − |10111011i + |10110100i
       − |01111000i − |01000100i + |01001011i − |00010001i − |11101110i
|ψ5i = |01001000i + |10110111i − |11101101i + |11100010i − |11011110i − |00010010i
       + |00011101i − |00100001i − |01000111i + |01111011i − |01110100i
       − |10111000i + |10000100i − |10001011i + |11010001i + |00101110i
|ψ6i = |00101000i + |11010111i − |10001101i − |10000010i + |10111110i − |01110010i
       − |01111101i + |01000001i + |00100111i − |00011011i − |00010100i
       + |11011000i − |11100100i − |11101011i + |10110001i + |01001110i
|ψ7i = |11101000i + |00010111i − |01001101i − |01000010i − |01111110i − |10110010i
       − |10111101i − |10000001i + |11100111i + |11011011i + |11010100i
       + |00011000i + |00100100i + |00101011i − |01110001i − |10001110i
```

TABLE III. The quantum code words for the n = 8 code.

<span id="page-13-0"></span>subspace. For instance, if three different errors map code words into a single two-dimensional subspace, this condition will not generally be satisfied.

Given a degenerate quantum error-correcting code of this type that corrects 1 error, we can list a number of conditions that describe which errors are degenerate. I will call these relations degeneracy conditions. As with the stabilizers in section [II,](#page-3-0) each independent condition will reduce the space of possible code words by a factor of 2. Note that I am not requiring that the basis for errors be the X, Y , Z basis I have used in the rest of the paper.<sup>3</sup>

Suppose there are l different degeneracy conditions describing the code. Each one equates two one-qubit errors, so at most 2l qubits are affected by the degenerate errors. The errors on the remaining n−2l qubits must produce mutually orthogonal states. There are 3(n−2l) possible errors affecting those qubits.

Furthermore, errors on those qubits commute with the degenerate errors, since they act on different qubits, so if M|ψii = N|ψii and E is an error that acts on a qubit unaffected by the degenerate errors,

$$ME|\psi_i\rangle = EM|\psi_i\rangle = EN|\psi_i\rangle = NE|\psi_i\rangle.$$
 (A1)

Thus, the state E|ψii still satisfies the same set of degeneracy conditions. The space of states that satisfy the given set of l degeneracy conditions has dimension at most 2<sup>n</sup>−<sup>l</sup> . To fit all the states E|ψii inside it, if l ≤ n/2, we must have

$$[1 + 3(n - 2l)] 2^k \le 2^{n-l}, \tag{A2}$$

or

$$k \le n - l - \log_2 [1 + 3(n - 2l)] = g(l).$$
 (A3)

<sup>3</sup>The proof that the dimension of T is 2n−<sup>l</sup> given in section [II](#page-3-0) only works for the X, Y , Z basis, but for this appendix, I only need the weaker result that the dimension of T is at least halved by any degeneracy condition that constrains a qubit unaffected by any of the other degeneracy conditions. This should be self-evident.

| n  | k |
|----|---|
| 5  | 1 |
| 6  | 1 |
| 7  | 2 |
| 8  | 3 |
| 9  | 4 |
| 10 | 5 |
| 11 | 5 |
| 12 | 6 |
| 13 | 7 |

TABLE IV. The maximum k allowed by the quantum Hamming bound for n ≤ 13

For l = 0, this becomes the quantum Hamming bound. Now,

$$\frac{\mathrm{d}g}{\mathrm{d}l} = -1 + \frac{6/\ln 2}{1 + 3(n - 2l)}.$$
 (A4)

Therefore g(l) is decreasing for

$$1 + 3(n - 2l) \ge \frac{6}{\ln 2} \tag{A5}$$

$$l \le \frac{n}{2} - \left(\frac{1}{\ln 2} - \frac{1}{6}\right). \tag{A6}$$

Thus, the quantum Hamming bound holds for l ≤ (n − 3)/2. For l > (n − 3)/2, we still have k ≤ n − l < (n + 3)/2. This automatically satisfies the quantum Hamming bound for n ≥ 13 (see table IV).

For n < 13, l > (n − 3)/2, we need a different argument. When l < n − 1, there must always be at least one degeneracy condition that relates errors on two qubits that are unaffected by any other degeneracy conditions. There are three possible errors on each qubit, and only one pair of them are going to produce the same results, so there are still 5 <span id="page-15-0"></span>different errors, plus the possibility of no error. As above, these errors will remain within the space that satisfies the other l − 1 degeneracy conditions, so

$$(1+5) 2^k \le 2^{n-(l-1)},\tag{A7}$$

or k ≤ n−l+ (1−log<sup>2</sup> 6) (i.e., k ≤ n−l−2). When l > (n−3)/2, this means k ≤ (n−1)/2. Applying this condition for n ≤ 12 restricts violations of the quantum Hamming bound to n ≤ 6, specifically: n = 6 and l = 2, and n = 4 and l = 1. For these two cases, we can directly apply equation [\(A2\)](#page-13-0) to see that for n = 6 and l = 2, k ≤ 1, in accordance with the quantum Hamming bound; and for n = 4 and l = 1, k = 0.

Finally, for l = n − 1, there must be at least one qubit that is only affected by a single degeneracy condition. All three errors on this qubit commute with the other n−2 degeneracy conditions, so

$$(1+3) 2^k \le 2^{n-(n-2)} \tag{A8}$$

Therefore k = 0, and the quantum Hamming bound holds for any degenerate quantum code where linearly independent errors can only map code words into a one-dimensional subspace.

### APPENDIX B: PROOF THAT THE NUMBERS FOR Y<sup>i</sup> ARE ALL DIFFERENT

The construction of the numbers for X<sup>i</sup> and Z<sup>i</sup> immediately demonstrates that they are all different. However, it is not as clear that all of the numbers for the Y<sup>i</sup> 's, which are determined by the numbers for the X<sup>i</sup> 's and Z<sup>i</sup> 's, will also be different. The first two bits just enforce the requirement that any Y<sup>i</sup> is different from an X or a Z, so I will only consider the last j bits. All references to bit number in this appendix will refer to position within the last j bits, so bit number "1" is actually bit 3, and bit "l" is actually bit l + 2.

Consider the pictorial representation of the algorithm to pick the errors' binary numbers given in table [V](#page-16-0). The numbers given for X<sup>i</sup> are the actual numbers that appear. For Y<sup>i</sup> and Zi , we need to take an XOR with the parity of i (for j even or i ≤ 2 j−1 ), or an XOR with

<span id="page-16-0"></span>

|     | $X_i$ : |   |   |   |   |   |     |   |   |   |   |   |   |   |  |
|-----|---------|---|---|---|---|---|-----|---|---|---|---|---|---|---|--|
|     |         | 0 |   |   | 1 |   |     |   |   |   |   |   |   |   |  |
|     | 0 1     |   |   |   |   |   | 0 1 |   |   |   |   |   |   |   |  |
| 0   | 1       |   | 0 |   | 1 |   |     | 0 |   | 1 | 0 |   | 1 |   |  |
| 0 1 | 0       | 1 | 0 | 1 | 0 | 1 | 0   | 1 | 0 | 1 | 0 | 1 | 0 | 1 |  |
|     | •       |   |   |   |   |   | :   |   |   | • | • |   |   | • |  |

 $Z_i$ : Parity XOR

|   | 0   |   |     |   |   |   |   |   | 0 |   |   |   |   |   |   |  |  |
|---|-----|---|-----|---|---|---|---|---|---|---|---|---|---|---|---|--|--|
|   | 0 0 |   |     |   |   |   |   |   | 1 |   | 1 |   |   |   |   |  |  |
|   | 0 0 |   | 1 1 |   |   | 1 | 0 |   |   | 0 |   | 1 |   | 1 |   |  |  |
| 0 | 0   | 1 | 1   | 0 | 0 | 1 | 1 | 0 | 0 | 1 | 1 | 0 | 0 | 1 | 1 |  |  |
|   |     |   |     |   |   |   |   | : |   |   |   |   |   |   |   |  |  |

 $Y_i$ : Parity XOR

|   | 0   |     |  |   |   |   |   |   | 1 |   |   |   |   |   |   |   |   |
|---|-----|-----|--|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|   | 0 1 |     |  |   |   |   |   |   | 1 |   | 0 |   |   |   |   |   |   |
|   | 0   | 0 1 |  | Ĺ | 1 |   | 0 |   | 0 |   |   | 1 | 1 |   | 0 |   |   |
| ( | )   | 1   |  | 1 | 0 | ( | 1 | 1 | 0 | 0 | 1 | 1 | 0 | 0 | 1 | 1 | 0 |

TABLE V. The first 4 bits (of the last j) of the numbers for  $X_i$ ,  $Y_i$ , and  $Z_i$ . The pth row corresponds to the pth bit and the columns in the pth row correspond to the possible values for the first p bits of i. For  $Y_i$  and  $Z_i$ , the actual numbers require an additional XOR with the parity or reverse of the parity of i.

<span id="page-17-0"></span>the reverse of the parity of i (for j odd and  $i > 2^{j-1}$ ). We can see that before we apply the XOR, the number for  $Y_i$  encodes i in a unique fashion, since if i and i' first differ in the rth bit, then the numbers for  $Y_i$  and  $Y_{i'}$  will also differ in the rth bit. The only way we could get two of the numbers to be the same would be if the XOR operation reverses one of a pair that would normally have complementary values in all bits.

Does this ever happen? Given a number  $f(Y_i)$  for  $i \leq n/2$ , the number with complementary bits must appear for i > n/2, since the first digit does not change until then. The XOR will therefore collapse these two numbers into one whenever the parity of the appropriate i's is the same (for j odd) or different (for j even).

Pick some bit string starting with 0. There will be an  $i \leq n/2$  such that  $Y_i$  has that number. Which i' will have the complementary bitstring? If we take the binary representation of i, it will begin with a 0 and the binary representation of i' will begin with a 1.4 The next digit of i can be either 0 or 1, and from table V, we can see i' will have the same value for this digit. The third digits of i and i' will be opposite again. In general, a 0 in the i' digit of i' means the two squares relevant to the next digit will read 01, while a 1 in the i' digit will mean the two squares for the next digit will read 10. Thus, if i' agree in the i' digit, they will disagree in the next digit, and vice-versa. Thus, i' and i' agree on even-numbered digits and disagree on odd-numbered digits.

This means the last digit agrees for j even and disagrees for j odd. Therefore, the XOR will not make  $Y_i$  the same as  $Y_{i'}$  — it will either reverse both of them or neither of them. This explains why different rules for odd and even j were necessary.

<sup>&</sup>lt;sup>4</sup>I am ignoring the special case of i = n/2, which works on the same principle after the first digit of i.

#### APPENDIX C: PROOF THAT THE GENERATORS OF H COMMUTE

We can also use table [V](#page-16-0) to help us understand what the generators M1, . . .M<sup>a</sup> of H look like. M<sup>1</sup> is always the product of all n X<sup>i</sup> 's, and M<sup>2</sup> is always the products of all the Z<sup>i</sup> 's. The other generators are bit more complicated, but still behave systematically. As we advance i, they cycle through the sequence I → Z → X → Y , with a change every 2<sup>j</sup>−(r−2) qubits for generator Mr. In addition, the NOT switches I ↔ X and Z ↔ Y whenever it applies — odd qubits for even j; odd qubits for the first half and even qubits for the second half for odd j. This immediately implies that every M<sup>r</sup> for r > 2 has equal numbers of X's, Y 's, Z's, and I's, namely, 2<sup>j</sup>−<sup>2</sup> of each. Since j ≥ 3, this means there are an even number of Y 's, so M<sup>2</sup> <sup>r</sup> = +1.

Now, do the generators commute? Any time two generators have non-trivial but different operations on a qubit, we get a factor of -1 when we commute them. Therefore, we can determine if M<sup>r</sup> and M<sup>s</sup> commute by counting the qubits on which they differ and neither is the identity. If this count is even, they commute; if it is odd, they do not.

Since M<sup>1</sup> is all X's, it disagrees with M<sup>r</sup> (for r ≥ 3) whenever M<sup>r</sup> has a Y or a Z. M<sup>r</sup> has 2<sup>j</sup>−<sup>2</sup> of each, so we get 2<sup>j</sup>−<sup>1</sup> factors of -1, and [M1, Mr] = 0. Similarly, M<sup>2</sup> disagrees with M<sup>r</sup> on X's and Y 's, producing 2<sup>j</sup>−<sup>2</sup> + 2<sup>j</sup>−<sup>2</sup> factors of -1, and [M2, Mr] = 0 also. M<sup>1</sup> and M<sup>2</sup> disagree on every qubit, and since there are an even number of qubits, [M1, M2] = 0.

For r, s ≥ 3, both M<sup>r</sup> and M<sup>s</sup> follow the pattern described above. I will consider the cases s = r + 1, s = r + 2, and s > r + 2. Table [VI](#page-19-0) compares M<sup>r</sup> and M<sup>s</sup> on blocks of size 2 j−(s−2) .

In general, half of each block will be normal and half will be reversed by a NOT. Therefore, the number of factors of -1 from commuting M<sup>r</sup> and M<sup>s</sup> will generally be 2<sup>j</sup>−(s−3) times the total number of non-trivial disagreements for the normal and reversed rows. We also need to consider a few special cases. When r = 3, the generator never reaches the second half of the cycle, so we need to count up the disagreements only in the first half of the cycle. When s = a = j + 2, the block size is 1, so the NOT either affects the whole block or it does

<span id="page-19-0"></span>

| r<br>=<br>s<br>+ 1: |   |   |   |   |   |   |             |      |   |   |   |   |   |   |   |   |
|---------------------|---|---|---|---|---|---|-------------|------|---|---|---|---|---|---|---|---|
| Mr<br>norm          | I |   | I |   | Z |   | Z           |      | X |   | X |   | Y |   | Y |   |
| Ms<br>norm          | I |   | Z |   | X |   | Y           |      | I |   | Z |   | X |   | Y |   |
|                     |   |   |   |   |   |   |             |      |   |   |   |   |   |   |   |   |
| Mr<br>rev           | X |   | X |   | Y |   | Y           |      | I |   | I |   | Z |   | Z |   |
| Ms<br>rev           | X |   | Y |   | I |   | Z           |      | X |   | Y |   | I |   | Z |   |
|                     |   |   |   |   |   |   |             |      |   |   |   |   |   |   |   |   |
|                     |   |   |   |   |   |   | r<br>=<br>s | + 2: |   |   |   |   |   |   |   |   |
| Mr<br>norm          | I | I | I | I | Z | Z | Z           | Z    | X | X | X | X | Y | Y | Y | Y |
| Ms<br>norm          | I | Z | X | Y | I | Z | X           | Y    | I | Z | X | Y | I | Z | X | Y |
|                     |   |   |   |   |   |   |             |      |   |   |   |   |   |   |   |   |
| Mr<br>rev           | X | X | X | X | Y | Y | Y           | Y    | I | I | I | I | Z | Z | Z | Z |
| Ms<br>rev           | X | Y | I | Z | X | Y | I           | Z    | X | Y | I | Z | X | Y | I | Z |

TABLE VI. Comparisons of M<sup>r</sup> and M<sup>s</sup> in blocks of size 2j−(s−2) when the normal cycle applies and when it is reversed by a NOT.

not affect any of it. In this case, we need to count disagreements only on every other block. For even j, count the normal disagreements on even numbered blocks and the reversed disagreements on odd numbered blocks. For odd j, we must count normal disagreements on even-numbered blocks in the first half and odd-numbered blocks in the second half; count reversed disgreements on odd-numbered blocks in the first half and even-numbered blocks in the second half. We must also consider the combined special case of r = 3, s = a.

For s = r + 1, the general case gives 4 blocks with normal disagreements and 2 blocks with reversed disagreements. When r = 3, there are 2 blocks with normal disagreements and 2 blocks with reversed disagreements. When s = a, and j is even, there are 2 blocks with normal disagreements and 0 blocks with reversed disagreements. When s = a and j is odd, there are also 2 blocks with normal disagreements and 0 blocks with reversed disagreements. Because a ≥ 5, we do not need to consider the combined special case. Thus, whenever s = r + 1, there are an even number of disagreements and M<sup>r</sup> and M<sup>s</sup> commute.

For s = r + 2, the general case gives 6 blocks with normal disagreements and 6 blocks with reversed disagreements. For r = 3, there are 2 blocks with normal disagreements and 4 blocks with reversed disagreements. For s = a, j even, there are 4 blocks with normal disagreements and 2 blocks with reversed disagreements. For s = a, j odd, there are 2 blocks with normal disagreements and 2 blocks with reversed disagreements. For r = 3, s = a, it does not matter if j is even or odd, since we only consider the first half. In this case, there is 1 block with a normal disagreement and 1 block with a reversed disagreement. In all of these cases, the total number of disagreements is even, so for s = r + 2, [Mr, Ms] = 0.

For s > r + 2, generator M<sup>s</sup> completes 2<sup>s</sup>−r−<sup>2</sup> cycles before M<sup>r</sup> advances to the next step in the cycle. This means we can just find the number of disagreements by multiplying the number of disagreements for s = r + 2 by 2<sup>s</sup>−r−<sup>2</sup> . We can do this even for the special cases, since the cycle repeats after 4 steps, which does not change the parity. Thus, there will always be an even number of disagreements, and all of the generators of H commute.

# REFERENCES

- <span id="page-21-0"></span>[1] P. W. Shor, Phys. Rev. A 52, 2493 (1995).
- [2] A. R. Calderbank and P. W. Shor, [quant-ph/9512032](http://arxiv.org/abs/quant-ph/9512032), 1995.
- [3] A. Steane, [quant-ph/9601029](http://arxiv.org/abs/quant-ph/9601029), 1996.
- [4] R. Laflamme, C. Miquel, J. P. Paz, and W. H. Zurek, [quant-ph/9602019](http://arxiv.org/abs/quant-ph/9602019), 1996.
- [5] C. H. Bennett, D. P. DiVincenzo, J. A. Smolin, and W. K. Wootters, [quant-ph/9604024](http://arxiv.org/abs/quant-ph/9604024), 1996.
- [6] E. Knill, R. Laflamme, [quant-ph/9604034](http://arxiv.org/abs/quant-ph/9604034), 1996.
- [7] A. Ekert and C. Macchiavello, [quant-ph/9602022](http://arxiv.org/abs/quant-ph/9602022), 1996.
- [8] P. W. Shor and J. A. Smolin, [quant-ph/9604006](http://arxiv.org/abs/quant-ph/9604006), 1996.
- [9] S. Lloyd, [quant-ph/9604015,](http://arxiv.org/abs/quant-ph/9604015) 1996.
- [10] C. H. Bennett, G. Brassard, S. Popescu, B. Schumacher, J. A. Smolin, and W. K. Wootters, Phys. Rev. Lett. 76, 722 (1996).
- [11] A. R. Calderbank, E. M. Rains, P. W. Shor, and N. J. A. Sloane, [quant-ph/9605005](http://arxiv.org/abs/quant-ph/9605005), 1996.
- [12] A. M. Steane, [quant-ph/9605021](http://arxiv.org/abs/quant-ph/9605021), 1996.