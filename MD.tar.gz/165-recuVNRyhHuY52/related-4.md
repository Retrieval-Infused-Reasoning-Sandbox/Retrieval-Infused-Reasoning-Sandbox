# [On the Griesmer Bound for Systematic Codes](https://www.researchgate.net/publication/257812121_On_the_Griesmer_Bound_for_Systematic_Codes?enrichId=rgreq-6774ab89f1530d28c7441e1be77016df-XXX&enrichSource=Y292ZXJQYWdlOzI1NzgxMjEyMTtBUzoxNTIxNjAyMjIzMjI2ODhAMTQxMzI4OTIzMjAzNA%3D%3D&el=1_x_3&_esc=publicationCoverPdf)

| Article · October 2013 |                                 |  |
|------------------------|---------------------------------|--|
| Source: arXiv          |                                 |  |
|                        |                                 |  |
| CITATIONS              | READS                           |  |
| 0                      | 110                             |  |
|                        |                                 |  |
| 1 author:              |                                 |  |
|                        | Emanuele Bellini                |  |
|                        | Technology Innovation Institute |  |
|                        | 69 PUBLICATIONS   444 CITATIONS |  |
|                        | SEE PROFILE                     |  |

# On the Griesmer Bound for Systematic Codes

Emanuele Bellini (eemanuele.bellini@gmail.com)

Department of Mathematics, University of Trento, Italy.

## Abstract

We generalize the Griesmer bound in the case of systematic codes over a field of size q greater than the distance d of the code. We also generalize the Griesmer bound in the case of any systematic code of distance 2,3,4 and in the case of binary systematic codes of distance up to 6.

Keywords: systematic code, nonlinear code, Griesmer bound

# 1 Introduction

In this article we want to prove that the Griesmer Bound applies also to some systematic codes.

## 2 The Griesmer Bound

From now on let q be the power of a prime number, and n, k, d three integers such that a [q, n, k, d] systematic code exists. Let us recall the original bound given by Griesmer [1].

Theorem 2.1 (Griesmer bound). Let n be such that there exists an [q, n, k] linear code with distance at least d. Then

$$n \ge \sum_{j=0}^{k-1} \left\lceil \frac{d}{q^j} \right\rceil.$$

Lemma 2.2. If k = 1, then for each q, n, d such that a systematic code C exists, then

$$n \ge \sum_{j=0}^{k-1} \left\lceil \frac{d}{q^j} \right\rceil.$$

Proof. For k = 1 we have P<sup>k</sup>−<sup>1</sup> <sup>j</sup>=0 <sup>l</sup> d q j m = d, and clearly n ≥ d. In the following sections let C be a [q, n, k, d] systematic code, with  $k \geq 2$ , such that  $0 \in C$ , and let us indicate a word of C as  $c = (\bar{c}, \tilde{c})$ , where  $\bar{c}$  is the systematic part of c and  $\tilde{c}$  is the nonsystematic part of c.

### 3 The case $q \geq d$

**Theorem 3.1.** If  $q \ge d$ , for all  $k \ge 2$ , there exists no q-ary systematic code such that  $n < \sum_{i=0}^{k-1} \lceil \frac{d}{q^i} \rceil$ .

*Proof.* If  $q \geq d$  we have that  $\lceil \frac{d}{q^i} \rceil = 1$  for all  $i \geq 1$ , and so:

$$\sum_{i=0}^{k-1} \left\lceil \frac{d}{q^i} \right\rceil = d + \left\lceil \frac{d}{q} \right\rceil + \dots + \left\lceil \frac{d}{q^{k-1}} \right\rceil = d + k - 1$$

But we also have, by the Singleton bound, that  $n \geq d + k - 1$ .  $\square$ 

#### 4 The case d = 1, 2, 3, 4

**Theorem 4.1.** If d = 1, 2, than for all  $k \ge 2$ , there exists no q\_ary systematic code such that  $n < \sum_{i=0}^{k-1} \left\lceil \frac{d}{a^i} \right\rceil$ .

*Proof.* If d=1,2 we have  $q\geq d$  an so we are in the hypothesis of Theorem 3.1.  $\square$ 

**Theorem 4.2.** If d = 3, 4, then for all  $k \ge 2$ , there exists no q\_ary systematic code such that  $n < \sum_{i=0}^{k-1} \lceil \frac{d}{a^i} \rceil$ .

*Proof.* If d=3 and  $q\geq 3$  or d=4 and  $q\geq 4$  then we are in the hypothesis of Theorem 3.1.

Otherwise, if d=3 and q=2 or d=4 and q=2,3 then we have that  $\left\lceil \frac{d}{q} \right\rceil = 2$  and  $\left\lceil \frac{d}{q^i} \right\rceil = 1$  for all  $i \geq 2$ , and so:

$$\sum_{i=0}^{k-1} \left\lceil \frac{d}{q^i} \right\rceil = d + \left\lceil \frac{d}{q} \right\rceil + \dots + \left\lceil \frac{d}{q^{k-1}} \right\rceil = d + k$$

Suppose by contradiction that n < d + k. It is enough to prove the case n = d + k - 1. Then n - k = d - 1. Since  $0 \in C$ , if we consider two different words  $c_1 = (\bar{c}_1, \tilde{c}_1), c_2 = (\bar{c}_2, \tilde{c}_2)$  such that  $w(\bar{c}_1) = w(\bar{c}_2) = 1$ , then  $w(\tilde{c}_1) = w(\tilde{c}_2) = d - 1$  and, if q = 2 then  $\tilde{c}_1 = \tilde{c}_2 = (1, \ldots, 1)$ , and so  $(c_1, c_2) \leq 2$ , contradiction. There is only one case left, which is the case q = 3 and d = 4. In this case, since  $k \geq 2$ , we have at least 9 words in C. Consider the following

Emanuele Bellini 3

four words:

$$c_0 = (\bar{c}_0, \tilde{c}_0) = (0 \dots 0000, 0 \dots 0)$$

$$c_1 = (\bar{c}_1, \tilde{c}_1) = (0 \dots 0001, c_{11}c_{12}c_{13})$$

$$c_2 = (\bar{c}_2, \tilde{c}_2) = (0 \dots 0002, c_{21}c_{22}c_{23})$$

$$c_3 = (\bar{c}_3, \tilde{c}_3) = (0 \dots 0010, c_{31}c_{32}c_{33})$$

Since the distance between  $c_1, c_2, c_3$  from  $c_0$  must be greater than d, then  $\tilde{c}_1, \tilde{c}_2, \tilde{c}_3$  must have weigth 3.  $c_{11}, c_{12}, c_{13}$  can be any combination of 1 and 2, let us suppose  $(c_{11}, c_{12}, c_{13}) = (111)$ . Then, to have  $(c_1, c_2) \geq 4$ , we must have  $(c_{21}, c_{22}, c_{23}) = (222)$ . And for the same reason  $(c_{31}c_{32}c_{33})$  must differ from  $(c_{11}c_{12}c_{13})$  and from  $(c_{21}c_{22}c_{23})$  in at least two positions at the same time, but this is not possible.  $\square$ 

#### 5 The case q = 2 and d = 5, 6

**Theorem 5.1.** For k=2, there exists no binary systematic code such that  $n < \sum_{i=0}^{k-1} \lceil \frac{d}{2^i} \rceil$  for d=5,6.

Proof. If k=2 then  $\sum_{i=0}^{1} \lceil \frac{d}{2^i} \rceil = d + \lceil \frac{d}{2} \rceil = d+3$ . Suppose by contradiction that n < d+3. It is enough to prove the case n=d+2. Consider two different words  $c_1=(\bar{c}_1,\tilde{c}_1),c_2=(\bar{c}_2,\tilde{c}_2)$  such that  $\mathrm{w}(\bar{c}_1)=\mathrm{w}(\bar{c}_2)=1$ , then  $\mathrm{w}(\tilde{c}_1)=\mathrm{w}(\tilde{c}_2)\geq d-1$ . Since n-k=d, then  $(\tilde{c}_1,\tilde{c}_2)\leq 2$  and thus  $(c_1,c_2)\leq 4$ .  $\square$ 

**Theorem 5.2.** For all  $k \geq 3$ , there exists no binary systematic code such that  $n < \sum_{i=0}^{k-1} \lceil \frac{d}{2^i} \rceil$  for d = 5, 6.

*Proof.* If d = 5, 6, we have that  $\lceil \frac{d}{2} \rceil = 3$ ,  $\lceil \frac{d}{4} \rceil = 2$  and  $\lceil \frac{d}{2^i} \rceil = 1$  for all  $i \ge 3$ , and so:

$$\sum_{i=0}^{k-1} \left\lceil \frac{d}{2^i} \right\rceil = d + \left\lceil \frac{d}{2} \right\rceil + \left\lceil \frac{d}{4} \right\rceil + \dots + \left\lceil \frac{d}{2^{k-1}} \right\rceil = d + 5 + k - 3 = d + k + 2$$

Suppose by contradiction that n < d + k + 2. It is enough to prove the case n = d + k + 1, so that n - k = d + 1. Let us consider the following five words:

$$c_{0} = (\bar{c}_{0}, \tilde{c}_{0}) = (0 \dots 0000, 0 \dots 0)$$

$$c_{1} = (\bar{c}_{1}, \tilde{c}_{1}) = (0 \dots 0001, c_{11} \dots c_{1,d+1})$$

$$c_{2} = (\bar{c}_{2}, \tilde{c}_{2}) = (0 \dots 0010, c_{21} \dots c_{2,d+1})$$

$$c_{3} = (\bar{c}_{3}, \tilde{c}_{3}) = (0 \dots 0011, c_{31} \dots c_{3,d+1})$$

$$c_{5} = (\bar{c}_{5}, \tilde{c}_{5}) = (0 \dots 0101, c_{51} \dots c_{5,d+1})$$

We want to show that there is no way to assign 0 or 1 to the  $c_{ij}$  to obtain distance d between these five words. Let us do the following considerations:

- (1) to have  $(c_1, c_0) = w(c_1) \ge d$  and  $(c_2, c_0) = w(c_2) \ge d$ , it must be that  $w(\tilde{c_1}), w(\tilde{c_2}) \ge d 1$ . Clearly it is not possible that  $w(\tilde{c_1}), w(\tilde{c_2}) \ge d$ , otherwise  $(c_1, c_2) \le 4$ . So, wlog, we have only one of the two following cases:
  - (a) either  $w(\tilde{c_1}) = d$  and  $w(\tilde{c_2}) = d 1$ ,
  - (b) or  $w(\tilde{c_1}) = w(\tilde{c_2}) = d 1$ .
- (2) to have  $w(c_3), w(c_5) \geq d$ , it must be that  $w(\tilde{c_3}), w(\tilde{c_5}) \geq d 2$ .

Consider the case (1.a). Since  $(\bar{c_1}, \bar{c_3}) = 1$  and  $w(\tilde{c_1}) = d$ , the only way to have distance at least d between  $c_0, c_1, c_3$  (modulo the permutation of the colums) is to assign the following values to  $c_1, c_3$ :

$$c_{0} = (\bar{c}_{0}, \tilde{c}_{0}) = (0 \dots 0000, 000000)$$

$$c_{1} = (\bar{c}_{1}, \tilde{c}_{1}) = (0 \dots 0001, 011111)$$

$$c_{3} = (\bar{c}_{3}, \tilde{c}_{3}) = (0 \dots 0011, 111000)$$

$$c_{2} = (\bar{c}_{2}, \tilde{c}_{2}) = (0 \dots 0010, c_{21} \dots c_{2,d+1})$$

$$c_{5} = (\bar{c}_{5}, \tilde{c}_{5}) = (0 \dots 0101, c_{51} \dots c_{5,d+1})$$

in case d = 5 and:

$$c_0 = (\bar{c}_0, \tilde{c}_0) = (0 \dots 0000, 0000000)$$

$$c_1 = (\bar{c}_1, \tilde{c}_1) = (0 \dots 0001, 0111111)$$

$$c_3 = (\bar{c}_3, \tilde{c}_3) = (0 \dots 0011, 1111000)$$

$$c_2 = (\bar{c}_2, \tilde{c}_2) = (0 \dots 0010, c_{21} \dots c_{2,d+1})$$

$$c_5 = (\bar{c}_5, \tilde{c}_5) = (0 \dots 0101, c_{51} \dots c_{5,d+1})$$

in the case d=6.

This allows to have  $(\tilde{c_1}, \tilde{c_3}) = d - 1$ , which is the only we can reach in our conditions.

Now consider  $c_2$ .  $\tilde{c_1}$  has only a zero and d ones, and  $\tilde{c_2}$  has d-1 ones, which are either in the same postitions of the ones in  $\tilde{c_1}$  (this case is impossible because otherwise  $(\tilde{c_1}, \tilde{c_2}) = 1 \implies (c_1, c_2) = 3$ ) or  $c_{21} = 1$ . Since  $w(c_2) = d$ , there remain d bits to be filled in  $\tilde{c_2}$ , and d-2 of this bit must be ones and the other 2 zeros. Since  $c_{31} = c_{21} = 1$ , to have  $(\tilde{c_3}, \tilde{c_2}) \ge d-1$ , at least d-1 of the d rightmost bits must differ. Thus we have the following situation in case d=5:

$$c_0 = (\bar{c}_0, \tilde{c}_0) = (0 \dots 0000, 000000)$$

$$c_1 = (\bar{c}_1, \tilde{c}_1) = (0 \dots 0001, 011111)$$

$$c_3 = (\bar{c}_3, \tilde{c}_3) = (0 \dots 0011, 111000)$$

$$c_2 = (\bar{c}_2, \tilde{c}_2) = (0 \dots 0010, 100111)$$

$$c_5 = (\bar{c}_5, \tilde{c}_5) = (0 \dots 0101, c_{51} \dots c_{56})$$

Emanuele Bellini 5

and in the following situation in case d = 6:

$$c_0 = (\bar{c}_0, \tilde{c}_0) = (0 \dots 0000, 0000000)$$

$$c_1 = (\bar{c}_1, \tilde{c}_1) = (0 \dots 0001, 0111111)$$

$$c_3 = (\bar{c}_3, \tilde{c}_3) = (0 \dots 0011, 1111000)$$

$$c_2 = (\bar{c}_2, \tilde{c}_2) = (0 \dots 0010, 1001111)$$

$$c_5 = (\bar{c}_5, \tilde{c}_5) = (0 \dots 0101, c_{51} \dots c_{57})$$

Now,  $\tilde{c_5}$  must be such that  $w(\tilde{c_5}) \geq d-2$  and  $(\tilde{c_5}, \tilde{c_1}) \geq d-1$ . Thus in  $\tilde{c_5}$  there must be at most d+1-(d-2)=3 zero components, which is a contradiction because, in the case d=5, if:

$$c_0 = (\bar{c}_0, \tilde{c}_0) = (0 \dots 0000, 000000)$$

$$c_1 = (\bar{c}_1, \tilde{c}_1) = (0 \dots 0001, 011111)$$

$$c_3 = (\bar{c}_3, \tilde{c}_3) = (0 \dots 0011, 111000)$$

$$c_2 = (\bar{c}_2, \tilde{c}_2) = (0 \dots 0010, 100111)$$

$$c_5 = (\bar{c}_5, \tilde{c}_5) = (0 \dots 0101, 100011)$$

or, in the case d = 6, if:

$$c_0 = (\bar{c}_0, \tilde{c}_0) = (0 \dots 0000, 0000000)$$

$$c_1 = (\bar{c}_1, \tilde{c}_1) = (0 \dots 0001, 0111111)$$

$$c_3 = (\bar{c}_3, \tilde{c}_3) = (0 \dots 0011, 1111000)$$

$$c_2 = (\bar{c}_2, \tilde{c}_2) = (0 \dots 0010, 1001111)$$

$$c_5 = (\bar{c}_5, \tilde{c}_5) = (0 \dots 0101, 1000111)$$

then  $(c_2, c_5) = 4$ .

Let us try now with case (1.b), so that we know  $w(\tilde{c_1}) = w(\tilde{c_2}) = d - 1$ . We also have that  $(\tilde{c_1}, \tilde{c_2}) \ge d - 2$ , and at the same time  $(\tilde{c_1}, \tilde{c_2})$  can only be 0, 2, 4, since there are only two zeros components both in  $\tilde{c_1}$  and in  $\tilde{c_2}$ , and  $c_1$  and  $c_2$  have the same parity. Since d - 2 > 2, then  $(\tilde{c_1}, \tilde{c_2})$  must be 4 and the only choice (modulo permutation of the columns) for  $\tilde{c_1}, \tilde{c_2}$  is:

$$c_0 = (\bar{c}_0, \tilde{c}_0) = (0 \dots 0000, 000000|0)$$

$$c_1 = (\bar{c}_1, \tilde{c}_1) = (0 \dots 0001, 001111|1)$$

$$c_2 = (\bar{c}_2, \tilde{c}_2) = (0 \dots 0010, 111100|1)$$

$$c_4 = (\bar{c}_4, \tilde{c}_4) = (0 \dots 0100, c_{41} \dots c_{4,d+1})$$

$$c_3 = (\bar{c}_3, \tilde{c}_3) = (0 \dots 0011, c_{31} \dots c_{3,d+1})$$

where the rightmost component exists only in the case d = 6.

Now consider  $c_4$ , which must be such that  $w(\tilde{c_4}) = d - 1$  (it can not be d or d+1, otherwise we would be in a similar case to (1.a)), so that it has two zero components which, using a reasoning similar to that for  $\tilde{c_1}$  and  $\tilde{c_2}$ , to have

 $(\tilde{c_1}, \tilde{c_4}) = (\tilde{c_4}, \tilde{c_2}) = 4$ , must be positioned as follows:

$$c_0 = (\bar{c}_0, \tilde{c}_0) = (0 \dots 0000, 000000|0)$$

$$c_1 = (\bar{c}_1, \tilde{c}_1) = (0 \dots 0001, 001111|1)$$

$$c_2 = (\bar{c}_2, \tilde{c}_2) = (0 \dots 0010, 111100|1)$$

$$c_4 = (\bar{c}_4, \tilde{c}_4) = (0 \dots 0100, 110011|1)$$

$$c_3 = (\bar{c}_3, \tilde{c}_3) = (0 \dots 0011, c_{31} \dots c_{3,d+1})$$

Now,  $c_3$  is such that  $w(\tilde{c_3}) \ge d - 2$ .

 $w(\tilde{c_3}) = d+1$  or  $w(\tilde{c_3}) = d$  is not possible, otherwise we would have  $(c_3, c_1) \le 4$ .  $w(\tilde{c_3}) = d-1$  is not possible in the case d=6, because, having only two zeros the value  $(c_3, c_1)$  can be at most 5.

In the case d = 5, if  $w(\tilde{c_3}) = d - 1$ , to have  $(c_3, c_1) \geq 5$  the two leftmost component of  $\tilde{c_3}$  must be the same as the two leftmost component of  $\tilde{c_2}$  and of  $\tilde{c_4}$ , which are ones, giving either  $(c_3, c_2) = 5$  and  $(c_3, c_4) = 3$ , or  $(c_3, c_2) < 5$ , which is a contradiction.

It remains to prove that  $w(\tilde{c}_3) \neq d-2$ . In this case, again, to have  $(c_3, c_1) \geq d$  the two leftmost component of  $\tilde{c}_3$  must be the same as the two leftmost component of  $\tilde{c}_2$  and of  $\tilde{c}_4$ , which are ones, obtaining actually  $(c_3, c_1) = 6$ . In the remaining components of  $\tilde{c}_3$  there must be three zeros. If these three zeros are in the same positions where the leftmost ones of  $\tilde{c}_2$  are, then  $(c_3, c_2) = d$  and  $(c_3, c_4) \leq 4$ . Otherwise  $(c_3, c_2) < d$ .

This completes our proof.

### References

[1] Griesmer, J.H.: A bound for error-correcting codes. IBM Journal of Res. and Dev., vol. 4, no. 5, pp. 532-542, 1960.