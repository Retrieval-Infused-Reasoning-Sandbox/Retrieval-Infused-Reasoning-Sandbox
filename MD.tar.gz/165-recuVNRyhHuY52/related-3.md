# Optimal linear codes with few weights from simplicial complexes

Bing Chen, Yunge Xu, Zhao Hu, Nian Li, Xiangyong Zeng

## **Abstract**

Recently, constructions of optimal linear codes from simplicial complexes have attracted much attention and some related nice works were presented. Let q be a prime power. In this paper, by using the simplicial complexes of  $\mathbb{F}_q^m$  with one single maximal element, we construct four families of linear codes over the ring  $\mathbb{F}_q + u\mathbb{F}_q$  ( $u^2 = 0$ ), which generalizes the results of [IEEE Trans. Inf. Theory 66(6):3657-3663, 2020]. The parameters and Lee weight distributions of these four families of codes are completely determined. Most notably, via the Gray map, we obtain several classes of optimal linear codes over  $\mathbb{F}_q$ , including (near) Griesmer codes and distance-optimal codes.

#### **Index Terms**

Optimal linear code, Simplicial Complex, Lee weight distribution, Code over ring

## I. INTRODUCTION

Let  $\mathbb{F}_{q^m}$  be the finite field with  $q^m$  elements and  $\mathbb{F}_{q^m}^* = \mathbb{F}_{q^m} \setminus \{0\}$ , where q is a power of a prime p and m is a positive integer. An [n,k,d] linear code C over  $\mathbb{F}_q$  is a k-dimensional subspace of  $\mathbb{F}_q^n$  with minimum Hamming distance d. Let  $A_i$  denote the number of codewords with Hamming weight i in a code C of length n. The weight enumerator of C is defined by  $1 + A_1z + A_2z^2 + \cdots + A_nz^n$ . The sequence  $(1,A_1,A_2,\cdots,A_n)$  is called the weight distribution of C. A code is said to be a t-weight code if the number of nonzero  $A_i$  in the sequence  $(A_1,A_2,\cdots,A_n)$  is equal to t. Linear codes with few weights have applications in secret sharing schemes [1], [3], authentication codes [6], [8], association schemes [2], strongly regular graphs and some other fields.

An [n,k,d] linear code  $\mathcal{C}$  over  $\mathbb{F}_q$  is said to be distance-optimal if no [n,k,d+1] code exists (i.e., this code has the largest minimum distance for given length n and dimension k) and it is called almost distance-optimal if there exists an [n,k,d+1] distance-optimal code. An [n,k,d] linear code  $\mathcal{C}$  is called optimal (resp. almost optimal) if its parameters n, k and d (resp. d+1) meet a bound on linear codes with equality [15]. The Griesmer bound [10], [26] for an [n,k,d] linear code  $\mathcal{C}$  over  $\mathbb{F}_q$  is given by

$$n \ge g(k,d) := \sum_{i=0}^{k-1} \lceil \frac{d}{q^i} \rceil,$$

where  $\lceil \cdot \rceil$  denotes the ceiling function. An [n,k,d] linear code  $\mathcal{C}$  is called a Griesmer code (resp. near Griesmer code) if its parameters n (resp. n-1), k and d achieve the Griesmer bound.

In 2007, Ding and Niederreiter [7] introduced a nice and generic way to construct linear codes via trace functions. Let  $D \subset \mathbb{F}_{q^m}$  and define

$$C_D = \{c_a = (\operatorname{Tr}_q^{q^m}(ax))_{x \in D} : a \in \mathbb{F}_{q^m}\},$$

where  $\operatorname{Tr}_q^{q^m}(\cdot)$  is the trace function from  $\mathbb{F}_{q^m}$  to  $\mathbb{F}_q$ . Then  $\mathcal{C}_D$  is a linear code of length n:=|D| over  $\mathbb{F}_q$  and the set D is called the defining set of  $\mathcal{C}_D$ . Many attempts have been made in this direction by selecting

B. Chen, Y. Xu and X. Zeng are with the Hubei Key Laboratory of Applied Mathematics, Faculty of Mathematics and Statistics, Hubei University, Wuhan, 430062, China. Z. Hu and N. Li are with the Hubei Provincial Engineering Research Center of Intelligent Connected Vehicle Network Security, School of Cyber Science and Technology, Hubei University, Wuhan, 430062, China. Email: chenbing@hubu.edu.cn, xuy@hubu.edu.cn, zhao.hu@aliyun.com, nian.li@hubu.edu.cn, xiangyongzeng@aliyun.com

proper defining set to obtain good or optimal linear codes, see, for example, [5], [11], [12], [16], [18], [20], [21], [31] and references therein.

Let R be a finite commutative ring and  $R_m$  be an extension of R of degree m. A trace code over R with defining set  $L \subset R_m^*$  is defined by

<span id="page-1-0"></span>
$$C_L = \{c_a = (\operatorname{Tr}(ax))_{x \in L} : a \in R_m\}$$
(1)

where  $R_m^*$  is the multiplicative group of units of  $R_m$  and  $\text{Tr}(\cdot)$  is a linear function from  $R_m$  to R. Using the construction above, some good linear codes over rings were contructed in the previous works, see, for example, [13], [19], [22], [24], [25], [29] and references therein.

Recently, constructing optimal or good linear codes from simplicial complexes has attracted much attention from researchers. Some optimal linear codes over the finite field  $\mathbb{F}_q$  or the ring R has been constructed in this direction. For the results on constructing linear codes over finite fields from simplicial complexes, we refer the readers to [4], [14], [16] and references therein. As for linear codes over the ring R, to the best of my knowledge, Wu et al. (in 2020) were the first to construct linear codes over  $R = \mathbb{F}_2 + u\mathbb{F}_2$  ( $u^2 = 0$ ) from simplicial complexes of  $\mathbb{F}_2^m$  with one maximal element, from which two classes of optimal few-weight binary codes were obtained via the Gray map. Later, Wu et al. [27] constructed linear codes over  $\mathbb{F}_p + u\mathbb{F}_p$  ( $u^2 = 0$  and p is a prime) from simplicial complexes of  $\mathbb{F}_p^m$  with one maximal element, and obtained 2(p-1) classes of p-ary distance-optimal linear codes. In 2021, Li et al. [17] constructed a family of linear codes over  $R = \mathbb{F}_2 + u\mathbb{F}_2 + u^2\mathbb{F}_2$  ( $u^3 = 0$ ) from simplicial complexes of  $\mathbb{F}_2^m$  with one maximal element, from which a new family of optimal binary few-weight codes was derived. In the same year, Shi et al. [23] constructed two classes of linear codes over  $\mathbb{F}_p + u\mathbb{F}_p$  ( $u^2 = u$ ) from simplcial complexes of  $\mathbb{F}_p^m$  with one maximal element, and two classes of distance-optimal p-ary linear codes were presented by using the Gray map. In 2024, Wu et al. [28] prsented interesting constructions of linear codes over  $\mathbb{Z}_4$  by using the simplicial complexes of  $\mathbb{F}_2^m$  with one or two maximal elements.

In this paper, inspired by the previous works, we investigate the linear codes over the ring  $R = \mathbb{F}_q + u\mathbb{F}_q$  ( $u^2 = 0$ ) by employing the simplicial complexes of  $\mathbb{F}_q^m$ . Let  $\Delta_A$ ,  $\Delta_B$  and  $\Delta_{B'}$  be simplicial complexes of  $\mathbb{F}_q^m$  with one maximal element, where A and B are subsets of [m] and B' is a subset of B. We focus on the four families of linear codes  $C_L$  over  $R = \mathbb{F}_q + u\mathbb{F}_q$  defined by (1) with the following defining sets:

<span id="page-1-2"></span>1): 
$$L = \Delta_A + u(\Delta_B \setminus \Delta_{B'});$$
  
2):  $L = \Delta_A^c + u(\Delta_B \setminus \Delta_{B'});$   
3):  $L = \Delta_A + u(\Delta_B \setminus \Delta_{B'})^c;$   
4):  $L = \Delta_A^c + u(\Delta_B \setminus \Delta_{B'})^c,$  (2)

where  $\Delta^c$  denotes the complement of  $\Delta$  for a set  $\Delta$  of  $\mathbb{F}_{q^m}$ . Notice that the codes  $\mathcal{C}_L$  with defining sets 1) and 2) are reduced to the codes studied in [29] if q=2 ane |B|=m. By employing some detailed calculations on certain exponential sums, we obtained infinite families of few-weight linear codes with flexible parameters, and completely determined the parameters and Lee weight distributions of these four families of linear codes over  $\mathbb{F}_q + u\mathbb{F}_q$ . Most notably, under the Gray map  $\phi$ , several classes of optimal linear codes over  $\mathbb{F}_q$  are derived by characterizing the optimality of the Gray images  $\phi(\mathcal{C}_L)$  using the Griesmer bound, which include the (near) Griesmer codes and distance-optimal linear codes.

The rest of this paper is organized as follows. In Section II, we introduce some concepts and results. In Sections III, we determine the parameters and Lee weight distributions of these four infinite families of linear codes  $C_L$  over  $\mathbb{F}_q + u\mathbb{F}_q$  with defining sets given by (2). In Section IV, by employing the Gray map, we obtain several infinite families of optimal linear codes over  $\mathbb{F}_q$  and present some examples. Section V concludes this paper.

## II. PRELIMINARIES

<span id="page-1-1"></span>In this section, we introduce some notation, definitions and lemmas which will be used later. Starting from now on, we adopt the following notation unless otherwise stated:

- q is a power of a prime p, and m is a positive integer.
- Identify the vector space  $\mathbb{F}_q^m$  with the finite field  $\mathbb{F}_{q^m}$  since  $\mathbb{F}_q^m$  is isomorphic to  $\mathbb{F}_{q^m}$ .
- Let  $R = \mathbb{F}_q + u\mathbb{F}_q$  with  $u^2 = 0$ .
- For a positive integer e,  $[e] = \{1, \dots, e\}$ .
- For a set S, |S| denotes the cardinality of S.
- For a vector  $x \in \mathbb{F}_q^m$ , wt(x) denotes the Hamming weight of x; for a vector  $y \in \mathbb{R}^n$ ,  $wt_L(y)$  denotes the Lee weight of y.
- $\operatorname{Tr}_q^{q^m}(\cdot)$  denotes the trace function from  $\mathbb{F}_{q^m}$  to  $\mathbb{F}_q$ .
- $\chi(\cdot)$  denotes the canonical additive character of  $\mathbb{F}_q$ , i.e.  $\chi(\cdot) = \zeta_p^{\operatorname{Tr}_p^q(\cdot)}$ , where  $\zeta_p$  is a primitive complex p-th root of unity and  $\operatorname{Tr}_p^q(\cdot)$  is the trace function from  $\mathbb{F}_q$  to  $\mathbb{F}_p$ .
- $\Delta_A$  is a simplicial complex of  $\mathbb{F}_q^m$  with one maximal element, where  $A \subseteq [m]$  is the support of the maximal element.

## A. The definition of simplicial complexes of $\mathbb{F}_q^m$

For two vectors  $u = (u_1, u_2, ..., u_m)$  and  $v = (v_1, v_2, ..., v_m)$  in  $\mathbb{F}_q^m$ , we say that u covers v, denoted  $v \leq u$ , if  $\operatorname{Supp}(v) \subseteq \operatorname{Supp}(u)$ , where  $\operatorname{Supp}(u) = \{1 \leq i \leq m : u_i \neq 0\}$  is the support of u. A subset  $\Delta$  of  $\mathbb{F}_q^m$  is called a **simplicial complex** if  $u \in \Delta$  and  $v \leq u$  imply  $v \in \Delta$ .

For a simplicial complex  $\Delta \subseteq \mathbb{F}_q^m$ , an element u in  $\Delta$  with entries 0 or 1 is said to be maximal if there is no element  $v \in \Delta$  such that  $\operatorname{Supp}(u)$  is a proper subset of  $\operatorname{Supp}(v)$ . Let  $\mathcal{F} = \{F_1, F_2, \ldots, F_h\}$  be the set of maximal elements of  $\Delta$ , where h is the number of maximal elements in  $\Delta$  and  $F_i$ 's are maximal elements of  $\Delta$ . Let  $A_i = \operatorname{Supp}(F_i)$  for  $1 \le i \le h$ , which implies  $A_i \subseteq [m]$ . Let  $\mathcal{A} = \{A_1, A_2, \ldots, A_h\}$  be the set of supports of maximal elements of  $\Delta$ , and  $\mathcal{A}$  is said to be the support of  $\Delta$ , denoted  $\operatorname{Supp}(\Delta) = \mathcal{A}$ . Then one can see that a simplicial complex  $\Delta$  is uniquely generated by  $\mathcal{A}$ , denoted  $\Delta = \langle \mathcal{A} \rangle$ . Notice that both the set of maximal elements  $\mathcal{F}$  and the support  $\mathcal{A}$  of  $\Delta$  are unique for a fixed simplicial complex  $\Delta$ .

It should be noted that the simplicial complex  $\Delta_A = \langle \{A\} \rangle$  with exactly one maximal element is an |A|-dimensional subspace of  $\mathbb{F}_q^m$ . Let  $\{\alpha_1, \ldots, \alpha_m\}$  be a basis of  $\mathbb{F}_{q^m}$  over  $\mathbb{F}_q$ . Then  $\Delta_A$  can be viewed as an |A|-dimensional  $\mathbb{F}_q$ -subspace of  $\mathbb{F}_{q^m}$  spanned by the set  $\{\alpha_i : i \in A\}$ . Specially, when  $A = \emptyset$  (i.e., |A| = 0), we have  $\Delta_A = \{0\}$ . For more details on simplicial complexes, we refer the readers to [4], [14], [29].

## B. Linear codes over the ring R

Let  $R = \mathbb{F}_q + u\mathbb{F}_q$  with  $u^2 = 0$ . A linear code  $\mathcal{C}$  of length n over R is an R-submodule of  $R^n$ . For any  $a + ub \in R$  where  $a, b \in \mathbb{F}_q$ , the Gray map  $\phi$  from R to  $\mathbb{F}_q^2$  is defined by

$$\phi: R \to \mathbb{F}_q^2, a + ub \mapsto (b, a + b).$$

Any vector  $\mathbf{x} \in R^n$  can be written as  $\mathbf{x} = \mathbf{a} + u\mathbf{b}$  where  $\mathbf{a}, \mathbf{b} \in \mathbb{F}_q^n$ . The map  $\phi$  is a bijection, which can be extended naturally from  $R^n$  to  $\mathbb{F}_q^{2n}$  as follows:

$$\phi: \mathbb{R}^n \to \mathbb{F}_q^{2n}, \mathbf{x} = \mathbf{a} + u\mathbf{b} \mapsto (\mathbf{b}, \mathbf{a} + \mathbf{b}).$$

The Hamming weight  $wt(\mathbf{a})$  of a vector  $\mathbf{a} \in \mathbb{F}_q^n$  is the number of nonzero coordinates in  $\mathbf{a}$ . The Lee weight  $wt_L(\mathbf{a} + u\mathbf{b})$  of a vector  $\mathbf{a} + u\mathbf{b} \in R^n$  is the Hamming weight of its Gray image  $\phi(\mathbf{a} + u\mathbf{b})$  as follows:

$$wt_L(\mathbf{a} + u\mathbf{b}) = wt(\mathbf{b}) + wt(\mathbf{a} + \mathbf{b}).$$

The Lee distance of  $\mathbf{x}, \mathbf{y} \in R^n$  is defined as  $wt_L(\mathbf{x} - \mathbf{y})$ . It is easy to check that the Gray map is an isometry from  $(R^n, d_L)$  and  $(\mathbb{F}_q^{2n}, d_H)$ .

Let  $\mathcal{R} = \mathbb{F}_{q^m} + u\mathbb{F}_{q^m}$  with  $u^2 = 0$ . Let F be the Frobenius operator over  $\mathcal{R}$  defined by  $F(a + ub) = a^q + ub^q$ . The trace function  $Tr(\cdot)$  is defined by

$$\operatorname{Tr} = \sum_{i=0}^{m-1} F^i : \mathcal{R} \to R, a + ub \mapsto \sum_{i=0}^{m-1} F^i(a + ub) = \sum_{i=0}^{m-1} (a^{q^i} + ub^{q^i}).$$

By the definition above, it can be readily verified that

$$\operatorname{Tr}(a+ub) = \operatorname{Tr}_q^{q^m}(a) + u\operatorname{Tr}_q^{q^m}(b),$$

where  $\operatorname{Tr}_q^{q^m}(\cdot)$  denotes the trace function from  $\mathbb{F}_{q^m}$  to  $\mathbb{F}_q$ .

With the discussion above, the Lee weight of the trace code  $C_L$  for a general defining set L can be determined by the following lemma.

<span id="page-3-1"></span>**Lemma 1.** ([13]) Let  $L = L_1 + uL_2$  where  $L_1, L_2 \in \mathbb{F}_{q^m}$ . Then  $C_L$  is a code of length |L| over R and for any  $a + ub \in \mathcal{R} \setminus \{0\}$ , the Lee weight of the codeword  $c_{a+ub}$  in  $C_L$  is  $wt_L(c_{a+ub}) = 2|L| - \Omega$  where

$$\Omega = \frac{1}{q} \sum_{u \in \mathbb{F}_q} \sum_{y \in L_2} \chi(u \operatorname{Tr}_q^{q^m}(ay)) \sum_{x \in L_1} (\chi(u \operatorname{Tr}_q^{q^m}(bx)) + \chi(u \operatorname{Tr}_q^{q^m}((a+b)x))).$$

## C. Useful auxiliary results

For an r-dimensional  $\mathbb{F}_q$ -subspace H of  $\mathbb{F}_{q^m}$ , the dual of H is defined by

$$H^{\perp} = \{ v \in \mathbb{F}_{q^m} : \operatorname{Tr}_q^{q^m}(uv) = 0 \text{ for all } u \in H \}.$$

The dual  $H^{\perp}$  is an (m-r)-dimensional  $\mathbb{F}_q$ -subspace of  $\mathbb{F}_{q^m}$ . Let  $\{\alpha_1,\ldots,\alpha_m\}$  be a basis of  $\mathbb{F}_{q^m}$  over  $\mathbb{F}_q$  and  $\{\beta_1,\ldots,\beta_m\}$  be its dual basis. For the simplicial complex  $\Delta_A$ , its dual  $\Delta_A^{\perp}$  is the m-|A|-dimensional  $\mathbb{F}_q$ -subspace of  $\mathbb{F}_{q^m}$  spanned by the set  $\{\beta_j: j\in [m]\setminus A\}$ .

By using the relevant result in [30], we can give the following lemma regarding the exponential sum on the simplicial complexex  $\Delta_A$  of  $\mathbb{F}_q^m$  with exactly one maximal element, which will be helpful to prove our main results.

<span id="page-3-2"></span>**Lemma 2.** Let  $\Delta_A = \langle \{A\} \rangle$  be the simplicial complex of  $\mathbb{F}_{q^m}$  with exactly one maximal element. Then for  $y \in \mathbb{F}_{q^m}^*$  we have

$$\sum_{x \in \Delta_A} \zeta_p^{\operatorname{Tr}_p^{q^m}(yx)} = \left\{ \begin{array}{ll} q^{|A|}, & \text{if } y \in \Delta_A^{\perp}; \\ 0, & \text{otherwise.} \end{array} \right.$$

# III. Four families of linear codes over $\mathbb{F}_q + u \mathbb{F}_q$

<span id="page-3-0"></span>In this section, we construct four families of linear codes over  $R = \mathbb{F}_q + u\mathbb{F}_q$  with  $u^2 = 0$  by employing the simplicial complexes of  $\mathbb{F}_q^m$  with one maximal element. With detailed computation on some exponential sums, the parameters and the Lee weight distributions of these codes are completely determined.

# <span id="page-3-3"></span>A. The first class of linear codes $C_L$ with $L = \Delta_A + u(\Delta_B \setminus \Delta_{B'})$

**Theorem 1.** Let m be a positive integer. Let  $\Delta_A$ ,  $\Delta_B$  and  $\Delta_{B'}$  be simplicial complexes of  $\mathbb{F}_{q^m}$ , where  $A \subseteq [m]$  and  $B' \subset B \subseteq [m]$ . Assume that |A| + |B'| > 0. Denote  $L = \Delta_A + u(\Delta_B \setminus \Delta_{B'})$ . Then  $C_L$  defined by (1) is a 4-weight code of length  $q^{|A|}(q^{|B|} - q^{|B'|})$ , size  $q^{|A| + |A \cup B|}$ , and its Lee weight distribution is given by

| Weight w                            | Multiplicity $A_w$                                                                   |
|-------------------------------------|--------------------------------------------------------------------------------------|
| 0                                   | 1                                                                                    |
| $2(q-1)q^{ A + B -1}$               | $q^{ A\cup B - A\cup B' }-1$                                                         |
| $2(q-1)q^{ A -1}(q^{ B }-q^{ B' })$ | $q^{ A + A\cup B } - 2q^{ A\cup B - B' } + q^{ A\cup B - A\cup B' }$                 |
| $(q-1)q^{ A -1}(q^{ B }-q^{ B' })$  | $2(q^{ A \cup B  -  B } - 1)$                                                        |
| $(q-1)q^{ A -1}(2q^{ B }-q^{ B' })$ | $2(q^{ A \cup B  -  B' } - q^{ A \cup B  -  B } - q^{ A \cup B  -  A \cup B' } + 1)$ |

*Proof.* It is easy to check that the length of  $C_L$  is  $n := q^{|A|}(q^{|B|} - q^{|B'|})$ . By Lemma 1, for  $a + ub \in \mathcal{R} \setminus \{0\}$ , the Lee weight of the codeword  $c_{a+ub}$  in  $C_L$  is

<span id="page-4-1"></span>
$$wt_L(c_{a+ub}) = 2q^{|A|}(q^{|B|} - q^{|B'|}) - \Omega,$$

where

$$\Omega = \frac{1}{q} \sum_{u \in \mathbb{F}_q} \sum_{\mathbf{y} \in \Delta_R \setminus \Delta_{P'}} \chi(u \operatorname{Tr}_q^{q^m}(a\mathbf{y})) \sum_{\mathbf{x} \in \Delta_A} (\chi(u \operatorname{Tr}_q^{q^m}(b\mathbf{x})) + \chi(u \operatorname{Tr}_q^{q^m}((a+b)\mathbf{x}))).$$

By Lemma 2, for  $u \in \mathbb{F}_q^*$ , one can obtain that

$$\begin{split} \sum_{y \in \Delta_B \setminus \Delta_{B'}} \chi(u \operatorname{Tr}_q^{q^m}(ay)) &= \sum_{y \in \Delta_B} \chi(u \operatorname{Tr}_q^{q^m}(ay)) - \sum_{y \in \Delta_{B'}} \chi(u \operatorname{Tr}_q^{q^m}(ay)) \\ &= \left\{ \begin{array}{ll} q^{|B|} - q^{|B'|}, & \text{if } a \in \Delta_B^{\perp}; \\ -q^{|B'|}, & \text{if } a \notin \Delta_B^{\perp}, a \in \Delta_{B'}^{\perp}; \\ 0, & \text{if } a \notin \Delta_{B'}^{\perp}, \end{array} \right. \end{split}$$
(3)

where  $\Delta_B^{\perp} \subset \Delta_{B'}^{\perp}$ . To determine the value of  $\Omega$ , we consider the following three cases. Case (1):  $a \in \Delta_B^{\perp}$ . Then by Lemma 2 we have

$$\begin{split} &\Omega = & \frac{2}{q} n + \frac{1}{q} (q^{|B|} - q^{|B'|}) \sum_{u \in \mathbb{F}_q^*} \sum_{x \in \Delta_A} (\chi(u \operatorname{Tr}_q^{q^m}(bx)) + \chi(u \operatorname{Tr}_q^{q^m}((a+b)x))) \\ &= & \begin{cases} 2q^{|A|} (q^{|B|} - q^{|B'|}), & \text{if } b \in \Delta_A^{\perp}, a+b \in \Delta_A^{\perp}; \\ 2q^{|A|-1} (q^{|B|} - q^{|B'|}), & \text{if } b \notin \Delta_A^{\perp}, a+b \notin \Delta_A^{\perp}; \\ (q+1)q^{|A|-1} (q^{|B|} - q^{|B'|}), & \text{otherwise.} \end{cases} \end{split}$$

Thus, for  $a \in \Delta_B^{\perp}$ , one gets

$$wt_L(c_{a+ub}) = \begin{cases} 0, & \text{if } b \in \Delta_A^{\perp}, a+b \in \Delta_A^{\perp}; \\ 2(q-1)q^{|A|-1}(q^{|B|}-q^{|B'|}), & \text{if } b \notin \Delta_A^{\perp}, a+b \notin \Delta_A^{\perp}; \\ (q-1)q^{|A|-1}(q^{|B|}-q^{|B'|}), & \text{otherwise.} \end{cases}$$

Case (2):  $a \notin \Delta_B^{\perp}$  and  $a \in \Delta_{B'}^{\perp}$ . Then we have

$$\begin{split} \Omega = & \frac{2}{q} n - q^{|B'|-1} \sum_{u \in \mathbb{F}_q^*} \sum_{x \in \Delta_A} (\chi(u \operatorname{Tr}_q^{q^m}(bx)) + \chi(u \operatorname{Tr}_q^{q^m}((a+b)x))) \\ = & \begin{cases} 2q^{|A|-1}(q^{|B|} - q^{|B'|+1}), & \text{if } b \in \Delta_A^{\perp}, a+b \in \Delta_A^{\perp}; \\ 2q^{|A|-1}(q^{|B|} - q^{|B'|}), & \text{if } b \notin \Delta_A^{\perp}, a+b \notin \Delta_A^{\perp}; \\ q^{|A|-1}(2q^{|B|} - (q+1)q^{|B'|}), & \text{otherwise.} \end{cases} \end{split}$$

Thus, for  $a \notin \Delta_B^{\perp}$  and  $a \in \Delta_{B'}^{\perp}$ , it gives

<span id="page-4-0"></span>
$$wt_{L}(c_{a+ub}) = \begin{cases} 2(q-1)q^{|A|+|B|-1}, & \text{if } b \in \Delta_{A}^{\perp}, a+b \in \Delta_{A}^{\perp}; \\ 2(q-1)q^{|A|-1}(q^{|B|}-q^{|B'|}), & \text{if } b \notin \Delta_{A}^{\perp}, a+b \notin \Delta_{A}^{\perp}; \\ (q-1)q^{|A|-1}(2q^{|B|}-q^{|B'|}), & \text{otherwise.} \end{cases}$$
(4)

Case (3):  $a \notin \Delta_{B'}^{\perp}$ . Then we have  $\Omega = \frac{2}{q}n$ , which indicates

$$wt_L(c_{a+ub}) = 2(q-1)q^{|A|-1}(q^{|B|}-q^{|B'|}).$$

With the discussion above,  $wt_L(c_{a+ub}) = 0$  if and only if  $a \in \Delta_B^{\perp}$ ,  $b \in \Delta_A^{\perp}$  and  $a+b \in \Delta_A^{\perp}$ . This indicates

$$\begin{split} A_0 = & |\{(a,b) \in \mathbb{F}_{q^m}^2 : a \in \Delta_B^{\perp}, b \in \Delta_A^{\perp}, a + b \in \Delta_A^{\perp}\}| \\ = & |\{(a,b) \in \mathbb{F}_{q^m}^2 : a \in \Delta_B^{\perp}, a \in \Delta_A^{\perp}, b \in \Delta_A^{\perp}\}| \\ = & q^{m-|A|} |\{a \in \mathbb{F}_{q^m} : a \in \Delta_B^{\perp}, a \in \Delta_A^{\perp}\}| \\ = & q^{m-|A|} |\Delta_B^{\perp} \cap \Delta_A^{\perp}| \\ = & q^{2m-|A|-|A \cup B|}. \end{split}$$

Here the second equality holds due to the fact that the addition operation in  $\Delta_A^{\perp}$  is closed, and the last equality holds since  $|\Delta_B^{\perp} \cap \Delta_A^{\perp}| = |\Delta_{A \cup B}^{\perp}| = q^{m-|A \cup B|}$ . This means that the size of  $\mathcal{C}_L$  is  $q^{|A|+|A \cup B|}$ . Moreover,  $\mathcal{C}_L$  has the following four nonzero Lee weights:  $w_1 = 2(q-1)q^{|A|+|B|-1}$ ,  $w_2 = 2(q-1)q^{|A|-1}(q^{|B|}-q^{|B'|})$ ,  $w_3 = (q-1)q^{|A|-1}(q^{|B|}-q^{|B'|})$  and  $w_4 = (q-1)q^{|A|-1}(2q^{|B|}-q^{|B'|})$ .

It then follows from (4) that

$$\begin{split} A_{w_{1}} = & |\{(a,b) \in \mathbb{F}_{q^{m}}^{2} : a \notin \Delta_{B}^{\perp}, a \in \Delta_{B'}^{\perp}, b \in \Delta_{A}^{\perp}, a + b \in \Delta_{A}^{\perp}\}| \\ = & q^{m-|A|} |\{a \in \mathbb{F}_{q^{m}} : a \notin \Delta_{B}^{\perp}, a \in \Delta_{B'}^{\perp}, a \in \Delta_{A}^{\perp}\}| \\ = & q^{m-|A|} (|\Delta_{A}^{\perp} \cap \Delta_{B'}^{\perp}| - |\Delta_{A}^{\perp} \cap \Delta_{B}^{\perp}|) = q^{m-|A|} (q^{m-|A \cup B'|} - q^{m-|A \cup B|}). \end{split}$$

Moreover, according to the computation on the Lee weights of  $C_L$ , one has

$$\begin{split} N_{1} := & |\{(a,b) \in \mathbb{F}_{q^{m}}^{2} : a \in \Delta_{B}^{\perp}, b \in \Delta_{A}^{\perp}, a + b \notin \Delta_{A}^{\perp}\}| \\ = & |\{(a,b) \in \mathbb{F}_{q^{m}}^{2} : a \in \Delta_{B}^{\perp}, b \in \Delta_{A}^{\perp}, a \notin \Delta_{A}^{\perp}\}| \\ = & q^{m-|A|}(|\Delta_{B}^{\perp}| - |\Delta_{A}^{\perp} \cap \Delta_{B}^{\perp}|) \\ = & q^{m-|A|}(q^{m-|B|} - q^{m-|A \cup B|}) \end{split}$$

and similarly, by denoting a+b=-c, it gives

$$\begin{split} N_2 := & |\{(a,b) \in \mathbb{F}_{q^m}^2 : a \in \Delta_B^{\perp}, b \notin \Delta_A^{\perp}, a+b \in \Delta_A^{\perp}\}| \\ = & |\{(a,c) \in \mathbb{F}_{q^m}^2 : a \in \Delta_B^{\perp}, a+c \notin \Delta_A^{\perp}, c \in \Delta_A^{\perp}\}| \\ = & N_1 = q^{m-|A|}(q^{m-|B|} - q^{m-|A \cup B|}), \end{split}$$

which indicates  $A_{w_3} = N_1 + N_2 = 2q^{m-|A|}(q^{m-|B|} - q^{m-|A \cup B|})$ . Similar to the computation on  $A_{w_3}$ , we have

$$\begin{split} N_{3} := & |\{(a,b) \in \mathbb{F}_{q^{m}}^{2} : a \notin \Delta_{B}^{\perp}, a \in \Delta_{B'}^{\perp}, b \in \Delta_{A}^{\perp}, a + b \notin \Delta_{A}^{\perp}\}| \\ = & |\{(a,b) \in \mathbb{F}_{q^{m}}^{2} : a \notin \Delta_{B}^{\perp}, a \in \Delta_{B'}^{\perp}, b \in \Delta_{A}^{\perp}, a \notin \Delta_{A}^{\perp}\}| \\ = & q^{m-|A|}(|\Delta_{B'}^{\perp} \setminus \Delta_{B}^{\perp}| - |(\Delta_{B'}^{\perp} \setminus \Delta_{B}^{\perp}) \cap \Delta_{A}^{\perp}|) \\ = & q^{m-|A|}(q^{m-|B'|} - q^{m-|B|} - q^{m-|A \cup B'|} + q^{m-|A \cup B|}) \end{split}$$

and by denoting a+b=-c it gives

$$\begin{split} N_4 := & |\{(a,b) \in \mathbb{F}_{q^m}^2 : a \notin \Delta_B^{\perp}, a \in \Delta_{B'}^{\perp}, b \notin \Delta_A^{\perp}, a + b \in \Delta_A^{\perp}\}| \\ = & |\{(a,c) \in \mathbb{F}_{q^m}^2 : a \notin \Delta_B^{\perp}, a \in \Delta_{B'}^{\perp}, a + c \notin \Delta_A^{\perp}, c \in \Delta_A^{\perp}\}| \\ = & N_3 = q^{m-|A|} (q^{m-|B'|} - q^{m-|B|} - q^{m-|A \cup B'|} + q^{m-|A \cup B|}), \end{split}$$

which implies  $A_{w_4} = N_3 + N_4 = 2q^{m-|A|}(q^{m-|B'|} - q^{m-|B|} - q^{m-|A\cup B'|} + q^{m-|A\cup B|})$ . Therefore,  $A_{w_2} = q^{2m} - A_{w_0} - A_{w_1} - A_{w_3} - A_{w_4} = q^{2m} - q^{m-|A|}(2q^{m-|B'|} - q^{m-|A\cup B'|})$ . Since each codeword in  $\mathcal{C}_L$  repeats  $A_0 = q^{2m-|A|-|A\cup B|}$  times, the frequency of  $w_i$  can be obtained from the value of  $A_{w_i}$  by dividing  $A_0$ , where  $0 \le i \le 4$ . Then the Lee weight distribution of  $\mathcal{C}_L$  follows. This completes the proof.

**Remark 1.** When q = 2 and |B| = m, the code  $C_L$  in Theorem 1 is reduced to the linear code over  $\mathbb{F}_2 + u\mathbb{F}_2$  in [29, Theorem 3.2]. Moreover, when |B| = m and both |A| and |B'| divide m, the code  $C_L$  in Theorem 1 has the same parameters and weight distribution as those of the code in [13, Theorem 1].

**Remark 2.** Notice that the code  $C_L$  in Theorem 1 is a 3-weight code if  $A \subseteq B$ ; it is a 2-weight code if  $A \subseteq B'$ ; and it is a 3-weight code if |A| = m.

**Example 1.** Let q = 2, m = 6,  $A = \{1,2,3,5\}$ ,  $B = \{1,2,3,4\}$  and  $B' = \{2\}$ . Magma experiments show that  $C_L$  is a linear code over  $\mathbb{F}_2 + u\mathbb{F}_2$  of length 224 and size  $2^9$ , and it has the weight enumerator  $1 + 2z^{112} + 482z^{224} + 26z^{240} + z^{256}$ , which is consistent with our result in Theorem 1.

<span id="page-6-1"></span>B. The second class of linear codes  $C_L$  with  $L = \Delta_A^c + u(\Delta_B \setminus \Delta_{B'})$ 

**Theorem 2.** Let m be a positive integer. Let  $\Delta_A$ ,  $\Delta_B$  and  $\Delta_{B'}$  be simplicial complexes of  $\mathbb{F}_{q^m}$ , where  $A \subset [m]$  and  $B' \subset B \subseteq [m]$ . Denote  $L = \Delta_A^c + u(\Delta_B \setminus \Delta_{B'})$ . Then  $C_L$  defined by (1) is a 9-weight code of length  $(q^m - q^{|A|})(q^m - q^{|B'|})$ , size  $q^{2m}$ , and its Lee weight distribution is given by

| Weight w                                                       | Multiplicity $A_w$                                                      |
|----------------------------------------------------------------|-------------------------------------------------------------------------|
| 0                                                              | 1                                                                       |
| $(q-1)q^{m-1}(q^{ B }-q^{ B' })$                               | $2(q^{m- A\cup B }-1)$                                                  |
| $(q-1)(q^{m-1}-q^{ A -1})(q^{ B }-q^{ B' })$                   | $2(q^{m- B }-q^{m- A\cup B })$                                          |
| $2(q-1)q^{m-1}(q^{ B }-q^{ B' })$                              | $q^{m- A\cup B }(q^{m- A }-1)-(q^{m- A\cup B }-1)$                      |
| $(q-1)(2q^{m-1}-q^{ A -1})(q^{ B }-q^{ B' })$                  | $2(q^{m- B } - q^{m- A \cup B })(q^{m- A } - 1)$                        |
| $2(q-1)(q^{m-1}-q^{ A -1})(q^{ B }-q^{ B' })$                  | $q^{2m} - q^{m- A }(2q^{m- B' } - q^{m- A \cup B' })$                   |
| $(q-1)(2(q^m-q^{ A })q^{ B -1}-q^{m+ B' -1})$                  | $2(q^{m- A\cup B' }-q^{m- A\cup B })$                                   |
| $(q-1)(q^{m-1}-q^{ A -1})(2q^{ B }-q^{ B' })$                  | $2(q^{m- B' }-q^{m- B })-2(q^{m- A\cup B' }-q^{m- A\cup B })$           |
| $2(q-1)((q^{m-1}-q^{ A -1})q^{ B }-q^{m+ B' -1})$              | $(q^{m- A\cup B' }-q^{m- A\cup B })(q^{m- A }-2)$                       |
| $(q-1)(2(q^{m-1}-q^{ A -1})(q^{ B }-q^{ B' })-q^{ A + B' -1})$ | $2(q^{m- B' }-q^{m- B }-q^{m- A\cup B' }+q^{m- A\cup B })(q^{m- A }-1)$ |

*Proof.* It is clear that the length of  $C_L$  is  $n := (q^m - q^{|A|})(q^{|B|} - q^{|B'|})$ . By Lemma 1, for  $a + ub \in \mathcal{R} \setminus \{0\}$ , the Lee weight of the codeword  $c_{a+ub}$  in  $C_L$  is

$$wt_L(c_{a+ub}) = 2(q^m - q^{|A|})(q^{|B|} - q^{|B'|}) - \Omega,$$

where

$$\Omega = \frac{1}{q} \sum_{u \in \mathbb{F}_q} \sum_{y \in \Delta_B \setminus \Delta_{R'}} \chi(u \operatorname{Tr}_q^{q^m}(ay)) \sum_{x \in \Delta_A^c} (\chi(u \operatorname{Tr}_q^{q^m}(bx)) + \chi(u \operatorname{Tr}_q^{q^m}((a+b)x))).$$

Note that  $\sum_{y \in \Delta_B \setminus \Delta_{B'}} \chi(u \operatorname{Tr}_q^{q^m}(ay))$  for  $u \in \mathbb{F}_q^*$  is given by (3). Similar to (3), for  $u \in \mathbb{F}_q^*$ , one has

<span id="page-6-0"></span>
$$\sum_{x \in \Delta_A^c} \chi(u \operatorname{Tr}_q^{q^m}(bx)) = \begin{cases} q^m - q^{|A|}, & \text{if } b = 0; \\ -q^{|A|}, & \text{if } b \neq 0, b \in \Delta_A^{\perp}; \\ 0, & \text{if } b \notin \Delta_A^{\perp}. \end{cases}$$

$$(5)$$

To further determine the value of  $\Omega$ , we consider the following three cases.

Case (1):  $a \in \Delta_B^{\perp}$ . Then we have

$$\Omega = \frac{2}{q}n + \frac{1}{q}(q^{|B|} - q^{|B'|}) \sum_{u \in \mathbb{F}_q^*} \sum_{x \in \Delta_A^c} (\chi(u\operatorname{Tr}_q^{q^m}(bx)) + \chi(u\operatorname{Tr}_q^{q^m}((a+b)x))).$$

Next we discuss the following three subcases:

Subcase (1.1): b = 0. By (5), we have

$$\Omega = \left\{ \begin{array}{ll} 2(q^m - q^{|A|})(q^{|B|} - q^{|B'|}), & \text{if } a + b = 0; \\ ((q+1)q^{m-1} - 2q^{|A|})(q^{|B|} - q^{|B'|}), & \text{if } a + b \neq 0, a + b \in \Delta_A^\perp; \\ (q+1)(q^{m-1} - q^{|A|-1})(q^{|B|} - q^{|B'|}), & \text{if } a + b \notin \Delta_A^\perp, \end{array} \right.$$

which indicates

$$wt_L(c_{a+ub}) = \left\{ \begin{array}{ll} 0, & \text{if } a+b=0; \\ w_1 := (q-1)q^{m-1}(q^{|B|}-q^{|B'|}), & \text{if } a+b \neq 0, a+b \in \Delta_A^{\perp}; \\ w_2 := (q-1)(q^{m-1}-q^{|A|-1})(q^{|B|}-q^{|B'|}), & \text{if } a+b \notin \Delta_A^{\perp}. \end{array} \right.$$

Subcase (1.2):  $b \neq 0$ ,  $b \in \Delta_A^{\perp}$ . Similar to Subcase (1.1), we have

$$wt_L(c_{a+ub}) = \left\{ \begin{array}{ll} w_1 = (q-1)q^{m-1}(q^{|B|}-q^{|B'|}), & \text{if } a+b=0; \\ w_3 := 2(q-1)q^{m-1}(q^{|B|}-q^{|B'|}), & \text{if } a+b \neq 0, a+b \in \Delta_A^{\perp}; \\ w_4 := (q-1)(2q^{m-1}-q^{|A|-1})(q^{|B|}-q^{|B'|}), & \text{if } a+b \notin \Delta_A^{\perp}. \end{array} \right.$$

Subcase (1.3):  $b \notin \Delta_A^{\perp}$ . Similar to Subcase (1.1), it gives

$$wt_L(c_{a+ub}) = \left\{ \begin{array}{ll} w_2 = (q-1)(q^{m-1}-q^{|A|-1})(q^{|B|}-q^{|B'|}), & \text{if } a+b=0; \\ w_4 = (q-1)(2q^{m-1}-q^{|A|-1})(q^{|B|}-q^{|B'|}), & \text{if } a+b \neq 0, a+b \in \Delta_A^\perp; \\ w_5 := 2(q-1)(q^{m-1}-q^{|A|-1})(q^{|B|}-q^{|B'|}), & \text{if } a+b \notin \Delta_A^\perp, \end{array} \right.$$

Case (2):  $a \notin \Delta_B^{\perp}$ ,  $a \in \Delta_{B'}^{\perp}$ . Then we have

$$\Omega = \frac{2}{q}n - q^{|B'|-1} \sum_{u \in \mathbb{F}_q^*} \sum_{x \in \Delta_A^c} (\chi(u \operatorname{Tr}_q^{q^m}(bx)) + \chi(u \operatorname{Tr}_q^{q^m}((a+b)x))).$$

Similar to Case (1), we have the following results.

Subcase (2.1): b = 0. One has

$$wt_L(c_{a+ub}) = \begin{cases} w_6 := 2(q-1)(q^m - q^{|A|})q^{|B|-1}, & \text{if } a+b=0; \\ w_7 := (q-1)(2(q^m - q^{|A|})q^{|B|-1} - q^{m+|B'|-1}), & \text{if } a+b \neq 0, a+b \in \Delta_A^{\perp}; \\ w_8 := (q-1)(q^{m-1} - q^{|A|-1})(2q^{|B|} - q^{|B'|}), & \text{if } a+b \notin \Delta_A^{\perp}. \end{cases}$$

Subcase (2.2):  $b \neq 0$ ,  $b \in \Delta_A^{\perp}$ . It follows that

$$wt_L(c_{a+ub}) = \begin{cases} w_7 = (q-1)(2(q^m-q^{|A|})q^{|B|-1}-q^{m+|B'|-1}), & \text{if } a+b=0; \\ w_9 := 2(q-1)((q^{m-1}-q^{|A|-1})q^{|B|}-q^{m+|B'|-1}), & \text{if } a+b \neq 0, a+b \in \Delta_A^{\perp}; \\ w_{10} := (q-1)(2(q^{m-1}-q^{|A|-1})(q^{|B|}-q^{|B'|})-q^{|A|+|B'|-1}), & \text{if } a+b \notin \Delta_A^{\perp}. \end{cases}$$

Subcase (2.3):  $b \notin \Delta_A^{\perp}$ . It gives

$$wt_L(c_{a+ub}) = \left\{ \begin{array}{ll} w_8 = (q-1)(q^{m-1}-q^{|A|-1})(2q^{|B|}-q^{|B'|}), & \text{if } a+b=0; \\ w_{10} = (q-1)(2(q^{m-1}-q^{|A|-1})(q^{|B|}-q^{|B'|})-q^{|A|+|B'|-1}), & \text{if } a+b \neq 0, a+b \in \Delta_A^\perp; \\ w_5 = 2(q-1)(q^{m-1}-q^{|A|-1})(q^{|B|}-q^{|B'|}), & \text{if } a+b \notin \Delta_A^\perp. \end{array} \right.$$

Case (3):  $a \notin \Delta_{B'}^{\perp}$ . Then it can be easily verified that  $wt_L(c_{a+ub}) = w_5 = 2(q-1)(q^{m-1}-q^{|A|-1})(q^{|B|}-q^{|B'|})$  in this case.

Notice that  $w_2$  is the minimal value in the 10 nonzero Lee weights  $w_i$  for  $1 \le i \le 10$ . It's clear that  $w_2 > 0$ , and thus  $w_1(c_{a+ub}) = 0$  if and only if a = b = 0. This shows that the size of  $C_L$  is  $Q^{2m}$ .

Now, we compute the Lee weight distribution of  $C_L$ . From the discussion on  $wt_L(c_{a+ub})$ , one has

$$\begin{split} A_{w_1} = & |\{(a,b) \in \mathbb{F}_{q^m}^2 : a \in \Delta_B^{\perp}, b = 0, a+b \neq 0, a+b \in \Delta_A^{\perp}\}| \\ + & |\{(a,b) \in \mathbb{F}_{q^m}^2 : a \in \Delta_B^{\perp}, b \neq 0, b \in \Delta_A^{\perp}, a+b = 0\}| \\ = & 2|\{(a,b) \in \mathbb{F}_{q^m}^2 : a \in \Delta_B^{\perp}, a \neq 0, a \in \Delta_A^{\perp}, b = 0\}| \\ = & 2(q^{m-|A \cup B|} - 1), \end{split}$$

where the second equality holds since  $|\{(a,b)\in\mathbb{F}_{q^m}^2:a\in\Delta_B^\perp,b\neq0,b\in\Delta_A^\perp,a+b=0\}|=|\{(a,c)\in\mathbb{F}_{q^m}^2:a\in\Delta_B^\perp,a+c\neq0,a+c\in\Delta_A^\perp,c=0\}|$  by denoting c:=a+b. Similarly we have

$$\begin{split} A_{w_2} = & 2|\{(a,b) \in \mathbb{F}_{q^m}^2 : a \in \Delta_B^{\perp}, b = 0, a + b \notin \Delta_A^{\perp}\}| \\ = & 2|\{(a,b) \in \mathbb{F}_{q^m}^2 : a \in \Delta_B^{\perp}, a \notin \Delta_A^{\perp}, b = 0\}| \\ = & 2(q^{m-|B|} - q^{m-|A \cup B|}), \end{split}$$

and

$$\begin{split} A_{w_{3}} = & |\{(a,b) \in \mathbb{F}_{q^{m}}^{2} : a \in \Delta_{B}^{\perp}, b \neq 0, b \in \Delta_{A}^{\perp}, a+b \neq 0, a+b \in \Delta_{A}^{\perp}\}| \\ = & |\{(a,b) \in \mathbb{F}_{q^{m}}^{2} : a \in \Delta_{B}^{\perp}, a \in \Delta_{A}^{\perp}, b \neq 0, b \in \Delta_{A}^{\perp}, a+b \neq 0\}| \\ = & |\{(a,b) \in \mathbb{F}_{q^{m}}^{2} : a \in \Delta_{B}^{\perp}, a \in \Delta_{A}^{\perp}, b \neq 0, b \in \Delta_{A}^{\perp}\}| \\ & - |\{(a,b) \in \mathbb{F}_{q^{m}}^{2} : a \in \Delta_{B}^{\perp}, a \in \Delta_{A}^{\perp}, b \neq 0, b \in \Delta_{A}^{\perp}, a+b = 0\}| \\ = & |\{(a,b) \in \mathbb{F}_{q^{m}}^{2} : a \in \Delta_{B}^{\perp}, a \in \Delta_{A}^{\perp}, b \neq 0, b \in \Delta_{A}^{\perp}\}| - |\{(a,b) \in \mathbb{F}_{q^{m}}^{2} : a \neq 0, a \in \Delta_{B}^{\perp}, a \in \Delta_{A}^{\perp}\}| \\ = & q^{m-|A\cup B|}(q^{m-|A|}-1) - (q^{m-|A\cup B|}-1). \end{split}$$

Using the same techniques of computing  $A_1$ ,  $A_2$  and  $A_{w_3}$ , we have  $A_{w_4} = 2(q^{m-|B|} - q^{m-|A\cup B|})(q^{m-|A|} - 1)$ ,  $A_{w_6} = 0$ ,  $A_{w_7} = 2(q^{m-|A\cup B'|} - q^{m-|A\cup B|})$ ,  $A_{w_8} = 2(q^{m-|B'|} - q^{m-|B'|}) - 2(q^{m-|A\cup B'|} - q^{m-|A\cup B'|})$ ,  $A_{w_9} = (q^{m-|A\cup B'|} - q^{m-|A\cup B|})(q^{m-|A|} - 2)$ , and  $A_{w_{10}} = 2((q^{m-|B'|} - q^{m-|B|}) - (q^{m-|A\cup B'|} - q^{m-|A\cup B|}))(q^{m-|A|} - 1)$ . With the computation as above, we have  $A_{w_5} = q^{2m} - q^{m-|A|}(2q^{m-|B'|} - q^{m-|A\cup B'|})$  due to  $\sum_{1 \le i \le 10} A_{w_i} + 1 = q^{2m}$ . Then the Lee weight distribution of  $\mathcal{C}_L$  follows. This completes the proof.

**Remark 3.** When q = 2 and |B| = m, the code  $C_L$  in Theorem 2 is reduced to the linear code over  $\mathbb{F}_2 + u\mathbb{F}_2$  in [29, Theorem 3.6]. Moreover, when |B| = m and both |A| and |B'| divide m, the code  $C_L$  in Theorem 2 has the same parameters and weight distribution as those of the code in [13, Theorem 2].

**Remark 4.** Notice that the code  $C_L$  in Theorem 2 is a 7-weight code if  $A \subseteq B$ ; it is a 5-weight code if  $A \subseteq B'$ . Moreover, it is a 6-weight code if |B| = m.

**Example 2.** Let q = 2, m = 6,  $A = \{1,2,3,5\}$ ,  $B = \{1,2,3,4\}$  and  $B' = \{2\}$ . Magma experiments show that  $C_L$  is a linear code over  $\mathbb{F}_2 + u\mathbb{F}_2$  of length 672 and size  $2^{12}$ , and it has the weight enumerator  $1 + 4z^{336} + 2z^{448} + 4z^{640} + 156z^{656} + 3856z^{672} + 4z^{704} + 52z^{720} + 12z^{784} + 5z^{896}$ , which is consistent with our result in Theorem 2.

<span id="page-8-0"></span>C. The third class of linear codes  $C_L$  with  $L = \Delta_A + u(\Delta_B \setminus \Delta_{B'})^c$ 

**Theorem 3.** Let m be a positive integer. Let  $\Delta_A$ ,  $\Delta_B$  and  $\Delta_{B'}$  be simplicial complexes of  $\mathbb{F}_{q^m}$ , where  $A \subseteq [m]$  and  $B' \subseteq B \subset [m]$ . Denote  $L = \Delta_A + u(\Delta_B \setminus \Delta_{B'})^c$ . Then  $C_L$  defined by (1) is a 5-weight code of length  $q^{|A|}(q^m - q^{|B|} + q^{|B'|})$ , size  $q^{m+|A|}$ , and its Lee weight distribution is given by

| Weight w                                 | Multiplicity $A_w$                                         |
|------------------------------------------|------------------------------------------------------------|
| 0                                        | 1                                                          |
| $2(q-1)q^{ A -1}(q^m-q^{ B }+q^{ B' })$  | $q^{m+ A } - 2q^{m- B' } + q^{m- A\cup B' }$               |
| $2(q-1)q^{m+ A -1}$                      | $q^{m- A\cup B }-1$                                        |
| $(q-1)q^{ A -1}(2q^m-q^{ B }+q^{ B' })$  | $2(q^{m- B }-q^{m- A\cup B })$                             |
| $2(q-1)q^{ A -1}(q^m-q^{ B })$           | $q^{m- A\cup B' }-q^{m- A\cup B }$                         |
| $(q-1)q^{ A -1}(2q^m-2q^{ B }+q^{ B' })$ | $2(q^{m- B' }-q^{m- B }-q^{m- A\cup B' }+q^{m- A\cup B })$ |

*Proof.* The length of  $C_L$  is  $n := q^{|A|}(q^m - q^{|B|} + q^{|B'|})$ . By Lemma 1, for  $a + ub \in \mathcal{R} \setminus \{0\}$ , the Lee weight of the codeword  $c_{a+ub}$  in  $C_L$  is

$$wt_L(c_{a+ub}) = 2q^{|A|}(q^m - q^{|B|} + q^{|B'|}) - \Omega,$$

where

$$\Omega = \frac{1}{q} \sum_{u \in \mathbb{F}_q} \sum_{y \in (\Delta_B \setminus \Delta_{R'})^c} \chi(u \operatorname{Tr}_q^{q^m}(ay)) \sum_{x \in \Delta_A} (\chi(u \operatorname{Tr}_q^{q^m}(bx)) + \chi(u \operatorname{Tr}_q^{q^m}((a+b)x))).$$

By Lemma 2, for  $u \in \mathbb{F}_q^*$ , one can obtain that

$$\sum_{y \in (\Delta_{B} \setminus \Delta_{B'})^{c}} \chi(u \operatorname{Tr}_{q}^{q^{m}}(ay)) = \sum_{y \in \mathbb{F}_{q^{m}}} \chi(u \operatorname{Tr}_{q}^{q^{m}}(ay)) - \sum_{y \in \Delta_{B}} \chi(u \operatorname{Tr}_{q}^{q^{m}}(ay)) + \sum_{x \in \Delta_{B'}} \chi(u \operatorname{Tr}_{q}^{q^{m}}(ay))$$

$$= \begin{cases}
q^{m} - q^{|B|} + q^{|B'|}, & \text{if } a = 0; \\
-q^{|B|} + q^{|B'|}, & \text{if } a \neq 0, a \in \Delta_{B}^{\perp}; \\
q^{|B'|}, & \text{if } a \notin \Delta_{B'}^{\perp}, a \in \Delta_{B'}^{\perp}; \\
0, & \text{if } a \notin \Delta_{B'}^{\perp}.
\end{cases} (6)$$

To determine Lee weight of  $C_L$ , we consider the following three cases.

Case (1): a = 0. Then we have

<span id="page-9-0"></span>
$$\begin{split} \Omega = & \frac{2}{q} n + \frac{2}{q} (q^m - q^{|B|} + q^{|B'|}) \sum_{u \in \mathbb{F}_q^*} \sum_{x \in \Delta_A} \chi(u \operatorname{Tr}_q^{q^m}(bx)) \\ = & \left\{ \begin{array}{l} 2q^{|A|} (q^m - q^{|B|} + q^{|B'|}), & \text{if } b \in \Delta_A^{\perp}; \\ 2q^{|A|-1} (q^m - q^{|B|} + q^{|B'|}), & \text{if } b \notin \Delta_A^{\perp}. \end{array} \right. \end{split}$$

Thus, for a = 0, one has

$$wt_L(c_{a+ub}) = \begin{cases} 0, & \text{if } b \in \Delta_A^{\perp}; \\ w_1 := 2(q-1)q^{|A|-1}(q^m - q^{|B|} + q^{|B'|}), & \text{if } b \notin \Delta_A^{\perp}. \end{cases}$$

Case (2):  $a \neq 0$ ,  $a \in \Delta_B^{\perp}$ . Then we have

$$\begin{split} &\Omega = & \frac{2}{q} n - \frac{1}{q} (q^{|B|} - q^{|B'|}) \sum_{u \in \mathbb{F}_q^*} \sum_{x \in \Delta_A} (\chi(u \operatorname{Tr}_q^{q^m}(bx)) + \chi(u \operatorname{Tr}_q^{q^m}((a+b)x))) \\ &= \left\{ \begin{array}{ll} 2q^{|A|} (q^{m-1} - q^{|B|} + q^{|B'|}), & \text{if } b \in \Delta_A^{\perp}, a+b \in \Delta_A^{\perp}; \\ 2q^{|A|-1} (q^m - q^{|B|} + q^{|B'|}), & \text{if } b \notin \Delta_A^{\perp}, a+b \notin \Delta_A^{\perp}; \\ q^{|A|-1} (2q^m - (q+1)q^{|B|} + (q+1)q^{|B'|}), & \text{otherwise.} \end{array} \right. \end{split}$$

which indicates

$$wt_L(c_{a+ub}) = \begin{cases} w_2 := 2(q-1)q^{m+|A|-1}, & \text{if } b \in \Delta_A^{\perp}, a+b \in \Delta_A^{\perp}; \\ w_1 = 2(q-1)q^{|A|-1}(q^m - q^{|B|} + q^{|B'|}), & \text{if } b \notin \Delta_A^{\perp}, a+b \notin \Delta_A^{\perp}; \\ w_3 := (q-1)q^{|A|-1}(2q^m - q^{|B|} + q^{|B'|}), & \text{otherwise.} \end{cases}$$

Case (3):  $a \notin \Delta_B^{\perp}$ ,  $a \in \Delta_{B'}^{\perp}$ . Then we have

$$\begin{split} \Omega = & \frac{2}{q} n + q^{|B'|-1} \sum_{u \in \mathbb{F}_q^*} \sum_{x \in \Delta_A} (\chi(u \operatorname{Tr}_q^{q^m}(bx)) + \chi(u \operatorname{Tr}_q^{q^m}((a+b)x))) \\ = & \begin{cases} 2q^{|A|-1}(q^m - q^{|B|}) + 2q^{|A|+|B'|}, & \text{if } b \in \Delta_A^{\perp}, a+b \in \Delta_A^{\perp}; \\ 2q^{|A|-1}(q^m - q^{|B|} + q^{|B'|}), & \text{if } b \notin \Delta_A^{\perp}, a+b \notin \Delta_A^{\perp}; \\ 2q^{|A|-1}(q^m - q^{|B|}) + (q+1)q^{|A|+|B'|-1}, & \text{otherwise}, \end{cases} \end{split}$$

which implies

$$wt_L(c_{a+ub}) = \begin{cases} w_4 := 2(q-1)q^{|A|-1}(q^m - q^{|B|}), & \text{if } b \in \Delta_A^{\perp}, a+b \in \Delta_A^{\perp}; \\ w_1 = 2(q-1)q^{|A|-1}(q^m - q^{|B|} + q^{|B'|}), & \text{if } b \notin \Delta_A^{\perp}, a+b \notin \Delta_A^{\perp}; \\ w_5 := (q-1)q^{|A|-1}(2q^m - 2q^{|B|} + q^{|B'|}), & \text{otherwise.} \end{cases}$$

Case (4):  $a \notin \Delta_{B'}^{\perp}$ . Then it can be easily verified that  $wt_L(c_{a+ub}) = w_1 = 2(q-1)q^{|A|-1}(q^m - q^{|B|} + q^{|B'|})$  in this case.

Notice that  $0 < w_4 < w_1, w_2, w_3, w_5$  since |B'| < |B| < m. Thus  $wt_L(c_{a+ub}) = 0$  if and only if a = 0 and  $b \in \Delta_A^{\perp}$ , and it can be obtained that  $A_0 = q^{m-|A|}$ . This shows that the size of  $C_L$  is  $q^{m+|A|}$ .

Now we compute the Lee weight distribution of  $C_L$ . Similar to the computation in Theorem 2, it follows that

$$\begin{split} A_{w_2} = & |\{(a,b) \in \mathbb{F}_{q^m}^2 : a \neq 0, a \in \Delta_B^{\perp}, b \in \Delta_A^{\perp}, a + b \in \Delta_A^{\perp}\}| \\ = & |\{(a,b) \in \mathbb{F}_{q^m}^2 : a \neq 0, a \in \Delta_B^{\perp}, a \in \Delta_A^{\perp}, b \in \Delta_A^{\perp}\}| \\ = & (q^{m-|A\cup B|}-1)q^{m-|A|}, \\ A_{w_3} = & 2|\{(a,b) \in \mathbb{F}_{q^m}^2 : a \neq 0, a \in \Delta_B^{\perp}, b \in \Delta_A^{\perp}, a + b \notin \Delta_A^{\perp}\}| \\ = & 2|\{(a,b) \in \mathbb{F}_{q^m}^2 : a \in \Delta_B^{\perp}, a \notin \Delta_A^{\perp}, b \in \Delta_A^{\perp}\}| \\ = & 2(q^{m-|B|}-q^{m-|A\cup B|})q^{m-|A|}, \\ A_{w_4} = & |\{(a,b) \in \mathbb{F}_{q^m}^2 : a \notin \Delta_B^{\perp}, a \in \Delta_{B'}^{\perp}, b \in \Delta_A^{\perp}, a + b \in \Delta_A^{\perp}\}| \\ = & |\{(a,b) \in \mathbb{F}_{q^m}^2 : a \notin \Delta_B^{\perp}, a \in \Delta_{B'}^{\perp}, a \in \Delta_A^{\perp}, b \in \Delta_A^{\perp}\}| \\ = & |\{(a,b) \in \mathbb{F}_{q^m}^2 : a \notin \Delta_B^{\perp}, a \in \Delta_{B'}^{\perp}, a \in \Delta_A^{\perp}, b \in \Delta_A^{\perp}\}| \\ = & (q^{m-|A\cup B'|}-q^{m-|A\cup B|})q^{m-|A|}, \end{split}$$

and

$$\begin{split} A_{w_5} = & 2|\{(a,b) \in \mathbb{F}_{q^m}^2 : a \notin \Delta_B^{\perp}, a \in \Delta_{B'}^{\perp}, b \in \Delta_A^{\perp}, a + b \notin \Delta_A^{\perp}\}|\\ = & 2|\{(a,b) \in \mathbb{F}_{q^m}^2 : a \notin \Delta_B^{\perp}, a \in \Delta_{B'}^{\perp}, a \notin \Delta_A^{\perp}, b \in \Delta_A^{\perp}\}|\\ = & 2(q^{m-|B'|} - q^{m-|B|} - q^{m-|A \cup B'|} + q^{m-|A \cup B|})q^{m-|A|}. \end{split}$$

With the computation as above, we have  $A_{w_1} = q^{m-|A|}(q^{m+|A|} - 2q^{m-|B'|} + q^{m-|A \cup B'|})$  due to  $\sum_{0 \le i \le 5} A_{w_i} = q^{2m}$ . Then the Lee weight distribution of  $C_L$  can be derived completely. This completes the proof.

**Remark 5.** Note that the code  $C_L$  in Theorem 3 is a 4-weight code if  $A \subseteq B$ ; it is a 3-weight code if  $A \subseteq B'$ ; and it is a 2-weight code if A = B'.

**Example 3.** Let q=2, m=6,  $A=\{1,2,3,5\}$ ,  $B=\{1,2,3,4\}$  and  $B'=\{2\}$ . Magma experiments show that  $C_L$  is a linear code over  $\mathbb{F}_2+u\mathbb{F}_2$  of length 800 and size  $2^{10}$ , and it has the weight enumerator  $1+2z^{768}+52z^{784}+964z^{800}+4z^{912}+z^{1024}$ , which is consistent with our result in Theorem 3.

<span id="page-10-0"></span>*D.* The fourth class of linear codes  $C_L$  with  $L = \Delta_A^c + u(\Delta_B \setminus \Delta_{B'})^c$ 

**Theorem 4.** Let m be a positive integer. Let  $\Delta_A$ ,  $\Delta_B$  and  $\Delta_{B'}$  be simplicial complexes of  $\mathbb{F}_{q^m}$ , where  $A \subset [m]$  and  $B' \subseteq B \subset [m]$ . Denote  $L = \Delta_A^c + u(\Delta_B \setminus \Delta_{B'})^c$ . Then  $C_L$  defined by (1) is a 10-weight code of length  $(q^m - q^{|A|})(q^m - q^{|B|} + q^{|B'|})$ , size  $q^{2m}$ , and its Lee weight distribution is given by

| Weight w                                                              | Multiplicity A <sub>w</sub>                                             |
|-----------------------------------------------------------------------|-------------------------------------------------------------------------|
| 0                                                                     | 1                                                                       |
| $2(q-1)q^{m-1}(q^m-q^{ B }+q^{ B' })$                                 | $q^{m- A }-1$                                                           |
| $2(q-1)(q^{m-1}-q^{ A -1})(q^m-q^{ B }+q^{ B' })$                     | $q^{2m} - q^{m- A }(2q^{m- B' } - q^{m- A \cup B' })$                   |
| $(q-1)q^{m-1}(2q^m-2q^{ A }-q^{ B }+q^{ B' })$                        | $2(q^{m- A\cup B }-1)$                                                  |
| $(q-1)(q^{m-1}-q^{ A -1})(2q^m-q^{ B }+q^{ B' })$                     | $2(q^{m- B }-q^{m- A\cup B })$                                          |
| $2(q-1)q^{m-1}(q^m-q^{ A }-q^{ B }+q^{ B' })$                         | $(q^{m- A\cup B }-1)(q^{m- A }-2)$                                      |
| $(q-1)(2q^{m-1}(q^m-q^{ A })-(2q^{m-1}-q^{ A -1})(q^{ B }-q^{ B' }))$ | $2(q^{m- B } - q^{m- A \cup B })(q^{m- A } - 1)$                        |
| $(q-1)(2(q^{m-1}-q^{ A -1})(q^m-q^{ B })+q^{m+ B' -1})$               | $2(q^{m- A\cup B' }-q^{m- A\cup B })$                                   |
| $(q-1)(q^{m-1}-q^{ A -1})(2q^m-2q^{ B }+q^{ B' })$                    | $2(q^{m- B' }-q^{m- B }-q^{m- A\cup B' }+q^{m- A\cup B })$              |
| $(q-1)(2(q^{m-1}-q^{ A -1})(q^m-q^{ B })+2q^{m+ B' -1})$              | $(q^{m- A\cup B' }-q^{m- A\cup B })(q^{m- A }-2)$                       |
| $(q-1)(2(q^{m-1}-q^{ A -1})(q^m-q^{ B })+(2q^m-q^{ A })q^{ B' -1})$   | $2(q^{m- B' }-q^{m- B }-q^{m- A\cup B' }+q^{m- A\cup B })(q^{m- A }-1)$ |

*Proof.* The length of  $C_L$  is  $n := (q^m - q^{|A|})(q^m - q^{|B|} + q^{|B'|})$ . By Lemma 1, for  $a + ub \in \mathcal{R} \setminus \{0\}$ , the Lee weight of the codeword  $c_{a+ub}$  in  $C_L$  is

$$wt_L(c_{a+ub}) = 2(q^m - q^{|A|})(q^m - q^{|B|} + q^{|B'|}) - \Omega,$$

where

$$\Omega = \frac{1}{q} \sum_{u \in \mathbb{F}_q} \sum_{y \in (\Delta_B \setminus \Delta_{B'})^c} \chi(u \operatorname{Tr}_q^{q^m}(ay)) \sum_{x \in \Delta_A^c} (\chi(u \operatorname{Tr}_q^{q^m}(bx)) + \chi(u \operatorname{Tr}_q^{q^m}((a+b)x))).$$

For  $u \in \mathbb{F}_q^*$ , the values of  $\sum_{y \in (\Delta_B \setminus \Delta_{B'})^c} \chi(u \operatorname{Tr}_q^{q^m}(ay))$  and  $\sum_{x \in \Delta_A^c} \chi(u \operatorname{Tr}_q^{q^m}(bx))$  can be given by (6) and (5) respectively. To further determine the Lee weights of  $\mathcal{C}_L$ , we consider the following four cases.

Case (1): a = 0. Then we have

$$\begin{split} &\Omega = & \frac{2}{q} n + \frac{2}{q} (q^m - q^{|B|} + q^{|B'|}) \sum_{u \in \mathbb{F}_q^*} \sum_{x \in \Delta_A^c} \chi(u \operatorname{Tr}_q^{q^m}(bx)) \\ &= \left\{ \begin{array}{ll} 2(q^m - q^{|A|})(q^m - q^{|B|} + q^{|B'|}), & \text{if } b = 0; \\ 2(q^{m-1} - q^{|A|})(q^m - q^{|B|} + q^{|B'|}), & \text{if } b \neq 0, b \in \Delta_A^{\perp}; \\ 2(q^{m-1} - q^{|A|-1})(q^m - q^{|B|} + q^{|B'|}), & \text{if } b \notin \Delta_A^{\perp}, \end{array} \right. \end{split}$$

which indicates that

$$wt_L(c_{a+ub}) = \begin{cases} 0, & \text{if } b = 0; \\ w_1 := 2(q-1)q^{m-1}(q^m - q^{|B|} + q^{|B'|}), & \text{if } b \neq 0, b \in \Delta_A^{\perp}; \\ w_2 := 2(q-1)(q^{m-1} - q^{|A|-1})(q^m - q^{|B|} + q^{|B'|}), & \text{if } b \notin \Delta_A^{\perp}. \end{cases}$$

Case (2):  $a \neq 0$ ,  $a \in \Delta_R^{\perp}$ . Then we have

$$\Omega = \frac{2}{q}n - \frac{1}{q}(q^{|B|} - q^{|B'|}) \sum_{u \in \mathbb{F}_q^*} \sum_{x \in \Delta_A^c} (\chi(u \operatorname{Tr}_q^{q^m}(bx)) + \chi(u \operatorname{Tr}_q^{q^m}((a+b)x))).$$

In order to compute the value of  $\Omega$ , we discuss the following three subcases:

Subcase (2.1): b = 0. Then it leads to  $a + b \neq 0$  in this case due to  $a \neq 0$ . By (5), we have

$$\Omega = \left\{ \begin{array}{ll} 2(q^{m-1} - q^{|A|-1})q^m - ((q+1)q^{m-1} - 2q^{|A|})(q^{|B|} - q^{|B'|}), & \text{if } a+b \neq 0, a+b \in \Delta_A^\perp; \\ (q^{m-1} - q^{|A|-1})(2q^m - (q+1)q^{|B|} + (q+1)q^{|B'|}), & \text{if } a+b \notin \Delta_A^\perp, \end{array} \right.$$

which indicates

$$wt_L(c_{a+ub}) = \begin{cases} w_3 := (q-1)q^{m-1}(2q^m - 2q^{|A|} - q^{|B|} + q^{|B'|}), & \text{if } a+b \neq 0, a+b \in \Delta_A^{\perp}; \\ w_4 := (q-1)(q^{m-1} - q^{|A|-1})(2q^m - q^{|B|} + q^{|B'|}), & \text{if } a+b \notin \Delta_A^{\perp}. \end{cases}$$

Subcase (2.2):  $b \neq 0$ ,  $b \in \Delta_A^{\perp}$ . One has

 $wt_L(c_{a+ub})$ 

$$= \left\{ \begin{array}{ll} w_3 = (q-1)q^{m-1}(2q^m-2q^{|A|}-q^{|B|}+q^{|B'|}), & \text{if } a+b=0; \\ w_5 := 2(q-1)q^{m-1}(q^m-q^{|A|}-q^{|B|}+q^{|B'|}), & \text{if } a+b \neq 0, a+b \in \Delta_A^\perp; \\ w_6 := (q-1)(2q^{m-1}(q^m-q^{|A|})-(2q^{m-1}-q^{|A|-1})(q^{|B|}-q^{|B'|})), & \text{if } a+b \notin \Delta_A^\perp. \end{array} \right.$$

Subcase (2.3):  $b \notin \Delta_A^{\perp}$ . It can be obtained that

 $wt_L(c_{a+ub})$ 

$$= \left\{ \begin{array}{ll} w_4 = (q-1)(q^{m-1}-q^{|A|-1})(2q^m-q^{|B|}+q^{|B'|}), & \text{if } a+b=0; \\ w_6 = (q-1)(2q^{m-1}(q^m-q^{|A|})-(2q^{m-1}-q^{|A|-1})(q^{|B|}-q^{|B'|})), & \text{if } a+b \neq 0, a+b \in \Delta_A^\perp; \\ w_2 = 2(q-1)(q^{m-1}-q^{|A|-1})(q^m-q^{|B|}+q^{|B'|}), & \text{if } a+b \notin \Delta_A^\perp. \end{array} \right.$$

Case (3):  $a \notin \Delta_B^{\perp}$ ,  $a \in \Delta_{R'}^{\perp}$ . Then we have

$$\Omega = \frac{2}{q}n + q^{|B'|-1} \sum_{u \in \mathbb{F}_q^*} \sum_{x \in \Delta_A^c} (\chi(u \operatorname{Tr}_q^{q^m}(bx)) + \chi(u \operatorname{Tr}_q^{q^m}((a+b)x))).$$

Then we study the following three subcases to obtain the value of  $\Omega$ .

Subcase (3.1): b = 0. It leads to  $a + b \neq 0$  in this case due to  $a \notin \Delta_R^{\perp}$ . Then it gives

$$wt_L(c_{a+ub}) = \begin{cases} w_7 := (q-1)(2(q^{m-1}-q^{|A|-1})(q^m-q^{|B|}) + q^{m+|B'|-1}), & \text{if } a+b \neq 0, a+b \in \Delta_A^{\perp}; \\ w_8 := (q-1)(q^{m-1}-q^{|A|-1})(2q^m-2q^{|B|}+q^{|B'|}), & \text{if } a+b \notin \Delta_A^{\perp}. \end{cases}$$

Subcase (3.2):  $b \neq 0$ ,  $b \in \Delta_A^{\perp}$ . One has

 $wt_L(c_{a+ub})$ 

$$= \begin{cases} w_7 = (q-1)(2(q^{m-1}-q^{|A|-1})(q^m-q^{|B|}) + q^{m+|B'|-1}), & \text{if } a+b=0; \\ w_9 := (q-1)(2(q^{m-1}-q^{|A|-1})(q^m-q^{|B|}) + 2q^{m+|B'|-1}), & \text{if } a+b \neq 0, a+b \in \Delta_A^{\perp}; \\ w_{10} := (q-1)(2(q^{m-1}-q^{|A|-1})(q^m-q^{|B|}) + (2q^m-q^{|A|})q^{|B'|-1}), & \text{if } a+b \notin \Delta_A^{\perp}. \end{cases}$$

Subcase (3.3):  $b \notin \Delta_A^{\perp}$ . It can be derived that

 $wt_L(c_{a+ub})$ 

$$= \left\{ \begin{array}{ll} w_8 = (q-1)(q^{m-1}-q^{|A|-1})(2q^m-2q^{|B|}+q^{|B'|}), & \text{if } a+b=0; \\ w_{10} = (q-1)(2(q^{m-1}-q^{|A|-1})(q^m-q^{|B|})+(2q^m-q^{|A|})q^{|B'|-1}), & \text{if } a+b \neq 0, a+b \in \Delta_A^{\perp}; \\ w_2 = 2(q-1)(q^{m-1}-q^{|A|-1})(q^m-q^{|B|}+q^{|B'|}), & \text{if } a+b \notin \Delta_A^{\perp}. \end{array} \right.$$

Case (4):  $a \notin \Delta_{B'}^{\perp}$ . It gives  $wt_L(c_{a+ub}) = w_2 = 2(q-1)(q^{m-1} - q^{|A|-1})(q^m - q^{|B|} + q^{|B'|})$  directly in this case.

Notice that  $0 < w_5 < w_1, w_2, w_3, w_4, w_6$  and  $0 < w_8 < w_7, w_9, w_{10}$ . By a straightforward computation, one has  $w_5 \le w_8$  if and only if  $m - |A| \le |B| - |B'|$ . Therefore  $wt_L(c_{a+ub}) = 0$  if and only if a = b = 0, which implies  $A_0 = 1$ . This shows that the size of  $C_L$  is  $Q^{2m}$ .

Now we compute the Lee weight distribution of  $\mathcal{C}_L$ . According to the discussion on the Lee weights  $wt_L(c_{a+ub})$  of  $\mathcal{C}_L$ , we can get that  $A_{w_1}=q^{m-|A|}-1$ ,  $A_{w_3}=2(q^{m-|A\cup B|}-1)$ ,  $A_{w_4}=2(q^{m-|B|}-q^{m-|A\cup B|})$ ,  $A_{w_5}=(q^{m-|A\cup B|}-1)(q^{m-|A|}-2)$ ,  $A_{w_6}=2(q^{m-|B|}-q^{m-|A\cup B|})(q^{m-|A|}-1)$ ,  $A_{w_7}=2(q^{m-|A\cup B'|}-q^{m-|A\cup B'|})$ ,  $A_{w_8}=2(q^{m-|B'|}-q^{m-|A\cup B'|}+q^{m-|A\cup B|})$ ,  $A_{w_9}=(q^{m-|A\cup B'|}-q^{m-|A\cup B|})(q^{m-|A|}-2)$  and  $A_{w_{10}}=2(q^{m-|B'|}-q^{m-|A\cup B'|}+q^{m-|A\cup B'|})(q^{m-|A|}-1)$ . Here we omit the detailed computations since this can be derived similarly to the computation of  $A_{w_i}$ 's in Theorem 2. Furthermore, it gives  $A_{w_2}=q^{2m}-q^{m-|A|}(2q^{m-|B'|}-q^{m-|A\cup B'|})$  by  $\sum_{0\leq i\leq 10}A_{w_i}=q^{2m}$ . Then the Lee weight distribution of  $\mathcal{C}_L$  is completely determined. This completes the proof.

**Remark 6.** Note that the code  $C_L$  in Theorem 4 is an 8-weight code if  $A \subseteq B$ ; it is a 6-weight code if  $A \subseteq B'$ ; and it is an 8-weight code if  $|A \cup B'| = |A \cup B|$ .

**Example 4.** Let q = 2, m = 6,  $A = \{1,2,3,5\}$ ,  $B = \{1,2,3,4\}$  and  $B' = \{2\}$ . Magma experiments show that  $C_L$  is a linear code over  $\mathbb{F}_2 + u\mathbb{F}_2$  of length 2400 and size  $2^{12}$ , and it has the weight enumerator  $1 + 2z^{2176} + 12z^{2288} + 52z^{2352} + 4z^{2368} + 3856z^{2400} + 156z^{2416} + 4z^{2432} + 2z^{2624} + 4z^{2736} + 3z^{3200}$ , which is consistent with our result in Theorem 4.

## IV. OPTIMAL CODES OVER $\mathbb{F}_q$ AND EXAMPLES

<span id="page-13-0"></span>It's known that the Gray map  $\phi$  introduced in Section II is an isometry from  $(R^n, d_L)$  and  $(\mathbb{F}_q^{2n}, d_H)$ , which is distance-preserving and weight-preserving. In this section, we will investigate the Gray images  $\phi(\mathcal{C}_L)$  of the codes  $\mathcal{C}_L$  over  $R = \mathbb{F}_q + u\mathbb{F}_q$  ( $u^2 = 0$ ) constructed in Section III. By using the Griesmer bound, several calsses of optimal few-weight linear codes over  $\mathbb{F}_q$  and some examples will be presented.

<span id="page-13-1"></span>**Theorem 5.** Let  $C_L$  be defined as in Theorem 1 with  $|A \cup B| = |B|$ . Assume that |A| + |B'| > 0. Then the Gray image  $\phi(C_L)$  is a  $[2q^{|A|}(q^{|B|} - q^{|B'|}), |A| + |B|, 2(q-1)q^{|A|-1}(q^{|B|} - q^{|B'|})]$  linear code over  $\mathbb{F}_q$  with the weight distribution

| Weight w                            | Multiplicity $A_w$                                 |
|-------------------------------------|----------------------------------------------------|
| 0                                   | 1                                                  |
| $2(q-1)q^{ A + B -1}$               | $q^{ B - A\cup B' }-1$                             |
| $2(q-1)q^{ A -1}(q^{ B }-q^{ B' })$ | $q^{ A + B } - 2q^{ B - B' } + q^{ B - A\cup B' }$ |
| $(q-1)q^{ A -1}(2q^{ B }-q^{ B' })$ | $2(q^{ B - B' }-q^{ B - A\cup B' })$               |

Moreover, the code  $\phi(C_L)$  is a near Griesmer code and it is distance-optimal.

*Proof.* According to Theorem 1, the weight distribution of  $\phi(\mathcal{C}_L)$  can be given as in Theorem 5 for the case  $|A \cup B| = |B|$ . It's clear that the minimum distance of  $\phi(\mathcal{C}_L)$  is  $d = 2(q-1)q^{|A|-1}(q^{|B|}-q^{|B'|})$ , and  $A_d = q^{2m-|A|-|A|-|B'|}(q^{|A|+|A\cup B'|}-2q^{|A\cup B'|-|B'|}+1) > 0$  due to  $(|A|+|A\cup B'|)-(|A\cup B'|-|B'|)=|A|+|B'|>0$ . Then  $\phi(\mathcal{C}_L)$  has parameters  $[2q^{|A|}(q^{|B|}-q^{|B'|}), |A|+|B|, d:=2(q-1)q^{|A|-1}(q^{|B|}-q^{|B'|})]$ . By the Griesmer bound, we have

$$g(|A| + |B|, d) = \sum_{i=0}^{|A|+|B|-1} \left\lceil \frac{2(q-1)q^{|A|-1}(q^{|B|} - q^{|B'|})}{q^{i}} \right\rceil$$

$$= \sum_{i=0}^{|A|+|B'|-1} 2(q-1)(q^{|A|+|B|-i-1} - q^{|A|+|B'|-i-1})$$

$$+ \sum_{i=|A|+|B'|}^{|A|+|B|-1} (2(q-1)q^{|A|+|B|-i-1} + \lceil -2(q-1)q^{|A|+|B'|-i-1} \rceil)$$

$$= 2q^{|A|}(q^{|B|} - q^{|B'|}) - 1,$$
(7)

where the last equality holds since  $\lceil -2(q-1)q^{|A|+|B'|-i-1} \rceil = -1$  if i = |A|+|B'| and it is equal to 0 if  $|A|+|B'| < i \le |A|+|B|-1$ . Thus  $\phi(\mathcal{C}_L)$  is a near Griesmer code by (7). Moreover, we similarly have

<span id="page-13-3"></span><span id="page-13-2"></span>
$$g(|A| + |B|, d+1) = \sum_{i=0}^{|A| + |B| - 1} \left\lceil \frac{2(q-1)q^{|A| - 1}(q^{|B|} - q^{|B'|}) + 1}{q^i} \right\rceil$$
$$= 2q^{|A|}(q^{|B|} - q^{|B'|}) + |A| + |B'| + \left\lfloor \frac{2}{q} \right\rfloor - 1, \tag{8}$$

which implies  $\phi(C_L)$  is distance-optimal due to  $2q^{|A|}(q^{|B|}-q^{|B'|}) < g(|A|+|B|,d+1)$ . This completes the proof.

**Remark 7.** When q = 2 and |B| = m, the optimal codes  $\phi(C_L)$  in Theorem 5 are reduced to the binary optimal linear codes in [29, Theorem 4.1].

**Example 5.** Let q = 3, m = 4,  $A = \{1\}$ ,  $B = \{1,2,3\}$  and  $B' = \{2\}$ . Magma experiments show that  $\phi(C_L)$  is a [144,4,96] linear code over  $\mathbb{F}_3$  with the weight enumerator  $1 + 66z^{96} + 12z^{102} + 2z^{108}$ , which is consistent with our result in Theorem 5. This code is a near Griesmer code by the Griesmer bound and is optimal due to [9].

By characterizing the optimality of the codes in Theorem 2, we get a class of six-weight linear codes in the following, which can produce many optimal linear codes over  $\mathbb{F}_q$ .

<span id="page-14-0"></span>**Theorem 6.** Let  $C_L$  be defined as in Theorem 2 with |B| = m. Assume that  $|A \cup B'| < m$  and  $q^{m-|A|} > 2$ . Then the Gray image  $\phi(C_L)$  is a  $[2(q^m - q^{|A|})(q^m - q^{|B'|}), 2m, 2(q-1)(q^{2m-1} - q^{m+|A|-1} - q^{m+|B'|-1})]$  linear codes with the weight distribution

| Weight w                                                   | Multiplicity $A_w$                                   |
|------------------------------------------------------------|------------------------------------------------------|
| 0                                                          | 1                                                    |
| $2(q-1)q^{m-1}(q^m-q^{ B' })$                              | $q^{m- A }-1$                                        |
| $2(q-1)(q^{m-1}-q^{ A -1})(q^m-q^{ B' })$                  | $q^{2m} - q^{m- A }(2q^{m- B' } - q^{m- A\cup B' })$ |
| $(q-1)(2q^{2m-1}-2q^{m+ A -1}-q^{m+ B' -1})$               | $2(q^{m- A\cup B' }-1)$                              |
| $(q-1)(q^{m-1}-q^{ A -1})(2q^m-q^{ B' })$                  | $2(q^{m- B' }-q^{m- A\cup B' })$                     |
| $2(q-1)(q^{2m-1}-q^{m+ A -1}-q^{m+ B' -1})$                | $(q^{m- A\cup B' }-1)(q^{m- A }-2)$                  |
| $(q-1)(2(q^{m-1}-q^{ A -1})(q^m-q^{ B' })-q^{ A + B' -1})$ | $2(q^{m- B' }-q^{m- A\cup B' })(q^{m- A }-1)$        |

Moreover, the code  $\phi(C_L)$  is distance-optimal if  $2q^{|A|+|B'|} < m + \min\{|A|, |B'|\} + \delta$ , where

<span id="page-14-1"></span>
$$\delta = \begin{cases} 1, & \text{if } q = 2, \\ -1, & \text{if } |A| = |B'| \text{ and } q > 4, \\ 0, & \text{otherwise.} \end{cases}$$
 (9)

*Proof.* According to Theorem 2,  $\phi(\mathcal{C}_L)$  is reduced to a 6-weight code for the case |B|=m, and its weight distribution follows as in Theorem 6. It can be verified that the minimum distance of  $\phi(\mathcal{C}_L)$  is  $d=2(q-1)(q^{2m-1}-q^{m+|A|-1}-q^{m+|B'|-1})$ , and  $A_d=(q^{m-|A\cup B'|}-1)(q^{m-|A|}-2)>0$  due to  $|A\cup B'|< m$  and  $q^{m-|A|}>2$ . Then  $\phi(\mathcal{C}_L)$  has parameters  $[2(q^m-q^{|A|})(q^m-q^{|B'|}), 2m, 2(q-1)(q^{2m-1}-q^{m+|A|-1}-q^{m+|B'|-1})]$ . With detailed computation by using the Griesmer bound, it gives

<span id="page-14-2"></span>
$$g(2m,d) = \begin{cases} 2(q^{2m} - q^{m+|A|} - q^{m+|B'|}) - 1, & \text{if } |A| = |B'| \text{ and } q \neq 3; \\ 2(q^{2m} - q^{m+|A|} - q^{m+|B'|}), & \text{otherwise,} \end{cases}$$
(10)

and

$$g(2m,d+1) = 2(q^{2m} - q^{m+|A|} - q^{m+|B'|}) + m + \min\{|A|,|B'|\} + \delta,$$

where  $\delta$  is defined as in (9). Then  $\phi(\mathcal{C}_L)$  is distance-optimal if  $2q^{|A|+|B'|} < m + \min\{|A|,|B'|\} + \delta$ . This completes the proof.

**Remark 8.** It should be noted that for the case |A| = |B'| = 0 the code  $\phi(C_L)$  in Corollary 6 is close to the Griesmer bound since n - g(2m, d) = 2 or 3 by (10). Morover, the given condition in Theorem 6 for the code  $\phi(C_L)$  to be distance-optimal can be easily satisfied if |A| + |B'| is small enough and m is large enough. Thus many distance-optimal linear codes over  $\mathbb{F}_q$  can be derived from this construction.

**Example 6.** Let q = 2, m = 4,  $A = \{2\}$ ,  $B = \{1,2,3,4\}$  and  $B' = \emptyset$ . Magma experiments show that  $\phi(C_L)$  is a [420,8,208] linear code over  $\mathbb{F}_2$  with the weight enumerator  $1+42z^{208}+112z^{209}+64z^{210}+14z^{216}+16z^{217}+7z^{240}$ , which is consistent with our result in Theorem 6. This code is distance-optimal by the Griesmer bound.

For a special case of Theorem 2, we can get a family of two-weight optimal codes as follows.

<span id="page-14-3"></span>**Theorem 7.** Let  $C_L$  be defined as in Theorem 2 with q=2, |B|=m, A=B' and |A|=|B'|=m-1. Then the Gray image  $\phi(C_L)$  is a  $[2^{2m-1},2m,2^{2m-2}]$  linear code over  $\mathbb{F}_2$  with the weight enumerator  $1+z^{2^{2m-1}}+(2^{2m}-2)z^{2^{2m-2}}$ . This code  $\phi(C_L)$  is a Griesmer code.

*Proof.* This result can be proved directly by Theorem 2 and thus we omit the proof here.  $\Box$ 

**Remark 9.** The optimal code  $\phi(C_L)$  in Theorem 7 are the same as the binary optimal linear codes in [29, Theorem 4.3].

**Example 7.** Let q = 2, m = 4,  $A = \{1,2,3\}$ ,  $B = \{1,2,3,4\}$  and  $B' = \{1,2,3\}$ . Magma experiments show that  $\phi(C_L)$  is a [128,8,64] linear code over  $\mathbb{F}_2$  with the weight enumerator  $1 + 254z^{64} + z^{128}$ , which is consistent with our result in Theorem 7. This code is a Griesmer code by the Griesmer bound and it is optimal due to [9].

In the following theorem, we investigate the optimality of the codes in Theorem 3, and thus many distance-optimal linear codes over  $\mathbb{F}_a$  can be derived from our contruction.

<span id="page-15-0"></span>**Theorem 8.** Let  $C_L$  be defined as in Theorem 3. Assume that  $|A \cup B'| \neq |A \cup B|$ . Then the Gray image  $\phi(C_L)$  is a 5-weight  $[2q^{|A|}(q^m-q^{|B|}+q^{|B'|}),m+|A|,2(q-1)q^{|A|-1}(q^m-q^{|B|})]$  linear code over  $\mathbb{F}_q$  with the weight distribution

| Weight w                                 | Multiplicity A <sub>w</sub>                                |
|------------------------------------------|------------------------------------------------------------|
| 0                                        | 1                                                          |
| $2(q-1)q^{ A -1}(q^m-q^{ B }+q^{ B' })$  | $q^{m+ A } - 2q^{m- B' } + q^{m- A \cup B' }$              |
| $2(q-1)q^{m+ A -1}$                      | $q^{m- A\cup B }-1$                                        |
| $(q-1)q^{ A -1}(2q^m-q^{ B }+q^{ B' })$  | $2(q^{m- B }-q^{m- A\cup B })$                             |
| $2(q-1)q^{ A -1}(q^m-q^{ B })$           | $q^{m- A\cup B' }-q^{m- A\cup B }$                         |
| $(q-1)q^{ A -1}(2q^m-2q^{ B }+q^{ B' })$ | $2(q^{m- B' }-q^{m- B }-q^{m- A\cup B' }+q^{m- A\cup B })$ |

The code  $\phi(\mathcal{C}_L)$  is distance-optimal if  $2q^{|A|+|B'|} < |A|+|B|+\lfloor \frac{2}{q} \rfloor -1$ .

*Proof.* According to proof of Theorem 3, the minimum distance of  $\phi(\mathcal{C}_L)$  is  $d=2(q-1)q^{|A|-1}(q^m-q^{|B|})$ , and  $A_d=q^{m-|A\cup B'|}-q^{m-|A\cup B|}>0$  due to  $|A\cup B'|\neq |A\cup B|$ . Thus the parameters are determined completely. Moreover, the weight distribution of  $\phi(\mathcal{C}_L)$  is the same as the Lee weight distribution of  $\mathcal{C}_L$ .

Now we investigate the optimality of  $\phi(C_L)$ . Due to (7) and (8), we have

$$g(m+|A|,d) = \sum_{i=0}^{m+|A|-1} \lceil \frac{2(q-1)q^{|A|-1}(q^m-q^{|B|})}{q^i} \rceil = 2q^{|A|}(q^m-q^{|B|}) - 1$$

and

$$g(m+|A|,d+1) = \sum_{i=0}^{m+|A|-1} \lceil \frac{2(q-1)q^{|A|-1}(q^m-q^{|B|})+1}{q^i} \rceil = 2q^{|A|}(q^m-q^{|B|})+|A|+|B|+\lfloor \frac{2}{q} \rfloor -1.$$

Therefore the code  $\phi(\mathcal{C}_L)$  is distance-optimal if  $2q^{|A|+|B'|} < |A|+|B|+\lfloor \frac{2}{q} \rfloor -1$ . This completes the proof.

**Remark 10.** The code  $\phi(C_L)$  in Theorem 8 is close to the Griesmer bound if |A| = |B'| = 0 since n - g(m+|A|,d) = 3 in this case. Morover, observe that the given condition in Theorem 8 for the code  $\phi(C_L)$  to be distance-optimal can be easily satisfied if |B| - |B'| is large enough.

**Example 8.** Let q = 2, m = 6,  $A = \{4\}$ ,  $B = \{1,2,3,5\}$  and  $B' = \emptyset$ . Magma experiments show that  $\phi(C_L)$  is a [196,7,96] linear code over  $\mathbb{F}_2$  with the weight enumerator  $1+30z^{96}+60z^{97}+32z^{98}+4z^{113}+z^{128}$ , which is consistent with our result in Theorem 8. This code is distance-optimal by the Griesmer bound and it is optimal due to [9].

By a in-depth study on a special case of Theorem 4, we can obtain a class of two-weight optimal linear codes in the following.

<span id="page-15-1"></span>**Theorem 9.** Let  $C_L$  be defined as in Theorem 4 with B = B' (i.e.,  $(\Delta_B \setminus \Delta_{B'})^c = \mathbb{F}_{q^m}$ ). Then the Gray image  $\phi(C_L)$  has parameters  $[2(q^{2m}-q^{m+|A|}),2m,2(q-1)(q^{2m-1}-q^{m+|A|-1})]$  with the weight enumerator  $1+(q^{m-|A|}-1)z^{2(q-1)q^{2m-1}}+(q^{2m}-q^{m-|A|})z^{2(q-1)(q^{m-1}-q^{|A|-1})q^m}$ . This code  $\phi(C_L)$  is a near Griesmer code and it is distance-optimal.

*Proof.* By Theorem 4, it can be verified directly that  $\phi(\mathcal{C}_L)$  is reduced to a two-weight code with the weight enumerator  $1+(q^{m-|A|}-1)z^{2(q-1)q^{2m-1}}+(q^{2m}-q^{m-|A|})z^{2(q-1)(q^{m-1}-q^{|A|}-1)q^m}$  for the case B=B'. Certainly, the parameters of  $\phi(\mathcal{C}_L)$  can be given by  $[2(q^{2m}-q^{m+|A|}),2m,2(q-1)(q^{2m-1}-q^{m+|A|}-1)]$ .

By the Griesmer bound, one has

$$g(2m,d) = \sum_{i=0}^{2m-1} \lceil \frac{2(q-1)(q^{2m-1} - q^{m+|A|-1})}{q^i} \rceil = 2(q^{2m} - q^{m+|A|}) - 1$$

and

$$g(2m,d+1) = \sum_{i=0}^{2m-1} \left\lceil \frac{2(q-1)(q^{2m-1} - q^{m+|A|-1}) + 1}{q^i} \right\rceil = 2(q^{2m} - q^{m+|A|}) + m + |A| + \lfloor \frac{2}{q} \rfloor - 1.$$

Therefore the code  $\phi(C_L)$  is a near Griesmer code and it is distance-optimal. This completes the proof.  $\Box$ 

**Remark 11.** It should be noted that for the case |A| = |B| = m the codes in Theorem 5 have parameters  $[2(q^{2m} - q^{m+|B'|}), 2m, 2(q-1)(q^{2m-1} - q^{m+|B'|-1})]$ , which is the same as the parameters of the codes in Theorem 9. However, they are inequivalent since they have different weight distributions. The weight enumerator of the code in Theorem 5 for the case |A| = |B| = m can be given by  $1 + (q^{2m} - 2q^{m-|B'|} + 1)z^{2(q-1)q^{m-1}(q^m - q^{|B'|})} + 2(q^{m-|B'|} - 1)z^{(q-1)q^{m-1}(2q^m - q^{|B'|})}$ , which is different from that of Theorem 9.

**Example 9.** Let q = 2, m = 4,  $A = \{1,2\}$  and B = B'. Magma experiments show that  $\phi(C_L)$  is a [384,8,192] linear code over  $\mathbb{F}_2$  with the weight enumerator  $1 + 252z^{192} + 3z^{256}$ , which is consistent with our result in Theorem 9. This code is distance-optimal by the Griesmer bound.

#### V. CONCLUSIONS

<span id="page-16-8"></span>In this paper, we constructed four families of linear codes over  $\mathbb{F}_q + u\mathbb{F}_q$ ,  $u^2 = 0$  with defining sets associated with simplicial complexes of  $\mathbb{F}_q^m$ . This extends the results of [29] from q = 2 and B = [m] to general q and  $B \subseteq [m]$ . By computing certain exponential sums on simplicial complexes, we completely determined the parameters and Lee weight distributions of these four families of codes, and many linear codes with few Lee weights can be produced. Moreover, via the Gray map, we obtained several infinite families of optimal linear codes over  $\mathbb{F}_q$  by using the Griesmer bound, which include the near Griesmer codes and distance-optimal codes.

#### VI. ACKNOWLEDGEMENTS

This work was supported by the Major Program(JD) of Hubei Province (No. 2023BAA027), the National Natural Science Foundation of China (No. 62072162), the Natural Science Foundation of Hubei Province of China (No. 2021CFA079), the Knowledge Innovation Program of Wuhan-Basic Research (No. 2022010801010319) and the innovation group project of the natural science foundation of Hubei Province of China (No. 2023AFA021).

### REFERENCES

- <span id="page-16-0"></span>[1] R. J. Anderson, C. Ding, T. Hellsesth, T. Klove, How to build robust shared control systems, Des. Codes Cryptogr. 15(2) (1998), pp. 111-123.
- <span id="page-16-4"></span><span id="page-16-1"></span>[2] A. R. Calderbank, J. Goethals, Three-weight codes and association schemes, Philips J. Res. 39(4-5) (1984), pp. 143-152.
- [3] C. Carlet, C. Ding, J. Yuan, Linear codes from perfect nonlinear mappings and their secret sharing schemes, IEEE Trans. Inf. Theory 51(6) (2005), pp. 2089-2102.
- <span id="page-16-7"></span><span id="page-16-6"></span>[4] S. Chang, J.Y. Hyun, Linear codes from simplicial complexes, Des. Codes Cryptogr. 86 (2018), pp. 2167-2181.
- <span id="page-16-2"></span>[5] C. Ding, Linear codes from some 2-designs, IEEE Trans. Inf. Theory 61(6) (2015), pp. 3265-3275.
- [6] C. Ding, T. Helleseth, T. Kløve, X. Wang, A generic construction of cartesian authentication codes, IEEE Trans. Inf. Theory 53(6) (2007), pp. 2229-2235.
- <span id="page-16-5"></span><span id="page-16-3"></span>[7] C. Ding, H. Niederreiter, Cyclotomic linear codes of order 3, IEEE Trans. Inf. Theory 53(6) (2007), pp. 2274-2277.
- [8] C. Ding, X. Wang, A coding theory construction of new systematic authentication codes, Theor. Comput. Sci. 330(1) (2005), pp. 81-99.

- <span id="page-17-22"></span><span id="page-17-1"></span>[9] M. Grassl, Bounds on the minimum distance of linear codes, Online available at http://www.codetables.de, Accessed on 2024-06-21
- <span id="page-17-3"></span>[10] J.H. Griesmer, A bound for error correcting codes, IBM J. Res. Dev. 4 (1960), pp. 532-542.
- <span id="page-17-4"></span>[11] Z. Heng, Projective linear codes from some almost difference sets, IEEE Trans. Inf. Theory 69(2) (2023), pp. 978-994.
- <span id="page-17-10"></span>[12] Z. Heng, C. Ding, W. Wang, Optimal binary linear codes from maximal arcs, IEEE Trans. Inf. Theory 66(9) (2020), pp. 5387-5394.
- [13] Z. Hu, B. Chen, N. Li, X. Zeng, Two classes of optimal few-weight codes over  $\mathbb{F}_q + u\mathbb{F}_q$ , In: S. Mesnager, Z. Zhou (eds) Arithmetic of Finite Fields. WAIFI 2022. LNCS, Springer, Cham, 13638 (2023): 208-220.
- <span id="page-17-16"></span>[14] Z. Hu, Y. Xu, N. Li, X. Zeng, L. Wang, X. Tang, New constructions of optimal linear codes from simplicial complexes, IEEE Trans. Inf. Theory 70(3) (2024), pp. 1823-1835.
- <span id="page-17-5"></span><span id="page-17-0"></span>[15] W. Huffman, V. Pless, Fundamentals of error-correcting codes, Cambridge University Press (1997).
- [16] J. Y. Hyun, J. Lee, Y. Lee, Infinite families of optimal linear codes constructed from simplicial complexes, IEEE Trans. Inf. Theory 66(11) (2020), pp. 6762-6773.
- <span id="page-17-18"></span>[17] X. Li, M. Shi, A new family of optimal binary few-weight codes from simplicial complexes, IEEE Communications Letters 25(4) (2021), pp. 1048-1051.
- <span id="page-17-11"></span><span id="page-17-6"></span>[18] X. Li, Q. Yue, D. Tang, A family of linear codes from constant dimension subspace codes, Des. Codes Cryptogr. 90 (2022), pp. 1-15.
- <span id="page-17-7"></span>[19] H. Liu, Y. Maouche, Two or few-weight trace codes over  $\mathbb{F}_q + u\mathbb{F}_q$ , IEEE Trans. Inf. Theory 65(5) (2019), pp. 2696-2703.
- <span id="page-17-8"></span>[20] S. Mesnager, Y. Qi, H. Ru, C. Tang, Minimal linear codes from characteristic functions, IEEE Trans. Inf. Theory 66(9) (2020), pp. 5404-5413.
- [21] S. Mesnager, A. Sınak, Several classes of minimal linear codes with few weights from weakly regular plateaued functions, IEEE Trans. Inf. Theory, 66(4) (2020), pp. 2296-2310.
- <span id="page-17-19"></span><span id="page-17-12"></span>[22] M. Shi, Y. Guan, P. Solé, Two new families of two-weight codes, IEEE Trans. Inf. Theory 63(10) (2017), pp. 6240-6246.
- <span id="page-17-13"></span>[23] M. Shi, X. Li, Two classes of optimal p-ary few-weight codes from down-sets, Discret. Appl. Math. 290 (2021), pp. 60-67.
- <span id="page-17-14"></span>[24] M. Shi, Y. Liu, P. Solé, Optimal two-weight codes from trace codes over  $\mathbb{F}_2 + u\mathbb{F}_2$ , IEEE Commun. Lett. 20(12) (2016), pp. 2346-2349.
- <span id="page-17-2"></span>[25] M. Shi, R. Wu, Y. Liu, P. Solé, Two and three weight codes over  $\mathbb{F}_p + u\mathbb{F}_p$ , Cryptogr. Commun. 9 (2017), pp. 637-646.
- <span id="page-17-17"></span>[26] G. Solomon, J.J. Stiffer, Algebraically punctured cyclic codes, Inform. and Control 8 (1965), pp. 170-179.
- [27] Y. Wu, J.Y. Hyun, Few-weight codes over  $\mathbb{F}_p + u\mathbb{F}_p$  associated with down sets and their distance optimal Gray image, Discret. Appl. Math. 283 (2020), pp. 315-322.
- <span id="page-17-20"></span><span id="page-17-15"></span>[28] Y. Wu, C. Li, L. Zhang, F. Xiao, Quaternary codes and their binary images, IEEE Trans. Inf. Theory 70(7) (2024), pp. 4759-4768.
- <span id="page-17-21"></span>[29] Y. Wu, X. Zhu, Q. Yue, Optimal few-weight codes from simplicial complexes, IEEE Trans. Inf. Theory 66(6) (2020), pp. 3657-3663.
- <span id="page-17-9"></span>[30] M. Yang, J. Li, K. Feng, D. Lin, Generalized Hamming weights of irreducible cyclic codes, IEEE Trans. Inf. Theory 61(9) (2015), pp. 4905-4913.
- [31] Z. Zhou, N. Li, C. Fan, T. Helleseth, Linear codes with two or three weights from quadratic Bent functions, Des. Codes Cryptogr. 81 (2016), pp. 283-295.