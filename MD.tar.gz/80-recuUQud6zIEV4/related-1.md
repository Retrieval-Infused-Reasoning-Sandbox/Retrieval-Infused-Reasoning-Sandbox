![](_page_0_Picture_2.jpeg)

### TRIPLE POINT NUMBERS OF TWIST SPUN KNOTS

### TSUKASA YASHIRO

Department of Mathematics,
Graduate School of Science Osaka City University,
Sugimoto, Sumiyoshi-ku,
Osasa 558-8585, Japan
yashiro@sci.osaka-cu.ac.jp

Accepted 23 August 2004

#### ABSTRACT

The present paper gives an improved upper bound of triple point numbers for some family of twist-spun knots. The upper bound is obtained by deforming surface diagrams, which contain special sub-diagrams.

Keywords: Roseman moves; surface-knots; triple point numbers.

Mathematics Subject Classification 2000: 57M25, 57Q45

## 1. Introduction

The triple point number of a surface-knot is the minimal number of triple points for all surface diagrams of the surface-knot. This is a surface-knot invariant. This invariant has been studied with geometric techniques [10–12]. In this paper we will give improved upper bounds of triple point numbers for some family of twist spun knots. Let I be the closed interval [0,1] and let  $\partial I$  denote its boundary  $\{0,1\}$ . We denote the n times of product of I by  $I^n$ . Take finite subsets of  $\partial I \times (I \times I) \subset I^3$ :

$$A = \left\{ a_i = \left( 0, \frac{n+2-i}{n+3}, \frac{1}{2} \right) \in I^3 : i = 1, 2, \dots, n+1 \right\},$$
 (1.1)

$$B = \left\{ b_i = \left( 1, \frac{n+2-i}{n+3}, \frac{1}{2} \right) \in I^3 : i = 1, 2, \dots, n+1 \right\}.$$
 (1.2)

A surface-knot is an embedded oriented closed connected surface in  $\mathbb{R}^4$  and a surface diagram is a generic image of the projection of surface-knot into  $\mathbb{R}^3$  with crossing information.

Let  $\beta_i: I \to I^3 \subset \mathbf{R}^3$  be a simple proper arc from  $a_i$  to  $b_i$ , (i = 1, 2, ..., n + 1), which is monotonic with respect to the x-axis, such that

- (i)  $\beta_1, \ldots, \beta_n$  are disjoint arcs parallel to the x-axis,
- (ii)  $\beta_{n+1}(\frac{1}{2}) = (\frac{1}{2}, \frac{n+2}{n+3}, \frac{1}{2}),$

![](_page_1_Figure_3.jpeg)

Fig. 1.

(iii)  $\beta_{n+1}((0,\frac{1}{2}))$  is lower than  $\bigcup_{i=1}^{n} \beta_i$  and  $\beta_{n+1}((\frac{1}{2},1))$  is higher than  $\bigcup_{i=1}^{n} \beta_i$  with respect to the z-axis.

Then we obtain a tangle in  $I^3 \subset \mathbf{R}^3$  and we denote this (n+1)-string tangle by  $T_{n+1}$  (see Fig. 1). Let K be a knot. We denote the number of crossings of  $D_K$  by  $c(D_K)$ . Then the following holds and the proof will be given in Sec. 4.

**Theorem 1.** Let K be a knot and let  $\tau^q(K)$  be the q twist-spinning of K. Assume that K has a diagram  $D_K$  such that  $D_K$  contains the tangle  $T_{n+1}$  for some  $n \geq 1$ . Then the following holds.

$$t(\tau^{q}(K)) \le 2q(c(D_K) - 2n).$$
 (1.3)

Theorem 1 implies the following.

Corollary 1 (Satoh and Shima [11]). If a knot diagram  $D_K$  of a knot K contains a full twisted trivial tangle with 2-strings, then the following holds:

$$t(\tau^{q}(K)) \le 2q(c(D_K) - 2).$$
 (1.4)

**Proof.** The full twisted trivial tangle with two strings is  $T_2$ . Thus the result follows from Theorem 1.

Satoh [10] proved that for every knot K, the triple point number of a q-twist spinning of K is bounded above by 2q(c(K)-1), where c(K) is the crossing number of K. Satoh and Shima proved that the double twist spun trefoil has the triple point number 4 [11], and the triple twist spun trefoil has the triple point number 6 [12]. The equality in the formula in Corollary 1 holds in these cases. Theorem 1 implies the following corollaries.

**Corollary 2.** Let K be the (r, s)-torus knot with  $2 \le r < s$  and let  $\tau^q(K)$  be the q-twist-spinning of K. Then the following holds.

$$t(\tau^q(K)) \le 2q\left((r-2)(s-1) + r\left[\frac{s-1}{r}\right] - (r-1)\left[\frac{s}{r}\right]\right),\tag{1.5}$$

where  $\left\lceil \frac{s}{r} \right\rceil$  is the integer part of  $\frac{s}{r}$ .

The proof will be given in Sec. 2. The above corollary immediately gives the following corollary.

**Corollary 3.** Let K be the (2,k)-torus knot with odd  $k \geq 2$  and let  $\tau^q(K)$  be the q-twist-spin of K. Then the following holds.

$$t(\tau^q(K)) \le q(k-1). \tag{1.6}$$

The organization of this paper is the following. In Sec. 2, we will prove a key lemma and then prove Corollary 2. In Sec. 3, surface diagrams and their deformations will be described. Finally, we prove Theorem 1. We work in the smooth category.

### 2. Deformations of Knot Diagrams

In this section we will prove the following lemma.

**Lemma 1.** Let K be a (r,s)-torus knot with  $2 \le r < s$ . Then K has a diagram  $D_K$  with the tangle  $T_{n+1}$ , where  $n = (s-1) - \left[\frac{s}{r}\right]$  and  $\left[\frac{s}{r}\right]$  is the integer part of  $\frac{s}{r}$ .

**Proof.** We will construct a diagram of K with the tangle  $T_n$ . Let  $p_i^j = (j, \frac{i}{s+1}, \frac{1}{2})$ ,  $(j = 0, 1, i = 1, \ldots, s)$ . A braid of s strings is the set of disjoint s arcs in  $I^3$ , in which each arc is simple and monotonic from  $p_i^0$  to  $p_k^1$ ,  $(1 \le i, k \le s)$  with respect to the second coordinate. A braid word w of s strings is a product of standard generators  $\sigma_1, \ldots, \sigma_{s-1}$  of the braid group  $\mathcal{B}_s$  (see [1] for details). A braid word w is geometrically represented by a diagram consisting of proper s strings in  $I^3$ , the (r, s)-torus knot has a braid presentation with s strings; the word presentation is

$$(\sigma_{s-1}\cdots\sigma_1)^r. (2.1)$$

The word  $\sigma_{s-1}\cdots\sigma_1$  is geometrically represented as a picture in Fig. 2. We denote the dotted box representing  $\sigma_{s-1}\cdots\sigma_1$  by T. Take r copies of T;  $T^1,T^2,\ldots,T^r$ , in which points  $p_i^0$  and  $p_i^1$ ,  $(i=1,\ldots,s)$  in the jth copy  $T^j$  are denoted by  $p_i^{j-1}$  and  $p_i^j$  respectively. Make a braid with s strings by attaching r boxes,  $T^1,\ldots,T^r$  by identifying  $p_i^j \in T^j$  and  $p_i^j \in T^{j+1}$ ,  $(j=1,\ldots,r-1)$ . Take a box with trivial s strings; we denote it by s0, in which each straight string joins s1, and s2, and s3, and s3, and s3, and s4, and s5, are denoted by s5.

![](_page_2_Figure_13.jpeg)

Fig. 2.

 $(i=1,\ldots,s)$ . Adding  $T^0$  to  $T^1\cdots T^r$  to obtain a closed braid, we obtain a diagram of the (r,s)-torus knot K. We will denote the closed braid diagram by  $D_K$ . Note that the number of crossings in  $D_K$  is r(s-1). We will deform  $D_K$  into a simpler one as follows. Take a sub-arc  $\gamma$  in  $D_K$  from  $p_1^0$  to  $p_s^{r-u}$ , where  $u=(s-1)-r[\frac{s-1}{r}]$ . So that  $\gamma$  lies behind the arcs  $p_1^jp_s^{j+1}$   $(j=1,\ldots,r-1)$ . Replace the arc  $\gamma$  with an arc  $\gamma'$  from  $p_s^u$  to  $p_1^0$  so that  $\gamma'$  runs behind the trivial strings to eliminate  $r[\frac{s}{r}]+u$  crossings, and add  $(s-1)-[\frac{s}{r}]$  crossing points so that the number of crossings in the modified diagram  $D_K'$  is  $r(s-1)-(r+1)[\frac{s}{r}]+r[\frac{s-1}{r}]$ . It is not too difficult to see that the tangle  $T_n$  appears in  $T^0T^1$ , where  $n=(s-1)-[\frac{s}{r}]$ . Thus the result follows.

Now we will prove Corollary 2.

**Proof of Corollary 2.** The number of crossings of the diagram of K, obtained from the braid presentation, is r(s-1). From Lemma 1, an (r,s)-torus knot with  $2 \le r < s$ , has a diagram  $D_K$  with  $T_{n+1}$ , where  $n = (s-1) - \left[\frac{s}{r}\right]$ . The modified diagram is given by reducing  $r\left[\frac{s}{r}\right] + u$  crossing points and adding  $(s-1) - \left[\frac{s}{r}\right]$  crossing points. The number of the crossings of  $D_K$  is:

$$c(D_K) = r(s-1) - (r+1) \left\lceil \frac{s}{r} \right\rceil - r \left\lceil \frac{s-1}{r} \right\rceil.$$

$$(2.2)$$

Then Theorem 1 implies that

$$t(\tau^{q}(K)) \leq 2q(c(D_{K}) - 2n)$$

$$= 2q\left(r(s-1) - (r+1)\left[\frac{s}{r}\right] - r\left[\frac{s-1}{r}\right] - 2n\right)$$

$$= 2q\left((r-2)(s-1) - (r-1)\left[\frac{s}{r}\right] + r\left[\frac{s-1}{r}\right]\right). \tag{2.3}$$

This proves the corollary.

# 3. Surface Diagrams

For surface-knots, there exist seven types of local moves to deform their diagrams, called *Roseman moves* [9] (see Figs. 3 and 4).

![](_page_3_Picture_11.jpeg)

Fig. 3.

![](_page_4_Picture_3.jpeg)

Fig. 4.

**Lemma 2 [9].** Let  $F_1$  and  $F_2$  be equivalent surface-knots and let  $D_{F_1}$  and  $D_{F_2}$  be their diagrams respectively. Then there is a finite sequence of seven types of Roseman moves such that  $D_{F_1}$  is deformed into  $D_{F_2}$  by the sequence.

A generic disc, with a pair of branch points and a double segment between them, is called a bug (see Fig. 5). This is produced by  $R_4^+$  Roseman move (see Fig. 4). We denote this local diagram by B. The lift of B into  $\mathbf{R}^4$  is an embedded disc and it has points a and b, corresponding to branch points of B, and a pair of arcs  $\xi$  and  $\eta$  from b to a. We put an orientation to a bug by an orientation of the double segment of the bug. It will be described by an arrow from one branch point, called the tail, to the other, called the tail. D. Roseman described some 2-knots by surface diagrams and their deformations [9]. Satoh [10] used a similar construction of a diagram to represent a twist-spun knot (see also [8]); here we will use Satoh's diagram as a standard diagram of a twist spinning of K. Figure 6 shows a partial diagram of twisting part of the standard diagram of a twist spun trefoil. The construction of the standard diagram of  $\tau^q(K)$  is given as follows. Let  $S^1$  be the unit circle in  $\mathbf{R}^2$  parametrized by  $\theta \in [0, 2\pi]$ . Let T(K) be a tangle from K with 1-string.

![](_page_4_Picture_7.jpeg)

Fig. 5.

![](_page_5_Picture_3.jpeg)

Fig. 6.

 $S^1 \times T(K) \subset \mathbf{R}^3$  is a diagram of annulus with boundary circles A and B. Add q bugs  $B_1, \ldots, B_q$  on the unit sphere  $\mathbf{S}^2$  such that the pre-image of each  $B_i$  has a pair of branch points  $a_i$  and  $b_i$ , and arcs  $\xi_i$  and  $\eta_i$  from  $b_i$  to  $a_i$  so that  $\xi_i$  and  $\eta_i$  are sent onto the double segment of  $B_i$ ,  $(i = 1, \ldots, q)$ . Assume that those bugs are put along the equator of  $\mathbf{S}^2$  so that

- (i) the double segment of each bug transversally intersects the equator at one point, and
- (ii) all  $a_i$  are on the upper hemisphere and all  $b_i$  are on the lower hemisphere of  $S^2$ .

We denote the sphere with q copies of bugs defined in the above by  $\mathbf{S}_q^2$ . Assume that  $S^1$  is parametrized by  $\theta \in [0, 2\pi]$ . Let  $\gamma : S^1 \to \mathbf{S}^2$  be a smooth closed curve on  $\mathbf{S}^2$  so that  $\gamma(S^1)$  satisfies the following conditions:

- (i) There exists q points,  $0 < \theta_0 < \dots < \theta_{q-1} < 2\pi$  on  $[0, 2\pi]$  such that  $\gamma([\theta_i, \theta_{i+1}])$  passes each double segment of a bug twice in the diagram  $\mathbf{S}_q^2$ , and
- (ii) in the pre-image of  $\mathbf{S}_q^2$ ,  $\gamma$  starts from the point  $\gamma(0)$  between  $a_q$  and  $a_1$  in the upper hemisphere, then it passes  $\xi_i$  for each i, (i = 1, ..., q) in the upper hemisphere once and then it passes  $\eta_i$  in the lower hemisphere once, and finally returns to the initial point.

Let  $N(\gamma)$  be a tubular neighborhood of  $\gamma$  in  $\mathbf{R}^4$ . Then  $N(\gamma)$  is diffeomorphic to  $S^1 \times B^3$ . The closed set  $\mathbf{S}_q^2 \backslash N(\gamma)$  is a disjoint union of closed discs. Let  $\psi : S^1 \times T(K) \to N(\gamma)$  be an embedding such that  $\psi(S^1 \times \partial T(K)) = \partial(\mathbf{S}_q^2 \backslash N(\gamma))$ , where  $\partial(\mathbf{S}_q^2 \backslash N(\gamma))$  is a disjoint union of two circles. Paste  $S^1 \times T(K)$  to  $\mathbf{S}_q^2 \backslash N(\gamma)$  by  $\psi$ . Then we obtain a surface in  $\mathbf{R}^4$ . This is equivalent to a q-twist spinning of K. Also this construction gives a surface diagram in  $\mathbf{R}^3$ . We denote the constructed surface by  $\tau^q(K)$  and denote the diagram in  $\mathbf{R}^3$  by  $D(\tau^q(K))$ .

# 3.1. $R_6^{\pm}$ and $R_7$ moves

We will introduce a set of local deformations which will be used in Sec. 4. Assume that a diagram D is oriented so that the double curves are oriented (see [10]). An  $R_7$  move joins a pair of double curves, which satisfy certain conditions. This

deformation consists of deformations of two discs such that one of discs forms a saddle  $P_1$  and the other forms a moving disc  $P_2$ . Assume that there exists a disc E bounded by two arcs  $\gamma_1 \subset P_1$  and  $\gamma_2 \subset P_2$  such that  $\gamma_1 \cap \gamma_2 = \{q_1, q_2\}$  is a pair of double points in  $P_1 \cap P_2$ . We call E a guide disc. Also assume that the double curves in  $P_1 \cap P_2$  have opposite direction. Then we can apply  $R_7$  move to  $P_1 \cup P_2$ .  $P_1$  is deformed along the guide disc so that the connection of these double curves is changed. Let  $E^2 = \{(x,y) \in \mathbf{R}^2 : |x| \leq 1, |y| \leq 1\}$ . Define three discs in 4-space by

$$E_0 = \{(0, y, z, -1) : (y, z) \in E^2\},\tag{3.1}$$

$$E_1 = \{(x, 0, z, 0) : (x, z) \in E^2\},\tag{3.2}$$

$$E_2 = \{(x, y, 0, 1) : (x, y) \in E^2\}. \tag{3.3}$$

We denote the projected image of  $E_i$ , (i = 0, 1, 2) into  $\mathbb{R}^3$  along the fourth coordinate by  $E_i$  again. Assume that the orientation of  $\mathbb{R}^3$  is given by the standard basis:  $\{e_0, e_1, e_2\}$ . We assume that the orientation of this local diagram is given by  $\{\mathbf{n}_2 = \mathbf{e}_2, \ \mathbf{n}_1 = \mathbf{e}_1, \ \mathbf{n}_0 = -\mathbf{e}_0\}$ , where each  $\mathbf{n}_i$  is a normal vector to  $E_i \subset \mathbf{R}^3$ (i=0,1,2). Let p be the triple point in the local diagram;  $\{p\}=E_0\cap E_1\cap E_2$ . With respect to the height function on the local diagram, there exist three kinds of double arcs around p, marked by (b/t), (b/m) and (m/t)-edges [10] formed by the bottom and top, the bottom and middle, and the middle and top sheets respectively. Let  $h^1$  be a 1-handle,  $h^1 \cong I \times I$ , and let  $I \times \partial I$  be the attaching edges of  $h^1$ . Let  $\varphi: I \times \partial I \to \bigcup_{i=0}^2 \partial E_i$  be an embedding such that  $\varphi(x) = (0, x/3 + 1/3, 1)$ for  $x \in I \times \{0\}$  and  $\varphi(x) = (-x/3 - 1/3, 0, 1)$  for  $x \in I \times \{1\}$ . Paste the handle  $h^1$ to the local diagram by the embedding  $\varphi$  so that the orientation is preserved (see the left picture of Fig. 7). Now we can find a guide disc E to join a pair of double curves  $E_0 \cap E_2$  and  $E_1 \cap E_2$  connecting to the triple point p. We call the guide disc a quide disc associated with the triple point p. Applying this modification to the local diagram about the triple point p, then we obtain a double loop based at p (see Fig. 7). Applying  $R_5^+$  and  $R_6^-$  moves, we can eliminate the triple point p.

![](_page_6_Picture_8.jpeg)

Fig. 7.

## 3.2. Eliminating pairs of triple points

Let  $F \subset \mathbf{R}^4$  be a surface-knot and let  $D_F$  be an oriented surface diagram. Assume that there exist double curves  $\alpha, \beta \subset D_F$  and assume that there exist triple points  $p_1, p_2 \in D_F$  such that  $p_1 \in \alpha$  and  $p_2 \in \beta$ . Assume that the pair of triple points is joined by two double curves  $\gamma_1, \gamma_2 \subset D_F$  such that

- (1)  $\alpha$  and  $\beta$  have opposite orientations at end points of  $\gamma_i$  for each i=1,2,
- (2)  $\gamma_1 \cap \gamma_2 = \{p_1, p_2\},\$
- (3) each  $\gamma_i$  (i=1,2) has the same types of edges at its ends; that is,  $\{b/m,b/m\}$  or  $\{m/t,m/t\}$  or  $\{b/t,b/t\}$  and
- (4)  $\gamma_1 \cup \gamma_2$  bounds a disc  $E_0$  in  $D_F$  such that the interior of  $E_0$  misses the multiple points of the diagram  $D_F$ .

Then for a tubular neighborhood N of  $E_0$  in  $\mathbb{R}^4$ , there exists a disc  $E_* \subset F$  as an extension of  $E_0$  in N. Then  $N \cap F$  consists of three discs  $E_*$ ,  $D_1$  and  $D_2$  and  $E_* \cap D_1 \cap D_2 = \{p_1, p_2\}$ . If we have such a disc  $E_0$ , then we can push down  $D_1$  under  $D_2$  along the disc  $E_0$  so that we can eliminate the pair of triple points. Note that this deformation is decomposed into a sequence of Roseman moves. We call  $E_0$  a guide disc for a pair of triple points in  $D_K$ . Then we have the following.

**Lemma 3.** Let  $F \subset \mathbf{R}^4$  be a surface-knot and let  $D_F$  be its diagram in  $\mathbf{R}^3$ . Then if there exists a guide disc  $E_0$  in  $D_F$  for a pair of triple points of  $D_F$ , then the pair of triple points can be eliminated.

## 4. Proof of Theorem 1

In this section we will prove Theorem 1.

**Proof of Theorem 1.** We will deform the standard surface diagram of a q twist spinning of K so that the deformed diagram has the required number of triple points. Note that K has a diagram  $D_K$  containing  $T_{n+1}$ . The deformation consists of Roseman moves and local deformations defined in the previous section. First we construct the standard surface diagram of a q-twist spinning of K. Replace the string  $\beta_{n+1}$  in  $T_{n+1}$  with two disjoint simple strings  $\alpha_1$  and  $\alpha_2$  so that

$$\alpha_1(0) = \beta_{n+1}(0), \quad \alpha_1(1) = \left(0, \frac{n+1}{n+3}, \frac{1}{2}\right),$$
(4.1)

$$\alpha_2(0) = \left(1, \frac{n+1}{n+3}, \frac{1}{2}\right), \quad \alpha_2(1) = \beta_{n+1}(1).$$
 (4.2)

Then we obtain a tangle T from  $D_K$  with 1 string so that  $\partial T$  is  $\alpha_1(1)$  and  $\alpha_2(0)$ . We will use this tangle T to construct the standard surface diagram of q twist spinning of K denoted by  $D(\tau^q(K))$ . In  $T_{n+1}$ , replacing  $\beta_{n+1}$  with  $\alpha_1$  and  $\alpha_2$ , we obtain a new tangle with n+2 strings. We will denote this tangle by  $T_{n+2}^*$ . For each twisting part of the diagram  $D(\tau^q(K))$ , we can find a partial diagram, which contains 4n

triple points. The partial diagram is described as the following. Take the product space  $I \times T_{n+2}^* \subset \mathbf{R} \times \mathbf{R}^3$ , which consists of (n+2) discs in 4-dimensional space. Note that the projection  $\pi : \mathbf{R}^4 \to \mathbf{R}^3$  is defined by  $\pi(x_1, x_2, x_3, x_4) = (x_1, x_2, x_3)$ . Define

$$E_0^2 = \left\{ \left( \frac{1}{4}, y, z, -1.5 \right) : |y| \le 1, |z| \le 1 \right\},\tag{4.3}$$

$$E_1^2 = \left\{ \left( \frac{3}{4}, y, z, 1.5 \right) : |y| \le 1, |z| \le 1 \right\}$$
(4.4)

so that the height of  $E_0^2$  is lower than any other discs in  $I \times T_{n+2}^*$  and the height of  $E_1^2$  is higher than any other discs in  $I \times T_{n+2}^*$ . Then we obtain a surface diagram consisting of n+4 discs. We denote the set of surfaces by  $F_{n+4}$ . The tangle T with 1 string contains the tangle  $T_{n+2}^*$ . According to the construction of the diagram  $D(\tau^q(K))$  with the tangle T, we can find a sub-diagram of  $D(\tau^q(K))$ , which is homeomorphic to the diagram  $I \times D(T(K)) \cup E_0^2 \cup E_1^2$ . We use the same notations for the corresponding sub-diagram. Take four double points on  $E_0^2 \cup E_1^2$ ,

$$A_i = \left\{ \frac{2i+1}{4} \right\} \times \alpha_1(1), \quad B_i = \left\{ \frac{2i+1}{4} \right\} \times \alpha_2(0), \quad (i=0,1).$$
 (4.5)

Then from the construction of  $D(\tau^q(K))$ ,  $B_0$  and  $A_1$  are on the same double curve of the bug used for constructing the twisting part. There is a double curve  $\gamma'$  from  $A_0$  to  $B_1$  so that there exists a 1-handle  $h^1$  along  $\gamma'$  connecting  $E_0^2$  and  $E_1^2$ . We denote the diagram  $I \times D(T(K)) \cup E_0^2 \cup E_1^2 \cup h^1$  by  $F_{n+4}^*$ . There are 4n triple points in the diagram of  $F_{n+4}^*$ , and we denote these triple points by

$$p_{ij}^{0} = \left\{\frac{1}{4}\right\} \times (\alpha_i \cap \beta_j), \quad p_{ij}^{1} = \left\{\frac{3}{4}\right\} \times (\alpha_i \cap \beta_j), \tag{4.6}$$

for  $i=1,2,j=1,\ldots,n$ . In the diagram, one of double arcs on  $(I\times\alpha_1)\cap E_0^2$ from the triple point  $p_{11}^0$ , connects to a branch point. Also one of double arcs on  $(I \times \alpha_2) \cap E_1^2$ , from the triple point  $p_{21}^1$ , connects to another branch point. Note that  $B_0$  and  $A_1$  is joined by the double arc  $\gamma'$  hence  $p_{21}^0$  and  $p_{11}^1$  are joined by a simple double arc denoted by  $\gamma$ . We shall show that we can eliminate all of the 4ntriple points by a sequence of Roseman moves as follows. We can find a guide disc Eassociated with the triple point  $p_{11}^0$ . The boundary of E consists of two arcs  $c_1$  and  $c_2$  between points  $r_1 \in \left[\frac{1}{3}, \frac{2}{3}\right] \times (\alpha_1 \cap \beta_1)$  and  $r_2 \in (I \times \beta_1) \cap E_0^2$ , where  $c_1$  is an arc on  $h^1 \cup E_0^2 \cup ([\frac{1}{3}, \frac{2}{3}] \times \alpha_1)$ ,  $c_2$  is an arc on  $I \times \beta_1$  and  $c_1 \cap c_2 = \{r_1, r_2\}$ . Also we can assume that  $c_1$  is parallel to  $\gamma$  so that  $c_1 \cup r_1 p_{21}^0 \cup \gamma \cup p_{11}^1 r_2$  bounds the disc E. Along E we can apply  $R_7$  move to join the pair of double curves,  $\frac{1}{4} \times \beta_1$  and  $I \times (\alpha_1 \cap \beta_1)$ . The resulting diagram contains a double loop based at the triple point  $p_{11}^0$ . Since the triple point  $p_{11}^0$  connects to the branch point, the loop and the triple point  $p_{11}^0$  can be eliminated by  $R_6^-$  move. After this modification we can find a pair of disjoint double curves between  $p_{21}^0$  and  $p_{11}^1$ . One is  $\gamma$  and the other, denoted by  $c_2$ , is on  $I \times \beta_1$  which is obtained by the above deformation. The pair of double curves bounds a guide disc E' in the diagram so that the pair of triple points  $\{p_{21}^0, p_{11}^1\}$  can be eliminated.

After this elimination, we obtain another double loop based at  $p_{21}^1$ . The triple point connects to another branch point, so that we can eliminate the double loop and the triple point  $p_{21}^1$  by  $R_6^-$  move. At this stage we can find the diagram  $F_{n+3}^*$ . Therefore, we can continue to apply the same procedure until other triple points are eliminated. Thus for each twisting part of the diagram of  $\tau^q(K)$ , we can eliminate 4n triple points. Therefore, the number of triple points of the resulting surface diagram is  $2q(c(D_K)-2n)$ .

### Acknowledgments

The author would like to thank to Professor Kawauchi for giving useful suggestions for early version of this paper. This research is supported by Japan Society for the Promotion of Science Postdoctoral Fellowship for Foreign Researchers.

## References

- J. S. Birman, Braids, Links, and Mapping Class Groups, Annals of Mathematics Studies, No. 82 (Princeton University Press, Princeton, NJ; University of Tokyo Press, Tokyo, 1974).
- [2] J. S. Carter and M. Saito, Knotted Surfaces and Their Diagrams, Mathematical Surveys and Monographs, Vol. 55 (American Mathematical Society, Providence, RI, 1998).
- [3] J. S. Carter and M. Saito, Surfaces in 3-space that do not lift to embeddings in 4-space, in *Knot Theory*, Banach Center Publications, Vol. 42 (Warzawa, 1998), pp. 29–47.
- [4] T. Homma and T. Nagase, On elementary deformations of maps of surfaces into 3-manifolds I, Yokohama Math. J. 33 (1985) 103–119.
- [5] T. Homma and T. Nagase, On elementary deformations of maps of surfaces into 3-manifolds II, in *Topology and Computer Science*, 1-20 (Kinokuniya, Tokyo, 1987).
- [6] K. Murasugi, Knot Theory and Its Applications (Birkhäuser Boston, Inc., Boston, MA, 1996), translated from the 1993 Japanese original by Bohdan Kurpita.
- [7] D. Rolfsen, Knots and Links, Mathematics Lecture Series, No. 7 (Publish or Perish, Inc., Berkeley, CA, 1976).
- [8] D. Roseman, Spinning knots about submanifolds; spinning knots about projections of knots, *Topology Appl.* **31**(3) (1989) 225–241.
- [9] D. Roseman, Reidemeister-type moves for surfaces in four dimensional space, in Knot Theory, Banach Center Publications, Vol. 42 (1998), pp. 347–380.
- [10] S. Satoh, Surface diagrams of twist-spin 2-knots, J. Knot Theory Ramifications 11(3) (2002) 413–430.
- [11] S. Satoh and A. Shima, The 2-twist-spun trefoil has the triple point number four, Trans. Amer. Math. Soc. 356(3) (2004) 1007–1024.
- [12] S. Satoh and A. Shima, Triple point numbers and quandle cocycle invariants of knotted surfaces in 4-space, preprint.
- [13] T. Yashiro, Immersions and their lifts, New Zealand J. Math. 30 (2001) 197–210.