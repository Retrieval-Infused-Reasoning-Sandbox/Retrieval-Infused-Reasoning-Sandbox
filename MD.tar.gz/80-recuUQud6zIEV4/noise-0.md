Journal of Knot Theory and Its Ramifications Vol. 25, No. 13 (2016) 1650068 (18 pages) © World Scientific Publishing Company DOI: 10.1142/S0218216516500681

![](_page_0_Picture_2.jpeg)

## Pseudo-cycles of surface-knots

Tsukasa Yashiro

Department of Mathematics and Statistics, College of Science, Sultan Qaboos University, P.O. Box 36, P.C. 123 Al-Khoud, Muscat, Sultanate of Oman yashiro@squ.edu.om

> Received 4 January 2016 Accepted 1 August 2016 Published 15 September 2016

#### ABSTRACT

In this paper, we describe a two-dimensional rectangular-cell-complex derived from a surface-knot diagram of a surface-knot. We define a pseudo-cycle for a quandle colored surface-knot diagram. We show that the maximal number of pseudo-cycles is a surface-knot invariant.

Keywords: Surface-knot; pseudo-cycle; invariant; diagrams.

Mathematics Subject Classification 2010: 57Q45, 57M25

### 1. Introduction

A surface-knot F is a connected oriented closed surface smoothly embedded in  $\mathbb{R}^4$ . If the genus of F is zero, then F is called a 2-knot. Let proj :  $\mathbb{R}^4 \to \mathbb{R}^3$  be the orthogonal projection defined by  $\operatorname{proj}(x_1, x_2, x_3, x_4) = (x_1, x_2, x_3)$ . The singular set  $S(\operatorname{proj}|F) \subset F$  of  $\operatorname{proj}|F: F \to \mathbb{R}^3$  is the set defined as  $S(\operatorname{proj}|F) = \{x \in F \mid \#((\operatorname{proj}|F)^{-1}(\operatorname{proj}(x))) > 1\}$ . We can assume that a point of image of the closure of  $S(\operatorname{proj}|F)$  in F is either a double point or a triple point or a branch point.

We define a height function  $h: F \to \mathbb{R}$  by  $h(x_1, x_2, x_3, x_4) = x_4$ . The values h(x),  $x \in S(\operatorname{proj}|_F)$  will be called a *crossing information*. A *surface-knot diagram* of a surface-knot F is the projected image  $\operatorname{proj}(F)$  of F with its crossing information [3]. We denote the surface-knot diagram of F by  $D_F$ . If we do not consider the crossing information, then we denote  $\operatorname{proj}(F)$  by  $|D_F|$ .

The minimal number of triple points for all possible surface-knot diagrams of a surface-knot F is called a *triple point number* denoted by t(F). This is a surface-knot invariant. There is no 2-knots with triple point number 1 or 2 or 3 [12]. Zeeman [16] studied a special type of 2-knots called twist spun knots. Satoh and

Shima [13] proved that the triple point numbers of a double-twist spun trefoil and a triple-twist spun trefoil knot, are 4 and 6, respectively.

In this paper, we intend to obtain a geometric surface-knot invariant obtained from diagrams.

The organization of this paper is the following. In Sec. 2, we define the lower decker set denoted by  $S_b$  (see Definition 2.2). We will introduce a rectangular-cell-complex  $K_{D_F}$  associated with  $D_F$ . The complex can be decomposed into two types of subcomplexes  $R_{D_F}$  and  $B_{D_F}$  (Lemma 2.9). The subcomplex  $R_{D_F}$  consists of singular rectangular-cells, each of which represents a triple point in  $D_F$ , and discs bounded by loops, each of which represents a branch point. The subcomplex  $B_{D_F}$  represents the set of simple double circles in  $S_b$ . Also, it is decomposed into  $K_1, \ldots, K_n$ , where each  $K_i$  corresponds to a connected component of  $S_b$  (see [9]):

$$K_{D_F} = R_{D_F} + B_{D_F} (1.1)$$

$$= K_1 + \dots + K_n. \tag{1.2}$$

Each  $K_i$  is called a parcel. Each parcels K contains a connected component  $s_b$  of the lower decker set  $S_b$  and  $s_b$  represents a subcomplex  $c_b$  of  $K_{D_F}$ . In Sec. 3, we define a chain complex  $C_2(K_{D_F})$  of  $K_{D_F}$  and discuss about quandle chain complex  $\{C_*^Q(X), \partial_*\}$ . A homomorphism  $\operatorname{Col}_{\sharp}: C_2(K_{D_F}) \to C_3^Q(X)$  is induced from the coloring of  $D_F$  with a quandle X. Section 4 defines a pseudo-cycle in  $K_{D_F}$  and discuss about relations between Roseman moves and deformations on the rectangular-cell-complex. Our main result is the following:

<span id="page-1-1"></span>**Theorem 1.1.** Let  $D_F$  be a surface-knot diagram of a surface-knot F. Then the maximal number of pseudo-cycles in  $K_{D_F}$  is a surface-knot invariant.

A proof will be given in Sec. 5. Finally, Sec. 6 presents some examples.

# <span id="page-1-0"></span>2. Complexes for Surface-Knot Diagrams

Rectangular-cell-complexes for surface-knot diagrams are introduced and discussed in [9, 10, 15]. Here, we give some detailed description of the complex. Let F be a surface-knot, and let  $D_F$  be a surface-knot diagram of F. In this section, we will construct a two-dimensional rectangular-cell-complex associated with  $D_F$ . Then, we will show some properties of the complex.

We define some standard 2-cells as follows.

**Definition 2.1.** Let I be the closed interval [0,1]. Put labels  $a_0$ ,  $a_1$ ,  $a_2$  and  $a_3$  onto vertices (0,0), (1,0), (1,0) and (1,1) of  $I^2$  respectively. For each edge of  $I^2 = I \times I$ , a specified orientation is given and it is expressed by the order of vertices of the edge such as  $a_0a_1$ ,  $a_0a_2$ ,  $a_1a_3$  and  $a_2a_3$  (see the left picture of Fig. 1). We call the labeled  $I^2$  a standard rectangle. We write the rectangle as  $(a_0; a_0a_1, a_0a_2; a_3)$  and denote it by  $\rho$ . We call the vertices  $a_0$  a source vertex and  $a_3$  a target vertex.

![](_page_2_Picture_2.jpeg)

Fig. 1. Standard cells.

<span id="page-2-2"></span><span id="page-2-1"></span>We denote a disc bounded by a looped edge  $\widehat{a_0a_0}$  by  $\delta$  (see Fig. 1). We call the special edge  $\widehat{a_0a_0}$  a loop based at  $a_0$ . In the following, we treat a looped edge as an edge unless otherwise stated. The orientation of the boundary of  $\delta$  is counterclockwise as the middle picture in Fig. 1. We call  $\delta$  a standard loop disc and write as  $(a_0; \widehat{a_0a_0})$ .

We also define a 2-cell with two edges and two vertices as the right picture in Fig. 1. We denote this by  $\lambda$ . We call this a *standard bubble*. We write as  $(a_0a_1; a_0a_1)$ .

Let F be a surface-knot, and let  $D_F$  be a surface-knot diagram of F. Let  $h: \mathbb{R}^4 \to \mathbb{R}$  be a height function. Let A, B be subsets of  $\mathbb{R}^4$ . If h(b) < h(a) for any  $a \in A$ ,  $b \in B$ , then we write h(B) < h(A).

<span id="page-2-0"></span>**Definition 2.2 (Carter and Saito [2]).** For the set  $S(\text{proj}|_F)$ , there are two families  $\mathcal{S}_a = \{s_a^1, \dots, s_a^n\}$  and  $\mathcal{S}_b = \{s_b^1, \dots, s_b^n\}$  of immersed open intervals and immersed circles with transversal crossings such that  $\text{proj}(s_a^i) = \text{proj}(s_b^i)$   $i = 1, \dots, n$  and  $h(s_b^i) < h(s_a^i)$   $i = 1, \dots, n$  [2]. We denote the union  $\bigcup_{s_W \in \mathcal{S}_W} \text{cl}(s_W)$  by  $S_W$  for W = a, b.

**Definition 2.3.** The lower decker set  $S_b$  can be seen as a graph with nodes, lines and loops embedded in F. Nodes are boundary points of a line of  $S_b$  corresponding to either a triple point or a branch point in  $D_F$ . We call the node corresponding to a branch point a branch point. We call the node corresponding to triple points a crossing points.

Let J denote the closed interval [-1,1]. Let  $m \geq 0$ ,  $r \geq 0$ ,  $u \geq 0$  and  $l \geq 0$  be the numbers of lines, isolated simple closed curves, crossing points and branch points of  $S_b$  respectively.

Then there are two cases.

- (1) If  $s_b$  is an immersed circle, then there is an immersion  $\alpha: S^1 \to s_b$  such that  $\alpha$  extends to an immersion  $\widehat{\alpha}: S^1 \times J \to F$  with  $\widehat{\alpha}|(S^1 \times \{0\}) = \alpha$  [8]. We define  $N(s_b)$  as  $\widehat{\alpha}(S^1 \times J)$ .
- (2) If  $s_b$  is an immersed closed interval, then there is an immersion  $\beta: I \to s_b$  such that  $\beta$  extends to an immersion  $\widehat{\beta}: I \times J \to F$ .

Suppose that  $s_b = \beta(I)$ . For end points  $\{\beta(0), \beta(1)\}$  of  $s_b$ , take small closed disc neighborhoods  $B_0$  and  $B_1$  of  $\beta(0)$  and  $\beta(1)$  in F, respectively such that  $\widehat{\beta}(\{0\} \times J) \subset$  $B_0$  and  $\widehat{\beta}(\{1\} \times J) \subset B_1$ . Then, we denote the  $B_0 \cup \widehat{\beta}(I \times J) \cup B_1$  by  $N(s_b)$ . We denote  $\bigcup_{s_b \in S_b} N(s_b)$  by  $N(S_b)$ .

Let  $l_1, l_2, \ldots, l_{m+r}$  be lines and simple closed curves of  $S_b$ . Take a point  $q_i \in l_i$  or  $q_i \in \mathbb{S}^1$   $(i = 1, 2, \ldots, m)$  such that

- (i)  $q_i \in l_i$  is neither a branch point nor a crossing point,
- (ii)  $\widehat{\alpha}(q_i \times J)$  or  $\widehat{\beta}(q_i \times J)$  are not in the multiple point set of  $\widehat{\alpha}$  or  $\widehat{\beta}$ .

We denote  $\widehat{\alpha}(q_i \times J)$  or  $\widehat{\beta}(q_i \times J)$  by  $e_i$ . We call each  $e_i$  (i = 1, 2, ..., m) an edge.

 $F \setminus S_b$  is the union of finite number of connected regions denoted by  $R_0, \ldots, R_n$ . For an edge e, there are connected regions R, R', R'' in  $F \setminus S_b$  such that  $\operatorname{proj}(e)$  transversely intersects to  $\operatorname{proj}(R)$  at a double point  $p = \operatorname{proj}(e) \cap \operatorname{proj}(R)$  and  $\operatorname{proj}(R)$  locally divides  $\operatorname{proj}(R')$  and  $\operatorname{proj}(R'')$ . Let  $\mathbf{n}, \mathbf{n}'$  and  $\mathbf{n}''$  be orientation normals to  $\operatorname{proj}(R)$ ,  $\operatorname{proj}(R')$  and  $\operatorname{proj}(R'')$ . Let  $\mathbf{u}$  be the orientation vector of the double curve containing p so that  $\{\mathbf{n}, \mathbf{n}', \mathbf{u}\}$  is a positive orientation in  $\mathbb{R}^3$ . The orientation of the edge e is defined by the direction of the tangent vector  $\mathbf{v}$  to the arc  $\operatorname{proj}(e)$  at p so that  $\{\mathbf{v}, \mathbf{n}', \mathbf{u}\}$  gives a positive orientation.

We have obtained a closed neighborhood  $N(S_b)$  with directed proper edges  $\{e_j\}$   $j=1,\ldots,m+r$ . Let  $F\setminus N(S_b)=\{V_0,\ldots,V_n\}$ : the set of connected regions so that  $V_s\subset R_s,\ (s=0,\ldots,n)$ .

We define an equivalence relation  $x \sim y$  for  $x, y \in F$ , if  $x, y \in \operatorname{cl}(V_i)$  or  $x = y \in \operatorname{int}(N(S_b))$ . This equivalence relation identifies each  $V_i$  with a point. We denote the point by  $v_i$  and call a *vertex*. Let  $\mathcal{V}$  denote the set of vertices. We denote the quotient space  $F/_{\sim}$  by F'. Define a quotient map

$$g: F \to F'$$
 (2.1)

by  $g(x) = v_i$  if  $x \in cl(V_i)$  and g(x) = x if  $x \in int(N(S_b))$ .

Let  $D_F$  be a surface-knot diagram. Suppose that there is a triple point p in  $D_F$ . Take a ball neighborhood B(p) of p in  $\mathbb{R}^3$ , so that  $\operatorname{proj}|_F^{-1}(B(p) \cap D_F)$  is a disjoint union of three discs  $D_T$ ,  $D_M$  and  $D_B$  with  $h(D_T) > h(D_M) > h(D_B)$ . We call  $D_T$ ,  $D_M$  and  $D_B$  the top sheet, middle sheet and bottom sheet.

We introduce a diagram  $K_b$  associated with the quotient space F'. From the definition of F',  $S_b \subset F'$ . Near a crossing point, the crossing is formed by two arcs say  $\gamma_1$  and  $\gamma_2$ . We suppose that  $\gamma_1$  is formed by double points of the bottom and middle sheets, and that  $\gamma_2$  is formed by double points of the bottom and top sheets. We add crossing information to the crossing point of  $S_b$  so that  $\gamma_2$  is higher than  $\gamma_1$ . We denote  $S_b$  with the crossing information by  $K_b$ . We express the crossing point of  $K_b$  like as a crossing point of a classical knot diagram. Note that  $|K_b| = S_b$  may contain branch points.

**Lemma 2.4.** Let F be a surface-knot and let  $D_F$  be a surface-knot diagram of F. Let  $S_b$  be the lower decker set of  $D_F$ , and let F' be the quotient space defined

above. Then the set  $\operatorname{int}(N(S_b))\setminus (\bigcup_{j=1}^m e_j) \subset F'$  consists of connected regions such that each region is either

- (a) An open disc containing a crossing point of  $S_b$  or
- (b) An open disc containing a branch point or
- (c) An open disc containing no crossing points or no branch points of  $S_h$ .

**Proof.** From the definition of edges and  $N(S_b)$ , it is obvious.

We denote the discs in (a), (b) and (c) by  $C'_{i_u}$ , (i = 1, ..., u),  $B'_{i_l}$ ,  $(i_l = 1, ..., l)$  and  $D'_{i_r}$   $(i_r = 1, 2, ..., r)$  respectively (see Fig. 2). Adding the edges contained in the closures of  $C'_{i_u}$ ,  $B'_{i_l}$  and  $D'_{i_r}$ , we obtain closed discs  $C_{i_u}$  and  $B_{i_r}$ , and closed annuli  $D_{i_l}$ . For each  $i_u = 1, ..., u$ , there is a map

$$f_{i_u}: \rho \to C_{i_u} \tag{2.2}$$

such that

- (1)  $f_{i_u}|\text{int}(\rho)$  is a homeomorphism onto  $C'_{i_u}$ ,
- (2) Each edge of  $\rho$  is mapped onto one of edges in  $C_{i_u}$  with respect to the orientation such that the edge  $a_0a_1$  is mapped onto an edge intersecting the lower arc of  $K_b$  with respect to the crossing point in  $C_{i_u}$ , and the edge  $(a_0a_2)$  is mapped onto an edge intersecting the upper arc of  $K_b$  in  $C_{i_u}$ .

We call  $f_{i_u}(\rho)$  a rectangle. Putting  $v_i = f_{i_u}(a_i)$  (i = 0, 1, 2, 3), we denote  $f_{i_u}(\rho)$  by  $(v_0; v_0v_1, v_0v_2; v_3)$ . Note that  $f_{i_u}$  may be an orientation reversing map and the number of vertices and edges in a rectangle may less than four. For a rectangle  $\sigma$ , define the signature  $\varepsilon(\sigma) = +1$  if  $f_{i_u}$  preserves the orientation, otherwise -1 (see Fig. 3).

The set  $B_{i_l}$  (k = 1, ..., l) is a disc with a base vertex  $v_0$  and a looped edge  $\widehat{v_0v_0}$ . There is a map

$$f'_{i_l}: \delta \to B_{i_l}$$
 (2.3)

![](_page_4_Figure_15.jpeg)

<span id="page-4-0"></span>Fig. 2. Discs corresponding to a crossing, a branch point and a circle.

![](_page_5_Picture_2.jpeg)

Fig. 3. Signatures of rectangles.

<span id="page-5-0"></span>such that

- (1)  $f'_{i_l}|\text{int}(\delta)$  is a homeomorphism onto  $B'_{i_l}$ ,
- (2)  $f'_{i_l}(a_0 a_0) = e$  with respect to the orientation.

We call  $f'_{i_l}(\delta)$  a loop disc. Let  $\sigma$  denote a loop disc. We define the signature  $\varepsilon(\sigma) = +1$  if  $f_{i_l}$  preserves the orientation, otherwise -1 (see Fig. 4).

The set  $D_{i_r}$  is a union of an open disc, an edge and one or two vertices. There is a map

$$f_{i_r}^{"}: \lambda \to D_{i_r}$$
 (2.4)

such that

- (1)  $f_{i_r}''|\text{int}(\lambda)$  is a homeomorphism onto  $D_{i_r}'$ ,
- (2)  $f_{i_r}^{"}$  maps two edges onto the edge e of  $D_{i_r}$ .

We call  $f''_{i_r}(\lambda)$  a bubble. For a bubble  $\sigma$ ,  $\varepsilon(\sigma) = 0$ .

<span id="page-5-1"></span>![](_page_5_Picture_14.jpeg)

Fig. 4. Parities of loop discs.

The pair of the rectangular-cell-complex defined from F' and  $K_b$  will be denoted by  $K_{D_F}$  (cf. [5]). The followings are the properties of  $K_{D_F}$ .

**Lemma 2.5.** Let  $K_{D_F}$  be the rectangular-cell-complex induced from a surface-knot diagram  $D_F$ . Then the following hold.

- (i)  $K_{D_F}$  is uniquely determined by  $|D_F|$  up to isotopy.
- (ii)  $|K_{D_F}|$  is a union of vertices, edges and rectangles, loop discs and bubbles.
- (iii) A vertex of  $K_{D_F}$  corresponds to a connected region of  $F \setminus N(S_b)$ .
- (iv) A rectangle of  $K_{D_F}$  corresponds to a triple point in  $D_F$ .
- (v) A loop disc of  $K_{D_F}$  corresponds to a branch point in  $D_F$ .
- (vi) Every point q of the interior of an edge of  $K_{D_F}$  has an open neighborhood N(q) in  $|K_{D_F}|$  such that  $N(q) \cap |K_{D_F}|$  is an open 2-disc.
- (vii) Each edge is labeled by vertices  $v_0, \ldots, v_n$  of  $K_{D_F}$ .

**Proof.** (i)  $f_i(\rho)$ ,  $f'_k(\delta)$  and  $f''(\lambda)$  in  $F' = |K_{D_F}|$  depend on the choice of edges  $e_j$  in  $E_j$ , (j = 1, ..., m). Take an edge  $e'_j$  in  $E_j/_{\sim} \subset F'$ .  $e_j$  and  $e'_j$  has the same vertices and  $\operatorname{int}(E_j)$  is an open disc. This implies that  $e_j$  and  $e'_j$  are isotopic to each other. Thus  $f_i(\rho)$ ,  $f'_k(\delta)$  and  $f''(\lambda)$  are determined up to isotopy.

From (ii) to (v), they are immediate consequences from the construction.

- (vi) We can take a thin neighborhood  $N(\operatorname{int}(e_j))$  of  $\operatorname{int}(e_j)$  in  $E_j$ , so that  $g|N(\operatorname{int}(e_j))$  is an homeomorphism onto the image in  $K_{D_F}$ . Then, we can find a desired disc neighborhood of a point g of  $\operatorname{int}(e_j)$ .
- (vii) For each edge e, there is  $k \in \{1, ..., n\}$  such that  $\operatorname{proj}(g^{-1}(\operatorname{int}(e))) \subset D_F$  intersects a sheet  $\operatorname{proj}(V_k)$  at a unique point. Thus the edge e has a  $label v_k$  denoted by  $w(e): w(e) = v_k$ .

Note that in the following, when we use  $K_{D_F}$ , we assume that all edges are weighted by vertices. We denote the quotient space F' by  $|K_{D_F}|$ .

We have the following.

**Proposition 2.6.** Let F be a surface-knot. Then  $|K_{D_F}|$  is connected for any surface-knot diagram  $D_F$  of F.

**Proof.** Let  $g: F \to F' = |K_{D_F}|$  be the quotient map. Then by the definition, g is continuous and F is connected. Thus  $g(F) = F' = |K_{D_F}|$  is connected.

**Definition 2.7.** Let  $K_{D_F}$  be a rectangular-cell-complex induced from a surface-knot diagram  $D_F$ . The union of rectangular-cells or loop discs or bubbles in  $K_{D_F}$  corresponding to a connected component in  $S_b$  is called a *parcel*.

We define the dimension of the empty set  $\emptyset$  is -1.

<span id="page-7-2"></span>**Lemma 2.8.** For a surface-knot diagram  $D_F$  of a surface-knot F,  $K_{D_F}$  is the union of finite number of parcels  $K_1, \ldots, K_s$  such that

$$\dim(K_i \cap K_j) \le 0, \quad (i \ne j). \tag{2.5}$$

**Proof.** The neighborhood  $N(S_b)$  of  $S_b$  in F is a disjoint union of neighborhoods  $N_1, \ldots, N_k$  of connected components of  $S_b$  in F. By the quotient map  $g: F \to F'$  each boundary component of  $\partial N_i$   $(i = 1, \ldots, k)$  is mapped to a vertex. Thus each  $g(N_i)$   $(i = 1, \ldots, k)$  is a parcel.

We will show that if  $K_i \cap K_j \neq \emptyset$   $(i \neq j)$ , then  $K_i \cap K_j$  consists of vertices. Assume that  $K_i \cap K_j$  contains an edge e. Every point q of int(e) has a neighborhood which is not homeomorphic to a disc. This contradicts the definition of an edge of  $K_{D_F}$ . Similarly  $K_i \cap K_j$  cannot be a 2-cell. Then the desired result follows.  $\square$ 

Suppose that  $K_{D_F} = \bigcup_{i=1}^n K_i$ , where  $K_i$  are distinct parcels of  $K_{D_F}$ . Then, we write  $K_{D_F} = K_1 + \cdots + K_n$ . Let  $R_{D_F}$  denote the union of parcels consisting of rectangles and loop discs. Let  $B_{D_F}$  denote the union of parcels consisting of bubbles.

<span id="page-7-0"></span>**Lemma 2.9.** Let  $D_F$  be a surface-knot diagram of a surface-knot F. Then the following holds.

$$K_{D_F} = R_{D_F} + B_{D_F}. (2.6)$$

**Proof.** The surface-knot diagram  $D_F$  induces a rectangular-cell-complex  $K_{D_F}$  from the set  $S_b \subset F$ . Recall that  $S_b$  is the union of immersed closed intervals with finite number of crossing points or simple closed curves. By the definition of  $K_{D_F}$ , each rectangle corresponds to a crossing point of  $S_b$  and each bubble corresponds to an isolated simple closed curve in  $S_b$ . Branch points correspond to loop discs. Therefore,  $K_{D_F}$  consists of parcels of rectangles or loop discs or bubbles. Thus from Lemma 2.8  $K_{D_F} = R_{D_F} + B_{D_F}$ .

# <span id="page-7-1"></span>3. Chain Complexes of $K_{D_F}$

A quandle X is a nonempty set equipped with a binary operation \* satisfying (i) a\*a=a, (ii) for  $a,b\in X$  there is a unique  $c\in X$  such that c\*a=b, (iii) (a\*b)\*c=(a\*c)\*(b\*c) for  $a,b,c\in X$ .

For a quandle X, the quandle homology of X is defined and is denoted by  $H_*^Q(X)$  (see [1, 3, 4] for definition and details). Here, we consider the quandle homology group of a quandle chain complex with integer coefficients.

Let  $D_F$  be a surface-knot diagram of a surface-knot F. Denote the family of open connected components of  $F \setminus S_b$  by  $\mathcal{R}$ . Figure 5 shows a neighborhood of a double point in  $\mathbb{R}^3$ , where  $\mathbf{n}$  means an orientation normal. A quandle coloring Col

![](_page_8_Picture_2.jpeg)

Fig. 5. A neighborhood of a double point in  $\mathbb{R}^3$ .

<span id="page-8-1"></span><span id="page-8-0"></span>is a map

$$\operatorname{Col}: \mathcal{R} \to X$$
 (3.1)

such that at every double point curve depicted in Fig. 5, the relation  $Col(R'_1) * Col(R'_2) = Col(R'_3)$  holds.

Let  $K_{D_F}$  be the rectangular-cell-complex for a surface-knot diagram  $D_F$ . Let  $\mathcal{V}$  and  $\mathcal{E}$  be the set of vertices and the set of edges respectively. The quandle coloring Col can be interpreted as a map  $\mathcal{V} \to X$ ; we also denote this map by Col. Col extends to  $\mathcal{V} \cup \mathcal{E}$ , so that Col assigns an edge  $e \in \mathcal{E}$  its label w(e). We call the map Col:  $\mathcal{V} \cup \mathcal{E} \to X$  a coloring of  $K_{D_F}$ . If  $K_{D_F}$  is equipped with a coloring with a quandle X, then  $K_{D_F}$  is said to be colourable with X.

Let us view the 2-complex  $K_{D_F}$  as a complex with rectangles, loop discs, bubbles, edges and vertices. We call rectangles or loop discs or bubbles 2-cells, edges 1-cells and vertices 0-cells.

Let  $C'_n(K_{D_F})$  be a free abelian group generated by n-cells of  $K_{D_F}$  (n = 0, 1, 2). Each  $c \in C'_n(K_{D_F})$  is expressed by

$$c = \sum_{i=1}^{m} \lambda_i \sigma_i,$$

where  $\sigma_i \in K_{D_F}$ ,  $\lambda_i \in \mathbb{Z}$ , for i = 1, 2, ..., m.

We define a homomorphism  $\partial_n: C'_n(K_{D_F}) \to C'_{n-1}(K_{D_F}), (n = 1, 2)$  by for  $\sigma = (v_0; v_0v_1, v_0v_2; v_3) \in C'_n(K_{D_F}),$ 

$$\partial_2(v_0; v_0v_1, v_0v_2; v_3) = v_0v_2 + v_2v_3 - v_1v_3 - v_0v_1, \tag{3.2}$$

$$\partial_2(v_0; \widehat{v_0 v_0}) = \widehat{v_0 v_0}, \tag{3.3}$$

$$\partial_2(v_0v_1; v_0v_1) = 0, (3.4)$$

$$\partial_1(v_0 v_1) = v_0 - v_1. (3.5)$$

Then, we obtain a chain complex  $\{C_n'(K_{D_F}), \partial_n\}$ , where  $C_n'(K_{D_F}) = 0$  for  $n \geq 3$  and n < 0. The homology groups  $H_n(K_{D_F})$  are defined. Let  $C_*^Q(X) = \{C_n^Q(X), \partial_n\}$  be a quandle chain complex with  $C_n^Q(X) = 0$  for  $n \leq 0$ . The quandle homology groups  $H_n^Q(X)$  are defined.

For the chain groups  $C_n^R(X)$  and  $C_n^Q(X)$  of a quandle X, see [1, 3] for definitions. Let  $(v_0; v_0v_1, v_0v_2; v_3)$  be a rectangle in  $K_{D_F}$ . Then, we define a map

$$\operatorname{Col}_{\sharp}: C'_n(K_{D_F}) \to C^R_{n+1}(X)$$

by

$$\operatorname{Col}_{\sharp}(v_0; v_0v_1, v_0v_2; v_3) = (\operatorname{Col}(v_0), \operatorname{Col}(v_0v_1), \operatorname{Col}(v_0v_2)) \in C_3^R(X).$$

For a loop disc  $(v_0; v_0v_0)$ ,  $\operatorname{Col}_{\sharp}(v_0; v_0v_0) = (\operatorname{Col}(v_0), \operatorname{Col}(v_0)) \in C_2^R(X)$ . For a bubble  $(v_0v_1; v_0v_1)$ ,  $\operatorname{Col}(v_0v_1; v_0v_1) = 0$  and its unique edge is mapped into  $C_2^R(X)$  with the similar way. Then the map Col induces a homomorphism  $\operatorname{Col}_{\sharp}: C'_n(K_{D_F}) \to C_{n+1}^Q(X)$  and it induces the chain map:

$$\operatorname{Col}_{\sharp}: C'_{\ast}(K_{D_F}) \to C^{Q}_{\ast}(X). \tag{3.6}$$

Let  $\sigma \in C'_n(K_{D_F})$  be a generator. Then  $\sigma$  is degenerate if  $\operatorname{Col}_{\sharp}(\sigma) = 0$ , The homomorphism  $\operatorname{Col}_{\sharp}$  induces the homomorphism:

$$\operatorname{Col}_n: H_n(K_{D_F}) \cong H_n(R_{D_F}) \oplus H_n(B_{D_F}) \to H_{n+1}^Q(X), (0 \le n).$$
 (3.7)

Obviously,  $\operatorname{Col}_2(B_{D_F}) = 0$ .

## <span id="page-9-0"></span>4. Pseudo-Cycles and Roseman Moves

**Definition 4.1.** For a surface-knot diagram  $D_F$ , we have a rectangular cell complex  $K_{D_F}$ . If a chain  $c \in C'_2(K_{D_F})$  is in the special form:

$$c = \sum_{i=1}^{k} \varepsilon(\sigma_i)\sigma_i, \quad \sigma_i \in K_{D_F}, \tag{4.1}$$

where  $\sigma_i$  are rectangles or loop discs or bubbles, then c is called a fundamental chain.

**Definition 4.2.** Let c be a fundamental chain of  $C_2(K_{D_F})$ . If c satisfies the following conditions,

- (i)  $\operatorname{Col}_{\sharp} \partial(c) = 0$  and
- (ii)  $[\operatorname{Col}_{\sharp}(c)] \neq 0 \in H_3^Q(X)$

then c is called a pseudo-cycle in  $K_{D_F}$ .

Roseman [11] introduced seven types of local moves called *Roseman moves* to deform a surface-knot diagram into an equivalent surface-knot diagram. These are generalized Reidemeister moves. Here, we use six types of local moves (see [7, 14]) rather than seven. These moves are also called Roseman moves.

Now, we look at the relation between each Roseman move and the rectangular-cell-complex  $K_{D_F}$ .

![](_page_10_Picture_2.jpeg)

Fig. 6. Roseman moves  $R-1^{\pm}$ ,  $R-2^{\pm}$  and  $R-3^{\pm}$ .

<span id="page-10-2"></span><span id="page-10-0"></span>![](_page_10_Picture_4.jpeg)

Fig. 7. Roseman moves  $R-4^{\pm}$ ,  $R-5^{\pm}$  and R-6.

<span id="page-10-3"></span>![](_page_10_Picture_6.jpeg)

Fig. 8. Roseman moves  $R-1^{\pm}$  and the move on  $K_{D_F}$ .

## <span id="page-10-1"></span>Roseman move $R-1^{\pm}$

This move consists of two discs; one disc move into another (see Fig. 6) and this move creates an isolated circle and a bubble in  $S_b$  (see Fig. 8).

## Roseman move $R-2^{\pm}$

This move consists of three discs: one moving disc moves into a double curve formed by other two discs (see Fig. 6). Also this move contains R-1 $^{\pm}$ . For the complex  $K_{D_F}$ , the move contains the move obtained from R-1 $^{\pm}$  also it creates a pair of rectangles. In Fig. 9, the moving disc  $U_0$  is between the upper disc  $V_0$  and the lower disc  $V_1$ . This case R-2 $^{+}$  creates one bubble and substitute a pair of rectangles  $\tau = (v_3; v_3v_4, v_3v_1; v_2)$  and  $\tau' = -(v_3; v_3v_4, v_3v_1; v_2)$ . Thus the substituted chain is  $\tau + \tau' = \tau - \tau = 0$ .

![](_page_11_Picture_2.jpeg)

Fig. 9. Roseman moves R-2 $^{\pm}$  and the move on  $K_{D_F}$ .

<span id="page-11-0"></span>Note that there are other two cases depending on the position of  $U_0$  but other cases are similar to this case.

# Roseman move R- $3^{\pm}$

This move consists four discs: one moving disc moves into a triple point (see Fig. 6). For the complex  $K_{D_F}$ , the move contains the previous moves and it substitutes five or six rectangles to the complex (see Fig. 10). For Fig. 10, five rectangles are

![](_page_11_Figure_7.jpeg)

<span id="page-11-1"></span>Fig. 10. Roseman moves  $R-3^{\pm}$  and the move on  $K_{D_F}$ .

substituted:

$$\tau_1 = (v_7; v_7 v_8, v_7 v_9; v_{10}), \quad \varepsilon(\tau_1) = 1$$

$$\tau_2 = (v_7; v_7 v_9, v_7 v_3; v_5), \quad \varepsilon(\tau_2) = 1$$

$$\tau_3 = (v_7; v_7 v_8, v_7 v_3; v_4), \quad \varepsilon(\tau_3) = -1$$

$$\tau_4 = (v_8; v_8 v_{10}, v_8 v_4; v_6), \quad \varepsilon(\tau_4) = -1$$

$$\tau_5 = (v_9; v_9 v_{10}, v_9 v_5; v_6), \quad \varepsilon(\tau_5) = 1.$$

The original rectangle is  $\tau_0 = (v_3; v_3v_4, v_3v_5; v_6)$  with  $\varepsilon(\tau_0) = 1$ . Therefore, the chain  $c' - c = \tau_1 + \tau_2 - \tau_3 - \tau_4 + \tau_5 - \tau_0$ .

Let  $\operatorname{Col}(v_3) = x$ ,  $\operatorname{Col}(v_3v_4) = y$ ,  $\operatorname{Col}(v_3v_5) = z$  and  $\operatorname{Col}(u_0) = w$  for  $x, y, z, w \in X$ . Then  $\partial(x, w, y, z) = \operatorname{Col}_{\sharp}(c' - c)$ . Therefore, c' - c is homologous zero in  $H_3^Q(X)$ .

# Roseman move $R-4^{\pm}$

This move creates or eliminates a pair of branch points and a simple double arc joining them (see Fig. 7). For the complex  $K_{D_F}$ , the move R-4<sup>+</sup> adds two loop discs pasting at their boundaries (see Fig. 11).

# Roseman move $R-5^{\pm}$

This move consists of a branch point and a regular disc (see Fig. 7). There are two cases depending on the height of the branch point against the regular disc (see Fig. 12). If the moving disc  $U_0$  is lower than another disc, the deformation produces an extra rectangle in which two pairs of edges are pasted so that two edges appear (see Fig. 12).

### Roseman move R-6

This move consists of two regular discs intersecting at two simple proper curves (see Fig. 7). There is no '–' move as it is symmetric. There are two cases: one is the resulting diagram has the same number of connected components in  $S_b$  (the upper diagram in Fig. 13). The other is that the number of connected components in  $S_b$  is changed by the move (the lower diagram in Fig. 13). It is not difficult to see that either case, each rectangular cell is not deformed just the connection is changed.

![](_page_12_Figure_12.jpeg)

<span id="page-12-0"></span>Fig. 11. Roseman moves  $R-4^{\pm}$  and the move on  $K_{D_F}$ .

![](_page_13_Figure_2.jpeg)

Fig. 12. Roseman moves  $R-5^{\pm}$  and the move on  $K_{D_F}$ .

<span id="page-13-0"></span>![](_page_13_Figure_4.jpeg)

Fig. 13. Roseman moves R-6 and the move on  $K_{D_F}$ .

<span id="page-13-1"></span>Therefore, the chain c and c' are the same. Thus  $\operatorname{Col}_{\sharp}(c'-c)$  is homologous zero in  $H_3^Q(X)$ .

Therefore, we have the following:

<span id="page-13-2"></span>**Lemma 4.3.** Let F be a surface-knot and let  $D_F$  be a surface-knot diagram of F. Suppose that  $D_F$  is colored by a finite quantle X. Let c be a fundamental chain of

 $K_{D_F}$ . Then Roseman moves R- $k^{\pm}$  for k = 1, 2, 3, 4, 5 and R-6 preserve the homology class  $[\operatorname{Col}_{\sharp}(c)] \in H_3^Q(X)$ .

## <span id="page-14-0"></span>5. Proof of Theorem 1.1

**Proof.** Let c be the fundamental chain of  $K_{D_F}$ . In Lemma 4.3, Roseman moves from R- $1^{\mp}$  to R- $5^{\pm}$  and does not change the homology class  $[\operatorname{Col}_{\sharp}(c)]$  as well as it does not change the number of pseudo-cycles.

Thus, it is sufficient to show that Roseman move R-6 does not change the number of pseudo-cycles. Suppose that R-6 makes two distinct nondegenerate parcels  $K_1$  and  $K_2$  from one parcel K:  $K = K_1 \cup K_2$  (see Fig. 14).

Then there are edges  $\{e, e'\}$  in K (see Fig. 14) such that

- (1) w(e) = w(e'),
- (2)  $\partial(K_1) = e' e$ ,
- (3)  $\partial(K_2) = e e'$ .

Therefore,

$$\operatorname{Col}_{\sharp} \partial_{2}(K_{1}) = \operatorname{Col}_{\sharp}(e' - e) = \operatorname{Col}_{\sharp}(e') - \operatorname{Col}_{\sharp}(e) = 0$$
$$\operatorname{Col}_{\sharp} \partial_{2}(K_{2}) = \operatorname{Col}_{\sharp}(e - e') = \operatorname{Col}_{\sharp}(e) - \operatorname{Col}_{\sharp}(e') = 0.$$

Hence, if K is a pseudo-cycle, then the subcomplexes  $K_1$  and  $K_2$  are both pseudo-cycles. Therefore, the number of fundamental pseudo-cycles is not changed by the R-6 move. This implies that the maximal number of nondegenerate fundamental pseudo-cycles is invariant under the Roseman moves up to the quandle homology.

# <span id="page-14-1"></span>6. Examples

Here, we present some examples of pseudo-cycles of some surface-knot diagrams.

![](_page_14_Figure_15.jpeg)

<span id="page-14-2"></span>Fig. 14. The middle diagram (b) is substituted for describing the deformation on the complex induced by the R-6 move.

**Definition 6.1.** Let  $\mu(F, X)$  denote the maximal number of pseudo-cycles for all colorings of a quandle X.

Let F be a surface-knot. A diagram that has the minimal number of triple points is called a t-minimal surface-knot diagram. A pseudo-ribbon surface-knot [6] is a surface-knot F with t(F) = 0.

**Proposition 6.2.** For a pseudo-ribbon surface-knot F,  $\mu(F,X) = 0$ .

**Proof.** A pseudo-ribbon surface-knot has a surface-knot diagram with no triple points. Thus the rectangular-cell-complex  $K_{D_F}$  is a union of bubbles. Thus there is no pseudo-cycles.

**Proposition 6.3.** Let F be the double twist spun trefoil colored by the dihedral quantile  $R_3$  of order 3. Then  $\mu(F, R_3) = 1$ .

**Proof.** In [13], it is proved that the triple point number of the double twist spun trefoil is 4. We have a t-minimal diagram with 4 triple points and 4 branch points (see [13, 15]). The rectangular-cell-complex of the t-minimal surface-knot diagram is shown in Fig. 15. The diagram in Fig. 15 is a developed diagram; the edges on the both sides are pasted to obtain  $K_{D_F}$ . This consists of four rectangular-cells and four loop discs:

$$\tau_1 = (v_0; v_0 v_1, v_0 v_2; v_2), \quad \tau_2 = (v_0; v_0 v_1, v_0 v_2; v_1), 
\tau_3 = (v_2; v_2 v_3, v_2 v_1; v_3), \quad \tau_4 = (v_1; v_1 v_3, v_1 v_2; v_3), 
\sigma_1 = (v_2; \widehat{v_2 v_2}), \quad \sigma_2 = (v_1; \widehat{v_1 v_1}), 
\sigma_3 = (v_3; \widehat{v_3 v_3}), \quad \sigma_4 = (v_3; \widehat{v_3 v_3}).$$

![](_page_15_Figure_9.jpeg)

<span id="page-15-0"></span>Fig. 15.  $K_{D_F}$ .

The fundamental cycle c is:

$$c = -\tau_1 - \tau_2 + \tau_3 + \tau_4 - \sigma_1 - \sigma_2 + \sigma_3 + \sigma_4.$$

The surface-diagram is colored by the dihedral quandle of order 3. Then, it is not difficult to see that any combination of rectangular cells and loop discs cannot be pseudo-cycles except c. Thus the fundamental cycle c is the only one pseudo-cycle.

# **Acknowledgments**

The author would like to thank Professors A. Kawauchi, S. Kamada and S. Satoh for valuable discussions about the ideas of the early version of the paper. Also, he would like to thank Professors D. B. Gauld and G. J. Martin for giving him opportunities to continue the research in the University of Auckland and Massey University Albany.

# <span id="page-16-8"></span><span id="page-16-0"></span>**References**

- [1] J. S. Carter, D. Jelsovsky, S. Kamada, L. Langford and M. Saito, State-sum invariants of knotted curves and surfaces from quandle cohomology, *Electron. Res. Announc. Amer. Math. Soc.* **5** (1999) 146–156.
- <span id="page-16-5"></span>[2] J. S. Carter and M. Saito, Surfaces in 3-space that do not lift to embeddings in 4 space, in *Knot Theory* (Warsaw, 1995), Banach Center Publications, Vol. 42 (Polish Academy of Science, Warsaw, 1998), pp. 29–47.
- <span id="page-16-9"></span><span id="page-16-1"></span>[3] J. S. Carter and M. Saito, *Knotted Surfaces and their Diagrams*. Mathematical Surveys and Monographs, Vol. 55 (American Mathematical Society, Providence, RI, 1998).
- <span id="page-16-10"></span>[4] J. S. Carter, S. Kamada and M. Saito, *Surfaces in* 4*-Space*, *Low-Dimensional Topology, III*, Encyclopaedia of Mathematical Sciences, Vol. 142 (Springer-Verlag, Berlin, 2004).
- <span id="page-16-7"></span>[5] R. Fenn, C. Rouke and B. Sanderson, Trunks and classifying spaces, *Appl. Categ. Structures* **3** (1995) 321–356.
- <span id="page-16-13"></span>[6] A. Kawauchi, On pseudo-ribbon surface-links, *J. Knot Theory Ramifications* **11**(7) (2002) 1043–1062.
- <span id="page-16-12"></span><span id="page-16-6"></span>[7] K. Kawamura, On relationship between seven types of Roseman moves, *Topology Appl.* **196** (2015) 551–557.
- <span id="page-16-3"></span>[8] B. H. Li, On immersions of manifolds in manifolds, *Sci. Sinica Ser. A* **25** (1982) 255–263.
- [9] A. Mohamad and T. Yashiro, On triple point numbers of 5-colorable 2-knots, *J. Knot Theory Ramifications* **18**(11) (2009) 1493–1508.
- <span id="page-16-4"></span>[10] A. Mohamad and T. Yashiro, Surface diagrams with at most two triple points, *J. Knot Theory Ramifications* **21**(1) (2012) 17, Article ID:1250013.
- <span id="page-16-11"></span>[11] D. Roseman, Reidemeister-type moves for surfaces in four dimensional space, *Knot Theory* (Warsaw, 1995), Banach Center Publications, Vol. 42 (Polish Academy of Science, Warsaw, 1998), pp. 347–380.
- <span id="page-16-2"></span>[12] S. Satoh, No 2-knot has triple point number two or three, *Osaka J. Math.* **42**(3) (2005) 543–556.

- <span id="page-17-1"></span>[13] S. Satoh and A. Shima, Triple point numbers and quandle cocycle invariants of knotted surfaces in 4-space, *New Zealand J. Math.* **34**(1) (2005) 71–79.
- <span id="page-17-3"></span><span id="page-17-2"></span>[14] T. Yashiro, A note on Roseman moves, *Kobe J. Math.* **22**(1–2) (2005) 31–38.
- [15] T. Yashiro, Cell-complexes for *t*-minimal surface diagrams with 4 triple points, in *Intelligence of low dimensional topology 2006*, Series on Knots and Everything, Vol. 40 (World Scientific, 2007), pp. 367–374.
- <span id="page-17-0"></span>[16] E. C. Zeeman, Twisting spun knots, *Trans. Amer. Math. Soc.* **115** (1965) 471–495.