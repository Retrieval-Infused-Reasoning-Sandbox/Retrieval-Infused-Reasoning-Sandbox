# Probabilistic Counting Algorithms for Data Base Applications

## PHILIPPE FLAJOLET

INRIA, Rocyuencourt, 78153 Le Chesnav, France

## G. NIGEL MARTIN

IBM Detlelopnzent Lahoralory, Hursley Park, Winchester, Hampshire S0212JN, United Kingdom

Received June 13, 1984; revised April 3. 1985

This paper introduces a class of probabilistic counting algorithms with which one can estimate the number of distinct elements in a large collection of data (typically a large tile stored on disk) in a single pass using only a small additional storage (typically less than a hundred binary words) and only a few operations per element scanned. The algorithms are based on statistical observations made on bits of hashed values of records. They are by construction totally insensitive to the replicative structure of elements in the file; they can be used in the context of distributed systems without any degradation of performances and prove especially useful in the context of data bases query optimisation. '7' 1985 Academic Press. Inc

## 1. INTR~OUCTI~N

As data base systems allow the user to specify more and more complex queries, the need arises for efficient processing methods. A complex query can however generally be evaluated in a number of different manners, and the overall performance of a data base system depends rather crucially on the selection of appropriate decomposition strategies in each particular case.

Even a problem as trivial as computing the intersection of two collections of data A and B lends itself to a number of different treatments (see, e.g., [7]):

- 1. Sort A, search each element of B in A and retain it if it appears in A;
- 2. sort A, sort B, then perform a merge-like operation to determine the intersection;
- 3. eliminate duplicates in A and/or B using hashing or hash filters, then perform Algorithm 1 or 2.

Each of these evaluation strategy will have a cost essentially determined by the number of records a, b in A and B, and the number of distinct elements ~1, j? in A and B, and for typical sorting methods, the costs are:

for strategy 1: O(a log a + b log a); for strategy 2: O(a log a + b log b + a + b)... .

In a number of similar situations, it appears thus that, apart from the sizes of the tiles on which one operates (i.e., the number of records), a major determinant of efficiency is the cardinalities of the underlying sets, i.e., the number of distinct elements they comprise.

The situation gets much more complex when operations like projections, selections, multiple joins in combination with various boolean operations appear in queries. As an example, the relational system system R has a sophisticated query optimiser. In order to perform its task, that programme keeps several statistics on relations of the data base. The most important ones are the sizes of relations as well as the number of different elements of some key fields [8]. This information is used to determine the selectivity of attributes at any given time in order to decide the choice of keys and the choice of the appropriate algorithms to be employed when computing relational operators. The choices are made in order to minimise a certain cost function that depends on specific CPU and disk access costs as well as sizes and cardinalities of relations or fields. In system R, this information is periodically recomputed and kept in catalogues that are companions to the data base records and indexes.

In this paper, we propose efficient algorithms to estimate the cardinalities of multisets of data as are commonly encountered in data base practice. A trivial method consists in determining card(M) by building a list of all elements of M without replication; this method has the advantage of being exact but it has a cost in number of disk accesses and auxiliary storage (at least O(a) or O(a log a) if sorting is used) that might be higher than the possible gains which one can obtain using that information.

The method we propose here is probabilistic in nature since its result depends on the particular hashing function used and on the particular data on which it operates. It uses minimal extra storage in core and provides practically useful estimates on cardinalities of large collections of data. The accuracy is inversely related to the storage: using 64 binary words of typically 32 bits, we attain a typical accuracy of 10%; using 256 words, the accuracy improves to about 5 %. The performances do not degrade as files get large: with 32 bit words, one can safely count cardinalities well over 100 million. The only assumption made is that records can be hashed in a suitably pseudo-uniform manner. This does not however appear to be a severe limitation since empirical studies on large industrial files [S] reveal that careful implementations of standard hashing techniques do achieve practically uniformity of hashed values. Furthermore, by design, our algorithms are totally insensitive to the replication structures of files: as opposed to sampling techniques,'

<sup>&#</sup>x27; The simplest sampling algorithm is: take a sample of size No of a file of size N. Estimate the cardinality v,, of the sample using any direct algorithm and return vO(N/No) as estimate of the cardinality of the whole file.

the result will be the same whether elements appear a million times or just a few times.

From a more theoretical standpoint, these techniques constitute yet another illustration of the gains that may be achieved in many situations through the use of probabilistic methods. We mention here Morris' approximate counting algorithm [6] which maintains approximate counters with an expected constant relative accuracy using only

$$\log_2\log_2 n + O(1)$$

bits in order to count up to n. Morris' algorithm (see [2] for a detailed analysis that has analogies to the present paper) may be used to reduce by a factor of 2 the memory size necessary to store large statistics on a large number of events in computer systems.

The structure of the paper is as follows: in Section 2, we describe a basic counting procedure called COUNT that forms the basis of our algorithms. It may be worth noting that non-trivial analytic techniques enter the justification, and actually the design, of the algorithms; these techniques are also developed in Section 2. Section 3 presents the actual counting algorithms based on this COUNT procedure and on the probabilistic tools of Section 2. Finally, Section 4 concludes with several indications on contexts in which the methods may be used: most notably they can be employed on the fly as well as in the context of distributed processing with minimal exchanges of information between processors and without any degradation of performances. Preliminary results about this work have been reported in [3].

### 2. A PROBABILISTIC COUNTING PROCEDURE AND ITS ANALYSIS

The Basic Counting Procedure

We assume here that we have at our disposal a hashing function hash of the type:

function hash(x: records): scalar range 
$$[0 \cdots 2^{L} - 1]$$
,

that transforms records into integers sufficiently uniformly distributed over the scalar range or equivalently over the set of binary strings of length L. For y any non-negative integer, we define bit( y, k) to be the kth bit in the binary repesentation of y, so that

$$y = \sum_{k \ge 0} \operatorname{bit}(y, k) 2^{k}.$$

We also introduce the function p(y) that represents the position of the least significant l-bit in the binary representation of y, with a suitable convention for P(o):

$$\rho(y) = \min_{k \ge 0} \text{ bit}(y, k) \ne 0 \qquad \text{if} \quad y > 0$$
$$= L \qquad \text{if} \quad y = 0.$$

(Thus ranks are numbered starting from zero.)

We observe that if the values hash(x) are uniformly distributed, the pattern Ok1 ... appears with probability 2-k-'. The idea consists in recording observations on the occurrence of such pattrns in a vector BZTMAP[O . . . L - 11. If M is the multiset whose cardinality is sought, we perform the following operations:

```
for i :=0 to L- 1 do BZTMAP[i] :=O; 
for all x in A4 do 
       begin 
       index := p(hash(x)); 
      if BZ7'MAP[index] = 0 then BZZ'MAP[index] := 1; 
       end;
```

Thus BZTMAP[i] is equal to 1 iff after execution a pattern of the form 0'1 has appeared amongst hashed values of records in M. Notice that by construction, vector BITMAP only depends on the set of hashed values and not on the particular frequency with which such values may repeat themselves.

From the remarks concerning pattern probabilities, we should therefore expect, if n is the number of distinct elements in M that BZTMAP[O] is accessed approximately n/2 times, BZTMAP[ l] approximately n/4 times . . . . Thus at the end of an execution, BZTMAP[i] will almost certainly be zero if iglog, n and one if i<log, n with a fringe of zeros and ones for izlog, n. As an example, we took as A4 the on-line documentation corresponding to Volume 1 of the manual of the Unix system on one of our installations. M consists here of 26692 lines of which 16405 were distinct. Considering these lines as records and hashing them through standard multiplicative hashing over 24 bits (L = 24), we found the following BITMAP vector:

### 111111111111001100000000

The leftmost value zero appears in position 12 and the rightmost value one in position 15 while 2i4 = 16384.

We propose to use the position of the leftmost zero in BITMAP (ranks start at 0) as an indicator of log,n. Let R be this quantity, we shall see that under the assumption that hashed values are uniformly distributed, the expected value of R is close to:

$$\mathbf{E}(R) \approx \log_2 \varphi n, \qquad \varphi = 0.77351 \cdots \tag{1}$$

so that our intuition is justified. In fact the "correction factor" cp plays quite an important role in the design of the final algorithms we propose here. We shall also

prove that under reasonable probabilistic assumptions, the standard deviation of R is close to

$$\sigma(R) \approx 1.12 \tag{2}$$

so that an estimate based on (1) will typically be one binary order of magnitude off the exact result, a fact that calls for more elaborate algorithms to be developed in Section 3.

### Probability Distributions

We now proceed to justify rigorously the above claims (1) and (2) concerning the distribution of the value of parameter R in the basic counting procedure.

PROBABILISTIC MODEL. We let B denote the set of infinite binary strings. The model assumes that bits of elements of B are uniformly and independently distributed. Equivalently strings can be considered as real numbers over the interval [O; 11, and the model assumes that the numbers are uniformly distributed over the interval. Functions bit and p are extended to B trivially. We denote by R, the random variable defined over B" (assuming independence) that is, the analogue of the parameter R above:

$$R_n(x_1, x_2,..., x_n) = r$$
 iff (i) for all  $0 \le j < r$  there is an i such that  $\rho(x_i) = j$  and (ii) for all  $i \ \rho(x_i) \ne r$ .

We also introduce the following notations concerning the probability distribution of R, under the uniform model:

$$p_{n,k} = \Pr(R_n = k); \qquad q_{n,k} = \Pr(R_n \ge k)$$

$$\bar{R}_n = \mathbf{E}(R_n) = \sum_{k \ge 0} k p_{n,k}$$

$$\sigma_n^2 = \mathbf{E}((R_n - \bar{R}_n)^2) = \sum_{k \ge 0} k^2 p_{n,k} - \bar{R}_n^2,$$

and we let v(n) denote the number of ones in the binary representation of n, so that for instance v(13)= v((llOl),)= 3. We have

THEOREM 1. The probability distribution of R, is characterised by:

$$q_{n,k} = \sum_{j=0}^{2^k} (-1)^{v(j)} \left(1 - \frac{j}{2^k}\right)^n.$$

Proof: For each integer k > 0, we define the following events (i.e., subsets of B):

$$E_k = \{x \mid \rho(x) = k\}; \qquad K_k = \{x \mid \rho(x) \ge k\}.$$

Thus, for each k, E,,, E, ,..., Eke,, Kk form a disjoint and complete set of events. When n elements are drawn from B, the formal polynomial:

$$P_k^{(n)} = (E_0 + E_1 + \dots + E_{k-1} + K_k)^n$$
(3)

represents the set of all possible events in the following sense: if we expand (3) taken as a non-commutative polynomial in its indeterminates, interpreting the sums as (disjoint) unions of events and the products as successions of events (each monomial has degree n), we obtain a complete and disjoint representation of B".

We are interested in obtaining from Pf) an expression for the polynomial Qr) that represents in a similar fashion the succession of all events corresponding to R, 2 k. Polynomial Qf) is formed by a subset of the noncommutative monomials appearing in Pp).

Let us start with a few examples. If k = 0, we have: Pg' = (K,)" and Qg) = Pl;). If k= 1,

$$P_1^{(n)} = (E_0 + K_1)^n, Q_1^{(n)} = (E_0 + K_1)^n - K_1^n,$$

since Q is obtained from P is this case by taking out from P the monomial K; corresponding to the situation where all strings drawn have a p-value at least 1. For k = 2 now, we have

$$Q_2^{(n)} = (E_0 + E_1 + K_2)^n - (E_1 + K_2)^n - (E_0 + K_2)^n + K_2^n$$

since we have to take out from P the cases where either p-value 1 or p-value 0 does not appear but in so doing, we have eliminated the case where all p-values are at least 2 (i.e., K2) twice.

In general, for P a polynomial in the indeterminates E,, E2,..., the polynomial Q formed with monomials of degree at most 1 in each of the indeterminates E, can be obtained from P by the inclusion-exclusion type formula:

$$Q = P - \sum_{i} P[E_i \to 0] + \sum_{i \neq j} P[E_i, E_j \to 0] - \sum_{i \neq j \neq k} P[E_i, E_j, E_k \to 0] + \cdots, \quad (4)$$

where the notation P[x, y + 0] means the replacement of x, y by 0 in P. Thus Q!/) can in general be obtained by applying (4) to the expression of Pf) given by (3).

To evaluate the probabilities qn,k, all we have to do is to take the measures ~1 of the events described by polynomial Q using the rules:

$$\mu(E_j) = \frac{1}{2^{j+1}}; \qquad \mu(K_k) = \frac{1}{2^k},$$

using additivity of measure ,U over disjoint sets of events as well as the relation p(A. B) = p(A) \* p(B) since trials in B are assumed to be independent. On our pevious examples, we find in this way:

$$q_{n,0} = 1;$$
  $q_{n,1} = 1 - (\frac{1}{2})^n;$   $q_{n,2} = 1 - (\frac{3}{4})^n - (\frac{1}{2})^n + (\frac{1}{4})^n,$ 

and in general:

$$q_{n,k} = 1 + \xi_1 + \xi_2 + \xi_3 + \cdots$$
 (5)

where

$$\xi_t = (-1)^t \sum_{i=1}^t \left(1 - \frac{1}{2^{i_1}} - \frac{1}{2^{i_2}} - \cdots - \frac{1}{2^{i_t}}\right),$$

and the sum extends to all t-tuples of integers i i, iz,..., of distinct integers in the interval [ l... k]. Notice that by changing the summation indexes to Z, = k - i,, 5, can be rewritten as:

$$\xi_t = (-1)^t \sum \left( 1 - \frac{2^{t_1} + 2^{t_2} + \cdots + 2^{t_t}}{2^k} \right)'$$

where now the lJ are distinct integers over the interval [0 . . . k - 11. In other words, we have shown that

$$\xi_{t} = (-1)^{t} \sum_{\substack{v(j) = t \\ j \le 2^{k}}} \left(1 - \frac{j}{2^{k}}\right)^{n}.$$
 (6)

Using (6) inside (5) completes the proof of the theorem. m

We now turn to the derivation of asymptotic forms for these probabilities.

THEOREM 2. The distribution of R, satisfies the following estimates:

(i) Ifk<log,n-2log,logn, then

$$q_{n,k}=1-O(ne^{-\log^2 n});$$

(ii) rf k < 3 log, n, then

$$q_{n,k} = \prod_{j=0}^{\infty} (1 - e^{-2j(n/2^k)}) + O\left(\frac{\log^6 n}{\sqrt{n}}\right)$$
$$= \sum_{j \ge 0} \left[ (-1)^{\nu(j)} e^{-jn/2^k} \right] + O\left(\frac{\log^6 n}{\sqrt{n}}\right);$$

(iii) If k > \$ log, n + 6, with 6 > 0, the tail of the distribution is exponential:

$$q_{n,k} = O\left(\frac{2^{-\delta}}{\sqrt{n}}\right).$$

Proof. The main device here consists in using repeatedly the exponential approximation:

$$(1-a)^n \approx e^{-na}$$
.

inside the terms that form the expression of qn,k:

$$q_{n,k} = \sum_{j=0}^{2^k} (-1)^{\nu(j)} \left(1 - \frac{j}{2^k}\right)^n.$$
 (7)

We set

$$t(j, n, k) = \left(1 - \frac{j}{2^k}\right)^n$$
:

(i) The case when k 6 log, n - 2 log, log n. Pulling out the 1 corresponding to the first term (j= 0) in (7), and noticing that, as j increases, the terms t(j, n, k) decrease, we find

$$1 - q_{n,k} \leqslant 2^k \left(1 - \frac{1}{2^k}\right)^n.$$

Since 2k < n/log2 n, we have log( 1 - l/2k)-' > log2 n/n, and the above inequality becomes

$$1 - q_{n,k} \leqslant ne^{-\log^2 n},$$

as was to be established.

(ii) The case when k < 2 log, n. We set here c(n) = log' n/n. When j > .c(n)2k, for k in the given range, t(j, n, k) is O(e-'"gZ"); since there are less than 2k such terms, and 2k = O(n3'\*), we get

$$q_{n,k} = \sum_{j < e(n)2^k} (-1)^{\nu(j)} t(j, n, k) + O(n^{3/2} e^{-\log^2 n}).$$
 (8)

We let qi,& denote the sum that appears in (8), and we define similarly

$$q''_{n,k} = \sum_{j < \varepsilon(n)2^k} (-1)^{\nu(j)} e^{-nj/2^k}.$$

For j < .s-(n)2k, we have

$$|t(j, n, k) - e^{-nj/2^{k}}| = O(e^{-nj/2^{k}}(e^{O(-nj^{2}/2^{2^{k}})} - 1))$$
  
=  $O(n\varepsilon^{2}(n))$ .

so that, since q' and q" comprise 2ke(n) terms,

$$|q'_{n,k} - q''_{n,k}| = O(n2^k \varepsilon^3(n)),$$
 (9)

a quantity which is O(log6 n/G). T o d erive the final expression, all we have to do is to "complete the sum" in qz,&; we set

$$q_{n,k}'' = \sum_{k \ge 0} (-1)^{\nu(j)} e^{-nj/2^k} + E$$
 (10)

where the error term E satisfies

$$|E| < \sum_{j > \varepsilon(n)2^k} e^{-nj/2^k}$$

$$= O\left(\frac{e^{-n\varepsilon(n)}}{1 - e^{-n/2^k}}\right) = O\left(\frac{2^k}{n}e^{-\log^2 n}\right) = O(n^{1/2}e^{-\log^2 n}). \tag{11}$$

Combining Eqs. (8), (9), (lo), (11) therefore establishes the sum expression that appears in claim (ii) of the statement. To derive the product form, we appeal to the general identity

$$\sum_{j \ge 0} (-1)^{\nu(j)} q^j \equiv \prod_{m \ge 0} (1 - q^{2^m}).$$

(iii) The case when k = \$ log, n + 6. We bound the probabilities qn.k by observing that since the p-value k - 1 is taken at least once:

$$\Pr(R_n \ge k) \le 1 - (1 - 1/2^k)^n, < 1 - \exp(-2 \cdot n/2^k).$$
 (12)

In the range of values of k considered, the last expression is O(n/2k), which is itself of order 0(2-"/J); thus the proof of part (iii) is now completed. 1

For the sequel we introduce the real function:

$$\psi(x) = \prod_{j \ge 0} (1 - e^{-x2^j}) = \sum_{j \ge 0} (-1)^{\nu(j)} \exp(-jx).$$
 (13)

Thus Theorem 2 expresses essentially the existence of a sort of limiting distribution for the probability distribution of R,, as n gets large:

$$q_{n,k} \approx \psi\left(\frac{n}{2^k}\right); \qquad p_{n,k} \approx \psi\left(\frac{n}{2^k}\right) - \psi\left(\frac{n}{2^{k+1}}\right).$$
 (14)

Table I describes the values of the probabilities compared to the approximation given by (14). It shows excellent agreement between the qn,ls and their approximations. It also reveals that the tail decreases sharply (actually a decrease faster than that of Theorem 2 may be established).

Asymptotic Analysis

From Theorem 2 follows that

LEMMA 1. The expectation 8, of R, satisfies

$$\bar{R}_n = \sum_{k \ge 1} k \left[ \psi\left(\frac{n}{2^k}\right) - \psi\left(\frac{n}{2^{k+1}}\right) \right] + O\left(\frac{1}{n^{0.49}}\right), \tag{15}$$

|       | k=4      | k=5    | k=6    | k=l      | k=8      | k=9      | k=lO   | k=ll     |
|-------|----------|--------|--------|----------|----------|----------|--------|----------|
| loo   | 0.0019   | 0.0439 | 0.200  | 0.3452   | 0.2767   | 0.1088   | 0.0212 | 0.0020   |
|       | 0.0016   | 0.0417 | 0.1985 | 0.3476   | 0.2789   | 0.1087   | 0.0209 | 0.0020   |
|       | k=7      | k=8    | k=9    | k=<br>10 | k=ll     | k=<br>12 | k=l3   | k=<br>14 |
| loo0  | o.ooo4   | 0.0201 | 0.1389 | 0.3166   | 0.3216   | 0.1586   | 0.0388 | 0.0047   |
|       | 0.0004   | 0.0200 | 0.1387 | 0.3167   | 0.3219   | 0.1586   | 0.0388 | 0.0047   |
|       | k=<br>10 | k=ll   | k=l2   | k=<br>13 | k=<br>14 | k=l5     | k=l6   | k=<br>17 |
| loo00 | O.oool   | 0.0076 | 0.0863 | 0.2673   | 0.3469   | 0.2150   | 0.0659 | 0.0101   |
|       | 0.0001   | 0.0076 | 0.0863 | 0.2673   | 0.3469   | 0.2150   | 0.0659 | 0.0101   |

TABLE I Values of Exact Probabilities (qn,J and of the Approximations (9) (in Italics)

Note. n= 100~2~@, n= 1000~9~'~, and n= lOC~00~2'~'~.

Thus the problem of estimating R,, asymptotically reduces to that of estimating the sum in (15), i.e., the function

$$F(x) = \sum_{k \ge 1} k \left[ \psi\left(\frac{x}{2^k}\right) - \psi\left(\frac{x}{2^{k+1}}\right) \right],\tag{16}$$

for large x. To that purpose we appeal to Mellin transform techniques whose introduction in the context of analysis of algorithms is due to De Bruijn (see [4, pp. 131 et seq.]). The Mellin transform of a function f(x) defined for x > 0, x real, is by definition the complex functionJ\*(s) given by

$$f^*(s) \equiv M[f(x); s] = \int_0^\infty f(x) \, x^{s-1} \, dx. \tag{17}$$

We succinctly recall the salient properties of the Mellin transform, referring the reader to [ I] for precise statements. The Mellin transform of a function f is defined in a strip of the complex plane that is determined by the asymptotic behaviours off at 0 and co. It satisfies the important functional property

$$M[f(ax); s] = a^{-s}f^*(s).$$
 (18)

Finally there is a complex inversion formula

$$f(x) = \frac{1}{2i\pi} \int_{c-i\infty}^{c+i\infty} f^{*}(s) x^{-s} ds$$
 (19)

where c is chosen in the strip where the integral in (17) is absolutely convergent.

The interest of the inversion formula is that, in many cases, it can be evaluated by means of the residue theorem, each residue corresponding to a term in the asymptotic expansion of J:

LEMMA 2. The Mellin transform qf F(x) is for - 1 < Re(s) < 0:

$$F^*(s) = \frac{2^s}{1 - 2^s} N(s) \Gamma(s),$$

where T(s) is the Euler Gamma function and N(s) is an entire function that is the analytic continuation of the function defined for Re(s) > 1 by

$$N(s) = \sum_{j \ge 1} \frac{(-1)^{\nu(j)}}{j^s}.$$

Proof Let I+!J~(x)z \$(x)- 1. The transform of \$1 is for Re(s)> 1:

$$\psi_1^*(s) = \sum_{j \ge 1} (-1)^{\nu(j)} j^{-s} \Gamma(s)$$
  
=  $N(s) \Gamma(s)$ , (20)

as follows from the basic functional property (18), and the fact that the transform of exp( -x) is the Gamma function T(s). Similarly, for \$\*(x) = Ii/(x) -+(x/2) and Re(s) > 1, we get

$$\psi_2^*(s) = M[\psi(x) - \psi(x/2); s] = \psi_1^*(s)(1 - 2^s). \tag{21}$$

Since t&c) - \$(x/2) is exponentially small both at 0 and co, the transform +: is actually analytic for all complex s; since:

$$N(s) = \frac{\psi_2^*(s)}{\Gamma(s)(1-2^s)}.$$
 (22)

we find that N(s) is analytic for all s except possibly for the points s = 2ikn/log 2, where the denominator of (22) vanishes. However, direct calculations in Lemma 3 below show that N(s) is analytic for Re(s) > -1, so that N(s) is analytic everywhere.

Now, using again the basic functional property,

$$F^*(s) = \psi_2^*(s) \sum_{k \ge 1} k 2^{ks}$$

$$= \psi_2^*(s) \frac{2^s}{(1 - 2^s)^2},$$
(23)

where (23) is valid for Re(s)<O. Putting together (20), (21), (22), (23) establishes the claim of the lemma.

We now need to establish some more constructive properties of N(s) for Re(s) < 0, establishing in passing the analytic continuation property of N(s) used in the proof of Lemma 2.

LEMMA 3. The function N(s) satisfies N(0) = -1. Furthermore, for s = o + it and c7 > -0.99, it satisfies

$$N(s) = O(1 + |s|^3).$$

Proof Terms in the definition of N(s) may be grouped 4 by 4; using the property

$$v(4j) = v(j); v(4j+1) = v(4j+2) = 1 + v(j); v(4j+3) = 2 + v(j),$$

we find

$$N(s) = -1^{-s} - 2^{-s} + 3^{-s} + \sum_{j \ge 1} \frac{(-1)^{\nu(j)}}{(4j)^s} \left[ 1 - \frac{1}{\left(1 + \frac{1}{4j}\right)^s} - \frac{1}{\left(1 + \frac{2}{4j}\right)^s} + \frac{1}{\left(1 + \frac{3}{4j}\right)^s} \right]. \tag{24}$$

We observe that the general term in the above sum is 0(jj-2) as j gets large. This confirms that N(s) is defined and analytic when c > - 1. To obtain the bounds on N(s), we split the sum (24): the terms such that j< IsI\* contribute at most O(1 + Is]") to the sum; and since

$$1 - (1+u)^{-s} - (1+2u)^{-s} + (1+3u)^{-s} = O(|s|^2u^2)$$

uniformly in s and u when u < l/Is/ 2, we find that the contribution of terms such that j> (s[\* is

$$O(|s|^2 \sum_{j>|s|^2} j^{-\sigma-2}) = O(|s|^2),$$

uniformly in s when c > -0.99, say. Finally substituting s= 0 in (24) gives N(O)= -1. 1

We can now come back to the asymptotic study of F(x) and hence of 8, using the inversion formula (19).

THEOREM 3.A. The average value of parameter R, satisfies:

$$\overline{R}_n = \log_2(\varphi n) + P(\log_2 n) + o(1),$$

where constant cp = 0.77351 . . . is given by

$$\varphi = 2^{-1/2} e^{\gamma} \frac{2}{3} \prod_{p=1}^{\infty} \left[ \frac{(4p+1)(4p+2)}{(4p)(4p+3)} \right]^{(-1)^{\nu(p)}}$$

and P(u) is a periodic and continuous functions of u with period 1 and amplitude bounded by  $10^{-5}$ .

*Proof.* By Lemma 1, the problem reduces to obtaining an asymptotic expansion of F(x) as  $x \to \infty$  up to o(1) terms. The principle consists in evaluating the complex integral of the form (19) by residues. From the inversion theorem for Mellin transforms, we have

$$F(x) = \frac{1}{2i\pi} \int_{-1/2 + i\infty}^{-1/2 + i\infty} F^*(s) x^{-s} ds.$$
 (25)

We consider for k a positive integer the rectangle contour  $\Gamma_k$  defined by its corner points (and traversed in that order)

$$\Gamma_k = [-1/2 - i(2k+1) \pi/\log 2; -1/2 + i(2k+1) \pi/\log 2; 1 - i(2k+1)\pi/\log 2; 1 + i(2k+1)\pi/\log 2].$$

By Cauchy's residue theorem, we have

$$\frac{1}{2i\pi} \int_{\Gamma_k} F^*(s) \, x^{-s} \, ds = -\sum_{s \, in \, \Gamma_k} \text{Res}(F^*(s) x^{-s}).$$

For fixed x, as k gets large, the integral along the segment  $[-1/2-i(2k+1)\pi/\log 2; -1/2+i(2k+1)\pi/\log 2]$  tends to F(x) by (25). From Lemma 3 and the exponential decrease of  $\Gamma(s)$  towards  $i\infty$ , the integrals along  $[-1/2+i(2k+1)\pi/\log 2; 1-i(2k+1)\pi/\log 2]$  and  $[1+i(2k+1)\pi/\log 2; -1/2-i(2k+1)\pi/\log 2]$  tend to zero exponentially fast (as functions of m). As to the integral along  $[1-i(2k+1)\pi/\log 2; 1+i(2k+1)\pi/\log 2]$ , it stays bounded in absolute value by

$$\frac{1}{2\pi} \int_{-\infty}^{+\infty} |F^*(1+it)| \ x^{-1} \ dt < \frac{K}{x},$$

for some constant K. (Again the exponential decrease of  $\Gamma(s)$  guarantees convergence of the above integral.) We have thus found that, by letting  $m \to \infty$ :

$$F(x) = -\sum_{\text{Re}(s) = 0} \text{Res}(F^*(s)x^{-s}) + O\left(\frac{1}{x}\right).$$
 (26)

(The sum of residues is also absolutely convergent because of the decrease of  $\Gamma(s)$  towards  $i\infty$ .) It only remains to evaluate the residues in (26).  $F^*(s)$  has a double pole at s=0 and simple poles at each  $\chi_k = 2ik\pi/\log 2$ , with k an integer different from 0, and we find easily

$$-\operatorname{Res}(F^*(s)x^{-s}; s=0) = \log_2 x + \frac{\gamma}{\log 2} + \frac{N'(0)}{\log 2} - \frac{1}{2},$$

which we may rewrite as log, cpx, and

$$-\operatorname{Res}(F^*(s) \ x^{-s}; s = \chi_k) = (1/\log 2) \ \Gamma(\chi_k) \ N(\chi_k) \ x^{-\chi_k},$$

which is of the form pk e~Ziknlogzx.

Thus summing the residues, and using (26), we find the announced asymptotic form for F(x) (and hence Rll), with P(u) given by

$$P(u) = \sum_{k \in \mathbb{Z}/\{0\}} p_k e^{-2ik\pi u}$$

The gory details of the bound on the amplitude of P(u) are left for the Appendix. 1

We can evaluate the standard deviation of R, in a similar fashion. Let S, be the second moment of R, : S, = E(Rz). As before, S, is approximated by the function G(n) where

$$G(x) = \sum_{k \ge 1} k^2 \left[ \psi\left(\frac{x}{2^k}\right) - \psi\left(\frac{x}{2^{k+1}}\right) \right],$$

whose transform is found to be for Re(s) < 0

$$G^*(s) = \frac{2^s(1+2^s)}{(1-2^s)^2} \Gamma(s) N(s),$$

which now has a triple pole at s = 0. Computing G(z) is done from G\*(s) via the inversion theorem followed by residue calculations, and one finds:

THEOREM 3.B. The standard deviation of R, satisfies

$$\sigma_n^2 = \sigma_\infty^2 + Q(\log_2 n) + o(1),$$

where (T o. = 1.12127... and Q(u) is a periodic function with mean value 0 and period 1.

We can mention in passing for crm the "closed form" expression

$$\sigma_{\infty}^2 = \frac{1}{12(\log 2)^2} \left[ 2\pi + \log 2 - 12N'(0) - 12N''(0) \right] - 2\sum_{k>0} |p_k|^2,$$

where the pk are the Fourier coefficients of P(u) defined above.

## 3. PROBABILISTIC COUNTING ALGORITHMS

We have seen in the previous section that the result R of the COUNT procedure has an average close to log, cpn, with a standard deviation close to 1.12. Actually the values of

$$\lambda(n) = (1/\varphi)2^{R_n}$$

are amazingly close to n as the following instances show:

$$\lambda(10) = 10.502;$$
  $\lambda(100) = 100.4997;$   $\lambda(1000) = 1000.502.$ 

This observation justifies the hope of obtaining very good estimates on n from the observation of parameter R, using the correction factor cp. However, the dispersion of results corresponds to a typical error of 1 binary order of magnitude which is certainly too high for many applications.

The simplest idea to remedy this situation consists in using a set H of m hashing functions, where m is a design parameter and computing m different BITMAP vectors. In this way, we obtain m estimates R(l), R<\*),..., R'"'. One then considers the average

$$A = \frac{R^{\langle 1 \rangle} + R^{\langle 2 \rangle} + \dots + R^{\langle m \rangle}}{m}.$$
 (27)

When n distinct elements are present in the file, the random variable A has expectation and standard deviation that satisfy

$$\mathbf{E}(A) \approx \log_2 \varphi n; \qquad \sigma(A) \approx \sigma_{\infty} / \sqrt{m}.$$

Thus we may expect 2A to provide an estimate of n with a typical error (measured by the standard deviation of the estimates) of relative value z K/h.

Such an algorithm using direct averaging has indeed provably good performances (with an expected relative error of about 10 % if m = 64) but it has the disadvantage of requiring the calculation of a number of hashing functions, so that the CPU cost per element scanned gets essentially multiplied by a factor of m.

It turns out that an effect very similar to straight averaging may be achieved by a device that we call stochastic averaging. The idea consists in using the hashing function in order to distribute each record into one of m lots, computing LY = h(x) mod m. We update only the corresponding BITMAP vector of address c1 with the "rest" of the information contained in h(x), namely h(x) div m = Lh(x)/m]. At the end, we determine as before the R(j)' s and compute their average A by (27). Hoping for the distirbution of records into lots to be even enough, we may thus expect that about n/m elements fall into each lot so that (1/~)2~ should be a reasonable approximation of n/m.

The corresponding algorithm is called Probabilistic Counting with Stochastic Averaging, or PCSA for short. It is described in Fig. 1. We claim that its cost per element scanned is handly distinguishable from that of the COUNT procedure and its relative accuracy improves with m roughly as 0.78/& In the sequel, we shall call standard error the quotient of the standard deviation of an estimate of n by the value of n; this quantity is thus a precise indication of the expected relative accuracy of an algorithm estimating n. Neglecting periodic fluctuations of extremely small amplitude (less than lo-'), we shall call the bias of an algorithm the ratio between the estimate of n and the exact values of n for large n. Standard error and bias of

```
program PCSA;
const nmap = 64; {with nmap = 64, accuracy is typically 10%}
   [nmap corresponds to variable m in the analysis]
   \varphi = 0.77351 {the magic constant}; maxlength = 32;
   {with maxlength =32 (==L), one can count up to 10^8.}
var M: multiset of data of type records;
      x: records; hashedx, index, a, R, S, E: integer;
      BITMAPS: array [0..nmap-1;0.maxlength-1] of integer;
function getelement(var x.records);
{reads an element x of type records from file M}
function hash (x records) integer;
{hashes a record x into an integer over scalar range [0..2^{maxlength}-1]}
function \rho(y integer) integer;
{returns the position of the first 1-bit in y; ranks start at 0.}
begin
while not eof(M) do
    begin
    getelement(x), hashedx = hash(x);
    a:=hashedx mod nmap; index:=ρ(hashedx div nmap);
    if BITMAP[a,index]=0 then BITMAP[a,index]:=1;
    end:
S = 0;
for i:=0 to nmap-1 do
    R:=0; while (BITMAP[i,R]=1) and (R<maxlength) do R:=R+1; S:=S+R;
    end;
\Xi:=\operatorname{trunc}(nmap/\varphi ^{*2} * (S/nmap));
[Result \Xi of the PCSA programme that estimates n]
end.
```

Fig. 1. Probabilistic counting with stochastic averaging (PCSA).

TABLE II

Bias and Standard Error of PCSA for Several Values of 
m, the Number of BITMAP Vectors Used

| m    | Bias   | % Standard error |
|------|--------|------------------|
| 2    | 1.1662 | 61.0             |
| 4    | 1.0792 | 40.9             |
| 8    | 1.0386 | 28.2             |
| 16   | 1.0191 | 19.6             |
| 32   | 1.0095 | 13.8             |
| 64   | 1.0047 | 9.7              |
| 128  | 1.0023 | 6.8              |
| 256  | 1.0011 | 4.8              |
| 512  | 1.0005 | 3.4              |
| 1024 | 1.0003 | 2.4              |

algorithm PCSA for various values of the design parameter m are displayed in Table II.

In the remainder of this section, we are going to justify these claims rigorously and in particular show how the estimates of Table II are deduced.

We let Z denote the random variable computed by PCSA with m BITMAPS and let 3, denote this random variable when n distinct elements are present in the file; we denote by E[Z",] the average value of ED and cr(Z:,) the standard deviation of E-,. We propose to establish:

THEOREM 4. The estimate Z-, of algorithm PCSA has average value that satisfies':

$$\mathbb{E}[\Xi_n] = \frac{n}{\varphi} \left[ \frac{1}{\log 2} N\left(-\frac{1}{m}\right) \Gamma\left(-\frac{1}{m}\right) (1 - 2^{-1/m}) \right]^m + n P_m(\log_2 n) + o(n).$$

the second moment of Z,, satisfies

$$\mathbb{E}[\Xi_n^2] = \frac{n^2}{\varphi^2} \left[ \frac{1}{\log 2} N \left( -\frac{2}{m} \right) \Gamma \left( -\frac{2}{m} \right) (1 - 2^{-2/m}) \right]^m + n^2 Q_m(\log_2 n) + o(n^2)$$

In the above expressions P, and Q,,, represent periodic functions with period 1, mean value 0 and amplitude bounded by 10 ~- '.

THEOREM 5. Using the notation u(n) E v(n) to express the property

$$\exists n_0 \ \forall n > n_0 \ |u(n) - v(n)| < 10^{-5}$$

one has the following characterisations of the bias and standard error of algorithm PCSA :

$$\frac{\mathbb{E}[\Xi_n]}{n} \simeq (1 + \varepsilon(m))$$

$$\frac{\sigma[\Xi_n]}{n} \simeq \eta(m),$$

where quantities E(m) and g(m) satisfy as m gets large:

$$\varepsilon(m) \sim \lambda/2m$$

$$n(m) \sim \lambda^{1/2} / \sqrt{m},$$

where

$$\lambda = \frac{\pi^2}{12} - \frac{\gamma^2}{2} - N'(0)^2 - N''(0) + \frac{\log^2 2}{12}.$$

<sup>&#</sup>x27; The error terms in Theorem 4 and the n, in Theorem 5 are not uniform in tn.

The Analysis of Algorithm PCSA

We now proceed with the proof of Theorem 4. We start with an estimate of E[j""] for 1 </I 6 2 that is needed throughout the rest of this section and prove

LEMMA 4. Setting fl= 2l1'7, with q > 1, one has for fixed q

$$\mathbf{E}[\beta^{R_n}] = n^{1/q}(d_q + P_q(\log_2 n)) + o(n^{1/q}),$$

$$d_q = -\frac{1}{\log 2} (1 - 2^{-1/q}) N\left(-\frac{1}{q}\right) \Gamma\left(-\frac{1}{q}\right)$$

and P, is a periodic function of amplitude less than 10p5.

Proof: (i) We start with a strenghening of bounds on the tail of the distribution of R,. Consider the probability Pr[R, > k] where k = ilog, n + 6, with 6 > 0. When R, > k, positions (k- 1) and (k - 2) of BITMAP are set to 1, an event that has probability

$$1 - \left(1 - \frac{1}{2^k}\right)^n - \left(1 - \frac{1}{2^{k-1}}\right)^n + \left(1 - \frac{1}{2^k} - \frac{1}{2^{k-1}}\right)^n$$

a quantity which is

$$1 - e^{-n/2^k} + O(n/2^{2k}) - e^{-n/2^{k-1}} + O(n/2^{2k}) + e^{-3n/2^{k-1}} + O(n/2^{2k})$$

or O(n/22k), which in the given range of values of k is O(n-3'24--5). Thus

$$\sum_{k>(5/4)\log_2 n} 2^k p_{n,k} = O\left(n^{5/4-3/2} \sum_{\delta \ge 0} 4^{-\delta} 2^{\delta}\right) = O(n^{-1/4}), \tag{28}$$

and the same bound applies if 2 is replaced by b in the above sum.

We now consider the error that comes from the replacement of the pn,k by their asymptotic equivalent for "small" k. From the bounds of Theorem 2, one finds

$$\sum_{k \le (5/4)\log_2 n} \beta^k \left[ p_{n,k} - \psi\left(\frac{n}{2^k}\right) + \psi\left(\frac{n}{2^{k+1}}\right) \right] = O\left(\frac{n^{5/4q}}{n^{0.49}}\right) = O(n^{0.76/q}), \tag{29}$$

a quantity which is <n 'lq . Thus completing the sum and defining the function

$$H(x) = \sum_{k > 1} \beta^{k} \left[ \psi \left( \frac{x}{2^{k}} \right) - \psi \left( \frac{x}{2^{k+1}} \right) \right],$$

we have from (28), (29):

$$\mathbb{E}[\beta^{R_n}] = H(n) + O(n^{0.76/q}).$$

The asymptotic behaviour of H is determined by Mellin transform techniques as before; the transform of function H is

$$H^*(s) = \frac{\beta 2^s}{1 - \beta 2^s} \Gamma(s) N(s).$$

H\* has poles at s = -l/q + 2&/log 2 and we find the claim of the lemma, using the inversion theorem with

$$d_q = -\operatorname{Res}(H^*(s); s = -1/q). \quad \blacksquare$$

The next step in the proof of Theorem 4 is to establish that algorithm PCSA behaves asymptotically as though the n elements were perfectly distributed in m groups.

LEMMA 5. If n elements are distributed into m cells (m fixed), where the probability that any element goes to a given cell has probability l/m, then the probability that at least one of the cells has a number of elements N satisfying

$$|N - n/m| > \sqrt{n} \log n$$

is O(e- h'og2n) for some constant h > 0.

Proof Set p = l/m, q = 1 - l/m; let N, be the number of elements that fall into cell 1. N, obeys a binomial distribution

$$\Pr(N_1 = k) = \binom{n}{k} p^k q^{n-k},\tag{30}$$

and taking logarithms of (30), for k = pn + 6 and 6 4 n, one finds

$$\Pr(N_1 = pn + \delta) = \exp\left(-\frac{\delta^2 + O(\delta)}{2npq} + O\left(\frac{\delta^3}{n^2}\right)\right).$$

If 6 = & log n, the probability (30) is exponentially small. We conclude the proof by observing that the binomial distribution is unimodal and

$$\Pr\left[\bigcup_{1 \le i \le m} \left| N_i - \frac{n}{m} \right| > \sqrt{n} \log n \right] < m \Pr\left[\left| N_1 - \frac{n}{m} \right| > \sqrt{n} \log n \right]. \quad \blacksquare$$

We can now conclude the proof of the first part of Theorem 4. Let S denote the sum R<'> + RC2) + ... + R<">. We have

$$\Pr(S=k) = \sum_{\substack{n_1+n_2+\cdots+n_m=n\\k_1+k_2+\cdots+k_m=k}} \frac{1}{m^n} \binom{n}{n_1, n_2, \dots, n_m} p_{n_1, k_1} p_{n_2, k_2} \cdots p_{n_m, k_m}.$$
(31)

Thus

$$\mathbf{E}(2^{S/m}) = \sum_{n_1 + n_2 + \dots + n_m = n} \frac{1}{m^n} \binom{n}{n_1, n_2, \dots, n_m} \mathbf{E}(2^{R_{n_1}/m}) \mathbf{E}(2^{R_{n_2}/m}) \cdots \mathbf{E}(2^{R_{n_m}/m}).$$
(32)

Call E the quantity (32) and E, the sum of the terms in (32) such that for all j, 1 <j< m:

$$\left| n_j - \frac{n}{m} \right| < \sqrt{n} \log n$$

From Lemmas 4,5, E-E, is O(ne- "'g2"). As to the central contribution EC it is bounded by

$$(\mathbf{E}[2^{(1/m)R_{n/m}-\sqrt{n}\log n}])^m < E_C < (\mathbf{E}[2^{(1/m)R_{n/m}+\sqrt{n}\log n}])^m,$$

so that finally

$$\mathbf{E}[2^{S/m}] = (\mathbf{E}[2^{(1/m)R_{n/m}}])^m + o(n). \tag{33}$$

or

$$\mathbf{E}(\boldsymbol{\Xi}_n) = \frac{m}{\omega} \left( \mathbf{E} \left[ 2^{(1/m)R_{n/m}} \right] \right)^m + o(n). \tag{34}$$

Equation (34) combined with Lemma 5 is sufficient to establish the estimates on .Yn from Theorem 4, provided we check that the amplitudes of the periodic fluctuations do not grow with m, a fact that can be proved using the methods described in the Appendix.

Estimates on the second moment of Sn are derived in exactly the same way through the equality

$$\mathbf{E}(\Xi_n^2) = \frac{m^2}{\varphi^2} \left( E[2^{(2/m)R_{n/m}}] \right)^m + o(n^2). \tag{35}$$

Dependence of Results on the Number of BITMAPS

We finally conclude with an indication of the (easy) proof of Theorem 5. From Theorem 4, all we need is to determine the asymptotic behaviour of the quantities

$$\alpha(m) = \frac{1}{\varphi} \left[ \frac{1}{\log 2} N \left( -\frac{1}{m} \right) \Gamma \left( -\frac{1}{m} \right) (1 - 2^{-1/m}) \right]^m, \tag{36}$$

$$\beta(m) = \frac{1}{\varphi^2} \left[ \frac{2}{\log 2} N \left( -\frac{2}{m} \right) \Gamma \left( -\frac{2}{m} \right) (2 - 2^{-2/m}) \right]^m, \tag{37}$$

$$\gamma(m) = (\beta(m) - \alpha^2(m))^{1/2}, \tag{38}$$

as m gets large since we neglect the effect of the small periodic fluctuations. This is achieved by performing standard (but tedious) asymptotic expansions of (36), (37), (38) for large m. (This task as been carried out with the help of the MACSYMA system for symbolic computations.) We find that the bias and standard error are for all values of m closely approximated by the formulae

bias: 
$$1 + 0.31/m$$
 (39)

standard error: 
$$0.78/\sqrt{m}$$
. (40)

#### 4. IMPLEMENTATION ISSUES

There are three factors to be taken into account when applying algorithm PCSA:

- (i) The choice of the hashing function.
- (ii) The choice of the length of the BITMAP-vectors, L.
- (iii) The number, nmap, of BITMAP used (corresponding to quantity m in our analyses).

Also corrections of two types may be introduced:

- (iv) Corrections to the systematic bias of Table II.
- (v) Corrections for initial nonlinearities of the algorithm.

We briefly proceed to discuss these issues here.

1. Hashing functions. Simulations on textual files (see below) ranging in size from a few kilobytes to about 1 megabyte indicate that standard multiplicative hashing leads to performances that do not depart in any detectable way from those predicted by the uniform model of Sections 2, 3. There, a record  $x = (x_0, x_1, ..., x_p)$  formed of ASCII characters is hashed into

$$h(x) = \left(M + N \sum_{j=0}^{p} \operatorname{ord}(x_j) 128^{j}\right) \mod 2^{L},$$

with  $ord(\kappa)$  denoting the (standard ASCII) rank of character  $\kappa$ . This good agreement between theoretically predicted and practically observed performances is in accordance with empirical studies concerning standard hashing techniques and conducted on large industrial files by Lum *et al.* [5].

2. Length of the BITMAP vector. Since the probability distribution of the R-parameter has a very steep distribution, it suffices to select L in such a way that

$$L > \log_2(n/\text{nmap}) + 4. \tag{41}$$

Thus, as already pointed out, with nmap = 64, taking L = 16 makes it possible to safely count cardinalities of files up to  $n \sim 10^5$ , and L = 24 can be used for car-

dinalities well beyond 10'. The probabilities of obtaining underestimates because of such truncations (the probabilistic model assumes L to be infinite) can be computed from our previous results and when (41) is satisfied, the error introduced is below 5. 10e3.

3. Number of BITMAPS. The expected relative accuracy of the algorithm or standard error is by Theorems 4, 5 inversely proportional to fi, being closely approximated by

$$0.78/\sqrt{m}$$

Thus nmap = 64 leads to a standard error of about lo%, and with nmap = 256, this error decreases to about 5 % (see Table II).

4. Bias. The bias of algorithm PCSA as presented in Table II is negligible compared to the standard error as soon as nmap exceeds 32. If smaller values of nmap are to be used, it can be corrected using the results of Theorems 4, 5. For a practical use of the algorithm, it suffices to use the estimates of Theorem 5, which one achieves by changing the last instruction of the programme to

$$\Xi := \text{trunc}(\text{nmap}/(\varphi^*(1 + 0.31/\text{nmap}))^*2^{**}(S/\text{nmap}))$$

In so doing, we obtain an algorithm which apart from the small periodic fluctuations of amplitude less than lop4 is an asymptotically unbiased estimator of cardinahties n.

5. Initial non-linearities. The asymptotic estimates which form the basis of the algorithm are extremely close to the actual average values as soon as n/nmap exceeds l&20. If very small cardinalities were to be estimated, then based on the characterisation of probability distributions, corrections could be computed and introduced in the algorithm. (These corrections would be based on calculation of exact average values from our formulae instead of using the asymptotic estimates).

#### Simulations

We have conducted fairly extensive simulations of algorithm PCSA applied to textual data. The files called man,, man\* ,..., mans correspond to chapters of the online documantation available on one of our systems, and the versions mani w, man2 w,... correspond to the tiles obtained from the preceding ones by segmentation into 5 character blocks. Standard multiplicative hashing was used as described by Eq. (41). We counted in each case the number of different records and compared with corresponding values estimated by algorithm PCSA (here, a record is a line of text for mani ,... and a 5 letter block for man, w,...). Some sample runs are reported in Table III, and they show good agreement between our estimates and actual values. The files are mixtures of text in English, names of commands and typesetting commands.

We have also taken these 16 tiles, and have subjected them to algorithm PCSA, varying the constants M and N in (41). This provides empirical values of the bias

| TABLE<br>III                   |  |  |  |                                              |                  |  |  |  |  |
|--------------------------------|--|--|--|----------------------------------------------|------------------|--|--|--|--|
| Sample Executions of Algorithm |  |  |  | PCSA on 6 Files with the Same Multiplicative | Hashing Function |  |  |  |  |

| File    | Card. | 8     | 16    | 32    | 64    | 128   | 256   |
|---------|-------|-------|-------|-------|-------|-------|-------|
| man 1   | 16405 | 17811 | 16322 | 14977 | 15982 | 16690 | 17056 |
|         |       | 1.08  | 0.99  | 0.91  | 0.97  | 1.01  | 1.03  |
| man 1.w | 38846 | 40145 | 40566 | 40145 | 43290 | 41230 | 42592 |
|         |       | 0.96  | 1.01  | 0.96  | 1.07  | 1.02  | 1.06  |
| man 2   | 3149  | 2421  | 2887  | 3015  | 3015  | 2840  | 2982  |
|         |       | 0.77  | 0.91  | 0.95  | 0.95  | 0.90  | 0.94  |
| man 2.w | 10560 | 10590 | 9711  | 9100  | 9100  | 10032 | 10734 |
|         |       | 1.00  | 0.91  | 0.86  | 0.86  | 0.95  | 1.01  |
| man 8   | 3075  | 4452  | 3744  | 3360  | 3252  | 3097  | 3106  |
|         |       | 1.44  | 1.21  | 1.09  | 1.05  | 1.00  | 1.01  |
| man 8.w | 11334 | 10590 | 10590 | 10363 | 10705 | 10999 | 10676 |
|         |       | 0.93  | 0.93  | 0.91  | 0.94  | 0.97  | 0.94  |

Note. The figure displays the file name, the exact cardinality, the estimated cardinality for nmap = 8. 16, 32, 64, 128, 256, and the ratio of estimated cardinalities to exact cardinalities (in italics).

and standard error of PCSA (averaging over 10 simulations x 16 tiles) that again appear to be in amazingly good agreement with the theoretical predictions. Such results are reported in Table IV and should be compared with Table II. (The correction for small values of nmap described above has been inserted into the algorithm PCSA of Fig. 1.)

## Applications to Distributed Computing

Assume a fine F is partitioned into subtiles F,, F;!,..., F,, where the F, and Fi need not be disjoint. Such a situation occurs routinely in the context of distributed data bases.

TABLE IV Empirical Values of Bias and Standard Error Based on 160 Simulations

| m   | Bias    | % Standard error |  |  |  |  |
|-----|---------|------------------|--|--|--|--|
| 8   | 1.0169  | 31.92            |  |  |  |  |
| 16  | 1.0104  | 19.63            |  |  |  |  |
| 32  | 0.9798  | 12.98            |  |  |  |  |
| 64  | 0.996 1 | 9.67             |  |  |  |  |
| 128 | 1.0035  | 6.68             |  |  |  |  |
| 256 | 1.0073  | 4.65             |  |  |  |  |
|     |         |                  |  |  |  |  |

Note. Ten different hashing functions applied to the 16 files mani ,..., mans.w.

Then the global cardinality of file F may be determined as follows:

Process separately each of the s subfiles by algorithm PCSA. This gives rise to s BITMAP vectors, BITMAP, ,..,. Each of the s processors sends its result to a central processor that computes the logical or of the s BITMAPS. The resulting BITMAP vector is then used to construct the estimate of n.

It is rather remarkable that the accuracy of the estimate is, by construction, not affected at all by the way records are spread amongst subtiles. The number of messages exchanged is small (being O(s)), and the algorithm results in a net speedup by a factor of s.

#### Scrolling

The matrix of BITMAP vectors has a rather specific form: it starts with rows of ones followed by a fringe of rows consisting of mixed zeros and ones and followed by rows all zeros. This suggests naturally a more compact encoding of the bitmap that may be quite useful for distributed applications since it then minimises the sizes of messages exchanged by processors. The idea is to indicate the left boundary of the fringe, followed by a standard encoding of the fringe itself. For instance if the BITMAP matrix is

|  |  | 1111101000000 |  |  |  |  |
|--|--|---------------|--|--|--|--|
|  |  | 1111110000000 |  |  |  |  |
|  |  | 1111010110000 |  |  |  |  |
|  |  | 1111110100000 |  |  |  |  |

then, one only needs to represent the leftmost boundary of the fringe here 4) and the binary words 10100, 11000, 01011, 11010.

This technique amounts to keeping only a small window of the BITMAP matrix and scrolling it is necessary. For practical pruposes, a window of size 8 should suffice, so that the storage requirement of this version of PCSA becomes close to \$log,n + nmap bytes.

#### Deletions

If instead of keeping only bits to record the occurrences of patterns of the form O"l, one also keeps the counts of such occurrences, one obtains an algorithm that can maintain running estimates of cardinalities of tiles subjected to arbitrary sequences of insertions and deletions. The price to be paid is however a somewhat increased storage cost.

## 5. CONCLUSION

Probabilistic counting techniques presented here are particular algorithmic solutions to be problem of estimating the cardinality of a multiset. It is quite clear z.4 that other observable regularities on hashed values of records could have been used, in conjunction with direct or stochastic averaging. We mention is passing:

- -the rank of the rightmost one in BITMAP: this parameter has a flatter distribution that results in an appreciably less accurate algorithm (in terms of standard error);
- -the binary logarithm of the minimal hashed value encountered (hashed values being considered are real [O; 11 numbers) provides an approximation to log, l/n, but the resulting algorithm appears to be slightly less accurate than PCSA.

The common feature of all such algorithms is to estimate the cardinality n of a multiset in real time, using auxiliary storage O(m log, n) with a relative accuracy of the form:

$$\alpha/\sqrt{m}$$
.

It might be of interest to determine whether appreciably better storage/accuracy trade-offs can be achieved (or to prove that this is not possible from an information-theoretic standpoint).

For practical purposes, algorithm PCSA is quite satisfactory. It consumes only a few operations per element scanned (may be 20 or 30 assembly language instructions), has good accuracy described at length in the previous sections, and may be used to gather statistics on files on the fly (therefore eliminating the additonal cost of disk accesses). On a VAX 1 l/780 running Berkeley Unix, a non-optimised version in Pascal used for our tests is already typically twice as fast as the standard system sorting routine. A version of the algorithm has been implemented at IBM San Jose in the context of the System R\* Project.

### APPENDIX: THE AMPLITUDE OF PERIODIC FLUCTUATIONS

The purpose of this Appendix is to show how the fluctuations, in the form of Fourier series, that appear in Theorems 3, 4, 5 can be precisely bounded. Notice that the problem reduces to showing that the Fourier coefficients have sufficiently small values.

All these Fourier coefficients are values of functions of the form:

$$\Gamma(s) N(s) \omega(s),$$

with w(s) a "well-behaved" function, taken at points xk = 0 + 2ikrc/log 2 and k is a non-zero integer. Quantity (r depends on the particular problem considered: 0 = 0 in Theorem 3, 0 = -l/m in Theorems 4, 5.

We shall only give a proof in the case of Theorem 3.A, the other proofs being entirely similar. We thus need to find bounds for the Fourier series:

$$P(u) = \sum_{k \in \mathbb{Z}/\{0\}} p_k e^{-2ik\pi u}$$

with

$$p_k = \frac{1}{\log 2} \Gamma\left(\frac{2ik\pi}{\log 2}\right) N\left(\frac{2ik\pi}{\log 2}\right).$$

The behaviour of the gamma function along the imaginary axis is known:

$$|\Gamma(it)| = \sqrt{\pi/t \sinh \pi t}$$

so that it decreases very fast when going away from the real axis. For instance, one finds with Xk = 2ikrcllog 2:

$$|\Gamma(\chi_1)| = 5.45249 \cdot 10^{-7}; \qquad |\Gamma(\chi_2)| = 2.52468 \cdot 10^{-13}.$$

Thus all that is required is effective bounds on IN(i These follows easily by refining the approach taken in the proof of Lemma 3.

Define for x and t real, the function (see Eq. (24)):

$$f(x, t) = 1 - (1+x)^{-it} - (1+2x)^{-it} + (1+3x)^{-it}.$$

LEMMA. For t 3 1 and x < 3/2t, one has:

$$|f(x,t)| \leqslant 16x^2t^2.$$

ProoJ: The proof depends on the following easy observations: for y 3 0:

$$\log(1+y) \leqslant y \tag{1}$$

and for Iu( < 4:

$$|e^{u} - 1 - u| \le |u|^{2}. \tag{2}$$

which follows immediately from the inequality:

$$|e^{u} - 1 - u| \le \frac{|u|^{2}}{2} \left( 1 + \frac{|u|}{3} + \frac{|u|^{2}}{12} + \cdots \right)$$

$$\le \frac{|u|^{2}}{2(1 - |u|)}.$$
(3)

Thus rewriting the definition off in exponential form

$$f(x, t) = 1 - e^{-it\log(1+x)} - e^{-it\log(1+2x)} + e^{-it\log(1+3x)}$$

we find using (2) that, when 3xt < 4,

$$f(x, t) = -it \log \frac{1 + 3x}{(1 + x)(1 + 2x)} + R$$

where the remainder R satisfies

$$|R| \le t^2(\log^2(1+x) + \log^2(1+2x) + \log^2(1+3x))$$

$$\le 14t^2x^2.$$
(5)

Now since

$$\left| \log \frac{1+3x}{(1+x)(1+2x)} \right| \le 2x^2, \tag{6}$$

we obtain

$$|f(x, t)| \le 2tx^2 + 14t^2x^2 \le 16x^2t^2$$
.

The above lemma can be used for two purposes: (1) bounding the values of jN(it)l for large t; (2) bounding the truncation errors when estimating N(t) from the sum of its first few terms.

COROLLARY. For all t 3 1, N(d) satisfies

$$|N(it)| \le t^2 + 7t + 7. \tag{7}$$

Proof Consider the form (24) of N(it). With the notations of the lemma, it is

$$N(it) = -1^{-it} - 2^{-it} - 3^{-it} + \sum_{j \ge 1} \frac{(-1)^{\nu(j)}}{(4j)^{it}} \alpha(j, it)$$
 (8)

where ol(j, it) = f( 1/4j, t). Define j,(t) = max(Lt/6\_1, 1) so that 1/4j, 6 3/2t. Splitting the sum in (8) as I,,, = XI <j<jo + Cl, <i and applying the trivial bound If(x, t)l <4 to the first sum and the bound of the lemma to the other one, we find

$$|N(it)| \le 3 + 4j_0 + 16t^2 \sum_{j>j_0} \frac{1}{(4j)^2}$$

$$\le 3 + 4j_0 + \frac{t^2}{j_0} \le 7 + 7t + t^2. \quad \blacksquare$$
(9)

The modulus of N(xl) is found by direct numerical computations to be less than 6, and one has

$$N(\chi_1) \approx -4.42 - 3.99i;$$
  $N(\chi_2) \approx -6.55 - 3.17i;$   $N(\chi_3) \approx +2.75 + 1.77i.$ 

Thus using these values, one can check that lp,l < 0.5 10P6, I pzl < 10e9, and that the pk with k > 2 are much smaller and exponentially decreasing with the basis of the exponential equal to e-n2"og 2 ~0.6584 10-6.

#### ACKNOWLEDGMENTS

The first author would like to express his gratitude to IBM France and the IBM San Jose Research Laboratory for an invited visit during which his work on the subject was done for a large part. Thanks are due to M. Schkolnick, Kyu Young Wang (who implemented the method), and R. Fagin for their support and many stimulating discussions.

Note added in proof: The sequence ( - 1) "(PI that occurred repeatedly here is the classical Morse-Thue sequence. Using the Dirichlet generating function N(s), Allouche et al. (Automates finis et series de Dirichlet, J. Inform. Math., Publ. Math. Universiti de Caen, 1985) have obtained several interesting properties of that sequence, including a proof of a curious identity of Shallit (compare with our Theorem 3A):

$$\frac{1}{\sqrt{2}} = \frac{2}{3} \prod_{p=1}^{\infty} \left[ \frac{(4p+1)(4p+4)}{(4p+2)(4p+3)} \right]^{(-1)^{\nu(p)}}.$$

## REFERENCES

- 1. G. DOETSCH, "Handbuch der Laplace-Transformation," Birkhauser, Basel, 1950.
- 2. P. FLAJOLET, Approximate counting: A detailed analysis, BIT 25 (1985), 113-134.
- 3. P. FLAJOLET AND N. MARTIN, Probabilistic counting, in "Proc. 24th IEEE Sympos. Foundations of Computer Science, Nov. 1983," pp. 76-82.
- 4. D. E. KNUTH, "The Art of Computer Programming: Sorting and Searching," Addison-Wesley, Reading, Mass., 1973.
- 5. V. Y. LUM, P. S. T. YLJEN, AND M. DODD, Key to address transformations: A fundamental study based on large existing formatted tiles, Comm. ACM 14 (1971), 228-239.
- 6. R. MORRIS, Counting large numbers of events in small registers, Comm. ACM 21 (1978), 84&842.
- 7. I. MUNRO AND P. SPIRA, Sorting and searching in multisets, SIAM J. Comput 5, No. I (1976), l-8.
- 8. P. GRIFFITHS SELINGER, M. M. ASTRAHAN, D. D. CHAMBERLIN, R. A. LORIE, AND T. G. PRICE, "Access Path Selection in A Relational Database Management System," Report RJ-2429, IBM San Jose Res. Lab., Aug. 1979.