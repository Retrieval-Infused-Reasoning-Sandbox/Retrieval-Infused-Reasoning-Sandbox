However, the <sup>11</sup>B spectrum at twice the magnetic field strength remains unchanged, proving that the additional multiplicity is a result of long-range coupling and not two separate boron

Long-range P-H spin-spin coupling in the 40.5-MHz <sup>31</sup>P NMR spectrum is also observed in B<sub>4</sub>H<sub>8</sub>·PF<sub>2</sub>H while none of the other PF<sub>2</sub>X adducts exhibit this behavior. The protoncoupled 80-MHz 31P NMR spectrum of B<sub>4</sub>H<sub>8</sub>·PF<sub>2</sub>H was identical with that obtained at 40.5 MHz, again indicating that long-range spin-spin coupling is involved rather than nonequivalent <sup>31</sup>P resonances. A 200-MHz <sup>1</sup>H NMR spectrum was of no assistance in resolving the ambiguities associated with this compound.

As stated above, PF<sub>2</sub>H is known to have unusual base properties toward BH<sub>3</sub>. <sup>12</sup> Recently on the basis of the reaction of PF2H with nickel and the instability of the resulting compound, it has been concluded that the stability of PF<sub>2</sub>H·BH<sub>3</sub> results from specific hydride-proton interactions involving BH3 rather than PF<sub>2</sub>H being an unusually strong base.<sup>13</sup> This type of interaction could also occur in B<sub>4</sub>H<sub>8</sub>·PF<sub>2</sub>H and, indeed, on the basis of our data it seems probable that the bonding and structural parameters in B<sub>4</sub>H<sub>8</sub>·PF<sub>2</sub>H are different from those of the other PF<sub>2</sub>X complexes studied. A single-crystal X-ray diffraction study of this molecule is clearly needed.

While this work has contributed significantly to the understanding of the B<sub>4</sub>H<sub>8</sub>L complexes, several interesting factors are still not well understood. The anomalous properties of B<sub>4</sub>H<sub>8</sub>·PF<sub>2</sub>H, the factors which stabilize the endo isomer relative to the exo isomer, and the importance of the electronic and steric requirements of the ligand in determining the relative stability of the two isomers deserve further study.

Acknowledgment. The authors wish to express their gratitude to Drs. E. J. Stampf and A. R. Garber for assistance in preliminary work and through helpful discussion. We also thank the National Science Foundation for financial support through Grants CHE77-08310 and CHE77-10098.

Registry No. B<sub>4</sub>H<sub>8</sub>·PF<sub>2</sub>N(CH<sub>3</sub>)<sub>2</sub>, 60930-18-9; B<sub>4</sub>H<sub>8</sub>·PF<sub>3</sub>, 60930-19-0; B<sub>4</sub>H<sub>8</sub>·PF<sub>2</sub>Cl, 36907-24-1; B<sub>4</sub>H<sub>8</sub>·PF<sub>2</sub>Br, 36907-25-2; B<sub>4</sub>H<sub>8</sub>·PF<sub>2</sub>I, 36907-26-3; B<sub>4</sub>H<sub>8</sub>·PF<sub>2</sub>H, 24189-89-7.

> Contribution from the Department of Chemistry, Cornell University, Ithaca, New York 14853

## Bent Cis d<sup>0</sup> MoO<sub>2</sub><sup>2+</sup> vs. Linear Trans d<sup>0</sup>f<sup>0</sup> UO<sub>2</sub><sup>2+</sup>: A Significant Role for Nonvalence 6p Orbitals in Uranyl

KAZUYUKI TATSUMI and ROALD HOFFMANN\*

Received April 17, 1980

The marked preference of uranyl, UO<sub>2</sub><sup>2+</sup>, d<sup>0</sup>f<sup>0</sup>, for linear geometries, while MoO<sub>2</sub><sup>2+</sup> and isoelectronic d<sup>0</sup> molecules are bent, is not due to oxygen 2p-actinide  $5f\pi$  bonding. Instead we trace the geometrical effect to a substantial involvement of formally inner-shell 6p orbitals of  $\sigma$  symmetry on uranium which interact significantly with oxygen p $\sigma$  orbitals and "activate" these for  $\sigma$  bonding with U 5f.

Enigmatic is the contrast between the ubiquitous linear uranyl ion UO<sub>2</sub><sup>2+</sup> and the common *bent* transition metal dioxo ions such as VO<sub>2</sub><sup>+</sup>, MoO<sub>2</sub><sup>2+</sup>, and WO<sub>2</sub><sup>2+</sup>. UO<sub>2</sub><sup>2+</sup>, 1, in which uranium has a formal 5f<sup>0</sup>6d<sup>0</sup> valence configuration, always occurs in crystals or in complexes with trans geometry, having four, five, or six secondary coordinations in an equatorial plane perpendicular to the main O-U-O axis.1 In contrast, the VO<sub>2</sub><sup>+</sup>, MoO<sub>2</sub><sup>2+</sup>, and WO<sub>2</sub><sup>2+</sup> ions, **2**, which have a related d<sup>0</sup> valence configuration, occur, mostly in octahedral ligand sets, with exclusive cis geometry  $(O-M-O \text{ angle} = 102-114^\circ)$ .<sup>2</sup>

$$\begin{array}{cccccccccccccccccccccccccccccccccccc$$

An obvious difference in electronic structure between the trans-UO22+ and cis-VO2+, MoO22+, or WO22+ is that the uranium has f orbitals in the valence orbital set while the other metals do not have them. So are the f orbitals in UO<sub>2</sub><sup>2+</sup> really important in describing its geometrical preference of trans over cis? The numerous theoretical studies on uranyl certainly involve the f orbitals in bonding<sup>3</sup> but do not address themselves to the choice among alternative geometries. We now hypothesize that the answer is both no and ves and that nonvalence 6p orbitals on U play a previously unappreciated role in determining the trans geometry.

A feature characteristic of both MoO<sub>2</sub><sup>2+</sup> and UO<sub>2</sub><sup>2+</sup> complexes is a very short M-O distance (Mo-O  $\approx 1.67$  Å, U-O  $\approx 1.76 \text{ Å}$ ) and labile coordination geometries. Thus, as a first approximation, we may consider that the geometrical preferences reside in the naked cations themselves, and not in the auxiliary ligands. We have carried out extended Hückel calculations for  $MoO_2^{2+}$  and  $UO_2^{2+}$  with a variety of basis sets:4 for Mo 4d, 5s, 5p separately (d or s or p) or all together

For reviews: (a) Dyatkina, M. E.; Mikhailov, Yu. N. Zh. Strukt. Khim.

For Feviews: (a) Dyatkina, M. E.; Mikhailov, Tu. N. Zh. Struki. Khim. 1962, 3, 724–727; (b) Cattalini, L.; Croatto, U.; Degetto, S.; Tondello, E. Inorg. Chim. Acta Rev. 1971, 5, 19–43.
(a) Griffith, W. P. Coord. Chem. Rev. 1970, 5, 459–517. (b) Scheidt, W. R.; Tsai, Chun-che; Hoard, J. L. J. Am. Chem. Soc. 1971, 93, 3867–3872. Scheidt, W. R.; Collins, D. M.; Hoard, J. L. Ibid. 1971, 93, 3873–3877. (c) Schröder, F. A. Acta Crystallogr., Sect. B 1975, B31, 2294–2309. (d) Stiefel, E. I. Prog. Inorg. Chem. 1977, 22, 1–223.

<sup>(</sup>a) Coulson, C. A.; Lester, G. R. J. Chem. Soc. 1956, 3650-3659. (b) (a) Coulson, C. A.; Lester, G. R. J. Chem. Soc. 1956, 3650-3659. (b) McGlynn, S. P.; Smith, J. K. J. Mol. Spectrosc. 1961, 6, 164-187. (c) Dyatkina, M. E.; Markov, V. P.; Tsapkina, I. V.; Mikhailov, Yu. N. Zh. Neorg. Khim. 1961, 6, 575-580. (d) Belford, R. L. J. Chem. Phys. 1961, 34, 318-321. (e) Boring, M.; Wood, J. H.; Moskowitz, J. W. Ibid. 1975, 63, 638-642. Boring, M.; Wood, J. H. Ibid. 1979, 71, 392-399. (f) Walch, P. F.; Ellis, D. E. Ibid. 1976, 65, 2387-2392. (g) Yang, C. Y.; Johnson, K. H.; Horsley, J. A. Ibid. 1978, 68, 1001-1005. (h) Denning, R. G.; Snellgrove, T. R.; Woodwark, D. R. Mol. Phys. 1979, 37, 1109-1143. *37*, 1109-1143

<sup>(</sup>a) Mo-O and U-O bond distances are assumed to be 1.67 and 1.76 (a) MO-O and O-O boild distances are assumed to be 1.37 and 1.76 A, respectively. (b) Atomic parameters are as follows. H<sub>ii</sub>: Mo 5s, -9.66 eV; Mo 5p, -6.36 eV; Mo 4d, -12.3 eV; U 7s, -5.50 eV; U 7p, -5.50 eV; U 6d, -5.09 eV; U 5f, -9.01 eV; U 6p, -30.03 eV. Orbital exponents: Mo 5s, 1.96; Mo 5p, 1.90; Mo 4d, 4.54 (0.5899) + 1.90 (0.5899); U 7s, 1.914; U 7p, 1.914; U 6d, 2.581 (0.7608) + 1.207 (0.4126); U 5f, 4.943 (0.7844) + 2.106 (0.3908); U 6p, 4.033. The parameters for U are estimated from the relativistic Dirac-Fock wave functions of Desclaux. Details will be given in a forthcoming paper.

![](_page_1_Figure_2.jpeg)

![](_page_1_Figure_3.jpeg)

Figure 1. Relative total energy as a function of bond angle for Mo 4d, 5s, 5p (separately) and dsp (all together) basis sets in MoO<sub>2</sub><sup>2+</sup> (top) and for U 5f, 6d, 7s, 7p (separately) and fdsp (all together) basis sets in UO<sub>2</sub><sup>2+</sup> (bottom).

(dsp); for U 5f, 6d, 7s, 7p separately (f or d or s or p) or all together (fdsp).

Figure 1 shows the various calculated potential energy curves for bending  $MoO_2^{2+}$  or  $UO_2^{2+}$ . For  $MoO_2^{2+}$  the s and p curves lead to an angular differentiation, the d curve favors a strongly bent geometry, and the composite dsp surface has a minimum at an O-Mo-O angle of  $\sim 110^{\circ}$ , agreeing quite well with the observed structures.<sup>2</sup> It is evident that Mo 4d orbitals play a dominant role in stabilizing the bent MoO<sub>2</sub><sup>2+</sup>. This may be explained simply in terms of maximum utilization of vacant d orbitals in  $\pi$  bonding with oxygen lone pairs.<sup>2d,7</sup> There are four oxygen  $\pi$ -type lone pairs. In the cis geometry they can interact with three vacant d orbitals on the metal, 3, whereas in the trans geometry they thay have to "share" two d orbitals,

![](_page_1_Figure_7.jpeg)

In the case of the uranyl ion, the shapes of the energy curves for the d, s, and p basis sets bear a close resemblance to those

Desclaux, J. P. At. Data Nucl. Data Tables 1973, 12, 311-406.

Chem. 1978, 17, 1581-1584.
(a) Veal, B. W.; Lam, D. J.; Carroll, W. T.; Hoekstra, H. R. Phys. Rev. B: Solid State 1975, 12, 5651-5663. (b) Verbist, J. J.; Riga, J.; Tenret-Noel, C.; Pireaux, J.-J.; d'Ursel, G.; Caudano, R. In "Plutonium and Other Actinides"; Blank, H., Lindner, R., Eds.; North-Holland: Amsterdam, 1976; pp 409-419.

![](_page_1_Figure_12.jpeg)

Figure 2. Relative total energy as a function of O-U-O bond angle for U 6p and 6p + 5f, 6d, 7s, 7p basis sets in  $UO_2^{2+}$ .

for corresponding basis sets on MoO<sub>2</sub><sup>2+</sup>. For example, U 6d orbitals want  $UO_2^{2+}$  to bend, as 4d orbitals do for  $MoO_2^{2+}$ . However, the curvatures for  $UO_2^{2+}$  are all decreased compared to those for MoO<sub>2</sub><sup>2+</sup>. Our orbital parameters<sup>4b</sup> have U 6d, U 7s, and U 7p at much higher energies than Mo 4d, Mo 5s, and Mo 5p, respectively, causing smaller interactions between the vacant U orbitals and occupied O 2p orbitals in UO<sub>2</sub><sup>2+</sup>. It is also apparent that f orbitals by themselves do not favor linearity, even though the surface computed is very soft. In bent UO22+ all four oxygen lone pairs are stabilized, not all equally, by four f orbitals. In the linear alternative only two f orbitals are available for the stabilization of two oxygen combinations. This picture is rather similar to that drawn for the role of d orbitals in favoring a cis geometry for  $MoO_2^{2+}$ . It is supported by angular overlap model calculations which show explicitly that d or f orbitals by themselves will always provide a better opportunity for  $\pi$  bonding in the bent cis geometry, no matter what the metal is.

This result may disappoint the chemist who wants to attribute the linearity of uranyl to f orbitals. But please do not come to a hasty pessimistic conclusion at this stage.

When 5f, 6d, 7s, and 7p orbitals are all used in the fdsp basis, the potential energy curve becomes very flat in the range of  $\theta$  110–180°. A complicated hybridization of the basis set is probably behind this, but we would like to bypass an explication here, for while the result is encouraging, it does not account for the experimental preponderance of strictly trans uranyl groupings.

Now we take into account the influence of the filled nonvalence, "inner-shell" 6p orbitals. There are several reasons for doing so. First, the weighted average 6p level, estimated from the relativistic Dirac-Fock wave functions of the U 6p<sub>3/2</sub> and  $6p_{1/2}$  orbitals,<sup>5</sup> is at -30.0 eV in energy, with the maximal radial density at  $R_{\text{max}} = 0.853 \text{ Å}$ . Considering the short U-O distance and the energy levels of O 2s (-32.3 eV) and O 2p (-14.8 eV), it is natural to expect substantial overlap interactions of a U 6p level with O 2s and O 2p. Note that the corresponding inner Mo 4p level is much more corelike, being at -48.5 eV with  $R_{\rm max} = 0.569$  Å. Second, XPS and ESCA spectra of uranyl compounds<sup>8</sup> show a reorganization of U  $6p_{3/2}$  and  $6p_{1/2}$  and O 2s energy levels in the region between -12and -32 eV, ascribable to the presence of a U 6p-O 2s covalent interaction. And third, both the MS-X $\alpha$  and DVM calculations<sup>3e,f</sup> confirmed strong coupling between the O 2s and U

Tatsumi, K.; Hoffmann, R., to be submitted for publication.
(a) Griffith, W. P.; Wickins, T. D. J. Chem. Soc. A 1968, 400-404. (b) Mingos, D. M. P. J. Organomet. Chem. 1979, 179, C29-C33. (c) See also: Burdett, J. K.; Albright, T. A. Inorg. Chem. 1979, 18, 2112-2120. (d) The problem is connected to the observed nonlinearity of alkaline earth dihalides: Wharton, L.; Berg, R. A.; Klemperer, W. J. Chem. Phys. 1963, 39, 2023-2031; Büchler, A.; Stauffer, J. L.; Klemperer, W. Ibid. 1964, 40, 3471-3474; J. Am. Chem. Soc. 1964, 86, 4544-4550; White, D.; Calder, G. V.; Hemple, S.; Mann, D. E. J. Chem. Phys. 1973, 59, 6645-6651; Hayes, E. F. J. Phys. Chem. 1966, 70, 3740-3742; Gole, J. L.; Siu, A. K. Q.; Hayes, E. F. J. Chem. Phys. 1973, 58, 857-868. See also: Myers, C. E.; Norman, L. J., II; Loew, L. M. Inorg.

![](_page_2_Figure_2.jpeg)

Figure 3. The valence orbitals of trans-UO<sub>2</sub><sup>2+</sup> (at left) and cis-UO<sub>2</sub><sup>2+</sup> (at right) calculated for U 6p and 6p + fdsp basis sets.

6p, especially the  $6p_{3/2}$  level. The degree of admixture of O 2s in the  $14 S1_u$ , which is formally identified as one of the U  $6p_{3/2}$  states, amounts to  $\sim 50\%$ . Potential energy curves for the 6p and 6p + fdsp basis sets are in Figure 2.

Adding the 6p orbitals to the U fdsp valence set has a dramatic effect. The potential now clearly favors the linear form, while the 6p orbitals by themselves still want a bent  $UO_2^{2+}$ .

The way in which valence and "inner shells" operate to produce this effect is traced through Figure 3, which shows some of the frontier orbitals of trans- and cis-UO<sub>2</sub><sup>2+</sup>. The six highest occupied orbitals are derived from the 2p orbitals of the two oxo ligands, in general destabilized by their mixing with occupied U 6p and stabilized primarily by unoccupied U 5f. Among these, the  $\sigma_u^+$  orbital of the trans form is strongly pushed up (+5.8 eV) by  $6p_z$  and is pushed back (-2.3 eV), mainly by  $5f_{z^3}$ . The two  $\pi_u$  orbitals are similarly affected by  $6p_x$ ,  $6p_y$ ,  $5f_{xz^3}$ , and  $5f_{yz^2}$ , but not so much. This is due to a relatively large O  $2p_\sigma$ -U  $6p_\sigma$  overlap integral (0.210) and a concomitant small O  $2p_\pi$ -U  $6p_\pi$  overlap integral (0.049). In the cis form, two orbitals, the highest occupied  $a_1$  and  $b_1$ , are pushed up by the sum of 5.1 eV and then pushed down by -1.2 eV. The  $\sigma_u^+$  of the trans geometry is more destabilized by 6p, compared with  $a_1$  and  $b_1$  of cis, which in turn results in a more effective stabilization of  $\sigma_u^+$  by 5f.

The considerations we present here are based on calculations without inclusion of spin-orbit interactions. The effects of

spin-orbit coupling are hardly negligible for uranium, <sup>10a</sup> but we believe that trends in energy with angular deformation will carry over from calculations without spin-orbit interaction to those with such interaction, <sup>10b</sup> especially for systems having f<sup>0</sup> electronic configurations.

We believe that we have found a reasonable explanation for the unique linear geometry of  $UO_2^{2+}$ . The nonvalence 6p and the valence 5f cooperate to determine the linear geometry—the repulsive 6p-oxygen interaction makes one oxygen p combination a superlative  $\sigma$  donor only in the linear form, for interaction with, stabilization by, an appropriate symmetry 5f combination. We will also show that a similar cooperation of 6p and 5f orbitals accounts for the T shape of  $UO_3$ . 12

Acknowledgment. We are grateful to J. K. Burdett for some discussions and to the National Science Foundation for its support of this work through Research Grant CHE-7828048.

**Registry No.**  $MoO_2^{2+}$ , 16984-32-0;  $UO_2^{2+}$ , 16637-16-4.

<sup>(10) (</sup>a) Hayes, R. G.; Edelstein, N. J. Am. Chem. Soc., 1972, 94, 8688-8691. Pitzer, K. S. Acc. Chem. Res. 1979, 12, 271-276. Pyykkö, P.; Desclaux, J. P. Ibid. 1979, 12, 276-281. (b) Wadt, W. R.; Hay, P. J. J. Am. Chem. Soc. 1979, 101, 5198-5206. A number of comparisons pertinent to this point are given by: Pyykkö, P.; Lohr, L. L., Jr. Ibid., in press.

<sup>(11)</sup> Conclusions similar to ours concerning the role of 6p orbitals in stabilizing a linear uranyl have been independently reached by: Lohr, L. L., Jr.; Pyykkö, P., to be submitted for publication.

<sup>(12)</sup> Gabelnick, S. D.; Reedy, G. T.; Chasanov, M. G. J. Chem. Phys. 1973, 59, 6397-6404.

<sup>(9)</sup> The z axis is along O-U-O.