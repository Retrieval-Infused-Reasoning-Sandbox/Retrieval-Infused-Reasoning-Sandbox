![](_page_0_Picture_3.jpeg)

## Relativity and the Lead-Acid Battery

Rajeev Ahuja, <sup>1,\*</sup> Andreas Blomqvist, <sup>1</sup> Peter Larsson, <sup>1</sup> Pekka Pyykkö, <sup>2,†</sup> and Patryk Zaleski-Ejgierd<sup>2,‡</sup>

<sup>1</sup>Division of Materials Theory, Department of Physics and Astronomy, Uppsala University, Box 516, SE-751 20, Uppsala, Sweden

<sup>2</sup>Department of Chemistry, University of Helsinki, Box 55 (A. I. Virtasen aukio 1), FI-00014 Helsinki, Finland

(Received 30 August 2010; published 5 January 2011)

The energies of the solid reactants in the lead-acid battery are calculated *ab initio* using two different basis sets at nonrelativistic, scalar-relativistic, and fully relativistic levels, and using several exchange-correlation potentials. The average calculated standard voltage is 2.13 V, compared with the experimental value of 2.11 V. All calculations agree in that 1.7–1.8 V of this standard voltage arise from relativistic effects, mainly from PbO<sub>2</sub> but also from PbSO<sub>4</sub>.

DOI: 10.1103/PhysRevLett.106.018301

The lead-acid battery is an essential part of cars, and has numerous other applications. This well-known invention is now 150 years old [1,2]. Although there are electrochemical simulations starting from the given thermodynamical data [3,4], we are not aware of any ab initio ones for the lead battery. This is in stark contrast to other rechargeable batteries, such as the modern lithium-ion based systems, where they abound. The problem is difficult enough to be a theoretical challenge, and there is also the aspect that, Pb being a heavy element, relativistic effects on its compounds could play an important role, as qualitatively found a long time ago [5–8]. It has been shown that already the structure of lead itself can be substantially altered by the inclusion or relativity; see Refs. [9–12]. It is thus particularly interesting to investigate the effects of relativity on the total voltage of the lead-acid cell.

The lead-acid battery [13] consists of a positive lead dioxide electrode, a negative electrode of metallic lead, and a sulfuric acid electrolyte. The electronic structures of both PbO [14–16] and  $\beta$ -PbO<sub>2</sub> [17–19] have been theoretically studied earlier. The high metallic conductivity of the  $\beta$ -PbO<sub>2</sub>, enabling large currents, was shown to be an impurity, conduction-band effect, attributed to donor impurities at oxygen sites [18–21]. The alloying of the Pb electrode is also important in practice, but it is not discussed here, because the minute amounts of other elements do not affect the electromotive force (EMF) of the cell.

The discharge reaction between a Pb<sup>IV</sup> and a Pb<sup>0</sup> produces 2Pb<sup>II</sup>, in the form of solid PbSO<sub>4</sub>:

$$Pb(s) + PbO_{2}(s) + 2H_{2}SO_{4}(aq)$$

$$\rightarrow 2PbSO_{4}(s) + 2H_{2}O(l) \qquad \Delta G_{cell}^{0}. \qquad (1)$$

Here (l) is liquid, (s) is solid, (aq) is aqueous solution, and  $\Delta G_{\rm cell}^0$  refers to the free energy of the cell reaction. The experimental thermodynamics of the reaction are well known [22], but here we approach it from an ab initio point of view. Our goal is to investigate the relativistic effects on the EMF,  $E_{\rm cell}^0$ , of the cell, which we derive from the free energy of the reaction  $\Delta G_{\rm cell}^0$  using

$$\Delta G^0 = -RT \log(K) = -nFE_{\text{cell}}^0. \tag{2}$$

In the final calculation of the  $E_{\rm cell}^0$ , we will neglect temperature effects, and effectively use  $\Delta G \approx \Delta H(0~{\rm K})$ . This introduces an error of at most 0.1 V in the EMF, as can be judged by the experimental thermodynamical data of the reaction, given in the supplementary material [23]. We will later see that this is an order of magnitude less than the calculated relativistic contributions.

PACS numbers: 82.47.Cb, 31.15.ae, 31.15.aj, 82.60.Cx

At 0 K, the three solids in Eq. (2) can be treated with existing solid-state theories, such as density functional theory (DFT), because the bonding mechanism in the investigated species is dominated by interactions where DFT is expected to provide reliable results. Adequately simulating the liquid phase in multiple relativistic regimes is beyond current state of the art, however. We avoid this problem by introducing the known energy  $\Delta E(3)$  for the experimental reaction

$$H_2O(l) + SO_3(g) \rightarrow H_2SO_4(l)$$
  $\Delta E(3)$ , (3)

where (g) is gas. We can use this empirical relationship because only light elements and only  $S^{VI}$  occur in Eq. (3), whose contribution to relativistic effects are small. Combining the equations (1) and (3) gives

$$Pb(s) + PbO_2(s) + 2SO_3(g) \rightarrow 2PbSO_4(s) \quad \Delta E(4).$$
 (4)

The voltages for the lead-acid battery reaction may then be calculated from the reaction energies

$$E_{\text{cell}}^0 = \left[\Delta E(4) - 2\Delta E(3)\right]/nF,\tag{5}$$

where we use calculated  $\Delta E(4)$  values and experimental  $\Delta E(3)$  values. Concentrated sulfuric acid is used in reactions (1) and (3). The cell voltage at typical acid concentration of 5.5 mol/dm<sup>3</sup> (in  $\rm H_2SO_4 \cdot 10H_2O$ ) is calculated using the values tabulated by Duisman and Giauque [22].

Prediction of formation energies in a quantitative manner from *ab initio* calculation requires, in additional to having an accurate underlying theory, also absolute convergence of all technical parameters and a sufficiently general basis set. It is therefore fruitful to approach the problem with several independent methods, and see if they

converge on the result. In our case, we used a linear combination of local orbitals (LCAO), with and without a frozen-core approximation, using the BAND program [24], and a full-potential local-orbital minimum-basis approach [25] with the FPLO program (version 7.00-27). With BAND, we employed the following exchange-correlation potentials: SVWN [26], PBEsol [27], PBEsol-D [28], where the last one includes dispersion corrections, while the FPLO calculations used only PW92 [29].

The calculations are performed with crystal structures from experimental room-temperature measurements (for data, see the supplementary material [23]), allowing no ionic relaxations, thus capturing the dynamic electronic effects of relativity (meaning Dirac versus Schrödinger). The alternative, more laborious choice would have been to also consider relativistic structural and vibrational changes. As mentioned above, the thermal effects on the reaction energies are fairly small and are simply neglected. If a battery freezes at low temperatures, it is due to the kinetics, not due to the  $\Delta G$ . As stated, we assume for simplicity pure, unalloyed Pb and a pure  $\beta$ -PbO<sub>2</sub> phase in the electrode materials. The measured cell voltages for  $\alpha$ - and  $\beta$ -PbO<sub>2</sub> differ by ca. 0.01 V [30].

In the LCAO approach, the one-electron basis sets consist of a linear combination of Herman-Skillman numerical atomic orbitals and Slater-type orbitals. We apply quadruple-zeta basis sets augmented with four polarization functions, from the BAND basis-set repository. The frozencore approximation is applied to reduce the size of the variational basis set. The use of frozen core, as implemented in BAND [24], is preferable over pseudopotentials because it essentially allows for all-electron calculations. The frozen-core orbitals are taken from high-accuracy calculations with extensive Slater-type orbital basis sets. For oxygen and sulfur, we use all-electron basis sets. For lead, we include up to 4f orbitals in the core. The change in the deep-core orbitals due to formation of chemical bonds was confirmed to be negligible. The band nature of the solid-state species was inferred by studying the density of states (DOS). The orbital character of the total DOS was determined with respect to contributions from individual atoms. The band structures along a series of lines of high symmetry change only slightly depending on the exchange-correlation potential used: the ordering, the orbital character, and the dispersion remain comparable within local-density-type and generalized-gradient-type approximations.

In the case of BAND calculations, we used experimentally determined structures for both solid- and gas-phase species. The lattice constants and atomic positions were kept fixed in all calculations, motivated by our interest in the electronic origin of the EMF and the relativistic contributions to it. The relativistic effects are investigated by means of the zeroth-order regular approximation (ZORA, see Ref. [31] and references therein). We consider three cases: nonrelativistic (NR) with no ZORA operators, scalar

relativistic (SR) including ZORA but without the spin-orbit coupling part, and the fully relativistic (FR) case with complete ZORA where first-order spin-orbit effects are also taken into account. To ensure high-accuracy results, the convergence of the calculations was checked with respect to all crucial numerical parameters including the number of k points, basis-set quality, and size of the frozen core. The formation energies were calculated with respect spherically symmetric spin-restricted atoms and converged within 1 kJ/mol or less. To sample the first Brillouin zone, and evaluate the k-space integrals, we used a quadratic numerical integration scheme with  $9 \times 9 \times 9$  (Pb and Sn),  $5 \times 5 \times 5$  (PbO, PbO<sub>2</sub>, SnO,  $SnO_2$ ), and  $3 \times 3 \times 3$  (PbSO<sub>4</sub>) meshes. The  $SO_3$  molecule was placed in the middle of a large cubic unit cell (a = 20 Å) with a single k point.

In the FPLO approach, we performed band-structure calculations using the nonrelativistic, the scalar-relativistic, and the full four-component relativistic versions of the method [25]. The local density approximation was used [29] for the exchange-correlation functional. Optimal volumes of the crystal structures were determined by calculating the experimental structures at different volumes and fitting a fourth-order polynomial equation of state to the data points. To sample the first Brillouin zone and evaluate the k-space integrals, we use a linear numerical integration scheme with  $24 \times 24 \times 24$  (Pb and Sn),  $12 \times 12 \times 12$  (PbO, PbO<sub>2</sub>, SnO, SnO<sub>2</sub>), and  $6 \times 6 \times 6$  (PbSO<sub>4</sub>) k-point meshes. The SO<sub>3</sub> molecule was calculated without periodic boundary conditions.

The resulting reaction energies for the lead-battery reaction (1), calculated at the FR, SR, and NR levels are compared to experiment in Table I. We manage to reproduce the absolute voltage of the lead-battery reaction within about 0.2 V. Taking the four calculations in Table I at face value, our calculated absolute voltage for reaction (1), in  $H_2SO_4 \cdot 10H_2O$ , is +2.13 V while its relativistic part is +1.74 V. The relativistic increase of the oxidative power of  $\beta$ -PbO<sub>2</sub>(s) is indeed the largest contribution. The PbSO<sub>4</sub>(s) contribution to EMF follows, and has the same sign. The third largest contribution comes from the spin-orbit coupling effects in metallic Pb. At the "PBEsol-D" level of theory these three, essentially

TABLE I. Comparison of the experimental and calculated results for the EMF (V) of the lead-battery reaction (1).

|        |                   | Level of relativity |                |                 | Δ              | Δ              |
|--------|-------------------|---------------------|----------------|-----------------|----------------|----------------|
| Method | _                 | NR                  | SR             | FR              | FR-NR          | SR-NR          |
| BAND   | VWN<br>PBEsol-D   |                     | +2.52<br>+2.25 | +2.27<br>+2.02  | +1.72<br>+1.81 | +1.97<br>+2.04 |
| FPLO   | PW92<br>PW92b     | +0.41<br>+0.39      | +2.20<br>+2.21 | +2.10 +2.11     | +1.69<br>+1.72 | +1.80<br>+1.82 |
|        | Average Exp. [30] | +0.39               | +2.30          | +2.13<br>+2.107 | +1.74          | +1.91          |

![](_page_2_Figure_3.jpeg)

FIG. 1 (color online). The relativistic shifts in energies of formation  $E_f$  (per formula unit), calculated at DFT–PBEsol-D level. The nonrelativistic energy, NR =  $E_f$ (NR), is chosen as reference;  $\Delta_{\rm SR} = E_f({\rm SR}) - E_f({\rm NR})$  and  $\Delta_{\rm FR} = E_f({\rm FR}) - E_f({\rm NR})$ . Note the smallness of the effect on SO<sub>3</sub>(g).

method-independent contributions are +1.58, +0.27, and -0.06 V, respectively. For details on individual contributions, see Fig. 1.

Comparing Pb with its lighter congener Sn, it has been noticed before that no corresponding "tin battery" exists [32]. It was attributed to the lower oxidative power of SnO<sub>2</sub>, as compared to PbO<sub>2</sub>. Our calculations supports this conclusion, since a tin battery would roughly correspond to a lead battery without relativistic effects (see below). We indeed found the largest relativistic shifts in the lead dioxide. In Fig. 2, we show the FR, SR, and NR DOS of Pb in  $\beta$ -PbO<sub>2</sub>(s). We see that the Pb 6s character is evenly distributed between the filled and empty states [18], making this shell "half-oxidized." Furthermore, the size of the band gap decreases with increasing level of relativity (NR, SR, FR). Note also the relative shifts and change in the Pb 6s population at different levels. The Pb 6s states are significantly stabilized by inclusion of relativity also in  $\beta$ -PbO<sub>2</sub>.

We derived above the cell voltage of reaction (1) by using a combination of experimental and theoretical results. In order to validate the solid-state DFT part—something which cannot be taken for granted—we also considered the simplified "toy-model" reactions, taking place entirely in the solid state,

$$M(s) + MO_2(s) \rightarrow 2MO(s),$$
 (6)

with M being Pb or Sn. The reaction energy of this model can be calculated completely by DFT, and should be close to experiment. We find that this is the case, with the voltages for Pb being within 0.05 V of the experimental value for the two different DFT implementations and several different exchange-correlation functionals; see Fig. 3. This suggests that our theoretical calculations accurately describe reality. In Fig. 1, we show the calculated energies of formation  $E_f$  of individual species at various levels

![](_page_2_Figure_10.jpeg)

FIG. 2 (color online). Total and partial DOS (states/eV/cell) of Pb in  $\beta$ -PbO<sub>2</sub> calculated at DFT-VWN level (the Fermi energy  $E_F$  is set to 0). Note the pronounced relativistic shift in both occupied and unoccupied Pb 6s states. (NR, nonrelativistic; SR, scalar relativistic; FR, fully relativistic). Gray (orange), Pb 6s; black (green), Pb 6p.

of relativity. The relativistic shift is most pronounced for solid  $\beta$ -PbO<sub>2</sub>. For solid PbO it is approximately 5 times smaller and has the same sign. In the case of the tin toy model, the largest relativistic contribution arises from SnO<sub>2</sub>, followed by SnO and Sn, for which the relativistic shifts are only slightly different.

Returning to a qualitative discussion, we mean here by relativistic effects anything that depends on the speed of light or, more technically, whether the Dirac or Schrödinger equation is used. The main effects are the stabilization of all ns and np shells, the destabilization of the nd and nf shells, and the spin-orbit splitting of the  $p, d, f, \ldots$  shells. For example, FR and NR atomic orbital energies of tin and lead are shown in Fig. 4. As noticed before [7,8], the nonrelativistic values are similar for Sn and Pb while the relativistic ones are not. Qualitatively,

![](_page_2_Figure_14.jpeg)

FIG. 3 (color online). Effect of relativity on the EMF of model reaction,  $M(s) + MO_2(s) \rightarrow 2MO(s)$ , calculated with four different methods (A-D). Experimental values for M=Pb ( +0.82 V) and M=Sn ( -0.085 V) are indicated with the horizontal dashed lines and dotted lines, respectively. (A) BAND (VWN), (B) BAND (PBEsol), (C) BAND (PBEsol-D), and (D) FPLO (PW92). The level C has empirical dispersion corrections.

![](_page_3_Figure_3.jpeg)

FIG. 4. Relativistic (FR) and nonrelativistic (NR) Hartree-Fock orbital energies for the tin and lead atoms in their  $ns^2np^2$  ground state. Note the relativistic stabilization of the ns level (lowest in the figure), leading to higher oxidative power for Pb<sup>IV</sup> than for Sn<sup>IV</sup>. Data from Desclaux [33].

the tendency of Pb to be predominantly divalent can be related to the increased binding energy of the Pb 6s shell. Relativistic effects have also been suggested as being responsible for changing the structure of metallic lead from diamond to fcc [9,12], as well being necessary to determine phase transitions between fcc, hcp, and bcc structures [10].

Moreover, it has been shown that the valence-shell relativistic effects of the periodic table scale roughly as  $Z^2$ , Z being the full nuclear charge [8]. For tin and lead the ratio is

$$\left[\frac{Z(\text{Sn})}{Z(\text{Pb})}\right]^2 = \left[\frac{50}{82}\right]^2 = 0.372,$$
 (7)

while the fully relativistic voltage changes  $\Delta E$ , calculated for the toy models(6), yield

$$\left[ \frac{\Delta E(\text{Sn})}{\Delta E(\text{Pb})} \right]^2 = \left[ \frac{0.34 \text{ V}}{0.86 \text{ V}} \right]^2 = 0.395.$$
 (8)

Indeed, the EMF calculated for the nonrelativistic lead toy model is similar to the analogous tin-model reaction, treated at fully relativistic level. It also explains why the analogous reaction (1) for tin is unknown.

In conclusion, the lead-acid battery belongs to those phenomena whose characteristic features are due to the relativistic dynamics of fast electrons when they move near a heavy nucleus. In this case the main actors are the 6s electrons of lead, in the substances involved. This insight may not help one to improve the lead battery, but it might be useful in exploring alternatives. Finally, we note that cars start due to relativity.

P.P. and P.Z.-E. belong to the Finnish Center of Excellence in Computational Molecular Science (CMS) and used computer resources at CSC, Espoo, Finland. P.Z.-E. acknowledges Magnus Ehrnrooths Stiftelse and Finnish Cultural Foundation. R.A., A.B., and P.L. are grateful for time on Swedish Supercomputing facilities and for financial support from the Swedish Research Council (VR) and Formas Council.

- \*rajeev.ahuja@fysik.uu.se
- †pekka.pyykko@helsinki.fi
- ‡patryk.ze@cornell.edu
- [1] G. Planté, C.R. Hebd. Seances Acad. Sci. 50, 640 (1860).
- [2] P. Kurzweil, J. Power Sources 195, 4424 (2010).
- [3] J. J. Esperilla, J. Félez, G. Romero, and A. Carretero, Simul. Model. Pract. Theory 15, 82 (2007).
- [4] J.J. Esperilla, J. Félez, G. Romero, and A. Carretero, J. Power Sources 165, 436 (2007).
- [5] J. C. Phillips, *Bonds and Bands in Semiconductors* (Academic, New York, 1973), pp. 16–17.
- [6] J. P. Desclaux and P. Pyykkö, Chem. Phys. Lett. 29, 534 (1974).
- [7] P. Pyykkö, Adv. Quantum Chem. 11, 353 (1979).
- [8] P. Pyykkö, Chem. Rev. 88, 563 (1988), see Fig. 11.
- [9] N. E. Christensen, S. Satpathy, and Z. Pawlowska, Phys. Rev. B 34, 5977 (1986).
- [10] A. Y. Liu, A. Garcia, M. L. Cohen, B. K. Godwal, and R. Jeanloz, Phys. Rev. B 43, 1795 (1991).
- [11] M. J. Verstraete, M. Torrent, F. Jollet, G. Zérah, and X. Gonze, Phys. Rev. B 78, 045119 (2008).
- [12] A. Hermann, J. Furthmüller, H.W. Gäggeler, and P. Schwerdtfeger, Phys. Rev. B 82, 155116 (2010).
- [13] G. Planté, Recherches sur l'Électricité de 1859 à 1879 (Gauthier-Villars, Paris, 1883).
- [14] H. J. Terpstra, R. A. de Groot, and C. Haas, Phys. Rev. B 52, 11690 (1995).
- [15] U. Häussermann, P. Berastegui, S. Carlson, J. Haines, and J.- M. Leger, Angew. Chem., Int. Ed. 40, 4624 (2001).
- [16] D. J. Payne, J. Mater. Chem. 17, 267 (2007).
- [17] M. Heinemann, H.J. Terpstra, C. Haas, and R.A. de Groot, Phys. Rev. B 52, 11740 (1995).
- [18] D. J. Payne, Chem. Phys. Lett. **411**, 181 (2005).
- [19] D. J. Payne, J. Electron Spectrosc. Relat. Phenom. 169, 26 (2009).
- [20] J. R. Anderson and A. V. Gold, Phys. Rev. 139, A1459 (1965).
- [21] T.L. Loucks, Phys. Rev. Lett. 14, 1072 (1965).
- [22] J. A. Duisman and W. F. Giauque, J. Phys. Chem. 72, 562 (1968).
- [23] See supplementary material at <a href="http://link.aps.org/supplemental/10.1103/PhysRevLett.106.018301">http://link.aps.org/supplemental/10.1103/PhysRevLett.106.018301</a> for information about details of structural parameters, details of calculations, and data for the toy model.
- [24] BAND2009.01 rev. 21855, http://www.scm.com.
- [25] K. Koepernik and H. Eschrig, Phys. Rev. B 59, 1743 (1999).
- [26] S. H. Vosko, L. Wilk, and M. Nusair, Can. J. Phys. 58, 1200 (1980).
- [27] L. A. Constantin, J. P. Perdew, and J. M. Pitarke, Phys. Rev. B 79, 075126 (2009).
- [28] S. Grimme, J. Comput. Chem. 27, 1787 (2006).
- [29] J. P. Perdew and Y. Wang, Phys. Rev. B 45, 13 244 (1992).
- [30] D. R. Lide, CRC Handbook of Chemistry and Physics (CRC Press, Boca Raton, FL, 1993), 74th ed.
- [31] E. van Lenthe, A.E. Ehlers, and E. Baerends, J. Chem. Phys. 110, 8943 (1999).
- [32] A. Holleman and N. Wiberg, in *Lehrbuchder Anorganischen Chemie*, 101. Auflage, edited by N. Wiberg (Walter de Gruyter, Berlin, 1995), p. 985.
- [33] J. P. Desclaux, At. Data Nucl. Data Tables 12, 311 (1973).