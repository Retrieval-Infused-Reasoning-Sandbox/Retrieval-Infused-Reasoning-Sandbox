![](_page_0_Picture_3.jpeg)

## **Density Functional Theory Studies of the Electronic Structure of Solid State Actinide Oxides**

Xiao-Dong Wen, Richard L. Martin, Thomas M. Henderson, and Gustavo E. Scuseria

<sup>†</sup>Theoretical Division, Los Alamos National Laboratory, Los Alamos, New Mexico 87545, United States

Department of Chemistry and Department of Physics and Astronomy, Rice University, Houston, Texas 77251, United States

![](_page_0_Picture_8.jpeg)

#### **CONTENTS**

| 1. Introduction                                   | 1063 |
|---------------------------------------------------|------|
| 2. Theoretical Methods                            | 1063 |
| 3. Applications to Actinide Oxides                | 1066 |
| 3.1. Experimental Results                         | 1067 |
| 3.2. Semilocal Functionals: LDA/GGA               | 1069 |
| 3.3. DFT+U                                        | 1072 |
| 3.4. DMFT                                         | 1078 |
| 3.5. SIC                                          | 1081 |
| 3.6. Hybrid Functionals (PBEh and HSE)            | 1084 |
| 3.6.1. PBEh                                       | 1084 |
| 3.6.2. HSE                                        | 1086 |
| 4. The HSE Perspective: Successes and Limitations | 1090 |
| 5. Concluding Remarks                             | 1091 |
| Author Information                                | 1091 |
| Corresponding Author                              | 1091 |
| Notes                                             | 1091 |
| Biographies                                       | 1092 |
| Acknowledgments                                   | 1093 |
| References                                        | 1093 |
|                                                   |      |

#### 1. INTRODUCTION

The actinide oxides have been extensively studied in the context of the nuclear fuel cycle. They are also of fundamental interest as members of a class of strongly correlated materials, the Mott insulators.1 Their complex physical and chemical properties make them challenging systems to characterize, both experimentally and theoretically.<sup>2</sup> Chiefly, this is because actinide oxides can exhibit both electronic localization and electronic delocalization and have partially occupied f orbitals, which can lead to multiple possibilities for ground states. Of particular concern for theoretical work is that the large number of competing states display strong correlations which are difficult to capture with computationally tractable methods.

There have been several recent reviews of actinide chemistry and physics. Edelstein and Lander survey many of the experimental issues associated with the actinide oxides in *The* Chemistry and Physics of the Actinide and Transactinide Elements, edited by Morss et al.,3 while Santini et al.4 review the evidence for multipolar interactions in f-electron systems. Another valuable review by Moore and van der Laan<sup>5</sup> focuses on the actinide metals and their properties. In this work, we limit ourselves to a discussion of the theoretical tools used to describe the electronic structure of actinide oxides and review several applications and what has been learned from them. We further concentrate on techniques that utilize full periodic boundary conditions. The texts by Hoffmann<sup>6</sup> and by Albright, Burdett, and Whangbo are recommended for an introduction to bonding concepts in solid state chemistry. For an entry to the literature on cluster approximations, we refer the reader to early DFT-X $\alpha$  work by Rosen and Ellis<sup>8,9</sup> and more recent wave function-based investigations by Bagus and co-workers. 10 The specific approximations on which we will focus are the localdensity approximation (LDA) and the generalized gradient approximation  $(GGA)^{11}$  of density functional theory (DFT), a popular semiempirical modification to LDA and GGA (DFT +U), 12 and a screened hybrid density functional (HSE). 13,14 In several instances, we will also compare our results with those obtained from the self-interaction correction (SIC)<sup>15</sup> and dynamical mean field theory (DMFT).16 In discussing applications, we will emphasize the lattice constants, electronic density-of-states (DOS), the band gap, and some magnetic and optical properties. The early actinide oxides are particularly interesting, and we will discuss the electronic structure of the  $AnO_2$  series (An = U, Np, and Pu) in some detail. However, we will also briefly cover other members of the  $AnO_2$  series (An = Th-Es), as well as  $U_3O_8$  and the sesquioxide  $Pu_2O_3$ . Although most of the calculations discussed in this review have been previously presented in the literature, we also report below unpublished original results obtained with the VASP (Vienna Ab-initio Simulation Package)<sup>17</sup> and Gaussian codes.<sup>18</sup>

We begin by reviewing the computational approximations in section 2 before turning to specific applications in section 3. The HSE perspective on strongly correlated systems is presented in section 4. Concluding remarks can be found in section 5.

#### 2. THEORETICAL METHODS

Density functional theory has proven to be a very powerful tool for the quantitative prediction of material properties in both chemistry and solid-state physics. Put briefly, the main idea in density functional theory is to express the energy as a functional of the electron density of the system, which the Hohenberg-

Special Issue: 2013 Nuclear Chemistry

Received: September 6, 2012 Published: December 19, 2012

![](_page_0_Picture_20.jpeg)

Kohn theorems guarantee is formally possible. In the vast majority of applications, one accomplishes this by working within the framework of Kohn–Sham theory, in which the energy is given by

$$\begin{split} E_{\text{KS}} &= \langle \Phi | T | \Phi \rangle + \int n(\vec{r}) v_{\text{ext}}(\vec{r}) + \frac{1}{2} \int \frac{n(\vec{r_1}) n(\vec{r_2})}{|\vec{r_1} - \vec{r_2}|} \\ &+ E_{\text{vc}}[n] \end{split}$$

where  $|\Phi\rangle$  is a single-determinant wave function with density n. The first term in the energy accounts for the bulk of the kinetic energy, the second for the interactions between electrons and the external potential,  $v_{\rm ext}(\vec{r})$  (which typically includes the electron–nuclear interaction and any external fields), and the third term, the classical Coulomb repulsion energy for charge density n, accounts for the bulk of the repulsion between electrons. The remainder of the kinetic energy and the electron–electron repulsion energy are given by the last piece,  $E_{\rm xc}[n]$ , which is known as the exchange–correlation functional and which is, in principle, a functional of the density alone. In practice, the exchange–correlation functional must be approximated.

Typical approximations for the exchange—correlation functional are *semilocal* in nature. That is, they write the exchange—correlation energy as

$$E_{\rm xc} = \int \varepsilon_{\rm xc}(\vec{r})$$

where the exchange-correlation energy density,  $\varepsilon_{xc}$ , at the point  $\vec{r}$  depends only on the density at that point (LDA), as well as its derivatives (GGA) and the local kinetic energy density (meta-GGAs). However, these first three generations of functionals, LDA, GGA, and meta-GGA, 19 have a glaring weakness: they are incapable of describing what have come to be known as strongly correlated materials. In fact, the definition of strongly correlated systems sometimes seems to mean those materials for which the conventional semilocal density functional approximations dramatically fail! These examples are typically found in compounds of the elements of the first transition metal series, and the lanthanide and the actinide rows, where the orbitals participating in the bonding are compact, leading to weak overlap with their neighbors. For example, the LDA predicts UO2 to be a ferromagnetic metal. 20,21 It is, in fact, an antiferromagnetic Mott insulator. 22 This problem is not remedied in subsequent generations of semilocal density functional approximations (GGA, meta-GGA). The major deficiency of these approximations is the self-interaction error,<sup>23</sup> which is particularly severe for systems with partially occupied d- or f-states, once again because of their small radial extent.

One-electron self-interaction error, which is the kind we are most concerned with here, is most readily understood as inexactness for one-electron systems. In practice, its origins lie in the form used for the Coulomb repulsion between electrons. This Coulomb repulsion does not vanish for one-electron systems. In a wave function theory such as Hartree—Fock, it is exactly canceled by self-exchange. With approximate exchange—correlation functionals, however, the cancellation of the self-Coulomb repulsion with self-exchange is incomplete. Typically, one-electron self-interaction error leads semilocal functionals to artificially delocalize electrons in order to mitigate this self-interaction. In addition, this error causes the potential at long-range to be different from the Coulombic 1/r.

The conceptually simplest approach to overcoming the difficulties caused by self-interaction is to explicitly eliminate it from the energy in the Perdew–Zunger self-interaction correction (SIC). That is, one writes

$$E_{\text{SIC}} = E_{\text{KS}} - \sum_{i} \left( \frac{1}{2} \int \frac{n_{i}(\vec{r_{i}}) n_{i}(\vec{r_{2}})}{|\vec{r_{1}} - \vec{r_{2}}|} + E_{\text{xc}}[n_{i}] \right)$$

where the sum runs over all occupied orbitals in the Kohn–Sham determinant  $|\Phi\rangle$ . This exactly eliminates the self-interaction error in one-electron systems and is assumed to reduce or eliminate the self-interaction error also in many-electron systems, though we note that there is no unique definition of the self-interaction error for a many-electron system treated with a conventional semilocal exchange–correlation functional. We should also note that the SIC is not trivial to implement or to apply, since the self-interaction correction is not invariant to unitary transformations among the occupied levels. In practice, the SIC leads to electronically localized orbitals in molecules and to Wannier-type functions in solids.

The SIC approximation has been quite successful for treating strongly correlated systems. However, the SIC vanishes for a metal, so when it is applied to an LDA or GGA metallic solution for an oxide, special approaches must be taken to transform the delocalized states of the metallic LDA/GGA solutions to the localized orbital space to which the correction is applied. This entails *a priori* knowledge of which orbitals should be singled out for special treatment.<sup>23</sup>

A second route toward handling strongly correlated systems is by applying models that empirically address the self-interaction error by modifying the electron repulsion directly via Hubbard U parameters<sup>24,25</sup> in what is known as DFT+U. In the DFT+U method, electrons are divided into two classes: delocalized s and p electrons that are well described by LDA (GGA) and localized d or f electrons for which an orbital-dependent term is added to describe Coulomb d–d or f–f interactions:  $^{1}/_{2}U\sum_{i\neq j}n_{i}n_{j}$ , where  $n_{i}$  are d or f orbital occupancies. The original LDA+U functional was introduced in 1991 by Anisimov, Zaanen, and Andersen<sup>24</sup> and was written as

$$\begin{split} E_{\text{tot}}^{\text{LDA}+\text{U}}[\rho_{\sigma}(r), \{n_{\sigma}\}] \\ &= E^{\text{LDA}}[\rho_{\sigma}(r)] + E^{\text{U}}[\{n_{\sigma}\}] - E_{\text{dc}}[\{n_{\sigma}\}] \end{split}$$

where  $\sigma$  denotes the spin index,  $\rho_{\sigma}(r)$  is the electron density for spin- $\sigma$  electrons and  $\{n_{\sigma}\}$  is the density matrix of d or f electrons for spin- $\sigma$ ; the first term is the standard LDA energy functional, the second term for the electron–electron Coulomb interaction, and the last one for the double counting term, which removes an averaged LDA energy contribution of these d or f electrons from the LDA energy.

These approaches shift selected atomic orbital spaces in energy, thereby adjusting their occupations so as to counterbalance the effects of self-interaction and, typically, also introducing a gap. The empirical parameter U is material-dependent and must be carefully chosen so as to counterbalance self-interaction without introducing errors in the opposite direction. At the most basic level, the LDA+U correction tends to drive the correlated orbital m occupation numbers  $n_{m\sigma}$  to integer values of 0 or 1. This in turn produces, under appropriate conditions, insulating states out of conducting LDA states, and the Mott insulating state of several

systems is regarded as being well described by LDA+U at the band theory level. The same physics is of course captured by GGA+U. However, the most important correlation effects in metals and fluctuation-induced mass renormalization are missing from LDA/GGA+U.<sup>26</sup>

Dynamical mean-field theory (DMFT)<sup>27,28</sup> typically builds on +U approaches, which, when applied to a specific atomic orbital space in the metallic DFT solution, define an orbital subspace for an embedding treatment. DMFT adds important new physics by mapping this orbital space onto an impurity Hamiltonian model, which is then solved using established many-body techniques. A great strength of DMFT is that it can handle the atomic multiplets which arise from partially filled localized orbitals. In practice, the localized orbital space is assumed to be in a spherical environment, so that the localized problem may be solved using the Coulomb integrals  $F_n$  familiar from Slater's theory of atomic structure. This is not unlike the early days of DFT when muffin-tin approximations were invoked in the solution of the Kohn-Sham equations. Unfortunately, the Coulomb parameters must be screened, and this is typically done by simply scaling the atomic values by an additional empirical constant. In the case of actinides, this entails estimates of screening for the atomic F<sub>0</sub>, F<sub>2</sub>, F<sub>4</sub>, and F<sub>6</sub> integrals.

Hybrid density functional theory<sup>29,30</sup> is a particularly promising route toward the correct description of strongly correlated systems. In hybrid DFT,<sup>29,30</sup> the self-interaction error of conventional DFT is partly corrected by incorporating a fixed portion of exact, nonlocal Hartree–Fock (HF) exchange into the exchange–correlation functional:

$$E_{xc} = aE_{x}^{HF} + (1 - a)E_{x}^{DFA} + E_{c}^{DFA}$$

where  $E_{\rm x}^{\rm HF}$  is the full nonlocal Hartree–Fock exchange interaction,  $E_{\rm x}^{\rm DFA}$  is the exchange energy from a conventional semilocal density functional approximation (DFA) and  $E_c^{DFA}$  is the corresponding DFA for the correlation energy; the parameter a is material independent. In the PBEh hybrid functional, the value of this parameter (0.25 or 25%) is determined from solid arguments.<sup>29</sup> We note in passing that the PBEh functional is identical to PBE0 and PBE1PBE; in this review, we use the label PBEh for consistency with our previous publications, but these acronyms mean the same thing. Hybrid DFT significantly improves the descriptions of d- or f-electron systems, generally predicting the correct insulating and magnetic behavior in Mott insulating cases. Unfortunately, it cannot at present address the multiplet problem associated with open shells of electrons. Moreover, calculating the nonlocal exchange energy and exchange potential can be very expensive in extended systems, particularly as the gap narrows. Finally, the fraction of HF exchange should ideally be a dynamic variable, not static as in the simple hybrid functional. That is, one expects the fraction of exact exchange to be smaller in a metallic system than in an insulator; this cannot be accommodated with a simple static hybrid functional that includes a universal mixing parameter. For typical semiconducting systems, hybrids such as PBEh tend to overcorrect semilocal approximations.

An important development for the application of hybrid DFT to solids was the development of "screened" hybrids, where the long-range portion of HF exchange is eliminated. This approach is especially adept for treating solid state systems while retaining the same accuracy as the unscreened hybrid for molecules. To avoid confusion, we emphasize that this screened functional is still static in the amount of HF exchange present in

the energy expression. It does not incorporate dynamic screening.

In screened hybrids, the concept of range separation takes center stage, as the interelectronic Coulomb potential is split into short-range (SR) and long-range (LR) components:

$$\frac{1}{r_{12}} = S_{\omega}(r_{12}) + L_{\omega}(r_{12}) = \frac{\text{erfc}(\omega r_{12})}{r_{12}} + \frac{\text{erf}(\omega r_{12})}{r_{12}}$$

where the interelectronic distance is  $r_{12} = |\vec{r}_1 - \vec{r}_2|$ , erf is the error function and governs long-range behavior, erfc is its short—range complement, and the screening length  $\omega$  determines the extent of short-range interactions. The HSE screened hybrid functional takes the form of the PBEh hybrid at short-range and the PBE GGA at long-range,

$$E_{\rm xc}^{\rm HSE} = aE_{\rm x}^{\rm HF,SR}(\omega) + (1-a)E_{\rm x}^{\rm PBE,SR}(\omega) + E_{\rm x}^{\rm PBE,LR}(\omega) + E_{\rm c}^{\rm PBE}$$
  
 $+ E_{\rm c}^{\rm PBE}$   $a = 1/4$ 

and can be viewed as an interpolation between these two limits, as discussed by Heyd, Scuseria, and Enzerhof (HSE).  $^{13,14}$  This functional has proven very useful for studies of semiconductors and insulators,  $^{31}$  particularly for the calculation of reliable band gaps. HSE dramatically reduces the computational cost for both localized (Gaussian) basis sets and plane-waves compared with unscreened calculations in periodic systems and large molecules. The value for the empirical screening parameter  $\omega$  was chosen to reproduce PBEh heats of formation in molecules with some consideration given to band gaps in solids. Values in the range of approximately 0.2-0.3 Å $^{-1}$ , corresponding to a screening length of 3-5 Å, give results of roughly similar quality in solids. In our work,  $\omega$  is defined as 0.207 Å $^{-1}$  as originally suggested by Heyd et al.  $^{13}$ 

The main features of HSE for our purposes are relatively simple to understand. In the exact theory, the long-range portion of the nonlocal Hartree-Fock exchange interaction is canceled by long-range correlations that are not accounted for in standard semilocal functionals. In HSE, this cancellation is built in automatically, resulting in significant improvements upon hybrid functionals such as PBEh and significant computational savings relative to many-body methods where the cancellation is calculated dynamically. In addition to improving on the description of semiconductor band gaps, HSE delivers accurate lattice constants and elastic properties, as well as defect formation energies, densities of states, and optical properties. Most important, HSE provides a balanced description of electronically localized and electronically delocalized states, and can also describe magnetic ordering. These strengths are critical for the proper theoretical treatment of actinide materials.

Relativistic effects are also important to consider in the actinides. In relativistic expansions of the wave function, the corrections that arise in first order include the scalar relativistic terms (the mass-velocity and one-electron Darwin operators) and the one-electron spin—orbit interaction. The scalar terms are generally treated with effective core potentials or pseudopotentials, which replace the core electrons with an effective operator that is constructed from a relativistic atomic wave function. The dominant scalar terms associated with the relativistic core, as well as orthogonality constraints between valence and core wave functions, are then represented through the effective potential. This is the usual approach taken by quantum chemistry codes such as Gaussian. Alternatively, a

frozen relativistic core is sometimes used to accomplish the same thing, as in the PAW approach used in VASP, for example. There are two predominat approaches to including the spin-orbit operator. It is possible to omit the spin-orbit terms and solve for the scalar relativistic wave function, the Russell-Saunders or LS coupling limit, or define a zero-order wave function by explicitly including the spin-orbit term and iterating that wave function to self-consistency, the j-j limit. Neither of these is strictly appropriate, of course, since the actual wave function generally displays intermediate coupling, that is, some mixture of the two. This can be approached by evaluating the spin-orbit term from the LS coupled result using first-order perturbation theory or by allowing additional configuration interaction with the j-j coupled wave function as the reference state. Results using the LS and j-j limits seem to be compatible for the properties of interest in this review, although the influence of intermediate coupling is only now beginning to be addressed. 10 The relativistic many body theory to describe the electronic structure in atoms and molecules has recently been reviewed by many research groups, 33-36 and a number of textbooks available discussed detailed information on the topic. 37-39

In summary, the strong-correlation problem has been around many years, and a number of approaches have been proposed as solutions. <sup>40</sup> Here, we present new results and review some old results in order to gain an overview of the specific successes and failures of these approximations in the actinide oxides. Calculations were carried out for this review with the Gaussian and VASP<sup>17</sup> codes using Gaussian-type and plane wave basis-sets with periodic boundary conditions, respectively.

![](_page_3_Figure_3.jpeg)

**Figure 1.** The fluorite crystal structure exhibited by  $AnO_2$ , where An = U, Np, or Pu. Red spheres represent O atoms; green spheres represent An atoms.

#### 3. APPLICATIONS TO ACTINIDE OXIDES

In this section, we will first discuss some experimental results on the actinide oxides and then review applications of the various theoretical methods that we have just introduced. Because our own work has focused on the use of hybrid functionals, they will form the bulk of our discussion. However, before we discuss either the experimental or the theoretical results, it may prove useful to summarize the most important features here.

Table 1. The Appearance, Band Gap (eV), Melting Point (K), Density (g/cm³), An-O Bonding Energy, and Pauling's Electronegativity for UO<sub>2</sub>, NpO<sub>2</sub>, and PuO<sub>2</sub><sup>47</sup>

|                                  | $UO_2$              | $NpO_2$             | $PuO_2$             |
|----------------------------------|---------------------|---------------------|---------------------|
| color                            | black               | green               | dark yellow         |
| band gap (eV)                    | 2.149               | $2.80^{48}$         | 2.85 <sup>48</sup>  |
| lattice constant (Å)             | 5.470 <sup>49</sup> | 5.420 <sup>50</sup> | 5.398 <sup>51</sup> |
| bulk modulus (GPa) <sup>52</sup> | 207                 | 200                 | 178                 |
| melting point (K)                | 3140                | 2820                | 2673                |
| density (g/cm <sup>3</sup> )     | 10.97               | 11.10               | 11.50               |
| An-O bonding energy (kJ/mol)     | 759.4 ± 13.4        | $718.4 \pm 41.8$    | $715.9 \pm 33.9$    |
| Pauling's electronegativity      | 1.38 for U          | 1.36 for Np         | 1.28 for Pu         |

![](_page_3_Figure_9.jpeg)

**Figure 2.** The energy-dependent photoemission data of Cox et al. <sup>53</sup> is presented. The intensity of occupied levels at the band edge follows the resonant (108 eV) and antiresonant (92 eV) behavior of the 5f orbital photoemission cross section, confirming that it is principally U 5f in character. Reprinted with permission from ref 53. Copyright 1987 American Physical Society.

As we have said, we are interested primarily in  $UO_2$ ,  $NpO_2$ , and  $PuO_2$ . Experimentally, all three are insulators. They can be classified according to the origin of the insulating gap. If it arises from correlations among the f-electrons, the oxide is a Mott insulator, and the gap is associated with  $f \rightarrow f$  transitions. It is also possible that ligand to metal transitions, O  $2p \rightarrow An$  Sf, occur at lower energies than the correlation driven Mott gap, leading to a charge-transfer insulator.  $UO_2$  is a Mott insulator and  $PuO_2$  a charge-transfer insulator, while it is not clear whether  $NpO_2$  is a Mott insulator or a charge-transfer insulator. Where  $UO_2$  displays antiferromagnetic ordering,  $PuO_2$  is paramagnetic and  $NpO_2$  shows multipole ordering.

Semilocal functionals generally predict these oxides to be ferromagnetic metals. Adding a Hubbard U parameter opens a gap whose magnitude depends on the value chosen for U. With a typical value of U=4 eV, DFT+U correctly predicts  $UO_2$  to be a Mott insulator and  $PuO_2$  to be a charge-transfer insulator. It also predicts  $NpO_2$  to be a charge-transfer insulator, though as we have said, experimentally this may or may not be the case. Neither dynamical mean-field theory nor self-interaction corrected DFT have been widely applied to these three oxides.  $SIC^{41,42}$  calculations find  $UO_2$  to be metallic; however there is a very low-lying antiferromagnetic insulating state just 100 meV higher in energy, characterized by a charge transfer gap. The SIC also predicts  $NpO_2$  and  $PuO_2$  to be charge-transfer insulators. The two DMFT calculations  $^{43,44}$  available in the literature differ in their predictions; in one case, all three

![](_page_4_Figure_1.jpeg)

**Figure 3.** (top) Valence band spectra of UO<sub>2</sub> along the azimuth  $\Gamma$ –X. The dispersion of the dominant 5f band is indicated by the solid line. Reprinted with permission from ref 54. Copyright 2008 John Wiley & Sons. (bottom) A combination of XPS ( $h\nu$  = 1486 eV of photons) and BIS (E = 915 eV of electrons). For XPS, the reference point is the valence band maximum where the XPS spectrum ends. Reprinted with permission from ref 55. Copyright 2011 American Physical Society.

members of this series are found to be charge-transfer insulators; in the other all are Mott insulators. Hybrid functional approaches correctly predict that  $UO_2$  is a Mott insulator and  $PuO_2$  a charge-transfer insulator. They find the gap in  $NpO_2$  to be of Mott character.<sup>20</sup>

### 3.1. Experimental Results

We now briefly review selected experimental observations for the actinide dioxides of interest. Figure 1 shows the well-known fcc  $CaF_2$  fluorite structure, in which the actinide dioxides  $AnO_2$  (An = U, Np, and Pu) appear with eight-coordinated An and four-coordinated O. If one takes oxygen as divalent, the stoichiometry implies  $An^{4+}$  and  $5f^2$ ,  $5f^3$ , and  $5f^4$  configurations for U, Np, and Pu atoms in  $AnO_2$ , respectively. Table 1 lists some physical properties for  $UO_2$ ,  $NpO_2$ , and  $PuO_2$ .

 ${
m UO_2}$  is insulating in its ground state (with a band gap  $\Delta$  = 2.1 eV<sup>49</sup>) and orders antiferromagnetically (AFM) with a Néel temperature of  $T_{
m N}$  = 30.8 K. It is experimentally known to have a transverse 3-k magnetic structure along (111) and oxygen sublattice distortion of the same symmetry.<sup>46</sup>

The partially filled f-orbitals suggested by the formal ionic occupations for An<sup>4+</sup> imply that the density of states (DOS) at the occupied band edge should have An 5f orbital character. This was confirmed by the energy-dependent photoemission

![](_page_4_Figure_8.jpeg)

**Figure 4.** (top) O Kα emission and O 1s XA spectra of  $PuO_2$ . Reprinted with permission from ref 57. Copyright 2008 American Institute of Physics. (middle) Calculated O 2p states in  $PuO_2$  from HSE (solid blue line) and PBE+U (dashed blue line, current work). (bottom) Total density of states of  $PuO_2$  from HSE (solid black line) and PBE+U (dashed black line, current work). The Fermi level is set to zero.

![](_page_4_Figure_10.jpeg)

**Figure 5.** Optical band gap of  $PuO_2$  measured on an epitaxially grown thin film. Reprinted with permission from ref 48. Copyright 2012 American Institute of Physics.

results (see Figure 2) of Cox et al.,<sup>53</sup> who demonstrated that the peak at the band edge grows stronger at the maximum of the atomic 5f orbital cross section and disappears at its minimum, thereby establishing its dominant 5f orbital character.

More recently, high-resolution photoemission (PES) spectra <sup>54</sup> reproduced in Figure 3 (top) were recorded at photon energies between 16 and 87 eV along the  $\Gamma$ -X azimuth of the Brillouin zone, indicating the width of this 5f peak to be ~130 meV, corresponding to a small but observable dispersion in the 5f band. The low-energy unoccupied bands were recently

![](_page_5_Figure_1.jpeg)

**Figure 6.** The band structure of UO<sub>2</sub> using linear muffin-tin potentials in the atomic sphere approximation (LMTO-ASA). Reprinted with permission from ref 71. Copyright 1979 EDP sciences.

shown to be dominantly 5f in character by the X-ray absorption (XAS) experiments by Yu et al. <sup>55</sup> (see Figure 3 bottom). The combination of the PES and XAS experiments firmly establish  $\rm UO_2$  as an f-f Mott-Hubbard insulator, where the electronic repulsion between f electrons is responsible for the insulating state.

Similar experiments on  $PuO_2$  tell a different story. Figure 4 (top) displays the measured O  $K\alpha$  emission and O 1s absorption spectra of single-crystal  $PuO_2$ , measured with the closed source setup by Modin et al. <sup>56,57</sup> Notice that the O  $K\alpha$  emission spectrum, which probes the occupied states, does not exhibit a two peak structure as is the case in  $UO_2$ . This is potentially tied to changes in the band structure, as well as the different selection rules in effect compared with PES (the O  $K\alpha$  emission essentially reflects the O 2p partial DOS). For comparison, the calculated O 2p states and total density of states of  $PuO_2$  from both HSE and GGA/PBE+U (this work) are also reproduced in Figure 4 (middle and bottom). One can

Table 2. The Elastic Constants (in GPa) of UO<sub>2</sub> Calculated Using Ultrasoft Pseudopotentials by Pickard et. al., <sup>78</sup> Where  $C' = 1/2(C_{11} - C_{12})$  and  $B = 2/3(C_{11} + 2C_{12})$ 

|                    | $C_{11}$ | $C_{12}$ | $C_{44}$ | C'    | В     |
|--------------------|----------|----------|----------|-------|-------|
| GGA                | 318.2    | 96.0     | 43.1     | 111.1 | 170.1 |
| expt <sup>83</sup> | 389.3    | 118.7    | 59.7     | 135.3 | 208.9 |

see the good agreement between experiment and our HSE result. We will return to this later. A more direct probe of the valence bands is given by the angle-resolved photoemission (ARPES) experiments<sup>58</sup> on a single-crystal quality thin film of  $PuO_2$ . In that work, it was found that, unlike  $UO_2$ , dispersion in  $PuO_2$  is of the order of several electronvolts.

Turning now to NpO<sub>2</sub>, Np<sup>4+</sup> has a 5f³ configuration, which in the ionic limit indicates a strongly magnetic  $\Gamma_8$  quartet ground state. The magnetic ordering in NpO<sub>2</sub>, however, has proven extremely difficult to determine. F9 Early magnetic susceptibility measurements suggested antiferromagnetic order with a Néel temperature  $T_{\rm N}=25~{\rm K_s}^{60}$  as in UO<sub>2</sub>. However, neutron diffraction indicated no discernible magnetic ordering down to  $T=2.4~{\rm K}$ . Mossbauer experiments suggested a very small amount of line broadening developing below  $T_{\rm N}$ , indicating a moment of  $\sim$ 0.01  $\mu_{\rm B}$ . This led to suggestions of a Np³+ valence in NpO<sub>2</sub> since Np³+ can have a singlet ground state. NpO<sub>2</sub> is now widely recognized as the archetypal compound for magnetic multipole ordering. We will discuss this in more detail in a later section.

The atomic ground state of  $Pu^{4+}$  is  $5f^4$  ( $^5I_4$ ), which generates a singlet  $\Gamma_1$  ground state in the dioxide, as confirmed by the measurement of the susceptibility. There are suggestions, however, that antiferromagnetic exchange enhancements may account for some of the difficulties in fitting the low-temperature magnetic susceptibility.

The colors of the actinide dioxides form an interesting sequence, black for UO<sub>2</sub>, green for NpO<sub>2</sub>, and yellow to olive green for PuO<sub>2</sub> (Table 1), depending on the particle size, temperature, and method of production. These colors would lead one to predict that all three are insulators. Optical band gaps of 1.8<sup>22</sup> and 0.4 eV<sup>66</sup> for PuO<sub>2</sub> and NpO<sub>2</sub>, respectively, have been estimated from the activation energy for electronic conduction using pressed powders. Note that these barriers can be significantly lower than the band gap and are very sensitive

![](_page_5_Figure_11.jpeg)

Figure 7. Total density of states of UO<sub>2</sub> from Kelly and Brooks in the "perfect localization" approximation. The f-levels appear between the O 2p and U 6d bands and are split by 1 eV due to spin—orbit coupling. Reprinted with permission from ref 74. Copyright 1980 Elsevier.

![](_page_6_Figure_1.jpeg)

**Figure 8.** Calculated density of states of paramagnetic and ferromagnetic (with majority and minority spin)  $UO_2$  from GGA by Boettger et al. <sup>79</sup> Reprinted with permission from ref 79. Copyright 2000 John Wiley & Sons.

Table 3. Theoretical Lattice Parameters (au) and Bulk Modulii (GPa) Obtained for UO<sub>2</sub> with the LCGTO-FF Method for Various Approximations<sup>a</sup>

|                             | DFT | $\operatorname{spin}^c$ | ${ m relativistic}^d$ | latt.<br>const.<br>(Å) | B<br>(GPa) | type      |
|-----------------------------|-----|-------------------------|-----------------------|------------------------|------------|-----------|
| LMTO-<br>ASA <sup>b82</sup> | LDA | NSP                     | SR                    | 5.248                  | 261        | metal     |
| LCGTO-<br>FF <sup>e</sup>   | LDA | NSP                     | SR                    | 5.285                  | 250        | metal     |
| LCGTO-<br>FF <sup>e</sup>   | LDA | NSP                     | FR                    | 5.327                  | 226        | metal     |
| LCGTO-<br>FF <sup>e</sup>   | GGA | NSP                     | SR                    | 5.380                  | 214        | metal     |
| LCGTO-<br>FF <sup>e</sup>   | GGA | NSP                     | FR                    | 5.428                  | 199        | metal     |
| LCGTO-<br>FF <sup>e</sup>   | GGA | SP                      | SR                    | 5.428                  | 205        | metal     |
| expt <sup>83</sup>          |     |                         |                       | 5.470                  | 209        | insulator |

"The data is from ref 79. "LMTO-ASA, linear muffin-tin-orbital (LMTO) method with restricted atomic sphere approximation. "NSP, non-spin-polarized; SP, spin-polarized. "SR, scalar-relativistic; FR, fully relativistic. "LCGTO-FF, linear combinations of Gaussian-type orbitals—fitting function.

to defects and vacancies (that is, the results depend on the quality of the samples used). McCleskey et al. 48 prepared single-crystal-quality epitaxial thin films of PuO<sub>2</sub> and NpO<sub>2</sub>

![](_page_6_Figure_7.jpeg)

Figure 9. The total DOS for  $UO_2$  from LDA and from PBE for the ferromagnetic solution at the experimental lattice constant. Reprinted with permission from ref 20. Copyright 2002 American Physical Society.

using the solution-based process of polymer-assisted deposition (PAD). Direct optical absorption measurements yield gaps of 2.80  $\pm$  0.1 and 2.85  $\pm$  0.1 eV at room temperature for PuO<sub>2</sub> (see Figure 5) and NpO<sub>2</sub>, respectively. As for magnetic properties, PuO<sub>2</sub> does not exhibit ordered moments even at low temperature, showing a paramagnetic state, which was confirmed by  $^{239}$ Pu nuclear magnetic resonance. UO<sub>2</sub> and NpO<sub>2</sub> have 3-k antiferromagnetic and multipole order, espectively.

#### 3.2. Semilocal Functionals: LDA/GGA

The local density approximation (LDA) and the generalized gradient approximation (GGA) have been extensively used to predict the properties of materials. Neither approximation provides a qualitatively correct description of the electronic structure of actinide oxides. Once again, both the LDA and the GGA predict UO<sub>2</sub>, PuO<sub>2</sub>, and Pu<sub>2</sub>O<sub>3</sub> in their ground states to be ferromagnetic conductors, while they are known to be insulators. <sup>22,49,70</sup>

To our knowledge, Kelly, Brooks, and Allen<sup>71</sup> reported the first band structure calculations for the actinide dioxides ThO<sub>2</sub> to CmO<sub>2</sub> in 1979. They utilized linear muffin-tin potentials in the atomic sphere approximation (LMTO-ASA) and found that the 5f levels decrease in energy and narrow with increasing atomic number due to actinide contraction. The dioxides were predicted to be metals (see Figure 6 for the band structure of UO<sub>2</sub>) except for ThO<sub>2</sub>, formally an f<sup>0</sup> species and a simple charge-transfer band insulator. From their calculated density of states, these authors argued that the positions of f states (relative to O 2p) were in crude agreement with experimental photoemission results,<sup>72</sup> even given the incorrect metallic behavior.

Later, Kelly and Brooks<sup>73,74</sup> performed calculations in which the f-orbitals were treated as semicore orbitals; that is, the U 5f orbitals were occupied by two electrons but not allowed to hybridize with the O 2p bands. This explicit localization of the electrons in the 5f orbitals significantly improved the lattice constants and introduced a gap between the O 2p derived bands and principally U 6d derived conduction bands of 5.35 eV (see Figure 7). The 5f levels were split by spin—orbit coupling into 5/2 and 7/2 sublevels separated by about 1 eV, with the former containing two electrons. While this approach generated a gap associated with 5f to 5f excitations characteristic of a Mott insulator, it did so for the wrong reasons; no contribution from correlation among the 5f electrons was considered. It did, however, point out the important physics of localizing the f-electron manifold. This explicit localization

Table 4. Summary of the Lattice Constant (Å), Bulk Moduli (GPa), Magnetic States, and Conductivity Type for Actinide Oxides across References

| authors                               | DFT                          | compound                                                                                                              | spin | latt. const.                        | B (GPa)                       | type                                                                                                 |
|---------------------------------------|------------------------------|-----------------------------------------------------------------------------------------------------------------------|------|-------------------------------------|-------------------------------|------------------------------------------------------------------------------------------------------|
| Kelly et al.<br>1979 <sup>71</sup>    | LMTO-ASA                     | $AnO_2$ (An = Th-Cm)                                                                                                  | NM   |                                     |                               | insulator (4.0 eV) for ThO <sub>2</sub> ;<br>metal for all the rest                                  |
| Kelly et al.<br>1980 <sup>73,74</sup> | LMTO-ASA                     | UO <sub>2</sub>                                                                                                       | NM   |                                     |                               | metal                                                                                                |
| Arko et al.<br>1986 <sup>75</sup>     | LAPW (LDA)                   | UO <sub>2</sub>                                                                                                       | NM   |                                     |                               | metal                                                                                                |
| Kelly et.al.<br>1987 <sup>93</sup>    | LMTO-ASA (LDA)               | UO <sub>2</sub>                                                                                                       | NM   | 5.295                               | 230                           | metal                                                                                                |
|                                       |                              | $PuO_2$                                                                                                               | NM   | 5.306                               | 190                           | metal                                                                                                |
|                                       |                              | $ThO_2$                                                                                                               | NM   | 5.533                               | 290                           | insulator, 4.1 eV                                                                                    |
| Goodman et al.<br>1992 <sup>94</sup>  | LDA                          | UO <sub>2</sub>                                                                                                       | NM   |                                     |                               | metal                                                                                                |
|                                       |                              | $PuO_2$                                                                                                               | NM   |                                     |                               | metal                                                                                                |
|                                       |                              | $CmO_2$                                                                                                               | NM   |                                     |                               | metal                                                                                                |
| Petit et al.<br>1996 <sup>82</sup>    | LMTO-ASA (LDA)               | UO <sub>2</sub>                                                                                                       | NM   | 5.270                               | 261                           | metal                                                                                                |
|                                       |                              | $ThO_2$                                                                                                               | NM   | 5.636                               | 209                           | metal                                                                                                |
| Xia et al.<br>2000 <sup>95</sup>      | LCAO-MO cluster calculations | PaO <sub>2</sub> , UO <sub>2</sub> , PuO <sub>2</sub> , AmO <sub>2</sub> ,<br>BkO <sub>2</sub> , and EsO <sub>2</sub> | NM   |                                     |                               | metals                                                                                               |
| Boettger et al. 2002 <sup>80</sup>    | LCGTO-FF (LDA)               | UO <sub>2</sub>                                                                                                       | NM   | 5.285                               | 250                           | metal                                                                                                |
| Maehira et al.<br>2007 <sup>76</sup>  | RLAPW (LDA)                  | ThO <sub>2</sub> , UO <sub>2</sub> , NpO <sub>2</sub> , and PuO <sub>2</sub>                                          | NM   |                                     |                               | metal for UO <sub>2</sub> , NpO <sub>2</sub> , and PuO <sub>2</sub> ; insulator for ThO <sub>2</sub> |
| Pickard et al.<br>2000 <sup>78</sup>  | plane-wave (GGA)             | UO <sub>2</sub>                                                                                                       | NM   | 5.474                               | 170                           | metal                                                                                                |
| Kudin et al.<br>2002 <sup>20</sup>    | Gaussian-type<br>(LDA/GGA)   | UO <sub>2</sub>                                                                                                       | FM   | 5.28 Å from LDA; 5.38<br>Å from GGA |                               | metal                                                                                                |
| Prodan et al.<br>2006 <sup>92</sup>   | Gaussian-type<br>(LDA/GGA)   | UO <sub>2</sub>                                                                                                       | FM   | 5.317 from LDA; 5.425 from PBE      | 239 from LDA; 206<br>from PBE |                                                                                                      |
|                                       |                              |                                                                                                                       | AFM  | 5.289 from LDA; 5.445 from PBE      | 216 from LDA; 186<br>from PBE | metal                                                                                                |
|                                       |                              | $PuO_2$                                                                                                               | FM   | 5.278 from LDA; 5.399<br>from PBE   | 229 from LDA; 189<br>from PBE | metal                                                                                                |
|                                       |                              |                                                                                                                       | AFM  | 5.285 from LDA; 5.412<br>from PBE   | 222 from LDA; 182<br>from PBE | metal                                                                                                |
|                                       |                              | $\beta$ -Pu <sub>2</sub> O <sub>3</sub>                                                                               | FM   | 3.690 from LDA; 3.790 from PBE      | 181 from LDA; 146<br>from PBE | metal                                                                                                |
|                                       |                              |                                                                                                                       | AFM  | 3.680 from LDA; 3.791 from PBE      | 175 from LDA; 136<br>from PBE | metal                                                                                                |
| current work                          | plane-wave (GGA)             | UO <sub>2</sub>                                                                                                       | FM   | 5.442                               |                               | metal                                                                                                |
|                                       |                              |                                                                                                                       | AFM  | 5.404                               |                               |                                                                                                      |
|                                       |                              | $NpO_2$                                                                                                               | FM   | 5.394                               |                               | metal                                                                                                |
|                                       |                              |                                                                                                                       | AFM  | 5.407                               |                               |                                                                                                      |
|                                       |                              | $PuO_2$                                                                                                               | FM   | 5.384                               |                               | metal                                                                                                |
|                                       |                              |                                                                                                                       | AFM  | 5.391                               |                               |                                                                                                      |

approach was further examined by Koelling, Wood, and Boring in their analysis of the photoemission spectrum of  ${\rm UO_2}^{75}$ 

Other LDA studies of note include the relativistic linear augmented-plane-wave results of Maehira et al. Their band structures for paramagnetic UO<sub>2</sub>, NpO<sub>2</sub>, and PuO<sub>2</sub> also yielded metals with significant hybridization between the actinide Sf and oxygen 2p states, a result identical to that seen in the spin-polarized calculations. The insulating character of the first member of the series, ThO<sub>2</sub>, was reproduced by the LDA, but as is typical of the LDA, the computed band gap of 3.3 eV is significantly lower than the experimental band gap, 6.0 eV. Pickard et al. Reveloped ultrasoft pseudopotentials for lanthanide and actinide materials and using them found a lattice constant for UO<sub>2</sub> of 5.474 Å, in good agreement with experiment (5.470 Å). In light of more complete all-electron treatments, which yield an LDA lattice constant of ~5.27 Å, this must be regarded as an artifact of the ultrasoft pseudopotential.

It is interesting, however, that the elastic constants can be reliably reproduced, as shown in Table 2.

The next round of studies focused on second generation density functionals. Boettger et al. <sup>79–81</sup> found that GGAs predict both paramagnetic and ferromagnetic UO<sub>2</sub> to be metallic (see Figure 8) whether or not spin—orbit coupling is included. The ferromagnetic metal was found to be more stable than either paramagnetic or antiferromagnetic states. The lattice constant and bulk modulus obtained by Boettger et al. <sup>79</sup> are reproduced in Table 3. The lattice parameters obtained from the GGA model ranged from 5.380 to 5.428 Å, while those obtained from the LDA model ranged from 5.248 to 5.327 Å; they are significantly shorter than the experimental value of 5.470 Å. The computed bulk moduli from LDA and GGA vary from 199 to 261 GPa, depending on the lattice parameters obtained for these calculations. Boettger et al. suggested that the strong correlation effects that are generally

![](_page_8_Figure_1.jpeg)

**Figure 10.** DOS of  $\rm UO_2$  calculated in the LDA+U approximation at the predicted equilibrium lattice constant of 5.361 Å. Reprinted with permission from ref 96. Copyright 1997 Taylor & Francis.

believed to produce the observed band gap do not have a significant impact on the binding properties of UO<sub>2</sub>.

Though LDA/GGA fail to predict the correct ground state and electronic configuration, they have provided defect energies and phonon spectra for  $UO_2$  that are consistent with experimental data. After consideration of the spin polarization of the Sf electrons, accurate defect energies can be achieved. Of particular note, the inclusion of spin—orbit coupling can lead to shifts of  $\sim 1-2$  eV in the LDA/GGA defect energies.

The studies above expanded the orbitals in a plane-wave basis set. GGA calculations on actinide dioxides using Gaussiantype basis sets and relativistic effective core potentials (RECPs) have also been performed.<sup>20,92</sup> Consistent with prior research, <sup>75,78–82,93–97</sup> neither the LDA nor the PBE GGA of Perdew, Burke, and Ernzerhof<sup>11</sup> yield an insulator for UO<sub>2</sub>. Both give ferromagnetic conductors, where the Fermi level cuts a band constructed primarily from uranium f orbitals (see Figure 9). A similar situation occurs with  $PuO_2$  and  $\beta$ - $Pu_2O_3$ . Both LDA and PBE predict significantly shorter lattice constants for UO<sub>2</sub>, 5.28 Å from LDA and 5.38 Å from PBE, compared with 5.47 Å from experiment. These lattice constants are much shorter than the LDA value (5.474 Å) obtained from the ultrasoft plane-wave pseudopotential approach by Pickard et al.<sup>78</sup> We have recently revisited this problem using plane waves and a PAW representation for the core, and find a lattice constant of 5.334 Å in the LDA and 5.404 Å with the PBE GGA. We conclude that the lattice constants are somewhat dependent on the basis set, and sensitive to the details of the treatment of the relativistic core.

To summarize, the LDA and GGA approximations have proven very useful for describing bonding properties of solids

![](_page_8_Figure_7.jpeg)

**Figure 11.** Partial density of states for antiferromagnetic  $UO_2$ : the GGA is reproduced on the left and the GGA+U (U = 4.5 eV and J = 0.5 eV) on the right. Reprinted with permission from ref 107. Copyright 2005 Korean Nuclear Society.

with weakly correlated electrons, but in these strongly correlated Mott insulators, they fail qualitatively, predicting metallic behavior. Before moving on to a discussion of those methods specifically addressing the strong correlations in these materials, we provide an overview of the status of LDA/GGA predictions in Table 4 for selected properties of interest.

![](_page_9_Figure_1.jpeg)

**Figure 12.** A combination of XPS, BIS, and density of states from GGA+U. Reprinted with permission from ref 55. Copyright 2011 American Physical Society.

![](_page_9_Figure_3.jpeg)

Figure 13. (top) Lattice constant of AFM  $PuO_2$  as a function of the Hubbard repulsion term U. (bottom) Band gap of AFM  $PuO_2$  as a function of U. Reprinted with permission from ref 132. Copyright 2008 American Institute of Physics.

#### 3.3. DFT+U

Once again, the major deficiency of the LDA/GGA approximations for the Mott insulators is the self-interaction error, <sup>23,98</sup> which is particularly severe for systems with partially occupied d- or f-states. A variety of approaches have been developed for overcoming the shortcomings of semilocal DFT. The simplest approach is the DFT+U method, proposed by Anisimov, Zaanen, and Andersen,<sup>24</sup> where an orbital-dependent interaction term, characterized by an energy scale U (representing the screened Coulomb interaction between the correlated orbitals) replaces the on-site repulsion in the semilocal functional, an approach very similar in spirit to the physics first proposed by Mott<sup>99</sup> and by Hubbard, 100 in which a gap is introduced in a tight-binding band through the use of an on-site Coulomb repulsion term U. The DFT+U method contains two adjustable parameters, conventionally denoted by U and J. The latter derives from an effective on-site Hartree-Fock exchange term. These parameters can be estimated from experimental core-level-photoemission measurements or from first-principles calculations but are generally simply empirical estimates. The LDA+U approach has been applied with

![](_page_9_Figure_7.jpeg)

**Figure 14.** The total and partial DOS for AFM  $PuO_2$  computed in the LDA+U and GGA+U formalisms with various U. Note that when  $U \approx 4$  eV, both approaches place significant O 2p density near the occupied band edge, indicating a charge-transfer insulator. For smaller values of U, the system is in the f–f Mott limit. Reprinted with permission from ref 132. Copyright 2008 American Institute of Physics.

considerable success to a large variety of Mott insulators with occupied 3d and 4f orbitals as reviewed in refs 75–77 and 101–103. It is not surprising that LDA+U has been extensively applied to actinide materials with partially occupied 5f states and has met with some success in describing Mott insulators such as the actinide dioxides.

Dudarev et al.  $^{96,97}$  report the results of calculations on the electronic structure of  $UO_2$  using the LDA+U approach as proposed by Anisimov et al.  $^{24}$  The approximation finds an antiferromagnetic and insulating ground state for  $UO_2$  (see Figure 10). The calculated band gap is 1.1 eV, which is somewhat smaller than the value observed experimentally, 2.1 eV. The calculated DOS indicates that  $UO_2$  is a Mott–Hubbard insulator, because both the upper edge of the conduction band and the lower edge of the valence band have predominantly 5f

![](_page_10_Figure_1.jpeg)

**Figure 15.** Computed density of states of  $PuO_2$  (top) and  $Pu_2O_3$  (bottom) from GGA and from PBE+U ( $U=4.0~{\rm eV};~J=0.70~{\rm eV}$ ) calculations by Jomard et al. Reprinted with permission from ref 141. Copyright 2008 American Physical Society.

character. The calculated value of the magnetic moment localized on the uranium ion was found to be 1.92  $\mu_{\rm B}$ , which is about 10% larger than the value observed experimentally, 1.75  $\mu_{\rm B}$ . In the work by Dudarev et al., the values of U and J were set to 4.5 and 0.54 eV, respectively, and were taken from experimental estimates. Note that we use the phrase "magnetic moment" here and elsewhere in the text as the magnitude of the ordered magnetic moment.

Following the work by Dudarev et al., Yun et al.  $^{107,108}$  performed a GGA+U calculation (U=4.5 eV and J=0.5 eV) on the antiferromagnetic ground state of UO<sub>2</sub>. The optimized lattice constant and band gap with the GGA functional are 5.44 Å and 1.8 eV, larger than the corresponding values obtained in LDA+U.  $^{96}$  Again, UO<sub>2</sub> is predicted to be a Mott insulator (see Figure 11); the magnetic moment at the uranium site is calculated to be 1.89  $\mu_{\rm B}$ , which is again somewhat larger than the experimental result. Similar GGA+U calculations (U=4.772 eV; J=0.511 eV) by Yu et al.  $^{55}$  obtained a band gap of 2.1 eV. The gap was again Mott insulating in nature (see Figure 12). The increase in band gap compared with the work of Yun et al. closely follows the increase in the value chosen for U.

![](_page_10_Figure_5.jpeg)

**Figure 16.** Schematic figures of level splitting of f electrons in  $PuO_2$  (a) without and (b) with the spin—orbit coupling. The numbers inside parentheses denotes the degeneracy. Reprinted with permission from ref 142. Copyright 2010 American Physical Society.

Laskowski et al. 109 calculated the noncollinear magnetic structure of uranium dioxide from LDA+U by including spinorbit coupling. Standard spin-polarized LDA calculations of collinear AFM UO<sub>2</sub> yield a moment of 0.62  $\mu_B$  with spin and orbital moments of 0.7  $\mu_{\rm B}$  and -1.32  $\mu_{\rm B}$ , respectively. Recall that the experimental moment on U is 1.75  $\mu_{\rm B}$  Interestingly, the computed moment in the 1-k AFM structure (along 100) by LDA+U calculations (U = 4.76 eV) agrees well with the experimental moment. When spin-orbit coupling and noncollinearity are included, the moments remain nearly the same, but the 3-k structure emerges as the ground state, in agreement with experiment. It is surprising that the dependence of the total moment on the value of U is quite small. Generally, increasing the localization of f states should increase the magnetic moment. The computed density of states of UO<sub>2</sub> shows that the orbital potential in the LDA+U splits the f band into narrow occupied and broad unoccupied bands, indicating a Mott insulator  $(\bar{f} \rightarrow f)$ .

Gryaznov et al. <sup>110</sup> also found a 3-k AFM structure to be most stable using PBE+U ( $U=4.6~{\rm eV}$  and  $J=0.5~{\rm eV}$ ). Further, they proposed that in contrast to UO<sub>2</sub>, PuO<sub>2</sub> shows no trend for distortion toward a rhombohedral structure, and thus, no complex 3-k magnetic structure is expected there. Zhou et al. <sup>111</sup> presented a theoretical study of the electronic structure of UO<sub>2</sub> using a combination of DFT+U calculations and a model Hamiltonian and also found a 3-k structure as the  $T=0~{\rm K}$  ground-state.

The narrow f-orbital bands found in  $UO_2$  lead to a multitude of metastable states. Dorado et al. Lead this issue in  $UO_2$  and found numerous metastable states (after fixing occupation numbers) with various electronic properties ranging from metals (high energy states) to insulators (low energy). The existence of metastable states is inherent to methods that create an orbital anisotropy and localize electrons. In fact, a number of studies on phase transitions, Lefects, and number of studies on phase transitions, Defects, and mechanical and phonon properties optical properties, Lefects, and mechanical and phonon properties based on DFT+U have been performed on  $UO_2$  and have generally agreed qualitatively

![](_page_11_Figure_1.jpeg)

Figure 17. (left) Computed band structure for paramagnetic PuO2 without spin−orbit coupling. (right) Computed band structure for paramagnetic PuO2 with spin−orbit coupling. Reprinted with permission from ref 142. Copyright 2010 American Physical Society.

![](_page_11_Figure_3.jpeg)

Figure 18. Experimental O Kα X-ray emission and O 1s X-ray absorption (XA) spectra of PuO2 (top panel) and density of states from LDA+U (U = 5 eV. Reprinted with permission from ref 57. Copyright 2008 American Institute of Physics.

with experimental observation, though some properties such as lattice constants and band gaps depend on the value of U. Additional discussions concerning the metastable states can be found in the paper of Gryaznov et al.<sup>131</sup>

The structural, electronic, and thermodynamic properties of antiferromagnetic PuO2 and Pu2O3 within LDA+U and GGA +U have been examined by Sun et al.132−<sup>135</sup> The atomic structure (including lattice parameters and bulk modulus) and band gap of the two plutonium oxides have been plotted as a function of the effective on-site Coulomb repulsion parameter U (J = 0.75 eV). For PuO2, at U = 0, the ground state is predicted to be a FM metal. After turning on U, their calculations yield an AFM insulating ground state. As U increases from 0 to 6 eV, the lattice constant and band gap increase, as shown in Figure 13, again demonstrating that these properties are U-dependent and consistent wih the fact that the Hubbard U increases the localization of f electrons, leading to weaker bonding with oxygen, thereby increasing the lattice constant of PuO2. The Mott band gap between states of f character also increases steadily as U is increased.

The density of states as a function of U from Sun et al.<sup>132</sup> is shown in Figure 14. Interestingly, with increasing U, one can find more overlap between the Pu 5f and O 2p, indicating that PuO2 is a charge-transfer insulator, in agreement with experimental observation. The lattice constant computed for PuO2 in the LDA+U is shorter than that from the GGA+U, while both LDA+U and GGA+U predict similar electronic features and band gaps. When U = 4 eV, a typical value for

![](_page_12_Figure_1.jpeg)

**Figure 19.** (top) Lattice constant of AFM NpO<sub>2</sub> as a function of U in LDA+U and GGA+U. (bottom) Band gap of AFM NpO<sub>2</sub> as a function of U in LDA+U and GGA+U. Reprinted with permission from ref 144. Copyright 2010 American Physical Society.

![](_page_12_Figure_3.jpeg)

**Figure 20.** The total DOS for the  $\mathrm{NpO}_2$  AFM phase computed by (a) LDA+U and (b) GGA+U with four selected values of U. Reprinted with permission from ref 144. Copyright 2010 American Physical Society.

actinide materials, the lattice constant of PuO<sub>2</sub> is calculated to be 5.360 Å from LDA+U, which is close to the experimental value, while GGA+U yields 5.470 Å. The same group  $^{136,137}$  investigated the structural, electronic, mechanical, and magnetic properties for  $\beta\text{-Pu}_2\text{O}_3$ , again addressing the dependence on U. With U=4 eV, the calculated DOS of  $\beta\text{-Pu}_2\text{O}_3$  shows that it is an AFM Mott insulator with a band gap of 2 eV, in agreement with experimental observation.  $^{138,139}$  Just recently, they also studied the electronic properties of  $\alpha\text{-Pu}_2\text{O}_3$  and predicted the AFM  $\alpha\text{-Pu}_2\text{O}_3$  to be an insulator with a band gap of 1.0 eV using GGA+U (U=3.0 eV).  $^{140}$ 

Jomard et al. <sup>141</sup> also performed LDA/GGA+U calculations on  $PuO_2$  and  $\beta$ - $Pu_2O_3$  (Figure 15), comparing their results with those of Sun et al. Quite different results for  $Pu_2O_3$  were found,

a discrepancy later traced by Sun et al. 135 to an error in plotting their results for the equilbrium volume vs *U*. Jomard et al. stressed the difficulties associated with convergence to metastable states as opposed to the true DFT+U ground state. This point is well taken, because the large number of open-shell electrons in most of these compounds leads to many low-lying solutions.

As mentioned above, both LDA+U and PBE+U formalisms predict PuO<sub>2</sub> to be antiferromagnetic in its ground state with a net magnetic moment on plutonium of  $\sim$ 3.9  $\mu_{\rm B}$ . No Pu moment is found experimentally. The reason for this failure of theory regarding the magnetic moment is still unclear. Nakamura et al.  $^{142}$  performed an LDA+U (U=4 eV) numerical experiment with both relativistic and strong correlation effects on PuO<sub>2</sub>. Figure 16 (from ref 142) shows the schematic splitting of the f orbital manifold with and without spin-orbital coupling. With spin-orbit coupling, the f orbitals split into lower j = 5/2 and higher j = 7/2 orbitals, which opens a gap, although not the Mott gap due to localization. If one constrains the variational calculation to the paramagnetic (closed-shell) solution, Nakamura et al. 142 found that while the LDA+U approximation did not introduce a gap, the combination of LDA+U and spin-orbit coupling did. The computed band gap of ~1.5 eV (see Figure 17) is still lower than the latest measurement of 2.8 eV. 48 This "victory" is hollow, however, because the paramagnetic solution is not the variationally determined minimum energy; the AFM spinpolarized solution is still predicted to be lower in energy, and the inclusion of spin-orbit coupling to the spin-polarized LDA +U does not quench the associated moment.

As shown in the calculated density of states of PuO<sub>2</sub> for both the AFM and paramagnetic state, there is significant hybridization between Pu 5f and O 2p, indicating a covalent interaction. Recall that UO2 is characterized by small band dispersion and is firmly in the ionic limit. This covalency, first emphasized by Prodan et al.<sup>21</sup> in their hybrid DFT work, has now been observed by a number of researchers. In fact, evidence for covalency is also found in a number of organoactinide molecular complexes. A recent review of the evidence for covalent bonding derived from structural, spectroscopic, and theoretical studies in f-element containing molecules is available. 143 Evidence for this covalency in PuO<sub>2</sub> was presented by Modin et al. 56,57 using O 1s X-ray absorption (XA) and X-ray emission combined with LDA+U (U = 5) calculations (see Figure 18). Both of these experiments are sensitive to the partial O 2p DOS. We note that these X-ray emission and absorption experiments are also in excellent agreement with the hybrid DFT results in this work (see Figure 4). The LDA/PBE+U bandwidth of the occupied states (~5.0 eV) underestimates the experimental bandwidth of 6.7 eV; the width from HSE (~6.5 eV) is in better agreement with experiment.

NpO<sub>2</sub> also has been studied via DFT+U. Wang et al. <sup>144</sup> investigated the electronic structures, mechanical properties, and phonon dispersion in the LDA+U. The AFM state is calculated to be more stable than the FM state by 5 meV at U = 4 eV and by 2 meV at U = 6 eV. Again, the lattice constant depends on the functional chosen and on the value of U (see Figure 19). Roughly speaking, for each U, the lattice constant calculated from GGA+U is larger than that from LDA+U, while the band gaps from LDA+U and GGA+U seem consistent. At the typical U = 4 eV, the LDA+U gives  $a_0 = 5.40$  Å which is very close to the experimental value at 5.42 Å. <sup>50</sup> The computed

![](_page_13_Figure_1.jpeg)

Figure 21. continued

#### Figure 21, continued

Figure 21. (a) Orbital-projected DOS of a multipolar state computed with U = 4 eV, J = 0 eV. Plotted is Np 5f, j = 5/2, DOS projected on components of the irreducible  $D_{3d}$  basis, and the Np j = 7/2 and O p character DOS. (b) Orbital-projected DOS of the multipolar phase obtained with U = 4 eV and J = 0.2 eV. Reprinted with permission from ref 146. Copyright 2010 American Physical Society.

![](_page_14_Figure_3.jpeg)

**Figure 22.** The density of states for UO<sub>2</sub>, NpO<sub>2</sub>, and PuO<sub>2</sub>. The zero of energy has been aligned with the highest occupied orbital energy. The NpO<sub>2</sub> and PuO<sub>2</sub> DOS have been shifted from the zero line. The position of the An 5f bands is shown in dashed lines, including both localized states (shaded in gray) and states hybridized with the O 2p band. The arrows indicate the separation of the localized An 5f states and the O 2p bands. The highest occupied state is at 0 eV. Reprinted with permission from ref 147. Copyright 2009 American Physical Society.

density of states (Figure 20) shows the dependence on U; for both approximations, one can see that there is a transition from metal (U=0) to Mott insulator (U=2 eV) to charge-transfer insulator (U=6 eV). At the typical value of U=4, LDA+U predicts NpO<sub>2</sub> to be a Mott insulator and GGA+U a charge-transfer insulator. Experimentally, it is not certain whether NpO<sub>2</sub> is a Mott insulator or a charge-transfer insulator. In addition, Yun et al. Hard predicted paramagnetic NpO<sub>2</sub> to be a metal with U=3.5 eV and a Mott insulator at U=4 eV; GGA+U predicts it to be a charge-transfer insulator at U=4 eV. It is therefore not possible to determine a consistent ground state electronic character with DFT+U in this case.

The calculations above did not address the complex magnetic order. Experimentally,  $NpO_2$  is now widely recognized as the archetypal compound for magnetic multipole ordering.<sup>4</sup> Suzuki

![](_page_14_Figure_7.jpeg)

**Figure 23.** The computed density of states for  $UO_2$ ,  $NpO_2$ , and  $PuO_2$  using PBE+U with U=4.5 eV and J=0.5 eV in this work.

et al. <sup>146</sup> performed a noncollinear LDA+U (U=4 eV) calculation to explore the multipolar order and superexchange in NpO<sub>2</sub>. Figure 21 shows the calculated partial density of states of NpO<sub>2</sub> with the multipolar state computed with U=4 eV, J=0 and U=4 eV, J=0.2 eV, respectively; both DOS show a significant hybridization between oxygen 2p orbitals and Np 5f, j=5/2 orbitals, indicating a charge-transfer insulator. Interestingly, we note that the band gap depends fairly

Table 5. Calculated Relative Energy (eV per AnO<sub>2</sub>, Where An = U, Np, and Pu), Lattice Constants (Å), Magnetic Moment ( $\mu_B$ ) on the Actinide, and Band Gap (eV) Using PBE and PBE+U (U = 4.5 eV and J = 0.5 eV) in Current Work<sup>a</sup>

|         |       | E    | E <sub>rel.</sub> (eV per AnO <sub>2</sub> ) |      |                     | <i>a</i> <sub>0</sub> (Å) |       | $\mu$ ( $\mu$ <sub>B</sub> ) | $E_{\rm gap}$ (eV) |
|---------|-------|------|----------------------------------------------|------|---------------------|---------------------------|-------|------------------------------|--------------------|
|         |       | AFM  | FM                                           | NM   | $AFM^b$             | FM                        | NM    | AFM                          | AFM                |
| $UO_2$  | PBE   | 0.00 | -0.18                                        | 0.06 | 5.404               | 5.422                     | 5.379 | 1.53                         | 0.0                |
|         | PBE+U | 0.00 | 0.20                                         | 2.35 | 5.568               | 5.546                     | 5.440 | 1.96                         | 2.3                |
|         | expt  |      |                                              |      | 5.470 <sup>49</sup> |                           |       | $1.8 - 2.0^{64}$             | 2.149              |
| $NpO_2$ | PBE   | 0.00 | -0.25                                        | 0.62 | 5.407               | 5.394                     | 5.330 | 2.98                         | 0.0                |
|         | PBE+U | 0.00 | 0.00                                         | 3.70 | 5.498               | 5.498                     | 5.419 | 3.10                         | 2.6                |
|         | expt  |      |                                              |      | 5.420 <sup>50</sup> |                           |       | $0.00^{148}$                 | $2.80^{48}$        |
| $PuO_2$ | PBE   | 0.00 | -0.28                                        | 1.49 | 5.391               | 5.384                     | 5.298 | 4.05                         | 0.0                |
|         | PBE+U | 0.00 | 0.14                                         | 4.08 | 5.465               | 5.455                     | 5.430 | 4.18                         | 1.6                |
|         | expt  |      |                                              |      | 5.398 <sup>51</sup> |                           |       |                              | $2.85^{48}$        |

<sup>&</sup>quot;We note that the AFM column refers to an ordering along the (100) direction.  ${}^{b}A$  small tetragonal distortion with  $a = b \neq c$  has been found in the AFM state (by all three methods) for UO<sub>2</sub>, NpO<sub>2</sub>, and PuO<sub>2</sub>. The ferromagnetic and nonmagnetic solutions do not show the distortion.

Table 6. Summary for Lattice Constant (Å), Magnetic States, and Type for Actinide Oxides across References Using DFT+U<sup>a</sup>

| authors                                                   | DFT                              | U (eV)   | J (eV) | compd               | spin | latt. const.                                                          | type                                                              |
|-----------------------------------------------------------|----------------------------------|----------|--------|---------------------|------|-----------------------------------------------------------------------|-------------------------------------------------------------------|
| Dudarev et al.<br>1997 <sup>96</sup>                      | LDA+U                            | 4.5      | 0.54   | UO <sub>2</sub>     | AFM  | 5.361                                                                 | Mott insulator, 1.1 eV                                            |
| Laskowski et<br>al. 2004 <sup>109</sup>                   | LDA+U with spin orbtial coupling |          |        | $UO_2$              | AFM  |                                                                       | Mott insulator, 2.0 eV                                            |
| Yun et al.<br>2005, <sup>107</sup><br>2007 <sup>108</sup> | GGA+U                            | 4.5      | 0.50   | UO <sub>2</sub>     | AFM  | 5.44                                                                  | Mott insulator, 1.8 eV                                            |
| Yu et al.<br>2011 <sup>55</sup>                           | GGA+U                            | 4.772    | 0.511  | $UO_2$              | AFM  |                                                                       | Mott insulator, 2.1 eV                                            |
| Gryaznov et al.<br>2010 <sup>110</sup>                    | GGA+U                            | 4.6      | 1.5    | $UO_2$              | AFM  | 5.547                                                                 | Mott insulator, 2.0 eV                                            |
|                                                           |                                  | 3.0      | 1.5    | $PuO_2$             | AFM  | 5.402                                                                 | charge-transfer insulator, 1.5 eV                                 |
| Sun et al.<br>2008 <sup>132</sup>                         | LDA+U                            | variable | 0.75   | $PuO_2$             | AFM  | 5.360 at $U = 4$ eV from LDA+U; 5.470 at $U = 4$ from GGA+U           | charge-transfer insulator, 1.5 eV at $U = 4$ (both from LDA/GGA+U |
|                                                           |                                  |          |        | $\beta$ - $Pu_2O_3$ | AFM  | 3.75/5.80 at $U = 4$ eV from LDA+U; $3.84/5.92$ at $U = 4$ from GGA+U | Mott insulator, 2.0 eV                                            |
| Jomard et al.<br>2008 <sup>141</sup>                      | GGA+U                            |          |        | $PuO_2$             | AFM  |                                                                       | charge-transfer insulator, 1.5 eV at $U = 4$ (both from LDA/GGA+U |
|                                                           |                                  |          |        | $Pu_2O_3$           | AFM  |                                                                       | Mott insulator, 2.0 eV                                            |
| Andersson et al. 2009 <sup>147</sup>                      | LDA+U                            | 4.5      | 0.5    | $UO_2$              | AFM  | 5.448                                                                 | Mott insulator, 1.9 eV                                            |
|                                                           |                                  |          |        | $NpO_2$             | AFM  | 5.398                                                                 | Mott insulator, 2.0 eV                                            |
|                                                           |                                  |          |        | $PuO_2$             | AFM  | 5.354                                                                 | charge-transfer insulator, 1.5 eV                                 |
| Nakamura et<br>al. 2010 <sup>142</sup>                    | LDA+U                            | 4        | 0      | $PuO_2$             | NM   | 5.460                                                                 | charge-transfer insulator, 1.5 eV                                 |
| Zhang et al.<br>2010 <sup>136</sup>                       | LDA/GGA+U                        | 4        |        | $PuO_2$             | AFM  | 5.362 from LDA+U; 5.446 from GGA<br>+U                                | charge-transfer insulator, 1.5 eV                                 |
| current work                                              | GGA+U                            | 4.5      | 0.5    | $UO_2$              | AFM  | 5.568                                                                 | Mott insulator, 2.3 eV                                            |
|                                                           |                                  |          |        | $NpO_2$             | AFM  | 5.498                                                                 | charge-transfer insulator, 2.6 eV                                 |
|                                                           |                                  |          |        | $PuO_2$             | AFM  | 5.465                                                                 | charge-transfer insulator, 1.6 eV                                 |

<sup>a</sup>We note that an entry of AFM ordering relates to the (100) direction.

significantly on the on-site exchange term J;  $\Delta \approx 1.9$  eV with J

= 0 and 2.3 eV with J = 0.2 eV. Andersson et al. 147 used LDA+U to study the oxidation of  $AnO_2$  (An = U, Np, or Pu) in  $O_2$  and  $O_2/H_2O$  environments. Ordered  $An_4O_9$  and  $An_4O_8(OH)$  compounds were proposed in their study. In their work, hybridization between An 5f and O 2p can be found in the calculated density of states for all AnO<sub>2</sub> (see Figure 22), which differs from other DFT+U calculations (both those discussed above and our own; see below). Note that different U and J are employed for the three dioxides: for  $UO_2$ , U and J are 4.5 and 0.51 eV, respectively, U = 4.0 eV and J = 0.7 eV for  $PuO_2$ , and U = 4.25 and J = 0.6 eV for  $NpO_2$ .

It is apparent that the DFT+U results depend primarily on the value of U chosen and whether the underlying semilocal functional was the LDA or a GGA; if a GGA is used, the results are not terribly sensitive to which specific GGA functional is employed. It does appear that in some cases results differ significantly depending on the details of the specific implementation of the approximation in different codes. In order to make a consistent comparison along the series, we have performed calculations with the VASP code vising consistent numbers of k-points, PAW pseudopotentials, and plane-wave cutoff energies. We examine the relative energy, lattice constant, magnetic moment and band gap for three magnetic states (AFM, FM, and NM) of UO<sub>2</sub>, NpO<sub>2</sub>, and PuO<sub>2</sub> using PBE and PBE+U, as summarized in Table 5. The PBE functional predicts a ferromagnetic (FM) ground state for the three dioxides. It also predicts them to be metallic, resulting in too much bonding and a lattice constant shorter than experiment. The addition of the empirical Hubbard correction (PBE+U with U = 4.5 eV and J = 0.5 eV) introduces gaps for the three dioxides (2.3 eV for UO<sub>2</sub>, 2.6 eV for NpO<sub>2</sub>, and 1.6 eV for PuO<sub>2</sub>) and better localizes the electrons in the f-orbitals. PBE+U predicts AFM ground states for UO2 and PuO2, while PBE+U finds no preference for either ferro- or antiferromagnetic coupling in NpO<sub>2</sub>.

Figure 23 shows the computed density of states for UO2, NpO<sub>2</sub>, and PuO<sub>2</sub> using PBE+U with U = 4.5 eV and J = 0.5 eV in the current work. The DOS calculated with PBE+U clearly suggests that UO2 is a Mott insulator with a clear separation between O 2p and U 5f peaks. The band structure, not shown, associates the 5f derived states with a fairly broad band of width 1.8 eV. This dispersion is much greater that than that found in the experimental photoemission spectrum, which shows dispersion of ~130 meV.<sup>54</sup> The Np 5f and Pu 5f orbitals are in more favorable energetic positions to mix with the corresponding O 2p, indicating that both NpO2 and PuO2 are more covalent and charge-transfer insulators.

In summary, DFT+U has met with some success in describing UO2 and PuO2 when a suitable U is used. When U = 4 eV, the computed GGA+U band gap for  $UO_2$  is in good agreement with experiment, though the gap in PuO2 is normally underestimated. DFT+U correctly predicts UO2 and PuO<sub>2</sub> to be a Mott insulator and a charge-transfer insulator, respectively. However, for NpO<sub>2</sub>, the predictions of DFT+U are quite dependent on the parameters and functional chosen. Aside from DFT+U studies on  $UO_2$ ,  $PuO_2$ , and  $NpO_2$ , studies on  $U_3O_8$ ,  $^{145}Np_2O_5$ ,  $^{145}$  and  $ThO_2$  have been performed. Table 6 summarizes these results.

There are many methods that go beyond LDA+U, but the one of interest here (and the next simplest after LDA+U) is

![](_page_16_Figure_1.jpeg)

**Figure 24.** Comparison of experimental and theoretical phonons for  $PuO_2$ : (a) experimental phonon DOS determined by inelastic X-ray scattering by Manley et al.; <sup>156</sup> (b) theoretical phonon DOS determined using DFT by Minamoto et al. <sup>157</sup> (blue dashed line) and DFT+U by Zhang et al. <sup>136</sup> (red dotted line); (c) theoretical phonon dispersion curves associated with the DFT (blue) and DFT+U (red) phonon DOS above plus partial phonon dispersion curves calculated using DMFT by Yin et al. <sup>43</sup> (green symbols). Reprinted with permission from ref 156. Copyright 2012 American Physical Society.

dynamical mean field theory (DMFT). DMFT (or LDA +DMFT) goes beyond LDA+U by allowing the interaction potential of the correlated orbitals to be energy (frequency) dependent. This frequency-dependent potential, or self-energy, is computed for the correlated orbitals only using many-body techniques within an accurate impurity solver. One of DMFT's main successes is the description of the phase transition between a metal and a Mott insulator when the strength of electronic correlations is increased. DMFT has recently offered a practical way to treat the critical on-site correlations that dominate the properties of many f-electron metals and f- and d-electron compounds.

Yin et al.<sup>43</sup> studied the electronic properties and thermal conductivity of UO2 and PuO2 via a combination of LDA and DMFT where the relativistic 5f shells of uranium and plutonium were treated by exact diagonalization of manybody Hamiltonians obtained by allowing a hybridization between the 5f-electrons and the nearest oxygen 2p orbitals. In their study, a parameter  $U_{\text{eff}} = 3 \text{ eV}$  describing the on-site Coulomb repulsion between the 5f electrons was chosen. The band gaps computed for UO2 and PuO2 were 2.2 and 2.5 eV, respectively, and both were predicted to be classical Mott-Hubbard insulators. A recent comprehensive experimental X-ray absorption study by Yu et al. 55,154 as well as femtosecond pump—probe studies 155 firmly establish UO<sub>2</sub> as a Mott— Hubbard insulator. However, this DMFT prediction of Mott insulating behavior for PuO2 is incorrect, as the recent PES results of Joyce et al.<sup>58</sup> have shown it to be of charge-transfertype. Yin et al. also calculated the phonon dispersions for the paramagnetic phases of  $UO_2$  and  $PuO_2$  with U = 3 eV. The

![](_page_16_Figure_5.jpeg)

**Figure 25.** (top) Total and partial DOS of  $UO_2$  using DMFT with the parameter U extracted from first principles. XPS and BIS date taken from ref 104. (bottom) Total and partial DOS of  $PuO_2$  compared with XPS from ref 70. Both calculated at T=100 K. Reprinted with permission from ref 44. Copyright 2011 American Physical Society.

![](_page_16_Figure_7.jpeg)

**Figure 26.** The hypothetical structure of PuO<sub>2.25</sub> with the additional oxygen occupying the central position in fluorite PuO<sub>2</sub>. Reprinted with permission from ref 160. Copyright 2003 American Association for the Advancement of Science.

materials demonstrate very similar dispersion. As expected, the value chosen for the on-site repulsion also affects the overall phonon spectra.

Using inelastic X-ray scattering (see Figure 24), Manley et al.  $^{156}$  measured the phonon density of states of  $PuO_2$  (+2% Ga) and compared the results with theoretical predictions from DFT,  $^{157}$  DFT+U,  $^{136}$  and DMFT.  $^{43}$  The DFT prediction underestimates the measured energies of most features. The DFT+U prediction accurately reflects the low-energy features but incorrectly splits off an isolated high-energy oxygen mode. The dispersions predicted by DMFT are too limited to

![](_page_17_Figure_1.jpeg)

**Figure 27.** Total density of states (black), Pu f-projected DOS (red), and interstitial O p-projected DOS (blue) for (A) the tetravalent  $Pu_4^{\ 4+}O_8$ , (B) the tetravalent  $Pu_4^{\ 4+}O_9$  compound, (C) the mixed  $Pu_2^{\ 5+}Pu_2^{\ 4+}O_9$  compound, and (D) the pentavalent  $Pu_4^{\ 5+}O_9$  compound in the SIC-LSD. The interstitial O DOS is only displayed in panels B and C. The energy (in Rydberg) is relative to  $E_F$ . Reprinted with permission from ref 160. Copyright 2003 American Association for the Advancement of Science.

pinpoint optic features of the phonon DOS in this range, although they are clearly different than the DFT+U result. There is a practical need to improve calculations of the lattice vibrations to enhance the predictive capabilities regarding phase stability and thermal transport. Note that the effect of magnetic states on the phonon spectrum of  $PuO_2$  might cause some differences. It is unclear, for instance, whether a paramagnetic state was considered in DFT<sup>157</sup> and DMFT<sup>43</sup> calculations, while AFM ordering was used for DFT+U. <sup>136</sup>

Three years later, the same group<sup>44</sup> calculated the density of states of  $UO_2$  and  $PuO_2$  using a value U = 5.1 eV for uranium and 5.5 eV for plutonium instead of the 3 eV used in their

![](_page_17_Figure_5.jpeg)

**Figure 28.** Lattice parameters of the actinide dioxides. Experimental values from ref 52 (blue stars) are compared with the theoretical SIC values (red circles), and the theoretical HSE values (green squares) from our work in ref 165. Reprinted with permission from ref 41. Copyright 2010 American Physical Society.

![](_page_17_Figure_7.jpeg)

**Figure 29.** DOS of  $CmO_2$  from the SIC-LDA. (top) Total (black), Cm (green), and O (red dots). (bottom) the corresponding Cm f majority (red) and minority (blue) spin decomposed DOS. Reprinted with permission from ref 41. Copyright 2010 American Physical Society.

previous study.<sup>43</sup> These new parameters were determined nonempirically using a new method to extract *U* numerically from a first principles calculation. In this study, the full-

Table 7. Computed Band Gap (eV), Lattice Constant (Å), and Bulk Moduli (GPa) of AFM AO<sub>2</sub> (A = U, Np, Pu, Am, Cm, Bk, and Cf) in the SIC-LSD and Corresponding Experimental Data<sup>a</sup>

| compd            | config.                            | $E_{ m gap}$ | $E_{\rm gap}({\rm expt})$ | $a_0$ | $a_0(\text{expt})^{162}$ | $B_0$ | $B_0(\text{expt})$ | type       |
|------------------|------------------------------------|--------------|---------------------------|-------|--------------------------|-------|--------------------|------------|
| $UO_2$           | $f^{1}(U^{5+})$                    | 0            | $2.10^{49}$               | 5.40  | 5.470                    | 219   | 207 <sup>52</sup>  | C-T insul. |
| $UO_2$           | $f^{2}(U^{4+})$                    | 2.6          | 2.10                      | 5.47  | 5.470                    | 219   | $207^{52}$         | C-T insul. |
| $NpO_2$          | $f^3(Np^{4+})$                     | 2.3          | $2.80^{48}$               | 5.46  | 5.433                    | 217   | $200^{52}$         | C-T insul. |
| $PuO_2$          | $f^4(Pu^{4+})$                     | 1.2          | $2.85^{48}$               | 5.44  | 5.396                    | 214   | 178 <sup>52</sup>  | C-T insul. |
| $AmO_2$          | f <sup>5</sup> (Am <sup>4+</sup> ) | 0.8          | $1.30^{163}$              | 5.42  | 5.374                    | 209   | 205 <sup>52</sup>  | C-T insul. |
| $CmO_2$          | $f^6(Cm^{4+})$                     | 0.4          |                           | 5.37  | 5.359                    | 212   | $218^{164}$        | C-T insul. |
| $BkO_2$          | $f^{7}(Bk^{4+})$                   | 1.0          |                           | 5.36  | 5.331                    | 221   |                    | C-T insul. |
| CfO <sub>2</sub> | $f^{8}(Cf^{4+})$                   | 0.6          |                           | 5.36  | 5.310                    | 210   |                    | C-T insul. |

<sup>&</sup>lt;sup>a</sup>The type of insulator also is inserted (all of them are predicted to be charge-transfer insulator). Reproduced data from ref 41.

![](_page_18_Figure_1.jpeg)

**Figure 30.** (top) PBEh partial DOS for  $UO_2$ . The peak near  $E_F$  is primarily U 5f with a very small O 2p contribution. (bottom) Reproduction of the photoemission energy distribution curves taken by Cox et al.<sup>53</sup> demonstrating the predominantly U 5f character of the feature near  $E_F$ . The incident photon energies correspond to the resonance (98 and 108 eV) and antiresonance (92 eV) in the U 5f cross section. Reprinted with permission from ref 20. Copyright 2002 American Physical Society.

![](_page_18_Figure_3.jpeg)

**Figure 31.** The PBEh total and partial DOS for (a)  $PuO_2$  and (b)  $Pu_2O_3$  compared with experiment. The zero of energy is defined by the energy of the highest occupied crystal orbital. The experimental data were shifted upward for easier comparison with theory. Reprinted with permission from ref 21. Copyright 2005 American Institute of Physics.

potential charge self-consistent implementation of LDA +DMFT was based on the DFT program WIEN2K.<sup>158</sup> For the impurity solver, they used the continuous time quantum Monte Carlo (CTQMC) algorithm.

Figure 25 shows the total and partial DOS of paramagnetic  $UO_2$  and  $PuO_2$  from these calculations. With the larger values for U, they now find the two dioxides to be charge-transfer insulators; in disagreement with experiment for  $UO_2$  but in agreement for  $PuO_2$ . They also argue that a Zhang–Rice-like state<sup>159</sup> is present in  $UO_2$  but not in  $PuO_2$ . The former is

![](_page_18_Figure_7.jpeg)

**Figure 32.** A comparison of the PBEh projected DOS (a) for ferromagnetic PuO<sub>2</sub>, (b) for PuO<sub>2.25</sub> when the interstitial oxygen is located in the center of the ligand cube; or (c) for PuO<sub>2.25</sub> when the interstitial oxygen is displaced from this high-symmetry point. The projected orbitals are Pu 5f, Pu 6d, stoichiometric O 2p, and interstitial O 2p. Reprinted with permission from ref 21. Copyright 2005 American Institute of Physics.

incompatible with the energy-dependent photoemission results, which show the feature at the band edge to be dominantly f orbital in character. As expected, the computed band gaps of  $UO_2$  and  $PuO_2$  are also U-dependent. For  $UO_2$ , values of 2.2 and 2.5 eV are obtained from U=3 eV and U=5.1 eV, respectively; in  $PuO_2$ , the gaps are 2.5 eV and 3.5 eV for U=3 eV vs U=5.5 eV.

In summary, DMFT investigations on the oxides have only begun to appear. DMFT correctly predicts insulating behavior for  $UO_2$  and  $PuO_2$ , and the band gaps are reasonable compared with experiment. However, the nature of the insulating state has been predicted to be both Mott-like and charge-transfer-like, depending on the value chosen for the parameter U, so it is difficult to assess the DMFT embedding scheme itself when its practical implementation is so dependent on empirical parameters. The results reported for  $UO_2$  suggest that more work is needed to extract reliable parameters in a nonempirical manner. It is also difficult to assess this approximation as no optimized lattice constants are available.

#### 3.5. SIC

The self-interaction error introduced by semilocal approximations to density functional theory leads to some dramatic failures, ranging from qualitatively incorrect predictions in chemical reactions to incorrect descriptions of the insulating state in many transition metal oxides and qualitatively wrong pictures for lanthanide and actinide compounds. Nearly 30 years ago, Perdew and Zunger (PZ) suggested a remedy for this error, the so-called self-interaction corrected (SIC) local density

Table 8. Calculated and Experimental Properties of U and Pu Oxides: The Band Gap ( $\Delta$ ), Equilibrium Lattice Constant ( $a_0$ ), and Bulk Modulus ( $B_0$ )<sup>a</sup>

|                                         |                      | Δ (e        | ·V)  | $a_0$ (              | (Å)   | $B_0$ (           | GPa) |                                     |
|-----------------------------------------|----------------------|-------------|------|----------------------|-------|-------------------|------|-------------------------------------|
| compd                                   | method               | FM          | AFM  | FM                   | AFM   | FM                | AFM  | $E_{\rm FM}-E_{\rm AFM}~({ m meV})$ |
| UO <sub>2</sub>                         | LDA                  | 0           | 0    | 5.317                | 5.289 | 239               | 216  | -98                                 |
|                                         | PBE                  | 0           | 0    | 5.425                | 5.445 | 206               | 186  | -123                                |
|                                         | TPSS                 | 0           | 0    | 5.437                | 5.445 | 202               | 191  | -124                                |
|                                         | PBEh                 | 2.23        | 3.13 | 5.455                | 5.454 | 220               | 219  | +2                                  |
|                                         | HSE                  | 1.56        | 2.39 | 5.463                | 5.463 | 226               | 218  | +7                                  |
|                                         | GGA+U <sup>136</sup> |             | 2.00 |                      | 5.449 |                   | 220  |                                     |
|                                         | SIC <sup>41</sup>    |             | 0    |                      | 5.400 |                   | 219  |                                     |
|                                         | expt                 | 2.149       |      | 5.470 <sup>49</sup>  |       | $207^{52}$        |      | >0                                  |
| $PuO_2$                                 | LDA                  | 0           | 0    | 5.278                | 5.285 | 229               | 222  | -310                                |
|                                         | PBE                  | 0           | 0    | 5.399                | 5.412 | 189               | 182  | -259                                |
|                                         | TPSS                 | 0           | 0.06 | 5.382                | 5.403 | 201               | 201  | -116                                |
|                                         | PBEh                 | 2.40        | 3.39 | 5.387                | 5.385 | 221               | 221  | +14                                 |
|                                         | HSE                  | 1.68        | 2.64 | 5.398                | 5.396 | 221               | 220  | +14                                 |
|                                         | GGA+U <sup>132</sup> |             | 1.50 |                      | 5.470 |                   | 184  |                                     |
|                                         | SIC <sup>41</sup>    |             | 1.20 |                      | 5.44  |                   | 214  |                                     |
|                                         | Expt                 | $2.85^{48}$ |      | 5.398 <sup>51</sup>  |       | 178 <sup>52</sup> |      | ≥0                                  |
| $\beta$ -Pu <sub>2</sub> O <sub>3</sub> | LDA                  | 0           | 0    | 3.690                | 3.680 | 181               | 175  | -185                                |
|                                         | PBE                  | 0           | 0    | 3.790                | 3.791 | 146               | 136  | -291                                |
|                                         | TPSS                 | 0           | 0.04 | 3.770                | 3.777 | 156               | 146  | -241                                |
|                                         | PBEh                 | 2.51        | 3.50 | 3.823                | 3.824 | 176               | 175  | +11                                 |
|                                         | HSE                  | 1.83        | 2.78 | 3.823                | 3.822 | 159               | 158  | +3                                  |
|                                         | GGA+U <sup>132</sup> |             | 2.00 |                      | 3.841 |                   | 110  |                                     |
|                                         | SIC <sup>41</sup>    |             | 2.43 |                      |       |                   | 158  |                                     |
|                                         | Expt                 | >0          |      | 3.841 <sup>179</sup> |       |                   |      | >0                                  |

"A null  $\Delta$  indicates a metal. The semilocal functionals employed are the local density approximation (LDA), the PBE GGA, and the meta-GGA of Tao, Perdew, Staroverov, and Scuseria (TPSS). The hybrid density functionals are PBEh and Heyd—Scuseria—Ernzerhof (HSE), both based on PBE. Entries are for the ferromagnetic (FM) and antiferromagnetic (AFM) solutions.  $E_{\rm FM} - E_{\rm AFM}$  represents the difference in total energy between these solutions, per formula unit. For comparison, the results from GGA+U and SIC also are inserted.

approximation.<sup>15</sup> The approach removes the self-interaction error that occurs in semilocal functionals, thereby leading to an improved description of the static Coulomb correlations of the f electrons. The self-interaction correction associates an energy gain with electron localization, which competes with the opposing trend of band formation, providing a dual picture of combined localized and band-like f electrons. The method is fully *ab initio* because both kinds of electrons are treated on an equal footing with no adjustable parameters.

Petit et al. 160 studied changes in the Pu f-electron configuration induced by the oxidation/reduction process from PuO<sub>2</sub> to PuO<sub>2+x</sub>/PuO<sub>2-x</sub>, using the self-interaction corrected LDA. They found that the oxidation state of Pu in PuO<sub>2</sub> readily increases or decreases upon addition or removal of O, respectively. They examined a hypothetical structure for PuO<sub>2.25</sub> (see Figure 26) where the additional oxygen occupies a central position in the fluorite PuO<sub>2</sub> lattice. Later, Penneman and Paffett 161 argued that this interstitial oxygen presumably took the form of a hydroxyl anion, Pu<sub>4</sub>O<sub>8</sub>OH, containing one Pu(V) ion. We will discuss this possibility later.

The calculated density of states of several  $PuO_x$  stoichiometries using SIC are shown in Figure 27.  $PuO_2$  is predicted to be a charge-transfer insulator (with hybridization between Pu 5f and O 2p) with a band gap of 0.94 eV, much lower than experimental value of 2.8 eV. The computed lattice constant for  $PuO_2$  is 5.34 Å, somewhat shorter than the experimental result of 5.398 Å. Most of the  $PuO_{2+x}$  compositions are calculated to be metallic.

In 2010, Petit et al.  $^{41,42}$  studied the electronic structures of the entire series of actinide dioxides,  $AnO_2$  (An = U, Np, Pu, Am, Cm, Bk, and Cf) using SIC. Table 7 summarizes the calculated parameters (lattice constant, band gap, and bulk moduli) from SIC. The ground state of  $UO_2$  is found to be pentavalent  $U(f^1)$  and metallic. It is energetically only slightly more stable (100 meV) than the tetravalent  $U(f^2)$  state, an insulator. For the rest of the dioxides, a tetravalent ground-state configuration is found. The entire series is found to lie within the charge-transfer insulating ( $p \rightarrow f$ ) regime and so does not reproduce the Mott-insulating character ( $f \rightarrow f$  transition) of  $UO_2$ .

Petit et al. also plotted the corresponding lattice constants computed from SIC and HSE (our work), <sup>165</sup> as well as experimental data, as shown in Figure 28. The lattice constant for all dioxides from SIC is overestimated, while HSE predicts accurate lattice constants except for CmO<sub>2</sub>, where SIC is closer to experiment.

This unusual behavior in  $CmO_2$  is still not fully understood either experimentally  $^{166}$  or theoretically. Petit et al. predicted  $CmO_2$  to be a charge-transfer insulator (a band gap of around 0.4 eV) with f-spin states strongly hybridizing with the O p states (see Figure 29). This is qualitatively similar to our hybrid functional results using Gaussian-type basis sets,  $^{165}$  which give a charge-transfer insulator and a similar band gap (0.4 eV). The ground state of  $CmO_2$  found by Petit et al., indicates a localized  $f^6$  Cm ion, and the system turns out to be magnetic with a magnetic moment of 5.21  $\mu_B$ , which exceeds the experimental moment of 3.36  $\mu_B$ . We note that this moment is the

![](_page_20_Figure_1.jpeg)

Figure 33. The total and projected DOS for optimized FM and AFM UO2 from PBE, TPSS, PBEh, and HSE. Reprinted with permission from ref 92. Copyright 2006 American Physical Society.

"effective" magnetic moment as deduced from the magnetic susceptibility data. We have recently performed plane-wave PAW-based calculations with HSE, which also yield a chargetransfer gap, but it is slightly higher (1.0 eV). This is sufficiently different from the Gaussian based results that it bears further exploration. With the plane-wave based results, HSE yields a lattice constant (5.365 Å) in good agreement with the experimental value of 5.359 Å, and a magnetic moment of 6.00 μ<sup>B</sup> on Cm is obtained from our calculation. We will revisit CmO2 later.

Petit et al.<sup>41</sup> also discuss the ground-state electronic structure of the mono- and sesquioxides, AnO and An2O3, where An = U, Np, Pu, Am, Cm, Bk, and Cf.

In summary, while SIC, with the exception of UO2, correctly predicts the actinide dioxides to be insulators, it overestimates lattice constants, underestimates band gaps, and predicts the wrong location of f states in early actinide dioxides. There are also open questions regarding the spherical potentials often assumed in actual implementations, how important the orbitaldependent character of the self-interaction corrected mean-field

![](_page_21_Figure_1.jpeg)

Figure 34. The theoretical total and projected DOS for optimized FM and AFM PuO<sub>2</sub> from PBE, TPSS, PBEh, and HSE. Reprinted with permission from ref 92. Copyright 2006 American Physical Society.

potential is, and how best to deal with the overcorrection of the Perdew–Zunger SIC.

#### 3.6. Hybrid Functionals (PBEh and HSE)

We begin with a survey of results for the actinide oxide series,  $AnO_2$ , for An = Th-Es. Both plane wave and Gaussian basis sets have been utilized in the literature, using either a PAW approximation or relativistic effective core potentials (RECPs), respectively, to treat scalar relativistic effects. We focus on the antiferromagnetic solutions, which are generated by doubling

the size of the computational unit cell to include two actinide centers whose local magnetic moments are oppositely aligned. Spin—orbit coupling is present in the actinide oxides, and we will address its effect on the lattice parameters, band gaps, and electronic properties. We will discuss our work chronologically.

**3.6.1. PBEh.** *3.6.1.1. UO*<sub>2</sub>. In 2002, we reported the first application of the hybrid functional approach<sup>29,30,168,169</sup> to the electronic structure of bulk UO<sub>2</sub> using the PBEh hybrid<sup>20</sup> with Gaussian orbitals and periodic boundary conditions.<sup>170</sup> Recall

![](_page_22_Figure_1.jpeg)

Figure 35. The theoretical total and projected DOS for optimized FM and AFM β-Pu<sub>2</sub>O<sub>3</sub> from PBE, TPSS, PBEh, and HSE. Reprinted with permission from ref 92. Copyright 2006 American Physical Society.

that PBEh uses 25% exact nonlocal Hartree—Fock-type exchange and 75% PBE exchange, these values having been selected nonempirically, based on perturbation theoretic arguments. <sup>29,30</sup> This functional had been used quite successfully in molecular calculations. <sup>171–173</sup>

Our initial investigations into the magnetic properties of  $\rm UO_2$  studied the solution generated by coupling the two local triplets antiferromagnetically. The optimum PBEh lattice constant for the ferromagnetic state is 5.42 Å, in fair agreement with the experimental lattice constant of 5.47 Å. This is in contrast to the significantly shorter distances predicted in our work by the

LDA (5.28 Å) and PBE GGA (5.38 Å), suggesting that the hybrid solution is more localized than the metallic solutions.

Significantly, the PBEh hybrid functional yields a gap of 2.6 eV, slightly larger than the gap of 2.1 eV observed in the optical spectrum. <sup>174</sup> The Sf orbital character of the states at the band edge (Figure 30), are in good agreement with the resonant energy-dependent photoemission data of Cox et al., <sup>53</sup> as shown in the bottom panel of Figure 30. The gap is associated with Sf  $\rightarrow$  Sf transitions, indicating a Mott insulator; a prediction recently confirmed by the XAS experiments. Evarestov et al. <sup>175</sup> predicted UO<sub>2</sub> to be an insulator with a band gap of 3.5 eV (also larger than the experimental gap value, 2.1 eV) via

![](_page_23_Figure_1.jpeg)

**Figure 36.** Optimal lattice constants calculated with HSE for  $AnO_2$  (An = Pa–Es). Predictions are compared with known experimental data. The measured lattice constants for  $CmO_2$  are for isotopes <sup>244</sup>Cm (solid square) and for the longer-lived <sup>248</sup>Cm (open square). Reprinted with permission from ref 165. Copyright 2007 American Physical Society.

![](_page_23_Figure_3.jpeg)

**Figure 37.** Theoretical prediction for the absolute value of the spin density for the An Sf orbitals in  $AnO_2$  (An = Th–Es), at their respective optimum geometries. The expectations from formal  $An^{4+}$  charges and Hund's first rule are plotted with a dashed line. The inset shows the corresponding spin density at the oxygen sites, for the ferromagnetic case. Recall that the  $O^{2-}$  ion has a closed shell, and therefore it has zero spin density. Reprinted with permission from ref 165. Copyright 2007 American Physical Society.

performing the hybrid HF–DFT linear combination of atomic orbitals (LCAO) simulations.

3.6.1.2. PuO<sub>2</sub>, Pu<sub>2</sub>O<sub>3</sub>, and PuO<sub>2.25</sub>. Some years later, we used the PBEh hybrid to model an oxidized plutonium dioxide lattice, Pu<sub>4</sub>O<sub>9</sub>. This stoichiometry received a great deal of attention as a possible product of PuO<sub>2</sub> oxidation by H<sub>2</sub>O.<sup>51</sup> The PBEh approximation was first tested against stoichiometric bulk PuO<sub>2</sub> and Pu<sub>2</sub>O<sub>3</sub>.<sup>21,176</sup> Both PuO<sub>2</sub> and Pu<sub>2</sub>O<sub>3</sub> are predicted to be insulators, and our calculations find the antiferromagnetic solution to be slightly favored in both compounds. The lattice constants of AFM PuO<sub>2</sub> and Pu<sub>2</sub>O<sub>3</sub> were 5.385 and 3.824 Å, respectively, in good agreement with experimental data (5.398 vs 3.838 Å). PuO<sub>2</sub> was predicted to be a charge-transfer insulator (see Figure 31) with a band gap of

3.4 eV, larger than the experimental gap of 2.85 eV<sup>48</sup> and also larger than the gaps predicted by DFT+U (1.8 eV), <sup>136</sup> DMFT (2.5 eV), SIC (1.2 eV), <sup>41</sup> and the HSE screened hybrid (2.7 eV). On the other hand, Pu<sub>2</sub>O<sub>3</sub> was found to be a Mott insulator with a band gap of 3.5 eV. This is in contrast to the charge-transfer insulator ( $\Delta$  = 2.43 eV) prediction from SIC. <sup>41</sup> When a typical U (4 eV) is chosen, PBE+U also finds Pu<sub>2</sub>O<sub>3</sub> to be Mott insulator with gaps ranging from 2.2 eV (Sun et al.) <sup>132</sup> to 1.65 eV (Jamard et al.). <sup>141</sup>

Early calculations on the Pu<sub>4</sub>O<sub>9</sub> stoichiometry assumed that the additional oxygen resided in an octahedral interstitial site in the fluorite lattice, Figure 26, where it is surrounded by eight oxygen atoms at the corners of a cube. It is interesting that while the hybrid functional predicts  $Pu_4O_9$  (see Figure 32) to be insulating, both  $SIC^{160}$  and  $LDA+U^{147}$  predict it to be metallic. These approximations also differ on the qualitative character of the ground state. With PBEh, the interstitial oxygen resembles an O species, coupled antiferromagnetically to the surrounding Pu spin. 177 It is simply not able to stabilize the -2 oxidation state because of repulsion associated with the O<sup>2-</sup> anions at the corners of the cube. This scenario is quite different from SIC solution found by Petit et al., 160 who found that all oxygen sites were O2-. Within this charge constraint, the lowest energy SIC solution described the metal sites as two localized Pu<sup>4+</sup> and two Pu<sup>5+</sup> cations. This result was challenged by Penneman and Paffett, <sup>161</sup> who pointed out that the lattice constants in Pu<sub>4</sub>O<sub>9</sub> were nearly identical to those in PuO<sub>2</sub>. Zachariasen's bond length/bond strength relationships, 1 however, would suggest that an O<sup>2-</sup> is too large to occupy the interstice without a significant lattice expansion. A singly charged ion, on the other hand, would not require an increase in lattice constant, and Penneman and Paffett proposed that the interstice may be occupied by OH<sup>-</sup>. An interstitial O<sup>-</sup> (instead of O<sup>2-</sup>) as found variationally by HSE would seem compatible with this hypothesis, although we did not explicitly consider an interstitial OH<sup>-</sup> for PuO<sub>2</sub>.

On the other hand, experimental XAS investigations have challenged the view of an octahedrally coordinated oxygen. The conventional structure as well as a number of other possibilities have been examined with LDA+U calculations by Andersson et al.  $^{147}$  They found a  $\rm Pu_4O_8(OH)_2$  structure (an insulator) was energetically favorable. However, there is still no clear evidence for plutonium oxides with hydroxyl, either from experiment or from theory. The valence state of the interstitial would seem to be an important issue when considering transport of protons vs hydrogen atoms.

**3.6.2. HSE.** An important development in the application of hybrid functionals to solids was the introduction of the HSE screened hybrid. Recall that HSE differs from PBEh by replacing the long-range portion of the nonlocal exchange with that of PBE exchange, essentially because the long-range nonlocal exchange should be canceled by long-range nonlocal correlations, which are absent in the model.

 $3.6.2.1.~UO_2$ ,  $PuO_2$ , and  $Pu_2O_3$ . In 2006, we surveyed several actinide oxides with HSE based on Gaussian-type basis sets, and also performed detailed comparisons with four generations of density functional approximations: the LDA, the PBE GGA, the TPSS meta-GGA, and the PBEh hybrid. The hybrid methods predict all three oxides studied,  $UO_2$ ,  $PuO_2$ , and  $Pu_2O_3$ , to have antiferromagnetic ordering, while the semilocal methods predict all three to be ferromagnetic. None of these materials are ferromagnetic;  $UO_2$  is antiferromagnetic, but  $PuO_2$  has no moment. We are not aware of any studies of the

![](_page_24_Figure_1.jpeg)

Figure 38. The HSE total and partial density of states for optimized AFM AnO2 (An = Th−Es). The Fermi energy is defined as zero and is placed at the top of the valence band. Note the merging of An 5f and O 2p characters for intermediate members of the series. Reprinted with permission from ref 165. Copyright 2007 American Physical Society.

![](_page_24_Figure_3.jpeg)

Figure 39. Schematic of the atomic orbital energy levels for Th, Pa, U, Np, Pu, Am, and Cm and the O 2p band.

specific magnetic ordering in Pu2O3. Insulating gaps are predicted for all three materials by the hybrid functionals, while the semilocal methods incorrectly predict them to be metallic (except for TPSS, which opens a small gap of ∼0.05 eV in the antiferromagnetic states of PuO2 and Pu2O3).

In Table 8, we show the predicted band gaps, lattice constants, and bulk moduli for these three oxides, as well as the difference in energy between the ferromagnetic and antiferromagnetic solutions. Lattice constants and bulk moduli are obtained using the Murnaghan equation of state, with the lattice parameter ratio a0/c<sup>0</sup> in Pu2O3 constrained to the experimental result. Once again, it is striking how the LDA

![](_page_24_Figure_7.jpeg)

Figure 40. Experimental PES and the spin-polarized DOS for the AFM ground state for UO2 is shown on the left. The right panel depicts the total and partial DOS for UO2 calculated using the HSE functional and scalar relativistic effects. Reprinted with permission from ref 54. Copyright 2008 John Wiley & Sons.

underestimates the lattice constants. Although this underestimate is generally observed for Mott insulators, LDA geometries in most other species are usually quite reliable. We reiterate that this is a consequence of the self-interaction error, which causes the LDA to exaggerate delocalization.

Table 9. Calculated Relative Energies for AFM and FM AnO2 (An = Th, Pa, U, Np, Pu, Am, and Cm) from HSE and HSE+SOC and the Calculated AFM Gap and Magnetic Moment

|      |                 |      | Erel. (eV) | a0 (Å)            |       |                 |                     |                         |
|------|-----------------|------|------------|-------------------|-------|-----------------|---------------------|-------------------------|
|      |                 | AFM  | FM         | AFM               | FM    | μ (μB), AFM     | gap (eV), VASP, AFM | gap (eV), Gaussian, AFM |
| ThO2 | HSE             | 0.00 | 0.00       | 5.586             | 5.586 | 0.00            | 6.0                 | 6.1                     |
|      | HSE+SOC<br>expt | 0.00 | 0.00       | 5.580<br>5.580186 | 5.580 | 0.00            | 5.8<br>6.0077       | 6.1                     |
| PaO2 | HSE             | 0.00 | 0.25       | 5.501             | 5.483 | 0.94            | 1.2                 | 1.1                     |
|      | HSE+SOC<br>expt | 0.00 | 0.02       | 5.499<br>5.505187 | 5.494 | 0.95            | 1.5                 | 1.2                     |
| UO2  | HSE             | 0.00 | 0.19       | 5.458             | 5.418 | 1.98            | 2.4                 | 2.8                     |
|      | HSE+SOC<br>expt | 0.00 | 0.10       | 5.457<br>5.47049  | 5.457 | 1.95<br>1.8−2.0 | 2.4<br>2.1045       | 2.7                     |
| NpO2 | HSE             | 0.00 | −0.12      | 5.412             | 5.411 | 3.00            | 2.4                 | 3.0                     |
|      | HSE+SOC<br>expt | 0.00 | 0.15       | 5.418<br>5.42050  | 5.418 | 2.92<br>0.00    | 2.4<br>2.8048       | 3.0                     |
| PuO2 | HSE             | 0.00 | 0.15       | 5.383             | 5.378 | 4.00            | 2.4                 | 2.6                     |
|      | HSE+SOC<br>expt | 0.00 | 0.01       | 5.379<br>5.39851  | 5.373 | 3.91<br>0.00148 | 2.6<br>2.8548       | 2.6                     |
| AmO2 | HSE             | 0.00 | 0.23       | 5.375             | 5.362 | 4.99            | 1.5                 | 1.5                     |
|      | HSE+SOC         | 0.00 | 0.05       | 5.357<br>5.376180 | 5.355 | 4.96            | 1.5<br>1.30163      | 1.5                     |
| CmO2 | expt<br>HSE     | 0.00 | 0.06       | 5.365             | 5.397 | a<br>6.03       | 1.0                 | 0.4                     |
|      | HSE+SOC<br>expt | 0.00 | 0.05       | 5.360<br>5.364188 | 5.386 | 6.00            | 1.0                 | 0.4                     |

a Recent NMR experiments<sup>189</sup> suggest that AmO2 carries a moment, although its magnitude has not been determined.

![](_page_25_Figure_4.jpeg)

Figure 41. (top) Computed gap (HSE) versus the experimental gap of AnO2 (An = Th, Pa, U, Np, Pu, Am, and Cm). The dashed line has a slope of unity. Note the circle for PaO2 and CmO2 represents only a computed value, as we are not aware of an experimental result. (bottom) Computed lattice constant (HSE) versus the experimental lattice parameter for the AnO2 series.

![](_page_25_Figure_6.jpeg)

Figure 42. Comparisons for lattice constant (top) and band gap (bottom) of AnO2 series calculated from HSE in a plane wave basis (current work), HSE in a Gaussian basis (ref 165) and SIC (ref 41), as well the corresponding experimental data where available.

Another interesting point that can be extracted from Table 8 is that HSE and PBEh predict the band gap in the ferromagnetic phase to be approximately 1 eV lower than is the gap in the antiferromagnet. The origin is essentially as follows: excitation of an up-spin electron from an f orbital on one actinide center is stabilized via exchange if the adjacent center is ferromagnetically aligned, reducing the excitation energy and hence the gap. It can be seen that the results from PBEh and its screened variant are quite similar, although HSE tends to produce somewhat smaller band gaps, in better agreement with experiment.

In Figures 33, 34, and 35, we show the partial densities of states from PBE, TPSS, PBEh, and HSE for the ferromagnetic and antiferromagnetic states of each oxide. The semilocal methods predict in each case that the An 5f orbitals form a metallic conduction band, with minimal O 2p character. In contrast, HSE and PBEh predict that the actinide 5f orbitals split into a valence band and an empty conduction band, with the aforementioned mixing between Pu 5f and O 2p in PuO<sub>2</sub>.

3.6.2.2.  $AnO_2$  (An = Th-Es) Series. In 2007, we presented the first systematic study of the electronic properties of the  $AnO_2$  series, An = Th-Es, using screened hybrid density functional theory. Figure 36 shows the experimental and calculated lattice parameters for the actinide oxides. There is a general decrease (the actinide contraction), with an increase observed experimentally for  $CmO_2$ . Generally speaking, HSE is in excellent agreement with experiment, with larger deviations near Cm. While HSE captures the increased lattice constant of  $CmO_2$ , it overstates the degree to which the lattice expands.

The origins of this lattice expansion can be understood from the 5f populations, shown in Figure 37; more precisely, we plot the difference between the up-spin and down-spin occupation numbers. For earlier actinides, these spin densities are close to the formal expectation for a  $\mathrm{An^{4+}}$  ion, but in the later members of the series, the actinides have lower spin density than formally expected. In other words, the oxidation state is intermediate between  $\mathrm{An^{3+}}$  and  $\mathrm{An^{4+}}$ . In addition to accounting for the increase in lattice constant of  $\mathrm{CmO_2}$ , this partial covalency explains the preference for the sesquioxides  $\mathrm{An_2O_3}$  exhibited by the later actinides, because this stoichiometry allows the actinides to take the  $\mathrm{An^{3+}}$  valency, which they evidently prefer, while retaining the  $\mathrm{O^{2-}}$  configuration.

This preference for lower oxidation states is a consequence of the evolution of actinide 5f orbital energy as one progresses across the row. It is easy to see this from the partial densities of states in Figure 38. In the early actinides, the actinide 5f orbitals are well-separated from the oxygen 2p orbitals. As one moves toward the later actinides, the 5f orbitals decrease in energy and for PuO<sub>2</sub>, AmO<sub>2</sub>, and CmO<sub>2</sub>, there is a good energy match between the An 5f orbital energy and the O 2p band (see Figure 39). This "resonance" occurs near PuO<sub>2</sub>, and the resulting mixing causes the valence band edge to be of mixed An 5f/O 2p character. The unoccupied are still predominantly An 5f, and so beginning with PuO<sub>2</sub>, they are most accurately described as charge-transfer insulators.

3.6.2.3. Dispersion in UO<sub>2</sub> and PuO<sub>2</sub>. In 2008, we present a comparison between the screened hybrid density functional theory with high-resolution photoemission (PES) measurements on a single crystal of UO<sub>2</sub>. Figure 40 shows the total and projected density of states (DOS) for AFM UO<sub>2</sub> using the scalar relativistic results from the HSE functional and also reproduces the experimental photoemission spectrum for

comparison. As one can see, the calculated peak positions and bandwidths are in good agreement with experiment.

The valence band spectra presented in Figure 3 (top) were recorded at photon energies between 16 and 87 eV along the  $\Gamma$ -X azimuth of the Brillouin zone. This technique, known as normal emission photoemission, takes advantage of the tunable synchrotron light source, where incident photon energies can be adjusted within a certain range. The dispersion in the 5f band, not observed before<sup>53</sup> due to lack of energy resolution, is on the order of 100 meV. Specifically, dispersion along  $\Gamma$ -X is  $\sim$ 130 meV, in excellent agreement with our HSE prediction<sup>54</sup> of 190 meV. Both theory and experiment agree: UO<sub>2</sub> is quite ionic, possessing a very nearly flat U 5f band, indicative of highly localized electrons. The Pu 5f/O 2p orbital mixing observed in PuO<sub>2</sub>, however, results in a significant dispersion in the 5f band of PuO<sub>2</sub>. This difference has now been confirmed by recent ARPES measurements by Joyce and Durakiewicz.<sup>58</sup>

3.6.2.4. Spin—Orbit Coupling. The HSE work above utilized Gaussian-type basis sets with a small core relativistic effective core potential. Our results on actinide dioxides are quite satisfying when compared with available experimental data. We have also compared these results with those using a plane-wave basis set and an all-electron PAW/PBE approach to treat relativity as implemented in the computer program VASP (Vienna Ab-initio Simulation Package). Calculations were performed in both the scalar relativistic (LS) limit and the fully self-consistent *j*—*j* limit, 183 as implemented in VASP by Kresse and Lebacq. The nonspherical contributions from the gradient corrections inside the PAW spheres are considered in current calculations.

Table 9 compares HSE and HSE+SOC for the relative energies and lattice constants for the AFM and FM states of the AnO<sub>2</sub> series, together with the magnetic moments and band gaps of the AFM states. One can see that there are no large changes in the properties associated with inclusion of SOC. HSE generally predicts AFM ordered AnO<sub>2</sub> to be more favorable than the corresponding FM states. SOC generally decreases the splitting between AFM and ferromagnetic states. In PaO<sub>2</sub>, PuO<sub>2</sub>, and AmO<sub>2</sub>, this leads to very small Heisenberg couplings, on the order of 10-50 meV. The lone exception is NpO<sub>2</sub>, where inclusion of SOC changes the predicted ground state from ferromagnetic to AFMI (along 100). The calculated band gaps and lattice constants (from HSE and HSE+SOC) are in good agreement with the corresponding experimental values, as shown in Table 9 and Figure 41. A comparison of the scalarrelativistic HSE results in Tables 8 and 9 allows one to see the differences between the approximations for basis set and relativity between the two approaches. This information is presented graphically in Figure 42. The density of states (DOS) of the AFM phase of AnO2 is little affected by SOC. The original publication also contains a comparison of the dielectric functions and optical properties predicted by HSE and GGA/ PBE+U approaches.

3.6.3.5.  $\alpha$ - $U_3O_8$  phase. We have systematically explored the structures and electronic and optical properties of  $U_3O_8$  in the c2mm structure, so-called  $\alpha$ - $U_3O_8$ , using PBE+U and HSE. <sup>190</sup> Our calculated results show that the HSE functional provides a better description of the electronic and optical properties when compared with available experimental data. The interested reader is referred to the original paper; however, we point out one interesting conclusion from this study. The stoichiometry suggests that there are 16 charges to associate with the three uranium sites in this compound. This could ostensibly be

![](_page_27_Picture_1.jpeg)

**Figure 43.** The crystal structure of UN. Blue balls for N atoms; green balls for U atoms. Note the (001) AFM ordering considered is shown in the red arrows.

satisfied by two U(VI) and a U(IV) or one U(VI) and two U(V) sites. HSE finds the latter situation to be realized in the ground state. This mixed-valence ground state is responsible for a low-energy U(V, $f^1$ )  $\rightarrow$  U(VI, $f^0$ ) charge transfer gap at 0.8 eV, a possibility not available in the dioxides.

# 4. THE HSE PERSPECTIVE: SUCCESSES AND LIMITATIONS

Over the past few decades, hybrid DFT has evolved in the quantum chemistry community and has revolutionized the field. We have pioneered the implementation and application of the screened hybrid approach to periodic and strongly correlated systems. This development was made possible by methodological advances with Gaussian orbitals for periodic systems, in particular fast multipole methods <sup>170,191–194</sup> and fast exact exchange approaches. <sup>195,196</sup> We emphasize that unlike other many-body remedies, the screened hybrid approach contains no adjustable, material-dependent parameters. Once validated, it therefore qualifies as a predictive tool. The HSE functional has been very successful dealing with metal oxides, as shown in many publications from the Los Alamos and Rice collaboration. This success has been rationalized from different perspectives 206-209 and is not coincidental. It has been demonstrated that screened hybrid DFT yields improved band gaps, magnetic properties, lattice constants, densities-of-states, and optical spectra for conventional semiconductors, band insulators, and the problematic Mott insulators. 31,210,211 Such gratifying agreement is not found for correlated metals because higher order dynamic magnetic correlations are not captured even in hybrid DFT. <sup>201,212–215</sup> We hope that successors to HSE will be able to address this issue. $^{216-221}$  The HISS functional $^{222-224}$  has shown early promise, although the correlated metal front remains problematic.

Uranium nitride, UN, provides a good example of the problems yet to be addressed with correlated metals. UN exhibits the well-known rock salt crystal structure, as shown in Figure 43. Unlike the insulating dioxide, the mononitride is an itinerant antiferromaget. The (001) AFM ordering is shown in the red arrows. In our study, four different AFM structures are considered, and the AFM-I type along (001) is predicted by HSE as the most favorable structure, in agreement with the experiment.<sup>225</sup>

The relative energy, lattice parameter, and magnetic moment for UN using HSE, PBE, and PBE+U for the (001) AFM-I ordering are reported in Table 10. In agreement with HSE, PBE +U predicts UN to have an AFM ground state, while PBE predicts a ferromagnetic ground state. The lattice constants from HSE (4.943 Å) and PBE (4.858 Å) are reasonably close to the experimental value of 4.890 Å, while that predicted by PBE +U (5.134 Å) is far too large. If one makes the reasonable assumption of nitrogen as trivalent, the stoichiometry of UN implies  $U^{3+}$  and  $N^{3-}$ . A  $Sf^3$  configuration for U atoms should give a moment in the vicinity of 3  $\mu_{\rm B}$ , but all computed values are smaller than this estimate (but larger than the experimental moment of  $0.75~\mu_{\rm B}$ ). These deviations may arise in part from the effects of spin—orbit coupling, as found by Gryaznov et al. <sup>131</sup> in their DFT+U studies.

The most dramatic evidence of a problem with HSE for this correlated metal comes when a comparison is made between the DOS and the X-ray photoelectron spectroscopy. 227-229 Figure 44 shows the calculated density of states and band structure for UN by HSE, PBE, and PBE+U. The states near the Fermi level derived from HSE and PBE+U calculations are principally of U 5f parentage. At higher binding energy one finds N 2p derived bands. Note that both HSE and PBE+U predict very little density at the Fermi level. X-ray photoelectron spectroscopy indicates, however, that the U 5f orbitals form a rather narrow band strongly peaked at the Fermi level. 227-229 Interestingly, given the well-known problems associated with the semilocal functionals in strongly correlated systems, the PBE DOS correctly reproduces the strong 5f orbital peak at the Fermi level, even while incorrectly predicting the ground state to be ferromagnetic. The possibility that final state effects in the photoelectron spectrum render a direct comparison between the initial state DOS and experiment meaningless must be addressed before a firm conclusion is reached, but we tentatively conclude that screened hybrid DFT is missing key physics for the remaining piece of the puzzle, the correlated metallic regime. Given the well-known failures of exact nonlocal exchange in metallic systems, this may be an

Table 10. Calculated Relative Energy (eV per UN; Related to the Corresponding AFM-I state), Lattice Constants (Å), and Magnetic Moment ( $\mu_B$  per U) Using HSE, PBE, and PBE+U (U = 4.5)

|       | E <sub>rel.</sub> (eV per UN) |       |      | $a_0$ (Å)           |       |       | $\mu~(\mu_{ m B})$ |      |
|-------|-------------------------------|-------|------|---------------------|-------|-------|--------------------|------|
|       | AFM-I <sup>a</sup>            | FM    | NM   | AFM-I <sup>a</sup>  | FM    | NM    | AFM-I              | FM   |
| HSE   | 0.00                          | 0.22  | 0.67 | 4.943               | 4.860 | 4.795 | 1.82               | 1.74 |
| PBE   | 0.00                          | -0.04 | 0.04 | 4.858               | 4.868 | 4.856 | 1.04               | 1.28 |
| PBE+U | 0.00                          | 0.01  | 1.20 | 5.134               | 5.138 | 4.895 | 2.53               | 2.70 |
| expt  |                               |       |      | 4.890 <sup>49</sup> |       |       | $0.75^{225,226}$   |      |

<sup>&</sup>lt;sup>a</sup>The small tetragonal disorder with  $a = b \neq c$  has been found in AFM-I states (by the three methods) of UN.

![](_page_28_Figure_1.jpeg)

Figure 44. Calculated density of states (DOS) and band structure for AFM-I UN by PBE, PBE+U, and HSE.

indication that the exchange term should be screened dynamically as the calculation proceeds.

#### 5. CONCLUDING REMARKS

We have surveyed a series of methods, including LDA/GGA, DFT+U, SIC, DFT+DMFT, and HSE, assessing their predictive capability for the Mott insulating actinide dioxides. Our focus has been on lattice constants, electronic densities-of-states, band gaps, and magnetic and optical properties. Of particular interest to us is the nature and magnitude of the gap. Table 11 and Figure 45 present a comparison of the various approximations for those materials where information is available.

We conclude that the screened hybrid HSE functional gives a reasonable reproduction of the electronic and optical properties for these actinide dioxides when compared with available experimental data. Unlike DFT+U, HSE does not require the introduction of any material-specific parameters. Problems remaining to be addressed include multiplet effects and the proper treatment of complex magnetic properties. We also find that with a judiciously chosen *U*, the DFT+U approach can predict reasonable band gaps, generally at the expense of other important properties such as lattice constants and densities of states. The most dramatic difference between HSE and SIC-DFT or DMFT is in the qualitative nature of the gap as a

function of the atomic number *Z*, where SIC and DMFT predict even the early members of the series to be charge-transfer insulators, while HSE correctly predicts the early actinide dioxides to be Mott insulators.

The development of HSE has provided new and exciting insights into the fundamental chemistry and physics of these strongly correlated insulators. However, there is still work to be done with the primary need for further improvement being associated with the ability to describe strongly correlated metals.

### **AUTHOR INFORMATION**

#### **Corresponding Author**

\*E-mail: rlmartin@lanl.gov.

#### Notes

The authors declare no competing financial interest.

Table 11. Comparison of Various Many-Body Approximations, as Well as Experiment, for the Lattice Constant (Å), Band Gap (eV), and Insulator Classification for UO<sub>2</sub>, NpO<sub>2</sub> and PuO<sub>2</sub>

|                 |                                  | band gap<br>(eV)   | latt. const.<br>(Å) | classification                     |
|-----------------|----------------------------------|--------------------|---------------------|------------------------------------|
| UO <sub>2</sub> | HSE (VASP) <sup>a</sup>          | 2.4                | 5.458               | Mott-Hubbard                       |
|                 | HSE<br>(Gaussian) <sup>165</sup> | 2.6                | 5.463               | Mott-Hubbard                       |
|                 | PBE+U <sup>a</sup>               | 2.3                | 5.568               | Mott-Hubbard                       |
|                 | SIC <sup>41</sup>                | $0.0^{b}$          | 5.400               |                                    |
|                 | DMFT <sup>44</sup>               | 2.5                |                     | charge-transfer                    |
|                 | expt                             | 2.1 <sup>45</sup>  | 5.470 <sup>49</sup> | Mott–<br>Hubbard <sup>55,155</sup> |
| $NpO_2$         | HSE $(VASP)^a$                   | 2.4                | 5.412               | Mott-Hubbard                       |
|                 | HSE<br>(Gaussian) <sup>165</sup> | 2.8                | 5.430               | Mott-Hubbard                       |
|                 | PBE+U <sup>a</sup>               | 2.6                | 5.498               | charge-transfer                    |
|                 | SIC <sup>41</sup>                | 2.3                | 5.460               | charge-transfer                    |
|                 | DMFT <sup>44</sup>               |                    |                     |                                    |
|                 | expt                             | 2.80 <sup>48</sup> | 5.420 <sup>50</sup> | Mott-<br>Hubbard <sup>230</sup>    |
| $PuO_2$         | $HSE (VASP)^a$                   | 2.6                | 5.383               | charge-transfer                    |
|                 | HSE<br>(Gaussian) <sup>165</sup> | 2.8                | 5.396               | charge-transfer                    |
|                 | PBE+U <sup>a</sup>               | 1.6                | 5.465               | charge-transfer                    |
|                 | SIC <sup>41</sup>                | 1.2                | 5.440               | charge-transfer                    |
|                 | DMFT <sup>44</sup>               | ~3.5               |                     | charge-transfer                    |
|                 | expt                             | 2.85 <sup>48</sup> | 5.398 <sup>51</sup> | charge-transfer <sup>56</sup>      |
|                 |                                  |                    |                     |                                    |

<sup>&</sup>lt;sup>a</sup>Current work. <sup>b</sup>The SIC finds an insulating state with a gap of 2.6 eV (a charge-transfer insulator), only 100 meV higher than this metallic ground state.

#### **Biographies**

![](_page_29_Picture_5.jpeg)

Xiao-Dong Wen received his Ph.D. degree from Institute of Coal Chemistry, Chinese Academy of Sciences, in 2007. During his Ph.D. research (2002–2007), he focused on the theoretical description of MoS<sub>2</sub> catalyst structure, the hydrodesulfurization mechanism, and Fischer—Tropsch chemistry (Fe-based catalysts). After his Ph.D., Dr. Wen joined the group of Dr. Roald Hoffmann and Dr. Neil Ashcroft at Cornell University where his research centered on the molecular orbital theory, materials of low dimensionality, and studies of electronic properties at high pressure. Beginning in 2010, Dr. Wen joined the Theoretical Division (T-1) at Los Alamos National Laboratory under a Seaborg Institute Postdoctoral Fellowship (research mentor Dr. Richard L. Martin) and is working on strongly correlated systems and magnetic materials (f-element and first-row transition metal systems).

![](_page_29_Figure_7.jpeg)

Figure 45. (top) Correlation of experimental gap (for  $UO_2$ ,  $NpO_2$ , and  $PuO_2$ ) with computed gap from various approximations. (bottom) Correlation of experimental lattice constant (for  $UO_2$ ,  $NpO_2$ , and  $PuO_2$ ) with computed lattice constant from various approximations. We were unable to find lattice constants reported with DMFT.

![](_page_29_Picture_9.jpeg)

Richard L. Martin is currently a Laboratory Fellow at Los Alamos National Laboratory. Dr. Martin received his Ph.D. in chemistry from the University of California, Berkeley, and spent two years as a Chaim Weizmann fellow at the University of Washington before joining the Theoretical Division at Los Alamos National Laboratory. He is a Fellow of the American Association for the Advancement of Science (AAAS) and a recipient of a DOE Award of Excellence. His research interests lie in the electronic structure theory of molecules and solids, especially transition metal and actinide chemistry, charge and energy localization and transport in molecularly engineered electronic materials and devices, strongly correlated materials, and homogeneous catalysis.

![](_page_30_Picture_1.jpeg)

Thomas M. Henderson is a senior research scientist at Rice University. He received his Ph.D. in physics from the University of Florida under the supervision of Dr. Rodney Bartlett. After completing his Ph.D., he joined the group of Dr. Jim Greer at the Tyndall National Institute in Cork, Ireland, before joining the Scuseria group.

![](_page_30_Picture_3.jpeg)

Gustavo E. Scuseria is currently Robert A. Welch Professor of Chemistry and Professor of Physics and Astronomy at Rice University in Houston, Texas. Dr. Scuseria received his B.S. and Ph.D. from the University of Buenos Aires in Argentina. He has held positions at the University of Buenos Aires, University of California, Berkeley, and University of Georgia before settling at Rice University in 1989. He is a fellow of the American Chemical Society, the American Physical Society, the Royal Society of Chemistry, and the American Association for the Advancement of Science (AAAS). Over the past 25 years, his research group has pioneered quantum chemistry methodologies for molecules and the solid state. He is Editor of the ACS Journal of Chemical Theory and Computation.

#### ACKNOWLEDGMENTS

This work was supported under the Heavy Element Chemistry Program at Los Alamos National Laboratory by the Division of Chemical Sciences, Geosciences, and Biosciences, Office of Basic Energy Sciences, U.S. Department of Energy. Portions of the work were also supported by the LDRD program at Los Alamos National Laboratory. Xiao-Dong Wen gratefully acknowledges a Seaborg Institute Fellowship. The work at Rice University is supported by DOE, Office of Basic Energy Sciences, Heavy Element Chemistry program, under Grant DE-FG02-04ER15523. Some of the calculations were performed on the Chinook computing systems at the Molecular Science Computing Facility in the William R. Wiley Environmental Molecular Sciences Laboratory (EMSL) at PNNL. The Los Alamos National Laboratory is operated by Los Alamos National Security, LLC, for the National Nuclear Security Administration of the U.S. Department of Energy under Contract DE-AC5206NA25396.

#### REFERENCES

- (1) Mott, N. F. Proc. Phys. Soc., London, Sect. A 1949, 62, 416.
- (2) The Chemistry of the Actinide and Transactinide Elements; Morss, L. R., Edelstein, N M., Fuger, J., Eds.; Springer: Dordrecht, The Netherlands, 2006.
- (3) Edelstein, N. M.; Lander, G. H. In The Chemistry of the Actinide and Transactinide Elements, 3rd ed.; Morss, L. R., Edelstein, N. M., Fuger, J., Katz, J. J. Springer: Dordrecht, The Netherlands, 2006; Vol. 4, pp 2225−2306.
- (4) Santini, P.; Caretta, S.; Amoretti, G.; Caciuffo, R.; Magnani, N.; Lander, G. H. Rev. Mod. Phys. 2009, 81, 807.
- (5) Moore, K. T.; van der Laan, G. Rev. Mod. Phys. 2009, 81, 235.
- (6) Hoffmann, R. Solids and Surfaces: A Chemist's View of Bonding in Extended Structures,\; WILEY-VCH: New York, 1988.
- (7) Albright, T. A.; Burdett, J. K.; Whangbo, M.-H. Orbital Interaction In Chemistry; John Wiley & Sons, Inc: New York, 1985.
- (8) Ellis, D. E.; Rosen, A.; Gubanov, V. A. J. Chem. Phys. 1982, 77, 4051.
- (9) Gubanov, V. A.; Rosen, A.; Ellis, D. E. J. Phys. Chem. Solids 1979, 40, 17.
- (10) Bagus, P. S.; Ilton, E. S.; Martin, R. L.; Jensen, H. J. Aa.; Knecht, S. Chem. Phys. Lett. 2012, 546, 58.
- (11) Perdew, J. P.; Burke, K.; Ernzerhof, M. Phys. Rev. Lett. 1996, 77, 3865; 1997, 78, 1396 (E).
- (12) Anisimov, V. I., Lichtenstein, A. I. LDA+U Method: Screened Coulomb Interaction in the Mean-field Approximation. In Strong Coulomb Correlations in Electronic Structure Calculations: Beyond the Local Density Approximation; Anisimov, V. I., Ed.; Gordon and Breach Science Publishers: Amsterdam, 2000.
- (13) Heyd, J.; Scuseria, G. E.; Ernzerhof, M. J. Chem. Phys. 2003, 118, 8207.
- (14) Heyd, J.; Scuseria, G. E.; Ernzerhof, M. J. Chem. Phys. 2006, 124, No. 219906.
- (15) Perdew, J. P.; Zunger, A. Phys. Rev. B 1981, 23, 5048.
- (16) Georges, A.; Kotliar, G.; Krauth, W.; Rozenberg, M. J. Rev. Mod. Phys. 1996, 68, 13.
- (17) Kresse, G.; Hafner, J. Phys. Rev. B 1993, 47, 558; 1994, 49, 14251.
- (18) Frisch, M. J.; Trucks, G. W.; Schlegel, H. B.; Scuseria, G. E.; Robb, M. A.; Cheeseman, J. R.; Scalmani, G.; Barone, V.; Mennucci, B.; Petersson, G. A.; Nakatsuji, H.; Caricato, M.; Li, X.; Hratchian, H. P.; Izmaylov, A. F.; Bloino, J.; Zheng, G.; Sonnenberg, J. L.; Hada, M.; Ehara, M.; Toyota, K.; Fukuda, R.; Hasegawa, J.; Ishida, M.; Nakajima, T.; Honda, Y.; Kitao, O.; Nakai, H.; Vreven, T.; Montgomery, J. A., Jr.; Peralta, J. E.; Ogliaro, F.; Bearpark, M.; Heyd, J. J.; Brothers, E.; Kudin, K. N.; Staroverov, V. N.; Kobayashi, R.; Normand, J.; Raghavachari, K.; Rendell, A.; Burant, J. C.; Iyengar, S. S.; Tomasi, J.; Cossi, M.; Rega, N.; Millam, J. M.; Klene, M.; Knox, J. E.; Cross, J. B.; Bakken, V.; Adamo, C.; Jaramillo, J.; Gomperts, R.; Stratmann, R. E.; Yazyev, O.; Austin, A. J.; Cammi, R.; Pomelli, C.; Ochterski, J. W.; Martin, R. L.; Morokuma, K.; Zakrzewski, V. G.; Voth, G. A.; Salvador, P.; Dannenberg, J. J.; Dapprich, S.; Daniels, A. D.; Farkas, O.; Foresman, J. B.; Ortiz, J. V.; Cioslowski, J.; Fox, D. J. Gaussian 09, revision A.1; Gaussian, Inc.: Wallingford, CT, 2009.
- (19) Perdew, J.; Kurth, S.; Zupan, A.; Blaha, P. Phys. Rev. Lett. 1999, 82, 2544.
- (20) Kudin, K. N.; Scuseria, G. E.; Martin, R. L. Phys. Rev. Lett. 2002, 89, No. 266402.
- (21) Prodan, I. D.; Scuseria, G. E.; Sordo, J. A.; Kudin, K. N.; Martin, R. L. J. Chem. Phys. 2005, 123, No. 014703.
- (22) McNeilly, C. E. J. Nucl. Mater. 1964, 11, 53.
- (23) Cohen, A. J.; Mori-Sanchez, P.; Yang, W. ́ Science 2008, 792, 321 and references therein.

- (24) Anisimov, V. I.; Zaanen, J.; Andersen, O. K. Phys. Rev. B 1991, 44, 943.
- (25) Anisimov, V. I.; Solovyev, I. V.; Korotin, M. A.; Xzyzyk, M. T.; Sawatzky, G. A. *Phys. Rev. B* **1993**, 48, 16929.
- (26) Petukhov, A. G.; Mazin, I. I.; Chioncel, L.; Lichtenstein, A. I. *Phys. Rev. B* **2003**, 67, No. 153106.
- (27) Lichtenstein, A. I.; Katsnelson, M. I. Phys. Rev. B 1998, 57, 6884.
- (28) Kotliar, G.; Savrasov, S. Y.; Haule, K.; Oudovenko, V. S.; Parcollet, O.; Marianetti, C. A. Rev. Mod. Phys. 2006, 78, 865.
- (29) Becke, A. D. J. Chem. Phys. 1993, 98, 1372.
- (30) Perdew, J.; Enzerhof, M.; Burke, K. J. Chem. Phys. 1997, 105, 9982.
- (31) Henderson, T. M.; Paier, J.; Scuseria, G. E. Phys. Status Solidi B **2011**, 248, 767.
- (32) Heyd, J.; Peralta, J. E.; Scuseria, G. E.; Martin, R. L. J. Chem. Phys. **2005**, 123, No. 174101.
- (33) Liu, W. Mol. Phys. 2010, 108, 1679.
- (34) Pyykkö, P. Chem. Rev. 2012, 112, 371.
- (35) Pyykkö, P. Annu. Rev. Phys. Chem. 2012, 63, 45.
- (36) Autschbach, J. J. Chem. Phys. 2012, 136, No. 150902.
- (37) Balasubramanian, K. Relativistic Effects in Chemistry; Wiley, New York, 1997; Part A, Theory and Techniques, and Part B, Application.
- (38) Grant, I. P. Relativistic Quantum Theory of Atoms and Molecules; Springer: New York, 2006.
- (39) Reiher, M.; Wolf, A. Relativistic Quantum Chemistry: The Fundamental Theory of Molecular Science; Wiley-VCH: Weinheim, Germany, 2009.
- (40) Kummel, S.; Kronik, L. Rev. Mod. Phys. 2008, 80, 3.
- (41) Petit, L.; Svane, A.; Szotek, Z.; Temmerman, W. M.; Stocks, G. M. *Phys. Rev. B* **2010**, *81*, No. 045108.
- (42) Petit, L.; Svane, A.; Szotek, Z.; Temmerman, W. M.; Stocks, G. M. *Mater. Res. Soc. Symp. Proc.* **2010**, DOI: 10.1557/PROC-1265-AA05-04-Z07-04.
- (43) Yin, Q.; Savrasov, S. Y. Phys. Rev. Lett. 2008, 100, No. 225504.
- (44) Yin, Q.; Kutepov, A.; Haule, K.; Kotliar, G.; Savrasov, S. Y.; Pickett, W. E. *Phys. Rev. B* **2011**, *84*, No. 195111.
- (45) Kern, S.; Robinson, R. A.; Nakotte, H.; Lander, G. H.; Cort, B.; Wason, P.; Vigil, F. A. *Phys. Rev. B* **1999**, *59*, 104.
- (46) Caciuffo, R.; Santini, P.; Carretta, S.; Amoretti, G.; Hiess, A.; Magnani, N.; Regnault, L.-P.; Lander., G. H. *Phys. Rev. B* **2011**, 84, No. 104409.
- (47) Lide, D. R. Handbook of Chemistry and Physics, 87th ed.; CRC Press: Boca Raton, FL, 1998.
- (48) McCleskey, T. M.; Bauer, E.; Jia, Q.; Burrell, A. K.; Scott, B. L.; Conradson, S. D.; Mueller, A.; Roy, L.; Wen, X.-D.; Scuseria, G. E.; Martin, R. L. *J. Appl. Phys.* **2013**, *113*, (1).
- (49) Schoenes, J. J. Appl. Phys. 1978, 49, 1463.
- (50) Yamashita, T.; Nitani, N.; Tsuji, T.; Inagaki, H. J. Nucl. Mater. 1997, 247, 90.
- (51) Haschke, J. M.; Allen, T. H.; Morales, L. A. Science 2000, 287, 285.
- (52) Idiri, M.; Le Bihan, T.; Heathman, S.; Rebizant, J. Phys. Rev. B **2004**, 70, No. 014113.
- (53) Cox, L. E.; Ellis, W. P.; Cowan, R. D.; Allen., J. W.; Oh, S.-J.; Lindau, I.; Pate, B. B.; Arko, A. J. Phys. Rev. B 1987, 35, 5761.
- (54) Roy, L. E.; Durakiewicz, T. D.; Martin, R. L.; Peralta, J. R.; Scuseria, G. E.; Olson, C. G.; Joyce, J. J.; Guziewicz, E. J. Comput. Chem. 2008, 29, 2288.
- (55) Yu, S.-W.; Tobin, J. G.; Crowhurst, J. C.; Sharma, S.; Dewhurst, J. K.; Velasco, P. O.; Yang, W. L.; Siekhaus, W. J. *Phys. Rev. B* **2011**, *83*, No. 165102.
- (56) Modin, A.; Yun, Y.; Suzuki, M.-T.; Vegelius, J.; Werme, L.; Nordgren, J.; Oppeneer, P. M.; Butorin, S. M. *Phys. Rev. B* **2011**, 83, No. 075113.
- (57) Modin, A.; Butorin, S. M.; Vegelius, J.; Olsson, A.; Englund, C.-J.; Andersson, J.; Werme, L.; Nordgren, J.; Käämbre, T.; Skarnemark, G.; Burakov, B. E. *Rev. Sci. Instrum.* **2008**, *79*, No. 093103.
- (58) Joyce, J. J.; Durakiewicz, T.; Graham, K. S.; Bauer, E. D.; Moore, D. P.; Mitchell, J. N.; Kennison, J. A.; McCleskey, T. M.; Jia, Q.;

Burrell, A. K.; Bauer, E.; Martin, R. L.; Roy, L. E.; Scuseria, G. E. *Mater. Res. Soc. Symp. Proc.* **2010**, *1264*, Z09-04.

- (59) Dunlap, B. D.; Kalvius, G. M. In *Handbook on the Physics and Chemistry of the Actinides*; Freeman, A. J., Lander, G. H., Eds.; Elsevier Science Publisher B.V: New York, 1985; Vol. 2, Chapter 5.
- (60) Ross, J. W.; Lam, D. J. J. Appl. Phys. 1967, 38, 1451.
- (61) Cox, D.; Frazer, B. C. J. Phys. Chem. Solids 1967, 28, 1649.
- (62) Dunlap, B. D.; Kalvius, G. M.; Lam, D. J.; Brodsky, M. B. J. *Phys. Chem. Solids* **1968**, 29, 1365.
- (63) Żolnierek, A.; Solt, G.; Eedös, P. J. Phys. Chem. Solids 1981, 42, 773.
- (64) Los Alamos Science, Cooper, N. G., Ed.; Los Alamos National Laboratory: Los Alamos, NM, 2000; Vol. 26.
- (65) Colarieti-Tosti, M.; Eriksson, O.; Nordstrom, L.; Wills, J.; Brooks, M. S. S. *Phys. Rev. B* **2002**, *65*, No. 195102.
- (66) Erdös, P.; Solt, G.; Zolnierek, Z.; Blaise, A.; Fournier, J. M. *Physica B* **1980**, *102*, 164.
- (67) Yasuoka, H.; Koutroulakis, G.; Chudo, H.; Richmond, S.; Veirs, D. K.; Smith, A. I.; Bauer, E. D.; Thompson, J. D.; Jarvinen, G. D.; Clark, D. L. *Science* **2012**, 336, 901.
- (68) Ikushima, K.; Tsutsui, S.; Haga, Y.; Yasuoka, H.; Walstedt, R. E.; Masaki, N. M.; Nakamura, A.; Nasu, S.; Onuki, Y. *Phys. Rev. B* **2001**, 63, No. 104404.
- (69) Tokunaga, Y.; Homma, Y.; Kambe, S.; Aoki, D.; Sakai, H.; Yamamoto, E.; Nakamura, A.; Shiokawa, Y.; Walstedt, R. E.; Yasuoka, H. *Phys. Rev. Lett.* **2005**, *94*, No. 137209.
- (70) Butterfield, M.; Durakiewicz, T.; Guziewicz, E.; Joyce, J. J.; Arko, A.; Graham, K.; Moore, D.; Morales, L. Surf. Sci. 2004, 571, 74.
- (71) Kelly, P. J.; Brooks, M. S. S.; Allen, R. J. Phys. (Paris) 1979, 40, C4.
- (72) Veal, B. W.; Lam, D. J.; Diamond, H.; Hoekstra, H. R. Phys. Rev. B 1977, 15, 2929.
- (73) Kelly, P. J.; Brooks, M. S. S. J. Phys. C: Solid State Phys. 1980, 13, L939.
- (74) Kelly, P. J.; Brooks, M. S. S. Physica 1980, 102B, 81.
- (75) Arko, A. J.; Koelling, D. D.; Boring, A. M.; Ellis, W. P.; Cox, L. E. J. Less-Common Met. 1986, 122, 95.
- (76) Maehira, T.; Hotta, T. J. Magn. Magn. Mater. 2007, 310, 754.
- (77) Jayakumara, O. D.; Gopalakrishnana, I. K.; Vinub, A.; Asthanac, A.; Tyagia, A. K. J. Alloys Compd. 2008, 461, 608.
- (78) Pickard, C. J.; Winkler, B.; Chen, R. K.; Payne, M. C.; Lee, M. H.; Lin, J. S.; White, J. A.; Milman, V.; Vanderbilt, D. *Phys. Rev. Lett.* **2000**, *85*, 5122.
- (79) Boettger, J. C.; Ray, A. K. Int. J. Quantum Chem. 2000, 80, 824.
- (80) Boettger, J. C.; Ray, A. K. Int. J. Quantum Chem. 2002, 90, 1470.
- (81) Boettger, J. C. Eur. Phys. J. B 2003, 36, 15.
- (82) Petit, T.; Morel, B.; Lemaignan, C.; Pasturel, A.; Bigot, B. *Philos. Mag. B* **1996**, *73*, 893.
- (83) Fritz, I.; , J. J. Appl. Phys. 1976, 47, 4353.
- (84) Freyss, M.; Vergnet, N.; Petit, T. J. Nucl. Mater. 2006, 352, 144.
- (85) Yun, Y.; Kim, H.; Kim, H.; Park, K. J. Nucl. Mater. 2008, 378, 40.
- (86) Yun, Y.; Eriksson, O.; Oppeneer, P. M. J. Nucl. Mater. 2009, 385, 510.
- (87) Yun, Y.; Eriksson, O.; Oppeneer, P. M. J. Nucl. Mater. 2009, 385, 364.
- (88) Yun, Y.; Oppeneer, P. M.; Kim, H.; Park, K. Acta Mater. 2009, 57, 1655.
- (89) Yun, Y.; Oppeneer, P. M. MRS Bull. 2011, 36, 178.
- (90) Yun, Y.; Legut, D.; Oppeneer, P. M. J. Nucl. Mater. 2012, 426,
- (91) Freyss, M.; Petit, T.; Crocombette, J.-P. J. Nucl. Mater. 2005, 347, 44.
- (92) Prodan, I. D.; Scuseria, G. E.; Martin, R. L. Phys. Rev. B 2006, 73, No. 045104.
- (93) Kelly, P. J.; Brooks, M, S. S. J. Chem. Soc., Faraday Trans. 2 1987, 83, 1189.
- (94) Goodman, G. L. J. Alloys Compd. 1992, 181, 33.
- (95) Xia, S.; Krupa, J. C. J. Alloys Compd. 2000, 307, 61.

- (96) Dudarev, S. L.; Manh, D. N.; Sutton , A. P. Phil. Mag. B 1997, 75, 613.
- (97) Dudarev, S. L.; Castell, M. R.; Botton, G. A.; Savrasov, S. Y.; Muggelberg, C.; Briggs, G. A. D.; Sutton, A. P.; Goddard, D. T. Micron 2000, 31, 363.
- (98) Cohen, A. J.; Mori-Sanchez, P.; Yang, W. ́ Chem. Rev. 2012, 112, 289.
- (99) Mott, N. F. Metal-Insulator Transitions; Taylor & Francis: London, 1974.
- (100) Hubbard, J. Proc. R. Soc. A 1963, 276, 238; 1964, 277, 237; 1964, 281, 401.
- (101) Anisimov, V. I.; Aryasetiawanz, F.; Lichtenstein, A. I. J. Phys.: Condens. Matter 1997, 9, 767.
- (102) Antonov, V. N.; Bekenov, L. V.; Yaresko, A. N. Adv. Condens. Matter Phys. 2011, 2011, No. 298928.
- (103) Albers, R. C.; Christensen, N. E.; Svane, A. J. Phys.: Condens. Matter 2009, 21, No. 343201.
- (104) Baer, Y.; Schonene, J. Solid State Commun. 1980, 33, 885.
- (105) Schonene, J. J. Chem. Soc., Faraday Trans. 2 1987, 83, 1205.
- (106) Kotani, A.; Yamazaki, T. Prog. Theor. Phys. Suppl. 1992, 108, 117.
- (107) Yun, Y.; Kim, H.; Kim, H.; Park, K. Nucl. Eng. Technol. 2005, 37, 293.
- (108) Yun, Y.; Kim, H.; Kim, H.; Park, K. J. Korean Phys. Soc. 2007, 50, 1285.
- (109) Laskowski, R.; Madsen, G. K. H.; Blaha, P.; Schwarz, K. Phys. Rev. B 2004, 69, No. 140408.
- (110) Gryaznov, D.; Heifets, E.; Sedmidubsky, D. Phys. Chem. Chem. Phys. 2010, 12, 12273.
- (111) Zhou, F.; Ozolins, V. ̌ Phys. Rev. B 2011, 83, No. 085106.
- (112) Dorado, B.; Amadon, B.; Freyss, M.; Bertolus, M. Phys. Rev. B 2009, 79, No. 235125.
- (113) Geng, H. Y.; Chen, Y.; Kanea, Y.; Kinoshita, M. Phys. Rev. B 2007, 74, No. 054111.
- (114) Song, H. X.; Geng, H. Y.; Wu, Q. Phys. Rev. B 2012, 85, No. 064110.
- (115) Yu, J.; Devanathan, R.; Weber, W. J. J. Phys.: Condens. Matter 2009, 21, No. 435401.
- (116) Desai, T. G.; Uberuaga, B. P. Scr. Mater. 2009, 60, 878.
- (117) Gupta, F.; Brillant, G.; Pasturel, A. Philos. Mag. 2007, 87, 2561.
- (118) Thompson, A. E.; Wolverton, C. Phys. Rev. B 2011, 84, No. 134111.
- (119) Nerikar, P.; Watanabe, T.; Tulenko, J. S.; Phillpot, S. R.; Sinnott, S. B. J. Nucl. Mater. 2009, 384, 61.
- (120) Iwasawa, M.; Chen, Y.; Kaneta, Y.; Ohnuma, T.; Geng, H.-Y.; Kinoshita, M. Mater. Trans. 2006, 47, 2651.
- (121) Geng, H. Y.; Chen, Y.; Kaneta, Y.; Kinoshita., M. Appl. Phys. Lett. 2008, 93, No. 201903.
- (122) Geng, H. Y.; Chen, Y.; Kaneta, Y.; Iwasawa, M.; Ohnuma, T.; Kinoshita, M. Phys. Rev. B 2008, 77, No. 104120.
- (123) Dorado, B.; Jomard, G.; Freyss, M.; Bertolus, M. Phys. Rev. B 2010, 82, No. 035114.
- (124) Gupta, F.; Pasturel, A.; Brillant, G. Phys. Rev. B 2010, 81, No. 014110.
- (125) Gryaznov, D.; Heifets, E.; Kotomin, E. Phys. Chem. Chem. Phys. 2009, 11, 7241.
- (126) Gryaznov, D.; Rashkeev, S.; Kotomin, E. A.; Heifets, E.; Zhukovskii, Y. Nucl. Instrum. Methods Phys. Res., Sect. B 2010, 268, 3090.
- (127) Dorado, B.; Freyss, M.; Martin, G. Eur. Phys. J. B 2009, 69, 203.
- (128) Brillant, G.; Gupta, F.; Pasturel, A. J. Nucl. Mater. 2011, 412, 170.
- (129) Shi., H.; Chu, M.; Zhang., P. J. Nucl. Mater. 2010, 400, 151.
- (130) Devey, A. J. J. Nucl. Mater. 2011, 412, 301.
- (131) Gryaznov, D.; Heifets, E.; Kotomin, E. Phys. Chem. Chem. Phys. 2012, 14, 4482.
- (132) Sun, B.; Zhang, P.; Zhao, X.-G. J. Chem. Phys. 2008, 128, No. 084705.
- (133) Shi, H.; Zhang, P. J. Nucl. Mater. 2012, 420, 159.

- (134) Sun, B.; Zhang, P. Chin. Phys. B 2008, 17, 1364.
- (135) Sun, B.; Zhang, P.; Zhao, X.-G. J. Chem. Phys. 2009, 131, No. 169903.
- (136) Zhang, P.; Wang, B.-T.; Zhao, X.-G. Phys. Rev. B 2010, 82, No. 144110.
- (137) Wang, B.-T.; Zhang, P. Chin. Phys. Lett. 2011, 28, No. 047101.
- (138) McCart, B.; Lander, G. H.; Aldred, A. T. J. Chem. Phys. 1981, 74, 5263.
- (139) Wulff, M.; Lander, G. H. J. Chem. Phys. 1988, 89, 3295.
- (140) Lu, Y.; 1 Yang, Y.; Zheng, F.; Zhang, P. arXiv 2012, 1208, 3746.
- (141) Jomard, G.; Amadon, B.; Bottin, F.; Torrent, M. Phys. Rev. B 2008, 78, No. 075125.
- (142) Nakamura, H.; Machida, M.; Kato, M. Phys. Rev. B 2010, 82, No. 155131.
- (143) Neidig, M. L.; Clark, D. L.; Martin, R. L. Coord. Chem. Rev. 2012, 257, 394−406.
- (144) Wang, B.-T.; Shi, H.; Li, W.; Zhang, P. Phys. Rev. B 2010, 81, No. 045119.
- (145) Yun, Y.; Rusz, J.; Suzuki, M.-T.; Oppeneer, P. M. Phys. Rev. B 2011, 83, No. 075109.
- (146) Suzuki, M.-T.; Magnani, N.; Oppeneer, P. M. Phys. Rev. B 2010, 82, No. 241103(R).
- (147) Andersson, D. A.; Lezama, J.; Uberuaga, B. P.; Deo, C.; Conradson, S. D. Phys. Rev. B 2009, 79, No. 024110.
- (148) Friedt, J. M.; Litterst, J. M.; Rebizant, J. Phys. Rev. B 1985, 32, 257.
- (149) Wang, B.; Shi, H.; Li, W.; Zhang, P. J. Nucl. Mater. 2009, 399, 181.
- (150) Sevik, C.; Çağın, T. Phys. Rev. B 2009, 80, No. 014108.
- (151) Kanchana, V.; Vaitheeswaran, G.; Svane, A.; Delin, A. J. Phys.: Condens. Matter 2006, 18, 9615.
- (152) Olsen, J. S.; Gerward, L.; Kanchana, V.; Vaitheeswaran, G. J. Alloys Compd. 2004, 381, 37.
- (153) Kotliar, G.; Vollhardt, D. Phys. Today 2004, 57 (3), 53.
- (154) Tobin, J. G.; Yu, S. -W. Phys. Rev. Lett. 2011, 107, No. 167406.
- (155) An, Y.; Taylor, A. J.; Conradson, S. D.; Trugman, S. A.; Durakiewicz, T.; Rodriguez, G. Phys. Rev. Lett. 2011, 106, 207402.
- (156) Manley, M. E.; Jeffries, J. R.; Said, A. H.; Marianetti, C. A.; Cynn, H.; Leu, B. M.; Wall, M. A. Phys. Rev. B 2012, 85, No. 132301.
- (157) Minamoto, S.; Kato, M.; Konashi, K.; Kawazoe, Y. J. Nucl. Mater. 2009, 385, 18.
- (158) Blaha, P. K.; Schwarz, K.; Madsen, G.; Kvasnicka, D.; Luitz, J. WIEN2K package, see http://www.wien2k.at.
- (159) Zhang, F. C.; Rice, T. M. Phys. Rev. B 1988, 37, 3759.
- (160) Petit, L.; Svane, A.; Szotek, Z.; Temmerman, W. M. Science 2003, 301, 498.
- (161) Penneman, R. H.; Paffett, M. T. Actinide Research Quarterly; Los Alamos National Laboratory, Los Alamos, NM, 2004; 2nd Quarter, pp 9−13.
- (162) Villars, P.; Calvert, L. D. Pearson's Handbook of Cystallographic Data for Intermetallic Phases, 2nd ed.; ASM International: Materials Park, OH, 1991.
- (163) Suzuki, C.; Nishi, T.; Nakada, M.; Akabori, M.; Hirata, M.; Kaji, Y. J. Phys. Chem. Solids 2012, 73, 209.
- (164) Dancausse, J. P.; Haire, R. G.; Heathman, S.; Benedict, U. J. Nucl. Sci. Technol. 2002, 3, 136.
- (165) Prodan, I. D.; Scuseria, G. E.; Martin, R. L. Phys. Rev. B 2007, 76, No. 033101.
- (166) Soderholm, L. J. Less-Common Met. 1987, 133, 77.
- (167) Morss, L. R.; Richardson, J. W.; Williams, C. W.; Lander, G. H.; Lawson, A. C.; Edelstein, N. M.; Shalimoff, G. V. J. Less-Common Met. 1989, 156, 273.
- (168) Becke, A. D. In Modern Electronic Theory; Yarkony, D. A., Ed.; World Scientific: Singapore, 1995; Part 2.
- (169) Gorling, A.; Levy, M. J. Chem. Phys. 1997, 106, 2675.
- (170) Kudin, K. N.; Scuseria, G. E. Phys. Rev. B 2000, 61, 16440.
- (171) Ernzerhof, M.; Scuseria, G. E. J. Chem. Phys. 1999, 110, 5029.

- (172) Adamo, C.; Scuseria, G. E.; Barone, V. J. Chem. Phys. 1999, 111, 2889.
- (173) Rabuck, A. D.; Scuseria, G. E. Chem. Phys. Lett. 1999, 309, 450.
- (174) Schoenes, J. Phys. Rep. 1980, 63, 301 and references therein.
- (175) Evarestov, R.; Bandura, A.; Blokhin, E. Acta Mater. 2009, 57, 600.
- (176) Prodan, I. D. Hybrid Density Functional Studies of Bulk Actinide Oxides, Ph.D. Thesis, Rice University, 2006.
- (177) Calculations for  $PuO_{2.25}$  were carried out by using a neutral interstitial oxygen atom as the initial guess for the self-consistent procedure, which naturally led to the  $O^-$  solution. Our attempts to self-consistently obtain an interstitial  $O^{2-}$  could not produce a converged solution.
- (178) Zachariasen, W. H. J. Less-Common Met. 1978, 62, 1.
- (179) Ellinger, F. H. *The Metal Plutonium*; University of Chicago Press, Chicago, IL, 1961.
- (180) Asprey, L. B.; Ellinger, F. H.; Fried, S.; Zachariasen, W. H. J. Am. Chem. Soc. 1955, 77, 1707.
- (181) Peterson, J. R.; Fuger, J. J. Inorg. Nucl. Chem. 1971, 33, 4111. (182) Kuechle, W.; Dolg, M.; Stoll, H.; Preuss, H. J. Chem. Phys.
- 1924, 100, 7535.
- (183) Wen, X.-D.; Martin, R. L.; Roy, L. E.; Scuseria, G. E.; Rudin, S. P.; Batista, E. R.; McCleskey, T. M.; Soctt, B. L.; Bauer, E.; Joyce, J. J.; Durakiewicz, T. *J. Chem. Phys.* **2012**, *137*, 154707.
- (184) Kresse, G.; Lebacq, O. VASP manual, http://cms.mpi.univie. ac.at/vasp/vasp.html.
- (185) See VASP online manual at http://cms.mpi.univie.ac.at/vasp/vasp/LASPH tag.html.
- (186) Goldschmidt, V. M.; Thomassen, L. Phys. Rev. 1924, 23, 763.
- (187) Sellers, P. A.; Fried, S.; Elson, E.; Zachariasen, W. H. J. Am. Chem. Soc. 1954, 76, 5935.
- (188) Nave, S. E.; Haire, R. G.; Huray, P. G. Phys. Rev. B 1983, 28, 2317.
- (189) Tokunaga, Y.; Nishi, T.; Masami, S. K.; Nakada, M.; Itoh, A.; Homma, Y.; Sakai, H.; Chudo, H. *J. Phys. Soc. Jpn.* **2010**, 79, No. 053705.
- (190) Wen, X.-D.; Martin, R. L.; Scuseria, G. E.; Rudin, S. P.; Batista, E. R.; Burrell, A. K. *J. Phys.: Condens. Matter* **2013**, *25*, 025501.
- (191) Strain, M. C.; Scuseria, G. E.; Frisch, M. J. Science **1996**, 271, 51.
- (192) Kudin, K. N.; Scuseria, G. E. Chem. Phys. Lett. 1998, 283, 61.
- (193) Kudin, K. N.; Scuseria, G. E. Chem. Phys. Lett. 1998, 289, 611.
- (194) Kudin, K. N.; Scuseria, G. E. J. Chem. Phys. 2004, 121, 2886.
- (195) Burant, J. C.; Scuseria, G. E.; Frisch, M. J. J. Chem. Phys. 1996, 105, 8969.
- (196) Izmaylov, A.; Scuseria, G. E.; Frisch, M. J. J. Chem. Phys. 2006, 125, No. 104103.
- (197) Uddin, J.; Peralta, J. E.; Scuseria, G. E. *Phys. Rev. B* **2005**, *71*, No. 155112.
- (198) Hay, P. J.; Martin, R. L.; Uddin, J.; Scuseria, G. E. J. Chem. Phys. **2006**, 125, No. 034712.
- (199) Peralta, J. E.; Heyd, J.; Scuseria, G. E.; Martin, R. L. *Phys. Rev. B* **2006**, *74*, No. 073101.
- (200) Batista, E. R.; Heyd, J.; Hennig, R. G.; Uberuaga, B. P.; Martin, R. L.; Scuseria, G. E.; Umrigar, C. J.; Wilkins, J. W. *Phys. Rev. B* **2006**, 74, No. 121102.
- (201) Kasinathan, D.; Kunes, J.; Koepernik, K.; Diaconu, C. V.; Martin, R. L.; Prodan, I. D.; Scuseria, G. E.; Spaldin, N.; Petit, L.; Schulthess, T. C.; Pickett, W. E. *Phys. Rev. B* **2006**, *74*, No. 195110.
- (202) Uddin, J.; Scuseria, G. E. Phys. Rev. B 2006, 74, No. 245115.
- (203) Lucero, M. J.; Aguilera, I.; Palacios, P.; Diaconu, C. V.; Wahnon, P.; Scuseria, G. E. Phys. Rev. B 2011, 83, No. 205128.
- (204) El-Mellouhi, F.; Brothers, E. N.; Lucero, M. J.; Scuseria, G. E. *Phys. Rev. B* **2011**, *84*, No. 115122.
- (205) Ellis, J. K.; Lucero, M. J.; Scuseria, G. E. Appl. Phys. Lett. 2011, 99, No. 261908.
- (206) Heyd, J.; Scuseria, G. E. J. Chem. Phys. 2004, 120, 7274.
- (207) Brothers, E. N.; Izmaylov, A. F.; Normand, J. O.; Barone, V.; Scuseria, G. E. *J. Chem. Phys.* **2008**, *129*, No. 011102.

(208) Izmaylov, A. F.; Scuseria, G. E. J. Chem. Phys. 2008, 129, No. 034101.

- (209) Henderson, T. M.; Izmaylov, A. F.; Scalmani, G.; Scuseria, G. E. J. Chem. Phys. **2009**, 131, No. 044108.
- (210) Henderson, T. M.; Janesko, B. G.; Scuseria, G. E. J. Phys. Chem. A 2008, 112, 12530.
- (211) Janesko, B. G.; Henderson, T. M.; Scuseria, G. E. Phys. Chem. Chem. Phys. 2009, 11, 443.
- (212) Lim, I. S.; Scuseria, G. E. Chem. Phys. Lett. 2008, 460, 137.
- (213) Paier, J.; Marsman, M.; Hummer, K.; Kresse, G.; Gerber, I. C.; Ángyán, J. G. *J. Chem. Phys.* **2006**, *124*, No. 154709.
- (214) Paier, J.; Marsman, M.; Kresse, G. J. Chem. Phys. 2007, 127, No. 024103.
- (215) Stroppa, A.; Kresse, G. New J. Phys. 2008, 10, No. 063020.
- (216) Henderson, T. M.; Janesko, B. G.; Scuseria, G. E. J. Chem. Phys. **2008**, 128, No. 194105.
- (217) Krukau, A. V.; Scuseria, G. E; Perdew, J. P.; Savin, A. J. Chem. Phys. 2008, 129, No. 124103.
- (218) Janesko, B. G.; Krukau, A. V.; Scuseria, G. E. J. Chem. Phys. 2008, 129, No. 124110.
- (219) Janesko, B. G.; Henderson, T. M.; Scuseria, G. E. J. Chem. Phys. **2009**, 130, No. 081105.
- (220) Weintraub, E.; Henderson, T. M.; Scuseria, G. E. J. Chem. Theory Comput. 2009, 5, 754.
- (221) Henderson, T. M.; Janesko, B. G.; Scuseria, G. E.; Savin, A. Int. J. Quantum Chem. 2009, 109, 2023.
- (222) Henderson, T. M.; Izmaylov, A. F.; Scuseria, G. E.; Savin, A. J. Chem. Phys. **2007**, 127, No. 221103.
- (223) Henderson, T. M.; Izmaylov, A. F.; Scuseria, G. E.; Savin, A. J. Chem. Theory Comput. 2008, 4, 1254.
- (224) Lucero, M. J.; Henderson, T. M.; Scuseria, G. E. J. Phys.: Condens. Matter 2012, 24, No. 145504.
- (225) Curry, N. A. Proc. Phys. Soc. London 1965, 86, 1193.
- (226) Erdös, P.; Robinson, J. M. Actinide Compounds; Plenum Press: New York, 1983.
- (227) Norton, P. R.; Tapping, R. L.; Creber, D. K.; Buyers, W. J. L. *Phys. Rev. B* **1980**, *21*, 2572.
- (228) Black, L.; Miserque, F.; Gouder, T.; Havela, L.; Rebizant, J.; Wastin, F. J. Alloys Compd. 2001, 315, 36.
- (229) Samsel-Czekała, M.; Talik, E.; de, V.; Du Plessis, P.; Troć, R.; Misiorek, H.; Sułkowski1, C. *Phys. Rev. B* **2007**, *76*, No. 144426.
- (230) Private communication with Dr. John J. Joyce at Los Alamos National Laboratory.