![](_page_0_Figure_3.jpeg)

Figure 4. SF-RS spectra for the ClO<sub>2</sub>--Cu<sup>2+</sup> system. Each spectrum is the average of the first three to five consecutive scans. Scan rate: 190 nm/100 ms. Dashed line: 0.500 M NaClO<sub>2</sub>. Dotted line: 0.157 M Cu(ClO<sub>4</sub>)<sub>2</sub>. Solid lines:  $C_{\text{ClO}_7} = 5.01 \times 10^{-3}$  M and  $C_{\text{Cu}^{2+}} = 6.97 \times 10^{-3}$ ,  $1.39 \times 10^{-2}$ ,  $3.49 \times 10^{-2}$ ,  $6.97 \times 10^{-2}$ , 0.105, and 0.157 M in the order of increasing absorbance.  $C_{\text{H}^+} = 7.0 \times 10^{-4} - 1.1 \times 10^{-3}$  M.

experiments clearly prove the formation of a new species.

The data, evaluated by using Job's method<sup>22</sup> (Figure 3), are consistent with the formation of a complex with 1:1 stoichiometry for ClO<sub>2</sub><sup>-</sup> and Cu<sup>2+</sup> (reaction 2). The evaluation of the data based on the Coleman-Varga method<sup>23</sup> led to the same conclusion.

$$Cu^{2+} + ClO_2^- = CuClO_2^+$$
 (2)

At higher reactant concentrations, and at longer times, the spectra seemingly were somewhat corrupted by the formation of ClO<sub>2</sub>. Considering the applied experimental conditions (pH = 2.5-3.5), this observation indicates that Cu<sup>2+</sup> slightly catalyzes the decomposition of chlorite ion.

The SF-RS measurements were performed by varying the Cu2+ and ClO<sub>2</sub> concentrations in the range of  $1.39 \times 10^{-3}$ –0.157 and  $1.00 \times 10^{-3}$ –0.500 M, respectively. The acid concentration of these samples was  $5 \times 10^{-4}$ –1.0 ×  $10^{-3}$  M. In general, the rate of the complex formation reactions with Cu<sup>2+</sup> is close to the diffusioncontrolled limit.24 Accordingly, the formation of the CuClO2+ complex was completed in less than the dead time of the SF-RS measurements. No apparent change was observed in the consecutive rapid-scan spectra, even when the fastest available scan rate (190 nm/2 ms) was applied. A few representative spectra are shown in Figure 4. A similar concentration dependence was observed with chlorite ion.

The data for 15 wavelengths in the 360-480-nm wavelength range were evaluated with the program PSEQUAD.25 In these calculations, the  $pK_a$  of  $HClO_2$  and the spectrum of the chlorite ion were included as known parameters, and the stability constant as well as the spectrum of the CuClO<sub>2</sub>+ complex were simultaneously evaluated. The Job's curves calculated with the fitted parameters are in excellent agreement with the experimental data from standard spectrophotometric measurements (Figure 3).

The calculated stability constant for the CuClO<sub>2</sub>+ complex is  $1.04 \pm 0.07 \text{ M}^{-1}$ . The molar absorptivity of this species at the maximum wavelength, 387 nm, is  $1990 \pm 120 \text{ M}^{-1} \text{ cm}^{-1}$ . As expected, a relatively weak complex is formed with Cu2+, although its stability is considerably higher than that of the uranyl complex.5 The complex formation is associated with the appearance of an intense, presumably charge-transfer, band in the near-UV-visible spectral region. The main implication of these results is that the complex formation can be part of any reaction system including a transition-metal ion and ClO<sub>2</sub>. Most likely, these complexes

are rapidly formed at even relatively low concentration levels. However, they may be of crucial kinetic importance in the oxidation-reduction and catalytic decomposition reactions of chlorite ion. The results also indicate that proper characterization of these complexes requires the application of fast spectrophotometric methods. This subject has been addressed in our ongoing equilibrium and kinetic studies.

> Contribution from the Department of Chemistry, University of Helsinki, Et. Hesperiankatu 4. 00100 Helsinki, Finland

## The Large Range of Uranyl Bond Lengths: Ab Initio Calculations on Simple Uranium-Oxygen Clusters

Pekka Pyykkö\* and Yongfang Zhao†

Received May 15, 1991

The large range of uranyl bond lengths is a classical problem.<sup>1</sup> We present here an ab initio study of the underlying mechanism, supposing it to be an intramolecular one, taking place inside an axial + equatorial,  $[(O_{ax}UO_{ax})(O_{eq})_n]^{6-}$  (n = 4) distorted octahedral model cluster, including the  $UO_2^{m+}$  (m = 0-2), "antiuranyl"  $UO_4^{2-}(D_{4h})$  and cubic  $UO_6^{6-}$  limits.

The quasirelativistic pseudopotential of Hay et al.2 and Gaussian 90<sup>3</sup> were used. The oxygen basis is described in ref 4. For a possible explanation as to why structural calculations on highly charged anions work, see ref 5. The calculated bond lengths and breathing frequencies are given in Table I.

The free UO2m+ bond length and its charge dependence resemble earlier studies and are for uranyl near the low end of the experimental range of about 150-208 pm. 1a The UO<sub>4</sub>2- one is a little below and the UO66 one a little above experiment. Taking then U-O<sub>eq</sub> as the independent variable and optimizing U-O<sub>ax</sub>, we find the results shown in Figure 1. They nicely parallel the

Job, P. Ann. Chim. Phys. 1928, 9, 113.

Coleman, I. S.; Varga, L. P. Inorg. Chem. 1970, 9, 1015. Margerum, D. W.; Cayley, G. R.; Weatherburn, D. C.; Pagenkopf, G.

K. In Coordination Chemistry; Martell, A. E., Ed.; American Chemical Society: Washington, DC, 1978; Vol. 2, p 1 and references therein.

(25) Zékány, L.; Nagypál, I. In Computational Methods for the Determination of Formation Constants; Leggett, D. J., Ed.; Plenum: New York, 1985; p 291.

On leave from the Institute of Atomic and Molecular Physics, Jilin University, 130023 Changchun, People's Republic of China.

<sup>(</sup>a) Denning, R. G. Gmelin Handbook, U Supplement A6; Springer: Berlin, 1983; pp 31-79. (b) Katz, J. J.; Seaborg, G. T.; Morss, L. R. The Chemistry of the Actinide Elements, 2nd ed.; Chapman and Hall: London and New York, 1986; Vol. 1. (c) Jørgensen, C. K.; Reisfeld, R. Structure Bonding 1982, 50, 121-171 (see p 155). (d) Glebov, V. A. Electronic Structure and Properties of Uranyl Compounds (in Russian); Energoatomizdat: Moscow, 1983.

(2) Hay, P. J.; Wadt, W. R.; Kahn, L. R.; Raffenetti, R. C.; Phillips, D. H. J. Chem. Phys. 1979, 71, 1767–1779.

<sup>(3)</sup> Frisch, M. J.; Head-Gordon, M.; Trucks, G. W.; Foresman, J. B.; Schlegel, H. B.; Raghavachari, K.; Robb, M. A.; Binkley, J. S.; Gonzalez, C.; Defrees, D. J.; Fox, D. J.; Whiteside, R. A.; Seeger, R.; Melius, C. F.; Baker, J.; Martin, R. L.; Kahn, L. R.; Stewart, J. J. P.; Topiol, S.; Pople, J. A. Gaussian 90; Gaussian, Inc.: Pittsburgh PA,

Wadt, W. R. J. Am. Chem. Soc. 1981, 103, 6053. Pyykkö, P.; Zhao, Y.-F. J. Phys. Chem. 1990, 94, 7753-7759.

van Wezenbeek, E. M.; Baerends, E. J.; Snijders, J. G. Submitted for publication. This paper contains a good summary of earlier calculations

Green, D. W.; Gabelnick, S. D.; Reedy, G. T. J. Chem. Phys. 1976, 64, 1697-1705.

Allen, G. C.; Baerends, E. J.; Vernooijs, P.; Dyke, J. M.; Ellis, A. M.; Fehér, M.; Morris, A. J. Chem. Phys. 1988, 89, 5363-5372.
Gabelnick, S. D.; Reedy, G. T.; Chasanov, M. G. J. Chem. Phys. 1973,

<sup>(10)</sup> Hoekstra, H.; Siegel, S. J. Inorg. Nucl. Chem. 1964, 26, 693-700

![](_page_1_Figure_3.jpeg)

Figure 1. Optimized  $R_{ax}$  as a function of  $R_{eq}$  for  $UO_6^{6-}$  clusters. The experimental points are taken from refs 1d and 10.

![](_page_1_Figure_5.jpeg)

Figure 2. (a) Experimental geometry for  $(ONpO^+)_2$  in  $Na_4(NpO_2)_2$ - $C_{12}O_{12}^*8H_2O.^{12}$  (b) Calculated geometry in a  $(OUO^+)_2$  model dimer (S = 1). Only the dimer parameters  $O_2$ - $U_2$  and  $O_2$ - $U_1$ - $O_3$  are optimized.

experimental trend. The intramolecular total energy changes only very little over the range given. 11 Thus we interpret the large

Table I. Calculated Relativistic U-O Bond Lengths, R (in pm), and Breathing Frequencies  $\nu_1(a_1)$  (in cm<sup>-1</sup>)

| species                       | method | R       | $\nu_1$ | ref |
|-------------------------------|--------|---------|---------|-----|
| UO <sub>2</sub> 2+            | HF     | 162.5   | 1216    |     |
|                               | MP2    | 173.2   | 922     |     |
|                               | HF     | 163     | ,       | a   |
|                               | HFS    | 170.0   |         | b   |
|                               | exptl  |         | ca. 830 | c   |
| UO <sub>2</sub> +             | HF     | 171.2   | 1031    |     |
|                               | MP2    | 177.0   | 1074    |     |
|                               | exptl  |         | 808     | d   |
| UO <sub>2</sub>               | ΗF     | 181.8   | e       |     |
|                               | MP2    | 179.7   |         |     |
|                               | HFS    | 187.3   |         | f   |
|                               | HFS    | 183.4   |         | b   |
|                               | expti  |         | 765     | g   |
| UO <sub>4</sub> <sup>2-</sup> | HF     | 187.3   | 872     |     |
|                               | exptl  | 199     |         | h   |
|                               | HF     | 214.8   | 592     |     |
|                               | exptl  | 208-209 |         | i   |
|                               | exptl  |         | 797     | j   |
| UN <sub>2</sub>               | HF     | 181.8   | 783     |     |
|                               | MP2    | 191.1   | 816     |     |

<sup>a</sup>Reference 4. <sup>b</sup>Reference 6. <sup>c</sup>A typical value for U-O<sub>ax</sub> around 170 pm.  $^{1d}$  <sup>d</sup>Reference 7 (average). Purposely omitted for this single-configuration open-shell  $\phi^1\delta^1$  triplet state. Reference 8. Reference 9. In Na<sub>4</sub>UO<sub>5</sub> and Li<sub>4</sub>UO<sub>5</sub>. See Figure 1. Reference

range of U-O<sub>ax</sub> distances as a soft e<sub>g</sub> vibrational mode (axial in-equatorial out, or vice versa) of the cubic UO<sub>6</sub>6- cluster, which is frozen in by the lattice forces, totally neglected here.

For Np, a peculiar (ONpO+)2 dimer was found by Cousson et al.<sup>12</sup> (Figure 2a). For a dimer of linear, symmetrical (OUO<sup>+</sup>) groups (R = 171.2 pm) we indeed find the stable geometry in Figure 2b. Hence also this structure could be explained by intramolecular interactions.

Acknowledgment. The calculations were performed on the VAX 8650 and Cray X-MP EA/432 computers of the Centre for Scientific Computing, Espoo, Finland. We thank Alain Cousson, José Jové, Peter Schwerdtfeger, and Ulf Wahlgren for discussions.

## Additions and Corrections

1990, Volume 29

S. K. Xi, H. Schmidt, C. Lensink, S. Kim, D. Wintergrass, L. M. Daniels, R. A. Jacobson, and J. G. Verkade\*: Bridgehead-Bridgehead Communication in Untransannulated ZP(ECH<sub>2</sub>CH<sub>2</sub>)<sub>3</sub>N Systems.

Pages 2215, 2216, and 2219. The oxygens in structure 8 should be replaced by nitrogens, the captions for Figures 1 and 2 should be interchanged, and the nitrogen in structure 16 should be replaced by a phosphorus.—J. G. Verkade

The cubic symmetry is an energy minimum. The force constant  $\partial^2 E/\partial R_{\rm eq}^2$  for the minimum-energy path in Figure 1 at  $R_{\rm eq} = R_{\rm ax} = 214.4$  pm is only 0.14 au, compared to 1.31 au for the breathing  $(a_{1g})$ (11)mode.

Cousson, A.; Dabos, S.; Abazli, H.; Nectoux, F.; Pagès, M.; Choppin, G. J. Less-Common Met. 1984, 99, 233.