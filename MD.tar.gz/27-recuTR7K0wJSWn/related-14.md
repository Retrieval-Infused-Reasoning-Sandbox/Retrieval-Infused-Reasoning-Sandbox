# Effects of spin-orbit coupling and strong correlation on the paramagnetic insulating state in plutonium dioxides

Hiroki Nakamura, <sup>1,2,\*</sup> Masahiko Machida, <sup>1,2,†</sup> and Masato Kato<sup>3</sup>

<sup>1</sup>CCSE, Japan Atomic Energy Agency, 6-9-3 Higashi-Ueno, Taito-ku, Tokyo 110-0015, Japan

<sup>2</sup>CREST, JST, 4-1-8 Honcho, Kawaguchi, Saitama 332-0012, Japan

<sup>3</sup>Advanced Nuclear System R&D Directorate, Japan Atomic Energy Agency,

4-33 Muramatsu, Tokai-mura, Naka-gun, Ibaraki 319-1194, Japan

(Received 4 June 2010; revised manuscript received 20 September 2010; published 21 October 2010)

We perform first-principles calculations taking account of both relativistic and strong correlation effects on plutonium dioxides in order to numerically obtain its observed ground state, i.e., the paramagnetic insulating state and properly calculate the material properties. Generally, it is known for plutonium dioxides that the standard local-density approximation (LDA) calculations give metallic states and even LDA+U considering the strong correlation on Pu f orbitals fails to attain the paramagnetic insulating state. In this paper, we clarify that inclusion of the spin-orbit coupling in addition to the strong correlation is responsible for the paramagnetic insulating state. Using the obtained paramagnetic insulating state, we calculate various material properties and claim that the proper state preparation is essential for quantitative evaluation of the material properties.

DOI: 10.1103/PhysRevB.82.155131 PACS number(s): 71.27.+a, 71.15.Mb, 71.20.-b, 71.70.Ej

### I. INTRODUCTION

Plutonium dioxide (PuO<sub>2</sub>) is a main compound of a mixed oxide fuel whose usage is presently of great importance for nuclear materials recycling. So far, much attention has been paid to its thermodynamical properties such as heat capacity, thermal conductivity, and so on. However, the experimental data stock has still remained insufficient because of severe difficulties on its experimental treatments. Then, numerical experiments without any limitation have been in great demand. On the other hand, certain compounds of plutonium have attracted much fundamental interest as typical heavy fermion systems, where the strong correlation on f orbital plays an important role. PuO2 is classified into a Mott insulator due to the strong correlation which is currently an intensive focus of solid-state physics. Thus, PuO<sub>2</sub> has been a key substance in not only nuclear fuel research but also fundamental science.

PuO<sub>2</sub> is a peculiar insulator which does not exhibit any magnetic transition up to experimentally accessible low temperature. In contrast, uranium and neptunium dioxides show triple-q antiferromagnetic<sup>1</sup> and multipole ordering,<sup>2</sup> respectively, in low-temperature ranges with opening of their insulating gaps. Thus, PuO<sub>2</sub> has been initially regarded as a theoretically simple system compared to other actinide dioxides. However, the standard density-functional theory (DFT) with local-density approximation (LDA) predicts a metallic ground state. Moreover, even modern correction schemes such as LDA+U (Ref. 3) and hybrid DFT (Ref. 4) taking account of strong correlation effects on f-orbital electrons are known to fail to reach the paramagnetic insulating state. Indeed, these schemes can give insulating states but always generate unexpected ferromagnetic or antiferromagnetic order together.<sup>5</sup> To our knowledge, only a few literatures considering the spin-orbit coupling in addition to the correlation effects [self-interaction-corrected LDA (Ref. 6), LDA+dynamical mean-field theory (DMFT) (Ref. 7), and a specific LDA+U (Ref. 8)] successfully obtained the paramagnetic insulating state. However, we do not find out any explicit explanation on their two effects. In this paper, we therefore examine and clarify how both effects are crucial for obtaining the paramagnetic insulating state. The fact that inclusion of the spin-orbit coupling gives the correct state implies importance of the relativistic effect on 5f electrons. Thus, the present paper sheds a light on the following two topics. The first one is the role of both the spin-orbit coupling and the Hubbard U for  $PuO_2$  within the LDA+U framework, and the second one is how experimental material properties are reproducible based on the correct state. Our final claim is that the paramagnetic insulating state obtained by taking account of both effects is essential for further accurate prediction of the material properties.

The contents of the present paper are as follows. In Sec. II, we explain the present method on the electronic structure calculations. In order to examine each effect of the strong correlation (i.e., Hubbard U) and the spin-obit coupling, we turn on and off each or both of them and compare the results in Sec. III. Section IV demonstrates material properties based on the obtained paramagnetic insulating state. The focus of the section is on energy gaps, lattice constants, and mechanical properties. Section V is devoted to discussion of the obtained paramagnetic insulating state in comparison with other magnetically ordered states. The conclusion is given in Sec. VI.

#### II. ELECTRONIC-STRUCTURE CALCULATIONS

We briefly explain the DFT calculation methods. The calculation package employed throughout the present paper is VASP, which adopts projector augmented wave (PAW) method  $^{10,11}$  and both LDA (Ref. 12) and generalized gradient approximation (GGA) (Ref. 13) exchange-correlation energies and supports the LDA+U and GGA+U methods. The calculation results of LDA(+U) and GGA(+U) are compared and discussed in terms of agreement with experimental results in Sec. IV. K points are taken as  $9 \times 9 \times 9$  and the

![](_page_1_Picture_2.jpeg)

FIG. 1. (Color online) Crystal structure of PuO<sub>2</sub>. The right panel shows a structure of O atoms surrounding Pu atom.

energy cut-off is 500 eV.<sup>14,15</sup> The electronic self-consistent loop is repeated until the energy difference between the successive loops becomes less than  $10^{-7}$  eV. The crystal structure is stabilized until the atomic forces are reduced to be less than 0.01 eV/Å. We apply the Hubbard U correction only on f orbitals of Pu in order to take account of the strong correlation of f-orbital electrons. Though U can be estimated by first-principles methods such as the constrained LDA (Ref. 16) and constrained random-phase approximation (RPA),<sup>17</sup> we treat U as just an input parameter. In this paper, we set J to be zero for simplicity. In the present parameter set, the interorbital repulsion, which is often called U' or V, increases with the intraorbital repulsion (U). Some of the present results are compared with those of WIEN2K (Ref. 18) and confirmed to be consistent each other.

## III. CRYSTAL FIELD AND ORIGIN OF PARAMAGNETIC INSULATOR

The crystal structure of  $PuO_2$  is equivalent with that of  $CaF_2$ , whose space group is  $Fm\overline{3}m$  as seen in Fig. 1. As

![](_page_1_Figure_7.jpeg)

![](_page_1_Figure_8.jpeg)

(b) Crystal Field + Spin-Orbit Coupling

![](_page_1_Figure_10.jpeg)

FIG. 2. (Color online) Schematic figures of level splitting of f electrons in  $PuO_2$  (a) without and (b) with the spin-orbit coupling. The numbers inside parentheses denotes the degeneracy number.

pointed out in Sec. I, the DFT methods which drop the spinorbit coupling cannot obtain the paramagnetic insulating state. This can be simply understood by the crystal-field theory [see Fig. 2(a)]. Pu<sup>4+</sup> is surrounded by O<sup>2-</sup>-cube (Fig. 1), and its point symmetry group is O<sub>h</sub>. In this case, Pu<sup>4+</sup> has four electrons on 5f orbitals. The standard LDA calculations without the spin-orbit coupling make f-orbital bands cross the Fermi level without any gap opening [see Fig. 3(a) for the calculation results]. Though seven f bands are generally dispersive, at  $\Gamma$  point they degenerate into three bands, which correspond to singlet  $\Gamma_2(a_{2u})$  and two triplets  $\Gamma_4(t_{1u})$  and

![](_page_1_Figure_13.jpeg)

FIG. 3. (Color online) Band structures and density of states (DOS) of  $PuO_2$  calculated by LDA+U without the spin-orbit coupling. (a) The case of standard LDA without the spin-orbit coupling and (b) that of LDA+U where U=4 eV without the spin-orbit coupling. The left panels show the band structures and the three right panels display total DOS, partial DOS of Pu Tu orbital and partial DOS of Tu Tu orbital, respectively.

![](_page_2_Figure_2.jpeg)

FIG. 4. (Color online) Band structures and density of states of  $PuO_2$  calculated by LDA+U with the spin-orbit coupling. (a) The case of standard LDA with the spin-orbit coupling (U=0), (b) that of LDA+U where U=4 eV with the spin-orbit coupling. The left panels show the band structures and the three right panels display total DOS, partial DOS for j=5/2 and j=7/2, where j is the angular momentum of Puf orbital, respectively.

 $\Gamma_5(t_{2u})$  according to the crystal field theory [see Fig. 2(a)]. If four electrons occupy these bands in order to form an insulating state, then one finds that a doublet is necessary as the lowest level by considering the spin degree of freedom. However, there is no doublet in the nonrelativistic f orbitals. In this case, even if strong correlation effect is taken into account, it is found that any gap cannot open [see Fig. 3(b)] as long as magnetic ordering is not incorporated.

On the other hand, if one includes the spin-orbit coupling, then f orbitals split into lower j=5/2 and higher j=7/2 orbitals, where j is the total angular momentum as shown in Fig. 2(b). In the LDA calculation with the spin-orbit coupling, a gap indeed opens between j=5/2 and j=7/2 bands as shown in Fig. 4(a). However, the calculated state is still metallic since there are six bands of j=5/2 for four electrons. At the  $\Gamma$  point, two degenerate bands for j=5/2 orbitals are displayed. These correspond to  $\Gamma_7$  doublet and  $\Gamma_8$ quartet according to the crystal field theory. One then notices that at the  $\Gamma$  point  $\Gamma_7$  doublet and  $\Gamma_8$  quartet levels are inverted contrary to the crystal-field theory. We note that WIEN2K also exhibits such a similar inversion. Moreover, one finds that the level distance between  $\Gamma_7$  and  $\Gamma_8$  is too small to open a clear insulating gap. This indicates that the crystal field is relatively less effective in the present first-principles calculations. Thus, we apply the Hubbard U via LDA+U method to open a wide gap between  $\Gamma_8$  quartet occupied by four electrons and empty  $\Gamma_7$  doublet as seen in Fig. 4(b). The calculation result is just as we expected. In fact, the application of the Hubbard U inverts the levels of  $\Gamma_8$  and  $\Gamma_7$  and opens a large gap between them. Thus, the spin-orbit coupling with the Hubbard U finally leads to the paramagnetic insulating state.

## IV. NUMERICAL RESULTS FOR MATERIAL PROPERTIES

Figure 5 shows U dependences of the lattice parameter a and the gap size  $\Delta$ . In the case of GGA+U, the calculated lattice constant agrees with experimental value 5.396 Å (Ref. 19) around  $U \sim 0$ , where the gap does not open. The experimentally measured gap size is about 1.8 eV,  $^{20}$  which is comparable to that obtained at  $U \sim 4$  eV. However, the lattice constant at U = 4 eV is 5.460 Å which is 1.2% larger than the observed value. On the other hand, in the case of LDA+U, the lattice constant is always smaller than the experimental value but increases with U similar to GGA+U. The gap size shows the same tendency as GGA+U. At U = 4 eV, the lattice constant is 0.75% smaller than the experimental value but the gap size agrees well with the experimental data. Comparing these results, we clearly find that

![](_page_2_Figure_9.jpeg)

![](_page_2_Figure_10.jpeg)

FIG. 5. (Color online) The lattice constant and gap as a function of the Hubbard U.

![](_page_3_Figure_2.jpeg)

FIG. 6. (Color online) Total energies for various U in the LDA+U method as a function of the lattice constant a. The curves represent the Birch-Murnaghan equation of states through the data fitting.

GGA(LDA) over(under)-estimates the bonding length between Pu and O. Similar results are reported for other materials, such as  $CeO_2$ .<sup>21</sup> Since the experimental value of the lattice constant is measured at the room temperature, it should be larger than that at zero temperature due to thermal expansion. Hence, we conclude that LDA+U with finite U is the most successful in terms of the lattice constant. In the remaining part, we mainly examine the electronic structure and material properties with LDA+U at U=4 eV and J=0. These parameter (U and J) values are not so different from those reported in Ref. 22 (U=4 eV and J=0.7 eV) and Ref. 23 (U~5.5 eV and J~0.68 eV).

We also evaluate the lattice constant dependence of the total energy. In Fig. 6, total energies in the LDA+U are plotted in a wide range of the lattice constant. The calculated energies are well fitted to the Birch-Murnaghan equation of states. <sup>24</sup>

$$E(V) = E_0 + \frac{9V_0B}{16} \left[ \left\{ \left( \frac{V_0}{V} \right)^{2/3} - 1 \right\}^3 B' + \left\{ \left( \frac{V_0}{V} \right)^{2/3} - 1 \right\}^2 \left\{ 6 - 4 \left( \frac{V_0}{V} \right)^{2/3} \right\} \right], \tag{1}$$

where B and B' are bulk modulus and its pressure derivative, and  $V_0$  and  $E_0$  are stable volume and energy, respectively. The parameters obtained according to the above relation are summarized in Table I. The bulk modulus (B) does not show any strong dependence on U. Though the experimental value was initially estimated to be 380 GPa in Ref. 25, the data was corrected to be 178 in Ref. 26, in which the original data of Ref. 25 was re-evaluated. The present result agrees better with the latter.

TABLE I. Calculated bulk modulus B, its derivatives B' and optimized volume  $V_0$  in LDA+U with the spin-orbit coupling. These values are obtained by fitting the Birch-Murnaghan equation of states.

| U<br>(eV) | B<br>(GPa) | B'   | $V_0$ (Å <sup>3</sup> ) |
|-----------|------------|------|-------------------------|
| 2         | 226        | 4.37 | 37.917                  |
| 4         | 228        | 4.36 | 38.468                  |
| 5         | 228        | 4.35 | 38.667                  |

We study mechanical properties of PuO<sub>2</sub> in more details. We calculate elastic constants from the stress on the strained structures. <sup>27,28</sup> PuO<sub>2</sub> has only three elastic constants,  $c_{11}$ ,  $c_{12}$ , and  $c_{44}$ , due to the cubic symmetry. The elastic constants and mechanical properties derived from the proper state are shown in Table II. The bulk modulus B, Young modulus Yand Poisson's ratio  $\sigma$  are obtained by Voigt formalism:  $B = (c_{11} + 2c_{12})/3$ , Y = 9BG/(G+3B), and  $\sigma = (B-2G/3)/3$ (2B+2G/3), where G is the shear modulus defined by  $G=(c_{11}-c_{12}+3c_{44})/5$ . We compare the elastic constants in the LDA+U (U=4 eV) with those of LDA (U=0). In both cases, the spin-orbit coupling is taken into account. The obtained bulk moduli are consistent with that derived from the Birch-Murnaghan equation of states within the standard error.<sup>29</sup> The bulk modulus obtained at U=0 results show a slightly better agreement with the experimental value 178 GPa than finite U cases. However, the Young modulus (Y) and Poisson's ratio ( $\sigma$ ) of LDA+U at U=4 eV agree much better with the experimental data 268.4 GPa and 0.28 GPa, respectively, than U=0 cases. This is because  $c_{11}$  and  $c_{44}$  are larger than those at U=0. Generally, the elastic constants of metals become smaller than those of insulators. Our result also follows the tendency since U=0 (U=4 eV) is metallic (insulating).

#### V. DISCUSSIONS

So far, we have demonstrated that both the Hubbard U and spin-orbit coupling are crucial in obtaining the paramagnetic insulating state in first-principles calculations. However, one should compare its total energy with those of other magnetic ordered states to confirm whether the paramagnetic state is a true ground state or not. As a consequence of such a comparison, we find that a ferromagnetic state becomes more stable in a wide parameter range. For instance, in the case of U=4 eV, the total energy per  $PuO_2$  of the ferromagnetic state becomes

TABLE II. Elastic constants  $c_{11}$ ,  $c_{12}$ , and  $c_{44}$ , bulk modulus B, Young modulus Y and Poisson's ratio  $\sigma$  in the LDA+U method. Experimental data are also shown for comparison.

| U<br>(eV) | c <sub>11</sub><br>(GPa) | c <sub>12</sub><br>(GPa) | c <sub>44</sub><br>(GPa) | B<br>(GPa) | Y<br>(GPa) | $\sigma$ |
|-----------|--------------------------|--------------------------|--------------------------|------------|------------|----------|
| 0         | 380                      | 140                      | 55                       | 220        | 216        | 0.336    |
| 4         | 412                      | 141                      | 72                       | 231        | 258        | 0.314    |
| Expt.     |                          |                          |                          | 178 or 380 | 268.4      | 0.28     |

netic state is 2 eV lower than that of the paramagnetic one. This clearly means that the obtained paramagnetic insulating state is just a metastable one in the parameter set within the present calculation scheme. Of course, other schemes, e.g., LDA+*U* without the spin-orbit coupling, cannot even have such a metastable paramagnetic insulating state. On the other hand since any magnetic ordering is not experimentally observed up to considerably low temperature, the true ground state should be paramagnetic. Note that the obtained state in the present calculation is the lowest-energy state under the constraint that it is paramagnetic and insulating. Though in the case of dipole-ordered *U*O2 many metastable states as local minima are found in LDA+*U* calculations,5,30 we did not find such local minima in the paramagnetic insulating states of PuO2. Here, let us discuss the reason why such magnetic ordering strongly competes the paramagnetic state in the present scheme. We mention the following points. The first one is that LDA calculation by VASP as well as WIEN2K contradicts the energy levels of <sup>7</sup> and <sup>8</sup> predicted by the crystal-field theory. Namely, the lowenergy level distribution does not coincide with the consequence of the crystal-field theory. This fact suspects that the present calculations may not fully reflect the crystal field. This may be because the strongly anisotropic and confined nature of *f* orbitals is not fully incorporated in LDA calculations. If it is the case, one requires a larger *U* value to obtain the paramagnetic insulating state while the large *U* also stabilizes the magnetic state. This disagreement with the crystal-field theory may be an origin of the strong competition, though the reason why the crystal field is less effective in the present calculations is unclear yet. Second, the present treatment on correlation effects in LDA+*U* is within the mean-field level. Since the mean-field treatment generally favors ordered states, the stability of the ferromagnetic state may be overestimated. Indeed the same problem was reported in the case of -Pu. In this case, the volume of -Pu obtained by LDA+*U* agrees with the observed one, i.e., LDA+*U* solves the volume under-estimation of the standard LDA. However, LDA+*U* Ref. 22 predicts a magnetic state while no magnetic order is found in experiments. This disagreement was settled down by the LDA+DMFT method31

which incorporates effects of quantum fluctuations. In the present case, more advanced treatment of strong correlations such as DMFT may also settle down the present competing problem. The LDA+DMFT is now under investigation.

Finally, let us discuss in terms of material properties. We have succeeded in preparing the paramagnetic insulating state. If one would like to estimate optical properties, the present paramagnetic state is clearly crucial. On the other hand, if one pays attention to only the lattice constant, the standard GGA calculation with *U*=0 is enough to agree with the experimental data. This may lead to conclude that structural properties do not sensitively depend on whether the obtained electronic state is correct or not. However, the present results have revealed that the Young modulus shows more than 10% difference between LDA+*U* and the ordinary LDA, although the bulk modulus does not depend on *U*. These results clearly indicates that a preparation of the correct electronic state is of great importance for systematic material-property evaluations.

### **VI. CONCLUSIONS**

In order to obtain the observed ground state of PuO2, i.e., the paramagnetic insulating state, we studied why the paramagnetic insulating state emerges as the ground state through first-principle calculations together with the crystal-field theory. Consequently, we obtained the paramagnetic insulating state by using LDA+*U* scheme including the spin-orbit coupling, though the obtained paramagnetic state strongly competes with other magnetically ordered states. Moreover, we found that the LDA+*U U*=4 eV calculation with the spin-orbit coupling very well reproduces the observed energy gap and the other experimental data as mechanical properties compared to any other schemes. This fact emphasizes the role of both the Hubbard *U* and the spin-orbit coupling in calculating the electronic states and materials properties of actinide compounds.

### **ACKNOWLEDGMENTS**

The authors wish to thank M. Suzuki, T. Hotta, M. Hirata, T. Nishi, H. Shibata, C. Suzuki, S. Kambe, Y. Tokunaga, M. Osaka, and K. Morimoto for illuminating discussions.

<sup>\*</sup>nakamura.hiroki@jaea.go.jp

<sup>†</sup> machida.masahiko@jaea.go.jp

<sup>1</sup>K. Ikushima, S. Tsutsui, Y. Haga, H. Yasuoka, R. E. Walstedt, N. M. Masaki, A. Nakamura, S. Nasu, and Y. Onuki, Phys. Rev. B **63**, 104404 2001-.

<sup>2</sup>Y. Tokunaga, Y. Homma, S. Kambe, D. Aoki, H. Sakai, E. Yamamoto, A. Nakamura, Y. Shiokawa, R. E. Walstedt, and H. Yasuoka, Phys. Rev. Lett. **94**, 137209 2005-.

<sup>3</sup>A. I. Liechtenstein, V. I. Anisimov, and J. Zaanen, Phys. Rev. B **52**, R5467 1995-.

<sup>4</sup>A. D. Becke, J. Chem. Phys. **98**, 1372 1993-.

<sup>5</sup>See, e.g., F. Jollet, G. Jomard, B. Amadon, J. P. Crocombette, and D. Torumba, Phys. Rev. B **80**, 235109 2009-; G. Jomard, B. Amadon, F. Bottin, and M. Torrent, *ibid.* **78**, 075125 2008-;

I. D. Prodan, G. E. Scuseria, and R. L. Martin, *ibid.* **73**, 045104 2006-, see also references therein.

<sup>6</sup>L. Petit, A. Svane, Z. Szotek, and W. M. Temmerman, Science **301**, 498 2003-.

<sup>7</sup>Q. Yin and S. Y. Savrasov, Phys. Rev. Lett. **100**, 225504 2008-.

<sup>8</sup>M. Suzuki private communication-.

<sup>9</sup>G. Kresse and J. Hafner, Phys. Rev. B **47**, 558 1993-; G. Kresse and J. Furthmüller, Comput. Mater. Sci. **6**, 15 1996-; Phys. Rev. B **54**, 11169 1996-.

<sup>10</sup>P. E. Blöchl, Phys. Rev. B **50**, 17953 1994-; G. Kresse and D. Joubert, *ibid.* **59**, 1758 1999-.

<sup>11</sup>We used the "standard" PAW potentials provided with VASP. In these potentials, the numbers of the valence electrons are 6 and

.

- 16 for O and Pu, respectively. The cut-off radii become 1.52 a.u. and 1.8 a.u. for O and Pu, respectively.
- 12S. H. Vosko, L. Wilk, and M. Nusair, Can. J. Phys. **58**, 1200 1980-.
- <sup>13</sup> J. P. Perdew, K. Burke, and M. Ernzerhof, Phys. Rev. Lett. **77**, 3865 1996-.
- <sup>14</sup> In this setting, the number of plane-waves reached 22,000.
- 15We have compared the force convergence of cutoff energy 500 eV and 999 *k* points with that of cutoff energy 700 eV and 111111 *k* points, and their difference is less than 0.01 eV/A. Thus, the cutoff energy 500 eV and 999 *k* points give enough accuracy as long as the force convergence is less than 0.01 eV/A.
- 16O. Gunnarsson, O. K. Andersen, O. Jepsen, and J. Zaanen, Phys. Rev. B **39**, 1708 1989-.
- 17F. Aryasetiawan, M. Imada, A. Georges, G. Kotliar, S. Biermann, and A. I. Lichtenstein, Phys. Rev. B **70**, 195104 2004-.
- 18K. Schwarz, P. Blaha, and G. K. H. Madsen, Comput. Phys. Commun. **147**, 71 2002-.
- 19D. L. Clark, S. S. Hecker, G. D. Jarvinen, and M. P. Neu, in *The Chemistry of the Actinide and Transactinide Elements*, 3rd ed., edited by L. R. Morss, N. M. Edelstein, J. Fuger, and J. J. Katz

- Springer, New York, 2008-, Vol. 2, Chap. 7, p. 1027.
- 20C. E. McNeilly, J. Nucl. Mater. **11**, 53 1964-.
- <sup>21</sup> J. L. F. Da Silva, M. V. Ganduglia-Pirovano, J. Sauer, V. Bayer, and G. Kresse, Phys. Rev. B **75**, 045121 2007-.
- 22S. Y. Savrasov and G. Kotliar, Phys. Rev. Lett. **84**, 3670 2000-
- 23A. Kotani and T. Yamazaki, Prog. Theor. Phys. Suppl. **108**, 117 1992-.
- 24F. Birch, Phys. Rev. **71**, 809 1947-.
- 25U. Benedict, S. Dabos-Seignon, J. P. Dancausse, M. Gensini, G. Gering, S. Heathman, H. Luo, J. Staun Olsen, L. Gerward, and R. G. Haire, J. Alloys Compd. **181**, 1 1992-.
- 26M. Idiri, T. Le Bihan, S. Heathman, and J. Rebizant, Phys. Rev. B **70**, 014113 2004-.
- 27Y. Le Page and P. Saxe, Phys. Rev. B **65**, 104104 2002-
- <sup>28</sup> 1.5% strain is adopted to calculate the elastic constants.
- 29We estimate the standard error by the least-square method for the results of 0.5% and 1.0% strains. The obtained bulk modulus is 230.662.87 GPa, which agrees with that of Birch-Murnaghan fitting and that of 1.5% strain.
- 30F. Zhou and V. Ozoliņš, arXiv:1006.3988 unpublished-.
- 31S. Y. Savrasov, G. Kotliar, and E. Abrahams, Nature London-**410**, 793 2001-.