![](_page_0_Picture_0.jpeg)

Journal of Alloys and Compounds 461 (2008) 608-611

![](_page_0_Picture_2.jpeg)

www.elsevier.com/locate/jallcom

# Room temperature ferromagnetism in $\text{Th}_{1-x}\text{Fe}_x\text{O}_{2-\delta}$ (x = 0.0, 0.05, 0.10, 0.15, 0.20 and 0.25) nanoparticles

O.D. Jayakumar<sup>a</sup>, I.K. Gopalakrishnan<sup>a,\*</sup>, A. Vinu<sup>b</sup>, A. Asthana<sup>c</sup>, A.K. Tyagi<sup>a</sup>

<sup>a</sup> Chemistry Division, Bhabha Atomic Research Centre, Mumbai 400085, India
<sup>b</sup> Nano-Ionics Materials Group, Fuel Cell Materials Center, National Institute for Materials Science,
1-1 Namiki, Tsukuba, Ibaraki 305-0044, Japan
<sup>c</sup> Advanced Electron Microscopy Group, National Institute for Materials Science,
1-1 Namiki, Tsukuba, Ibaraki 305-0044, Japan

Received 11 April 2007; received in revised form 19 July 2007; accepted 21 July 2007 Available online 28 July 2007

#### **Abstract**

Nanocrystalline  $(Th_{1-x}Fe_x)O_{2-\delta}$  particles with different Fe concentrations (x = 0.0, 0.05, 0.10, 0.15, 0.20 and 0.25) have been prepared by a gel combustion method. Rietveld refinement analyses of X-ray diffraction data revealed the formation of an impurity free cubic type  $Th_{1-x}Fe_xO_{2-\delta}$  structure up to x = 0.20. This observation is further confirmed from the detailed studies conducted on 10 at.% Fe doped  $ThO_2$  using high-resolution transmission electron microscopy (HRTEM) imaging and indexing of the selected-area electron diffraction (SAED) patterns. DC magnetization studies as a function field indicate that they are ferromagnetic with Curie temperature ( $T_c$ ) well above room temperature. © 2007 Elsevier B.V. All rights reserved.

Keywords: Fe doped ThO<sub>2</sub>; Room temperature ferromagnetism; dc magnetization; High-resolution transmission electroscopy; Selected-area electron diffraction

### 1. Introduction

Diluted magnetic semiconductors (DMSs) are the active components of the proposed spintronic devices [1,2]. Since the theoretical prediction of room temperature ferromagnetism (RTF) in Mn doped p-type ZnO and GaN by Dietl et al. [3], extensive studies have been carried out by many groups on transition metal (TM) doped semiconducting or insulating oxides such as ZnO [4–6], TiO<sub>2</sub> [7–9], SnO<sub>2</sub> [10], In<sub>2</sub>O<sub>3</sub> [11,12], HfO<sub>2</sub> [13], CeO<sub>2</sub> [14] and III–V semiconductor GaN [15,16]. Despite these extensive studies on different types of oxide based DMSs, a clear picture about the origin of ferromagnetism (FM) in these compounds is yet to emerge. However, a number of recent reports by different groups on bulk as well thin films of TM doped semiconducting or insulating oxides converged on to a conclusion that structural defect plays an important role in the origin of FM [5,9–14,17–20]. The doped magnetic ions, mostly 3d transition metals, exhibit a very low solubility in host semiconductor oxides like ZnO and SnO<sub>2</sub>. This motivated researchers to look for other oxide systems based on host semiconductors with a high solubility of magnetic ions. Yoo et al. [11], have shown that Fe doped  $In_2O_3$  co-doped with Cu (Fe up to 20 at.%) is one of the oxide systems that shows promising results as a potential candidate for DMS. Recently, we were able to induce ferromagnetism in Fe doped  $In_2O_3$  (Fe concentration up to 20 at.%) without introducing Cu as the additional dopant [21].

Most of the DMS materials developed so far have noncubic crystal symmetry and were either semiconductors or wide band gap semiconductors. Recently Tiwari et al. [14] observed ferromagnetism in Co doped CeO<sub>2</sub> films. In this paper, we report the observation of ferromagnetism above room temperature in an insulator ThO<sub>2</sub> (band gap =  $5.75\,\mathrm{eV}$ ) doped with high concentration of Fe<sup>3+</sup> ions ( $\leq$ 25 at.%), with face centered cubic fluorite type structure, synthesized by a gel combustion method.

## 2. Experimental

Nanocrystalline particles of  $(Th_{1-x}Fe_x)O_{2-\delta}$  (x=0.0, 0.05, 0.10, 0.15, 0.20 and 0.25) were prepared by a gel combustion method using glycine as a fuel and nitrates of thorium and iron as the oxidizer. Appropriate amounts of nitrates

<sup>\*</sup> Corresponding author. Tel.: +91 22 25592327; fax: +91 22 25505151. E-mail address: ikgopal@barc.gov.in (I.K. Gopalakrishnan).

of Fe and Th were weighed and dissolved in distilled water along with glycine solution (metal to glycine molar ratio 1:1.5). The above solution was evaporated on a hot plate by heating at about 373 K and the gel was obtained. The resultant gel was subsequently swelled into foam undergoing a strong self-propagating combustion reaction to give fine powder. --Fe2O3 powders were also prepared by the same method for comparison. Cationic composition was determined by energy dispersive X-ray analysis. Phase purity and the structure of the fine powder obtained were analyzed by powder X-ray diffraction using Cu K radiation of a Philips Diffractometer (model PW 1071) fitted with graphite crystal monochromator. The lattice parameters of the compounds were extracted by Rietveld refinement of the XRD data by using the computer code Fullprof [22] with the X-ray intensity collected for the range 20◦ ≤ 2θ ≤ 70◦. dc magnetization measurements, as a function of field were carried out using an E.G.&G P.A.R vibrating sample magnetometer (model 4500). The electron diffraction and high-resolution transmission electron microscopic (HRTEM) images were acquired on a TEM JEOL 2010F. The preparation of samples for HRTEM analysis involved sonication in ethanol for 2–5 min and deposition on a carbon-coated copper grid. The accelerating voltage of the electron beam was 300 kV.

## **3. Results and discussion**

Energy dispersive X-ray analysis (EDAX) indicates that all samples show the nominal concentration of Fe within the experimental error. Rietveld profile refinement analysis of XRD data of (Th1−*x*Fe*x*)O2 (*x* = 0.0, 0.05, 0.10, 0.15, 0.20 and 0.25) samples revealed the formation of an impurity free cubic fluorite type structure (space group *Fm*(−3)*m*) up to *x* = 0.20 (Fig. 1). For concentration above 20 at.% of Fe, peaks corresponding to

![](_page_1_Figure_5.jpeg)

Fig. 1. Rietveld refinement of room temperature XRD data of [Th1−*x*Fe*x*]O2−<sup>δ</sup> (*x* = 0.0, 0.05, 0.10, 0.15, 0.20 and 0.25). The open circles represent the observed data while the line through circles is the calculated profile. The vertical ticks below the profile are the expected reflections for fluorite type cubic structure (*Fm*3*m*). The continuous line below the vertical tics is the difference pattern. (Inset shows the variation of lattice parameter *a* with dopant concentration *x* up to 20 at.%).

![](_page_1_Figure_7.jpeg)

Fig. 2. XRD patterns of 25 and 30 at.% Fe doped ThO2 along with XRD patterns of Fe2O3 (-+ ).

impurity phase like --Fe2O3 is seen in the XRD patterns (Fig. 2). When the same method of combustion is applied to synthesize the oxides of Fe, such as --Fe2O3, the XRD pattern of the sample showed the peaks corresponding to a mixture of and --Fe2O3 (Fig. 2). The crystallite size calculated for pristine ThO2 using Scherrer's equation is approximately 10–15 nm. It is worth to note that the peaks get narrowed down with increase in 'Fe' concentration indicating the increase in crystallinity and particle size as a function of Fe concentration for the samples prepared under identical conditions. This indicates that Fe may perhaps acts as a grain growth promoter on the growth of ThO2 particles and the crystallinity of the resultant product increases. The lattice parameters extracted by Rietveld refinement analysis presented in the inset of Fig. 1, shows that the lattice parameter '*a*' remained unchanged with increase of Fe concentration up to *x* = 0.20, even though the ionic radius of Fe3+ (0.67 A) is ˚ smaller than that of Th4+ ion (1.02 A). Similar type of behavior ˚ is seen by Hanic et al. [23] in CaO–ThO2 system. Using powder X-ray diffraction method and density measurements, they have proved that CaO–ThO2 system contains substitutional as well as interstitial cations. They observed that part of Ca2+ enters the substitutional special site (4a): (0, 0, 0) for Th4+, while simultaneously, another part of Ca2+ ions enters the interstitial positions (4b). Because of this the lattice parameter and hence the unit cell volume remained approximately constant within the concentration range 0 < *x* < 0.38. Electro neutrality of the solid solution is maintained by the formation of anion vacancies in the oxygen positions (8f,b). We feel it is reasonable to presume that similar explanation holds good for Fe doped ThO2 also.

![](_page_2_Picture_2.jpeg)

Fig. 3. HRTEM, TEM (inset bottom) and SAED (inset top) of 10 at.% Fe doped ThO $_2$ .

High-resolution TEM was performed on 10 at.% Fe doped  $ThO_2$  particles (taken as a representative sample) to investigate the different phases that might have formed in the nanosize range and to determine the chemical state of Fe atoms which could not be detected by XRD. Fig. 3 shows the HRTEM image of 10 at.% Fe doped  $ThO_2$  particles. We found no evidence for the presence of Fe metal clusters or Fe-rich secondary phases in these samples, and thus the Fe is homogenously distributed in  $ThO_2$  matrix. This is further confirmed from the selected-area electron diffraction (SAED) image showing an impurity free structure (inset top right). Indexing of SAED patterns matched with  $ThO_2$  lattice. The particle size of about 10 nm obtained from TEM image matches well with the XRD results.

Fig. 4 depicts the room temperature dc magnetization measurements of  $\text{Th}_{1-x}\text{Fe}_x\text{O}_{2-\delta}$  samples as a function of field. It can be seen from the figure that all samples showed symmetric hysteretic loops typical of ferromagnetic materials. The saturation magnetization value  $M_s$  is found to increase with Fe concentration up to x=0.20. However, for compounds with x above 0.20, a decrease in magnetic moment ( $\mu_B/\text{Fe}$ ) is observed. It is worth to note that while the large coercive field ( $H_c$ =750 Oe) remained more or less the same for all compositions of Fe, the

![](_page_2_Figure_6.jpeg)

Fig. 4. M vs. H curves at RT for  $[Th_{1-x}Fe_x]O_{2-\delta}$  (x = 0.0, 0.05, 0.10, 0.15, 0.20 and 0.25) and  $\gamma$ -Fe<sub>2</sub>O<sub>3</sub>.

![](_page_2_Figure_8.jpeg)

Fig. 5. M vs. H curve at RT and 77 K for 10 at.% Fe doped ThO<sub>2</sub>.

remanence increased linearly with Fe content. It is also worth to note that the coercive field is rather small ( $H_c = 50 \text{ Oe}$ ) for Fe<sub>2</sub>O<sub>3</sub> prepared by the same method (Fig. 4). In the present study, we could observe ferromagnetism for Fe concentration right from 5 to 25% without any co-doping.

Fig. 5 depicts the M versus H curve for the representative sample 10 at.% Fe doped ThO<sub>2</sub>, measured at RT and 77 K. It can be seen that the  $M_{\rm s}$  values at 77 K and RT are more or less same. This indicates there is no change in the ferromagnetic exchange interaction at RT and 77 K. This also indirectly indicates that  $T_{\rm c}$  of these compounds is well above RT.

RTF in dilute magnetic oxide systems is a new phenomenon, which challenges our current understanding of magnetic order in solids. Two most ubiquitous models proposed to explain ferromagnetism in DMS, viz. carrier induced exchange interaction (RKKY interaction) [24] and double exchange interaction [25] are neither flexible nor accurate enough to describe the properties of real systems. The measured carrier density in real systems is generally not sufficiently high for carrier induced exchange interaction. From the insulator nature of ThO2 (band gap = 5.75 eV) one can rule out carrier induced exchange interaction being the mechanism for the magnetic property observed in  $Fe^{3+}$  doped ThO<sub>2</sub>. The absence of any impurity peaks in the XRD patterns up to 20 at.% of Fe doped ThO<sub>2</sub>, excludes the possibility of impurity being the source for the observed room temperature ferromagnetism (RTF). Further, the decrease of magnetic moment ( $\mu_B/Fe$ ) observed for Fe concentration above 20 at.% rules out the possible impurities γ-Fe<sub>2</sub>O<sub>3</sub> and Fe<sub>3</sub>O<sub>4</sub> being the reason for the observed RTF. Recently Coey et al. proposed Fcenter mediated exchange [18,19] to explain the ferromagnetism in diluted magnetic insulators (DMI). An F-center consists of an electron trapped in an oxygen vacancy. The interaction of magnetic ions and this electron form bound magnetic polarons. As the density of F-center increases they overlap and produce donor impurity band. In Fe doped ThO<sub>2</sub>, when Fe<sup>3+</sup> ions substitute for Th<sup>4+</sup> ions, oxygen vacancies are formed near the Fe sites to compensate for the imbalance of the charge. Fe<sup>3+</sup> ions occupying Th<sup>4+</sup> sites are exchange coupled via electron trapped by charge compensating oxygen vacancies (F-centers) near the Fe<sup>3+</sup> ions. In other words the oxygen vacancies near Fe<sup>3+</sup> play a key role in mediating the RTF in the (Th1−*x*Fe*x*)O2−<sup>δ</sup> system. Thus we feel, it is reasonable to speculate that the RTF observed in Fe3+ doped ThO2 can be attributed to the oxygen vacancies and/or defects, in agreement with the model proposed by Coey et al. [18,19], and not due to any impurities formed during the synthesis as evidenced by HRTEM, SAED and XRD.

## **4. Conclusions**

In conclusion, nanocrystalline particles of (Th1−*x*Fe*x*)O2−<sup>δ</sup> (*x* = 0.0, 0.05, 0.10, 0.15, 0.20 and 0.25) have been synthesized by a gel combustion method. Powder X-ray diffraction studies showed an impurity free mono phasic compound up to *x* = 0.20. Lattice parameter values are found to remain constant throughout the Fe concentration range. Magnetization studies as a function of field showed ferromagnetism above room temperature in (Th1−*x*Fe*x*)O2−<sup>δ</sup> (0.0 ≤ *x* ≤ 0.25) system, which can be attributed to the oxygen vacancies and/or defects mediated.

# **References**

- [1] S.A. Wolf, D.D. Awschalom, R.A. Buhrman, J.M. Daughton, S. von Molnar, M.L. Roukes, A.Y. Chthelkanova, D.M. Treger, Science 294 (2001) 1488.
- [2] H. Ohno, F. Matsukura, Y. Ohno, JSAP Int. 5 (2002) 4.
- [3] T. Dietl, H. Ohno, F. Matsukura, J. Cibert, D. Ferrand, Science 287 (2000) 1019.
- [4] P. Sharma, A. Gupta, K.V. Rao, F.J. Owens, R. Sharma, R. Ahuja, J.M.O. Guillen, B. Johansson, G.A. Gehring, Nat. Mater. 2 (2003) 673.
- [5] D.A. Schwartz, N.S. Norberg, O.P. Nguyen, J.M. Parker, D.R. Gamelin, J. Am. Chem. Soc. 125 (2003) 13205.
- [6] P.V. Radovanovic, D.R. Gamelin, Phys. Rev. Lett. 91 (2003) 157202.

- [7] L.F. Liu, J.F. Kang, Y. Wang, H. Tang, L.G. Kong, X. Zhang, R.Q. Han, Solid State Commun. 139 (2006) 263.
- [8] R. Suryanarayana, V.M. Naik, P. Kharel, P. Talanga, R. Naik, Phys. Cond. Matter 17 (2005) 755.
- [9] J. Bryan Daniel, S.A. Santagdo, S.C. Keveren, D.R. Gamelin, J. Am. Chem. Soc. 127 (2005) 15568.
- [10] P.I. Archer, P.V. Rodovanovic, S.M. Heald, D.R. Gamelin, J. Am. Chem. Soc. 127 (2005) 14479.
- [11] Y.K. Yoo, O. Hue, H.-C. Lee, S. Cheng, X.D. Xiang, G.F. Dionne, S. Xu, J. He, Y.S. Chu, S.D. Preite, S.E. Lofland, I. Takeuchi, Appl. Phys. Lett. 86 (2005) 042506.
- [12] G. Peleckis, X. Wang, S.H. Dou, Appl. Phys. Lett. 89 (2006) 022501.
- [13] N.H. Hong, N. Poirot, J. Sakai, Appl. Phys. Lett. 89 (2006) 042503.
- [14] A. Tiwari, V.M. Bhosle, S. Ramachandran, N. Sudakar, J. Narayan, S. Budak, A. Gupta, Appl. Phys. Lett. 88 (2006) 142511.
- [15] S.J. Pearton, C.R. Abernathy, M.E. Overberg, G.T. Thaler, D.P. Nortan, N.A. Theodoropoulou, A.F. Hebard, Y.D. Park, F. Ren, J. Kim, L.A. Boatner, J. Appl. Phys. 93 (2003) 1.
- [16] S.A. Chambers, Y.K. Yoo, MRS Bull. 23 (2003) 706.
- [17] K.R. Kittilstved, N.S. Norberg, D.R. Gamelin, Phys. Rev. Lett. 94 (2005) 147209.
- [18] J.M.D. Coey, M. Venkatesan, C.B. Fitzgerald, Nat. Mater. 4 (2005) 173.
- [19] J.M.D. Coey, A.P. Douvalis, C.B. Fitzgerald, M. Venkatesan, Appl. Phys. Lett. 84 (2004) 1332.
- [20] N.H. Hong, J. Sakai, N.T. Huong, N. Poirot, A. Ruyter, Phys. Rev. B 72 (2005) 045336.
- [21] O.D. Jayakumar, I.K. Gopalakrishnan, S.K. Kulshreshtha, A. Gupta, K.V. Rao, D.V. Louzguine-Luzgin, A. Inoue, P.-A. Glans, J.-H. Guo, K. Samanta, M.K. Singh, R.S. Katiyar, Appl. Phys. Lett. 91 (2007) 052504.
- [22] J. Rodriguez-Carvajal, Fullprof: A Program for Rietveld Refinement and Profile Matching Analysis of Complex Powder Diffraction Patterns ILL, in: Proceedings of the XV Congress of the IUCr, International Union of Crystallography, Toulouse, France, 1990, p. 127.
- [23] F. Hanic, M. Hartmanova, S. Krcho, Solid State Ionics 31 (1988) 167.
- [24] T. Dietl, Semicond. Sci. Technol. 17 (2002) 377.
- [25] J.B. Goodenough, Magnetism and Chemical Bond, Interscience, New York, 1963.