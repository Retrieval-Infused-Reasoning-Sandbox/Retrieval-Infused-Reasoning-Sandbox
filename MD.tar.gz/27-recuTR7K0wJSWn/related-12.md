# **PCCP**

![](_page_0_Picture_2.jpeg)

**View Article Online PAPER** 

![](_page_0_Picture_4.jpeg)

Cite this: Phys. Chem. Chem. Phys., 2018, 20, 20943

Received 6th June 2018, Accepted 25th July 2018

DOI: 10.1039/c8cp03583k

rsc.li/pccp

# Hidden magnetic order in plutonium dioxide nuclear fuel†

James T. Pegg, (10 \*ab Ashley E. Shields, (10 c Mark T. Storr, b Andrew S. Wills, a David O. Scanlon and Nora H. de Leeuw and Nora H. de Leeuw

A thorough understanding of the chemistry of PuO2 is critical to the design of next-generation nuclear fuels and the long-term storage of nuclear materials. Despite over 75 years of study, the ground-state magnetic structure of PuO<sub>2</sub> remains a matter of much debate. Experimental studies loosely indicate a diamagnetic (DM) ground-state, whereas theoretical methods have proposed either a collinear ferromagnetic (FM) or anti-ferromagnetic (AFM) ground-state, both of which would be expected to cause a distortion from the reported  $Fm\bar{3}m$  symmetry. In this work, we have used accurate calculations based on the density functional theory (DFT) to systematically investigate the magnetic structure of PuO2 to resolve this controversy. We have explicitly considered electron-correlation, spin-orbit interaction and noncollinear magnetic contributions to identify a hereto unknown longitudinal 3k AFM ground-state that retains Fm3m crystal symmetry. Given the broad interest in plutonium materials and the inherent experimental difficulties of handling this compound, the results presented in this paper have considerable implications for future computational studies relating to PuO2 and related actinide structures. As the crystal structure is coupled by spin-orbit interactions to the magnetic state, it is imperative to consider relativity when creating computational models.

### 1 Introduction

In the nuclear fuel cycle, PuO<sub>2</sub> plays a significant role as a fissile material and a thorough understanding of its fundamental properties is therefore important. To characterise the nature of condensed matter systems, it is imperative to identify coupled and competing magnetic interactions. An accurate description of the underlying physics, including the magnetic ground-state, is key to the design of reliable computational models. A controversy exists between experimental and theoretical methods, which affects the calculation of phonon frequencies, thermodynamic properties and excited electronic states, 1,2 and has implications for the validation of basic models of reactivity, the design of surface models and the interaction of adsorbents.3 A singlet diamagnetic (DM) ground-state is inferred

by experimental measurements and the one-electron interpretation of the crystal electric field, 4-8 whereas a ferromagnetic (FM) or an anti-ferromagnetic (AFM) ground-state is calculated by firstprinciple methods. 2,3,9-21 In this paper, the controversy detailed in the literature is addressed by high-end first-principles methods and, for the first time, a fully relativistic noncollinear investigation of magnetic order in PuO2 has been conducted. As a key computational consideration, the spin-orbit interaction (SOI, which couples the lattice structure to the magnetic state) is fully considered in this study.<sup>22</sup> A number of experimental measurements on PuO<sub>2</sub> report  $Fm\bar{3}m$  (no. 225) crystal symmetry (Fig. 1), <sup>23</sup> but suggestions of low-temperature (T < 30.8 K) lattice anomalies (reminiscent of transverse 3k AFM behaviour in UO2 with Pa3 (no. 205) crystal symmetry) remain uninvestigated.<sup>24</sup>

The low-temperature characterisation of the PuO2 magnetic ground-state is challenging, due to: nucleonic radioactive decay,25 the toxicity of the metals,26 and the inhomogeneity of samples.<sup>7</sup> A number of inconsistencies in the literature have been recorded.<sup>27</sup> For example, a singlet  $\Gamma_1$  DM ground-state (in accordance with the one-electron crystal-field model) has been inferred by: magnetic susceptibility (T = 4 K), inelastic neutron scattering (INS) (T > 30 K), 5,6 and nuclear magnetic resonance (NMR)  $(T > 4 \text{ K})^{7,8}$  measurements. Although a number of inconsistencies in the literature have been recorded.<sup>27</sup> A singlet  $\Gamma_1$ ground-state has been inferred from the temperature-independent magnetic susceptibility of  $PuO_2$  (5.4  $\times$  10<sup>-4</sup> cm<sup>3</sup> mol<sup>-1</sup>).

<sup>&</sup>lt;sup>a</sup> Department of Chemistry, University College London, 20 Gordon Street, London WC1H 0AJ, UK. E-mail: pegg.james.t@gmail.com

<sup>&</sup>lt;sup>b</sup> Atomic Weapons Establishment (AWE) Plc, Aldermaston, Reading, RG7 4PR, UK

<sup>&</sup>lt;sup>c</sup> Oak Ridge National Laboratory, One Bethel Valley Road, Oak Ridge, Tennessee 37831. USA

<sup>&</sup>lt;sup>d</sup> Diamond Light Source Ltd., Diamond House, Harwell Science and Innovation Campus, Didcot, Oxfordshire OX11 0DE, UK

<sup>&</sup>lt;sup>e</sup> Thomas Young Centre, University College London, Gower Street, London WC1E 6BT, UK

f Cardiff University, School of Chemistry, Main Building, Park Place, Cardiff, CF1D 3AT, UK

<sup>†</sup> Electronic supplementary information (ESI) available. See DOI: 10.1039/c8cp03583k

Paper

Fig. 1 The crystal structure of  $PuO_2$  with; (left)  $Fm\bar{3}m$  (no. 225) (right)  $Pa\bar{3}$  (no. 205) crystal symmetry. The colours in the parentheses indicate the  $Pu^{4+}$  (blue) and  $O^{2-}$  (red) ions. Note, in  $Pa\bar{3}$  symmetry, the displacement of the  $O^{2-}$  ions is exaggerated.

In contrast, the temperature-dependent magnetic susceptibility of  $Th_{1-x}Pu_xO_2$  (~1.1 × 10<sup>-3</sup> cm<sup>3</sup> mol<sup>-1</sup>) indicates a magnetic response that is inconsistent with earlier results.<sup>28</sup> INS measurements of  $PuO_2$  indicate a singlet  $\Gamma_1$  to triplet  $\Gamma_4$ transition of 123 meV, which corresponds to a temperaturedependent magnetic susceptibility of  $\sim 1 \times 10^{-3} \text{ cm}^3 \text{ mol}^{-1}$ when T > 400 K. The magnetic coupling of proximal cations by intermediary DM anions is described by magnetic superexchange.<sup>29</sup> The full width at half maximum (FWHM) INS peak results of 25 meV is indicative of AFM superexchange. 1,30 In addition, magnetic susceptibility measurements of U<sub>1-x</sub>Pu<sub>x</sub>O<sub>2</sub> indicate AFM superexchange with high concentrations of plutonium.31 Finally, the low-temperature 17O NMR measurements of PuO<sub>2</sub> result in an apparent DM state at 6 K and it is conceivable that even lower temperatures may result in a different magnetic ground-state. For instance, low temperature measurements of U<sub>1-x</sub>Pu<sub>x</sub>O<sub>2</sub> indicate a Néel temperature under 5 K when x = 0.5. To compensate for experimental issues (thermal energy released by the decay of actinide nuclei), theoretical methods offer an alternative and complementary means of investigation.

A computational investigation of the PuO<sub>2</sub> systems is highly complicated. This is due to exchange-correlation effects, relativistic influences and magnetic behaviour. It is now well recognised that in highly correlated f-electron systems, conventional DFT<sup>32,33</sup> methods fail to reproduce the correct electronic structure. For instance, identifying finding well-known AnO2 insulators as metallic by underestimating the band-gap. 17,21 To calculate highly-correlated materials, a number of methods offer a correction to the self-interaction error. These include the self-interaction correction (SIC) method,34 modified density functional theory (DFT+U), 32,33,35-37 dynamic mean field theory (DMFT), 38,39 and hybrid density functionals. 12,40,41 In condensed matter physics, the DFT+U method offers a computationally tractable means of study, where the on-site Coulomb repulsion of the f-electrons is treated by tuneable U and I modifiers. In contrast, although the use of hybrid functionals are computationally expensive, they represent one of the more accurate methods available.

DFT studies have consistently reported either a collinear ferromagnetic (FM) or a collinear antiferromagnetic (AFM) ground-state.<sup>3</sup> The ordered magnetic states have been attributed

to approximations inherent to DFT methods.  $^{42}$  In response to the highly-controversial ordered magnetic structures, a number of investigations have focused on the DM solution.  $^{42,43}$  As a combination of the exact diagonalization of the Anderson impurity model and LDA+U ( $U=6.5~{\rm eV}$ ), correlated band theory yielded a DM solution with an f-shell occupation of  $\sim 4.5$  at the Pu atoms. The fully spherical symmetric Coulomb interaction, crystal field, and SOI were included in the multiorbital impurity model.  $^{43}$  The authors found an exited triplet state at 126 meV; however, a complete investigation of ordered magnetic states is needed.

In cases where an ordered magnetic state has been incorporated within the DFT methodology, the investigators have limited the discussion to FM(001) and collinear 1k AFM states.<sup>2,3,9–21</sup> As the actinide elements are heavy-fermion systems, SOI is imperative for the computational treatment of nuclear materials.<sup>44</sup> A limited number of studies have included SOI (due to the high computational cost) in their calculations.<sup>18–21,42,43</sup> The inclusion of noncollinear magnetic behaviour PuO<sub>2</sub> has been ignored.

In addition to general complications associated with highlycorrelated systems, the magnetic ground-state of the AnO2 is influenced by superexchange, multipolar and noncollinear interactions. 1,27 Other methods have been used to model PuO2 systems. The complete active space (CAS) wavefunctions to correct the exchange-correlation errors common to DFT can be used to achieve a DM ground-state. 45 A limitation of the embedded cluster method, however, is that the quantum cluster may not be sufficiently large enough to capture the superexchange interactions in PuO2, and therefore the findings are incomplete. In addition, the ground-state electronic structure and crystal-field levels of PuO2 have been calculated by DFT in terms of the total energy differences. 30 The total energy of the crystal-field states are calculated by the Clebsch-Gordon method from a standard model of rare-earth elements and as a function of their single-electron components. The calculated ground  $\Gamma_1$  state-excited  $\Gamma_4$  state transition of 99 meV compares with the measured INS result of 123 meV.

In the current study, the magnetic structure of  $PuO_2$  has been investigated by noncollinear relativistic calculations. We have implemented three levels of theory. These include density functional theory (PBEsol),  $^{32,33}$  DFT with the Hubbard correction (PBEsol+U),  $^{32,33,35-37}$  and hybrid (HSE06) functionals.  $^{12,40,41,46}$  To date, noncollinear contributions to the magnetic ground-state have remained unexplored, and we have therefore investigated the noncollinear interactions illustrated in Fig. 2. To highlight the importance of SOI, we have compared with non-SOI HSE06 calculations (see additional information, ESI†).

# 2 Computational methodology

A noncollinear relativistic computational study of the  $PuO_2$  magnetic structure by the Vienna Ab initio Simulation Package (VASP) code has been conducted. The code employs relativistic effective core potentials (ECPs), the frozen-core projector-augmented wave (PAW) method and a planewave

**PCCP** Paper

![](_page_2_Figure_4.jpeg)

Fig. 2 The magnetic structure of PuO<sub>2</sub> for the diamagnetic (DM), ferromagnetic (FM) and antiferromagnetic (AFM) states. The direction of the effective magnetic moment ( $\mu$ ) of each ion is described by the  $\mu$  = (a, b, c) wave-vector matrix. Here, transverse (T) and longitudinal (L) domains are considered for the AFM state. The number of independent wave vectors is denoted by the k prefix.

basis set. The cut-off energy of the planewave basis set is 500 eV. The cut-off energy and k-point mesh have been checked for convergence. The following explicit electrons for each atomic species are considered: O (1s<sup>2</sup>2s<sup>2</sup>2p<sup>2</sup>) and Pu (5f<sup>5</sup>6s<sup>2</sup>6p<sup>6</sup>6d<sup>1</sup>7s<sup>2</sup>). The ion-electron interaction was described using the projector-augmented wave (PAW)<sup>41,48</sup> approximation, considering spin-orbit interactions (SOI)<sup>49</sup> and noncollinear magnetic wave vectors. The spin quantisation axis is defined by (0, 0, 1)plane, from which magnetic and spinor-like values are calculated. Ionic forces have been evaluated using the Hellmann-Feynman theorem<sup>50</sup> and conjugate gradient algorithm.<sup>51</sup> The space group has been evaluated to  $10^{-5}$  Å based on a symmetry analysis of the unit cell.

As a computationally intensive method, hybrid functionals incorporate Hartree-Fock (HF) exchange energy into the DFT formulism. In this study, the hybrid Heyd-Scuseria-Ernzerhof (HSE06) functional is employed. 12,40,41,46 The functional offers improved: thermochemical data, band-gaps (for low-medium semi-conductors) and lattice constants.

$$E_{\rm XC}^{\rm HSE} = (a)E_{\rm X}^{\rm HF,SR}(\mu) + (1-a)E_{\rm X}^{\rm PBE,SR}(\mu) + E_{\rm X}^{\rm PBE,LR}(\mu) + E_{\rm C}^{\rm PBE}. \eqno(1)$$

The terms in the parentheses define; the exchange-correlation HSE06 energy  $(E_{XC}^{HSE})$ , an adjustable constant (a), the shortrange (SR) interaction energy and the long-range (LR) interaction energy. The adjustable screening  $(\mu)$  modifier, in the HSE06 functional, is  $0.207 \text{ Å}^{-1}$ . The integration of reciprocal space was completed with a  $\Gamma$ -centred (4·4·4) k-point mesh<sup>52</sup> by the conventional Gaussian or Blöchl tetrahedron method.<sup>53</sup> The iteration threshold for electronic and ionic convergence is  $1 \times 10^{-6}$  eV and  $1 \times 10^{-2}$  eV Å<sup>-1</sup>, respectively.

As a computationally more tractable means of investigation, the DFT+U32,33,35-37 method addresses the on-site Columbic repulsion of the Pu f-electrons. The correction of the electron self-interaction error (SIE) implicit in DFT calculations, is treated by the rotationally invariant Liechtenstein et al. 36 formulism. In the rotationally invariant Liechtenstein et al.36 formulism, the on-site Coulombic (U) and exchange (J) modifiers are treated as independent variables.

$$E_{\rm dc}(\hat{n}) = \frac{U}{2} \hat{n}_{\rm tot}(\hat{n}_{\rm tot} - 1) \frac{J}{2} \sum_{\sigma} \hat{n}_{\rm tot}^{\sigma} (\hat{n}_{\rm tot}^{\sigma} - 1).$$
 (2)

The terms in the parentheses indicate the; double counting energy term  $(E_{dc})$ , the main quantum number (n) and the spin index  $(\sigma)$ . These parameters are applied to the f-orbitals of plutonium. Thus, in the DFT+U modification, the electrons are correctly localised to their specific lattice sites.

In the past, the influence of I on noncollinear magnetic materials has been investigated.  $^{44,54}$  The introduction of Jincreased the anisotropic nature of the f-states. 42 As such, in the current study, the J modifier is kept at a constant value of  $0.00 \text{ eV.}^{44}$  By comparison, when J = 0.00 eV, the Dudarev et al.<sup>35</sup> formulism and Liechtenstein et al.36 formulism are equivalent.54 The integration of reciprocal space was completed with a  $\Gamma$ -centred k-point (5·5·5) mesh<sup>52</sup> by Blöchl tetrahedron method.<sup>53</sup> The iteration threshold for electronic and ionic convergence is  $1 \times 10^{-8}$  eV and  $1 \times 10^{-3}$  eV Å<sup>-1</sup>, respectively. The DFT<sup>32,33</sup> and DFT+ $U^{35-37}$  calculations are performed with PBE revised for solids (PBEsol)<sup>55</sup> exchange-correlation functional. In the calculation of actinide materials, the functional has shown improved results.44 For the optical absorbance calculation, the k-point mesh is 15  $\times$  15  $\times$  15. For the band structure calculations, the Fm3m k-point pathway of high

Paper PCCP

symmetry points in the Brillion zone is defined as  $\Gamma \to L \to W \to X \to \Gamma$ . The density of states and band structure have been illustrated using the SUMO code, a command-line plotting tool for *ab initio* calculations.<sup>56</sup>

#### 2.1 Noncollinear magnetic behaviour

In the high-temperature PM state, the  $AnO_2$  crystallises in the calcium fluorite ( $CaF_2$ ) motif with  $Fm\bar{3}m$  (no. 225) cubic symmetry. In this structure, the  $An^{4+}$  cations occupy octahedral (4a) sites; whereas, the  $O^{2-}$  anions occupy tetrahedral (8c) sites. As the magnetic planes are indistinct, the implicit PM disorder stabilizes the high symmetry  $Fm\bar{3}m$  crystal structure. At low-temperature, the  $AnO_2$  exhibit either DM or AFM behaviour. In addition, multiple first-principle methods calculate a FM ground-state under certain constraints. In the DM and FM states, the implications of noncollinearity are irrelevant. In the AFM state, noncolinear contributions result in 1k (one wave-vector), 2k (two independent wave-vectors) or 3k (three independent wave-vectors) configurations. These configurations are further differentiated when considering longitudinal and transverse domains (Table 1).

In the Russell–Saunders coupling scheme, under the cubic crystal-field, the degeneracy of the  $^5\mathrm{I}_4$  multiplet is split into ascending  $\Gamma_1$  (1),  $\Gamma_4$  (3),  $\Gamma_3$  (2), and  $\Gamma_5$  (3) crystal-field levels (the number in the parentheses denotes the degeneracy).  $^{30,42,43}$  The calculated singlet  $\Gamma_1$  ground-state to triplet  $\Gamma_4$  excited state transition is 123 meV as measured by neutron inelastic scattering.  $^6$  The crystal-field model is technically only valid for the one-electron case; nevertheless, the DM state inferred by experiment is often justified by crystal-field theory.

The majority of studies on the  $AnO_2$  are often limited by the computational expense of the systems and restricted to discussions of collinear 1k magnetism.<sup>2,3,9–21,57</sup> In general, the actinide dioxides ( $AnO_2$ ) exhibit low-temperature noncollinear 3k AFM or PM behaviour (Table S1,  $ESI^{\dagger}$ ).<sup>7,24,58–64</sup> The low-temperature magnetic state can result in a distortion of the crystal structure.<sup>1,27,44,65</sup> For instance, in uranium dioxide ( $UO_2$ ) transverse 3k AFM order results in  $Pa\bar{3}$  symmetry; whereas, in neptunium dioxide ( $NpO_2$ ) longitudinal 3k AFM order preserves  $Fm\bar{3}m$  symmetry. As the crystal structure is coupled by spin–orbit interactions (SOI) to the magnetic state, it is imperative to incorporate relativistic influences when creating computational models.

## 3 Results & discussions

#### 3.1 Magnetic structure

In the current study, the magnetic structure of PuO<sub>2</sub> has been investigated by first-principle methods. The magnetic state clearly influences: relative energetics, band structure, magnetic moment, and crystal symmetry. In our HSE06 and PBEsol+U calculations, the DM state of PuO2 is the highest energy magnetic configuration. In each instance, a longitudinal 3k AFM ground-state with  $Fm\bar{3}m$  cubic symmetry has been calculated. In the absence of SOI, a degenerate FM(011)-FM(111) ground-state has been calculated (see additional information, Table A1, ESI†). The result highlights the need (when modelling PuO<sub>2</sub>) to consider: relativistic effects, exchange-correlation, and noncollinear magnetism. In our hybrid (HSE06) calculations (compared to the DM configuration) the ordered FM and AFM configurations are  $\sim 1.01$  eV per F.U. (formula unit) lower in energy (Table 2). The finding is inconsistent with the DM ground-state indicated by current experimental data. 4-8

It is noted that the experimental optical band-gap (2.80 eV) has been measured by epitaxial thin film absorbance. As the band-gap is influenced by the magnetic state, the experimental PM (high-temperature,  $T \sim 298$  K) result and computational longitudinal 3k AFM result (low-temperature,  $T \sim 0$  K) cannot be directly compared. In addition, the magnetic structure is coupled by SOI to the crystal symmetry. In our calculations, the DM and longitudinal 3k AFM states retain  $Fm\bar{3}m$  crystal symmetry, only. The collinear 1k AFM states (used in past studies) calculate an incorrect crystal structure. A tetragonal I4/mmm (no. 139) (longitudinal 1k AFM) or orthorhombic Fmmm (no. 69) (transverse 1k AFM) crystallographic distortion results.  $^{2,3,9-21}$  This inconsistent with experimental results. In addition, transverse 3k AFM order results in  $Pa\bar{3}$  crystal symmetry (as observed in  $UO_2$  and  $AmO_2$ ).  $^{44}$ 

As a more computationally tractable method of theory (compared with the hybrid functionals), the results obtained from PBEsol+U are reported for different values of U (Fig. 3). In an identical manner to hybrid (HSE06) calculations, the magnetic state influences the electronic and crystallographic structure. PBEsol (U = 0 eV) calculates a degenerate metallic FM (111), (011), (001) ground-state; however, the metallic ground-state is inconsistent with the known insulating nature. The result exemplifies the failure of conventional DFT methods

Table 1 A list of magnetic wavevectors in PuO<sub>2</sub> for the ordered states

|                                            |               |           |           | Antiferromagnetic    |                           |                           |                   |                           |                                     |  |
|--------------------------------------------|---------------|-----------|-----------|----------------------|---------------------------|---------------------------|-------------------|---------------------------|-------------------------------------|--|
|                                            | Ferromagnetic |           |           | Longitudinal domain  |                           |                           | Transverse domain |                           |                                     |  |
| Ion                                        | (001)         | (011)     | (111)     | 1k                   | 2k                        | 3k                        | 1k                | 2k                        | 3k                                  |  |
| (0, 0, 0)                                  | (0, 0, 1)     | (0, 1, 1) | (1, 1, 1) | (0, 0, 1)            | (0, 1, 1)                 | (1, 1, 1)                 | (0, 0, 1)         | (0, 1, 1)                 | (1, 1, 1)                           |  |
| $\left(\frac{1}{2},\frac{1}{2},0\right)$   | (0, 0, 1)     | (0, 1, 1) | (1, 1, 1) | (0, 0, 1)            | $(0,  \overline{1},  1)$  | $(\bar{1},  \bar{1},  1)$ | $(0, 0, \bar{1})$ | $(0,  \bar{1},  \bar{1})$ | $(1,  \overline{1},  \overline{1})$ |  |
| $\left(\frac{1}{2}, 0, \frac{1}{2}\right)$ | (0, 0, 1)     | (0, 1, 1) | (1, 1, 1) | $(0, 0, \bar{1})$    | $(0, 1, \bar{1})$         | $(\bar{1}, 1, \bar{1})$   | (0, 0, 1)         | $(0,  \bar{1},  1)$       | $(\bar{1},\bar{1},1)$               |  |
| $\left(0,\frac{1}{2},\frac{1}{2}\right)$   | (0, 0, 1)     | (0, 1, 1) | (1, 1, 1) | $(0,0,\overline{1})$ | $(0,  \bar{1},  \bar{1})$ | $(1,  \bar{1},  \bar{1})$ | $(0,0,\bar{1})$   | $(0,1,\overline{1})$      | $(\bar{1}, 1, \bar{1})$             |  |

**PCCP** 

Table 2 The relative energy (eV per F.U.), band-gap (eV), magnetic moment ( $\mu_B/Pu$  ion), lattice volume ( $\mathring{A}^3$ ) and space group (number) for each PuO<sub>2</sub> magnetic configuration (calculated by the HSE06 functional). The energetics of the magnetic configurations are calculated relative to the longitudinal 3k antiferromagnetic ground-state

| Magnetic configuration                          |                                  | Relative energy<br>(eV per F.U.)                   | Band-gap<br>(eV)                             | Magnetic moment $(\mu_{ m B}/{ m Pu~ion})$   | Lattice<br>volume (ų)                                    | Space group<br>(number)                                                                    |  |
|-------------------------------------------------|----------------------------------|----------------------------------------------------|----------------------------------------------|----------------------------------------------|----------------------------------------------------------|--------------------------------------------------------------------------------------------|--|
| Diamagnetic                                     |                                  | 1.069                                              | 2.92                                         | 0.00                                         | 155.37                                                   | Fm3m (no. 225)                                                                             |  |
| Ferromagnetic                                   | (001)<br>(011)<br>(111)          | 0.074<br>0.037<br>0.027                            | 1.91<br>1.79<br>1.68                         | 3.66<br>3.68<br>3.68                         | 155.88<br>156.03<br>155.99                               | <i>I4/mmm</i> (no. 139)<br><i>Immm</i> (no. 71)<br><i>R</i> 3 <i>m</i> (no. 166)           |  |
| Antiferromagnetic<br>Longitudinal<br>Transverse | 1k<br>2k<br>3k<br>1k<br>2k<br>3k | 0.058<br>0.011<br>0.000<br>0.062<br>0.020<br>0.009 | 2.83<br>3.05<br>3.04<br>2.50<br>2.93<br>2.68 | 3.63<br>3.65<br>3.65<br>3.64<br>3.66<br>3.66 | 155.69<br>155.65<br>155.65<br>155.64<br>155.73<br>155.72 | I4/mmm (no. 139) I4/mmm (no. 139) Fm3m (no. 225) Fmmm (no. 69) Pbca (no. 61) Pa3 (no. 205) |  |
| Experimental                                    | - "                              | <del>-</del>                                       | $2.80^{66}$                                  | $0.00^{4-8}$                                 | 157.25 <sup>23</sup>                                     | $Fm\bar{3}m~(225)^{23}$                                                                    |  |

with highly-correlated systems. The band-gap is only replicated by the AFM and DM states when U = 5-7 eV.<sup>66</sup> In particular, the band-gap of the experimental DM state and theoretical longitudinal 3k AFM ground-state is reproduced when U = 6.35 eV and U = 6.00 eV, respectively. In contrast, when calculating the band-gap for the FM states, at every value of U, the band-gap is underestimated relative to experimental values.

In experimental studies, DM order has been inferred from the absence of an effective Pu<sup>4+</sup> magnetic moment.<sup>4-8</sup> In this study, the effective magnetic Pu<sup>4+</sup> moment of the ordered FM and AFM states is reported. In the FM states, the effective magnetic moment decreases from 3.85 to 3.75  $\mu_B$ /Pu ion in the U = 0-2 eV range; however, increases from 3.75  $\mu_{\rm B}/{\rm Pu}$  ion to 3.83  $\mu_{\rm B}/{\rm Pu}$  ion when U=3-7 eV. In contrast, the effective magnetic moment of the AFM states continually increases from 3.55  $\mu_{\rm B}/{\rm Pu}$  ion to 3.80  $\mu_{\rm B}/{\rm Pu}$  ion over the range of U=0-7 eV. However, when U = 6 eV, the effective magnetic moment converges at 3.80  $\mu_B$ /Pu ion for all magnetic states.

#### 3.2 Longitudinal 3k antiferromagnetic ground-state

In this paper, a theoretical longitudinal 3k AFM ground-state for  $PuO_2$  has been calculated by PBEsol+U (U = 6.00 eV) and hybrid (HSE06) functionals. The noncollinear magnetic ground-state of UO2, NpO2 (established by experimental means) and PuO2 are highly comparable. The optical absorbance, band structure and density of states for the longitudinal 3k AFM ground-state have been calculated by PBEsol+U (U = 6 eV) (Fig. 4 and Table 3).

A charge-transfer insulator with an indirect bandgap of 2.80 eV has been calculated; this contrasts against the Mottinsulator calculated by the fully relativistic linear combinations of Gaussian-type orbitals-fitting function (LCGTO-FF) method.<sup>19</sup> The respective X-Γ valence band maximum (VBM) to L conduction band minimum (CBM) is comprised predominately of O p- and Pu f-states. The degeneracy of the bands in the longitudinal 3k AFM ground-state is perturbed by the presence of magnetic order. This key finding was made possible only through the inclusion of noncollinear and spin-orbit interactions.

The fundamental band-gap (the difference between the ionisation potential and the electron affinity, the valence band maximum (VBM) to conduction band minimum (CBM) transition) and optical band-gap (transitions are restricted by orbital symmetry) are influenced by the magnetic state. In our calculations, the longitudinal 3k AFM electronic structure is in excellent agreement with optical absorbance measurements.<sup>66</sup> The direct and optical band-gaps differ by 0.17 eV, although both are in excellent agreement with the experimental band-gap of 2.80 eV (Table 3).66

### 3.3 Antiferromagnetic superexchange & small-moment systems

The experimental low-temperature structure of PuO2 (not necessarily indicative of DM order) is characterised by the absence of a lattice distortion and of a magnetic moment. The ambient PM, experimental DM ground-state, and theoretical longitudinal 3k AFM ground-state retain Fm3m crystal symmetry. The absence of any change in crystal structure between the PM and the longitudinal 3k AFM phase is presumed to have helped the ground-state elude detection. A complete analysis can be conducted by comparing other f-electron materials. The results are rationalised by considering magnetic anomalies in NpO2, URu2Si2, UPt3, and UPd3, which are small-moment materials.1

In the absence of an ordered moment and of noticeable lattice anomalies, a phase-transition could be driven by an ordered parameter no longer invariant under time-reversal symmetry.1 The interaction leading to a phase-transition would have to arise from a purely electronic mechanism, as phonons may only carry interactions between time-reversal-invariant multipoles. A magnetic multipole (for which Kramers' theorem would no longer apply) by AFM superexchange is a candidate for an ordered mechanism. 1,27,67 As an indication of superexchange, the magnetic susceptibility measurements for PuO2 and Th1-xPuxO2 are inconsistent. 4,28,31 The interaction of the Pu4+ ions in Th<sub>1-x</sub>Pu<sub>x</sub>O<sub>2</sub> is reduced by dilution; this suppresses the superexchange mechanism and increases the magnetic susceptibility.<sup>1</sup> Paper PCCP

![](_page_5_Figure_4.jpeg)

Fig. 3 The relative ground-state energies, band-gaps, and effective magnetic moments against the Coulomb modifier (U) for diamagnetic (DM), ferromagnetic (FM), and antiferromagnetic (AFM) states of PuO2, calculated with PBEsol (U = 0 eV) and PBEsol+U. The antiferromagnetic transverse (T) and longitudinal (L) domains are additionally represented. The k-prefix denotes the number of independent wave vectors: (upper row) the calculated energy of magnetic states relative to the longitudinal 3k antiferromagnetic ground-state; (middle row) the direct band-gap; (lower row) the effective Pu magnetic moment. The DM (yellow), FM (red), longitudinal AFM (green) and transverse AFM (blue) states are denoted by the colours in the parentheses.

In addition, anomalies in the INS measurements of PuO2 have been attributed to Jahn–Teller distortions and superexchange interactions.5,6 As a comparison, a superexchange interaction is theorised to occur in NpO2 where a magnetic octupole has been established.68

In another interpretation, PuO2 may be a small-moment system. This is observed in other actinide materials where the AFM response of URu2Si2 (T<sup>N</sup> = 17.5 K), UPt3 (T<sup>N</sup> = 5 K) and UPd3 (T<sup>N</sup> = 4.5 K) is 0.02–0.03 mB/U ion.1 Indeed, a smallmoment magnetic state has been theorised for NpO2 where muon spin rotation measurements of the magnetic moment is 0.06–0.15 mB/Np ion.1,69 The nature of small-moment systems in unclear.<sup>1</sup> The moment of a system may be reduced by competing magnetic interactions. In the localised PuO2 f-electron system, the interaction may be Rudermann, Kittel, Kasuya, Yoshida (RKKY) or Kondo in nature. If a smallmoment in the PuO2 system exists, establishing the magnetic ground-state is a considerable challenge. In our results, the magnetic moment of the longitudinal 3k AFM ground-state is B3.65 mB/Pu ion. In this regard, first-principle DFT methods are known to overestimate small-moment actinide materials.<sup>1</sup> It is also conceivable that PuO2 undergoes a second lowtemperature phase transition, which is known to occur in other actinide compounds. For instance, the specific heat capacity of UPt3 has two distinct anomalies at TC1 = 0.49 K and TC2 = 0.44 K indicative of changing magnetic order. A detailed low-temperature experimental study of magnetic order in PuO2 is needed.

**PCCP** Paper

![](_page_6_Figure_4.jpeg)

Fig. 4 The electronic structure of the longitudinal 3k antiferromagnetic ground-state of  $PuO_2$  calculated by PBEsol+U where U=6 eV; (left) band structure, (right) density of states. The colours in the parentheses indicate the Pu f- (blue), Pu d- (green) and O p- (red) states.

Table 3 The fundamental band-gap (eV), optical band-gap (eV), lattice constant (Å), bulk modulus (GPa) and magnetic moment ( $\mu_B/Pu$  ion) for the diamagnetic (DM, U = 6.35 eV) and longitudinal 3k antiferromagnetic (AFM, U = 6.00 eV) state of PuO<sub>2</sub> (calculated by PBEsol+U)

|                      | Band-gap (eV) |                                    | Lattice                                     | Bulk                  | Magnetic moment              | Crystal                                | Magnetic                                        |  |
|----------------------|---------------|------------------------------------|---------------------------------------------|-----------------------|------------------------------|----------------------------------------|-------------------------------------------------|--|
| $\mathrm{DFT} {+} U$ | Fundamental   | Optical                            | constant (Å)                                | modulus (GPa)         | $(\mu_{\rm B}/{\rm Pu~ion})$ | symmetry                               | configuration                                   |  |
| 6.35<br>6.00         | 2.81<br>2.80  | 2.82<br>2.97<br>2.80 <sup>66</sup> | 5.411<br>5.415<br>5.395–5.398 <sup>23</sup> | 217<br>215<br>178–379 | 0.00<br>3.80<br>0.00         | Fm3m (225)<br>Fm3m (225)<br>Fm3m (225) | DM <sup>44</sup><br>Longitudinal 3k AFM<br>Exp. |  |

## 4 Conclusions

In conclusion, the magnetic structure of PuO2 has been investigated by computational means. As a highly-correlated and heavy-fermion system, the electronic structure of PuO<sub>2</sub> is notoriously difficult to calculate. Investigations of surface reactivity and bonding often rely on exact calculations of the electronic structure. A key finding is the impact of transverse and longitudinal domains on the band structure. In the case of collinear 1k AFM order, the electronic structure is significantly different depending on the domain employed, which is important as most investigations on AnO2 do not differentiate between collinear magnetic structurers.

In our calculations, the metastable DM state (in contrast with the longitudinal 3k AFM ground-state) is inconsistent with current experimental information. In this paper, we have established a longitudinal 3k AFM ground-state with Fm3m crystal symmetry. The fact that this magnetic ground-state has not been experimentally observed may be explained in two possible ways. First, PuO<sub>2</sub> may be a small-moment material for which current experimental resolution is insufficient to identify an ordered magnetic state. If this is the case, dynamic mean field-theory (DMFT) may be needed to resolve the magnetic moment. Second, an AFM-DM phase transition may occur outside of the temperature range typically studied in the available literature. In theory a superexchange mechanism might result in a hidden magnetic phase transition. This paper calls for further experimental studies to resolve outstanding issues, in particular low-temperature specific heat capacity and muon spin relaxation measurements are needed.

Furthermore, we have shown how the crystal structure is influenced by the magnetic state. For instance, transverse 3k AFM behaviour results in Pa3 crystal symmetry, 22,44 synonymous with calculations of UO2 and AmO2 when SOI are considered. Finally, the electronic structure of PuO2 is highly influenced by the magnetic state employed. These results have profound implications for investigations of bonding, reactivity, and surface structure. The re-orientation of magnetic vectors in surface calculations is often neglected (the direction of magnetism is usually defined by the z-axis), resulting in incomparable magnetic configurations between low-index surfaces. As the magnetic structure has a clear impact of the energetics, it is imperative that the re-orientation of magnetic vector is accounted for in computational surface investigations.

### Conflicts of interest

The authors declare no competing financial interests.

# Acknowledgements

This research was supported by the UK Engineering & Physical Science Research Council (EPSRC) (grant no. EP/G036675 and EP/K016288) and the Atomic Weapons Establishment (AWE). AES gratefully acknowledges the United States Department of Homeland Security (DHS), Domestic Nuclear Detection Office (DNDO), National Technical Nuclear Forensics Centre (NTNFC) for a Postdoctoral Research Fellowship. NHdL thanks AWE for a William Penney Fellowship. This work made use of the ARCHER UK National Supercomputing Service (http://www.archer.ac.uk), *via* our membership of the UK's HEC Materials Chemistry Consortium, which is funded by EPSRC (EP/L000202).

### Notes and references

Paper

- 1 P. Santini, R. Lémanski and P. Erdős, *Adv. Phys.*, 1999, **48**, 537–653.
- 2 G. Jomard and F. Bottin, *Phys. Rev. B: Condens. Matter Mater. Phys.*, 2011, **84**, 195469.
- 3 D. Gryaznov, E. Heifets and D. Sedmidubsky, *Phys. Chem. Chem. Phys.*, 2010, 12, 12273–12278.
- 4 G. Raphael and R. Lallement, *Solid State Commun.*, 1968, 6, 383–385.
- 5 S. Kern, C. K. Loong, G. L. Goodman, B. Cort and G. H. Lander, *J. Phys.: Condens. Matter*, 1990, 2, 1933.
- 6 S. Kern, R. Robinson, H. Nakotte, G. Lander, B. Cort, P. Watson and F. Vigil, *Phys. Rev. B: Condens. Matter Mater. Phys.*, 1999, 59, 104.
- 7 Y. Tokunaga, H. Sakai, T. Fujimoto, S. Kambe, R. E. Walstedt, K. Ikushima, H. Yasuoka, D. Aoki, Y. Homma, Y. Haga, T. D. Matsuda, S. Ikeda, E. Yamamoto, A. Nakamura, Y. Shiokawa, K. Nakajima, Y. Arai and Y. Ōnuki, J. Alloys Compd., 2007, 444-445, 241-245.
- 8 H. Yasuoka, G. Koutroulakis, H. Chudo, S. Richmond, D. K. Veirs, A. I. Smith, E. D. Bauer, J. D. Thompson, G. D. Jarvinen and D. L. Clark, *Science*, 2012, 336, 901–904.
- 9 X.-D. Wen, R. L. Martin, G. E. Scuseria, S. P. Rudin and E. R. Batista, J. Phys. Chem. C, 2013, 117, 13122–13128.
- 10 I. D. Prodan, G. E. Scuseria and R. L. Martin, *Phys. Rev. B: Condens. Matter Mater. Phys.*, 2006, 73, 045104.
- 11 D. A. Andersson, J. Lezama, B. P. Uberuaga, C. Deo and S. D. Conradson, *Phys. Rev. B: Condens. Matter Mater. Phys.*, 2009, **79**, 024110.
- 12 I. D. Prodan, G. E. Scuseria and R. L. Martin, *Phys. Rev. B: Condens. Matter Mater. Phys.*, 2007, **76**, 033101.
- 13 Y. Yang, B. Wang and P. Zhang, *J. Nucl. Mater.*, 2013, **433**, 345–350.
- 14 B. Sun, H. Liu, H. Song, G. Zhang, H. Zheng, X. Zhao and P. Zhang, J. Nucl. Mater., 2012, 426, 139–147.
- 15 P. Zhang, B.-T. Wang and X.-G. Zhao, *Phys. Rev. B: Condens. Matter Mater. Phys.*, 2010, **82**, 144110.
- 16 D. Gryaznov, S. Rashkeev, E. Kotomin, E. Heifets and Y. Zhukovskii, *Nucl. Instrum. Methods Phys. Res., Sect. B*, 2010, **268**, 3090–3094.
- 17 I. D. Prodan, G. E. Scuseria, J. A. Sordo, K. N. Kudin and R. L. Martin, *J. Chem. Phys.*, 2005, **123**, 014703.
- 18 X.-D. Wen, R. L. Martin, T. M. Henderson and G. E. Scuseria, *Chem. Rev.*, 2013, **113**, 1063–1096.
- 19 J. Boettger and A. Ray, Int. J. Quantum Chem., 2002, 90, 1470-1477.
- 20 S. A. Moten, R. Atta-Fynn, A. K. Ray and M. N. Huda, J. Nucl. Mater., 2016, 468, 37–45.
- 21 H. Wang and K. Konashi, J. Alloys Compd., 2012, 533, 53-57.
- 22 J. T. Pegg, A. E. Shields, M. T. Storr, A. S. Wills, D. O. Scanlon and N. H. de Leeuw, 2018, https://chemrxiv.org/articles/

- Magnetic\_Structure\_of\_UO2\_and\_NpO2\_by\_First-Principle\_ Methods/6859940.
- 23 J. M. Haschke, T. H. Allen and L. A. Morales, *Science*, 2000, 287, 285–287.
- 24 L. Desgranges, Y. Ma, P. Garcia, G. Baldinozzi, D. Siméone and H. E. Fischer, *Inorg. Chem.*, 2016, **56**, 321–326.
- 25 M. Noe and J. Fuger, *Inorg. Nucl. Chem. Lett.*, 1974, **10**, 7–19.
- 26 E. Ansoborlo, O. Prat, P. Moisy, C. Den Auwer, P. Guilbaud, M. Carriere, B. Gouget, J. Duffield, D. Doizi, T. Vercouter, C. Moulin and V. Moulin, *Biochimie*, 2006, 88, 1605–1618.
- 27 P. Santini, S. Carretta, G. Amoretti, R. Caciuffo, N. Magnani and G. H. Lander, *Rev. Mod. Phys.*, 2009, **81**, 807–863.
- 28 G. A. Candela, C. A. Hutchison and W. B. Lewis, *J. Chem. Phys.*, 1959, **30**, 246–250.
- 29 P. W. Anderson, Phys. Rev., 1950, 79, 350-356.
- 30 M. Colarieti-Tosti, O. Eriksson, L. Nordström, J. Wills and M. S. S. Brooks, *Phys. Rev. B: Condens. Matter Mater. Phys.*, 2002, 65, 195102.
- 31 D. Kolberg, F. Wastin, J. Rebizant, P. Boulet, G. H. Lander and J. Schoenes, *Phys. Rev. B: Condens. Matter Mater. Phys.*, 2002, **66**, 214418.
- 32 P. Hohenberg and W. Kohn, Phys. Rev., 1964, 136, B864-B871.
- 33 W. Kohn and L. J. Sham, Phys. Rev., 1965, 140, A1133-A1138.
- 34 J. P. Perdew and A. Zunger, *Phys. Rev. B: Condens. Matter Mater. Phys.*, 1981, 23, 5048–5079.
- 35 S. L. Dudarev, G. A. Botton, S. Y. Savrasov, C. J. Humphreys and A. P. Sutton, *Phys. Rev. B: Condens. Matter Mater. Phys.*, 1998, 57, 1505–1509.
- 36 A. I. Liechtenstein, V. I. Anisimov and J. Zaanen, *Phys. Rev. B: Condens. Matter Mater. Phys.*, 1995, **52**, R5467–R5470.
- 37 V. I. Anisimov, J. Zaanen and O. K. Andersen, *Phys. Rev. B: Condens. Matter Mater. Phys.*, 1991, 44, 943–954.
- 38 A. Georges, G. Kotliar, W. Krauth and M. J. Rozenberg, *Rev. Mod. Phys.*, 1996, **68**, 13.
- 39 Q. Yin, A. Kutepov, K. Haule, G. Kotliar, S. Y. Savrasov and W. E. Pickett, *Phys. Rev. B: Condens. Matter Mater. Phys.*, 2011, **84**, 195111.
- 40 C. Adamo and V. Barone, J. Chem. Phys., 1999, 110, 6158-6170.
- 41 J. Heyd, G. E. Scuseria and M. Ernzerhof, *J. Chem. Phys.*, 2003, **118**, 8207–8215.
- 42 M. T. Suzuki, N. Magnani and P. M. Oppeneer, *Phys. Rev. B: Condens. Matter Mater. Phys.*, 2013, **88**, 195146.
- 43 A. Shick, J. Kolorenč, L. Havela, T. Gouder and R. Caciuffo, *Phys. Rev. B: Condens. Matter Mater. Phys.*, 2014, **89**, 041109.
- 44 J. T. Pegg, X. Aparicio-Anglès, M. Storr and N. H. de Leeuw, J. Nucl. Mater., 2017, 492, 269–278.
- 45 F. Gendron and J. Autschbach, *J. Phys. Chem. Lett.*, 2017, 673–678, DOI: 10.1021/acs.jpclett.6b02968.
- 46 A. V. Krukau, O. A. Vydrov, A. F. Izmaylov and G. E. Scuseria, J. Chem. Phys., 2006, 125, 224106.
- 47 V. I. Anisimov, Strong coulomb correlations in electronic structure calculations, CRC Press, 2000.
- 48 J. Heyd, G. E. Scuseria and M. Ernzerhof, *J. Chem. Phys.*, 2006, 124, 219906.
- 49 S. Steiner, S. Khmelevskyi, M. Marsmann and G. Kresse, *Phys. Rev. B: Condens. Matter Mater. Phys.*, 2016, **93**, 224425.

50 R. P. Feynman, Phys. Rev., 1939, 56, 340-343.

**PCCP** 

- 51 W. H. Press, S. A. Teukolsky, W. T. Vetterling and B. P. Flannery, Numerical Recipes3rd Edition: The Art of Scientific Computing, Cambridge University Press, 2007.
- 52 H. J. Monkhorst and J. D. Pack, Phys. Rev. B: Condens. Matter Mater. Phys., 1976, 13, 5188.
- 53 P. E. Blöchl, O. Jepsen and O. K. Andersen, Phys. Rev. B: Condens. Matter Mater. Phys., 1994, 49, 16223.
- 54 E. Bousquet and N. Spaldin, Phys. Rev. B: Condens. Matter Mater. Phys., 2010, 82, 220402.
- 55 G. I. Csonka, J. P. Perdew, A. Ruzsinszky, P. H. Philipsen, S. Lebègue, J. Paier, O. A. Vydrov and J. G. Ángyán, Phys. Rev. B: Condens. Matter Mater. Phys., 2009, 79, 155107.
- 56 A. M. Ganose, A. J. Jackson and D. O. Scanlon, Sumo: Command-line tools for plotting and analysis of \*ab initio\* calculations, 2018, https://raw.githubusercontent.com/SMTG-UCL/sumo/master/paper.md.
- 57 G. Jomard, B. Amadon, F. Bottin and M. Torrent, Phys. Rev. B: Condens. Matter Mater. Phys., 2008, 78, 075125.
- 58 L. Asprey, F. Ellinger, S. Fried and W. Zachariasen, I. Am. Chem. Soc., 1955, 77, 1707-1708.
- 59 K. Ikushima, S. Tsutsui, Y. Haga, H. Yasuoka, R. E. Walstedt, N. M. Masaki, A. Nakamura, S. Nasu and Y. Önuki, Phys. Rev. B: Condens. Matter Mater. Phys., 2001, 63, 104404.

- 60 Y. Tokunaga, Y. Homma, S. Kambe, D. Aoki, H. Sakai, E. Yamamoto, A. Nakamura, Y. Shiokawa, R. E. Walstedt and H. Yasuoka, Phys. Rev. Lett., 2005, 94, 137209.
- 61 Y. Tokunaga, T. Nishi, S. Kambe, M. Nakada, A. Itoh, Y. Homma, H. Sakai and H. Chudo, J. Phys. Soc. Jpn., 2010, 79, 053705.
- 62 J. Faber and G. H. Lander, Phys. Rev. B: Solid State, 1976, 14, 1151-1164.
- 63 J. Faber, G. H. Lander and B. R. Cooper, Phys. Rev. Lett., 1975, 35, 1770-1773.
- 64 D. Mannix, G. H. Lander, J. Rebizant, R. Caciuffo, N. Bernhoeft, E. Lidström and C. Vettier, Phys. Rev. B: Condens. Matter Mater. Phys., 1999, 60, 15187-15193.
- 65 R. Caciuffo, G. Amoretti, P. Santini, G. H. Lander, J. Kulda and P. D. V. Du Plessis, Phys. Rev. B: Condens. Matter Mater. Phys., 1999, 59, 13892-13900.
- 66 T. M. McCleskey, E. Bauer, Q. Jia, A. K. Burrell, B. L. Scott, S. D. Conradson, A. Mueller, L. Roy, X. Wen and G. E. Scuseria, J. Appl. Phys., 2013, 113, 013515.
- 67 P. Santini and G. Amoretti, Phys. Rev. Lett., 2000, 85, 2188-2191.
- 68 R. Caciuffo, J. A. Paixão, C. Detlefs, M. J. Longfield, P. Santini, N. Bernhoeft, J. Rebizant and G. H. Lander, I. Phys.: Condens. Matter, 2003, 15, S2287.
- 69 W. Kopmann, F. J. Litterst, H. H. Klauß, M. Hillberg, W. Wagener, G. M. Kalvius, E. Schreier, F. J. Burghart, J. Rebizant and G. H. Lander, J. Alloys Compd., 1998, 271-273, 463-466.