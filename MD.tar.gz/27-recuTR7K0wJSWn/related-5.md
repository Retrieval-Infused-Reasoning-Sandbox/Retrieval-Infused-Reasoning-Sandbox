## The Electronic Structure of Actinide-Containing Molecules: A Challenge to **Applied Quantum Chemistry**

MELANIE PEPPER and BRUCE E. BURSTEN\*

Department of Chemistry, The Ohio State University, Columbus, Ohio 43210

Received November 6, 1990 (Revised Manuscript Received February 18, 1991)

#### Contents

| I.   | Introduction                                 | 719 |  |  |  |  |  |
|------|----------------------------------------------|-----|--|--|--|--|--|
| II.  | Molecular Relativistic Quantum Chemical      |     |  |  |  |  |  |
|      | Methods                                      |     |  |  |  |  |  |
|      | A. Relativistic Extended Hückel Theory (REX) | 722 |  |  |  |  |  |
|      | B. Dirac-Fock One-Center Expansion           | 723 |  |  |  |  |  |
|      | (DF-OCE)                                     |     |  |  |  |  |  |
|      | C. Local Density Functional (LDF) Approach   | 723 |  |  |  |  |  |
|      | D. Ab Initio Effective Core Potentials (ECP) | 724 |  |  |  |  |  |
| III. | Actinide Hydrides                            | 725 |  |  |  |  |  |
| IV.  | Actinide Halides                             | 726 |  |  |  |  |  |
| ٧.   | Actinide Oxides                              | 729 |  |  |  |  |  |
| VI.  | Cyclopentadienyl-Actinide Complexes          | 731 |  |  |  |  |  |
| VII. | Actinocenes                                  | 733 |  |  |  |  |  |
| III. | Metal-Metal Bonding in Actinide Systems      | 735 |  |  |  |  |  |
| IX.  | Miscellaneous Other Actinide Systems         | 737 |  |  |  |  |  |
| X.   | Conclusions                                  | 738 |  |  |  |  |  |

#### I. Introduction

In the last century, three parallel developments have contributed greatly to our understanding of the electronic structure of the chemical elements. First, the application of quantum mechanics to chemical systems has allowed first-principles predictions of chemical properties. Second, the extension of the periodic table to include the lanthanide and actinide elements has compelled chemists to develop an understanding of f electrons and the chemical influence of special relativity. Finally, digital computer technology has advanced to the point that computational chemistry is now a commonplace tool for laboratory chemists. It is the purpose of this review to underscore that these three trends have merged, as is dramatically demonstrated in the study of molecular actinide systems by accurate quantum chemical methods.

With the development of the Schrödinger equation in 1927, followed by Dirac's matrix formulation including relativistic effects in 1929, Dirac was moved to pronounce:1 "The underlying physical laws necessary for the mathematical theory of a large part of physics and the whole of chemistry are thus completely known, and the difficulty is only that the exact application of these laws leads to equations much too complicated to be soluble." The next sentence in "Dirac's dictum" is often ignored, but is perhaps of value in the current discussion: "It therefore becomes desirable that approximate practical methods of applying quantum mechanics should be developed, which can lead to an explanation of the main features of complex atomic systems without too much computation."

The situation was viewed as not much more hopeful in 1960, when Coulson<sup>2,3</sup> pointed out the disparity be-

![](_page_0_Picture_13.jpeg)

Melanie Pepper was born in Atlanta, GA, in 1959. She received her B.S. degree with honors (1981) from the University of Kentucky, Lexington, and her Ph.D. degree (1989) from The Ohio State University under the direction of Prof. Isaiah Shavitt. She currently holds a postdoctoral position with Prof. Bruce E. Bursten at The Ohio State University. Her research interests include the development of quantum chemical methods and computer programs. characterization of potential energy surfaces, and application of ab initio quantum chemistry to heavy-metal systems.

![](_page_0_Picture_15.jpeg)

Bruce E. Bursten was born in Chicago, IL, in 1954. He received his S.B. degree with honors in chemistry from the University of Chicago (1974) and his Ph.D. degree (with R. F. Fenske) from the University of Wisconsin (1978). Following two years as an NSF Postdoctoral Fellow at Texas A&M University (with F. A. Cotton). he joined the faculty of The Ohio State University, where he is currently Professor of Chemistry. His research interests include the electronic structure of transition-metal and actinide complexes. organometallic photochemistry, metal-metal bonding, and applied quantum chemistry.

tween two groups of computational chemists: those doing accurate calculations on very small systems and those doing approximate calculations on chemically more-interesting systems. He went on to state, "It looks as if somewhere around 20 electrons there is an upper limit to the size of a molecule for which accurate calculations are ever likely to become practicable." By 1950, Boys<sup>4,5</sup> had realized that "[It] thus has been established that the only difficulty which exists in the evaluation of the energy and wave function of any molecule ... is the amount of computing necessary." This assertion was affirmed by Mulliken<sup>6,7</sup> in 1967: "There is only one obstacle, namely, that someone must pay for the computer time." Clementi was even more optimistic in 1972,8 when he stated, "We can calculate everything."

The current state of affairs has been nicely summarized by Karplus, 9 who notes that the two camps delineated by Coulson² are beginning to merge, with high accuracy available now for systems of up to 20 electrons. Karplus further points out that the four decades between 1950 and 1990 have seen a 107 increase in computer speed, and a 103 increase in code efficiency.

Although one might still hear theoretical chemists referring to carbon as a "heavy" atom, the advent of modern supercomputers, in concert with dramatic improvements in program algorithms, have brought about a revolution in computational chemistry and a convergence of the three trends described above. Highly accurate computational studies of "real" chemical systems are no longer an elusive dream; the entire periodic table of elements is open to computational study.

Of course, solution of the Schrödinger and Dirac equations for molecules still requires some approximations. Ab initio quantum chemists have most often employed the self-consistent field (SCF) approximation (nonlocal exchange) coupled with a basis set expansion. Approximate and semiempirical SCF methods have also been developed, in which ab initio SCF theory is the starting point upon which various approximations are overlaid. Local density functional (LDF) theorists take a different approach, using a local exchange potential and focusing on the density matrix rather than the wave function. The various  $X\alpha$  methods, such as the multiple scattering10 and discrete variational11,12 approaches, are examples of LDF methods. The inclusion of relativistic effects in quantum chemical calculations requires further approximations. These include relativistic extended Hückel theory, 13 one-center expansion solutions of the Dirac-Fock equations, 14 full solution of the Dirac–Fock equations with local exchange,  $^{15,16}$  quasirelativistic corrections to  $X\alpha$  calculations,  $^{17-25}$  and ab initio relativistic core potential methods.<sup>26-28</sup> These relativistic approximations, and the importance of relativity in studies of heavy-element chemistry, have been the subject of many review articles.<sup>29-41</sup>

Prior to the extension of the periodic table to include the whole family of actinide elements, uranium chemistry was well known. In fact, uranium is by far the most widely studied and best understood of the actinide elements. As early as 1833, chemists were studying the fluorescence of uranyl compounds.<sup>42</sup> Interest in nuclear fuels has prompted studies of small actinide-containing molecules and ions, especially the halides and oxides of uranium and plutonium. The synthesis of uranocene by Streitwieser and Müller-Westerhoff<sup>43</sup> in 1968 generated tremendous interest in organoactinide chemistry, paralleling the growth in the organometallic chemistry of the transition metals that followed the synthesis of ferrocene. Actinide chemistry has been the topic of numerous discussions and review articles. These in-

clude descriptions of uranyl chemistry<sup>42,44-47</sup> and the debate over the importance of 5f electrons and their covalent interactions.<sup>48-59</sup> Marks has written several excellent reviews of organoactinide chemistry,<sup>60-66</sup> and a recent review from our laboratories<sup>67</sup> addresses the bonding in the diverse class of cyclopentadienyl-actinide complexes.

Throughout these 20th century advances in actinide chemistry, quantum chemical calculations have been a willing and able partner to synthesis and spectroscopy. Perhaps more than any other recent developments in chemistry, the results of actinide studies have demanded that we reexamine and, in many cases, rewrite the empirical rules that define chemical intuition. The understanding of the electronic structure of actinidecontaining systems has been key in the development of this important area of chemistry. In addition to the molecular studies that are the subject of this review, a large body of research has been devoted to understanding the solid-state electronic properties of the actinides. In fact, many of the crucial theoretical developments were pioneered in the solid-state arena before being applied to molecular systems, and experimental work on solid-state systems often preceded research on the molecular level. The theoretical developments in solid-state actinide chemistry encompass quantum chemistry and theoretical condensed-matter physics and are, we believe, inappropriate for the present review. We will therefore limit our discussion to molecular actinide chemistry and refer the reader to the vast solid-state actinide literature.<sup>68</sup> We also will not address the important nuclear chemistry of the actinide elements in spite of its being the major stimulus for the development of actinide chemistry.

In this review, we will focus on computational studies of the molecular electronic structure of actinide systems, emphasizing the wide variety of computational methods that have been applied to these compounds. Pyykkö has provided a brief outline of relativistic calculations on f-element molecules,<sup>37</sup> as well as a bibliography of all such studies from 1916 to 1985.<sup>41</sup> Here, we expand upon these listings in order to illustrate the breadth of information that can be gained from computational treatment of actinide systems, as well as to provide some understanding of the quality and type of results that might be expected from both nonrelativistic and relativistic quantum chemical calculations.

By restricting our discussion to methods that have been applied to actinide systems, we omit several important families of quantum chemical calculations. The first are the semiempirical CNDO and MNDO approaches, with adaptations such as PRDDO and PNDO. Fanning<sup>89</sup> has extended CNDO to f-elements and Boca<sup>70</sup> has described a relativistic parameterization of CNDO/1, but, to our knowledge, these methods have only been applied to actinide systems by a single research group. <sup>71-73</sup> These methods may prove useful for systems still too large for study by more accurate (and expensive) methods.

We have also limited our discussion to molecular orbital (MO) and MO-based methods, neglecting the parallel development of valence-bond theory. The generalized valence bond (GVB) method<sup>74</sup> provides a satisfying chemical interpretation often lacking in molecular orbital methods. Again, to our knowledge this

approach has not been applied in studies of actinide systems. We refer the reader to the recent review by Pyykkö<sup>39</sup> for a discussion of more accurate relativistic quantum chemical calculations on light-atom systems; again, these methods have not been applied to actinide compounds and are therefore excluded from our discussion.

In the next section of this review, we outline the development of molecular electronic structure methods, including the various approaches for incorporating relativistic effects into these calculations. In subsequent sections, our discussion of applications of these methods to actinide systems will demonstrate the utility of the methods along with their relative strengths and weaknesses. In the third section, we present results of calculations on the simplest actinide systems, the actinide hydrides. Actinide halide systems and actinide oxides, including uranyl, are discussed in sections IV and V, respectively. Organoactinide systems are covered in sections VI (cyclopentadienyl compounds) and VII (actinocenes). Metal-metal bonding in actinide complexes is discussed in section VIII. In section IX, we present calculations on miscellaneous other actinide systems, including  $U(BH_4)_4$  and  $U(OCH_3)_6$ .

# II. Molecular Relativistic Quantum Chemical Methods

Although Dirac introduced special relativity into quantum mechanics in 1929, and the extension to many-electron systems was made by Breit soon after, the importance of relativistic corrections in molecular quantum chemistry was not fully appreciated until the 1970's. Dirac himself was not convinced of the importance of relativistic effects, which he declared would be "of no importance in the consideration of atomic and molecular structure and ordinary chemical reactions."1 In heavy atoms, beginning with the third-row transition metals, and certainly including the actinide elements, the high kinetic energy of the core electrons, corresponding to classical speeds close to the speed of light, leads to large relativistic effects. Powell<sup>29</sup> has provided an easily understood description of the derivation of Dirac's relativistic quantum mechanics and its impact on quantum chemistry. Several recent reviews of relativistic quantum chemistry cover the topic in even greater depth.30-41 Well-known consequences of special relativity in the periodic properties of elements include the yellow color of gold and the anomalous volatility of mercury, as well as the actinide and, to a lesser extent, lanthanide contractions. While nonrelativistic calculations have provided some qualitative insight into actinide chemistry, the inclusion of relativistic effects is essential for the quantitative prediction of molecular structures and energies.

Because most of the chemical uniqueness of the actinide elements is a consequence of the presence of valence f electrons, much of our focus will be on the effects of relativity on the 5f orbitals. The fact that many of the relativistic effects increase as  $Z^n$  (n > 1) indicates that these effects are more pronounced for the actinide (5f) elements than for the lanthanide (4f) elements. This trend is apparent in Figure 1, in which the nonrelativistic and Dirac-Fock relativistic atomic orbital energies<sup>75</sup> for lanthanide and corresponding actinide atoms are compared. Figure 1 illustrates the two

![](_page_2_Figure_7.jpeg)

Figure 1. The Dirac-Fock average of configuration orbital energies (au)<sup>75</sup> for the lanthanides Sm, Eu, Gd, and Tb and for the corresponding actinides Pu, Am, Cm, Bk. The inner columns for each lanthanide-actinide pair denote nonrelativistic orbital energies. The shifts in energy due to relativistic effects are evident in the relativistic orbital energies, displayed in the outer columns for each lanthanide-actinide pair (reprinted from ref 30; copyright 1978 Academic Press).

general classes of relativistic effects on electronic structure, both of which are greater for the actinides. The first effect is an increase in the orbital energies of the nf and (n+1)d orbitals relative to the (n+1)p and (n+2)s orbitals. These overall changes in the orbital energies are primarily due to "classical" relativistic effects, such as the relativistic mass correction for core electrons, that lead to greater shielding of the higher l-value orbitals. Because the 5f orbitals in actinides are more destabilized by relativistic effects than are the 4f orbitals of the lanthanides, the valence f electrons are more weakly bound, and hence more chemically active, in the former. As a result, a larger range of oxidation states is generally observed among the actinide elements than among the lanthanides.

The second relativistic effect is the splitting of subshells by spin-orbit coupling, which can be considered a "quantum" relativistic effect. The spin-orbit splitting generally decreases with increasing orbital energy; e.g. the (n + 1)p orbitals are split more than the nf orbitals. These two classes of relativistic effects are lucidly discussed in a review by Pitzer.<sup>31</sup>

Methods for including relativistic effects in molecular calculations can be separated into two broad classes. In the first approach to molecular relativistic effects, the Pauli Hamiltonian is employed. This Hamiltonian gives two-component wave functions (one spatial function and two spin components) that are bases for the representations of the familiar single groups used in nonrelativistic calculations. In most cases, only the mass-velocity and Darwin terms are included in the molecular orbital calculations, resulting in wave functions analogous to those obtained by nonrelativistic

#### MOLECULAR RELATIVISTIC QUANTUM CHEMISTRY

![](_page_3_Figure_3.jpeg)

Figure 2. Summary of the features and development of molecular relativistic quantum chemical methods, as described in further detail in the text.

methods. Spin-orbit corrections can then be added in a second step, through diagonalization of the spin-orbit operator (which is often empirically chosen) over the space of the Pauli Hamiltonian based MOs. Quasirelativistic multiple scattering and discrete variational methods, relativistic extended Hückel methods, and the Hay-Wadt-Kahn effective core potentials are examples of this type of approach.

In the second type of relativistic molecular electronic structure method, the full Dirac equation is solved, usually in the Dirac-Fock formalism analogous to nonrelativistic Hartree-Fock methods. Spin-orbit coupling is treated directly in this approach. Fourcomponent wave functions result from these calculations. The two small components, which are necessary for calculations involving electromagnetic field interactions, are often later omitted from the molecular wave functions. Because the electrons are subject to spinorbit coupling, the calculated orbitals are bases for representations of the less-familiar double groups, which can sometimes complicate interpretation of computational results. Dirac-Slater discrete variational and multiple scattering methods, the one-center expansion method of Pyykkö et al., and Pitzer's relativistic core potentials are included in this second group.

The various computational methods used for molecular electronic structure will now be described. These methods differ in the approximations employed in the evaluation of the electronic Hamiltonian as well as in the way relativistic corrections are included. As is generally the case in molecular calculations, the com-

putational expense increases with increasing quantum chemical rigor. The development and features of these approaches are briefly outlined below, roughly in order of increasing sophistication of the method. A summary of the methods is provided in Figure 2.

### A. Relativistic Extended Hückel Theory (REX)

Hückel theory, developed in the 1930's, is a oneelectron semiempirical approach to the treatment of  $\pi$ -electron systems. Wolfsberg and Helmholtz applied a modification of this treatment to inorganic compounds in 1952,77 which ultimately led to the wellknown extended Hückel theory (EHT) of Hoffmann in 1963.<sup>78</sup> Semiempirical implementations such as EHT often implicitly include relativistic effects through the use of experimentally derived parameters. Relativistic effects have also been explicitly addressed in the methods through the inclusion of spin-orbit corrections and parameters derived from Dirac-Fock atomic calculations. Manne introduced an approximate spinorbit correction to EHT in 1975.79 Lohr and Pyykkö introduced their relativistic extended Hückel (REX) method in 1979.13 In the REX approach, the assumptions of EHT are used with a full  $|lsjm\rangle$  AO basis and relativistic parameters derived from relativistic Dirac-Fock atomic calculations. 75 REX thus provides the least expensive means of obtaining a solution to the Dirac equation, albeit within a molecular orbital formalism that is highly approximate. The traditional REX approach involves minimal basis sets, but it has been

extended to include multiple-5 expansions.80

## B. Dirac-Fock One-Center Expansion (DF-OCE)

Like the Hartree-Fock equations, the Dirac equation is much easier to solve if all of the AOs share a common origin; the integrals are more easily calculated in spherical polar coordinates than in any of the other commonly used curvilinear systems. Thus, one-center expansion methods have been used in relativistic molecular calculations. The one-center expansion method was first applied to the numerical solution of the nonrelativistic Hartree-Fock equations by Albasiny and Cooper in 1963.81 Mackrodt extended this method to Dirac-Fock solutions for diatomic hydrides in 1970.<sup>14</sup> Although the DF-OCE approach in its current implementation is limited to hydride systems, it is the only current method that treats all electrons in a heavy-element compound with full nonlocal exchange and relativistic effects. Virtual orbitals on the central atom are used in lieu of hydrogen-based basis functions. These basis functions are influenced by relativistic effects from the heavy atom nucleus, while true hydrogen orbitals would display much smaller relativistic effects. The impact of this limitation in truncated one-center expansions has not been fully studied.

DF-OCE calculations provide a reliable total energy, and the method has been applied successfully to studies of relativistic effects on molecular geometries and bond energies. Molecular orbitals and force constants can also be obtained via the DF-OCE method.

#### C. Local Density Functional (LDF) Approach

Modern local density functional theory is based upon two important developments. The first is Slater's local exchange approximation, which was derived in 1951 from studies of the inhomogeneous electron gas.82 The second is the Hohenberg-Kohn theorem, published in 1964, which states that all information concerning the ground state of a molecular system can be determined from its charge density, even if the corresponding wave function is not known.83 The LDF equations for molecules are usually solved by two methods, the multiple-scattering  $X\alpha$  method (also known as the  $X\alpha$ scattered-wave or "muffin-tin" approach) introduced by Johnson in 1966, 10 and the various basis-set expansion methods stemming from the discrete variational (DV- $X\alpha$ ) approach<sup>11</sup> first applied to molecules by Baerends, Ellis, and Ros<sup>12</sup> in 1973. The replacement of the Hartree-Fock nonlocal exchange potential with Slater's local exchange (or a modification thereof) leads to what are often called the Hartree-Fock-Slater (HFS) equations. More complex exchange potentials, such as the Hedin-Lundqvist potential,84 have also been developed and modified to include the effects of relativity.85 Becke's recently published density functional, 86 which includes a nonlocal exchange correction, has yielded accurate predictions of transition-metal-ligand and metal-metal bond energies.

LDF calculations give one-electron energy levels (molecular orbital energies) that can be used in the interpretation of photoelectron spectra. Slater's transition state method<sup>87</sup> allows approximate evaluation of electronic transition energies, but explicit multiplet effects in excited states are not included in the calcu-

lations. Approximate potential energy curves may be based on total or binding energies in the DV-X $\alpha$  methods; these curves apply to an average of electronic states rather than to a specific spatial and spin state.

#### 1. Multiple-Scattering $X \alpha$ (MS- $X \alpha$ )

In the multiple-scattering method, the molecular volume is partitioned into spherical atomic regions, in which the potential is assumed to be spherically symmetric, and intersphere regions, in which the potential is assumed constant. This "muffin-tin" approximation results in exactly solvable SCF equations with no need for a basis set expansion. Multiple-scattering calculations are subject to inaccuracies arising from the muffin-tin approximation, but are known to provide reasonable molecular orbital energies, descriptions of bonding, and predictions of optical spectra at low computational cost. Relativistic effects are included through quasirelativistic corrections or full solution of the Dirac equations, as described below.

Quasirelativistic Multiple-Scattering (QR-MS). The Cowan-Griffin<sup>88</sup> approximate AO method has been used to develop quasirelativistic corrections to MS-X $\alpha$ calculations. In this procedure, the Pauli approximate Hamiltonian is applied, treating the mass-velocity and Darwin terms explicitly and including approximate spin-orbit corrections, albeit without explicit spin-orbit splitting. Koelling and Harmon reported such a procedure in 1977.<sup>17</sup> Their approach is nearly identical with that of Boring and Wood, 18-20 who report a factor of 4 improvement in computational speed relative to Dirac-Slater multiple-scattering calculations (described below), and with little degradation of results. A similar quasirelativistic approach was developed by Thornton et al. in 1979.21,22 QR-MS calculations yield one-electron, non-spin-orbit split MOs that can be compared directly to those obtained from nonrelativistic calculations. This approach has been the most popular one used to study large actinide systems, such as organoactinide complexes, as will be discussed later.

Dirac-Slater Multiple-Scattering (DS-MS). The most precise incorporation of relativistic effects in MS-Xα calculations involves solution of the full Dirac-Slater (Dirac-Fock with local exchange) equations. The first such calculations were performed by Yang and Rabii in 1975, 15 and the method has been critically discussed by Case and Yang. A second implementation of this method was described by Soldatov, 99 who claimed that his more accurate description of the core orbitals led to more accurate molecular orbital energies. Unlike the QR-MS approach, DS-MS calculations explicitly include spin-orbit coupling and yield complex, four-component MOs.

## 2. Basis Set LDF Methods

Various methods, all employing basis function expansions of one kind or another, have addressed the problem of solving the nonrelativistic Hartree–Fock–Slater equations without resorting to the muffin-tin approximation. In the local-exchange approximation, the exchange potential at a point  $\mathbf{r}$  is a functional of  $\rho(\mathbf{r})$ , where  $\rho$  is the electron density. In the most common implementations, the exchange potential is proportional to  $\rho(\mathbf{r})^{1/3}$ . This functional form for exchange makes it impossible to calculate the molecular

integrals analytically. Rather, numerical methods must be used. Ellis's discrete variational (DV) method,<sup>11</sup> introduced in 1968, couples expansion of the wave function and the potential in numerical or analytical atomic orbitals with a discrete numerical integration scheme for calculation of the molecular integrals. The integration may be subject to numerical errors, with an approximate accuracy limit of  $\pm 0.1$  eV in the molecular orbital energies.<sup>76</sup> Baerends et al. at the Free University, Amsterdam, employed analytical basis sets and updated these HFS methods to include more accurate integration schemes. 12,90 These methods provide reliable MOs and orbital energies that are useful for predicting ionization potentials and interpreting optical spectra. Both total energies and binding energies can be calculated, but binding energies are considered much more reliable.

Perturbative Hartree-Fock-Slater (P-HFS). In the late 1970's, Baerends et al. applied first-order perturbation theory to include relativistic effects in their HFS method, which uses analytical basis functions.<sup>23,24</sup> This approach is referred to as the perturbative Hartree-Fock-Slater (P-HFS) method. The perturbation expansion is based upon a truncated Foldy-Wouthuysen<sup>91</sup> transformation of the Dirac Hamiltonian, allowing separation of the large and small components of the wave function so that the wave function can be expressed in terms of a set of non-spin-orbit coupled spin orbitals analogous to the nonrelativistic case. The use of first-order perturbation theory results in the neglect of contributions to the total energy from relativistic changes in the valence electron density. These truncation effects are small for small Z, and the method has proved effective for predicting bond lengths and dissociation energies for elements up to Z = 80.92 Molecular orbital properties and binding energies can be obtained from P-HFS calculations.

Quasirelativistic Hartree–Fock–Slater (QR-HFS). Ziegler, Baerends, et al.  $^{25}$  have extended the P-HFS method to allow a more accurate treatment of relativistic effects beyond first order. In QR-HFS calculations, the first-order Foldy–Wouthuysen Hamiltonian described above is diagonalized in the space of zero-order solutions, incorporating higher-order corrections due to the first-order relativistic perturbation operator. Thus, the approach includes relativistic changes to the valence charge density, and can yield accurate binding energies for elements with Z > 80.

Dirac–Slater Discrete Variational (DS-DV). Rosén and Ellis showed in 1974 that the statistical exchange potential is valid for the Dirac–Fock equations. They were thus able to overlay the DV-X $\alpha$  method with a full Dirac–Fock relativistic treatment, yielding Dirac–Slater equations that were analogous to the nonrelativistic Hartree–Fock–Slater formalism. The DS-DV approach makes full solution of the Dirac–Fock equations possible, so that relativistic effects can be incorporated without any further approximation beyond that of local exchange; all relativistic effects, including spin–orbit coupling, are explicitly calculated.

#### D. Ab Initio Effective Core Potentials (ECP)

A major hindrance to the application of traditional ab initio methodologies to heavy-element chemistry is the large number of electrons involved. The size of a Hartree–Fock–Roothaan basis set expansion calculation scales as N<sup>4</sup>, where N is the number of basis functions. Obviously, the inclusion of one actinide atom in a molecule can lead to a prohibitively large calculation, especially if an extended basis set is employed. For example, a calculation on a U atom would require approximately 10000 times as many two-electron integrals as for a C atom with the same quality of basis set!

The most common solution to this problem is the effective core potential (ECP) approach, in which an additional potential energy term in the Hamiltonian replaces the core electrons in a molecular calculation. The numerical ECP is calculated through inverting the results of an accurate all-electron atomic calculation. The ECP becomes an additional one-electron term in the molecular Hamiltonian, so that a single extra set of one-electron integrals over valence molecular basis functions is the only additional requirement for solution of the traditional ab initio equations, at the SCF level or with electron correlation included. The numerical ECP is often fit to a linear combination of Gaussian functions to facilitate computation of the necessary one-electron integrals. Computation of these integrals represents only a small fraction of the total computational time, due to the overwhelming expense for evaluation of the valence two-electron integrals. In contrast, all-electron calculations would involve many additional two-electron integrals due to the core electrons, incurring much greater computational expense than in ECP calculations.

An excellent description of the early history of ECP methods is provided in the review by Krauss and Stevens<sup>34</sup> and references therein. The wide variety of relativistic ECP implementations has been recently reviewed by Balasubramanian and Pitzer.<sup>36</sup> Here we summarize the key milestones in this development.

Effective core potentials were first applied to quantum chemical calculations by Gombas and Hellmann in 1935, in studies of alkali metal atoms and diatomics. In 1959, Phillips and Kleinman demonstrated that ECPs could be used to obtain accurate atomic orbital energies. In 1968, Weeks and Rice generalized the Phillips-Kleinman procedure to include systems with many valence electrons. That same year, Goddard proposed a method for calculating nonorthogonal core potentials developed from smooth, nodeless atomic orbitals. Improvements in the pseudo-orbitals from which the ECPs are derived were offered by Christiansen et al. 197 and Hay. 198

In their 1976 study of HgH, Das and Wahl conducted the first relativistic core potential calculation that included configuration interaction (CI) and spin-orbit effects in a molecule.26 Relativistic core potentials (RCPs) are obtained by using relativistic all-electron atomic calculations as the starting point for the ECP procedure described above. The utility of using RCPs in molecular calculations is 2-fold. First, because relativistic effects are especially pronounced for core electrons, the use of RCPs leads to more accurate treatment of core electrons than in nonrelativistic allelectron approaches. Second, the number of electrons treated explicitly in the calculations is reduced dramatically, making molecular calculations with extended basis sets feasible for actinide systems. Thus, the use of RCPs leads to an increase in accuracy with a reduction in cost, a truly rare occurrence in computational science!

The two RCP approaches most often applied to chemical systems are briefly described below. A third relativistic model potential method, derived by Schwarz, has been applied in multireference CI calculations, but to our knowledge this method has not been used in computations on actinide systems. The two RCP approaches are distinguished in two ways. First, the atomic calculations from which the RCPs are derived may be based on the Pauli approximation or on the full Dirac Hamiltonian. Second, spin-orbit effects are incorporated by using either a perturbation theory approach with an approximate spin-orbit operator or via spin-orbit CI with use of an ab initio spin-orbit operator derived in tandem with the RCP.

## 1. Kahn-Hay-Cowan Relativistic Core Potentials

In 1978, Kahn, Hay, and Cowan<sup>27</sup> developed relativistic core potentials based on the Cowan-Griffin<sup>88</sup> approximate method for calculating relativistic atomic orbitals. In Cowan-Griffin calculations, the Hamiltonian includes the Darwin and mass-velocity terms from the Pauli approximation, but omits spin-orbit effects. Thus, the atomic calculation involves two-component wave functions rather than the Dirac four-component functions and can therefore easily be adapted to traditional electronic structure computer programs. The RCPs obtained by this method have been applied with success to many transition-metal systems, as well as to actinides, and further details of the method are given in application papers. 100,101 A complete set of core potentials and Gaussian basis sets for the main-group elements and transition metals has been published by Wadt and Hav. 102

In Hay-Kahn-Cowan RCP calculations, spin-orbit effects are treated by perturbation theory after the wave function has been determined. The principal limitation of this approach is its inability to provide an ab initio spin-orbit operator that could be applied in MCSCF or CI calculations. This limitation is addressed by the second RCP procedure described below.

#### 2. Pitzer Relativistic Core Potentials

In 1977, Lee, Ermler, and K. Pitzer developed a different formulation of relativistic core potentials.<sup>28</sup> The theoretical basis for their approach has been described in detail in a review by Pitzer.<sup>33</sup> In contrast to the Kahn-Hay-Cowan approach, these RCPs are derived from all-electron numerical Dirac-Fock atomic calculations, yielding ab initio spin-orbit operators in addition to the RCPs. Spin-orbit effects are included from the beginning in the atomic calculations, and full four-component atomic wave functions are obtained. The small components, which have negligible effect in the valence region, are omitted in deriving the core potential, resulting in two-component j-dependent RCPs. Christiansen, Lee, and Pitzer developed an improvement to the Phillips-Kleinman ECP formalism, which provides for balanced electron populations between core and valence; these improved potentials are referred to as "shape-consistent" or "norm-conserving."97 An l-dependent molecular core potential can be obtained as an average of the two j components of the original RCP. Alternatively,  $\omega - \omega$  coupling (j-dependent) may be used in two-component SCF and multiconfiguration SCF (MCSCF) calculations, as described in 1980 by Lee<sup>103</sup> and Christiansen,<sup>104</sup> respectively. A full set of lanthanide and actinide RCPs using the Pitzer approach has recently been developed.<sup>105</sup>

Nonempirical spin-orbit operators under the Pitzer formalism were derived by Ermler in 1981.<sup>106</sup> These operators make ab initio spin-orbit CI calculations possible. The expression of the spin-orbit operator was simplified by R. Pitzer and Winter,<sup>107</sup> facilitating the development of spin-orbit CI computer codes. Their use of double group symmetry results in a block diagonal Hamiltonian matrix; with sufficient spatial symmetry properties, the elements of this Hamiltonian matrix are all real. Their resulting spin-orbit CI computer codes have been used in the recent definitive uranocene studies of Chang and Pitzer.<sup>108</sup>

At present, the RCP method is the only ab initio approach that can be applied routinely to heavy-atom molecules. Core potentials are used in Hartree-Fock (SCF) calculations, which provide molecular orbitals, MO energies, and MO populations, as well as total electronic energies. Electron correlation effects may be included through MCSCF or CI calculations. The variational principle holds for these methods, so that the accuracy of the total energies can be assessed easily. Ab initio calculations give reliable potential energy surfaces, enabling prediction of molecular geometries and reaction dynamics. In contrast to the LDF methods, spin states are treated explicitly, allowing studies of excited states and interpretation of electronic spectra. However, application of the more sophisticated correlation treatments comes at the expense of ease of interpretation of the wave function. Thus, we believe that a combination of LDF and ab initio calculations is presently the best approach to study actinide systems.

We note here that relativistic all-electron ab initio calculations on heavy-atom molecules are not utterly beyond current computational capabilities. Lee and McLean have published results of relativistic Dirac-Hartree–Fock calculations on AgH and AuH, perhaps the largest ab initio LCAO-MO SCF calculations to date. 109

#### III. Actinide Hydrides

We now begin our survey of the applications of the above methodologies with a discussion of the actinide hydrides, which are the simplest actinide-containing molecules. These molecules provide a useful means of gauging the roles of relativistic effects and f-orbital covalency in molecular bonding. The hydrides have also been used as models for actinide halides, such as UF<sub>6</sub>, and to model the charge-transfer behavior of small actinide systems.<sup>110</sup>

As mentioned earlier, the actinide hydrides are amenable to study by the DF-OCE method, as demonstrated by Pyykkö and co-workers. 111-113 These investigations have focused on relativistic effects on molecular structure, and, in particular, on the use of calculated molecular bond lengths to predict and analyze the atomic lanthanide and actinide contractions. These calculations have also provided insight into the role of f electrons in actinides as compared to lanthanide systems. The results of Pyykkö's calculations on the actinide contraction, given in Table I, are in general

TABLE I. DF-OCE Estimates of the Actinide Contraction

| difference in M–H bond length       | contraction, Å | ref |  |
|-------------------------------------|----------------|-----|--|
| ThH4 - [104]H4                      | 0.302          | 111 |  |
| $UH_6 - [106]H_8$                   | 0.295          | 111 |  |
| RaH+ - NoH+                         | 0.382          | 112 |  |
| RaH <sub>2</sub> - NoH <sub>2</sub> | 0.426          | 112 |  |
| AcH - LrH                           | 0.330          | 113 |  |

agreement with the experimental observation of 0.02 Å/element<sup>114</sup> for the reduction in atomic size across the actinide series of elements. By comparing relativistic and nonrelativistic results, Pyykkö has shown that the lanthanide contraction is primarily an orbital shielding effect rather than a relativistic one, while the actinide contraction results from some relativistic effects. Further, hybridization involving the 5f orbitals in the ThH<sub>4</sub> and UH<sub>6</sub> calculations results in a dramatic decrease in bond length, while the analogous 4f hybridization has little influence on the bond lengths calculated for the lanthanide systems. 111 Pyykkö interprets these results as an indication of the increased importance of f-orbital interactions in actinides as compared with lanthanides. It is interesting to note that the full set of "pre-supercomputer" hydride calculations (roughly 20 molecules, with 5 energy points each) required about 9500 hours of CPU time on a UNIVAC 1108 or 1100/20 computer, as well as 400 hours on aDEC 10 computer. 111-113

Krauss and Stevens<sup>110</sup> have reported ab initio studies of UH, UF, UH-, UF-, and UH+, applying Pitzer's RCP approach in SCF calculations. They have also included minimal correlation effects through MCSCF calculations, using the smallest number of configurations necessary for an accurate description of bond dissociation. These studies show charge transfer from the U 7s to the H 1s or F 2p orbitals at a bond length of about 6.75 au, as evidenced by orbital character and change in dipole moment. The 6p, 6d, and 5f uranium atomic orbitals influence the electronic structure and geometry of the molecules via large ionic and electrostatic interactions, but they do not participate in bond formation. This description of the valence  $\sigma$  orbital behavior parallels that observed in group II ionic hydrides and halides. The analogy between uranium and alkaline earth chemistry is further supported by the remarkable similarity between the observed spectroscopic constants  $(R_e, \omega_e, \text{ and } \omega_e x_e)$  for SrH and SrF and those calculated for UH and UF.110

## IV. Actinide Halides

The chemistry of actinide halides has been extensively studied. UF<sub>6</sub>, as the only known uranium compound with a large vapor pressure at room temperature, is essential to the gaseous diffusion cascade process for separation of uranium isotopes. It is also a promising candidate for laser-induced isotope enrichment, in which isotopic shifts of excitation energies are exploited for separation of isotopes. Clearly, the optical properties of UF<sub>6</sub> are of critical interest in developing these separation methods. Uranium is recovered from spent nuclear fuel or ore in the form of hexavalent aqueous uranyl ions or solid oxides. These are converted to U metal for use as nuclear fuel or to UF<sub>6</sub> for isotopic enrichment via the tetrafluoride intermediate. The tetra-

TABLE II. Calculated 5f Populations and Metal Charges for UF.

| author   | year | ref | method          | 5f<br>population | U charge |
|----------|------|-----|-----------------|------------------|----------|
| Pyykkö   | 1981 | 122 | REX             | 2.29             |          |
| Boring   | 1978 | 116 | $NR-MS-X\alpha$ | 3.71             | +1.59    |
| Boring   | 1979 | 20  | QR-MS           | 2.33             |          |
| Koelling | 1976 | 119 | DS-DV           | 2.75             | +1.70    |
| Kim      | 1977 | 120 | NR-DV           | 3.35             | +1.25    |
|          |      |     | DS-DV           | 1.76             | +2.72    |
| Rosén    | 1978 | 121 | NR-DV           | 3.20             | +1.55    |
|          |      |     | DS-DV           | 2.75             | +1.70    |
| Hay      | 1983 | 127 | RCP             | 1.67             | +2.40    |

and penta-fluorides are also likely products of laserisotope separation experiments, and their optical properties are of interest to chemists. Computational studies have been useful in predicting or interpreting the optical spectra of these compounds.

Computational studies spanning the entire range of nonrelativistic and relativistic methods have been carried out for actinide hexahalides. Boring et al. 115,116 employed the nonrelativistic MS-X $\alpha$  method in molecular orbital calculations for the compounds  $MF_6$  (M = U, Np, Pu). These calculations yielded one-electron energies and bond-length estimates. Nonrelativistic  $MS-X\alpha$  calculations were also performed by Maylotte et al., who compared the electronic structures of UF<sub>6</sub> and UF<sub>5</sub>, 117 and by Schneider et al., in studies of the interaction potentials of the UF<sub>6</sub>-UF<sub>6</sub> and UF<sub>6</sub>-rare gas atom complexes. 118 After their development of a QR-MS approach, Boring and Wood applied this method to UF<sub>6</sub> and compared the results to nonrelativistic and other relativistic LDF approaches.20 DS-MS calculations on UF<sub>6</sub> were conducted by Case and Yang<sup>76</sup> and by Soldatov.<sup>89</sup> The DS-DV method was applied to UF<sub>6</sub> by Koelling, Ellis, and Bartlett<sup>119</sup> and by Kim et al. <sup>120</sup> Rosen compared these results to those of nonrelativistic approaches. 121 UF<sub>6</sub> served as a test case for the REX approach, 122 and the REX method has been exploited in the interpretation of actinide hexafluoride photoelectron spectra<sup>123,124</sup> and nuclear spin coupling constants. 125 Hay's definitive ab initio RCP calculations on UF<sub>6</sub> provide a benchmark for the evaluation of other methods. 126,127

The electronic structure of UF<sub>6</sub> is not particularly complex, but the wealth of experimental and spectroscopic data have made it a prototype for the testing of computational methods for actinide systems. The simplest model for UF<sub>6</sub>, provided by crystal-field theory, is displayed in Figure 3. In this model, UF<sub>6</sub> is considered as a completely ionic (U<sup>6+</sup>,F<sup>-</sup>) 5f<sup>0</sup> complex in which the highest occupied molecular orbitals are essentially F 2p, and the lowest unoccupied orbitals are primarily metal 5f. In this simple model, the lowest-energy optical transitions are simple ligand-to-metal charge transfer excitations. The effects of f-orbital covalency are evident in the one-electron energies and molecular orbital characters, as will be presented in the following paragraphs.

The participation of 5f orbitals in the bonding in  $UF_6$  can be evaluated through MO population analysis and overall metal charge estimates. The results from several computational models with respect to these quantities are compared in Table II. It is clear that nonrelativistic calculations, which yield low 5f orbital energies, overestimate the 5f orbital contributions to the occupied

![](_page_8_Figure_3.jpeg)

Figure 3. Schematic diagram of the highest occupied and lowest unoccupied orbitals of  $UF_6$ . The molecular orbitals prior to spin-orbit coupling are depicted on the far left and right sides of the figure. The relative energies of the molecular orbitals are given in the center. The orbital energies in the absence of spin-orbit splitting are depicted on the left and are labeled as irreducible representations of the  $O_h$  point group. Spin-orbit splitting effects are shown on the right, and the resulting MOs are labeled as representations of the  $O_h$  double point group. The numbers in parentheses above the spin-orbit split MOs indicate the spin-orbital degeneracies (reprinted from ref 33; copyright 1983 Plenum Press).

MOs. The various computational methods represented in Table II give a wide range of metal charge estimates, but it is clear from all calculations that the purely ionic model is an inadequate description of UF<sub>6</sub>. A basis set study by Koelling, et al. 119 tested the crystal-field approximation further. They performed calculations on NpF<sub>6</sub> using both a pure ionic (Np<sup>6+</sup>,F<sup>-</sup>) basis and a neutral atomic basis. The calculations using the purely ionic basis gave a calculated ionicity corresponding to Np4+, in disagreement with the initial assumption of Np6+, and a 5f orbital population of 2.2 as opposed to the population of 1.0 predicted by the ionic 5f<sup>1</sup> configuration. This disagreement with the ionic ansatz is evidence for significant covalent contributions to the bonding in the hexafluorides.

A comparison of the MO energies gives an indication of the importance of relativistic effects in studies of UF<sub>6</sub>. Boring et al. 116 have asserted that relativistic effects in molecules are much smaller than those observed in atoms. Their reasoning involves two arguments. First. the experimental spectra show charge transfer bands in  $UF_6$  at around 3 eV. 128 The authors contend that if the 5f orbitals in the molecule were shifted upward relative to the 6s and 6p orbitals in a magnitude similar to that observed in the atoms, then the charge-transfer bands would be observed at a much higher energy, 10-12 eV. Second, their nonrelativistic results were qualitatively similar to the relativistic ones of Koelling et al.,119 who also observed no large f-orbital energy shift.

![](_page_8_Figure_7.jpeg)

Figure 4. Molecular orbital energies for UF<sub>6</sub> from nonrelativistic and relativistic calculations. Methods include nonrelativistic multiple-scattering (NR-MS)<sup>115</sup> and discrete variational (NR- $\mathrm{DV})^{121}$  X $\alpha$ , relativistic core potential ab initio (RCP),  $\mathrm{^{127}}$  relativistic extended Hückel (REX),  $\mathrm{^{122}}$  quasirelativistic multiple-scattering (QR-MS-SO),  $\mathrm{^{20}}$  and Dirac–Slater discrete variational (DS-DV).  $\mathrm{^{119}}$  The QR-MS-SO and DS-DV calculations include the effects of spin-orbit splitting, and the MOs are thus labeled as representations of the  $O_h$  double point group. The remaining calculations do not include spin-orbit effects, and the MOs are labeled as representations of the  $O_h$  point group. See Figure 3 for a qualitative description of orbital interactions in UF<sub>6</sub>.

In spite of these results, the need for a relativistic treatment of UF<sub>6</sub> was asserted by Case, among many others. 76 Case states that large atomic orbital shifts have a marked effect on the gap between occupied and unoccupied molecular orbitals, and consequently a large effect on the optical spectrum. Second, he cites large spin-orbit effects that dominate the optical spectrum and are evident in the photoelectron (PE) spectra. The first peak in the PE spectrum for UF<sub>6</sub> is identified as one component of the 4t<sub>1u</sub> orbital; the other spin-orbit component of this orbital lies about 1.2 eV lower in energy and contributes to the second ionization band. 129

A comparison of nonrelativistic and relativistic oneelectron energies for  $UF_6$ , obtained from a variety of methods, is displayed in Figure 4. These data confirm the need for relativistic treatments in order to obtain quantitative results, but they also show that nonrelativistic calculations can provide a qualitative understanding of the bonding in the molecule. Figure 4 also provides a direct comparison of ab initio RCP calculations 126,127 and relativistic and nonrelativistic LDF calculations. The relativistic LDF methods yield results that are quite similar to the ab initio calculations, and the results of both of these approaches correlate well with the optical spectrum of UF<sub>6</sub>, as we shall now dis-

In 1983, Hay used ab initio methods to predict the excited-state energies and optical transitions for UF<sub>6</sub>. 127

TABLE III. Comparison of Calculated Excitation Energies (eV) for UF4, in eV

| primary<br>orbital excitation                                                                                                                                                                                                   | DS-DV<br>one-electron energies <sup>119</sup> | QR-MS<br>one-electron energies <sup>20</sup> | RCP<br>range of<br>many-electron energies <sup>127</sup> |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------|----------------------------------------------|----------------------------------------------------------|
| $\begin{array}{c} 2t_{1u}(8u) \rightarrow a_{2u}(7u) \\ 2t_{1u}(8u) \rightarrow 2t_{2u}(8u,7u) \\ 2t_{1u}(8u) \rightarrow 3t_{1u}(8u,6u) \end{array}$                                                                           | 2.78                                          | 3.34                                         | 3.41-3.55                                                |
|                                                                                                                                                                                                                                 | 3.72, 3.94                                    | 4.08, 4.16                                   | 4.01-4.56                                                |
|                                                                                                                                                                                                                                 | 5.22, 5.38                                    | 5.57, 5.42                                   | 5.24-6.02                                                |
| $\begin{array}{ll} 2t_{1u}(6u) & \rightarrow a_{2u}(7u) \\ 2t_{1u}(6u) & \rightarrow 2t_{2u}(8u,7u) \\ 2t_{1u}(6u) & \rightarrow 2t_{1u}(8u,6u) \end{array}$                                                                    | 4.02                                          | 4.55                                         | 5.83-5.97                                                |
|                                                                                                                                                                                                                                 | 4.87, 5.02                                    | 5.29, 5.37                                   | 6.51-7.05                                                |
|                                                                                                                                                                                                                                 | 6.30                                          | 6.78, 6.63                                   | 7.70-7.77                                                |
| $\begin{array}{l} t_{1g}(8g,6g) \to a_{2u}(7u) \\ t_{1g}(8g,6g) \to 2t_{2u}(8u,7u) \\ t_{1g}(8g,6g) \to 3t_{1u}(8u,6u) \end{array}$                                                                                             | 4.05, 4.08                                    | 4.53, 4.56                                   | 5.37-5.39                                                |
|                                                                                                                                                                                                                                 | 4.89, 5.07                                    | 5.14-5.32                                    | 5. <del>96-6.40(C)</del> a                               |
|                                                                                                                                                                                                                                 | 6.31–6.46(C) <sup>a</sup>                     | 6.61-6.79                                    | 7.05-7.65                                                |
| $\begin{array}{l} \mathbf{a_{1g}(6g)} \to \mathbf{a_{2u}}(7\mathbf{u}) \\ \mathbf{a_{1g}(6g)} \to 2\mathbf{t_{2u}}(8\mathbf{u}, 7\mathbf{u}) \\ \mathbf{a_{1g}(6g)} \to 3\mathbf{t_{1u}}(8\mathbf{u}, 6\mathbf{u}) \end{array}$ |                                               | 5.18<br>5.89( <i>C</i> ), <sup>a</sup> 5.97  | 6.12-6.16<br>6.80-7.08<br>7.85-8.75                      |
| $t_{2u}(8u,7u) \rightarrow a_{2u}(7u)$<br>$t_{2u}(8u,7u) \rightarrow 2t_{2u}(8u,7u)$<br>$t_{2u}(8u,7u) \rightarrow 3t_{1u}(8u,6u)$                                                                                              |                                               | 5.25, 5.26<br>5.98–6.15                      | 6.24-6.38<br>6.78-7.86<br>7.95-8.74                      |

The predicted energy of the first intense band in the electronic excitation spectrum is denoted by C.

These were among the first relativistic calculations on a polyatomic system that included both spin-orbit splitting and electron-electron interactions, yielding multiplet energies. A relativistic core potential replaced the 90 core electrons, leaving 56 valence electrons to be treated explicitly by restricted Hartree-Fock (RHF) and CI methods. The CI expansions were constructed by single or double excitations from the 18 highest occupied valence orbitals in a Alg closed-shell state into the 7 lowest virtual orbitals. The charge-transfer excitations from 36 F 2p spin-orbitals into 14 U 5f spin-orbitals led to 504 possible electronic states. Spin-orbit effects were incorporated through diagonalization of the resulting 504 × 504 spin-orbit matrix over the CI wave functions, partitioned into  $252 \times 252$  g and u blocks, giving 504 electronic states spanning an energy range of 3-10 eV. In contrast, LDF predictions of optical transitions are based on one-electron energies and give an approximate energy for configurations arising from a particular occupied-to-virtual excitation, precluding the identification of particular spin-coupled states.

In Table III, Hay's excited-state transition energies are compared to those from DS-DV<sup>119</sup> and QR-MS<sup>20</sup>  $X\alpha$ transition state calculations for the 3-7 eV transitions in UF<sub>6</sub>. The higher-energy (7-10 eV) states treated by Hay were not addressed by the LDF calculations. Qualitative similarities in the results include the relative energetic ordering of the virtual orbitals and the prediction that the lowest-energy excited states arise from exciting electrons from the  $2t_{1u}$  MO to the  $a_{2u}$  and  $2t_{2u}$ orbitals. A quantitative comparison of the methods is hindered by the fact the single-orbital excitation energies calculated by LDF methods correspond to spinspecific excited states spanning a 0.5-eV range in energy. Differences of 1 eV or more are evident where comparisons are possible, and these differences lead to discrepancies in the assignment of the first intense band in the spectrum (denoted by C in the table).

In studies of other actinide hexahalides, Thornton has interpreted the photoelectron spectrum of UCl<sub>6</sub> using QR-MS calculations.<sup>21</sup> Ligand field splitting effects and 5f-5f transition energies in  $5f^1$  hexahalide complexes were studied by QR-MS calculations on  $PaX_6^{2-}$ ,  $UX_6^{-}$  (X = F, Cl, Br, I), and NpF<sub>6</sub>. NpF<sub>6</sub> was found to be the most covalent of the hexahalide series, but, even in this

case, ionic effects appeared to dominate the f-orbital ligand-field splittings. Significant covalent effects in the bonding in  $UF_6^-$  were observed in nonrelativistic MS-X $\alpha$  calculations. <sup>130</sup>

Wadt used ab initio RCP calculations, including CI and spin-orbit effects, to study the low-lying  $5f \rightarrow 5f$  excitations in  $PuF_6$ , which is formally a  $5f^2$  complex. <sup>131</sup> He found remarkable agreement between these highly accurate calculations and semiempirical ligand field (LF) calculations by Kugel et al. <sup>132</sup> The agreement between the calculated transition energies and the observed matrix spectra was quite good, with an average difference of less than  $600 \text{ cm}^{-1}$  between calculated and experimental energies for the nine lowest transitions. Somewhat surprisingly, both the ab initio and LF calculations lead to similar errors: when the discrepancy between calculated and experimental energies is large, the two very different computational methods yield nearly identical results!

The geometry and electronic structure of UF<sub>5</sub> has also been studied by Wadt and Hay in SCF calculations using relativistic core potentials. The equilibrium geometry in the absence of spin-orbit effects was found to be square-pyramidal  $(C_{4v})$ , while spin-orbit interactions led to a  $D_{3h}$  trigonal-bipyramidal structure. The two structures differ in energy by less than 1 kcal/mol and are connected by a monotonic  $C_{2\nu}$  pathway, so that UF<sub>5</sub> is predicted to be a fluxional system. The effect of this fluxional behavior on the bonding and photochemistry of UF<sub>5</sub> has been discussed at length by Wadt and Hay, 133 with the important conclusion that the fluctuations in geometry, particularly in the gas phase, will lead to a complicated IR spectrum. The orbital energies calculated by Wadt were in good agreement with those of Rosen and Fricke, 134 who used the DS-DV method and assumed a  $C_{4\nu}$  geometry. However, the abinitio calculations indicated considerably lower energies for all transitions. This discrepancy is similar to that found for  ${\rm UF_6}^{-,126}$  in which ab initio calculations gave better agreement with experimental spectra than did the LDF method.

Actinide tetrafluorides have also been studied extensively by quantum chemists. Nonrelativistic MS-X $\alpha$  calculations provided a qualitative interpretation of the He I PE spectra of UF<sub>4</sub>, UCl<sub>4</sub>, ThF<sub>4</sub>, and ThCl<sub>4</sub>. <sup>135</sup> The

photoelectron spectra and f-orbital covalency of MF<sub>4</sub> complexes, (M = Th, U, Np, Pu) were interpreted by Ellis et al. 136 using the DS-DV method. Strong covalent interactions of the metal 5f, 6d, 7s, and 7p orbitals with the F 2p band were found, with 5f populations of 0.4-1.1 above the purely ionic limit. Ellis noted the possibility that the self-consistent charge truncation of the Coulomb potential may have caused an overestimation of covalency; errors in the self-consistent charge model also lead to discrepancies of about 3 eV in the predicted vs observed ionization energies. Ellis and Holland extended these studies to the tetrachlorides of U. Np. and Pu,<sup>137</sup> finding significantly lower ionicity than predicted by the crystal field U<sup>4+</sup> (5f<sup>2</sup>6d<sup>0</sup>7s<sup>0</sup>) model. This lowered ionicity was partially explained by f-orbital covalency, but also arises due to the diffuse nature of the ligand valence orbitals, which can overlap with those on the metal center. 137

On the basis of QR-MS calculations, Topol' et al. questioned the high UF<sub>4</sub> covalency proposed by Ellis. <sup>138</sup> The diffuse valence atomic orbitals in Ellis's calculations are localized in spherical potential energy wells, which tend to push the 7p orbitals too close to the nucleus, artificially increasing the 7p population. An added consequence of the high 7p population is an increase in nuclear shielding, which destabilizes the 5f orbitals, leading to increased hybridization of the 5f with the 7s and 7p orbitals. Alternative DV basis sets, such as those used by the Dutch HFS approaches (P-HFS, QR-HFS) circumvent these problems.

The P-HFS and QR-HFS methods have been used in studies of actinide tetrahalides by Boerrigter<sup>139,140</sup> and Ziegler.<sup>25</sup> Boerrigter found good agreement between the calculated and experimental ionization energies for UCl<sub>4</sub> and ThCl<sub>4</sub>, but poor correlation with those of UF<sub>4</sub> and ThF<sub>4</sub>. The errors observed in the tetrafluorides were attributed to configuration interaction effects, a notion that has not been explored via RCP calculations. Ziegler focused on the calculation of binding energies in MX<sub>4</sub> (M = Th, U; X = F, Cl, Br, I) and Cl<sub>3</sub>MR (M = Th, U; R = H, CH<sub>3</sub>).<sup>25</sup> He found excellent agreement with experiment provided the quasirelativistic correction beyond first-order perturbation theory was applied.

Finally, electron paramagnetic resonance properties can be predicted by DS-MS calculations. This method has been applied in calculations on NpF<sub>6</sub><sup>141</sup> and PaCl<sub>6</sub><sup>2-</sup>. Nuclear spin-spin coupling constants for UF<sub>6</sub> have been estimated by use of the REX method. <sup>125</sup>

#### V. Actinide Oxides

Uranium oxides are the oldest known actinide-containing materials. Klaproth's studies of uranyl salts in 1789 resulted in isolation of brown UO<sub>2</sub> solid, which was thought to be a semimetallic element until the isolation of uranium metal in 1841. Brewster studied uranyl fluorescence in 1833, and recorded emission bands in the yellow region. The absorption bands in uranyl are found in the blue, and the shift between absorption and emission maxima led to the proposal of Stoke's law in 1852.<sup>42</sup> Uranyl salts also played a role in the discovery of radioactivity by Henri Becquerel. Uranyl ion is identifiable in solid uranium ore and is thus important for nuclear fuel and isotopic enrichment technology. The uranyl ion exhibits a complex series of excited electronic states, which leads to interesting fluorescence

TABLE IV. Calculated MO Energies (eV) for UO22+

|   |        |      |     |        | - ,             | •                  |      |                       |   |
|---|--------|------|-----|--------|-----------------|--------------------|------|-----------------------|---|
| _ | author | year | ref | method | $\sigma_{ m u}$ | $\pi_{\mathrm{u}}$ | π,   | $\sigma_{\mathbf{g}}$ | _ |
| _ | Pyykkö | 1981 | 122 | REX    | 10              | 12                 | 13   | 13                    | _ |
|   | Boring | 1979 | 18  | QR-MS  | 23.1            | 23.6               | 23.5 | 24.9                  |   |
|   | Wood   | 1981 | 149 | QR-MS  | 23.0            | 23.3               | 23.2 | 24.6                  |   |
|   | Yang   | 1978 | 150 | DS-MS  | 26.5            | 25.6               | 24.6 | 26.3                  |   |
|   | Walch  | 1976 | 152 | DS-DV  | 22.5            | 25.3               | 24.5 | 23.5                  |   |
|   | Wadt   | 1981 | 153 | RCP    | 29.5            | 29.4               | 29.5 | 28.7                  |   |
|   |        |      |     |        |                 |                    |      |                       |   |

chemistry. A comprehensive discussion of actinyl photophysics has been presented by Jørgensen and Reisfeld.<sup>46</sup>

In this section, we focus on the electronic structure of actinyl molecules and ions. Three questions are of primary interest to actinide chemists: (1) What is the extent of f-orbital covalency in actinyl systems? (2) Can computational results assist in the interpretation of the optical spectra of actinyls? (3) Why is uranyl ion linear whereas other actinyls, such as ThO<sub>2</sub>, are bent? We shall also summarize computations on other actinide oxide systems.

Considering that it is a rather simple linear triatomic ion, the  $\mathrm{UO_2^{2^+}}$  ion has been the focus of a great deal of contentiousness among both computational and experimental chemists. As with UF<sub>6</sub>, a wide variety of computational methods have been used to study the electronic structure of the uranyl ion. The importance of relativistic effects in the bonding in uranyl ion was recognized as early as 1965,  $^{143}$  and all of the theoretical methods used to study  $\mathrm{UO_2^{2^+}}$  over the last 20 years have included explicit or implicit relativistic corrections. (Nonrelativistic MO calculations were reported by McGlynn and Smith in 1961.  $^{144}$ ) We will first address the debate over 5f contributions to the U–O bonds in  $\mathrm{UO_2^{2^+}}$ , a straightforward question that has polarized many in the field of actinide electronic structure.

The question of 5f covalency in actinide systems is not a new one. Chemical evidence for f-orbital covalency was provided by Glueckauf and McKay in 1950, 50 but was contested soon after by Katzin. 51,52 In 1953, Elliott used a model involving 5f interactions to explain the temperature dependence of paramagnetism in NpO<sub>2</sub><sup>2+</sup> and PuO<sub>2</sub><sup>2+</sup>. <sup>145</sup> In 1955, Eisenstein advanced group theoretical arguments in favor of 5f covalency in uranyl and other actinide compounds. Shortly thereafter, Coulson and Lester concluded that f-orbital interactions (surprisingly, they chose the 6f orbitals) must contribute to sexicovalent bonding, but that ionic interactions are probably dominant. Horizontal and actinide ions and attributed the observed differences to significant 5f interactions in the actinides.

There has been surprisingly little agreement among quantum chemists concerning the 5f contributions to and the energetic ordering of the highest occupied orbitals in  $\mathrm{UO_2}^{2+}$ . A qualitative MO diagram of  $\mathrm{UO_2}^{2+}$  is presented in Figure 5. The results of all of the methods applied to  $\mathrm{UO_2}^{2+}$  agree with the qualitative description that the highest occupied orbitals comprise a set of  $\sigma_g$ ,  $\sigma_u$ ,  $\pi_g$ , and  $\pi_u$  MOs, followed by low-lying 5f virtual orbitals. The quantitative results differ dramatically, however. Examples of MO energies from REX, <sup>122</sup> QR-MS, <sup>18,148,149</sup> DS-MS, <sup>150</sup> DS-DV, <sup>151,152</sup> and RCP<sup>153</sup> calculations are given in Table IV. In bemoaning the lack of quantitative agreement, Jørgensen went so far as to compare the discrepancy among the

![](_page_11_Figure_2.jpeg)

Figure 5. Schematic diagram of the bonding MO interactions in  $UO_2^{2+}$ , showing the interactions of the U 6d and 5f atomic orbitals with the oxygen 2s and 2p orbitals. Participation of the U 6p orbital in the  $\sigma_u$  bonding MO may account for its position as the HOMO.

results to the "effect of throwing dice." Most methods predict a  $\sigma_u$  HOMO, with the exceptions of the non-relativistic HFS calculations of DeKock et al., <sup>154</sup> the DS-MS calculations of Yang et al., <sup>150</sup> and the ab initio RCP calculations of Wadt. <sup>153</sup>

The proposal of a  $\sigma_u$  HOMO for  $UO_2^{2+}$  is initially surprising in light of the allowed interaction of the  $\sigma_{\rm u}$ O-based combination with the U 5f  $\sigma_{u}$  orbital. This interaction should be energetically favored over those of  $\sigma_g$  and  $\pi_g$  symmetry, which must involve the higher-energy U 6d and 7s orbitals, and is spatially favored over the  $\pi_{u}$  interaction involving the U 5f orbitals. Several explanations for this seemingly anomalous  $\sigma_{\rm u}$ HOMO have been advanced. The most ubiquitous explanation involves "pushing from below," in which the σ, HOMO is destabilized by a filled-filled interaction with the lower-lying U 6p orbitals. In an EHT study of  $UO_2^{2+}$ , Tatsumi and Hoffmann propose this "pushing" as a mechanism for facilitating significant interaction of the HOMO with the higher-energy 5f manifold. 165 REX calculations by Pyykkö et al. provide support for this hypothesis. 122,156,157 Further, the 6p contribution to the HOMO increases with decreasing U-O bond distance, and thus the very short U-O bonds in UO<sub>2</sub><sup>2+</sup> enhance the "pushing" effect.

The adequacy of the "pushing from below" explanation has been questioned by practitioners of more sophisticated calculations. The nonrelativistic HFS results of DeKock et al. gave a  $\sigma_g$  HOMO regardless of whether 6p functions were treated as core or valence. They surmised that the effect of the 6p orbitals alone was not sufficient to yield a  $\sigma_u$  HOMO. Inclusion of relativistic effects via a P-HFS treatment did result in a  $\sigma_u$  HOMO, and DeKock et al. 154 therefore concluded that a combination of "pushing from below" and relativistic f-orbital effects, described below, was responsible

TABLE V. Calculated Percent 5f Character for the Highest Occupied  $UO_2^{2+}\sigma_n$  Orbital

| author  | year | ref   | method                | % 5f<br>character |
|---------|------|-------|-----------------------|-------------------|
| Tatsumi | 1980 | 155   | EHT                   | 29                |
| Pyykkö  | 1981 | 122   | REX (single-ζ)        | 87                |
| Pyykkö  | 1984 | 156   | REX (single-5)        | 86                |
|         |      |       | REX (double-()        | 79                |
| Glebov  | 1981 | 71-73 | CNDO                  | 85                |
| Boring  | 1975 | 148   | $NR-MS-X\alpha$       | 76                |
| Boring  | 1979 | 18    | QR-MS                 | 59                |
| Wood    | 1981 | 149   | QR-MS                 | 53                |
| DeKock  | 1984 | 154   | NR-HFS (6s6p core)    | 56                |
|         |      |       | NR-HFS (6s6p valence) | 71                |
| Walch   | 1976 | 152   | DS-DV                 | 40                |
| Wadt    | 1981 | 153   | RCP                   | 57                |

for the anomalous HOMO. Wadt also investigated the effect of treating the 6p orbitals as valence orbitals vs their inclusion in the core potential.<sup>153</sup> No effect on the orbital ordering was observed.

Both Wadt<sup>153</sup> and DeKock<sup>154</sup> favor an explanation for the  $\sigma_{\rm u}$  HOMO that invokes a large contribution to the HOMO from the U 5f orbitals, which increase in energy when relativistic effects are "turned on." This hypothesis has been disputed by researchers using the REX approach.<sup>156</sup> They observe a large change in the 5f character of the HOMO on going from single- $\zeta$  to double- $\zeta$  basis sets, but the orbital energies and ordering are nearly unaffected. They therefore conclude that the 5f orbitals have minimal impact on the HOMO energy.<sup>156</sup> This minimal impact notwithstanding, most MO calculations have yielded a large percentage of 5f character for the  $\sigma_{\rm u}$  orbital; these data are summarized in Table V.

Experimental studies of the electronic structure of  $UO_2^{2^{\frac{1}{4}}}$  have been as polemical as the theoretical reports. The uranyl ion is fluorescent and exhibits a complex set of electronic states, the lowest of which has a lifetime > 1 ms.46 Optical spectra for uranyl complexes show a low-intensity band at 2.5 eV, in contrast to the much higher-energy excitations observed for molybdenate (5.4 eV) and tungstenate (6.2 eV). These observations have stimulated a great interest in the excited electronic states of UO<sub>2</sub><sup>2+</sup> and in developing a correspondence between the computational and experimental results. A direct comparison of the theoretical and experimental results is complicated by the presence of equatorial ligands in the latter studies; these additional ligands are generally not included in theoretical calculations, although Walch and Ellis have used a perturbing point ion model with DS-DV calculations to investigate the effects of secondary ligands on UO<sub>2</sub><sup>2+</sup>.<sup>152</sup> Veal et al. used X-ray photoelectron spectroscopy (XPS) to probe the energies of the lower occupied valence orbitals of a series of sexivalent uranium oxides (predominantly uranyl-containing) with a variety of U-O bond lengths. 158 Their studies led them to conclude that there is minimal 5f participation in the U-O bonding. A more extensive 5f interaction was asserted by Cox, 159 who performed additional XPS studies on UO2, and by Walch and Ellis, 152 on the basis of their DS-DV calculations. Walch and Ellis did note, however, that their model of 5f bonding is weakened by the fact that the calculated valence bandwidth is too broad if 5f orbitals are included in the calculation, while limitation to 6d effects leads to closer agreement with experiment. 152 Denning et al. have reported the 4.2 K one-photon<sup>44</sup> and

two-photon<sup>45</sup> electronic absorption spectra of Cs<sub>2</sub>UO<sub>2</sub>Cl<sub>4</sub>. Their studies provide support for a  $\sigma_u$  HOMO that is primarily U 5f in character. They propose that the lowest optical transitions in the salt arise from excitations from the  $\sigma_u$  HOMO into the low-lying  $\delta_u$  and  $\phi_u$  nonbonding 5f orbitals. These conclusions were questioned by Jørgensen.<sup>47</sup>

The interplay of 6p and 5f interactions in the highlying occupied orbitals is also important in determining the geometry of actinyl systems. Uranyl exists in a trans configuration in solid-state complexes, indicating that the UO<sub>2</sub><sup>2+</sup> ion is linear. 160 By contrast, ThO<sub>2</sub> is known to be bent.<sup>161</sup> The challenge for computational chemists is not simply to predict these geometries, but to explain why thoranyl is bent and uranyl is linear. As mentioned above, Tatsumi and Hoffmann proposed the "pushing from below" model for uranyl in 1980.155 They propose that 6p effects raise the HOMO energy sufficiently to allow strong 5f interactions, which are more favorable in a linear geometry. They also proposed a secondary effect involving the  $\pi_u$  SHOMO (second highest occupied molecular orbital), in which the linear arrangement allows enhanced overlap between the U 5f  $\pi_{\rm u}$  and O 2p  $\pi_{\rm u}$  orbitals. Pyykkö and Lohr concurred with the Tatsumi and Hoffmann analysis, and further noted increased antibonding interactions between the U 6p  $\pi_{\rm u}$  and O 2p  $\pi_{\rm u}$  orbitals upon bending. Pyykkö observed that while the 5f character of the HOMO increases by 10% in going from single- to double-5 REX calculations, the bending force constant does not change, indicating that 5f orbital interactions have little effect on uranyl linearity.<sup>156</sup>

The extent of the importance of 6p effects on actinvl geometries has been disputed by Wadt. 153 Wadt points out that thorium has a higher 6p orbital energy than uranium, which should lead to greater 6p interactions in thoranyl. Thus, the bent geometry of thoranyl would lead to the conclusion that 6p effects are not important in determining actinyl geometry. 153 This observation was confirmed by calculations in which the An 6p orbitals were removed from the valence space and placed in the core. The removal of the 6p orbitals still led to linear and bent geometries for  $UO_2^{2+}$  and  $ThO_2$ , respectively.<sup>153</sup> As described above, the P-HFS calculations of DeKock et al. also led to the conclusion that the 6p interactions were insufficient to affect the HOMO energy.<sup>154</sup> Wadt<sup>153</sup> attributes the difference in geometry between uranyl and thoranyl to differences in orbital energy ordering. The lowest virtual orbitals of uranyl are 5f-based, and donation from the O 2p to the U 5f orbitals is better achieved in a linear geometry. By contrast, the lowest virtual orbitals of thoranyl are primarily 6d, and stronger bonding interactions between O 2p and these 6d-based orbitals occur in a bent configuration. 153

A comprehensive discussion of actinyl geometry has recently been published by Pyykkö and Laakkonen. They affirm the mechanisms described above and add another: at short bond lengths, the  $\pi_u$  SHOMO of AnO<sub>2</sub><sup>q+</sup> has a greater An 6p character. Thus, the 6p effects are more important in uranyl, which has short U-O bonds, than in thoranyl, which has considerably longer Th-O bonds. They therefore propose that uranyl is linear for three reasons: (1) Its short bond lengths lead to strongly linearizing 6p interactions in the

SHOMO. (2) Its high-lying 6d orbitals lead to a negligible tendency to bend. (3) The interaction of its low-lying 5f orbitals with the HOMO is favored by a linear geometry. Conversely, thoranyl is bent because: (1) Its long bond length reduces 6p linearizing effects. (2) The low-lying 6d orbitals prefer a bent geometry for optimal bonding overlap. (3) The high-lying 5f orbitals do not interact significantly with the HOMO.

Ab initio methods have also been employed in studies of actinide monoxides, ThO162 and UO+.163 The first electronic spectrum of ThO was recorded in 1905, but analysis was not possible until much later (1965). ThO has an exceptionally strong bond, which can be explained by 5f interactions. The accessibility of 5f orbitals for bonding can be considered a relativistic effect, in that relativistic effects increase the 5f orbital energies. The calculations on ThO162 provided a test of a quasirelativistic one-component RCP method<sup>164</sup> that used the Foldy-Wouthuysen<sup>91</sup> factorization of the Dirac equation. Results of CAS-SCF and externally contracted CI calculations for four low-lying states of ThO were compared with REX results. Both methods indicate a strongly polarized double bond involving interactions of the Th d $\sigma$  and d $\pi$  orbitals with the O p $\sigma$ and  $p\pi$  orbitals. The anomalous bond strength is due to 5f hybridization in these orbitals, while the 7s  $\sigma$  orbital accommodates the two metal-based electrons.

Krauss and Stevens used a Pitzer-type RCP in  $\omega-\omega$  coupling calculations of the electronic structure and spectra of UO<sup>+</sup>. <sup>163</sup> The results of their restricted-valence CI calculations involving localized molecular orbitals point to an essentially ionic model for UO<sup>+</sup>, i.e. U<sup>3+</sup>O<sup>2-</sup>. UO<sup>+</sup> has been identified, along with uranyl ion, as a product of the interaction of gaseous U atoms and O<sub>2</sub> in molecular beams. While the uranyl spectrum has been studied extensively, as indicated by our previous discussion, other actinide oxides have not been so thoroughly examined. Krauss and Stevens predict that UO<sup>+</sup> should absorb strongly in the red region of the visible spectrum, results that should assist spectroscopists in assigning the optical spectrum for this ion.

In other computational studies of actinide oxides, electronic effects in a crystal environment have been analyzed by QR-MS<sup>165</sup> and DS-DV<sup>152,166-170</sup> calculations on molecular clusters. The electronic structure of solid UO<sub>2</sub> was also probed through study of the  $(UO_8)^{12}$ -cluster using the QR-MS approach.<sup>171</sup> The bonding in UO<sub>2</sub> has been studied by QR-MS<sup>159</sup> and P-HFS calculations.<sup>172</sup> In addition, Makhyoun performed QR-MS calculations on NpO<sub>2</sub>Cl<sub>4</sub><sup>2-</sup> and NpO<sub>2</sub>(NO<sub>3</sub>)<sub>3</sub>- complexes.<sup>173</sup> Borhovskii has reported results of extended Hückel calculations, including spin-orbit effects, on UO<sub>2</sub>X<sub>n</sub><sup>m-</sup> (X = halides),<sup>174</sup> and EHT has also been applied to studies of spin-lattice relaxation in a uranyl-phenanthraquinone radical ion complex.<sup>175</sup>

## VI. Cyclopentadienyl-Actinide Complexes

The cyclopentadienyl (Cp) ligand,  $C_5H_5$ , has been central to organometallic chemistry since the synthesis and characterization of ferrocene in 1951.<sup>176</sup> The remarkable synthesis of uranocene in 1968<sup>43</sup> has brought considerable experimental and theoretical interest in organoactinide chemistry, and the Cp ligand has been as useful and flexible in this area as in organotransition metal chemistry.

As with other actinide compounds, the question of the extent of relativistic effects and the role of f electrons are at the fore of Cp-actinide chemistry. The issue of f covalency has been discussed by many authors. 58,177,178 Recently, models involving a "steric coordination number"179 and a statistical analysis of structural data<sup>59</sup> have been applied to the evaluation of the role of f electrons in organoactinides. The radioactivity and toxicity of the actinide elements have resulted in a paucity of experimental results for organoactinides, with the exceptions of Th and U. The large size of the actinide atoms leads to variable and unpredictable coordination numbers in organoactinide complexes. These two factors complicate, and make evident the need for, computational studies. These studies are unfortunately made difficult by the large number of electrons, the necessity for including relativistic effects, and the complicating presence of f orbitals in these systems.

The bonding in cyclopentadienyl-actinide complexes has recently been reviewed in detail by one of us.<sup>67</sup> Therefore, in this section we shall only summarize some of the important computational studies in this area of actinide chemistry, with an emphasis on the variety of methods that have been applied to Cp-actinide systems.

Unlike actinide oxide and actinide halide chemistry, organoactinide chemistry is dominated by lower actinide oxidation states, primarily +3 and +4. For uranium, both of these oxidation states are accessible. Tetravalent uranium and thorium form a host of complexes with Cp of general formulation  $Cp_nAnX_{4-n}$  (An = Th, U; n = 1-4; X = anionic ligand); for n = 1 and 2, substituted cyclopentadienyls such as C<sub>5</sub>Me<sub>5</sub> (Cp\*) are usually used to confer steric stability to the complexes. U(III) also forms many Cp-containing complexes, most notably  $Cp_3U$  and  $Cp_3UL$  (L = neutral ligand). Later actinide chemistry is dominated by the +3 oxidation state, but difficulties in handling have made studies of compounds of these elements rather scant. For example, Cp<sub>3</sub>An complexes for all of the actinide elements through Cf have been isolated, but little is known about their chemical properties. 60-66

The nature of the bonding between an actinide metal and a cyclopentadienyl ring has been a question of paramount importance in the field of organoactinide chemistry. Tatsumi and Hoffmann used EHT calculations to compare the bonding of a Cp<sup>-</sup> ligand to a 5f<sup>0</sup> U<sup>6+</sup> center with that to a 3d<sup>6</sup> Fe<sup>2+</sup> ion. They concluded that the Cp-U(VI) interaction is largely ionic, while a significant degree of covalency is found for the transition-metal system, [CpFe]<sup>2+</sup>. Of course, the U<sup>6+</sup> ion is expected to be chemically "harder" than the lower oxidation states, so the Tatsumi-Hoffmann conclusions can probably be considered a limiting case. In a related study, Tatsumi and Nakamura used EHT to study the preference of  $\eta^5$  Cp coordination to actinides as compared to  $\eta^1$  coordination, which is not observed in Cpactinide complexes.<sup>181</sup> A 1989 review of the available experimental and theoretical studies of Cp-actinide bonding arrives at the conclusion that the Cp-actinide interaction is more covalent than Cp-lanthanide interactions, but more ionic than Cp-transition metal bonding.58

The study of the bonding in specific Cp-actinide complexes has grown steadily with the experimental

investigations of these systems. Some early EHT studies of  $\mathrm{Cp_4An}$  systems addressed the optical absorption spectrum of  $\mathrm{Cp_4U^{182}}$  and the temperature dependence of the magnetic susceptibility of  $\mathrm{Cp_4An}$  complexes, via calculations on model  $(\eta^6\text{-}\mathrm{C_6H_6})_4\mathrm{An^{4+}}$  systems. The electronic structure of a series of Th(IV) and U(IV) complexes has been investigated through QR-MS calculations. The calculated QR-MS transition-state ionization potentials of  $\mathrm{Cp_4Th}$  and  $\mathrm{Cp_4U}$  are in reasonable agreement with those observed in the PE spectra. These calculations predict significant donation from  $\mathrm{Cp}~\pi_2$  orbitals into the actinide 6d and 5f orbitals, an indication of stronger covalent interaction than is observed in actinide-halide bonding. 185

Several aspects of the bonding in Cp<sub>3</sub>AnX complexes have been investigated by a variety of quantum chemical methods. EHT calculations on Cp<sub>3</sub>U<sup>+</sup> show that the energy of the orbital that binds the fourth ligand is lowered upon pyramidalization of the fragment due to increased 6d-7p hybridization. 181 QR-MS calculations also show the formation of a predominantly  $6d_{z^2}$ σ-acceptor orbital in Cp<sub>3</sub>U upon pyramidalization;<sup>186</sup> the inclusion of quasirelativistic corrections in the latter calculations lowers the energy of the  $\sigma$ -acceptor orbital relative to the 5f block by about 4 eV. The formation of a  $\sigma$ -bond between the Cp<sub>3</sub>U fragment and a  $\sigma$ -donor ligand is qualitatively the same in both EHT calculations on Cp<sub>3</sub>UCH<sub>3</sub><sup>180,181</sup> and QR-MS calculations on Cp<sub>3</sub>UH:<sup>187</sup> the formally anionic fourth ligand donates charge into the empty  $\sigma$ -acceptor orbital on the actinide fragment. The PE spectra of  $Cp_3UX$  (X = F, Cl, Br) systems have been correlated to nonrelativistic DV-X $\alpha$ calculations. 188 EHT calculations have been used to study the formation of U-C multiple bonds in the novel Cp<sub>3</sub>U-ylide complexes of Cramer and Gilje. 189 Other calculations on U(IV) Cp3UX complexes have addressed the potential for multiple U-X bonding for a variety of N- and O-containing donor ligands, 190 and the ability of OH to serve as a  $\pi$ -donor to the U center. 187

The An(IV) complexes  $Cp*_2AnX_2$  (An = Th, U) are among the most widely studied Cp-actinide complexes, both experimentally and theoretically. Computational studies of these systems invariably model the Cp\* ligands with unsubstituted Cp, a replacement expected to have a constant, predictable effect on the orbital energies.  $^{185,191}$  EHT calculations on the  $\mathrm{Cp_2U^{2+}}$  fragment show that frontier orbitals of a<sub>1</sub>, b<sub>2</sub>, and b<sub>1</sub> symmetry are available to accept charge from the  $\sigma$ -donor X ligands (Figure 6). 192 These studies have been extended to explain the unusual agostic bonding in Cp\*<sub>2</sub>Th(CH<sub>2</sub>CMe<sub>3</sub>)<sub>2</sub>,<sup>192</sup>,<sup>193</sup> the bonding and reactivity of actinide acyl complexes, <sup>194</sup>, <sup>195</sup> the insertion of CO into the An-X bonds, 194,196 the relative energetics of actinacyclopentadiene and actinide cyclobutadiene complexes, <sup>192</sup> and the bonding in the pyrazolate complex  $Cp*_2U(pz)_2$  (pz =  $C_3H_3N_2$ -). <sup>197</sup> QR-MS calculations on  $Cp_2AnX_2$  (An = Th, U; X = Cl, CH<sub>3</sub>) systems indicate that CH<sub>3</sub> is a stronger σ donor than Cl and that Cl is not a good  $\pi$  donor to actinides. 198 The calculated ionization energies correlate reasonably well with the PE spectra. These calculations were also used to explain the paramagnetism of 5f<sup>2</sup> Cp\*<sub>2</sub>UX<sub>2</sub> systems as compared to the diamagnetism of 4d2 Cp2MoX2 complexes.

![](_page_14_Figure_2.jpeg)

Figure 6. Frontier molecular orbitals for  $Cp_2U^{2+}$ . The contour levels for each diagram are drawn at  $\pm 0.025$ ,  $\pm 0.05$ ,  $\pm 0.1$ , and  $\pm 0.2$ . The  $3a_1$ ,  $3b_2$ , and  $4a_1$  orbitals, all lying in the equatorial xy plane, can form  $\sigma$  bonds with incoming ligands to form the familiar  $Cp_2AnL_n$  complexes. The  $4b_1$  frontier orbital, perpendicular to the equatorial plane, can contribute to  $\pi$  interactions in the complexes (reprinted from ref 192; copyright 1987 American Chemical Society).

The monocyclopentadienyluranium(IV) complex  $CpU[(CH_2)(CH_2)P(C_6H_5)_2]_3$  exhibits rather long U–C  $\sigma$  bonds. EHT calculations on a model of this system show some covalent U–C interaction, but with significantly lower overlap than in  $Cp_3UCH_3$ , explaining the long bond length. 199

The bonding of an An(III) center to three Cp ligands is perhaps the most common actinidocyclopentadienyl moiety, either in the "base-free" Cp<sub>3</sub>An form, or coordinated to a fourth neutral ligand, as Cp<sub>3</sub>AnL. The "base-free" compounds are known for the actinides Th through Cf; the Cm<sup>200</sup> and Cf<sup>201</sup> complexes are noteworthy as the only organometallic compounds involving these elements.

Symmetry constraints in the pseudo- $D_{3h}$  Cp<sub>3</sub>An compounds result in a ligand a<sub>2</sub> orbital that can interact only with metal 5f AOs. This unique insistence on 5f interaction was recognized by Moffitt<sup>177</sup> and confirmed by EHT<sup>181</sup> and QR-MS<sup>187</sup> calculations. The EHT calculations showed a 5f contribution of 8% to the a<sub>2</sub> orbital, whereas the QR-MS show an increase in the 5f contribution to 29%. QR-MS results for Cp<sub>3</sub>An compounds, An = Pa through Pu, showed a dramatic drop in 5f energy across the series, with a smaller concomi-

tant rise in 6d energy. 186 These trends led to the prediction of the Cp<sub>3</sub>Pa configuration as 5f<sup>1</sup>6d<sup>1</sup>, with transuranium complexes adopting a 5f<sup>n</sup>6d<sup>0</sup> configuration. For Cp<sub>3</sub>U, the 5f<sup>2</sup>6d<sup>1</sup> and 5f<sup>3</sup>6d<sup>0</sup> configurations were energetically indistinguishable; subsequent DS-DV calculations established that 5f<sup>3</sup>6d<sup>0</sup> is the correct ground configuration for Cp<sub>3</sub>U, however.<sup>202</sup> Recently, the DS-DV method has been applied to Cp<sub>3</sub>Th, in addition to other three-coordinate actinide complexes.<sup>203</sup> Further studies of Cp<sub>3</sub>An systems involved comparison with AnCl<sub>3</sub> compounds. These QR-MS calculations showed greater ligand-to-metal contributions with Cp than with Cl, and a lesser drop in 5f energy for Cp than for Cl.<sup>204</sup> Recently, QR-MS calculations have also been reported for Cp<sub>3</sub>An complexes, An = U through Cf, in comparison with lanthanide and Zr analogues.<sup>205</sup>

The Cp<sub>3</sub>An fragment can interact with a variety of neutral ligands, including phosphines, isocyanides, and carbon monoxide. <sup>206</sup> The carbonyl complex Cp<sup>†</sup><sub>3</sub>UCO (Cp<sup>†</sup> =  $\eta^5$ -C<sub>5</sub>H<sub>4</sub>SiMe<sub>3</sub>) is particularly notable as the first isolable actinide—carbonyl complex. <sup>207</sup> QR-MS calculations on the model complex Cp<sub>3</sub>UCO indicate significant  $\pi$  backbonding from the U  $5f\pi$  orbitals to the empty CO  $2\pi$  orbitals, resulting in a stabilized  $5f\pi$  HOMO in this  $5f^3$  complex. <sup>208</sup> Because uranium has a propensity for binding oxygen, the isocarbonyl complex Cp<sub>3</sub>UOC was also considered as a possible model product of the reaction of CO with Cp<sup>†</sup><sub>3</sub>U. The low-lying oxygen lone pair disrupts the U–O  $\sigma$  bonding in this complex, and it is predicted to be less stable than the C-bound carbonyl complex.

Cyclopentadienyl-actinide complexes have not yet been investigated with use of ab initio methods. While such studies would necessarily be very computationally demanding, they are feasible. We expect, therefore, that this important class of actinide molecules will be studied by ab initio methods in the next several years.

## VII. Actinocenes

Organoactinide chemistry entered a new era with the synthesis of uranocene,  $U(COT)_2$  ( $COT = \eta^8-C_8H_8$ ), in 1968.<sup>43</sup> This U(IV) complex, which was synthesized by the reaction of  $COT^{2-}$  with  $UCl_4$ , is a  $D_{8h}$  molecule with two planar, parallel  $C_8H_8$  rings sandwiching the U atom.<sup>209</sup> The coordination of an octahapto ligand has no precedent in organotransition metal chemistry, thus establishing organoactinide chemistry as a distinct field. Soon after, the analogous actinocenes of Th,<sup>210</sup> Pa,<sup>211</sup> and Np and Pu<sup>212</sup> were synthesized and studied spectroscopically.<sup>213</sup> Actinocene chemistry has been reviewed extensively, <sup>60-66,214</sup> and here we will highlight those contributions of electronic structure calculations that have led to an increased understanding of these novel systems.

Computational studies of the actinocenes have played a significant role in understanding their chemistry, even prior to their synthesis: the stability of uranocene was predicted by R. D. Fischer five years prior to the reported synthesis. <sup>215</sup> Subsequent Wolfsberg-Helmholtz studies have been reported by Amberger and Fischer <sup>216</sup> for uranocene, and by Hayes and Edelstein <sup>217</sup> for the actinocenes of U, Np, and Pu. The REX approach was applied to uranocene in 1981. <sup>122</sup> Rösch and Streitwieser reported nonrelativistic MS-X $\alpha$  calculations on thorocene and uranocene, <sup>218</sup> as well as QR-MS studies of

TABLE VI. P-HFS,221 QR-MS,218-220 and Experimental Actinocene Ionization Energies (eV)

| МС                | Th<br>P-HFS <sup>b</sup> | Th<br>QR-MS | Th<br>expt | Pa<br>P-HFS <sup>b</sup> | U<br>P-HFS <sup>8</sup> | U<br>QR-MS | U<br>expt | Np<br>P-HFS <sup>6</sup> | Pu<br>P-HFS <sup>b</sup> |
|-------------------|--------------------------|-------------|------------|--------------------------|-------------------------|------------|-----------|--------------------------|--------------------------|
| 3e <sub>20</sub>  | 5.88                     | 6.53        | 6.79       | 5.92                     | 5.96                    | 6.75       | 6.90      | 6.00                     | 5.97                     |
|                   | 5.90                     |             |            | 5.97                     | 6.04                    |            |           | 6.12                     | 6.18                     |
| 3e <sub>2</sub> , | 6.61                     | 7.51        | 7.91       | 6.64                     | 6.61                    | 7.29       | 7.85      | 6.56                     | 6.47                     |
| -1                | 6.69                     |             |            | 6.73                     | 6.69                    |            |           | 6.63                     | 6.54                     |
| 4e <sub>1</sub> , | , 8.76                   | 9.44        | 9.90       | 8.75                     | 8.76                    | 9.43       | 9.95      | 8.78                     | 8.78                     |
| -                 | 8.95                     |             | 10.14      | 8.96                     | 8.97                    |            | 10.28     | 8.99                     | 8.98                     |
| 3e <sub>11</sub>  | , 9.44                   | 10.11       | 10.65      | 9.41                     | 9.37                    | 9.94       | 10.56     | 9.34                     | 9.28                     |
| _                 | 9.46                     |             |            | 9.43                     | 9.38                    |            |           | 9.36                     | 9.30                     |
| 2e <sub>3</sub>   | , 9.30                   | 10.61       |            | 9.31                     | 9.33                    | 10.51      |           | 9.35                     | 9.34                     |
| ٦                 | 9.30                     |             |            | 9.31                     | 9.33                    |            |           | 9.34                     | 9.34                     |
| 2e <sub>3</sub> , | , 9.32                   |             |            | 9.33                     | 9.36                    |            |           | 9.37                     | 9.37                     |
|                   | 9.31                     |             |            | 9.32                     | 9.35                    |            |           | 9.37                     | 9.35                     |

<sup>a</sup> Fragalà, I.; Condorelli, G.; Zanella, P.; Tondella, E. J. Organometal. Chem. 1976, 122, 357. <sup>b</sup> The two P-HFS values for each ionization represent spin-orbit split components.

the Th, U, and Ce compounds.<sup>219,220</sup> More sophisticated actinocene calculations have been reported recently, including the P-HFS investigations of Boerrigter et al.<sup>139,221</sup> and Chang and Pitzer's ab initio RCP spin—orbit CI calculations.<sup>108</sup>

A number of electronic structural issues are of interest in order to interpret the experimental data for the actinocenes and to understand their chemistry. The energetic order and extent of splitting of the f orbitals, and particularly the choice of an appropriate spin-orbit coupling scheme (weak field or strong-field, LS or jj), are critical to understanding the optical spectra. Computational studies of actinocenes have been used to predict optical transitions and ionization energies and thus aid in the interpretation of optical and PE spectra. In addition, the extent of 5f and 6d covalency, the role of each in metal-ligand bonding, and the strength of these bonds are significant questions with respect to understanding actinocene chemistry.

A schematic diagram of the major orbital interactions in the actinocenes is given in Figure 7. The e<sub>2u</sub> HOMOs of the COT<sup>2</sup> rings form group orbitals of e<sub>2g</sub> and e<sub>2u</sub> symmetry that can interact respectively with the 6d and 5f orbitals on the actinide atom. The 5f block of orbitals comprise the highest occupied orbitals of the actinocenes (except for 5f<sup>0</sup> thorocene) with the occupied ligand-based e<sub>2u</sub> and e<sub>2g</sub> orbitals lower in energy. The 5f block is progressively filled across the actinide series, from Th (5f<sup>0</sup>) to Pu (5f<sup>4</sup>). The photoelectron spectrum for uranocene shows three low-energy peaks at 6.20, 6.90, and 7.85 eV.<sup>222</sup> While the first ionization band is doubtless due to ionization of the 5f electrons, the ordering of the e<sub>2u</sub> and e<sub>2g</sub> ionization bands has been a matter of some controversy. Based on assumptions concerning the relative He I and He II photoionization cross sections for 5f and 6d electrons, the second ionization band (6.90 eV) was initially attributed to the  $e_{2g}$  orbital, which contains U 6d character. Subsequent studies, including a recent variable photon energy investigation by Green et al.,  $^{222d}$  place the  $e_{2u}$  ionization at lower energy than the  $e_{2g}$  ionization, implying a greater interaction of the U 6d orbitals with the ligands than that of the U 5f orbitals. REX, 122 nonrelativistic Xα-MS, 218 QR-MS, 219,220 P-HFS, 221 and RCP108 calculations all support this interpretation of the PES data, placing the e<sub>2u</sub> orbital higher in energy than the e<sub>2g</sub> orbital. MO energies resulting from P-HFS calculations for the actinocenes of Th through Pu are displayed in Figure 8.<sup>221</sup> Although the orbital orderings provided

![](_page_15_Figure_8.jpeg)

Figure 7. Schematic MO interaction diagram for the actinocenes. The molecular orbitals for the cyclooctatetraene fragment  $(COT)^2$  are displayed on the far left. The interaction of these MOs in  $(COT)_2^{4-}$  appear in the next column. The actinide 5f and 6d atomic orbitals, displayed in the far right column, interact with the  $(COT)_2^{4-}$  fragment MOs to form the actinocene complex,  $M(COT)_2^{221}$ 

by the various computational studies are in general agreement, the ionization energies displayed in Table VI show that quantitative agreement is lacking between the QR-MS and P-HFS results and those observed experimentally.

Streitwieser proposed that  $5f\delta$ -ligand  $e_{2u}$  bonding represented the principal covalent interaction in uranocene. While 5f bonding is certainly supported by molecular orbital studies, the importance of 6d interactions has proved equal or greater in magnitude. It is clear from the schematic diagram in Figure 7 that  $6d\delta$  interactions can stabilize the  $e_{2g}$  orbital, while interaction with the  $5f\delta$  orbitals would lower the energy of the  $e_{2u}$  orbital. As shown in Figure 8, the greater stabilization of the  $e_{2g}$  orbital relative to  $e_{2u}$ , as well as the stabilization of  $e_{1g}$  relative to  $e_{1u}$ , points to 6d-dominated bonding. On the other hand, the 5f manifold shows strong splitting between  $f\delta$  and the remaining  $f\sigma$ ,  $f\pi$ , and  $f\phi$  orbitals, with the  $f\delta$  pushed upward in energy

![](_page_16_Figure_2.jpeg)

Figure 8. MO energies for the actinocenes of Th through Pu, calculated by using the relativistic perturbative Hartree-Fock-Slater method. The diagram is based upon a figure in ref 221. The diagram clearly shows the drop in 5f orbital energies across the series, and the corresponding rise in 6d orbital energies, as well as the increase in 5f spin-orbit splittings.

by a bonding interaction with the e<sub>2u</sub> orbital. Boerrigter et al.<sup>221</sup> found that the 6d effects were more pronounced in the early actinocenes, with 5f interactions increasing in importance across the series. Significant 5f populations in the bonding orbitals have been reported by a number of researchers: Chang and Pitzer calculated ligand-to-metal donation of 6d<sup>1.98</sup>5f<sup>0.50</sup>, while Boerrigter found donation more balanced between 5f and 6d, 6d<sup>0.94</sup>5f<sup>0.71</sup>.

Determination of the uranocene ground state has been of interest to researchers for some years. A model of weak ligand-field interactions was adequate to allow Hayes and Edelstein<sup>217</sup> to predict a  $|M_J| = 3$  ground state and a  $|M_{\rm J}| = 2$  first excited state; REX results concurred with this prediction. 122 Boerrigter et al. 221 noted that the weak field model is essentially inadequate for describing the  $f\delta$  interactions, leading to inaccurate predictions of closely spaced excited states. They chose instead to use a combination of weak- and strong-field interactions, treating the  $f\sigma$ ,  $f\pi$ , and  $f\phi$ orbitals with primary spin-orbit interaction perturbed by a weak ligand field, and treating  $f\delta$  separately in the strong-field regime. This model predicted a  $|M_J| = 3$ ground state, with  $|M_J| = 2, 0, 4, 1$ , and 3 excited states. Chang and Pitzer<sup>108</sup> find similar deviations from the weak-field, LS coupling regime, but find it gives a better description of results than does strong-field, j-j coupling.

While LDF methods give accurate molecular orbital results, they do not provide information on how the orbitals are coupled together, and cannot give the precise symmetry of the ground state or excited states. Chang and Pitzer were able to provide this information accurately through RCP spin-orbit CI studies. They identified an  $E_{3g}$  ground state ( $|M_J| = 3$ ), in agreement with earlier predictions.  $^{122,217,221}$  The order of  $f^2$  excited states was found to be  $|M_J| = 2 < |M_J| = 4 < |M_J| = 1$ . Interestingly, Chang and Pitzer  $^{108}$  point out that while

the 6d orbitals seem to be most important in uranocene metal-ligand bonding, it is the 5f interaction that determines the ground state. As discussed above, bonding interactions push the 5f $\delta$  orbital up in energy, so that a high 5f $\delta$  population will lead to a higher energy state. The  $|M_J|=3$  state has the lowest 5f $\delta$  population, followed by  $|M_J|=2$ , 1, 0, and 4; the low 5f $\delta$  population ensures that  $|M_J|=3$  will be the ground state.

The excited-state studies of Chang and Pitzer 108 allowed full assignment of the visible spectrum of uranocene, including the explanation of the green color of the complex as arising from  $E_{3g}$  to  $E_{2u}$  and  $E_{3u}$  transitions, which are primarily metal 5f to 6d excitations with some ligand- $\pi$  to metal-d character. Further, they predicted many allowed transitions in the UV region and encouraged spectroscopists to conduct detailed experiments in this spectral region.

## VIII. Metal-Metal Bonding in Actinide Systems

Metal-metal bonding in actinide systems has been the topic of several synthetic and computational studies, as well as considerable speculation. To date, no discrete molecules containing a direct bond between two actinide atoms have been isolated. Nonrelativistic MS- $X\alpha^{223}$ and recent RCP<sup>224</sup> calculations have addressed the question of the existence and molecular electronic structure of the naked actinide dimers U<sub>2</sub> and Np<sub>2</sub>. March et al. have used simple models to predict that such heavy-atom homonuclear diatomics are unlikely to exist. 225 Contrary to their prediction, U2 has been observed in the gas phase. 226 MS- $X\alpha$  results indicated a 5f block of bonding orbitals lying considerably lower in energy than the metal 6d and 7s orbitals and a ground-state sextuple-bond configuration of  $5f(\sigma^2\pi^4\delta^4\phi^2)$ for U2. Our recent RCP calculations224 reveal that the inclusion of relativistic effects leads to a far more complicated picture for  $U_2$ . Two distinct sets of states having potential energy minima are identified. The first have long bond lengths (ca. 3.0 Å), essentially atomic 5f orbitals, and bonds involving the 6d and 7s orbitals. Another set of states have short bond lengths (ca. 2.2) A) and show roughly equal participation among 5f, 6d, and 7s orbitals in bonding. These results are summarized in Figure 9. Obviously, relativistic and correlation effects are necessary for a full understanding of the naked metal systems.

Although no complexes involving direct bonding between two actinide atoms have been synthesized, several examples of actinide-transition-metal bonding have been observed. In 1985, the first phosphido-bridged heterobimetallic complex involving an actinide atom was synthesized. This complex,  $Th(\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2(\mu-\eta^5-Cp^*)_2($ PPh<sub>2</sub>)<sub>2</sub>Ni(CO)<sub>2</sub>, exhibits a short Th-Ni distance, raising the possibility of Th-Ni bonding interaction in the complex. The nature of this interaction has been investigated by EHT<sup>228</sup> and QR-MS<sup>229</sup> calculations on the model compound  $Th(\eta^5-Cp)_2(\mu-PH_2)_2Ni(CO)_2$ . Ortiz<sup>228</sup> reported EHT overlap populations for Th-Ni as a function of bond distance, from 3.206 to 3.70 Å. Although the overlaps were negative in all cases, the short bond length structure showed the least negative overlap. Further, the Th-Ni overlap population was the one most dependent on bond distance, dropping rapidly with increasing bond length. His analysis of the bonding interactions showed a repulsive filled-filled

![](_page_17_Figure_2.jpeg)

Figure 9. CAS-SCF occupied orbital energy diagrams and contour plots for two possible ground states of  $U_2$ . MOs are plotted on a 12 au by 12 au grid, with contour lines at levels of -0.34 to 0.34 au in steps of 0.02 au.<sup>224</sup> The 6d, 5f, and 7s atomic orbitals all show bonding interactions in the  $2.2-\text{\AA}^5 A_g$  state, while the  $3.0-\text{\AA}^{13} A_g$  state consists of essentially atomic 5f orbitals, with bonding interactions limited to the 6d and 7s orbitals (reprinted from ref 224; copyright 1990 American Chemical Society).

interaction between the Ni 3d orbitals and the PH<sub>2</sub> MOs that are delocalized onto the Th center, leading to an antibonding Th-Ni interaction. Filled Ni 3d levels also interact with empty orbitals on the formally Th<sup>4+</sup> d<sup>0</sup>f<sup>0</sup> center in weak  $\sigma$  and  $\pi$  bonds. These bonding interactions are principally d-d in nature, with additional stabilization provided by 5f hybridization.

The EHT bonding description of the Th-Ni complex was supported by Makhyoun's QR-MS results, which showed a Ni 3d population of 8.74, considerably less than that expected for a  $d^{10}s^0p^0$  Ni atom.<sup>229</sup> Their MO analysis indicated a substantial  $\sigma$ - $\sigma$  overlap, as well as a weaker  $\pi$ - $\pi$  interaction. Like the bonding in mononuclear Th complexes, the metal-metal bonding in this heterobimetallic complex is dominated by Th 6d, rather than 5f, interactions. The bonding MOs are primarily Ni 3d in character, indicating a flow of charge from Ni to Th in these weak bonds. It is interesting to note that the nonrelativistic EHT and the relativistic QR-MS methods gave essentially the same qualitative description for this large molecule.

The power of ab initio RCP methods to handle even large metal systems was beautifully demonstrated by Hay's calculations on a similar heterobimetallic,  $Cl_2Th(\mu-PH_2)_2Pt(PH_3)$ , a model for the recently synthe sized  $Cp_2^*Th(\mu-PPh_2)_2Pt(PMe_3)$  complex. The purpose of these studies was to replace the Ni(CO)<sub>2</sub> fragment in the above Ni-Th complex with a more electron-rich transition-metal donor, in order to test the Ni-donor Th-acceptor model described above. The crystal structure for the Th-Pt complex showed a Th-Pt bond distance of 2.984 Å, significantly shorter than the estimated covalent distance of 3.2 Å, as well as acute Th-P-Pt angles. These structural data, along with <sup>31</sup>P NMR spectra and a comparison with other heterobimetallics, led these authors to conclude that the complex contains a direct Th-Pt bond. The RCP Har-

![](_page_17_Figure_7.jpeg)

Figure 10. Contour diagram of the metal-metal bonding HOMO of  $\text{Cl}_2\text{Th}(\mu\text{-PH}_2)_2\text{Pt}(\text{PH}_3)$  in the xy (top) and xz planes, from RCP calculations. Positive, negative, and nodal contours are represented by solid, short-dash, and long-dash lines, respectively. The contour plot shows convincing evidence of a metal-metal bond (reprinted from ref 230; copyright 1986 American Chemical Society).

tree–Fock and generalized valence bond calculations on the model complex indicated a metal–metal bonding orbital formed from Pt  $5d_{x^2-y^2}$  and  $Th_{x^2-y^2}$  contributions. A contour diagram of this metal–metal bonding orbital is given in Figure 10. The greater electron density was located on the Pt center, leading to the description of the bond as a donor–acceptor interaction between the filled  $d^{10}$  shell of Pt and the  $d^0$  shell of Th.

Concurrent with the first reports of the phosphidobridged actinide-transition-metal heterobimetallic complexes was the first report of a molecule containing an unsupported (and, perforce, unambiguous) bond between an actinide atom and a transition metal. The synthesis of the first two such complexes, Cp\*2(X)Th- $RuCp(CO)_2$  (X = Cl, I), was reported in 1985 by Marks and co-workers.<sup>231</sup> QR-MS calculations on a model for this system, Cp<sub>2</sub>(I)Th-RuCp(CO)<sub>2</sub>, as well as the Zr-Ru analogue, were reported shortly thereafter. 232 These calculations indicated that the metal-metal bonding orbitals of the d<sup>0</sup> Zr and d<sup>0</sup>f<sup>0</sup> Th complexes were similar, with both describing a donor-acceptor bond. As was found for the supported metal-metal bonded systems, the actinide 6d orbitals played the principal role in metal-metal bonding; the Th 5f population in the bonding MOs represented only 16% of the total Th contribution. These authors suggested that the bonding in these complexes was essentially the same as in  $Cp_2MX_2$  (M = Zr, Th) complexes, leading to the conclusion that the CpRu(CO)<sub>2</sub> fragment is best considered as an "organometallic pseudohalide." The conclusions of these studies were applied in the subsequent synthesis of additional complexes with unsupported bonds between Th or U and a transition metal.<sup>233</sup>

Clearly, computational studies have played an integral role in understanding metal-metal bonding in actinide complexes. It is expected that electronic structure calculations will also be an important tool in the design of molecules that contain a direct bond between two actinide atoms. Such covalent bonds might exhibit very different properties from those of the heterobimetallic systems.<sup>234</sup>

#### IX. Miscellaneous Other Actinide Systems

In this final applications section, we shall briefly discuss several other computational studies on actinide systems that are worthy of note. As mentioned previously, a series of trivalent actinide complexes has been investigated by using the DS-DV approach.<sup>203</sup> A particularly fascinating aspect of these studies is the complex interplay between spin-orbit and ligand-field effects, with metal-ligand bonding interactions damping the spin-orbit splitting.

Nonrelativistic DV- $X\alpha$  calculations have been reported for the uranium(VI) alkoxide, U(OCH<sub>3</sub>)<sub>6</sub>.<sup>235</sup> This alkoxide is of interest for a number of reasons: (1) Actinide alkoxides are becoming an increasingly important class of actinide complexes.<sup>236</sup> (2) The large M-O-R angles and short M-O bond distances in the complexes indicate unusual metal-ligand bonds. (3) U(OCH<sub>3</sub>)<sub>6</sub> has served as a successful prototype in laser-induced multiphoton isotope separation experiments. (4) The alkoxide is of intermediate complexity between the simple actinide halides and oxides and the more complicated organoactinide complexes.

By analogy to UF<sub>6</sub>, the high-lying occupied MOs in U(OCH<sub>3</sub>)<sub>6</sub> correspond to ligand lone-pair orbitals. The four sets of ligand  $\pi$  MOs, under  $O_h$  symmetry, include a  $t_{2g}$  orbital that can interact with U 6d, a  $t_{2u}$  orbital that can interact with U 5f, and a  $t_{1u}$  orbital that can interact with U 5f, U 7p, and ligand  $\sigma$  orbitals. The fourth  $\pi$  orbital is of  $t_{1g}$  symmetry, and cannot interact with any of the metal orbitals. QR-MS calculations on octahedral U(OH)<sub>6</sub> essentially confirmed this qualitative picture. Large 5f populations in the t<sub>2u</sub>-derived MOs (17, 26, and 36%) indicate significant ligand-tometal donation. Similarly, the t<sub>2g</sub> MO shows significant (10%) U 6d character. As expected the t<sub>1g</sub> orbital is essentially nonbonding. The  $t_{1u}$ ,  $t_{1g}$ , and  $t_{2u}$  triply degenerate orbitals are split by ca. 1 eV upon the reduction from  $O_h$  symmetry that occurs when the U-O-R bonds are bent. The t<sub>2g</sub> orbital undergoes a significantly larger splitting of 3-4 eV, due to strong interaction with the ligand  $\sigma$  orbitals.

These two effects, the donation from oxygen lone-pair orbitals into empty uranium MOs and the splitting due to reduction of symmetry upon U-O-C bending, provide an excellent basis for interpretation of the He I/He II PE spectra for U(OCH<sub>3</sub>)<sub>3</sub>.  $\sigma$ - and  $\pi$ -donation from the methyl groups into the O 2p orbitals increases the donor strength of the alkoxide group and enhances these effects relative to U(OH)<sub>6</sub>. The agreement between predicted and measured transitions is shown in Figure 11; the good agreement shows that the bonding information obtained from the QR-MS model can be useful in predicting the relative orbital energetics of actinide alkoxides.

The bonding in homoleptic tetravalent complexes of the borohydride ligand has been investigated by a variety of methods. Only seven  $M(BH_4)_4$  compounds are known; five of these involve actinides (M = Th through

![](_page_18_Figure_9.jpeg)

Figure 11. Comparison between experimental and QR-MS calculated transition-state ionization energies of U(OCH<sub>3</sub>)<sub>6</sub>, showing reasonable agreement between MO theory and experiment.<sup>235</sup>

Pu) and two contain transition metals (M = Zr, Hf). The actinide complexes contain four trihapto BH<sub>4</sub> ligands in which 12 hydrogen atoms are bound to the metal in rigorously tetrahedral symmetry.<sup>237</sup> These tetrakis(tetrahydroborates) are of interest because their physical and chemical properties, including high volatility and solubility in nonpolar solvents, point to strong covalent bonding. Thus, a comparison of transition metal and actinide tetrahydroborates could aid in understanding covalent d and f interactions. The REX approach was applied to U(BH<sub>4</sub>)<sub>4</sub>,<sup>122</sup> QR-MS calculations were used to study the Zr, Hf, Th, and U compounds,<sup>238</sup> and the DS-DV method was applied to the Zr and U systems.<sup>239</sup>

In spite of the observed covalent properties, U(BH<sub>4</sub>)<sub>4</sub> was found to be an essentially ionic 5f<sup>2</sup> system in the REX studies. The total 5f population was 2.03; further, the inclusion of 5f orbitals in the calculation had no impact upon the bond lengths, indicating a lack of 5f participation in bonding. The REX calculations were able to reproduce the main features of the PE spectrum, including the spin-orbit splitting of the HOMO.

QR-MS calculations<sup>238</sup> resulted in a description of the transition-metal compounds as tetrahedrally coordinated d<sup>0</sup> complexes with strong covalent  $\pi$ -bonding interactions between the ligand and metal orbitals. These  $\pi$  interactions lead to differences in orbital ordering relative to tetrahedral transition-metal  $\sigma$  complexes. Similar  $\pi$ -covalency was found for the actinide systems, with bonding dominated by metal 6d interactions. The importance of 5f orbitals in metal-ligand bonding was not negligible, but was of lesser importance than in the actinocenes.

Ligand field splittings for the 5f<sup>2</sup> orbitals were predicted in the QR-MS study, and were in good agreement with experimental values, in spite of the fact that the important spin-orbit splitting effects were not included in the calculations. Further, the spin-orbit constant estimated from the charge fraction localized within the uranium sphere (1740 cm<sup>-1</sup>) was in remarkable agreement with the experimental value (1782 cm<sup>-1</sup>).

The possible inadequacy of the muffin-tin approach in describing the rather open tetrahedral structure of the tetrakis(tetrahydroborates) was pointed out by Hohl, Ellis, and Rösch.<sup>239</sup> They conducted DS-DV calculations on Zr(BH<sub>4</sub>)<sub>4</sub> and U(BH<sub>4</sub>)<sub>4</sub>, as well as a nonrelativistic computation for the uranium compound. The results of these DV calculations supported the conclusions of the QR-MS results, indicating strong  $\pi$ -bonding due to the BH<sub>4</sub> ligands. The DV calculations led to improved agreement with experimental PES data, as compared with the QR-MS study. Further, the nonrelativistic calculation was found to overestimate the importance of U 5f contributions to bonding, giving a 5f population of 3.27 as compared with a relativistic value of 2.43. The U 6d participation was correspondingly underestimated (nonrelativistic = 1.11; relativistic = 1.30). This necessity for relativistic treatment parallels that observed in actinocene calculations, as well as in other actinide systems.

#### X. Conclusions

In summary, we find that computational results have played a central role in understanding actinide chemistry. Chemists have focused primarily on bonding interactions and interpretation of optical spectra, and molecular orbital methods have proved sufficient for such studies. Relativistic effects are unquestionably necessary for quantitative results; even qualitative conclusions are questionable when relativity is not considered. Relativistic core potentials have provided a way to incorporate these crucial effects, while at the same time reducing the computational effort of ab initio calculations to a tractable size. Although RCP ab initio methods have been applied extensively to main-group and transition-metal systems, they are in a formative stage in the study of actinide complexes. The potential for constructing accurate potential energy surfaces and predicting molecular geometries gives these methods one of their principal advantages over more approximate molecular orbital approaches, and these benefits will doubtless be exploited in the next several years. The capability of ab initio methods to provide precise information on ground- and excited-state symmetries was certainly demonstrated by the recent study of uranocene by Chang and Pitzer. 108 Beyond this single investigation, however, ab initio methods have not been used to any great degree in studies of organoactinide chemistry; this is certainly a potentially fruitful area for future work.

Recent developments in density functional theory, including improved functionals and methods for the accurate calculation of binding energies, also bode well for computational actinide chemistry. These methods have the advantage of providing easily interpreted information about bonding interactions in actinide systems, and have proved useful for many years in organotransition metal and organoactinide chemistry. Again, the improved approaches are just beginning to be applied to actinide systems, with promising results. The combination of LDF molecular orbital and binding energy information with ab initio potential energy surfaces and identification of excited states should provide chemists with a wealth of information on these interesting systems whose chemistry has yet to be fully explored. We expect this field to be a challenging and exciting one for applied quantum chemistry as it approaches the 21st century.

Acknowledgments. The authors gratefully acknowledge the support of our actinide research by the U.S. Department of Energy and the Ohio Supercomputer Center. We are grateful to Dr. William F. Schneider for lively and challenging discussions of all aspects of computational actinide chemistry and for helpful suggestions during preparation of the manuscript. We thank Dr. Richard Ross for commenting on our discussion of relativistic core potentials.

#### References

- Dirac, P. A. M. Proc. Roy. Soc. Ser. A 1929, 123, 714-733.
   Coulson, C. A. Rev. Mod. Phys. 1960, 32, 170-177.
- Coulson's after-dinner remarks bring to mind that chemistry is not the only area in which progress has been made in the past 30 years: "Lastly—since this is the first conference of this kind at which so many wives and families have been present—an apology is now due to all our lady friends..." The authors respectfully note that the National Organization for

- authors respectfully note that the National Organization for Women was not founded until 1966.

  (4) Boys, S. F. Proc. Roy. Soc. Ser. A 1950, 200, 542-554.

  (5) Parr, R. G. Proc. Nat. Acad. Sci. U.S.A. 1975, 72, 763-771.

  (6) Mulliken, R. S. Science 1967, 157, 13-24.

  (7) Clementi, E. J. Phys. Chem. 1980, 84, 2122-2134.

  (8) Proceedings of the Robert A. Welch Foundation Conferences on Chemical Research XVI. Theoretical Chemistry; Robert A. Welch Foundation: Houston, 1973; p 117.

  (9) Karplus, M. J. Phys. Chem. 1990, 94, 5435-5436.

  (10) Johnson, K. H. J. Chem. Phys. 1966, 45, 3085-3095.

  (11) (a) Ellis, D. E. Int. J. Quantum. Chem. Symp. 1968, 2, 35.
- (a) Ellis, D. E. Int. J. Quantum. Chem. Symp. 1968, 2, 35. (b) Painter, G. S.; Ellis, D. E. Int. J. Quantum Chem. Symp. 1970, 3, 801–805. (c) Ellis, D. E.; Painter, G. S. Phys. Rev. B 1970, 2, 2887–2898.
- (12) Baerends, E. J.; Ellis, D. E.; Ros, P. Chem. Phys. 1973, 2,
- (13) (a) Lohr, L. L., Jr.; Pyykkö, P. Chem. Phys. Lett. 1979, 62, 333-338. (b) Pyykkö, P. In Methods in Computational Chemistry; Wilson, S., Ed.; Plenum: New York, 1988; Vol. 2, pp 136-226.
- 2, pp 136-226.
  (14) Mackrodt, W. C. Mol. Phys. 1970, 18, 697-709.
  (15) (a) Yang, C. Y.; Rabii, S. Phys. Rev. A 1975, 12, 362-369. (b) Yang, C. Y. J. Chem. Phys. 1978, 68, 2626-2629.
  (16) (a) Rosén, A.; Ellis, D. E. Chem. Phys. Letters 1974, 27, 595-599. (b) J. Chem. Phys. 1975, 62, 3039-3049.
  (17) Koelling, D. D.; Harmon, B. N. J. Phys. C. 1977, 10, 3107-3114.
- 3107-3114.

- (18) Boring, M.; Wood, J. H. J. Chem. Phys. 1979, 71, 392-399.
   (19) Wood, J. H.; Boring, A. M. Phys. Rev. B 1978, 18, 2701-2711.
   (20) Boring, M.; Wood, J. H. J. Chem. Phys. 1979, 71, 32-41.
   (21) Thornton, G.; Edelstein, N.; Rösch, N.; Egdell, R. G.; Woodwark, D. R. J. Chem. Phys. 1979, 70, 5218-5221.
- Thornton, G.; Rösch, N.; Edelstein, N. Inorg. Chem. 1980, 19, (22)1304-1307
- Snijders, J. G.; Baerends, E. J.; Ros, P. Mol. Phys. 1979, 38, 1909–1929. (23)
- Snijders, 2 1789-1804. (24)J. G.; Baerends, E. J. Mol. Phys. 1978, 36,
- (25) Ziegler, T.; Tschinke, V.; Baerends, E. J.; Snijders, J. G.; Ravenek, W. J. Phys. Chem. 1989, 93, 3050-3056.
  (26) Das, G.; Wahl, A. C. J. Chem. Phys. 1976, 64, 4672-4679.
  (27) Kahn, L. R.; Hay, P. J.; Cowan, R. D. J. Chem. Phys. 1978, capes 2020. 68, 2386-2397.
- Lee, Y. S.; Ermler, W. C.; Pitzer, K. S. J. Chem. Phys. 1977, 67, 5861-5876.

- Powell, R. E. J. Chem. Ed. 1968, 45, 558-563. Pyykkö, P. Adv. Quantum Chem. 1978, 11, 353-409. Pitzer, K. S. Acc. Chem. Res. 1979, 12, 271-276. Pyykkö, P.; Desclaux, J.-P. Acc. Chem. Res. 1979, 12, (32)276-281
- (33) Relativistic Effects in Atoms, Molecules and Solids, Malli, G. L., Ed.; Plenum: New York, 1983. (34) Krauss, M.; Stevens, W. J. Ann. Rev. Phys. Chem. 1984, 35,
- 357-385
- (35) Christiansen, P. A.; Ermler, W. C.; Pitzer, K. S. Ann. Rev. Phys. Chem. 1985, 36, 407-432.
   (36) Balasubramanian, K.; Pitzer, K. S. Adv. Chem. Phys. 1987, 2022.

- Pyykkö, P. Inorg. Chim. Acta 1987, 139, 243-245. Ermler, W. C.; Ross, R. B.; Christiansen, P. A. Adv. Quantum Chem. 1988, 19, 139-182.
- (39) Pyykkö, P. Chem. Rev. 1988, 88, 563-594.

- (40) Pyykkö, P., Ed. Int. J. Quantum Chem. Symp. 1984, 25,
- (41) Pyykkö, P. Relativistic Theory of Atoms and Molecules. A Bibliography 1916-1985. In Lecture Notes in Chemistry; Springer: Berlin, 1986; Vol. 41.
- (42) Jørgensen, C. K.; Reisfeld, R. J. Electrochem. Soc. 1983, 130,
- (43) Streitwieser, A., Jr.; Müller-Westerhoff, U. J. Am. Chem. Soc. 1968, 90, 7364
- (44) Denning, R. G.; Snellgrove, T. R.; Woodwark, D. R. Mol. Phys. 1979, 37, 1109-1143.
   (45) Barker, T. J.; Denning, R. G.; Thorne, J. R. G. Inorg. Chem.
- 1987, 26, 1721-1732.
- (46) Jørgensen, C. K.; Reisfeld, R. Struct. Bonding 1982, 50, 121–171.
- (47) Jørgensen, C. K. Chem. Phys. Lett. 1982, 89, 455-458.
  (48) Van Vleck, J. H. J. Chem. Phys. 1935, 3, 803-806.
  (49) Street, K., Jr.; Seaborg, G. T. J. Am. Chem. Soc. 1950, 72,

- (50) Glueckauf, E.; McKay, H. A. C. Nature 1950, 165, 594-595.
  (51) Katzin, L. I. Nature 1950, 166, 605.
  (52) Glueckauf, E.; McKay, H. A. C. Nature 1950, 166, 605-606.
  (53) Connick, R. E.; Hugus, Z. Z., Jr. J. Am. Chem. Soc. 1952, 74,
- 6012-6015
- (54) Diamond, R. M.; Street, K., Jr.; Seaborg, G. T. J. Am. Chem. Soc. 1954, 76, 1461-1469.

- Soc. 1954, 76, 1461-1469.

  (55) Eisenstein, J. C. J. Chem. Phys. 1956, 25, 142-146.

  (56) Kettle, S. F. A.; Smith, A. J. J. Chem. Soc. A 1967, 688-692.

  (57) Kettle, S. F. A.; Pioli, A. J. P. J. Chem. Soc. A 1968, 122-125.

  (58) Burns, C. J.; Bursten, B. E. Comm. Inorg. Chem. 1989, 2, 61.

  (59) Sockwell, S. C.; Hanusa, T. P. Inorg. Chem. 1990, 29, 76-80.

  (60) Marks, T. J. Prog. Inorg. Chem. 1979, 25, 223-333.

  (61) Organometallics of the f Elements; Marks, T. J., Fischer, R. D., Eds.; Reidel: Dordrecht, 1979.
- D., Eds.; Reidel: Dordrecht, 1979.
  Marks, T. J.; Ernst, R. D. In Comprehensive Organometallic Chemistry; Wilkinson, G., Stone, F. G. A.; Abel, E. W., Eds.; Pergamon Press: Oxford, 1982; Vol. 3, pp 173-270.
  Fundamental and Technological Aspects of Organo-f-Element Chemistry; Marks, T. J., Fragalà, I. L., Eds.; Reidel: Dordrecht, 1985.
  Marks, T. L. Statispician A. J. In The Chemistry of the

- Dordrecht, 1985.

  (64) Marks, T. J.; Streitweiser, A., Jr. In The Chemistry of the Actinide Elements, Katz, J. J., Morss, L. R., Seaborg, G. T., Eds.; Chapman and Hall: New York, 1986; Chapter 22.

  (65) Marks, T. J. In The Chemistry of the Actinide Elements; Katz, J. J., Morss, L. R., Seaborg, G. T., Eds.; Chapman and Hall: New York, 1986; Chapter 23.

  (66) Marks, T. J. Science 1982, 217, 989-997.

  (67) Bursten, B. E.; Strittmatter, R. J. Angew. Chem., in press.

  (68) See, for example: (a) Weinberger, P. In Handbook on the Physics and Chemistry of the Actinides, Freeman, A. J., Lander, G. H., Eds.; North-Holland: Amsterdam, 1987; Vol. 5, pp 1-84. (b) The Chemistry of the Actinide Elements; Katz, J. J., Morss, L. R., Seaborg, G. T., Eds.; Chapman and Hall: New York, 1986; Chapters 14 (Summary and comparative aspects of the actinide elements), 18 (Magnetic properties), 19 (The metallic state), and 20 (Structural chemistry). (c) For a brief history of solid-state quantum chemical de-(c) For a brief history of solid-state quantum chemistry). (c) For a brief history of solid-state quantum chemical developments, see ref 30, p 369.

  (69) Fanning, M. O.; Fitzpatrick, N. J. Int. J. Quantum Chem. 1980, 18, 1339-1359.

- (70) Boca, R. Int. J. Quantum Chem. 1987, 31, 941-950.
  (71) Glebov, V. A. Koord. Khim. 1981, 6, 1852.
  (72) Glebov, V. A.; Nefedov, V. S. Koord. Khim. 1981, 7, 1664-1672.
- (73) Glebov, V. A.; Nefedov, V. S. Koord. Khim. 1981, 7, 1673-1681.
- (74) Goddard, W. A., III; Dunning, T. H., Jr.; Hunt, W. J.; Hay, P. J. Acc. Chem. Res. 1973, 6, 368-376.
- (75) Desclaux, J.-P. Atom. Data and Nuclear Data 1973, 12, 311-406.
- (76) Case, D. A.; Yang, C. Y. J. Chem. Phys. 1980, 72, 3443-3448.
  (77) Wolfsberg, M.; Helmholtz, L. J. Chem. Phys. 1952, 20,
- Hoffmann, R. J. Chem. Phys. 1963, 39, 1397-1412.
- Manne, R.; Wittel, K.; Mohanty, B. S. Mol. Phys. 1975, 29, 485-500.
- (80) Lohr, L. L., Jr.; Hotokka, M.; Pyykkö, P. Int. J. Quantum Chem. 1980, 18, 347-355.
  (81) Albasiny, E. L.; Cooper, J. R. A. Proc. Phys. Soc. 1963, 82, 289.

- (82) Slater, J. C. Phys. Rev. 1951, 81, 385-390.
  (83) Hohenberg, P.; Kohn, W. Phys. Rev. B 1964, 136, 864-871.
  (84) Hedin, L.; Lundqvist, B. I. J. Phys. C 1971, 4, 2064-2083.
  (85) MacDonald, A. H.; Vosko, S. H. J. Phys. C 1979, 12, 2977-2990.
  (86) Beske A. J. Cham. Phys. 1882, 24, 4764, 4762.
- Becke, A. J. Chem. Phys. 1986, 84, 4524-4529.
  Slater, J. C. Quantum Theory of Molecules and Solids;
  McGraw-Hill: New York, 1974; Vol. 4, pp 51-55.
  Cowan, R. D.; Griffin, D. C. J. Opt. Soc. Am. 1976, 66, (87)
- 1010-1014.

- (89) Soldatov, A. A. Zh. Strukt. Khim. 1985, 26, 3-7.
  (90) Baerends, E. J.; Ros, P. Int. J. Quantum Chem. Symp. 1978,
- (90) Baerends, E. J.; Ros, F. Int. J. Quantum Chem. Symp. 1918, 12, 169-190.
  (91) Foldy, L. L.; Wouthuysen, S. A. Phys. Rev. 1950, 78, 29-36.
  (92) (a) Ziegler, T.; Snijders, J. G.; Baerends, E. J. Chem. Phys. Lett. 1980, 75, 1-4. (b) J. Chem. Phys. 1981, 74, 1271-1284.
  (93) (a) Hellmann, H. J. Chem. Phys. 1935, 3, 61. (b) Hellmann, H.; Kassatotschkin, W. J. Chem. Phys. 1936, 4, 324-325. (c)

- Gombas, P. Z. Phys. 1935, 94, 473-488.

  (94) Phillips, J. C.; Kleinman, L. Phys. Rev. 1959, 116, 287-294.

  (95) Weeks, J. D.; Rice, S. A. J. Chem. Phys. 1968, 49, 2741-2755.

  (96) Goddard, W. A., III. Phys. Rev. 1968, 174, 659-662.

  (97) Christiansen, P. A.; Lee, Y. S.; Pitzer, K. S. J. Chem. Phys. 1979, 71, 4445-4450.
- (98) Hay, P. J. Unpublished results.
  (99) (a) Hafner, P.; Schwarz, W. H. E. Chem. Phys. Lett. 1979, 65, 537-541.
  (b) J. Phys. B. 1978, 11, 217-233.
  (c) Esser, M.; Butscher, W.; Schwarz, W. H. E. Chem. Phys. Lett. 1981, 77,

- 309-364.
  (100) Kahn, L. R. Int. J. Quantum Chem. 1984, 25, 149-183.
  (101) Hay, P. J.; Wadt, W. R.; Kahn, L. R.; Bobrowicz, F. W. J. Chem. Phys. 1978, 69, 984-997.
  (102) (a) Hay, P. J.; Wadt, W. R. J. Chem. Phys. 1985, 82, 270-283.
  (b) Hay, P. J.; Wadt, W. R. J. Chem. Phys. 1985, 82, 299-310.
  (c) Wadt, W. R.; Hay, P. J. J. Chem. Phys. 1985, 82, 284-298.
  (103) Lee, Y. S.; Ermler, W. C.; Pitzer, K. S. J. Chem. Phys. 1980, 73, 360-366.
  (104) Christiana R. A. Pitzer, K. S. J. Chem. Phys. 1980, 78
- (104) Christiansen, P. A.; Pitzer, K. S. J. Chem. Phys. 1980, 73, 5160-5163
- (105) Ermler, W. C.; Christiansen, P. A.; Ross, R. B. Int. J. Quan-
- tum Chem., in press.
  (106) Ermler, W. C.; Lee, Y. S.; Christiansen, P. A.; Pitzer, K. S. Chem. Phys. Lett. 1981, 81, 70-74.
  (107) Pitzer, R. M.; Winter, N. W. J. Phys. Chem. 1988, 92,
- 3061-3063 (108) Chang, A. H. H.; Pitzer, R. M. J. Am. Chem. Soc. 1989, 111, 2500-2507.

- (109) Lee, Y. S.; McLean, A. D. J. Chem. Phys. 1982, 76, 735-736. (110) Krauss, M.; Stevens, W. J. Comput. Chem. 1983, 4, 127-135. (111) Pyykkö, P.; Desclaux, J.-P. Chem. Phys. 1978, 34, 261-280. (112) Pyykkö, P. J. Chem. Soc. Faraday Trans. 2 1979, 75, 1256-1276.
- (113) Pyykkö, P. Phys. Scripta 1979, 20, 647-651.
- (114) Heslop, R. B.; Jones, K. Inorganic Chemistry; Elsevier: Amsterdam, 1976; p 610.
- (115) Boring, M.; Moskowitz, J. W. Chem. Phys. Lett. 1976, 38, 185-187.
- (116) Boring, M.; Hecht, H. G. J. Chem. Phys. 1978, 69, 112-116.
  (117) Maylotte, D. H.; St. Peters, R. L.; Messmer, R. P. Chem. Phys. Lett. 1976, 38, 181-184.
- (118) Schneider, B.; Boring, A. M.; Cohen, J. S. Chem. Phys. Lett. 1974, 27, 577-579.

- 1974, 27, 577-579.

  (119) Koelling, D. D.; Ellis, D. E.; Bartlett, R. J. J. Chem. Phys. 1976, 65, 3331-3340.

  (120) Kim, B.-I.; Adachi, H.; Imoto, S. Chem. Lett. 1977, 109-112.

  (121) Rosen, A. Chem. Phys. Lett. 1978, 55, 311-314.

  (122) Pyykkö, P.; Lohr, L. L., Jr. Inorg. Chem. 1981, 20, 1950-1959.

  (123) Larsson, S.; Tse, J. S.; Esquivel, J. L.; Tang Kai, A. Chem. Phys. 1984, 89, 43-50.

  (124) Larsson, S.; Pyykkö, P. Chem. Phys. 1986, 101, 355-369.

  (125) Rösch, N.; Pyykkö, P. Mol. Phys. 1986, 57, 193-200.

  (126) Hay, P. J.; Wadt, W. R.; Kahn, L. R.; Raffenetti, R. C.; Phillips, D. H. J. Chem. Phys. 1979, 71, 1767-1779.

  (127) Hay, P. J. J. Chem. Phys. 1983, 79, 5469-5482.

  (128) See refs 115 and 116 for a reinterpretation of the available

- (128) See refs 115 and 116 for a reinterpretation of the available
- pectroscopic data.

- spectroscopic data.
  (129) Karlsson, L.; Mattson, L.; Jadrny, R.; Bergmark, T.; Siegbahn, K. Phys. Scr. 1976, 14, 230.
  (130) Boring, M.; Wood, J. H.; Moskowitz, J. W. J. Chem. Phys. 1974, 61, 3800-3803.
  (131) Wadt, W. R. J. Chem. Phys. 1987, 86, 339-346.
  (132) Kugel, R.; Williams, C.; Fred, M.; Malm, J. G.; Carnall, W. T.; Hindman, J. C.; Childs, W. J.; Goodman, L. S. J. Chem. Phys. 1976, 65, 3486-3492.
  (133) Wadt W. R.; Hay, P. J. J. Am. Chem. Soc. 1979, 101.
- (133) Wadt, W. R.; Hay, P. J. J. Am. Chem. Soc. 1979, 101, 5198-5206.
- (134) Rosén, A.; Fricke, B. Chem. Phys. Lett. 1979, 61, 75-78.
  (135) Dyke, J. M.; Fayad, N. K.; Morris, A.; Trickle, I. R.; Allen, G. C. J. Chem. Phys. 1980, 72, 3822-3827.
  (136) Ellis, D. E.; Rosén, A.; Gubanov, V. A. J. Chem. Phys. 1982, 77, 4051 4060.
- *77*, 4051–4060
- (137) Ellis, D. E.; Holland, G. F. Chem. Scr. 1986, 26, 441-448. (138) Topol', I. A.; Zhilinskii, B. I. Teor. Eksp. Khim. 1984, 20,
- 406–415. (139) Boerrigter, P. M. Thesis, 1987, Vrije Universiteit, Amsterdam.
- (140) Boerrigter, P. M.; Snijders, J. G. J. Elect. Spect. Rel. Phen. 1988, 46, 43.
- (141) Case, D. A. J. Chem. Phys. 1985, 83, 5792-5796.

- (142) Arratia-Perez, R.; Marynick, D. S. Phys. Rev. B 1988, 37, 4893-4899

- (143) Newman, J. B. J. Chem. Phys. 1965, 43, 1691-1694.
  (144) McGlynn, S. P.; Smith, J. K. J. Mol. Spectrosc. 1961, 6, 164.
  (145) Elliott, R. J. Phys. Rev. 1953, 89, 659-660.
  (146) Eisenstein, J. C.; Pryce, M. H. L., F. R. S. Proc. Roy. Soc. A
- (146) Eisenstein, J. C.; Pryce, M. H. L., F. R. S. Proc. Roy. Soc. A 1955, 229, 20-38.
  (147) Coulson, C. A.; Lester, G. R. J. Chem. Soc. 1956, 3650-3659.
  (148) Boring, M.; Wood, J. H.; Moskowitz, J. W. J. Chem. Phys. 1975, 63, 638-642.
  (149) Wood, J. H.; Boring, M.; Woodruff, S. B. J. Chem. Phys. 1981, 74, 5225-5233.
  (150) Yang, C. Y.; Johnson, K. H.; Horsley, J. A. J. Chem. Phys. 1978, 68, 1001-1005.
  (151) Ellis D. F.; Porta, A.; Wolch, P. F. Int. J. Overture Chem.

- 1978, 68, 1001-1005.
  (151) Ellis, D. E.; Rosén, A.; Walch, P. F. Int. J. Quantum Chem. Symp. 1975, 9, 351-358.
  (152) Walch, P. F.; Ellis, D. E. J. Chem. Phys. 1976, 65, 2387-2392.
  (153) Wadt, W. R. J. Am. Chem. Soc. 1981, 103, 6053-6057.
  (154) DeKock, R. L.; Baerends, E. J.; Boerrigter, P. M.; Snijders, J. G. Chem. Phys. Lett. 1984, 105, 308-316.
  (155) Tatanini K. Haffmann, P. Ingg. Chem. 1980, 19, 2656-2658.
- (155) Tatsumi, K.; Hoffmann, R. Inorg. Chem. 1980, 19, 2656-2658.
   (156) Pyykkö, P.; Laaksonen, L. J. Phys. Chem. 1984, 88, 4892–4895.
- (157) Pyykkö, P.; Laakkonen, L.; Tatsumi, K. Inorg. Chem. 1989, 28, 1801–1805.
- 28, 1801-1805.
   Veal, B. W.; Lam, D. J.; Carnall, W. T.; Hoekstra, H. R. Phys. Rev. B 1975, 12, 5651-5663.
   Cox, L. E. J. Elect. Spect. Rel. Phen. 1982, 26, 167-171.
   Gmelin Handbook of Inorganic Chemistry; Springer Verlag: West Berlin, 1983; U Supplement A6.
   Gabelnick, S. D.; Reedy, G. T.; Chasanov, M. G. J. Chem. Phys. 1974, 60, 1167-1171.
   Marian, C. M.; Wahlgren, U.; Gropen, O.; Pyykkö, P. J. Mol. Struct. (THEOCHEM) 1988, 169, 339-354.
   Krauss, M.; Stevens, W. J. Chem. Phys. Lett. 1983, 99, 417-421.
   Almlöf, J.; Fægri, K., Jr.; Grelland, H. H. Chem. Phys. Lett.

- (164) Almlöf, J.; Fægri, K., Jr.; Grelland, H. H. Chem. Phys. Lett.
- 1985, 114, 53-57. (165) Heera, V.; Seifert, G.; Ziesche, P. Phys. Stat. Sol. B 1983, 118, K107-K112; Phys. Stat. Sol. B 1983, 119, K1-K4. (166) Gubanov, V. A.; Rosén, A.; Ellis, D. E. Solid State Commun.
- 1**977**, *22*, 219–2 (167) Gubanov, V. A.; Rosén, A.; Ellis, D. E. J. Inorg. Nucl. Chem.
- 1979, 41, 975-986
- (168) Gubanov, V. A.; Rosén, A.; Ellis, D. E. J. Phys. Chem. Solids 1979, 40, 17-28. (169) Ellis, D. E.; Goodman, G. L. Int. J. Quantum Chem. 1984, 25,
- 185-200. (170) Ellis, D. E.; Gubanov, V. A.; Rosen, A. J. Phys. Colloq. C4
- 1979, 40, 187. (171) Weber, J.; Gubanov, V. A. J. Inorg. Nucl. Chem. 1979, 41,
- 693-699.
- (172) Allen, G. C.; Baerends, E. J.; Vernooijs, P.; Dyke, J. M.; Ellis, A. M.; Fehér, M.; Morris, A. J. Chem. Phys. 1988, 89,
- (173) Makhyoun, M. A. Inorg. Chem. 1987, 26, 3592-3595.
  (174) Borhovskii, N. B.; Lyudchik, A. M. Dokl. Akad. Nauk. Belor. SSR 1985, 29, 137.
- SSR 1985, 29, 137.
  Hutchinson, D. A.; Chen, K. S.; Russell, J.; Wan, J. K. S. J. Chem. Phys. 1980, 73, 1862-1866.
  (176) (a) Kealy, T. J.; Pauson, P. L. Nature 1951, 168, 1039-1040.
  (b) Miller, S. A.; Tebboth, J. A.; Tremaine, J. F. J. Chem. Soc. 1952, 632-635. (c) Wilkinson, G.; Rosenblum, M.; Whiting, M. C.; Woodward, R. B. J. Am. Chem. Soc. 1952, 74, 2125-2126. (d) Fischer, E. O.; Pfab, W. Z. Naturforsch. 1952, 78, 377-379.
- 1952, 7B, 377-379. (177) Moffitt, W. In Reynolds, L. T.; Wilkinson, G. J. Inorg. Nucl.
- Chem. 1956, 2, 246-253.
  (178) Raymond, K. N.; Eigenbrot, C. W., Jr. Acc. Chem. Res. 1980, 3, 276-283
- (179) Marçalo, J.; Pires De Matos, A. Polyhedron 1989, 8, 2431.
  (180) Tatsumi, K.; Hoffmann, R. Inorg. Chem. 1984, 23, 1633-1634.
  (181) Tatsumi, K.; Nakamura, A. J. Organomet. Chem. 1984, 272, 41-154.
- (182) Amberger, H.-D. J. Organomet. Chem. 1976, 110, 59-66.
   (183) Amberger, H.-D.; Fischer, R. D.; Kanellakopulos, B. Z. Naturforsch. B 1976, 31, 12-21.
- (184) Bursten, B. E.; Casarin, M.; DiBella, S.; Fang, A.; Fragalà, I. *Inorg. Chem.* 1985, 24, 2169–2173.
- (185) Bursten, B. E.; Fang, A. Inorg. Chim. Acta 1985, 110, 53-160.
- (186) Bursten, B. E.; Rhodes, L. F.; Strittmatter, R. J. J. Am.
- Chem. Soc. 1989, 111, 2756-2758.

  (187) Bursten, B. E.; Rhodes, L. F.; Strittmatter, R. J. J. Am. Chem. Soc. 1989, 111, 2758-2766.

  (188) Vittadini, A.; Casarin, M.; Ajò, D.; Bertoncello, M.; Ciliberto, E.; Gulino, A.; Fragalà, I. Inorg. Chim. Acta 1986, 121, L23-768. L25.
- (189) Cramer, R. E.; Maynard, R. B.; Paw, J. C.; Gilje, J. W. J. Am. Chem. Soc. 1981, 103, 3589-3590.

- (190) Cramer, R. E.; Edelmann, F.; Mori, A. L.; Roth, S.; Gilje, J. W.; Tatsumi, K.; Nakamura, A. Organometallics 1988, 7, 841-849.
- (191) Gassman, P. G.; Macomber, D. W.; Hershberger, J. W. Organometallics 1983, 2, 1470-1472.
  (192) Tatsumi, K.; Nakamura, A. J. Am. Chem. Soc. 1987, 109,
- 3195-3206
- (193) Tatsumi, K.; Nakamura, A. Organometallics 1987, 6, 427–428.
- (194) Tatsumi, K.; Nakamura, A.; Hofmann, P.; Stauffert, P.; Hoffmann, R. J. Am. Chem. Soc. 1985, 107, 4440-4451.
   (195) Hofmann, P.; Stauffert, P.; Tatsumi, K.; Nakamura, A.; Hoffmann, R. Organometallics 1985, 4, 404-406.
- Tatsumi, K.; Nakamura, A.; Hofmann, P.; Hoffmann, R.; Moloy, K. G.; Marks, T. J. J. Am. Chem. Soc. 1986, 108, 4467-4476.
- (197) Tatsumi, K.; Nakamura, A. Inorg. Chim. Acta 1987, 139, 247-251.
- (198) Bursten, B. E.; Fang, A. J. Am. Chem. Soc. 1983, 105, 6495-6496
- (199) Cramer, R. E.; Mori, A. L.; Maynard, R. B.; Gilje, J. W.; Tatsumi, K.; Nakamura, A. J. Am. Chem. Soc. 1984, 106, 5920-5926.
- (200) (a) Laubereau, P. G.; Burns, J. H. Inorg. Nucl. Chem. Letters 1970, 6, 59-63.
  (b) Baumgärtner, F.; Fischer, E. O.; Billich, H.; Dornberger, E.; Kanellakopulos, B.; Roth, W.; Stieglitz, L. J. Organometal. Chem. 1970, 22, C17-C18.
- (201) Laubereau, P. G.; Burns, J. H. Inorg. Chem. 1970, 9, 1091-1095.
- (202) Strittmatter, R. J. Ph.D. Dissertation 1990, The Ohio State
- University, Columbus, OH.

  (203) Schneider, W. F.; Strittmatter, R. J.; Bursten, B. E.; Ellis, D.
  E. In Density Functional Methods in Chemistry; Labanow ski, J. K., Andzelm, J. W., Eds.; Springer-Verlag: New York, 1991; pp 247-260.

  (204) Bursten, B. E.; Rhodes, L. F.; Strittmatter, R. J. J. Less-Common Met. 1989, 149, 207-211.
- (205) Strittmatter, R. J.; Bursten, B. E. J. Am. Chem. Soc. 1991, 113, 552-559.
- (206) (a) Brennan, J. G. Ph.D. Dissertation 1985, University of California, Berkeley. (b) Brennan, J. G.; Stults, S. D.; Andersen, R. A.; Zalkin, A. Organometallics 1988, 7, 1329–1334.
  (207) Brennan, J. G.; Andersen, R. A.; Robbins, J. L. J. Am. Chem.
- Soc. 1986, 108, 335-336. (208) Bursten, B. E.; Strittmatter, R. J. J. Am. Chem. Soc. 1987,
- 109, 6606-6608. (209) Zalkin, A.; Raymond, K. N. J. Am. Chem. Soc. 1969, 91,
- 5667-5668.
- (210) Streitwieser, A., Jr.; Yoshida, N. J. Am. Chem. Soc. 1969, 91, 7528.
- (211) Goffart, J.; Fuger, J.; Brown, D.; Duyckaerts, G. Inorg. Nucl.
- (212) Karraker, D. G.; Stone, J. A.; Jones, E. R., Jr.; Edelstein, N. J. Am. Chem. Soc. 1970, 92, 4841-4845.
   (213) See, for example: (a) Dallinger, R. F.; Stein, P.; Spiro, T. G. J. Am. Chem. Soc. 1978, 100, 7865-7870. (b) Luke, W. D.; Streitwieser, A., Jr. In Lanthanide and Actinide Chemistry and Spectroscopy; Edelstein, N. M., Ed.; ACS Symposium Series 131; American Chemical Society: Washington, 1980;
- pp 93-140. Warren, K. D. Struct. Bonding 1977, 33, 97-138
- (215) Fischer, R. D. Theor. Chim. Acta (Berlin) 1963, 1, 418-431. (216) Amberger, H.-D.; Fischer, R. D.; Kanellakopulos, B. Theoret.
- Chim. Acta (Berlin) 1975, 37, 105–127 (217) Hayes, R. G.; Edelstein, N. J. Am. Chem. Soc. 1972, 94,
- 8688-8691. (218) Rösch, N.; Streitwieser, A., Jr. J. Organomet. Chem. 1978,
- *14*5, 195–200.
- (219) Rösch, N.; Streitwieser, A., Jr. J. Am. Chem. Soc. 1983, 105, 7237-7240.

- (220) Rösch, N. Inorg. Chim. Acta 1984, 94, 297-299.
  (221) Boerrigter, P. M.; Baerends, E. J.; Snijders, J. G. Chem. Phys. 1988, 122, 357-374.
  (222) (a) Clark, J. P.; Green, J. C. J. Organometal. Chem. 1976, 112, C14-C16. (b) Fragalà, I.; Condorelli, G.; Zanella, P.; Tondella, E. J. Organometal. Chem. 1976, 122, 357-363. (c) Clark, J. P.; Green, J. C. J. Chem. Soc. Dalton Trans. 1977, 505-508. (d) Brennan, J. G.; Green, J. C.; Redfern, C. M. J. 505-508. (d) Brennan, J. G.; Green, J. C.; Redfern, C. M. J. Am. Chem. Soc. 1989, 111, 2373-2377.
- (223) Bursten, B. E.; Ozin, G. A. Inorg. Chem. 1984, 23, 2910-2911.
  (224) Pepper, M.; Bursten, B. E. J. Am. Chem. Soc. 1990, 112, 7803-7804.
- (225) (a) Mucci, J. F.; March, N. H. J. Chem. Phys. 1985, 82, 5099. (b) Pucci, R.; March, N. H. Phys. Rev. A 1986, 33, 3511-3514.
  (226) Gingerich, K. A. Symp. Faraday Soc. 1980, 14, 109-125.
  (227) Ritchey, J. M.; Zozulin, A. J.; Wrobleski, D. A.; Ryan, R. R.; Wasserman, H. J.; Moody, D. C.; Paine, R. T. J. Am. Chem. Soc. 1985, 107, 501-503.
  (228) Ortiz, J. V. J. Am. Chem. Soc. 1986, 108, 550-551.

- (229) Makhyoun, M. A.; El-Issa, B. D.; Salsa, B. A. J. Mol. Struct. (THEOCHEM) 1987, 153, 241-248.
  (230) Hay, P. J.; Ryan, R. R.; Salazar, K. V.; Wrobleski, D. A.; Sattelberger, A. P. J. Am. Chem. Soc. 1986, 108, 313-315.
  (231) Sternal, R. S.; Brock, C. P.; Marks, T. J. J. Am. Chem. Soc. 1985, 107, 8270-8272.
  (232) Bursten, B. E.; Novo-Gradac, K. J. J. Am. Chem. Soc. 1987, 109, 904-905.
- 109, 904-905. (233) Sternal, R. S.; Marks, T. J. Organometallics 1987, 6, 2621-2623.
- (234) Novo-Gradac, K. J. Ph.D. Dissertation 1989, The Ohio State University, Columbus, OH.
- (235) Bursten, B. E.; Casarin, M.; Ellis, D. E.; Fragalà, I.; Marks, T. J. Inorg. Chem. 1986, 25, 1257-1261.
   (236) Van Der Sluys, W. G.; Sattelberger, A. P. Chem. Rev. 1990,
- 90, 1027-1040.
- 90, 1027-1040.
  (237) (a) James, B. D.; Smith, B. E.; Wallbridge, M. G. H. J. Mol. Structure 1972, 14, 327-329. (b) Banks, R. H.; Edelstein, N. M. In Lanthanide and Actinide Chemistry and Spectroscopy; Edelstein, N. M., Ed.; ACS Symposium Series 131; American Chemical Society: Washington, 1980; p 331.
  (238) Hohl, D.; Rösch, N. Inorg. Chem. 1986, 25, 2711-2718.
  (239) Hohl, D.; Ellis, D. E.; Rösch, N. Inorg. Chim. Acta 1987, 127, 195-202.
- 195-202.