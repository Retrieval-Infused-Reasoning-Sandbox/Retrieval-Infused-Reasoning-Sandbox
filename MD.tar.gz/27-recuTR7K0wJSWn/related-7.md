![](_page_0_Picture_1.jpeg)

**Article** 

https://doi.org/10.1038/s41467-023-39626-8

# Actinide inverse trans influence versus cooperative pushing from below and multi-center bonding

Received: 19 January 2023

Accepted: 22 June 2023

Published online: 18 July 2023

Check for updates

Laura C. Motta<sup>1,2</sup> & Jochen Autschbach <sup>1</sup>□

Actinide-ligand bonds with high multiplicities remain poorly understood. Decades ago, an effect known as *6p pushing from below* (PFB) was proposed to enhance actinide covalency. A related effect—also poorly understood—is *inverse trans influence* (ITI). The present computational study of actinide-ligand covalent interactions with high bond multiplicities quantifies the energetic contributions from PFB and identifies a hitherto overlooked fourth bonding interaction for 2nd-row ligands in the studied organometallic systems. The latter are best described by a terminal O/N ligand exhibiting quadruple bonding interactions with the actinide. The 4th interaction may be characterized as a multi-center or charge-shift bond involving the *trans* ligand. It is shown in this work that the 4th bonding interaction is a manifestation of ITI, assisted by PFB, and provides a long-sought missing piece in the understanding of actinide chemistry.

Chemical bonding is an essential concept in chemistry. However, the covalent participation of metal 5f atomic orbitals (AOs) in actinide (An) bonding remains comparatively poorly understood. Initial suggestions of An f-shell covalency<sup>1,2</sup> were met with contention<sup>3</sup>, because the 5f shell was thought to be radially too contracted to be able to participate in covalent bonding. Although f-shell covalency was correctly asserted more than 70 years ago and has important fundamental as well as practical aspects, its role in actinide chemistry remains challenging to interpret. Fundamentally, the actinides show unusual or unique bonding patterns that continue to push the frontiers of chemistry. As a practical matter, actinide chemistry must be understood and mastered as part of a safe and sustainable nuclear fuel cycle. For example, actinide nitrides have great potential as nuclear-accident tolerant fuel<sup>4</sup>.

This article is concerned with a poorly understood—yet extremely important—aspect of An chemistry, viz. unusually high An–ligand bond orders (BOs). It was reported in 2012 that carbon in CUO is triply to quadruply bonded to uranium<sup>5</sup>, with one  $\sigma$  and two  $\pi$  bonds similar to those in uranyl<sup>VI</sup> ([OUO]<sup>2+</sup>), and additionally a weaker so-called rearward  $\sigma$  bond. The rearward  $\sigma$  bond has not been identified in the isoelectronic uranyl<sup>VI</sup>, although it has been suggested that oxo 2s lone

pair interactions with uranium may take place<sup>6-8</sup>. It was also speculated that N is quadruply bonded to U in NUN<sup>9</sup>.

At the heart of actinide-ligand multiple bonding lie two-also poorly understood-aspects of An chemistry, namely 6p pushing from below (PFB)<sup>7,8,10-15</sup> and the inverse trans influence (ITI)<sup>7,8,16-21</sup>. PFB was initially<sup>10</sup> identified for uranyl<sup>VI</sup>, to explain among other aspects the finding that the  $\sigma_u$  HOMO, being a bonding linear combination of ligand AOs with 5f AOs, was calculated higher in energy than the  $\sigma_{\sigma}$ involving the metal 6d/7s shells, and higher than the  $\pi_{g/u}$  bonding combinations. This was surprising, given that a particularly strong covalent  $\sigma$  interaction involving 5f is expected to stabilize the  $\sigma_u$  $MO^{10,22,23}$ , and because the  $\sigma_g$  should be higher in energy since it involves the higher-energy 6d metal AOs instead of 5f. The occurrence of a  $\sigma_u$  HOMO was then rationalized by an electrostatic repulsion between the ligand lone pairs and the semi-core U 6p shell, potentially accompanied by 6p-5f hybridization. In addition, 6p-oxygen repulsion renders the oxygen a stronger  $\sigma$  donor that it would otherwise be.<sup>10</sup>. Typically, PFB is assumed for charge-dense ligand anions such as (formal) O<sup>2-</sup> or N<sup>3-</sup>. It was recently suggested that PFB is also present in certain thorium compounds<sup>24</sup>, prompting the question how general this effect truly is.

<sup>&</sup>lt;sup>1</sup>Department of Chemistry, University at Buffalo, State University of New York, Buffalo, NY 14260-3000, USA. <sup>2</sup>Present address: Department of Marine Chemistry & Geochemistry, Woods Hole Oceanographic Institution, Woods Hole, MA 02543-1050, USA. — e-mail: jochena@buffalo.edu

PFB has also been associated with ITI in actinide chemistry. ITI plays a vital role in the successful isolation of terminal organometallic actinide nitrido and oxo multiple bonds. Denning and co-workers<sup>7,8</sup> proposed that a U-ligand bond *trans* to a strong electron-rich bond (e.g., U≡O), is stabilized by parity-allowed 5f-6p mixing, resulting in ITI. The exact role of PFB in the ITI is unknown, however<sup>12,16,18</sup>. The original extended-Hückel theory study of PFB by Tatsumi and Hoffmann<sup>10</sup>, and subsequent related theoretical work<sup>11-13,24</sup> did not quantify PFB, and by extension ITI, in terms of energy across different types of compounds. Furthermore, the delocalized nature of the valence canonical MOs has made it difficult to assess the contributions of actinide 6p AOs in larger systems, such that PFB has been evaluated indirectly, for instance via calculations excluding or including 6p in frozen cores<sup>13,16,18,24</sup>.

The aim of the present study is therefore two-fold. First, we investigate the extent and energetic contributions from PFB to the electronic structure and its relevance to ITI for a variety of actinide compounds, using modern quantum chemical bonding analyses. The computational strategy harnesses all-electron relativistic Kohn-Sham Density Functional Theory (KS-DFT) and multiconfigurational wavefunction theory (WFT) to identify key orbitals involved in the metal-ligand bonding. The systems are analyzed by the complementary natural bond orbital (NBO) and natural orbitals for chemical valence (NOCV) frameworks, various BO measures, as well as orbital entanglement. Second, PFB is investigated in conjunction with the bonding contributions of the terminal nitrido and oxo 2s lone pairs in the exceptionally covalent [(Ra)3N-An-Y]n- systems20,24-27 [Ra =  $CH_2CH_2NSi^{\dagger}Pr_3$ , Y = N or O, and n = 0, 1, or 2; the compounds have also been labeled as [An(TREN<sup>TIPS</sup>)]<sup>n-</sup>]; see Fig. 1a below] and the systems<sup>17</sup>  $R-U^{VI}(R^b)_3-O[R = Me = H_3C \text{ or } R = Ph-C \equiv C(Ph = C_6H_6), R^b = N(SiMe_3)_2;$ see Fig. 1b below]. The terminal nitrido and oxo ligands were previously assigned as triple or double bonded to the actinide (Fig. 1). We find that these bonds also have considerable rearward  $\sigma$  contributions, aided by PFB. It is therefore appropriate to assign quadruple bond character to the terminal nitrido ligands (similar to C≣U in CUO), and even the terminal bonds with O have quadruple bond character, which is exceedingly rare in large organometallic complexes, if not unheard of. The terminal quadruple bond includes a 3-center 4-electron (3c4e) or charge-shift interaction involving the trans ligand, and it is facilitated by the covalent, steric, and likely also the electrostatic aspects of PFB, explaining the ITI phenomenon in actinide multiple bonding.

#### Results

#### **Bond orders**

NBO-derived BOs from the B3LYP calculations are collected in Table 1. See Supplementary Table 3 for additional BOs according to Mayer<sup>28</sup>, Nalewajski-Mrozek (N-M set 3)<sup>29</sup>, and Gopinathan-Jug (G-J)<sup>30</sup>. All calculated BOs depend on their underlying partitioning of the density (matrix) and the accompanying definition of the promolecule<sup>31</sup>. Mayer BOs for dative (donation) bonds in systems with metal atoms are often too low to conform to chemical intuition<sup>5,9,25,31,32</sup>. N-M and NBO BOs have been shown to reproduce expected bond multiplicities successfully for a variety of transition metals complexes<sup>31,33</sup>, resulting in overall similar bonding patterns. The G-J BOs for our samples are smaller than N-M and NBO because they exclude valence-bond-style ionic contributions, which is likely problematic when considering dative (donation) bonds that are polarized toward the ligands. We focus primarily the NBO-based analysis. The additionally available BO decomposition into contributions from individual Natural Localized Molecular Orbitals (NLMOs)33, aids the interpretation of the NBObased BOs.

For the organometallic compounds, the terminal An-N/O BOs are considerably larger than 3, therefore indicating the presence of a fourth bonding interaction. Quadruple bonding between an actinide and a C, N, or O ligand requires the participation of the rearward 2srich ligand  $\sigma$  lone pair and is therefore almost unheard of. As

mentioned, however, the rearward  $\sigma$  bond has been reported for CUO<sup>5</sup>. The present NBO analysis for CUO is in accordance with this previous assignment. We note in passing that the N-M C-UO BO of 4.4 (Supplementary Table 3) should not be interpreted as a quintuple bond, given that the bond is with carbon. Instead, one should view the BO as indicating a particularly covalent quadruple dative bond.

Inspection of individual natural localized molecular orbital (NLMO) contributions to the BOs for the organometallic compounds reveals participation of the terminal N and O rearward  $2s_p$  lone-pair NLMO in the bonds. The notation indicates a 2s-rich hybrid with secondary 2p contributions. The  $2s_p$  BO contributions are largest for the terminal nitrides (average  $0.17\pm0.02$ ), which are close in magnitude to the corresponding value (0.21) for CUO. The covalent contributions of the oxo  $2s_p$  (average  $0.10\pm0.06$ ) appear weaker because the An-oxo bonds are less covalent overall, but the relative contributions are comparable to those for the terminal N.

The BO analysis also reveals a small but not unimportant participation of the An  $6p_{\sigma}$  AOs, that is, a covalent contribution. The An  $6p_{\sigma}$  BO contributions are greatest for the small molecules (average  $0.015\pm0.01$ , lowest for ThO<sub>2</sub>) compared to the organometallics (average  $0.006\pm0.002$ ). The widespread participation of the An  $6p_{\sigma}$  in the bonding, including the C–U bond in CUO, indicates that PFB is likely to be a general chemical phenomenon, at least among the early actinides. The Th–Cl bond in  $(R^a)_3NTh$ –Cl has a much smaller BO than most of the other bonds listed in Table 1, as may be expected for a chloride ligand. The absence of a notable rearward  $\sigma$  interaction, indicated by the very small  $3s_p$  BO contribution, goes along with a negligible Th  $6p_{\sigma}$  contribution for this bond.

#### Terminal actinide-ligand triple vs. quadruple bond

Although the BO is calculated to be large for all terminal O/N-An bonds in the studied organometallics, and the involvement of the  $2s_p$  ligand lone pair hybrid is evident, further analysis is needed to decide whether these bonds should be assigned as quadruple.

The NBO analysis is designed to determine a best single Lewis structure that can optimally describe the electron density (matrix) upon accounting of some—presumably relatively minor—delocalization. The latter can be described via the contributions from other resonance structures<sup>34,35</sup>. The suitability of a given Lewis structure is quantified by a root-mean-square deviation (RMSD) representing a residual non-Lewis electron number<sup>33–35</sup>. For the closed-shell (R<sup>a</sup>)<sub>3</sub>NU<sup>VI</sup>N compound, the optimal Lewis structure as determined by the NBO algorithms (structure 1, in Fig. 1c) features a terminal U=N and an N-polarized  $\sigma$ (N<sub>amine</sub>–U) bond (83% nitrogen weight). See Fig. 1e, f for NLMO visuals. The analysis (Table 2) shows 1.8 electrons RMSD.

It has been shown previously for a variety of transition metal complexes that a multi-resonance description based on Natural Resonance Theory (NRT) can be much more appropriate than a description based on a single NBO Lewis structure<sup>34-36</sup>. In the present case, NRT analysis revealed, for example, for (R<sup>a</sup>)<sub>2</sub>NU<sup>VI</sup>N an important secondary resonance structure featuring a terminal U≣N bond and no N<sub>amine</sub>-U bond (Fig. 1c, Lewis structure 2). The fourth bond is an N-polarized covalent interaction between the nitride 2s<sub>p</sub> (89%) and a U 5f6d<sub>7s6p</sub> (an f-d hybrid with contributions from 7s and 6p, Fig. 1). For (R<sup>a</sup>)<sub>3</sub>NU<sup>VI</sup>N, resonance structures 1 and 2 have the same RMSD individually (1.8 electrons), and according to NRT, the system is best described by strong 45/55 percent resonance. In other words, there is a 3c4e N<sub>amine</sub>-U-N<sub>nitride</sub> interaction. The superiority of the resonance model is confirmed by the small residual RMSD (0.09e) in the NRT, meaning the delocalization in the system is essentially only in the N<sub>amine</sub>-U-N<sub>nitride</sub> moiety.

Similarly, the NBO-NRT analysis also shows that the resonance model (Table 2) is the best description for the other organometallics, including the PhCC/MeU<sup>VI</sup>(R<sup>b</sup>)<sub>3</sub>O compounds (Fig. 1d-f); this picture

![](_page_2_Figure_2.jpeg)

**Fig. 1** | **Resonance models for the organoactinide compounds.** Panels **a** and **b** represent proposed structures for the :N(R<sup>a</sup>)<sub>3</sub>-An-Y and X-U<sup>VI</sup>(R<sup>b</sup>)<sub>3</sub>-O compounds, respectively. Actinides emphasized by green color. The *trans*-interaction is emphasized by purple color, and blue is used for better readability of the panels. The purple arrow represents the proposed axial electronic stabilization via ITI by the N<sub>amine</sub> in the TREN<sup>TIPS</sup> ligand. Panels **c** and **d** show the dominant Lewis structures 1 and 2 for (R<sup>a</sup>)<sub>3</sub>N-U<sup>VI</sup>-N and Me-U<sup>VI</sup>(R<sup>b</sup>)<sub>3</sub>-O compounds analyzed by natural

bond orbital (NBO) natural resonance theory (NRT). Panels  ${\bf e}$  and  ${\bf f}$  show isosurfaces (±0.03 atomic units in red/blue) of selected natural localized molecular orbitals (NLMOs, from DFT/B3LYP calculations) for (R<sup>a</sup>)<sub>3</sub>N–U<sup>VI</sup>–N and Me–U<sup>VI</sup>(R<sup>b</sup>)<sub>3</sub>–O, respectively, with the corresponding AO contributions (some AO hybrids are labeled with subscripts; e.g.,  $2s_p$  indicates a 2s-rich hybrid with secondary 2p contributions). Hydrogens are omitted from the structures for clarity.

is supported by the terminal An-N/O and *trans*-An BOs in Table 1. However, for the terminal An-oxo compounds, structure 1 is more dominant given the lower RMSD values relative to structure 2. This is also reflected in the lower BOs for these compounds. In comparison, the uranyl ion is described well by a single Lewis structure ( $[O \equiv U \equiv O]^{+2}$ ), whereas CUO is also resonance stabilized by a 3c4e C-U-O interaction, favoring the C $\equiv$ O bond. Given that the resonance is of the type X-U  $\equiv$  Y:  $\leftrightarrow$  X: U $\equiv$ Y (without or with additional X-U bonds), the interaction produces a pronounced U-Y quadruple bond character.

# Stability and classification of the $\it trans$ -An-terminal multi-center interaction

The BOs and NBO-NRT analyses strongly support the existence of a fourth bonding interaction in the organometallic complexes. However, the analysis does not reveal information about the strength/stability of the 3c4e *trans*–U–terminal-ligand hyperbond. BOs do not strictly correlate with interaction energies, in particular when comparing

different types of chemical bonds<sup>5,37</sup>. To evaluate interaction energies related to the covalency of the  $2s_p$  O and N lone pairs, and the *trans* ligand, NBO-based second-order perturbation energies ( $\Delta E^{(2)}$ ) for the donor–acceptor interactions were evaluated and compared to those in  $[OUO]^{+2}$ , CUO, and NUN. To allow direct comparisons of the  $\Delta E^{(2)}$  values<sup>33</sup>, the X: U=Y: Lewis structure (structure 1 in Fig. 1) was used consistently. The dominant non-Lewis delocalization interactions are illustrated in Fig. 1c for  $(R^a)_3 NU^{VI}N$ .

The  $\Delta E^{(2)}$  stabilization interactions for  $(R^a)_3NU^{VI}N$  are illustrated in Fig. 2a and listed in Table 3 for a subset of compounds. For all tested compounds, the energetically dominant interactions (nos. 4 and 5) correspond to donation from the terminal and *trans* ligands lone pairs to formally unoccupied actinide AOs, that is, dative bonding. The strongest interactions are found for the An-terminal bond, in particular for the nitrido systems, in which apparently good overlap and a favorable energy match combine, according to the principles of MO theory, to yield substantial energetic stabilization. Stabilization by the rearward donation to An is also strong for CUO and NUN, in which the

Table 1 | Calculated (DFT/B3LYP) An-ligand bond orders and An 6p-hole for ionic and organometallic actinide compounds

|                                                       |      | NBO-NRT | BOs    | An-T Cova       |                  |                 |                  |       |           |
|-------------------------------------------------------|------|---------|--------|-----------------|------------------|-----------------|------------------|-------|-----------|
| Compound                                              | BL   | An-T    | Trs-An | 6ρ <sub>σ</sub> | 2s <sub>ρσ</sub> | 2p <sub>π</sub> | 2p <sub>sσ</sub> | Total | An6p-hole |
| $[U^V-N]^{2+}$                                        | 1.75 | 3.0     | -      | 0.010           | 0.077            | 1.392           | 0.726            | 2.2   | 0.03      |
| OTh <sup>IV</sup> -O C <sub>2v</sub>                  | 1.91 | 3.0     | -      | 0.003           | 0.019            | 0.550           | 0.422            | 1.0   | 0.04      |
| OTh <sup>IV</sup> −O D <sub>∞h</sub>                  | 1.91 | 3.0     | -      | 0.006           | 0.025            | 0.504           | 0.442            | 1.0   | 0.03      |
| $[OU^{VI}-O]^{2+}C_{2v}$                              | 1.70 | 2.9     | -      | 0.009           | 0.035            | 1.042           | 0.660            | 1.7   | 0.06      |
| $[OU^{VI}-O]^{2+}D_{\omega h}$                        | 1.70 | 2.9     | -      | 0.022           | 0.018            | 0.962           | 0.753            | 1.8   | 0.07      |
| [ONp <sup>VII</sup> -O] <sup>3+</sup>                 | 1.67 | 2.9     | -      | 0.023           | 0.020            | 1.262           | 0.824            | 2.1   | 0.09      |
| $[OU^V - O]^{1+}$                                     | 1.75 | 2.9     | -      | 0.015           | 0.024            | 0.790           | 0.688            | 1.5   | 0.06      |
| [ONp <sup>VI</sup> -O] <sup>2+</sup>                  | 1.68 | 2.9     | -      | 0.020           | 0.022            | 1.022           | 0.790            | 1.9   | 0.08      |
| NU <sup>VI</sup> -N                                   | 1.73 | 3.5     | -      | 0.016           | 0.110            | 1.318           | 0.948            | 2.4   | 0.06      |
| OU <sup>VI</sup> -C                                   | 1.74 | 3.7     | 3.3    | 0.016           | 0.205            | 1.956           | 0.506            | 2.7   | 0.05      |
| (R <sup>a</sup> ) <sub>3</sub> NTh <sup>IV</sup> -Cl  | 2.70 | 1.1     | 1.0    | 0.000           | 0.017            | 0.234           | 0.213            | 0.5   | 0.01      |
| $[(R^a)_3NTh^{IV}-N]^{2-}$                            | 1.93 | 3.6     | 0.4    | 0.006           | 0.172            | 0.882           | 0.573            | 1.6   | 0.02      |
| $(R^a)_3NU^{VI}-N$                                    | 1.80 | 3.5     | 0.5    | 0.009           | 0.195            | 1.458           | 0.873            | 2.5   | 0.03      |
| $[(R^a)_3 NU^V - N]^{1-}$                             | 1.83 | 3.5     | 0.5    | 0.006           | 0.171            | 1.276           | 0.777            | 2.2   | 0.02      |
| $[(R^a)_3 NU^{IV} - N]^{2-}$                          | 1.83 | 3.6     | 0.3    | 0.006           | 0.157            | 1.098           | 0.695            | 1.9   | 0.02      |
| $(R^a)_3NU^V-O$                                       | 1.85 | 3.4     | 0.6    | 0.004           | 0.096            | 0.744           | 0.458            | 1.3   | 0.01      |
| $(R^a)_3NNp^V-O$                                      | 1.80 | 3.4     | 0.6    | 0.005           | 0.096            | 0.792           | 0.549            | 1.4   | 0.02      |
| $Me(R^b)_3U^{VI}-O$                                   | 1.79 | 3.3     | 0.7    | 0.007           | 0.109            | 0.768           | 0.490            | 1.4   | 0.03      |
| PhCCU <sup>VI</sup> (R <sup>b</sup> ) <sub>3</sub> -O | 1.81 | 3.3     | 0.7    | 0.006           | 0.103            | 0.810           | 0.486            | 1.4   | 0.03      |
| O-U <sup>VI</sup> C*                                  | 1.80 | 3.3     | -      | 0.009           | 0.004            | 0.681           | 0.580            | 1.3   | 0.05      |
| $(R^a)_3N-U^{VI}N^*$                                  | 2.46 | 0.5     | 3.5    | 0.000           | 0.000            | 0.000           | 0.218            | 0.3   | 0.03      |
| $Me-U^{VI}(R^b)_3O^*$                                 | 2.34 | 0.7     | 3.3    | 0.003           | 0.000            | 0.000           | 0.639            | 0.7   | 0.03      |

Bond length (BL) in Å for the actinide—terminal ligand (An-T) bond. An-T and trans-ligand–actinde (Trs-An) total NBO-NRT bond order (BO; covalent + ionic contributions). Major individual Natural Localized Molecular Orbital (NLMO) contributions to An-T BO. The ionic NBO-NRT BO contributions correspond to a valence bond-type covalent-ionic resonance mixing concept<sup>33</sup>.  $C_{2v}$  angle = 120°.  $2p_{rr}$  = sum of  $2p_{rrx}$  and  $2p_{rrx}$ . \*Detailed analysis of the Trs-An bond instead of An-T.

Table 2 | NRT weights of the Lewis structures 1 and 2, and the associated non-Lewis RMSD errors in the NRT compared to using only a single resonance structure 1 or 2

|                                                      | Weights <sup>a</sup> |    | RMSD <sup>b</sup> | RMSD <sup>b</sup> |      |  |
|------------------------------------------------------|----------------------|----|-------------------|-------------------|------|--|
| Compound                                             | 1                    | 2  | Only 1            | Only 2            | NRT  |  |
| [UOU] <sup>2+ °</sup>                                | 99                   | -  | 0.35              | _                 | -    |  |
| CUO <sup>d</sup>                                     | 75                   | 26 | 0.28              | 0.44              | 0.07 |  |
| $\left[\left(R^{a}\right)_{3}NTh^{IV}N\right]^{2-}$  | 36                   | 64 | 2.04              | 1.98              | 0.10 |  |
| $(R^a)_3 NU^{VI}N$                                   | 45                   | 55 | 1.84              | 1.84              | 0.09 |  |
| $[(R^a)_3NU^VN]^{1-}$                                | 48                   | 52 | 0.96              | 0.92              | 0.05 |  |
| $[(R^a)_3NU^VN]^{2-}$                                | 34                   | 66 | 1.29              | 1.25              | 0.06 |  |
| $(R^a)_3 NU^V O$                                     | 60                   | 40 | 0.88              | 0.92              | 0.05 |  |
| $(R^a)_3NNp^VO$                                      | 60                   | 40 | 0.87              | 0.92              | 0.05 |  |
| MeU <sup>VI</sup> (R <sup>b</sup> ) <sub>3</sub> O   | 66                   | 34 | 2.99              | 3.34              | 0.08 |  |
| PhCCU <sup>VI</sup> (R <sup>b</sup> ) <sub>3</sub> O | 70                   | 30 | 5.12              | 6.24              | 0.12 |  |
| $(R^a)_3 NU^{VI} N^e$                                | 47                   | 53 | 3.31              | 3.31              | 0.00 |  |

DFT/B3LYP calculations.

U is quadruply bonded to the ligand. The NBO  $\Delta E^{(2)}$  data indicate that all of the studied actinide compounds are stabilized by the formation of the *trans* 3e4c bond from the resonance of structures 1 and 2. Given

the symmetry of the actinyl ions, the  $\Delta E^{(2)}$  values are the same for interaction nos. 4 and 5.

The *trans*-ligand–An-terminal-ligand rearward interaction involves orbitals that are polarized toward the corresponding nitrogen, oxygen, or carbon ligands. There are therefore good reasons to classify the rearward *trans*–An-terminal interaction as a charge-shift (CS) bond<sup>38</sup>. Indeed, using modern VB calculations, it was argued previously that 3c4e bonds in stable (not transient or transition state) species can be classified as CS bonds<sup>38</sup>. CS bonds can also be identified using QTAIM<sup>38</sup>, by a small negative or positive electron density Laplacian ( $\nabla^2 \rho$ ), densities ( $\rho$ )  $\geq$  0.1, and a negative overall energy density (H), at the bond critical point (BCP). In ( $R^a$ )<sub>3</sub>NU<sup>VI</sup>–N the N<sub>amine</sub>–U BCP has a  $\rho$  = 0.1,  $\nabla^2 \rho$  = 0.1, and H = -0.03, and for the U–N BCP we find  $\rho$  = 0.3,  $\nabla^2 \rho$  = 0.04, and H = -0.4. The data are compatible with a CS bond assignment. It is important to note that the QTAIM analysis reflects all of the interactions present in the quadruple terminal bond, not only  $2s_p$  rearward bonding.

To further explore the covalent contributions to the An-Terminal bonding, and the stability of the fourth 3c4e/CS interaction, we carried out ETS-NOCV analyses for the organometallic compounds, and compared the results to  $[OUO]^{2+}$ , NUN, and CUO (Table 3). The ETS-NOCV analysis clearly identifies four bonding contributions to the absolute values of  $\Delta E_{\rm orb}$ , the stabilization energy that arises from the covalency of the metal-ligand orbital interactions, for most systems: one  $\sigma$ , two  $\pi$ , and the additional (weaker) rearward  $\sigma$  interaction. The corresponding NOCVs are shown in Fig. 2b-c for  $(R^a)_3NU^{VI}-N$  and  $MeU^{VI}(R^b)_3-O$ . Consistent with the other analyses, there is a  $\sigma$  bond, two  $\pi$  bonds, and the  $\sigma$  3c4e/CS bond. The fourth NOCV clearly displays the multi-center covalent interactions between the *trans* and terminal ligand via U. For the

<sup>\*</sup>Percent weights of Lewis structures 1 and 2 of Figs. 1c and 1d in the resonance stabilized electronic structure according to NRT.

<sup>&</sup>lt;sup>b</sup>Non-Lewis RMSD (number of electrons).

<sup>°</sup>The dominant resonance structure for uranyl is  $O \equiv U \equiv O^{+2}$ .

<sup>&</sup>lt;sup>d</sup>The resonance for CUO is [(1) C $\equiv$ U  $\equiv$  O:  $\leftrightarrow$  (2):C  $\equiv$  U $\equiv$ O].

<sup>&</sup>quot;Data for the full experimental  $(R^a)_3 NU^{VI} N$  crystal structure to serve as comparison with the truncated structure. The overall RMSD numbers are larger due to minor hyperconjugative interactions along the  ${}^{i}Pr$  ligand compared to the truncated  $(R^a)_3 NU^{VI} N$  compound.

RU-N Δρ<sub>orb</sub><sup>7</sup>

N[83% 2p<sub>π</sub>] + U[1%

 $6p_{\pi}] \rightarrow U[57\% 5f +$ 

 $16\% 6d] + N[2\% 3p_{\pi}]$ 

MeU-O Δρ<sub>orb</sub>

O[81% 2p<sub>π</sub>] + U[1%

 $6p_{\pi} + 1\% 5f] \rightarrow$ 

U[57% 5f + 24% 6d]

![](_page_4_Figure_2.jpeg)

Fig. 2 | Energetic contributions to metal-ligand bonding. Left: a Natural bond orbital (NBO) representation of dominant non-Lewis delocalization and corresponding  $\Delta E^{(2)}$  stabilization (kcal mol<sup>-1</sup>) for  $(R^a)_3N-U-N$  shown by the favorable NBO donor-acceptor overlap in each case. Interactions 1 to 3 (circled numbers) correspond to contributions from the semi-core 6s,  $6p_{\sigma}$ , and  $6p_{\pi}$  U orbitals; 4 and 5 correspond to donation from the terminal (N) and trans U-N<sub>amine</sub> ligand lone pair to formally empty U and NBOs. NBO isosurfaces at  $\pm\,0.03$  atomic units in red/blue

for donor and cyan/orange for acceptor NBOs. The proposed structure (Fig. 1a) for  $(R^{a})_{3}N-U-N$  was used as the Lewis reference for the  $\Delta E^{(2)}$  analysis. Right: Energetic contributions  $\Delta E_{\mathrm{orb}}$  with corresponding natural orbitals for chemical valence (NOCV) analysis (NOCV isosurfaces at  $\pm$  0.001 atomic units in red/blue) for the terminal (b)  $(R^a)_3NU-N$  and (c)  $Me(R^b)_3U-O$  bonds, and the  $\sigma$  trans  $O(R^b)_3U-Me$ bond (d). Hydrogens are omitted from the structures for clarity. DFT/B3LYP calculations.

organometallics, the energetic bond component is the largest for the  $\sigma$  bond and the smallest for the 3c4e/CS bond, but the latter is not negligible. Namely, for  $(R^a)_3$ NAn<sup>n</sup>N compounds,  $\Delta E_{orb}$  for the 3c4e/ CS bond is larger than that of the known fourth rearward  $\sigma$  bond in CUO, and comparable to the covalent energy of the main  $[(R^a)_3NTh^{IV}-CI]\sigma$  bond.

We carried out a subset of ETS-NOCV analyses also for the bonds indicated by the dash in CU-O and OU<sup>VI</sup>(R<sup>b</sup>)<sub>3</sub>-Me, i.e., to evaluate covalent contributions to the trans-An interaction in the 3c4e/CS bond. This analysis is not possible for the (R<sup>a</sup>)<sub>3</sub>NAn<sup>n</sup>N compounds because the contributions of the  $\textit{trans}\ N_{\text{amine}}$  cannot be isolated from the TREN<sup>TIPS</sup> ligand (Table 3). There is a fourth  $\Delta E_{\rm orb}$  bonding contribution from the O lone pair in CU-O, although weaker relative to the C lone pair contributions, in agreement with the NBO-NRT resonance analysis. Likewise, the corresponding NOCV for the  $OU^{VI}$ -Me single  $\sigma$ bond illustrates a multi-center interaction composed of C, U, and O contributions.

The combined NBO and ETS-NOCV evidence lead to the conclusion that the trans-ligand-An-terminal-ligand interaction in An compounds with high An-ligand bond multiplicities is ITI, facilitated by the terminal and trans 2s<sub>p</sub> AOs. The participation of the actinide 6p semicore shell is discussed next.

#### Analysis of the pushing-from-below mechanism

As discussed earlier, the individual NLMO contributions to the BOs (Table 1) indicate covalent participation of the An  $6p_{\alpha}$  for most of the studied compounds. The  $\Delta E^{(2)}$  NBO analysis (Table 3 and Fig. 2; interactions 1-3), also demonstrates clear and energetically important non-Lewis donor–acceptor interactions involving the semi-core  $6p_{\sigma}$  (with the exception of (R<sup>a</sup>)<sub>3</sub>NTh<sup>IV</sup>-Cl, as noted already). Delocalization of a (partially) filled atomic orbital in a localized orbital framework is covalency, and it creates a partial electron hole in the 6p shell. We find a lesser, but non-negligible extent of 6s and  $6p_{\pi}$  delocalization. The extent of stabilization from  $6p_{\sigma}$  delocalization becomes smaller when going from  $(R^a)_3 NU^{VI}N$  to  $[(R^a)_3 NU^{IV}N]^{2-}$ .

In a complementary yet consistent picture, the charge-flow channels  $^{39}$  in  $(\dot{R}^a)_3NU^{VI}-\dot{N}$  and  $MeU^{VI}(R^b)_3-O$  corresponding to four bonding NOCVs (Fig. 1) indicate an outflow of 6p and 6s density to the formally unoccupied 5f and 6d AOs. As expected from the original extended-Hückel theory study of PFB<sup>10</sup>, the contributions from the  $6p_{\sigma}$ (~5%) to  $\sigma_u$  HOMO are greater than those of the  $6p_{\pi}$  (~1%) to the HOMO-1 and HOMO-2. The largest  $6p_{\sigma}$  (~28%) contributions arise in the  $\sigma$ trans-U-terminal NOCV, which is not entirely surprising given the comparatively larger radial overlap between the ligand 2s and the  $6p_{\sigma}$ vs.  $6p_{\pi}$  actinide AOs<sup>5,7,8</sup>. Thus, the fourth covalent interaction is a manifestation of PFB facilitating ITI, and it does not require inversion symmetry to be present. As discussed earlier, our results indicate that in addition to 6p-5f hybridization, the covalent participation of the ligand 2s<sub>p</sub> lone pair in the 3c4e bond is an essential component of ITI.

The covalent aspect of PFB may be accompanied by an energetic destabilization of the ligand 2s<sub>p</sub> hybrid by electrostatics and by Pauli repulsion with the 6sp shell, facilitating covalent interactions of 2s<sub>p</sub>

Table 3 | NBO second-order perturbation stabilization energies for the dominant non-Lewis interactions, and the orbital interaction energies  $\Delta E_{\rm orb}$  for the dominant bonding interactions shown in Fig. 2a

|                                                       | <sup>a</sup> NBO Δ <i>E</i> <sup>(2)</sup> |      |     |                       |            | bETS-NOCV         |        |            |  |
|-------------------------------------------------------|--------------------------------------------|------|-----|-----------------------|------------|-------------------|--------|------------|--|
|                                                       | Stabilization interactions                 |      |     |                       |            | ΔE <sub>orb</sub> |        |            |  |
| Compound                                              | °1                                         | °2   | °3  | <sup>d</sup> <b>4</b> | d <b>5</b> | $\sigma^2$        | π      | $\sigma^1$ |  |
| [OU <sup>VI</sup> −O] <sup>2+</sup> D <sub>∞h</sub>   | 2.2                                        | 14.2 | 1.8 | 29.8                  | 29.8       | -320.9            | -168.6 | -16.6      |  |
| $[OU^{VI}-O]^{2+}C_{2v}$                              | 0.8                                        | 7.9  | 1.6 | 21.0                  | 21.0       | -288.9            | -164.7 | -14.0      |  |
| OU <sup>VI</sup> –C                                   | 2.1                                        | 11.7 | 2.4 | 79.7                  | 42.9       | -473.0            | -317.2 | -24.6      |  |
| (R <sup>a</sup> ) <sub>3</sub> NTh <sup>IV</sup> -Cl  | 0.0                                        | 0.0  | 0.0 | 11.6                  | 28.2       | -26.6             | -10.7  | 0.0        |  |
| $\left[ (R^{a})_{3}NTh^{IV} \!-\! N \right]^{2-}$     | 1.0                                        | 7.1  | 1.1 | 82.4                  | 13.8       | -186.1            | -101.8 | -34.6      |  |
| $(R^a)_3NU^{VI}-N$                                    | 1.1                                        | 11.3 | 0.6 | 128.9                 | 28.9       | -287.1            | -153.2 | -28.3      |  |
| $[(R^a)_3 NU^V - N]^{1-}$                             | 0.4                                        | 8.0  | 0.4 | 112.1                 | 19.6       | -237.0            | -120.2 | -30.0      |  |
| $[(R^a)_3 NU^{IV} - N]^{2-}$                          | 0.8                                        | 7.3  | 0.7 | 73.5                  | 24.5       | -169.4            | -83.4  | -27.1      |  |
| $(R^a)_3NU^V-O$                                       | 0.0                                        | 6.0  | 0.0 | 79.8                  | 22.6       | -144.7            | -70.2  | -19.6      |  |
| $(R^a)_3NNp^V-O$                                      | 0.3                                        | 7.6  | 0.0 | 85.6                  | 30.0       | -172.7            | -48.4  | -17.4      |  |
| MeU <sup>VI</sup> (R <sup>b</sup> ) <sub>3</sub> -O   | 0.8                                        | 10.3 | 0.6 | 62.9                  | 61.3       | -179.3            | -87.6  | -19.6      |  |
| PhCCU <sup>VI</sup> (R <sup>b</sup> ) <sub>3</sub> -O | 0.6                                        | 7.3  | 0.0 | 47.3                  | 90.4       | -166.8            | -89.3  | -16.7      |  |
| CU <sup>VI</sup> –O <sup>e</sup>                      | 1.4                                        | 9.9  | 0.0 | 42.9                  | 79.7       | -209.1            | -77.9  | -13.7      |  |
| $O(R^b)_3 U^{VI} - Me^e$                              | 0.0                                        | 0.0  | 0.0 | 61.3                  | 62.9       | -82.6             | -9.1   | -          |  |
| $(R^a)_3NU^{VI}-N^f$                                  | 1.2                                        | 10.3 | 0.6 | 81.0                  | 21.2       | -287.0            | -152.6 | -27.9      |  |

DFT/B3LYP calculations.

with the valence 5f and 6d An orbitals. The numerical analysis indeed shows that Pauli repulsion is also an important component of the PFB mechanism. The NBO pairwise steric exchange energies ( $\Delta E_X$ ) associated with the Pauli repulsion between U 6p/6s and the terminal and *trans* ligand valence NLMOs are listed in Table 4 for [OUO]<sup>2+</sup>, CUO, and (R<sup>a</sup>)<sub>3</sub>NU<sup>VI</sup>–N. Although the Pauli repulsion is more pronounced between the U 6p<sub> $\sigma$ </sub> and ligand 2s<sub>p</sub> and 2p<sub>s</sub> interactions, the participation of the U 6s and 6p<sub> $\pi$ </sub> shells is not altogether negligible. Overall, it is clear that electrostatic repulsion, Pauli repulsion, and 6p covalency go together in the PFB mechanism.

### Orbital entanglement investigation

The KS-DFT NBO-NRT and ETS-NOCV analyses evidence a terminal An $\equiv$ L bond via a 3c4e/CS *trans*–An–terminal ligand interaction facilitated by the terminal O or N 2sp AO. Absence of most of the dynamic correlation at the CASSCF level means that the use of NBO-NRT and ETS-NOCV bonding analyses based on this level of multiconfigurational WFT is presently not particularly helpful. To corroborate the rearward lone pair bonding participation by WFT, we therefore conducted a multiconfigurational orbital entanglement analysis  $^{40-46}$ .

Orbital entanglement measures facilitate the qualitative interpretation of the electronic structure in terms of quantum correlation of MOs and have been successful in elucidating bond formation processes<sup>41</sup> and molecular complexation<sup>40</sup>. In particular, the mutual orbital information<sup>40,47,48</sup> indicates entanglement of an orbital pair, hence represent a measure to assess on a qualitative level, independent from the DFT calculations, whether the ligand 2s<sub>p</sub> and actinide

Table 4 | Selected axial pairwise steric exchange energies  $\Delta E_X$  from NBO analysis for interactions between U 6p/6s and ligand valence NLMOs for the dominant interactions shown in Fig. 2a

|                                                                                          | NLMO                                                         | ΔΕχ  |      |      |
|------------------------------------------------------------------------------------------|--------------------------------------------------------------|------|------|------|
| Compound                                                                                 | Steric<br>Interactions                                       | (1)  | (2)  | (3)  |
| $[O-U^{VI}-O]^{2+}$                                                                      | $U \; 6p_\sigma \! \leftrightarrow \! O \; 2p_s$             | 37.6 | -    | -    |
| (1) :O≡U≡O: <sup>b</sup>                                                                 | U 6s ↔ O 2p <sub>s</sub>                                     | 17.4 | -    | -    |
| (2) O≣U ≡ O:                                                                             | $U 6p_{\sigma} \leftrightarrow O 2s_{p}$                     | 12.3 | _    | -    |
| (3) :O ≡ U≣O                                                                             | U 6s ↔ O 2s <sub>p</sub>                                     | 0.9  | -    | -    |
|                                                                                          | $U 6p_{\pi} \leftrightarrow O 2\pi^{d}$                      | 3.5  | _    | -    |
| O-U <sup>VI</sup> -C                                                                     | $U 6p_{\sigma} \leftrightarrow C 2p_{s}$                     | 9.6  | 8.0  | 9.1  |
| (1) :C ≡ U ≡ O: <sup>c</sup>                                                             | $U 6s \leftrightarrow C 2p_s$                                | 5.6  | 4.8  | 5.6  |
| (2) C≣U ≡ O:                                                                             | $U 6p_{\sigma} \leftrightarrow C 2s_{p}$                     | 10.2 | 12.8 | 12.7 |
| (3) :C ≡U≣O                                                                              | $U \ 6s \leftrightarrow C \ 2s_p$                            | 3.3  | 4.0  | 2.9  |
|                                                                                          | $U 6p_{\pi} \leftrightarrow C 2\pi^{d}$                      | 0.3  | 0.3  | 0.3  |
|                                                                                          | $U \; 6p_{\sigma} \! \leftrightarrow \! O \; 2p_{s}$         | 36.2 | 36.4 | 40.0 |
|                                                                                          | $U \ 6s \leftrightarrow O \ 2p_s$                            | 12.2 | 12.3 | 12.9 |
|                                                                                          | $U 6p_{\sigma} \leftrightarrow O 2s_{p}$                     | 9.7  | 9.3  | 1.5  |
|                                                                                          | U 6s ↔ O 2s <sub>p</sub>                                     | 0.2  | 0.1  | 0.5  |
|                                                                                          | $U 6p_{\pi} \leftrightarrow C 2\pi^{d}$                      | 3.6  | 3.6  | 3.6  |
| (R <sup>a</sup> ) <sub>3</sub> N <sub>amine</sub> -U <sup>VI</sup> -N <sub>nitride</sub> | $U \ 6p_{\sigma} \leftrightarrow N_{nitride} \ 2p_{s}$       | 34.0 | 32.3 | 23.5 |
| (1) $(R^a)_3 N: U \equiv N:^c$                                                           | $U \ 6s \leftrightarrow N_{nitride} \ 2p_s$                  | 11.5 | 12.8 | 8.5  |
| (2) $(R^a)_3 N - U \equiv N$ :                                                           | $U \ 6p_{\sigma} \! \leftrightarrow \! N_{nitride} \ 2s_{p}$ | 9.1  | 10.0 | 18.5 |
| (3) (R <sup>a</sup> ) <sub>3</sub> N: U≣N                                                | $U \ 6s \leftrightarrow N_{nitride} \ 2p_s$                  | 1.3  | 0.4  | 4.3  |
|                                                                                          | $U 6p_{\pi} \leftrightarrow N_{\text{nitride}} 2\pi^{d}$     | 2.3  | 2.3  | 2.3  |
|                                                                                          | $U \; 6p_{\sigma} \! \leftrightarrow \! N_{amine} \; 2s_{p}$ | 8.4  | 8.6  | 8.8  |
|                                                                                          | $U \ 6s \leftrightarrow N_{amine} \ 2s_p$                    | 4.2  | 3.3  | 4.1  |

DFT/B3LYP calculations. Linear structures for the triatomics.

orbitals are meant to interact. We compare here the orbital entanglement diagrams for  $OUO^{+2}$ , CUO, and  $(R^a)_3 NU^{VI}N$ , shown in Fig. 3.

In the diagrams, the thickness of the connecting lines indicates the extent of entanglement. The diagrams reveal sizable mutual information between the MOs corresponding to the  $\sigma$  and  $\pi$  U=L bonds. It is also evident that the ligand lone pair is the least important (least entangled) for [OUO]<sup>+2</sup>. Although for CUO, both the C and O 2s<sub>p</sub> lone pairs are entangled with formally vacant 5f/6d U orbitals, indicative of the rearward bonding, the C 2s<sub>p</sub> orbital is more strongly entangled with the LUMO, in qualitative agreement with the preferred C≣U≡O resonance structure. The (Ra)3NUNIN diagram is qualitatively similar to CUO in this respect, and there is additionally substantial entanglement involving the MOs dominated by 2ps and 2s<sub>p</sub> AO contributions. Specifically, the 2s<sub>p</sub> lone pair shares mutual information with a low lying virtual orbital. Closer inspection of the 2s<sub>p</sub> orbitals shows pronounced mixing with the U 5f, 6d, 6p, and 6s and  $\textit{trans}\,N_{amine}\,2p_s\,AOs.$  It appears that the entanglement gives away the multi-center bonding and PFB interactions identified in the DFT calculations

For the orbital entanglement measurements, we found it necessary to use relatively large active spaces [e.g., MPS(24e, 24o)]. Previous MPS calculations of neptunium organometallic compounds demonstrated that small CASSCF spaces lead to overlocalization of the 5f shell and an underestimation of the ligand donation (dative bonding)<sup>49,50</sup>. Although (12e, 12o)<sup>51</sup> and (8e, 8o)<sup>5</sup> active spaces have been used

a,bEnergies in kcal mol-1

c,d Interactions illustrated in Fig. 2.

 $<sup>^{\</sup>rm a}$  NBO second-order perturbation theory donor–acceptor  $\Delta E^{(2)}$  stabilization energy.

<sup>&</sup>lt;sup>b</sup> ETS-NOCV contributions to  $\Delta E_{\text{orb}}$ . The  $\Delta E_{\text{orb}}$  and  $\Delta E^{(2)}$  for the two  $\pi$ -bonding interactions are equivalent and only one is listed.

<sup>°</sup>ΔE<sup>(2)</sup> donor-acceptor interactions involving 6s and 6p An semi-core shells.

 $<sup>^{</sup>d}\Delta E^{(2)}$  donor–interaction between the terminal and trans ligand lone pair and formally unoccupied An-centered NBOs. For the symmetric small compounds interactions nos. 4 and 5 are identical.

<sup>&</sup>lt;sup>e</sup>Data for the *trans*-An bond for a selected compounds.

<sup>&</sup>lt;sup>f</sup>Data for the full experimental (R<sup>a</sup>)<sub>3</sub>NU<sup>VI</sup>N structure for comparison.

<sup>&</sup>lt;sup>a</sup>Energies in kcal mol<sup>-1</sup>.

 $<sup>{}^</sup>b$ The dominant structure for uranyl is  $O \equiv U \equiv O^{+2}$ .

<sup>°</sup>This is not a major resonance structure for CUO or  $(R^a)_3N-U^{VI}-N$ ; it was included for direct comparison with  $O\equiv U\equiv O^{*2}$ .

 $<sup>^{\</sup>mathrm{d}}\mathrm{Data}$  for one of the two equivalent U  $6p_{\pi}$   $\leftrightarrow$   $ligand_{\pi}$  pairwise steric energies is shown.

![](_page_6_Figure_2.jpeg)

Fig. 3 | Ground state orbital entanglement diagrams (from MPS(24e,24o) calculations with 12 occupied and 12 virtual orbitals) for the [OUO] $^{+2}$ ion, CUO, and (R $^{a}$ ) $_{3}$ NU $^{VI}$ N. Orbitals involving the rearward 2s $_{p}$  hybrid are highlighted by a red dashed line. MPS natural occupation numbers are given in black for the entangled orbitals. The area of the red circles is proportional to an orbital's single-orbital

entropy, while the thickness of connecting lines is proportional to the mutual orbital pair information. Orbital isosurface values are  $\pm 0.04$  atomic units and rendered in red/blue vs. orange/yellow for high- vs. low-occupancy orbitals, respectively.

previously to investigate the electronic structure of CUO, these active spaces appear to be insufficient to bring about a full picture of the bonding. To describe the C–U and U–O sets of bonds, 4 C–U and 4 U–O (2p<sub>s</sub>, 2s<sub>p</sub> and two  $\pi$  each) occupied orbitals are needed. Thus, it is necessary to include at least 8 doubly occupied orbitals (16 electrons) in the active space for CUO. We therefore speculate that the use of smaller active spaces (see Supplementary Fig. 1) in previous research may have obscured the 3-center bonding and ITI interactions in CUO to some degree.

#### Discussion

Taken together, the NLMO BO decomposition,  $\Delta E^{(2)}$  delocalization energies, and ETS-NOCV bonding analyses paint a clear picture of 6p covalency as well as overlap-driven Pauli repulsion as part of the PFB mechanism. Furthermore, state-of-the-art KS-DFT and multiconfigurational WFT-based analyses uncovered a rearward interaction of the 2s<sub>p</sub> hybrid ligand lone pair with the metal, previously implicated in the C-U bond in CUO, among a range of actinide compounds. The rearward 2s<sub>p</sub> participation facilitates a fourth covalent interaction with terminal nitrido or oxo ligands in several of the studied systems. Actinide  $6p_{\sigma}$  (and 6s) contributions can be identified in this fourth, rearward interaction, which means that PFB assists, if not enables, a resonance stabilization resulting in the ITI noted for actinide compounds. It also appears that the present study is the first or perhaps one of few reports so far of oxo ligands featuring quadruple bonding interactions. Although the bonds in the studied actinyl ions do not qualify as quadruple, the oxo rearward 2s<sub>p</sub> bonding contributions also lead to additional stabilization. The ligand 2s<sub>p</sub> bonding contributions are most prominent for the exceptionally covalent organoactinide compounds that were selected for this study, in which we are also able to identify a 3c4e or CS bond involving the trans ligand. Overall, the data reveal that the PFB mechanism is a vital component of the bond multiplicity in actinide compounds. It is likely much more prevalent than previously anticipated. (With the latter statement, we echo a conclusion from ref. 24). The present computational study therefore shows that there are still many secrets related to the mystery of 5f covalency that can be uncovered, pushing the boundaries of our understanding of chemical bonding.

#### Methods

Absent experimental structures for gas-phase actinyl ions, CUO, and NUN, the geometries for these systems were optimized in linear symmetry with KS-DFT using the Amsterdam Density Functional (ADF) program version 2022<sup>52</sup> with the B3LYP functional<sup>53</sup> and the zeroth-order regular approximation (ZORA) all-electron scalar relativistic Hamiltonian<sup>54,55</sup>. The N–U distance of 1.75 Å for NU<sup>2+</sup> was taken from ref. 56. For the An(TREN<sup>TIPS</sup>N/O) and PhCC/MeU<sup>VI</sup>[N(SiMe<sub>3</sub>)<sub>2</sub>]<sub>3</sub>

compounds we used the available experimental crystal structures  $^{17,20,24-27}$ . Given the comparatively large size of the TREN  $^{\rm TIPS}$  ligand, truncated model structures replacing  $^{\rm i}$ Pr groups by hydrogen were used. Hydrogen positions were optimized as described above. All KS-DFT calculations employed Slater-type orbital (STO) triple- $\zeta$  polarized (TZ2P) all electron basis sets  $^{57}$ . For the subsequent electronic structure analyses, the eXact two-Component (X2C) Hamiltonian was used  $^{58-60}$ .

NBO analyses<sup>33</sup> were carried out with version 6 of the code included in the ADF suite. For the calculation of the NBO second-order stabilization energies, reference Lewis structures were specified using the CHOOSE keyword<sup>35</sup> to allow direct comparisons between different molecules. Resonant Lewis structures were generated and evaluated using the natural resonance theory (NRT) module in NBO, with high thresholds (20 kcal mol<sup>-1</sup>) to avoid minor intruding hyperconjugative interactions<sup>35,36</sup>. The bonding covalent interactions and the corresponding energy contributions to the total binding energy were evaluated with the extended transition state (ETS) NOCV approach<sup>39</sup> as implemented in ADF. For the ETS-NOCV analyses, the molecules were divided into two ionic fragments by cleaving the terminal bond (e.g.,  $UO^{4+}$  and  $O^{2-}$  for  $UO_2^{2+}$ , or  $\left[U(TREN^{TIPS})\right]^{3+}$  and  $N^{3-}$  for  $(R^a)_3NU^{VI}N)$ , to facilitate comparison among different molecules<sup>61</sup>. Pauli repulsion interactions were evaluated for a subset of molecules using the natural steric analysis in NBO62. Selected Quantum Theory of Atoms In Molecules (QTAIM) analyses were performed with the Bader module in ADF<sup>63</sup>.

To ascertain that the results reported herein are only weakly dependent on the chosen DFT functional, additional bonding analyses were conducted for UO2<sup>2+</sup> and (R<sup>a</sup>)<sub>3</sub>NU<sup>VI</sup>N with the functionals PBE, PBEO, and TPSSh. Likewise, because several optimized sets of bond lengths for CUO have been reported in the literature<sup>5,51,64-67</sup>, we carried out additional analyses for CUO with an X2C/DFT (PBEO functional) geometry<sup>66</sup>, which has slightly shorter C–U and U–O distances of 1.733 and 1.779 Å, respectively, compared to our ZORA/B3LYP bond lengths (1.746, 1.801 Å). Relevant data are provided in Supplementary Tables 1–5, showing that general conclusions can be drawn based on the B3LYP calculations. Given the multi-center nature of the 4th bonding interaction with the rearward 2s<sub>p</sub> AO and the general consensus that high An–ligand bond multiplicities are possible in the types of systems studied herein, inclusion of the spin–orbit interaction in the calculations was not deemed to be essential.

In addition to KS-DFT calculations, scalar X2C multiconfigurational wavefunction calculations were performed for OUO<sup>2+</sup>, CUO, and (R<sup>a</sup>)<sub>3</sub>NU<sup>VI</sup>N with the open-source version of the Molcas program (OpenMolcas)<sup>68-70</sup> at the complete active space (CAS) self consistent field (SCF)<sup>71</sup> matrix product state (MPS) DMRG level<sup>72</sup>. These calculations were used to generate orbital entanglement diagrams, among other information, with the QCMaquis extension  $^{73-75}$  of Molcas. These calculations employed Gaussian-type all electron atomic natural orbital relativistic semi-core correlation (ANO-RCC) basis sets  $^{76}$  in their valence triple- $\zeta$  contractions, except for hydrogen atoms where the double- $\zeta$  contraction was used instead for computational efficiency. The on-the-fly generated auxiliary-basis RICD functionality was utilized for the electron repulsion integrals  $^{77}$ . Symmetry was not specifically imposed in the wavefunction calculations. Initial orbitals for the orbital-optimizing DMRG runs were obtained from CASSCF calculations with relatively large active spaces [e.g., (16e, 13o) for CUO, and (12e, 13o) for  $(R^a)_3NU^{VI}N$ ]. Series of DMRG calculations were then conducted with active spaces enlarged by subsequent increments of 2 electrons and 2 orbitals, and the orbitals were carefully monitored to ensure that the intended active space was maintained.

Orbital entanglement diagrams were constructed using the AutoCAS software<sup>44</sup>. For the MPS calculations, m = 1024 and 15 sweeps were used. The ground state orbital entanglement diagrams were calculated for (14e, 14o) up to (24e, 24o) active spaces. Finally, to ascertain that the orbital entanglement diagrams are only weakly dependent on the reported CUO bond lengths, the (24e, 24o) and (12e, 12o) orbital entanglement diagrams based on the B3LYP geometry were compared to a (12e, 12o) diagram based on the PBEO geometry. The diagrams are provided in Supplementary Fig. 1.

#### Data availability

All data generated and analyzed in this study are included in this article, its supplementary information, and the publicly available source files at <a href="https://doi.org/10.5281/zenodo.7853933">https://doi.org/10.5281/zenodo.7853933</a>. The zenodo repository includes all ADF and OpenMolcas output files from which the data presented in this study were extracted. Other data related to this study can be obtained from the corresponding author upon request.

#### References

- Glueckauf, E. & McKay, H. Possible f-shell covalency in the actinide elements. Nature 165, 594–595 (1950).
- Street Jr, K. & Seaborg, G. T. The separation of americium and curium from the rare earth elements. J. Am. Chem. Soc. 72, 2790–2792 (1950).
- 3. Katzin, K. Possible f-shell covalency in the actinide elements. *Nature* **166**, 605 (1950).
- Streit, M. & Ingold, F. Nitrides as a nuclear fuel option. J. Eur. Ceram. Soc. 25, 2687–2692 (2005).
- Hu, H.-S., Qiu, Y.-H., Xiong, X.-G., Schwarz, W. E. & Li, J. On the maximum bond multiplicity of carbon: unusual C≡U quadruple bonding in molecular CUO. Chem. Sci. 3, 2786–2796 (2012).
- Platts, J. A. & Baker, R. J. A computational investigation of orbital overlap versus energy degeneracy covalency in [UE<sub>2</sub>]<sup>2+</sup> (E = O, S, Se, Te) complexes. *Dalton Trans.* 49, 1077–1088 (2020).
- 7. Denning, R. G. Electronic structure and bonding in actinyl ion and their analogs. *J. Phys. Chem. A* **111**, 4125–4143 (2007).
- Denning, R. G. Electronic Structure and Bonding in Actinyl Ions 215–276 (Springer Berlin Heidelberg, 1992).
- 9. Fox, A. R. & Cummins, C. C. Uranium- nitrogen multiple bonding: the case of a four-coordinate uranium (vi) nitridoborate complex. *J. Am. Chem.* Soc. **131**, 5716–5717 (2009).
- 10. Tatsumi, K. & Hoffmann, R. Bent cis  $d^0$  MoO $_2^{2+}$  vs. linear trans  $d^0$  MoO $_2^{2+}$ : a significant role for nonvalence 6p orbitals in uranyl. *Inorg. Chem.* **19**, 2656–2658 (1980).
- Pepper, M. & Bursten, B. E. The electronic structure of actinidecontaining molecules: a challenge to applied quantum chemistry. *Chem. Rev.* 91, 719–741 (1991).
- Dyall, K. G. Bonding and bending in the actinyls. *Mol. Phys.* 96, 511–518 (1999).
- Kaltsoyannis, N. Computational study of analogues of the uranyl ion containing the -N=U=N- unit: density functional theory calculations

- on UO2<sup>2+</sup>, UON<sup>+</sup>, UN<sub>2</sub>, UO(NPH<sub>3</sub>)<sup>3+</sup>, U(NPH<sub>3</sub>)<sup>4+</sup>, [UCl<sub>4</sub>{NPR<sub>3</sub>}<sub>2</sub>](R = H, Me), and [UOCl<sub>4</sub>{NP(C<sub>6</sub>H<sub>5</sub>)<sub>3</sub>}]<sup>-</sup>. *Inorg. Chem.* **39**, 6009–6017 (2000).
- 14. Jørgensen, C. K. & Reisfeld, R. in *Topics in Inorganic and Physical Chemistry* 121–171 (Springer Berlin Heidelberg, 1982).
- Feng, R., Glendening, E. D. & Peterson, K. A. Coupled cluster studies of platinum-actinide interactions. thermochemistry of PtAnO n+(n = 0-2 and An = U, Np, Pu). J. Phys. Chem. A 125, 5335-5345 (2021).
- O'Grady, E. & Kaltsoyannis, N. On the inverse trans influence.
  Density functional studies of [MOX<sub>5</sub>]<sup>n-</sup> (M = Pa, n = 2; M = U, n = 1; M = Np, n = 0; X = F, Cl or Br). Dalton Trans. 6, 1233–1239 (2002).
- Lewis, A. J., Carroll, P. J. & Schelter, E. J. Stable uranium (VI) methyl and acetylide complexes and the elucidation of an inverse trans influence ligand series. J. Am. Chem. Soc. 135, 13185–13192 (2013).
- Kosog, B., La Pierre, H. S., Heinemann, F. W., Liddle, S. T. & Meyer, K. Synthesis of uranium (VI) terminal oxo complexes: molecular geometry driven by the inverse trans-influence. *J. Am. Chem. Soc.* 134, 5284–5289 (2012).
- Gardner, B. M. & Liddle, S. T. Uranium triamidoamine chemistry. Chem. Comm. 51, 10589–10607 (2015).
- 20. King, D. M. et al. Synthesis and structure of a terminal uranium nitride complex. *Science* **10**, 717–720 (2012).
- 21. Zhao, J. et al. Cis- and trans-binding influences in  $[NUO \cdot (N_2)_n]^+$ . J. Chem. Phys. **157**, 054301 (9 pages) (2022).
- Pyykkö, P. & Lohr Jr, L. L. Relativistically parameterized extended Hückel calculations. 3. Structure and bonding for some compounds of uranium and other heavy elements. *Inorg. Chem.* 20, 1950–1959 (1981).
- Pyykkö, P. & Laaksonen, L. Relativistically parameterized extended Hückel calculations. 8. Double-ζ parameters for the actinoids thorium, protactinium, uranium, neptunium, plutonium, and americium and an application on uranyl. J. Phys. Chem. 88, 4892–4895 (1984).
- Du, J. et al. Thorium-nitrogen multiple bonds provide evidence for pushing-from-below for early actinides. *Nat. Commun.* 10, 1–13 (2019).
- 25. Dutkiewicz, M. S. et al. A terminal neptunium (V)-mono (oxo) complex. *Nat. Chem.* **14.** 342–349 (2022).
- 26. King, D. M. et al. Isolation and characterization of a uranium (VI)-nitride triple bond. *Nat. Chem.* **5**, 482-488 (2013).
- King, D. M. et al. Single-molecule magnetism in a single-ion triamidoamine uranium (V) terminal mono-oxo complex. *Angew. Chem. Int. Ed* 52, 4921–4924 (2013).
- Mayer, I. Using singular value decomposition for a compact presentation and improved interpretation of the CIS wave functions. Chem. Phys. Lett. 437, 284–286 (2007).
- Nalewajski, R. F., Mrozek, J. & Michalak, A. Two-electron valence indices from the Kohn-Sham orbitals. *Int. J. Quant. Chem.* 61, 589–601 (1997).
- 30. Gopinathan, M. & Jug, K. Valency. I. A quantum chemical definition and properties. *Theor. Chim. Acta* **63**, 497–509 (1983).
- Michalak, A., DeKock, R. L. & Ziegler, T. Bond multiplicity in transition-metal complexes: applications of two-electron valence indices. J. Phys. Chem. A 112, 7256–7263 (2008).
- 32. Takagi, N., Krapp, A. & Frenking, G. Bonding analysis of metal-metal multiple bonds in  $R_3M-M'R_3$  (M, M'= Cr, Mo, W; R = Cl, NMe<sub>2</sub>). Inorg. Chem. **50**, 819–826 (2011).
- 33. Glendening, E. D., Landis, C. R. & Weinhold, F. Natural bond orbital methods. *Wiley Interdiscip. Rev.: Comput. Mol. Sci.* **2**, 1–42 (2012).
- 34. Glendening, E. D., Badenhoop, J. & Weinhold, F. Natural resonance theory: III. Chemical applications. *J. Comput. Chem.* **19**, 628–646 (1998).
- Landis, C. R., Hughes, R. P. & Weinhold, F. Bonding analysis of TM(cAAC)<sub>2</sub> (TM= Cu, Ag, and Au) and the importance of reference state. Organometallics 34, 3442–3449 (2015).
- Landis, C. R. & Weinhold, F. Valence and extra-valence orbitals in main group and transition metal bonding. J. Comput. Chem. 28, 198–203 (2007).

- 37. Alvarez, S., Hoffmann, R. & Mealli, C. A bonding quandary–or–a demonstration of the fact that scientists are not born with logic. Eur. J. Chem. 15, 8358–8373 (2009).
- 38. Shaik, S. et al. Charge-shift bonding: a new and unique form of bonding. Angew. Chem. Int. Ed. 59, 984–1001 (2020).
- 39. Mitoraj, M. P., Michalak, A. & Ziegler, T. A combined charge and energy decomposition scheme for bond analysis. J. Chem. Theory Comput. 5, 962–975 (2009).
- 40. Tecmer, P., Boguslawski, K., Legeza, Ö. & Reiher, M. Unravelling the quantum-entanglement effect of noble gas coordination on the spin ground state of CUO. Phys. Chem. Chem. Phys. 16, 719–727 (2014).
- 41. Boguslawski, K., Marti, K. H. & Reiher, M. Orbital entanglement in bond-formation processes. J. Chem. Theory Comput. 9, 2959–2973 (2011).
- 42. Boguslawski, K., Tecmer, P., Legeza, Ö. & Reiher, M. Entanglement measures for single- and multireference correlation effects. J. Phys. Chem. Lett. 3, 3129–3135 (2012).
- 43. Stein, C. J., von Burg, V. & Reiher, M. The delicate balance of static and dynamic electron correlation. J. Chem. Theory Comput. 12, 3764–3773 (2016).
- 44. Stein, C. J. & Reiher, M. Automated selection of active orbital spaces. J. Chem. Theory Comput. 12, 1760–1771 (2016).
- 45. Stein, C. J. & Reiher, M. Measuring multi-configurational character by orbital entanglement. Mol. Phys. 115, 2110–2119 (2017).
- 46. Stein, C. J. & Reiher, M. Automated identification of relevant frontier orbitals for chemical compounds and processes. Chimia 71, 170–176 (2017).
- 47. Legeza, Ö. & Sólyom, J. Optimizing the density-matrix renormalization group method using quantum information entropy. Phys. Rev. B 68, 195116 (2003).
- 48. Rissler, J., Noack, R. M. & White, S. R. Measuring orbital interaction using quantum information theory. Chem. Phys. 323, 519–531 (2006).
- 49. Motta, L. C. & Autschbach, J. 237Np Mössbauer isomer shifts: a lesson about the balance of static and dynamic electron correlation in heavy element complexes. J. Chem. Theory Comput. 18, 3483–3496 (2022).
- 50. Motta, L. C. & Autschbach, J. Theoretical evaluation of metal-ligand bonding in neptunium compounds in relation to 237Np Mössbauer spectroscopy. Inorg. Chem. 61, 13399–13412 (2022).
- 51. Tecmer, P., Boguslawski, K., Legeza, Ö. & Reiher, M. Unravelling the quantum-entanglement effect of noble gas coordination on the spin ground state of CUO. Phys. Chem. Chem. Phys. 16, 719–727 (2014).
- 52. Baerends, E. J. et al. ADF2022.1, SCM, Theoretical Chemistry, Vrije Universiteit, Amsterdam, The Netherlands. https://www.scm.com.
- 53. Becke, A. D. Density–functional thermochemistry. III. The role of exact exchange. J. Chem. Phys. 98, 5648–5652 (1993).
- 54. van Lenthe, E., Baerends, E. J. & Snijders, J. G. Relativistic regular twocomponent Hamiltonians. J. Chem. Phys. 99, 4597–4610 (1993).
- 55. van Lenthe, E., Ehlers, A. & Baerends, E. J. Geometry optimizations in the zero order regular approximation for relativistic effects. J. Chem. Phys. 110, 8943–8953 (1999).
- 56. Meng, Q. et al. UN@C82:aU ≡ N triple bond captured inside fullerene cages. Nat. Commun. 13, 7192 (10 pages) (2022).
- 57. van Lenthe, E. & Baerends, E. J. Optimized Slater-type basis sets for the elements 1-118. J. Comput. Chem. 24, 1142–1156 (2003).
- 58. Dyall, K. G. Interfacing relativistic and nonrelativistic methods. I. Normalized elimination of the small component in the modified Dirac equation. J. Chem. Phys. 106, 9618–9626 (1997).
- 59. Kutzelnigg, W. & Liu, W. Quasirelativistic theory equivalent to fully relativistic theory. J. Chem. Phys. 123, 241102–4 (2005).
- 60. Ilias, M. & Saue, T. An infinite-order two-component relativistic Hamiltonian by a simple one-step transformation. J. Chem. Phys. 126, 064102 (2007).

- 61. Wu, Q.-Y., Wang, C.-Z., Lan, J.-H., Chai, Z.-F. & Shi, W.-Q. Electronic structures and bonding of the actinide halides An (TREN TIPS) X (An= Th–Pu; X= F–I): a theoretical perspective. Dalton Trans. 49, 15895–15902 (2020).
- 62. Badenhoop, J. & Weinhold, F. Natural bond orbital analysis of steric interactions. J. Chem. Phys. 107, 5406–5421 (1997).
- 63. Rodríguez, J. I. An efficient method for computing the QTAIM topology of a scalar field: the electron density case. J. Comput. Chem. 34, 681–686 (2013).
- 64. Bursten, B. E., Drummond, M. L. & Li, J. The quantum chemistry of dand f-element complexes: from an approximate existence to functional happiness. Faraday Discuss. 124, 457–458 (2003).
- 65. Nowak, A., Tecmer, P. & Boguslawski, K. Assessing the accuracy of simplified coupled cluster methods for electronic excited states in f0 actinide compounds. Phys. Chem. Chem. Phys. 21, 19039–19053 (2019).
- 66. Tecmer, P., Van Lingen, H., Gomes, A. S. P. & Visscher, L. The electronic spectrum of CUONg4 (Ng= Ne, Ar, Kr, Xe): New insights in the interaction of the CUO molecule with noble gas matrices. J. Chem. Phys. 137, 084308 (2012).
- 67. Yang, T., Tyagi, R., Zhang, Z. & Pitzer, R. Configuration interaction studies on the electronic states of the CUO molecule. Mol. Phys. 107, 1193–1195 (2009).
- 68. Galván, I. F. et al. OpenMolcas: from source code to insight. J. Chem. Theory Comput. 15, 5925–5964 (2019).
- 69. Aquilante, F. et al. Modern quantum chemistry with [Open]Molcas. J. Chem. Phys. 152, 214117 (2020).
- 70. OpenMolcas. https://gitlab.com/Molcas/. Accessed 07/23.
- 71. Roos, B. O., Lindh, R., Malmqvist, P. Å., Verazov, V. & Widmark, P.-O. Multiconfigurational Quantum Chemistry (John Wiley & Sons, 2016).
- 72. Baiardi, A. & Reiher, M. The density matrix renormalization group in chemistry and molecular physics: recent developments and new challenges. J. Chem. Phys. 152, 040903 (2020).
- 73. Keller, S. F. & Reiher, M. Determining factors for the accuracy of DMRG in chemistry. Chimia 68, 200–203 (2014).
- 74. Keller, S., Dolfi, M., Troyer, M. & Reiher, M. An efficient matrix product operator representation of the quantum chemical Hamiltonian. J. Chem. Phys. 143, 244118 (2015).
- 75. Knecht, S. et al. New approaches for ab-initio calculations of molecules with strong electron correlation. Chimia 70, 244–251 (2016).
- 76. Roos, B. O., Lindh, R., Malmqvist, P., Veryazov, V. & Widmark, P. New relativistic ANO basis sets for transition metal atoms. J. Phys. Chem. A 109, 6575–6579 (2005).
- 77. Aquilante, F., Lindh, R. & Bondo Pedersen, T. Unbiased auxiliary basis sets for accurate two-electron integral approximations. J. Chem. Phys. 127, 114107 (2007).

# Acknowledgements

This work was supported by the U.S. Department of Energy, Office of Basic Energy Sciences, Heavy Element Chemistry program, under grant DE-SC0001136 to J.A. The authors acknowledge the Center for Computational Research (CCR) at the University at Buffalo for providing computational resources and thank Prof. W. H. E. Schwarz for constructive comments on the manuscript.

# Author contributions

L.C.M. performed all calculations and prepared figures, tables, and supplementary data. J.A. designed the project and secured external funding. Both authors analyzed the data and co-wrote the manuscript.

# Competing interests

The authors declare no competing interests.

# Additional information

Supplementary information The online version contains supplementary material available at https://doi.org/10.1038/s41467-023-39626-8.

Correspondence and requests for materials should be addressed to Jochen Autschbach.

Peer review information Nature Communications thanks the anonymous reviewers for their contribution to the peer review of this work. A peer review file is available.

Reprints and permissions information is available at http://www.nature.com/reprints

Publisher's note Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations.

Open Access This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons licence, and indicate if changes were made. The images or other third party material in this article are included in the article's Creative Commons licence, unless indicated otherwise in a credit line to the material. If material is not included in the article's Creative Commons licence and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this licence, visit http://creativecommons.org/ licenses/by/4.0/.

© The Author(s) 2023