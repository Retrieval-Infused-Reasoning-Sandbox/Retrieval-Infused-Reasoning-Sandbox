# One-hundred-three compound band-structure benchmark of post-self-consistent spin-orbit coupling treatments in density functional theory

William P. Huhn\* and Volker Blum

Department of Mechanical Engineering and Materials Science, Duke University, Durham, North Carolina 27708, USA (Received 4 May 2017; published 30 August 2017)

We quantify the accuracy of different non-self-consistent and self-consistent spin-orbit coupling (SOC) treatments in Kohn-Sham and hybrid density functional theory by providing a band-structure benchmark set for the valence and low-lying conduction energy bands of 103 inorganic compounds, covering chemical elements up to polonium. Reference energy band structures for the PBE density functional are obtained using the full-potential (linearized) augmented plane wave code WIEN2K, employing its self-consistent treatment of SOC including Dirac-type  $p^{1/2}$  orbitals in the basis set. We use this benchmark set to benchmark a computationally simpler, non-self-consistent all-electron treatment of SOC based on scalar-relativistic orbitals and numeric atom-centered orbital basis functions. For elements up to  $Z \approx 50$ , both treatments agree virtually exactly. For the heaviest elements considered (Tl, Pb, Bi, Po), the band-structure changes due to SOC are captured with a relative deviation of 11% or less. For different density functionals (PBE versus the hybrid HSE06), we show that the effect of spin-orbit coupling is usually similar but can be dissimilar if the qualitative features of the predicted underlying scalar-relativistic band structures do not agree. All band structures considered in this work are available online via the NOMAD repository to aid in future benchmark studies and methods development.

### DOI: 10.1103/PhysRevMaterials.1.033803

#### I. INTRODUCTION

Spin-orbit coupling (SOC) is an essential ingredient for quantitatively correct energy band structures of materials composed of any but the lightest elements, appearing in materials applications as diverse as heavy-light hole masses in conventional semiconductors [1–3], Rashba splittings in reduced dimensionality systems [4–6], topologically insulating phases [7], and Berry phase physics [8]. Yet, for reasons of cost and convenience, the effects of spin-orbit coupling in different computational studies are often approximated based on different underlying scalar-relativistic (SR) orbitals and, at the simplest level, in a non-self-consistent fashion. In standard or generalized Kohn-Sham density functional theory [(g)KSDFT] [9–11], the effects of SOC on electronic levels can be incorporated into calculations by way of the spin-orbit-coupled effective Hamiltonian

$$\begin{split} \hat{H}[n] &= \hat{t}_{SR} + \hat{v}_{ext} + \hat{v}_{es} + \hat{v}_{XC} + \hat{v}_{SOC} \\ &= \hat{t}_{SR} + \hat{v} + \hat{v}_{SOC} \\ &= \hat{H}_{SR}[n] + \hat{v}_{SOC}, \end{split} \tag{1}$$

where n is the electron density obtained from a scalarrelativistic calculation,  $\hat{t}_{SR}$  is the SR kinetic energy operator,  $\hat{v}_{ext}$  is the external potential operator,  $\hat{v}_{es}$  is the electrostatic or Hartree potential operator of the electrons,  $\hat{v}_{XC}$  is the exchangecorrelation potential operator,  $\hat{H}_{SR}$  is the SR Hamiltonian operator, and  $\hat{v}$  is the effective or Kohn-Sham potential operator.  $\hat{v}_{SOC}$  is the spin-orbit coupling operator

$$\hat{v}_{SOC} = \frac{i}{4c^2} \hat{\boldsymbol{\sigma}} \cdot \hat{\boldsymbol{p}} \hat{v} \times \hat{\boldsymbol{p}}, \tag{2}$$

where atomic units are used. "Hatted" quantities indicate operators. Spatial vector quantities are indicated by boldfaced

characters, and scalar quantities (and individual components of vectors) are unbolded. Here,  $\hat{p}$  is the momentum operator and  $\hat{\sigma}$  is the vector spin operator of Pauli matrices, assumed to be polarized along the z axis,

$$\hat{\sigma}_x = \begin{bmatrix} 0 & 1 \\ 1 & 0 \end{bmatrix}, \quad \hat{\sigma}_y = \begin{bmatrix} 0 & -i \\ i & 0 \end{bmatrix}, \quad \hat{\sigma}_z = \begin{bmatrix} 1 & 0 \\ 0 & -1 \end{bmatrix}. \quad (3)$$

Equation (1) is the textbook expression and is itself already an approximation to the more accurate, fully relativistic Dirac-Kohn-Sham equations (see below). SOC can be added as part of routine computations in many electronic structure codes, but in fact a variety of different approximations to capture the effects of SOC are commonly employed. Some of the many possible approaches include (i) solving the Dirac-Kohn-Sham equation directly [12–15], (ii) including the SOC term in the zero-order regular approximation (ZORA) [16,17], (iii) the non-self-consistent or (iv) self-consistent second-variational method following a self-consistent scalar-relativistic calculation [18,19], or (v) the direct inclusion of SOC effects into pseudopotentials [17,20–23]. In the second-variational method, matrix elements for the full Hamiltonian

$$H_{m\alpha;m'\alpha'} = \langle \psi_{m\alpha} \alpha | [\hat{H}_{SR}[n] + \hat{v}_{SOC}] | \psi_{m'\alpha'} \alpha' \rangle$$
  
=  $\delta_{mm'} \delta_{\alpha\alpha'} \epsilon_{m\alpha} + \langle \psi_{m\alpha} \alpha | \hat{v}_{SOC} | \psi_{m'\alpha'} \alpha' \rangle$ , (4)

are calculated and diagonalized, where  $\alpha$  is a spinor,  $\psi_{m\alpha}$  is the scalar-relativistic KS eigenvector for energy index m and spin channel  $\alpha$ , and  $\epsilon_{m\alpha}$  is the SR energy eigenvalue of  $\psi_{m\alpha}$ . Second-variational SOC is performed as a post-processed correction on a number of (spin-non-polarized) SR eigenvectors with size  $2N_{\rm states}$ , where  $N_{\rm states}$  is the number of SR eigenvectors included. This is in contrast to the first-variational method, in which the problem is solved on the full set of SR eigenvectors with size  $2N_{\rm basis}$ , which is equivalent up to unitary transformation to calculation and diagonalization of matrix elements of the full Hamiltonian defined on computational

<sup>\*</sup>Corresponding author: william.paul.huhn@gmail.com

<sup>&</sup>lt;sup>†</sup>Corresponding author: volker.blum@duke.edu

basis functions  $\varphi_n$ :

$$H_{n\alpha;n'\alpha'} = \langle \varphi_n \alpha | [\hat{H}_{SR} + \hat{v}_{SOC}] | \varphi_{n'} \alpha' \rangle. \tag{5}$$

Since the final diagonalization step of the second-variational method is performed on a system with dimension  $2N_{\rm states} \ll 2N_{\rm basis}$ , the second-variational method constitutes a notable reduction in problem size compared to the first-variational method. In principle, both the first- and the second-variational approaches can be employed non-self-consistently (following a self-consistent SR calculation) or self-consistently by iterating over the eigenvectors obtained from the diagonalization of the Hamiltonians (4) or (5).

Second-variational spin-orbit coupling (non-self-consistent or self-consistent) is expected to offer a performance advantage over a full two- or four-component treatment from the outset, as it preserves the fundamental symmetries of scalar relativity for the initial self-consistency cycle of an electronic structure calculation. Scalar-relativistic self-consistency can be obtained with the assumption of spin collinearity and, depending on the system, real algebra. The more costly complex linear algebra and doubling of the problem size due to spin noncollinearity, implicit in Eqs. (2), (4) and (5), are then introduced only after the scalar-relativistic SCF cycle has finished.

Non-self-consistent second-variational spin-orbit coupling has an additional performance advantage, as no additional self-consistent-field (SCF) steps are required and spin-orbit coupling is applied only once per calculation. In particular, the non-self-consistent approach avoids computationally-expensive operations such as additional density and Fock matrix evaluations, which are required for a self-consistent approach. Towards large system sizes, the  $O(N^3)$  diagonalization would become costly and also occurs only once. On the other hand, the accuracy of non-self-consistent SOC is expected to decrease with increasing elemental atomic numbers Z, as is documented in the literature [24–27]. A detailed quantitative assessment is thus needed to gauge the expected reliability of the approach across the periodic table.

In this paper, we provide a broad assessment of the accuracy of first- or second-variational, non-self-consistent (NSC) SOC for all-electron energy band-structure calculations, based on numeric atom-centered orbital (NAO) basis sets. NAO basis sets are widely used in electronic structure theory [28–38]. Here, we focus on the NAO basis sets provided with the FHI-AIMS [39] code, a high-accuracy [40,41] implementation of electronic structure theory for molecules and solids, suitable for large-scale simulations [42–44]. To benchmark the NAObased NSC approach to SOC, we consider band structures for 103 crystalline solids, incorporating 66 chemical species (up to Po) and using the semilocal PBE [45] functional. The benchmark set includes 45 elemental materials and 21 alkali halides in addition to a group of 37 compound semiconductors. Band structures considered in this work are provided online via the NOMAD repository [46] and are citable via digital object identifiers (DOIs) [47–49]. These band structures will aid the community in future methods development involving relativistic effects.

We compare our results to a self-consistent (SC) SOC implementation based on (linearized) augmented plane wave [50] and local orbital [51,52] [(L)APW+lo] basis sets, which we abbreviate as "APW SC SOC," in the all-electron code

WIEN2K [53]. Optionally, the accuracy of the (L)APW+lo approach may be improved by including Dirac  $p^{1/2}$  local orbitals in the second-variational step [24,25]. We abbreviate this improved handling of SOC as "APW +  $p^{1/2}$  SC SOC."

Finally, we also investigate the exchange-correlation functional dependence of second-variational SOC by comparing band structures calculated by the PBE functional and the short-range screened hybrid exchange-correlation functional HSE06 [54–56] using the NAO basis set. SOC-related quantities calculated on semilocal and hybrid-functional levels of theory show close agreement for most materials, but important exceptions exist where qualitative differences in the scalar-relativistic band structures yield quantitative differences for SOC-related quantities. This highlights the need for qualitative accuracy in the underlying (g)KS scalar-relativistic band structure to achieve quantitative accuracy in spin-orbit-coupled calculations.

#### II. BACKGROUND

In relativistic Kohn-Sham density functional theory [57–61], the many-particle wave function  $\Psi$  of the system is rewritten by ansatz to a single Slater determinant of single-particle four-component wave functions  $\psi$  interacting with an effective relativistic potential operator  $\hat{v}[n,j]$ , where the dependence on current density j arises from covariance. Each single-particle wave function  $\psi$  then satisfies the Dirac-Kohn-Sham equation [61,62]

$$\begin{bmatrix} \hat{v} & c\hat{\boldsymbol{\sigma}} \cdot \hat{\boldsymbol{p}} \\ c\hat{\boldsymbol{\sigma}} \cdot \hat{\boldsymbol{p}} & \hat{v} - 2c^2 \end{bmatrix} \begin{bmatrix} \psi_L \\ \psi_S \end{bmatrix} = \epsilon \begin{bmatrix} \psi_L \\ \psi_S \end{bmatrix}, \tag{6}$$

where we have neglected the current density dependence of  $\hat{v}$  to introduce a scalar  $\hat{v}$ , and the single-particle bispinor  $\psi$  is decomposed into individual spinors  $\psi_L$  and  $\psi_S$ . In principle, solution of this equation would suffice to cover (almost) all relevant effects in chemistry and condensed matter science. However, the four-component approach necessitates additional computational expense and special care regarding basis sets and other quantities (e.g., energy gradients) and is therefore not commonly pursued in most implementations.

Three energy branches exist for the Dirac-Kohn-Sham equation: a positive continuum of unbound energy states with  $\epsilon \geqslant 0$ , a negative continuum of unbound energy states for finite systems with  $\epsilon \leqslant -2c^2$ , and a discrete spectrum of bound states lying within the  $[0,-2c^2]$  gap. The energy needed to couple the bound spectrum with the negative continuum solutions,  $\epsilon \approx 2c^2$ , would allow for electron-positron pair formation. However, this energy scale well exceeds the energy scales of electronic structure theory [63] for elements of interest in chemistry and materials science (usually  $Z \leqslant 100$ ). Accordingly, in the "no-pair" approximation, the negative continuum spectrum may be viewed as well separated from the bound spectrum and neglected, and the bound states may be regarded as electronlike.

Although Eq. (6) is a set of four differential equations, in the presence of a scalar potential it has only two degrees of freedom. There exists a coupling operator  $\hat{R}$  such that the "kinetic balance" condition

$$\psi_S = \hat{R}\psi_L \equiv \hat{K}\hat{\boldsymbol{\sigma}} \cdot \hat{\boldsymbol{p}}\psi_L \tag{7}$$

is satisfied for some operator  $\hat{K}$ , yielding an equation for  $\psi_L$  independent of  $\psi_S$ :

$$[c\hat{\boldsymbol{\sigma}}\cdot\hat{\boldsymbol{p}}\hat{K}\hat{\boldsymbol{\sigma}}\cdot\hat{\boldsymbol{p}}+\hat{v}]\psi_L=\epsilon\psi_L. \tag{8}$$

By simply using Eq. (6),  $\hat{K}$  can written exactly in closed form

$$\hat{K} = \frac{1}{2c} \left( 1 + \frac{\epsilon - \hat{v}}{2c^2} \right)^{-1} \tag{9}$$

for electronlike solutions, with a similar equation holding for positronlike solutions. However, the explicit dependence on  $\epsilon$  complicates the solution, and various further approximation schemes [62,64] exist for  $\hat{R}$ .

Equation (8) alone does *not* reduce Dirac-Kohn-Sham theory to a two-component formalism, as  $\psi_S$  is nonzero for nontrivial solutions and contributes to the normalization condition

$$1 = \langle \psi | \psi \rangle = \langle \psi_L | \psi_L \rangle + \langle \psi_S | \psi_S \rangle \tag{10}$$

defined on the full four-component wave function. Elimination of  $\psi_S$  can be accomplished by exact two-component formalisms [63–65] which fully decouple  $\psi_L$  and  $\psi_S$  using numerical construction of R and suitable unitary transformation of Eq. (6), but this formalism will not be considered in this paper.

The Dirac identity, valid for operators  $\hat{a}$  which satisfy  $[\hat{a}, \hat{\sigma}] = 0$ , asserts that

$$(\hat{\boldsymbol{\sigma}} \cdot \hat{\boldsymbol{a}})(\hat{\boldsymbol{\sigma}} \cdot \hat{\boldsymbol{b}}) = \hat{\boldsymbol{a}} \cdot \hat{\boldsymbol{b}}\hat{\boldsymbol{I}}_2 + i\hat{\boldsymbol{\sigma}} \cdot \hat{\boldsymbol{a}} \times \hat{\boldsymbol{b}}. \tag{11}$$

Making the identification  $\hat{a} \equiv \hat{p}\hat{K}$  and  $\hat{b} \equiv \hat{p}$ , Eq. (8) becomes

$$[c\,\hat{\boldsymbol{p}}\,\hat{K}\cdot\hat{\boldsymbol{p}}+i\,c\,\hat{\boldsymbol{\sigma}}\cdot\hat{\boldsymbol{p}}\,\hat{K}\times\hat{\boldsymbol{p}}+\hat{v}]\psi_L=\epsilon\psi_L,\qquad(12)$$

where  $\times$  is the usual cross product between spatial vectors. Equation (12) disentangles the two major relativistic corrections to the nonrelativistic Schrödinger equation considered in condensed matter physics and quantum chemistry. The first term, the scalar-relativistic kinetic energy term  $c\hat{p}\hat{K}\cdot\hat{p}$ , is independent of spin and modifies the nonrelativistic kinetic energy operator  $\hat{p}^2/2$  by a relativistic renormalization factor  $2c\hat{K}$ . The second term couples the spin operator acting on spinors to spatial operators operating on spatial degrees of freedom. This second term is accordingly called the "spin-orbit coupling" term.

For states weakly affected by relativity, e.g., valence and conduction states, the contribution of  $\psi_S$  to the normalization condition (10) is weak and may be neglected in the nonrelativistic limit.  $\psi_L$  may then be solved and normalized independently of  $\psi_S$ , functioning essentially as the nonrelativistic spinor. From here on, we will rewrite  $\psi_L \to \psi$ , which we identify as the Schrödinger-type two-component spinor. We will, however, return briefly to the small component  $\psi_S$  in the context of free-atom orbitals.

Although both the SR kinetic energy term and the SOC term arise from relativistic modification of the kinetic energy operator in the Dirac equation, the SR kinetic energy term is often considered the stronger relativistic effect in electronic structure theory. Relativistic effects are mostly significant in the nuclear region, where a highly negative v induces large kinetic energy densities via the relation  $\hat{t}\psi = (\epsilon - \hat{v})\psi$  even for the lightest atoms. Accordingly, Schrödinger-type atomic

l=0 orbitals are most strongly affected by scalar-relativistic effects, which diminish in strength for orbitals of increasing l, as the electronic density of the orbital spreads further away from the nuclear region of the system.

In contrast, the spin-orbit coupling term is antisymmetric in  $\hat{p}$  due to the presence of the cross product. Its effect is formally zero on the spherically symmetric Schrödinger atomic l=0 orbital. Higher l orbitals have zero electron density at the nuclei, requiring a compensating increase in the potential energy near the nucleus  $v \approx -Z/r$  for SOC to overcome the nodal structure of the Schrödinger orbitals and have an appreciable effect. This gives rise to the well-known dependence of SOC-related effects on the atomic number Z of atoms in a molecule or solid.

The expected difference in strength between these two relativistic corrections suggests an approximation where the two relativistic terms are conceptually decoupled from one another [66] and may be treated by different approximations

$$[c\,\hat{\boldsymbol{p}}\,\hat{K}_{\rm SR}\cdot\hat{\boldsymbol{p}}+ic\hat{\boldsymbol{\sigma}}\cdot\hat{\boldsymbol{p}}\,\hat{K}_{\rm SOC}\times\hat{\boldsymbol{p}}+\hat{\boldsymbol{v}}]\psi=\epsilon\psi. \tag{13}$$

 $\hat{K}_{SR}$  refers to the approximation for  $\hat{K}$  used in the scalar-relativistic term, and  $\hat{K}_{SOC}$  refers to the approximation for  $\hat{K}$  used in the SOC term. Using Eq. (9), the lowest-order approximation for  $\hat{K}_{SOC}$  is

$$\hat{K}_{SOC} \approx \frac{1}{2c}.$$
 (14)

In this approximation, the SOC term in Eq. (13) is proportional to  $\hat{\sigma} \cdot \hat{p} \times \hat{p} = 0$ . This eliminates the SOC term and yields the scalar-relativistic Schrödinger equation

$$[c\,\hat{\boldsymbol{p}}\,\hat{K}_{\rm SR}\cdot\hat{\boldsymbol{p}}+\hat{v}]\psi=\epsilon\psi. \tag{15}$$

The SR Schrödinger equation is the workhorse equation of electronic structure theory. For suitable choice of  $\hat{K}_{SR}$ , this equation has the same symmetries as the nonrelativistic Schrödinger equation. Most of the theoretical and conceptual machinery of the nonrelativistic quantum theory can be imported into analysis of the SR Schrödinger equation, while still including the dominant relativistic correction for lighter materials to energy levels. Several different successful approximations for  $\hat{K}_{SR}$  exist in the literature. In this work, two specific variants of  $\hat{K}_{SR}$  will be considered (outlined in Sec. IV below): (1) the "atomic zero-order regular approximation" (atomic ZORA) as used in the FHI-AIMS code [39] and a combination of a Dirac code and the Koelling-Harmon approximation [66] for valence states as implemented in WIEN2K [53].

To reintroduce SOC, Eq. (9) is taken to first order in  $(\epsilon - \hat{v})/c^2$ :

$$\hat{K}_{SOC} \approx \frac{1}{2c} - \frac{\epsilon - \hat{v}}{4c^3},\tag{16}$$

and inserted in Eq. (13), yielding the spin-orbit-coupled Schrödinger equation

$$\left[c\hat{\boldsymbol{p}}\hat{K}_{\mathrm{SR}}\cdot\hat{\boldsymbol{p}} + \frac{i}{4c^2}\hat{\boldsymbol{\sigma}}\cdot\hat{\boldsymbol{p}}\hat{\boldsymbol{v}}\times\hat{\boldsymbol{p}} + \hat{\boldsymbol{v}}\right]\psi = \epsilon\psi. \tag{17}$$

The main effect of SOC on energy levels of materials is the splitting of energy levels that were predicted to be degenerate in SR electronic structure theory. Figure 1 illustrates this effect

![](_page_3_Figure_2.jpeg)

FIG. 1. SR and SOC band structures of zinc-blende GaAs near  $\Gamma$  for the HSE06 functional, calculated using FHI-AIMS with a  $16 \times 16 \times 16$  k grid and the "tight" NAO basis set. "Really tight" integration settings of the FHI-AIMS code (see Sec. IV B) were used.

for the split valence band of the (cubic) zinc-blende compound semiconductor GaAs near the  $\Gamma$  point. This effect, known as spin-orbit splitting, can be understood as a Zeeman-type effect owing to the form of the perturbing SOC operator, and formally as the change in the irreducible representations of the Hamiltonian when transitioning from the single group of nonrelativistic/scalar-relativistic quantum theory to the double group of relativistic quantum theory [3,62].

# III. EVALUATION OF THE SPIN-ORBIT-COUPLING OPERATOR

# 1. Calculation of matrix elements of the spin-orbit-coupling operator

We next summarize the computational approach to evaluate the spin-orbit-coupled Hamiltonian matrix elements  $H_{m\alpha;m'\alpha'}$  in the second-variational method and using a localized basis set. Repeating Eq. (4),

$$H_{m\alpha;m'\alpha'} = \delta_{mm'}\delta_{\alpha\alpha'}\epsilon_{m\alpha} + \langle \psi_{m\alpha}\alpha | \hat{v}_{SOC} | \psi_{m'\alpha'}\alpha' \rangle, \quad (18)$$

where  $\epsilon_{m\alpha}$  is the SR eigenvalue for the self-consistent SR eigenstate  $\psi_{m\alpha}$  with energy index m and spin channel  $\alpha$ . For periodic boundary conditions,  $H_{m\alpha;m'\alpha'}$ ,  $\psi_{m\alpha}$ , and  $\epsilon_{m\alpha}$  acquire a k dependence by way of the Bloch theorem, and Eq. (18) must be evaluated for each k.

The SOC operator  $\hat{v}_{SOC}$ , when explicitly decomposed in terms of its spatial components, has the form

$$\hat{v}_{SOC} = \frac{-i}{4c^2} \left[ \left( \frac{d}{dy} \hat{v} \frac{d}{dz} - \frac{d}{dz} \hat{v} \frac{d}{dy} \right) \hat{\sigma}_x + \left( \frac{d}{dz} \hat{v} \frac{d}{dx} - \frac{d}{dx} \hat{v} \frac{d}{dz} \right) \hat{\sigma}_y + \left( \frac{d}{dx} \hat{v} \frac{d}{dy} - \frac{d}{dy} \hat{v} \frac{d}{dx} \right) \hat{\sigma}_z \right]$$

$$\equiv \frac{-i}{4c^2} \sum_{x_i} \hat{\Pi}_{x_i} \hat{\sigma}_{x_i}$$
(19)

 $(x_i = x, y, z)$ . Each term in this decomposition is a tensor product of a spatial operator  $\hat{\Pi}_{x_i}$ , which acts on the spatial wave functions  $|\psi_{m\alpha}\rangle$ , and a spin operator  $\hat{\sigma}_{x_i}$ , which acts on

the spinors  $|\alpha\rangle$ . The resulting matrix elements in the basis of SR eigenfunctions have the form

$$\langle \psi_{m\alpha} \alpha | \, \hat{v}_{SOC} | \psi_{m'\alpha'} \alpha' \rangle$$

$$= \frac{-i}{4c^2} \sum_{x_i} \langle \psi_{m\alpha} | \, \hat{\Pi}_{x_i} | \psi_{m'\alpha'} \rangle \, \langle \alpha | \, \hat{\sigma}_{x_i} | \alpha' \rangle \,. \tag{20}$$

Assuming polarization of  $\alpha$  in the z direction ( $|\alpha\rangle = |\uparrow\rangle$ ,  $|\downarrow\rangle$ ,) the matrix elements of  $\hat{v}_{SOC}$  assume a block form with respect to the spinor basis via the decomposition

$$\hat{v}_{SOC} = \begin{bmatrix} \hat{v}_{SOC,\uparrow\uparrow} & \hat{v}_{SOC,\uparrow\downarrow} \\ \hat{v}_{SOC,\downarrow\uparrow} & \hat{v}_{SOC,\downarrow\downarrow} \end{bmatrix} \\
= \frac{-i}{4c^2} \begin{bmatrix} \hat{\Pi}_z & \hat{\Pi}_x - i\,\hat{\Pi}_y \\ \hat{\Pi}_x + i\,\hat{\Pi}_y & -\hat{\Pi}_z \end{bmatrix}.$$
(21)

Within each subblock, one only considers operations on spatial wave functions of form  $\langle \psi_{m\alpha} | \hat{\Pi}_{x_i} | \psi_{m'\alpha'} \rangle$ .

### 2. Calculation of the spatial components of SOC matrix elements

a. Nonperiodic case. The spatial component of a nonperiodic eigenvector  $|\psi_{m\alpha}\rangle$  defined on a set of localized spatial basis functions  $\varphi_n$  is representable as a linear combination

$$|\psi_{m\alpha}\rangle = \sum_{n} c_{m\alpha n} |\varphi_{n}\rangle.$$
 (22)

The matrix elements for the  $\hat{\Pi}_{x_i}$  operators are

$$\langle \psi_{m\alpha} | \, \hat{\Pi}_{x_i} | \psi_{m'\alpha'} \rangle = \sum_{n,n'} c_{m\alpha n}^* M_{x_i;nn'} c_{m'\alpha'n'}, \qquad (23)$$

where

$$M_{x_i;nn'} = \langle \varphi_n | \, \hat{\Pi}_{x_i} | \varphi_{n'} \rangle = \int \varphi_n(\mathbf{r}) \hat{\Pi}_{x_i} \varphi_{n'}(\mathbf{r}) d\mathbf{r}. \quad (24)$$

 $M_{x_i;nn'}$  depends only on the spatial basis set and needs to be evaluated only once for a given  $\hat{v}$ . It can be evaluated efficiently using the same real-space, linear-scaling integration scheme as described for the FHI-AIMS Hamiltonian matrix elements in Ref. [67]

b. Periodic case. The spatial component of a periodic eigenvector  $|\psi_{m\alpha}(\mathbf{k})\rangle$  may be written in terms of Bloch basis functions  $|\chi_n(\mathbf{k})\rangle$  as

$$|\chi_n(\mathbf{k})\rangle = \frac{1}{\sqrt{N_{\text{cell}}}} \sum_{\mathbf{r}} e^{i\mathbf{k}\cdot\mathbf{T}} |\varphi_{n,\mathbf{r}}\rangle,$$
 (25)

where  $|\varphi_{n,T}\rangle$  is the periodic image of the *n*th spatial basis function in the unit cell indexed by T and  $\lim_{N_{\text{cell}}\to\infty}$  is implicit. The eigenvectors then acquire a k index,

$$|\psi_{m\alpha}(\mathbf{k})\rangle = \sum_{n} c_{m\alpha n}(\mathbf{k}) |\chi_n(\mathbf{k})\rangle.$$
 (26)

Using Eqs. (25) and (26), the matrix elements for the  $\hat{\Pi}_{x_i}$  operators are

$$\langle \psi_{m\alpha}(\mathbf{k}) | \hat{\Pi}_{x_i} | \psi_{m'\alpha'}(\mathbf{k}) \rangle$$

$$= \frac{1}{N_{\text{cell}}} \sum_{n,n'} c_{m\alpha n}^*(\mathbf{k}) c_{m'\alpha'n'}(\mathbf{k})$$

$$\times \sum_{TT'} e^{i\mathbf{k}\cdot(T'-T)} \langle \varphi_{n,T} | \hat{\Pi}_{x_i} | \varphi_{n',T'} \rangle. \tag{27}$$

By translational symmetry,

$$\langle \varphi_{n,T} | \, \hat{\Pi}_{x_i} | \varphi_{n',T'} \rangle \equiv \langle \varphi_{n,T} | \, \hat{\Pi}_{x_i} | \varphi_{n',\tau+T} \rangle = \langle \varphi_{n,0} | \, \hat{\Pi}_{x_i} | \varphi_{n',\tau} \rangle ,$$
(28)

that is, we may rewrite these matrix elements without loss of generality in terms of a "central unit cell" (with index T=0) and index  $\tau=T'-T$  relative to the central unit cell. Equation (27) then becomes

$$\langle \psi_{m\alpha}(\mathbf{k}) | \hat{\Pi}_{x_{i}} | \psi_{m'\alpha'}(\mathbf{k}) \rangle$$

$$= \frac{1}{N_{\text{cell}}} \sum_{n,n'} c_{m\alpha n}^{*}(\mathbf{k}) c_{m'\alpha'n'}(\mathbf{k})$$

$$\times \sum_{T\tau} e^{-i\mathbf{k}\cdot\boldsymbol{\tau}} \langle \varphi_{n,\mathbf{0}} | \hat{\Pi}_{x_{i}} | \varphi_{n',\tau} \rangle$$

$$= \sum_{n,n'} c_{m\alpha n}^{*}(\mathbf{k}) c_{m'\alpha'n'}(\mathbf{k}) \sum_{\tau} e^{-i\mathbf{k}\cdot\boldsymbol{\tau}} \langle \varphi_{n,\mathbf{0}} | \hat{\Pi}_{x_{i}} | \varphi_{n',\tau} \rangle$$

$$= \sum_{n,n'} c_{m\alpha n}^{*}(\mathbf{k}) \left[ \sum_{\tau} e^{-i\mathbf{k}\cdot\boldsymbol{\tau}} \langle \varphi_{n,\mathbf{0}} | \hat{\Pi}_{x_{i}} | \varphi_{n',\tau} \rangle \right] c_{m'\alpha'n'}(\mathbf{k}).$$
(29)

Equation (29) may be cast in a form analogous to the nonperiodic case:

$$\langle \psi_{m\alpha}(\mathbf{k})| \, \hat{\Pi}_{x_i} \, |\psi_{m'\alpha'}(\mathbf{k})\rangle = \sum_{n,n'} c_{m\alpha n}^*(\mathbf{k}) W_{x_i;nn'}(\mathbf{k}) c_{m'\alpha'n'}(\mathbf{k}).$$

Here,

$$W_{x_i;nn'}(\mathbf{k}) = \sum_{\tau} e^{-i\mathbf{k}\cdot\tau} M_{x_i;nn'\tau}$$
 (31)

incorporates all interactions between a given localized basis function  $\varphi_n$  in the central cell and all periodic images of  $\varphi_{n'}$  with overlapping support, and

$$M_{x_i;nn'\tau} = \langle \varphi_{n,\mathbf{0}} | \hat{\Pi}_{x_i} | \varphi_{n',\tau} \rangle \tag{32}$$

is the periodic analog of  $M_{x_i;nn'}$ .

 $M_{x_i;nn'\tau}$  is independent of k and depends only on the spatial basis, so it is evaluated once for a given  $\hat{v}$ . The matrix  $W_{x_i;nn'}(k)$  is evaluated once for each k point k. Once  $W_{x_i;nn'}(k)$ , is computed, solution of Eq. (30) requires two matrix multiplications for each k.

c. Avoiding explicit derivatives of the potential. Consider  $M_{z;nn'}$  in the nonperiodic case, where it has the form

$$M_{z;nn'} = \langle \varphi_n | \frac{d}{dx} \hat{v} \frac{d}{dy} | \varphi_{n'} \rangle - \langle \varphi_n | \frac{d}{dy} \hat{v} \frac{d}{dx} | \varphi_{n'} \rangle. \tag{33}$$

This matrix is antisymmetric, with the Hermiticity of the SOC operator  $\hat{v}_{SOC}$  preserved by the strictly imaginary coefficient of the overall operator. For localized basis functions, this matrix element can be rewritten by integration by parts to read as

$$M_{z;nn'} = -\left(\frac{d\varphi_n}{dx}\left|\hat{v}\right| \frac{d\varphi_{n'}}{dy}\right) + \left(\frac{d\varphi_n}{dy}\left|\hat{v}\right| \frac{d\varphi_{n'}}{dx}\right) \tag{34}$$

due to anti-Hermiticity of the gradient operator, with similar forms for the matrix elements of  $\hat{\Pi}_x$  and  $\hat{\Pi}_y$ . An analogous result holds for the periodic case.

By using Eq. (34), gradients of the potential  $\nabla \hat{v}$  do not need to be calculated. The gradients of the wave functions of basis elements  $\nabla \varphi_{n,\tau}$  needed can be readily computed in any electronic structure code based on localized basis functions.

#### 3. Steps for second-variational SOC in a localized basis set

To summarize, we briefly outline the steps for incorporating SOC in a second-variational approach.

Nonperiodic case:

- (1) Perform a self-consistent scalar-relativistic calculation to obtain SR eigenfunctions  $\psi_{m\alpha}$  and eigenvalues  $\epsilon_{m\alpha}$ .
- (2) Select a subset of SR eigenvectors  $\psi_{m\alpha}$  for inclusion in the second-variational method.
- (3) Calculate  $M_{x_i;nn'}$ , the matrix elements of the operators  $\hat{\Pi}_{x_i}$  between localized basis functions  $\varphi_n$ , via Eq. (24).
- (4) Use Eq. (23) to calculate the matrix elements of  $\hat{\Pi}_{x_i}$  between the scalar-relativistic eigenvectors chosen in step 2.
- (5) Use Eqs. (20) and (18) to construct the Hamiltonian matrix elements  $H_{m\alpha;m'\alpha'}$  of the system.
- (6) Diagonalize  $H_{m\alpha;m'\alpha'}$  to obtain the resulting SOC eigenvalues and (if needed) eigenvectors of the system.

Periodic case:

- (1) Perform a self-consistent scalar-relativistic calculation to obtain SR eigenfunctions  $\psi_{m\alpha}(\mathbf{k})$  and eigenvalues  $\epsilon_{m\alpha}(\mathbf{k})$ .
- (2) Select a subset of SR eigenvectors  $\psi_{m\alpha}(\mathbf{k})$  to include in the second-variational method.
- (3) Calculate  $M_{x_i;nn'\tau}$ , the matrix elements of the operators  $\hat{\Pi}_{x_i}$  between localized basis functions  $\varphi_{n,T}$ , via Eq. (32).
- (4) For each k point k, use Eq. (31) to calculate the matrix  $W_{x_i;nn'}(k)$ .
- (5) For each k point k, use Eq. (30) to calculate the matrix elements of  $\hat{\Pi}_{x_i}$  between the scalar-relativistic eigenvectors chosen in step 2.
- (6) For each k point k, use Eqs. (20) and (18) to construct the Hamiltonian matrix elements  $H_{m\alpha,m'\alpha'}(k)$  of the system at k.
- (7) For each k point k, diagonalize  $H_{m\alpha;m'\alpha'}(k)$  to obtain the resulting SOC eigenvalues and (if needed) eigenvectors of the system at k.

In practice, our NAO-based implementation in FHI-AIMS includes one further approximation, which is to omit  $\hat{v}_{XC}$  from the effective potential operator  $\hat{v}$  appearing in  $\hat{v}_{SOC}$ . The effect of this omission is small since relativistic effects only contribute significantly to the Hamiltonian deep in the nuclear region. This simplification yields a form for the SOC operator

$$\hat{v}_{SOC} \approx \frac{i}{4c^2} \hat{\boldsymbol{p}} \hat{\hat{v}} \times \hat{\boldsymbol{p}} \cdot \hat{\boldsymbol{\sigma}}, \tag{35}$$

where

$$\hat{\tilde{v}} \equiv \hat{v} - \hat{v}_{XC} = \hat{v}_{ext} + \hat{v}_{es}. \tag{36}$$

This approximation is assessed for the Perdew-Wang parametrization of the local-density approximation functional (PW-LDA) [68] in Table I, where spin-orbit splittings for select materials are calculated without and with the inclusion of  $\hat{v}_{XC}$  in the effective potential operator  $\hat{v}$  used for  $\hat{v}_{SOC}$ . The spin-orbit splitting at VBM for a given material is presented, with the exception of the Pb-containing compounds where the spin-orbit splitting in the first conduction band at  $\Gamma$  is

TABLE I. A comparison of select spin-orbit splittings using the PW-LDA functional, with and without the XC contribution to the effective potential operator used in ˆ*v*SOC. Values are presented in units of eV. "RS" and "ZB" denote rock-salt and (cubic) zinc-blende prototypes, respectively.

| Material | Prototype | VBM splitting<br>No vXC<br>in vSOC | VBM splitting<br>vXC<br>in vSOC |  |
|----------|-----------|------------------------------------|---------------------------------|--|
| ZnS      | ZB        | 0.064                              | 0.065                           |  |
| GaP      | ZB        | 0.089                              | 0.090                           |  |
| AlAs     | ZB        | 0.312                              | 0.315                           |  |
| GaAs     | ZB        | 0.350                              | 0.353                           |  |
| ZnSe     | ZB        | 0.403                              | 0.406                           |  |
| KBr      | RS        | 0.517                              | 0.522                           |  |
| RbCl     | RS        | 0.137                              | 0.140                           |  |
| CdS      | ZB        | 0.047                              | 0.048                           |  |
| CdSe     | ZB        | 0.382                              | 0.385                           |  |
| InP      | ZB        | 0.108                              | 0.109                           |  |
| AlSb     | ZB        | 0.687                              | 0.691                           |  |
| NaI      | RS        | 1.107                              | 1.113                           |  |
| CsF      | RS        | 0.157                              | 0.160                           |  |
| HgS      | ZB        | 0.692                              | 0.692                           |  |
| Material | Prototype | CB splitting                       | CB splitting                    |  |
|          |           | No vXC<br>in vSOC                  | vXC<br>in vSOC                  |  |
| PbS      | RS        | 2.793                              | 2.804                           |  |
| PbSe     | RS        | 2.619                              | 2.629                           |  |
| PbTe     | RS        | 2.350                              | 2.359                           |  |

presented. Calculations were performed using FHI-AIMS at "benchmark settings," described in Sec. IV B.

We find that inclusion of ˆ*v*XC changes spin-orbit splittings by 1% for these materials. While the omission of ˆ*v*XC does not affect the previous derivation conceptually, in practice it simplifies the implementation (higher derivatives of gradientbased exchange-correlation functionals that would be needed for the potential expression are avoided) and also allows one to use a local potential operator in calculations involving hybrid functionals.

# **IV. COMPUTATIONAL DETAILS**

#### **A. Materials and** *k* **paths for band structures**

We use the band structures of 103 materials for benchmarking the implementation of spin-orbit coupling. A brief overview of these materials is presented in Table II. Structural prototypes and the lattice parameters used may be found in Tables 3–5 of the Supplemental Material (SM) [69].

For most materials, we use experimental lattice parameters taken from Pearson's Handbook [70]. Notable exceptions are noble gas solid phases, for which lattice parameters are taken from Villars and Daams [71], and alkali halides, for which lattice parameters are taken from Wyckoff [72].

We use the *k* paths proposed by Setyawan and Curtarolo [73] for all band structures presented, with 21 even-spaced *k* points per *k*-path segment. The energy zero in band structures is set to the valence band maximum for insulators and to the Fermi level for metals. All reported energies are in units of eV. All scalar-relativistic calculations reported in the main

TABLE II. Materials used in this study, grouped by type. For materials with identical chemical composition but differing prototypes, the prototype has been indicated in brackets (see Sec. 3 of the Supplemental Material [69]). Underlined materials were used for the "band delta" benchmark (Sec. VC1) but not in the comparison of spin-orbit splittings.

| Family         | No. materials | Materials                |
|----------------|---------------|--------------------------|
| Elementals     | 45            | Be, C [GRA], Ne, Mg,     |
|                |               | Al, Si, Ca, Sc, Ti, V,   |
|                |               | Cr, Mn, Fe, Co, Ni,      |
|                |               | Cu, Zn, Ge, Sr, Y,       |
|                |               | Zr, Nb, Mo, Tc, Ru,      |
|                |               | Rh, Pd, Ag, Cd, Sn,      |
|                |               | Xe, Ba, Lu, Hf, Ta,      |
|                |               | W, Re, Os, Ir, Pt,       |
|                |               | Au, Tl, Pb, Bi, Po       |
| Compound       | 37            | C [DIA], MgO, AlN [WUR], |
| semiconductors |               | AlN [ZB], SiC, BP, AlP,  |
|                |               | MgS, ZnO, ZnS [WUR],     |
|                |               | ZnS [ZB], GaN [WUR],     |
|                |               | GaN [ZB], GaP, AlAs,     |
|                |               | BAs, GaAs, MgSe, ZnSe,   |
|                |               | CdS [WUR], CdS [ZB],     |
|                |               | CdSe [WUR], CdSe [ZB],   |
|                |               | InN, InP, InAs, AlSb,    |
|                |               | GaSb, InSb, ZnTe, CdTe,  |
|                |               | HgS, HgSe, HgTe,         |
|                |               | PbS, PbSe, PbTe          |
| Alkali         | 21            | LiF, NaF, LiCl, NaCl,    |
| halides        |               | KF, KCl, LiBr, NaBr,     |
|                |               | KBr, RbF, RbCl, RbBr,    |
|                |               | LiI, NaI, KI, RbI,       |
|                |               | CsF, CsCl [CSCL],        |
|                |               | CsCl [RS], CsBr, CsI     |

text of this paper were performed without spin polarization. A comparison of the calculated band structures for face-centered cubic (fcc) Ni on the spin-polarized scalar-relativistic and subsequent spin-orbit-coupled levels of theory is provided in Fig. S1 in the SM [69]. Excellent agreement is observed between FHI-AIMS and WIEN2K on both levels of theory, consistent with the trends observed in the main text. We briefly summarize code-dependent settings in the following two subsections; details may be found in Sec. 2 of the SM [69].

### **B. FHI-AIMS benchmark calculations**

All NAO calculations are performed using FHI-AIMS [39,44,67,74,75], a full-potential all-electron electronic structure code. In FHI-AIMS, basis functions have the form

$$\varphi_n(\mathbf{r}) = \frac{u_n(r)}{r} Y_{lm}(\Omega), \tag{37}$$

where *r* is the distance from the nucleus of the atom associated with the basis function,  is the solid angle with respect to the associated atom, *un*(*r*) are numerically tabulated functions, and *Ylm*() are real-valued spherical harmonics, with *l* and *m* implicitly depending on the index *n*. *un*(*r*) may be constructed to be exactly zero for *r r*cut, introducing spatial locality and linear scaling (with respect to system size) of computational effort for integrals [39].

FHI-AIMS includes preconstructed NAO basis sets for elements Z = 1-102. These basis sets are organized in socalled "tiers" or levels of increasing accuracy (see Table 1 in Ref. [39] and Sec. 3 in Ref. [76] for several examples) and are constructed for DFT-based total energy calculations. In Ref. [40], the accuracy of these basis sets was shown to be on par with the best available benchmark codes for calculated scalar-relativistic equations of state for 71 elemental solids. All basis sets include the occupied Kohn-Sham core and valence orbitals for spherical free atoms, known as the "minimal basis" in the literature. Additional basis functions can be added individually or in groups (tiers). The numerical definition of these basis functions is element specific; for instance, a C atom has three radial functions of s, p, d character in the first tier, five radial functions of s, p, d, f, g character in the second tier, and so on [39]. Additionally, defaults for basic numerical settings (integration grids, Hartree potential, and basis functions) are provided at three levels: "light," "tight," and "really tight." We use "really tight" integration settings throughout this paper.

For the scalar-relativistic kinetic energy operator of Eq. (13) in FHI-AIMS, we use the atomic zero-order regular approximation ("atomic ZORA") as defined in Eq. (55) of Ref. [39], and as benchmarked in Ref. [40]. In atomic ZORA, the kinetic energy operator operating on an atom-centered orbital  $\varphi_n(\mathbf{r})$  centered about atom j is expressed as

$$\hat{t}_{\text{at. ZORA}}\varphi_n(\mathbf{r}) = \hat{\mathbf{p}} \cdot \frac{c^2}{2c^2 - v_{at(j)}^{\text{free}}(\mathbf{r})} \hat{\mathbf{p}}\varphi_n(\mathbf{r}), \quad (38)$$

where  $v_{at(j)}^{\text{free}}(r)$  is the onsite free-atom potential near the nucleus of atom j. Since the form of  $\hat{t}_{\text{at.ZORA}}$  depends explicitly on the atom index of the basis function  $\varphi_n$  that it acts upon, and since the operator can either act to the left or to the right in a matrix element, the atomic ZORA matrix elements are symmetrized to restore Hermiticity.

We use two classes of settings in this paper, described in detail in Sec. 2.1 of the SM [69]. For comparison between NAO and (L)APW+lo data, "benchmark settings" are used, in which Monkhorst-Pack [77] k grids with k-point densities similar to the  $\Delta$  project [40,78] are used. Tier 2 basis sets are used in FHI-AIMS for all benchmark settings calculations. Usually, all possible eigenstates consistent with the basis set are calculated and included in second-variational spin-orbit coupling (exceptions may be found in Sec. 2.1 of the SM [69]). Band structures calculated using FHI-AIMS and benchmark settings may be found on the NOMAD repository via Ref. [47].

For comparisons between PBE and HSE06 calculations, "tight production settings" are used, in which FHI-AIMS' tight basis sets are used and  $\Gamma$ -centered  $16 \times 16 \times 16$  k-space integration grids are generally employed. Materials using coarser k-space grids are given in detail in Table 1 of the SM [69]. The HSE06 functional in this work is defined by a fixed screening parameter ( $\omega = 0.2 \,\text{Å}^{-1}$ ) and a fixed exchange mixing parameter ( $\alpha = 0.25$ ). Band structures calculated using FHI-AIMS and tight production settings may be found on the NOMAD Repository via Ref. [48].

For materials with maximum atomic numbers smaller than  $Z \leq 79$  (Au and lighter), we use FHI-AIMS' default value for the

number of calculated eigenstates in tight production setting, which is given approximately by the empirical formula

$$n_{\text{states}} \approx n_{\text{electrons}} + \sum_{\text{atoms}} [2 + (1 + l_{\text{max,atom}})^2],$$
 (39)

where  $n_{\rm electrons}$  is the number of electrons in the calculation and  $l_{\rm max,atom}$  is the maximum (occupied) angular momentum channel for the indicated atom. In practice, the default value gives roughly 35%–75% of all possible eigenstates consistent with the tight basis set and is sufficient to converge second-variational spin-orbit coupling in valence and lowlying conduction states. For materials containing species with  $Z \geqslant 80$  (Hg and heavier), we increase the number of calculated empty states per atom to 50. For reference, the default *total* number of empty states calculated for HgS would instead be 24. A study of the effect of basis set size and number of empty states included in second-variational SOC on calculated spin-orbit splittings may be found in Appendix B of the SM [69].

#### C. WIEN2K benchmark calculations

All (L)APW+lo based calculations are performed using the WIEN2K code [19,53]. In the (L)APW approach, each atom has a "muffin-tin radius"  $R_{\rm MT}$ , defining a sphere that partitions space into two types of regions: core regions S  $[r \leqslant R_{\rm MT}]$  near each nucleus, where each basis function is represented by a linear combination of atom-centered functions, and an interstitial/valence region I in the rest of space, where each basis function has the form of a single plane wave with wave vector  $k_G$ , i.e., proportional to  $e^{ik_G \cdot r}$ .

In (L)APW+lo, the basis set size is determined by  $\frac{1}{2}K_{\text{max}}^2$ , the highest-energy plane wave included in the basis set.  $K_{\text{max}}$  is often specified as a product with the smallest muffin-tin radius  $R_{\text{MT}}$  in the calculation, and this quantity  $R_{\text{MT}}K_{\text{max}}$  serves as an indicator of how many (L)APW+lo basis functions are used in a given run and thus the degree of basis set convergence achieved.

We present only PBE results using benchmark settings for WIEN2K. We generally use the converged "WIEN2K/acc" settings from the  $\Delta$  project [40,78], which were constructed for calculation of total energies of low-temperature elemental structures. The settings used may be found in Sec. 2.2 of the SM [69]. Band structures calculated using WIEN2K and benchmark settings may be found on the NOMAD repository via Ref. [49].

The relativistic approximations used in WIEN2K vary based on the character of the states. For core states, a spin-compensated Dirac solver is used. For semicore and valence/conduction states in the atomic-sphere region, scalar-relativistic effects are included using the Koelling-Harmon approximation [66] and SOC effects can be included using the self-consistent second-variational method adapted for the (L)APW+lo method. No relativistic corrections are applied in the interstitial region. We only consider valence/conduction states in this paper, and accordingly we will refer to the (L)APW+lo basis set as scalar relativistic. A cutoff energy for spin-orbit coupling of 10 Ry was used, below which all states were included in the second-variational SOC calculation. As mentioned above, WIEN2K optionally allows one to include

Dirac  $p^{1/2}$  local orbitals in the second-variational SOC step, denoted as "APW +  $p^{1/2}$  SC SOC" below.

#### V. RESULTS

# A. Comparison of different approaches to relativity and SOC in spherical free atoms

Since SOC effects arise predominantly in the "deep" potential regions near a nucleus, it is instructive to first recall the effects of SOC and relativity on the atomic radial functions and energy levels of moderate to heavy atoms. The spherically symmetric, closed-shell Hg (Z=80) atom is chosen to allow for a comparison to exact atomic Dirac radial functions. The reference solutions are orbitals and energies obtained using the fully relativistic Dirac-Kohn-Sham solver DFTATOM [79] for spherical free atoms. For the exchange-correlation treatment in the atomic calculations, we use the Perdew-Wang parametrization of the local-density approximation functional (PW-LDA) [68].

In Fig. 2, the fully relativistic radial functions of several core (1s, 2p), semicore (5p) and valence (5d) Hg orbitals are contrasted with the radial functions from a nonrelativistic treatment and from the atomic ZORA scalar-relativistic treatment as implemented in FHI-AIMS. The scale on the x axes is logarithmic. It is worth noting that, in the area very close to the nucleus, large total-energy contributions can originate already from small radial function changes due to the very deep Z/r nuclear Coulomb potential in this range. For the 1s orbital (which cannot show any spin-orbit splitting), the

maximum of the nonrelativistic radial function occurs at a noticeably larger value than that of the large component radial function. The maximum of the radial function of ZORA lies even further inward. In line with the literature [80,81], the 1s orbital energy of ZORA is therefore significantly lower than the proper Dirac solution, while the nonrelativistic 1s orbital energy is higher. However, since the contribution from the core orbital is almost entirely dominated by the nucleus, this particular effect cancels practically exactly in any total-energy difference (as evidenced in Ref. [40]) or in the SR orbital energy associated with semicore and valence levels. The small component [also shown in Fig. 2(a)] is not at all negligible, but also cancels in energy differences. It is noteworthy that the overall combined density of the small and large 1s components is closer to the atomic ZORA 1s radial function than the large component on its own.

The 2p core orbital [Fig. 2(b)] is the radial function with the largest overall SOC effect since its relativistic version is split into a  $j=\frac{1}{2}$  component and a  $j=\frac{3}{2}$  component; as is well known [19,24,25], the  $j=\frac{1}{2}$  component differs fundamentally from the scalar-relativistic 2p function in that it has no angular momentum barrier and thus a finite probability density to find a 2p electron at the nucleus. For the Hg atom, the split is clearly reflected in the two different components. The nonrelativistic 2p function is close to the Dirac  $j=\frac{3}{2}$  function but, interestingly, the SR ZORA 2p radial function near its maximum resides in-between the two Dirac 2p components.

The same trend persists into the 5p semicore functions [Fig. 2(c)], i.e., the ZORA 5p radial function resides between

![](_page_7_Figure_10.jpeg)

FIG. 2. Orbital shapes for the (a) 1s, (b) 2p, (c) 5p, and (d) 5d orbital(s) of a free Hg atom calculated with the PW-LDA functional for various relativistic approximations. FHI-AIMS (tier 2) was used for nonrelativistic and scalar-relativistic (atomic ZORA) orbitals, and DFTATOM was used for Dirac orbitals.

the  $j=\frac{3}{2}$  and  $\frac{1}{2}$  Dirac components. The Dirac 5p functions inherit the visible difference between the radial function components that is already apparent in the 2p functions. This means that a NSC second-variational treatment of SOC following a SR treatment must face limits for the 5p functions since the second-variational treatment will only approximate their energy difference but will not restore the difference of the underlying  $j=\frac{1}{2}$  and  $\frac{3}{2}$  radial functions themselves. In contrast, the difference between the 5d valence radial functions of Hg in Fig. 2(d) is much smaller.

These trends manifest themselves quantitatively in Fig. 3, which compares the actual energy levels of the Cd 4d and the Hg 5d valence orbitals, as well as the Hg 5p semicore orbitals. This figure incorporates energy levels obtained using the WIEN2K code, the FHI-AIMS code, and the DFTATOM code as a reference. To allow for a comparison of atomic energy levels in periodic and nonperiodic calculations, the highest occupied energy levels (5s orbital for Cd, 6s orbital for Hg) are chosen as the energy zero. For WIEN2K, the second-variational SC (L)APW+lo levels of theory without and with additional  $p^{1/2}$  local orbitals are shown. In WIEN2K, the free atoms were placed in cubic unit cell with edges d=10 Å, and benchmark settings (with  $R_{\rm MT}$  increased to 2.26 for Hg) were used. In FHI-AIMS, nonperiodic calculations with benchmark settings were performed.

For each orbital, Figs. 3(a)–3(c) include nonrelativistic orbital energies for FHI-AIMS, WIEN2K, and DFTATOM. Since this level of theory is formally identical in all three codes, the differences due to the different numerical implementations are small (within several tens of meV), as expected. The SR treatments in WIEN2K and FHI-AIMS are different regarding the core orbitals, but for the atomic semicore and valence orbitals investigated here, the differences are again small.

For the spin-orbit split levels, the Dirac solution given by the DFTATOM code is the appropriate reference. For the valence orbitals, 4d for Cd and 5d for Hg, all three alternative approaches (NAO NSC SOC, APW SC SOC, and APW +  $p^{1/2}$  SC SOC) yield practically identical results at the same scale (differences of a few tens of meV at most) as the NR and SR treatments in all three codes. This is consistent with the observation that the SOC-split d valence radial functions are practically identical in these cases. In contrast, the Hg 5p semicore orbital is a semicore state, more closely localized near the nucleus than a valence orbital. The 5p  $j = \frac{1}{2}$  and  $\frac{3}{2}$  radial functions are appreciably different, so the three different SOC treatments show noticeable differences as well.

# B. Comparison of different approaches to SOC in GaAs and other compound semiconductors

We next exemplify the differences that arise for scalarrelativistic and spin-orbit coupling treatments, as well as from different basis set choices. We will focus on the calculated band structure of the semiconductor GaAs [70] (cubic zinc-blende structure, experimental lattice parameter  $a = 5.6532 \,\text{Å}$ ), but we will briefly assess other compound semiconductors for which VBM spin-orbit splitting have been

![](_page_8_Figure_8.jpeg)

FIG. 3. Energy levels of select orbitals of free Cd and Hg atoms calculated with the PW-LDA functional [68] for various relativistic approximations. Red denotes nonrelativistic calculations, black denotes scalar-relativistic calculations, and blue denotes SOC/Dirac-based methods. Spin-orbit splittings are listed in the inset table, and the energy levels are given in Appendix A of the SM [69].

![](_page_9_Figure_2.jpeg)

FIG. 4. A comparison of PBE band structures of GaAs calculated using FHI-AIMS (tier 2) and WIEN2K (*RK*max = 10) on (a) SR and (c) SOC levels of theory. Closeups on the band edges for SR and SOC levels of theory are shown in (b) and (d), respectively. The experimental room-temperature lattice parameter of 5.6532 A is used. Slight differences can be seen between NAO NSC SOC and APW ˚ + *p*<sup>1</sup>*/*<sup>2</sup> SC SOC at *X* and in the  → *L* direction. Band structures calculated using APW SC and APW + *p*<sup>1</sup>*/*<sup>2</sup> SC SOC are visually indistinguishable.

reported in the literature. Figure 4(a) overlays scalarrelativistic band structures at the level of DFT-PBE, calculated using (L)APW+lo (red) and a tier-2 NAO basis set (blue). Figure 4(b) shows the segment around the band gap on a five times larger scale. In the physically important range of the valence bands and low-lying conduction bands [up to 5 eV above the conduction band minimum (CBM)], both sets are visually practically indistinguishable. Some visible differences arise only in the higher-energy bands (more than 7 eV above the CBM). These differences are a consequence of the more limited size of the NAO basis set (designed for accurate representations of occupied orbitals and the resulting density in DFT), compared to the overall larger (L)APW+lo basis set. For any scenarios requiring quantitatively more precise higher-lying states, further increasing the size of the NAO basis set used would be an adequate approach.

Similarly, Fig. 4(c) shows overlayed DFT-PBE band structures for GaAs including SOC, overlaying NAO NSC band structures with APW + *p*<sup>1</sup>*/*<sup>2</sup> SC band structures. Excellent visual agreement for the valence and low-lying conduction bands shows that the NSC SOC treatment based on atomic ZORA yields results that are essentially identical to the more sophisticated APW + *p*<sup>1</sup>*/*<sup>2</sup> SC treatment. In particular, the hallmark SOC-related features in the GaAs band structure are precisely reproduced. The fundamental gap of GaAs decreases by approximately 100 meV when applying SOC. This decrease arises from the splitting of the SR <sup>25</sup> *<sup>v</sup>* state into SOC <sup>8</sup>*<sup>v</sup>* and <sup>7</sup>*<sup>v</sup>* states, where <sup>8</sup>*<sup>v</sup>* is the new VBM. This splitting drives up the VBM (here defined to be the zero of energy) and consequently reduces the *relative* energy of the conduction band <sup>6</sup>*<sup>c</sup>*, which itself is negligibly affected by SOC due to its *s*-like nature.

In Table III, we provide quantitative values for the valence and conduction band edges at the SR NAO, SR (L)APW+lo, NAO NSC SOC, and APW + *p*1*/*<sup>2</sup> SC SOC levels of theory for DFT-PBE at three high-symmetry *k* points. We place this comparison in the perspective of the quantitatively more accurate HSE06 density functional and of experimentally obtained

TABLE III. Comparison of calculated single-particle energy levels of GaAs with experimental quasiparticle energy levels. Values are presented in units of eV. The first column labels the associated high-symmetry *k* point, with a subscript of "*V* " denoting the valence band and "*C*" the conduction band. SO denotes the split-off valence band at . The experimental room-temperature lattice parameter [70] of 5.6532 A is used. Experimental energy levels are taken from ˚ Adachi [82].

|    |       |       | NAO                         | APW           | APW + p1/2 | NAO          |       |
|----|-------|-------|-----------------------------|---------------|------------|--------------|-------|
|    | NAO   | APW   | PBE                         | PBE           | PBE        | HSE06        |       |
|    | PBE   | PBE   | SOC                         | SOC           | SOC        | SOC          |       |
|    | SR    | SR    | NSC                         | SC            | SC         | NSC          | Expt. |
| V  | 0.000 | 0.000 | 0.000                       | 0.000         | 0.000      | 0.000        | 0.00  |
| SO | N/A   | N/A   |                             | −0.340 −0.329 | −0.332     | −0.323 −0.34 |       |
| LV |       |       | −1.139 −1.139 −1.150 −1.149 |               | −1.148     | −1.125 −1.30 |       |
| XV |       |       | −2.674 −2.672 −2.746 −2.742 |               | −2.742     | −2.988 −2.80 |       |
| C  | 0.527 | 0.526 | 0.418                       | 0.417         | 0.416      | 1.210        | 1.52  |
| LC | 1.004 | 1.012 | 0.889                       | 0.902         | 0.902      | 1.596        | 1.78  |
| XC | 1.467 | 1.481 | 1.353                       | 1.371         | 1.371      | 1.964        | 2.00  |

TABLE IV. Comparison of PBE-calculated spin-orbit splittings to experimental values for the valence band of select compound semiconductors. Values are presented in units of eV. Benchmark settings were used.

|           | NAO<br>PBE | APW<br>PBE | APW + p1/2<br>PBE |                   |
|-----------|------------|------------|-------------------|-------------------|
| Structure | SOC<br>NSC | SOC<br>SC  | SOC<br>SC         | Expt. (Ref.)      |
| Ca        | 0.01       | 0.01       | 0.01              | 0.01 [83]         |
| Si        | 0.05       | 0.05       | 0.05              | 0.04 [83]         |
| ZnSb      | 0.03       | 0.03       | 0.03              | 0.09 [83]         |
| GaNc      | 0.01       | 0.01       | 0.01              | 0.02 [82]         |
| GaP       | 0.08       | 0.08       | 0.08              | 0.08–0.1 [82]     |
| AlAs      | 0.30       | 0.30       | 0.30              | 0.28–0.33 [82]    |
| GaAs      | 0.34       | 0.33       | 0.33              | 0.34 [82]         |
| ZnSe      | 0.39       | 0.38       | 0.38              | 0.40 [83]         |
| CdSb      | 0.07       | 0.07       | 0.07              | 0.06 [83]         |
| CdSeb     | 0.39       | 0.37       | 0.38              | 0.42 [83]         |
| InP       | 0.10       | 0.09       | 0.10              | 0.10–0.12 [82]    |
| AlSb      | 0.70       | 0.64       | 0.66              | 0.67 [82]         |
| ZnTe      | 0.93       | 0.83       | 0.89              | 0.91 [83]         |
| CdTe      | 0.90       | 0.80       | 0.86              | 0.80 [83]         |
| HgSe      | 0.25       | 0.22       | 0.23              | 0.38–0.40 [84–86] |
| HgTe      | 0.83       | 0.71       | 0.78              | 0.89–0.93 [87,88] |

a Diamond structure.

energy levels at the same *k* points (taken from Ref. [82]). For the SR energy levels, agreement within 14 meV is observed; similarly, agreement within 19 meV is observed for the two different treatments of SOC. As is well known, the DFT-PBE level of theory itself shows key differences to experiment, which are partially alleviated by the more expensive HSE06 treatment.

We end this section with a brief comparison of PBEcalculated spin-orbit splittings to experimental values for the valence bands of select compound semiconductors (Table IV). General agreement between calculated and experimental values to within 50 meV is observed for lighter materials, consistent with earlier validation work performed by Peralta *et al.* [89] and Carrier and Wei [25]. For the heaviest materials considered (CdTe, HgSe, HgTe), deviations on the order of 200 meV are observed. Notably, deviations between calculated and experimental values for HgSe are similar in magnitude to the calculated spin-orbit splittings themselves. Similar disagreement was observed for mercury chalcogenides on the LDA level by Sakuma *et al.* [26], who attributed the deviation to a lack of many-body renormalization effects on the KS level of theory. We will return to the question of choice of level of theory (in the context of density functionals) later in this paper.

# **C. Non-self-consistent vs self-consistent treatment of spin-orbit coupling: Trends across 103 materials**

# *1. Quantifying band-structure Differences: "Band delta"*

We first define a simple, quantitative metric for the difference between two calculated band structures, called "band delta" or band in the following. band is analogous to a root-mean-square deviation, defined on the energy levels of two energy band structures {1*,n*[*ki*]} and {2*,n*[*ki*]} within a given energy window [−*l,u*]:

$$\Delta_{\text{band}}[-\epsilon_{l}, \epsilon_{u}] = \sqrt{\frac{1}{N_{E}} \sum_{i=1}^{N_{k}} \sum_{\substack{\epsilon_{n,1} \leq \epsilon_{u} \\ \epsilon_{n,2} \leq \epsilon_{u} \\ \epsilon_{n,1} \geq -\epsilon_{l} \\ \epsilon_{n,2} \geq -\epsilon_{l}}} (\epsilon_{n,1}[\boldsymbol{k}_{i}] - \epsilon_{n,2}[\boldsymbol{k}_{i}])^{2}.$$

$$(40)$$

*Nk* is the number of unique *k* points calculated along the *k* path, *NE* is the total number of energy eigenvalues across all *k<sup>i</sup>* that both band structures predict to lie within the energy window [−*l,u*], and 1*,n*[*ki*] and 2*,n*[*ki*] are the energy eigenvalues for the two band structures being compared at the *k* point *ki*. For example, the SR valence bands of GaAs shown in Fig. 4 have a band[VBM-10 eV, VBM] value of 4 meV.

#### *2. "Band delta" analysis of valence bands of 103 compounds*

Figures 5(a) and 5(b) show band values between SR band structures for 103 elemental and multiatomic compounds (Table II), calculated using NAO and (L)APW+lo basis sets, respectively. Since the purpose of this paper is to highlight differences of different SOC treatments, we focus on the range of valence bands [VBM-10 eV, VBM] and low-lying conduction bands [CBM, CBM + 5 eV], i.e., the energy windows for which both basis set types are expected to give the most accurate answers. The band values in Fig. 5 are ordered according to the maximum atomic number Zmax within a given material, i.e., the principal quantity with which relativistic effects are expected to increase.

In brief, at the SR level of theory, we find excellent agreement between NAO and (L)APW+lo basis sets for the valence and low-lying conduction bands of all compounds. A maximum band value of 20 meV in the valence bands and 47 meV in the low-lying conduction bands is observed for alkali halides containing three specific elements: the large alkali atoms K (*Z* = 19), Rb (*Z* = 37), and Cs (*Z* = 55). The reason why these specific elements stand out is unclear and could reside *either* on the NAO side *or* on the (L)APW+lo side, or both. (Regarding NAOs, we note that no special behavior or uncertainties regarding alkali atoms were observed during the construction of the NAO basis sets as reported in Ref. [39].) However, even the maximum band for these three outliers is so minor that it does not affect the conclusions regarding SOC, which is the main purpose of this work.

In Figures 5(c) and 5(d), an analogous comparison of band is reported, but this time for NAO NSC SOC vs APW + *p*<sup>1</sup>*/*<sup>2</sup> SC SOC band structures. Remarkably, for materials with *Z*max 50 (Sn), band for SOC band structures are similar to those seen in SR band structures, i.e., extremely low. The "outlier materials" containing K, Rb, and Cs also agree somewhat better for valence bands between both methods. This suggests that the changed basis set on the (L)APW+lo side may have some accidental beneficial effect. (The NAO basis set remains unchanged compared to the SR case.) As shown in Fig. 4 and Table III, the effects of SOC in the *Z*max 50

bWurtzite structure.

c Cubic zinc-blende structure.

![](_page_11_Figure_2.jpeg)

FIG. 5. band on the benchmark set of 103 materials calculated with the PBE functional (a), (b) for SR calculations comparing NAO and (L)APW+lo basis sets and (c), (d) for SOC calculations comparing NAO NSC and APW + *p*<sup>1</sup>*/*<sup>2</sup> SC handlings of SOC. Outliers have been labeled.

range can already be appreciable. However, they appear to be captured essentially exactly by the NSC approach to SOC. This justifies the use of the computationally relatively cheap post-processing of a SC SR calculation even for high-accuracy band structures at least up to *Z*max ≈ 50.

From *Z*max = 51 (Sb) to *Z*max = 80 (Hg), Fig. 5(b) shows elevated but consistent band values, up to band = 84 meV (*Z*max = 71, Lu) for valence bands and 131 meV (*Z*max = 78, Pt) for low-lying conduction bands. Most band lie between 30 and 70 meV. This implies that NSC SOC should safely serve to capture any qualitatively relevant band-structure effects even in this range. The associated uncertainty is well below the overall uncertainty implied, e.g., by the use of DFT itself, and potentially other approximations inherent in the Born-Oppenheimer treatment of materials in most standard computations.

For the heaviest materials in the benchmark set (*Z*max = 81 onwards), band as large as 196 meV (*Z*max = 81, Bi) for valence bands and 312 meV (*Z*max = 83, Po) for low-lying conduction bands are observed. These elements feature open 6*p* valence shells, i.e., the shell that is most affected by SOC on a qualitative level (see Fig. 2 and the associated discussion).

The quantitative band-structure deviations associated with 6*p* elements are thus significant (a fact well known in the community [24,25,90,91]). However, as we show specifically for spin-orbit splittings below, even in this range the *relative* accuracy of NSC SOC (compared to the overall magnitude of SOC effects) is still within 11%, justifying the use of NSC SOC treatments for qualitative analyses of band structures even for very heavy elements.

## *3. Spin-orbit splittings*

Figure 6 shows spin-orbit splittings SOC at specific *k* points, calculated using NAO NSC, APW SC, and APW + *p*<sup>1</sup>*/*<sup>2</sup> SC SOC and the PBE functional. Benchmark settings are used. For each material in our band-structure benchmark set, we select the largest unambiguous spin-orbit splitting of valence and conduction states for inclusion in this study. Materials for which spin-orbit splittings could not be unambiguously identified by visual inspection of band structures were omitted. The spin-orbit splittings chosen for each material are provided in Sec. 5 of the SM [69].

Figure 6(a) illustrates the expected strong dependence of the magnitudes of spin-orbit splittings on *Z*max. In addition

![](_page_12_Figure_2.jpeg)

FIG. 6. NAO NSC, APW SC, and APW + *p*<sup>1</sup>*/*<sup>2</sup> SC spin-orbit splittings for the benchmark set of 103 materials calculated using the PBE functional. In (c), the *y* = *x* line corresponds to perfect agreement between APW + *p*<sup>1</sup>*/*<sup>2</sup> SC SOC and the other two levels of theory.

to the values of the splittings, the difference between the calculated NAO NSC and APW + *p*<sup>1</sup>*/*<sup>2</sup> SC splittings is also shown. Interestingly, for the selected splittings, the magnitude of the difference remains very small compared to the overall spin-orbit splittings, indicating relative deviations of the NSC approach are within 11% for the heaviest tested materials in this plot (Tl, Pb, Pb chalcogenides, Bi, and Po).

For a more quantitative comparison, we turn to Fig. 6(b), which shows the difference between the expected highestaccuracy APW + *p*1*/*<sup>2</sup> SC spin-orbit splittings and two different approximate approaches: NAO NSC spin-orbit splittings and APW SC spin-orbit splittings, respectively, again as a function of *Z*max. Qualitatively, the observed deviations for these specific spin-orbit splittings are well in line with the broader comparison of band values in Fig. 5. For materials exclusively containing elements lighter than 6*p*, we find a maximum deviation of 156 meV (HgS) between NAO NSC and APW + *p*1*/*<sup>2</sup> SC spin-orbit splittings. This deviation is within the margin of error expected due to usage of the (g)KS level of theory, as previously shown in Table IV.

Interestingly, both NAO NSC and APW SC spin-orbit splittings differ noticeably from APW + *p*1*/*<sup>2</sup> SC spin-orbit splittings for materials containing 6*p* elements, suggesting that the dominant contribution is the purely SR nature of the basis set considered and not the approximation of nonself-consistency used in the calculation. The deviations of the NAO NSC splittings are actually *smaller* than that of the APW SC splittings. Maximum differences of 688 meV (APW SC SOC) and 435 meV (NAO NSC SOC) from APW + *p*1*/*<sup>2</sup> SC SOC values were observed for Bi (*Z*max = 83.) Although this observation is difficult to generalize, it could be that the location of the atomic ZORA *p* functions between the *p*1*/*<sup>2</sup> and *p*3*/*<sup>2</sup> radial functions (Fig. 2) renders the atomic ZORA *p* function a slightly better starting point for the secondvariational treatment without explicit *p*1*/*<sup>2</sup> radial functions.

We replot the splittings of Fig. 6(a) in Fig. 6(c) as a function of the APW + *p*1*/*<sup>2</sup> SC splittings. This reveals an interesting trend, namely, that NAO NSC SOC consistently predicts larger values and APW SC SOC generally predicts smaller values for the splittings than the reference approach, i.e., APW + *p*1*/*<sup>2</sup> SC SOC. This trend may be related to the difference of the underlying SR core orbitals of both approaches.

The spin-orbit splittings reported in Fig. 6 were chosen by the criterion of being the largest spin-orbit splitting observed in the band structure for a material within a [−10 eV, 10 eV] energy range around the VBM/Fermi level. Band structures contain multiple spin-orbit splittings in this energy range, and the largest spin-orbit splitting cleanly observable in a computed band structure may be difficult to observe in experimental spectra (e.g., it may lie in the middle of the conduction band). This was observed for the lead chalcogenides, for which the spin-orbit splittings reported in Fig. 6 lie within the conduction band at .

We provide the calculated valence band spin-orbit splittings for the lead chalcogenides alongside experimental values in Table V. Notably smaller maximum deviations were observed for VB splittings (60 meV for NAO NSC, 120 meV for APW SC) compared to the maximum deviations in the CB splitting at  for lead chalcogenides reported in Fig. 6 (280 meV for NAO NSC, 390 meV for APW SC). The improved agreement is consistent with the trends reported in this paper, as the VB splittings arise primarily from the *p* orbitals of the lighter chalcogenides (although with some contribution from Pb *p*

TABLE V. Comparison of PBE-calculated valence band spinorbit splittings for lead chalogenides. Values are presented in units of eV. Benchmark settings were used.

|          | VB                     | NAO  | APW  | $APW + p^{1/2}$ |                                       |
|----------|------------------------|------|------|-----------------|---------------------------------------|
|          | Spin-orbit             | SOC  | SOC  | SOC             |                                       |
| Material | splitting              | NSC  | SC   | SC              | Expt.                                 |
| PbS      | $\Gamma_8^ \Gamma_6^-$ | 0.37 | 0.31 | 0.36            | 0.3ª                                  |
| PbS      | $X_7^ X_6^-$           | 0.33 | 0.28 | 0.32            | 0.2ª                                  |
| PbSe     | $\Gamma_8^ \Gamma_6^-$ | 0.69 | 0.60 | 0.67            | $0.6^{\rm a}, 0.75^{\rm b}$           |
| PbSe     | $X_7^ X_6^-$           | 0.51 | 0.43 | 0.49            | $0.5^{\rm a}, 0.55^{\rm b}$           |
| PbTe     | $\Gamma_8^ \Gamma_6^-$ | 1.18 | 1.00 | 1.12            | 1.15 <sup>a</sup> , 1.10 <sup>b</sup> |
| PbTe     | $X_7^ X_6^-$           | 0.77 | 0.63 | 0.72            | 0.9 <sup>a</sup> , 1.10 <sup>b</sup>  |

<sup>&</sup>lt;sup>a</sup>Taken from Ref. [92].

orbitals [92]) whereas the CB splitting at  $\Gamma$  are dominated by the p orbitals of heavier lead. Calculated spin-orbit splittings in Table V are generally in agreement with experiment, with the exception of the X splitting for PbTe where calculated values underestimate the splitting on the order of 400 meV. Similar results were observed by Svane  $et\ al.$  [94] at the level of quasiparticle self-consistent GW many-body theory, also employing a post-processed non-self-consistent treatment of SOC.

Returning to the spin-orbit splittings reported in Fig. 6, we end this section by putting the largest observed quantitative deviations into proper context with a comparison of the

computed band structures for Bi (Fig. 7). The reported spinorbit splitting occurs at the lowest-lying conduction band at  $\Gamma$ and is marked by an arrow in Fig. 7(c). The SOC-perturbed band structures on the three levels of theory, though visually distinguishable, all predict the same qualitative behavior. In the region near the Fermi level [Figs. 7(b) and 7(d)] critical for modeling electronic transport properties, the three levels of theory are vertically shifted relative to one another, but these translate to only small lateral shifts of the Fermi surface in practice. The lingering quantitative deviations induced by usage of NAO NSC versus APW +  $p^{1/2}$  SC SOC are much smaller than the qualitative (and quantitative) improvement relative to the original SR band structure. Overall, Figs. 6(c) and 7 together visually reaffirm the impression that the NAO NSC SOC approximation to SOC still captures SOC effects on the band structure correctly even for the heaviest elements investigated here.

#### 4. PBE versus HSE06

We next investigate the dependence of calculated SOC effects on the underlying density functional, using the PBE and HSE06 functionals as examples. The NAO NSC SOC approach with tight production settings is used. We consider spin-orbit splittings as well as changes of the fundamental gap due to SOC,

$$\Delta E_g = E_g^{\text{SOC}} - E_g^{\text{SR}} \,. \tag{41}$$

Here  $E_g^{\rm SR}$  is the scalar-relativistic fundamental gap and  $E_g^{\rm SOC}$  is the spin-orbit-coupled fundamental gap. The fundamental

![](_page_13_Figure_13.jpeg)

FIG. 7. A comparison of PBE band structures of bcc Bi calculated using FHI-AIMS and WIEN2K on (a) SR and (c) SOC levels of theory. Closeups near the Fermi level for SR and SOC levels of theory are shown in (b) and (d), respectively. The midpoint of the spin-orbit splitting reported in the text is marked by an arrow in (c). Benchmark settings and the experimental room-temperature lattice parameter [70] of 3.800 Å were used. Scalar-relativistic band structures calculated using NAO and (L)APW+lo basis sets are visually indistinguishable.

<sup>&</sup>lt;sup>b</sup>Taken from Ref. [93].

gaps (for gapped materials) and spin-orbit splittings calculated using tight production settings are listed in Sec. 6 of the SM [69]. We omit Co and Fe from the comparison of spin-orbit splittings at tight production settings due to difficulty converging the electronic structures on the HSE06 level of theory.

![](_page_14_Figure_3.jpeg)

FIG. 8. A comparison between the PBE and HSE06 functionals using NAO NSC SOC for (a) spin-orbit splittings and (b) SOCinduced fundamental gap changes. (c) Shows the absolute deviation in SOC-induced fundamental gap changes.

Figure 8(a) shows spin-orbit splittings calculated with the PBE and HSE06 functionals and supports the assertion in the literature [89] that different functionals yield similar spinorbit splittings. Most differences lie below 60 meV. A notable exception is Tl, with an absolute difference of 189 meV. We note that the spin-orbit splitting chosen for Tl occurs for a highlying state, and this deviation is likely due to a combination of the basis set size used for these calculations and the open-shell 6*p* orbital.

![](_page_14_Figure_6.jpeg)

FIG. 9. Scalar-relativistic and spin-orbit-coupled band structures near band edges of zinc-blende HgS calculated at tight production settings using (b) the PBE functional and (c) the HSE06 functional. The band structures calculated using the PBE functional and APW + *p*<sup>1</sup>*/*<sup>2</sup> SC SOC at benchmark settings (a) are also shown for comparison.

We next turn to SOC-induced changes of the band gap *Eg* in Fig. 8(b). Only gapped materials are included in the *Eg* comparison. We note that SOC consistently *decreases* the fundamental gap relative to the SR fundamental gap (*Eg* 0).

Regarding the dependence on the density functional used, it is striking that there is no significant functional dependence of the SOC-induced gap *change*, except for a few materials that show surprisingly stark differences between the PBE and HSE06 functional [Fig. 8(c)]. We discuss these materials in more detail in the next subsection.

#### *5. Outliers: Ge, InAs, GaSb, InSb, HgS*

The five "outlier" materials (Ge, InAs, GaSb, InSb, HgS) in Fig. 8(b) are either predicted to be zero-band-gap semiconductors (InAs, InSb, HgS) or have negligible fundamental gaps of 0.13 eV or less (Ge, GaSb) in SR DFT-PBE. In contrast, in SR HSE06, they have gaps of 0.35 eV or more.

To pinpoint the origin of the deviations, in Fig. 9 we consider the example of HgS, considered here in the (cubic) zinc-blende *β* phase. The PBE functional predicts SR HgS to be a zero-band-gap semiconductor at a lattice parameter of 5.874 A. SOC intermixes the valence and conduction bands at ˚  [Fig. 9(b)], opening an indirect fundamental gap of 38 meV. A similar behavior is observed for WIEN2K and APW + *p*1*/*<sup>2</sup> SOC at benchmark settings [Fig. 9(a)]. The HSE06 functional predicts a separation of the valence and conduction bands on the SR level of theory, and application of SOC preserves the direct nature of the fundamental gap [Fig. 9(c)].

Analogous observations were made by Aguilera *et al.* [27], Svane *et al.* [95], and Sakuma *et al.* [26] in the context of *GW* quasiparticle energy calculations. For mercury chalcogenides [26,95] and bismuth [27], (g)KS-DFT predicts qualitatively incorrect features for SOC band structures. It is necessary to include SOC self-consistently within the *GW* method for these materials to achieve qualitatively accurate results [26,96,97].

#### **VI. CONCLUSIONS**

In this paper, we established a band-structure benchmark set and systematically examined the dependence of SOCrelated phenomena on basis sets [NAO, (L)APW+lo, and (L)APW+lo including a *p*<sup>1</sup>*/*<sup>2</sup> orbital], handling of selfconsistency within post-processed SOC (NSC and SC), and functionals (PBE and HSE06) across 103 materials and two different, high-accuracy all-electron DFT codes (FHI-AIMS and WIEN2K). At the scalar-relativistic level of theory, near-complete agreement between band structures calculated with the different basis sets and codes is found. Regarding SOC effects, we find quantitative agreement between all basis sets and SOC approaches used up to the 5*p* block of the periodic table. We provide these benchmark-quality band structures to the community via the NOMAD repository [46] citable by Ref. [49] for WIEN2K-calculated band structures and Ref. [47] for FHI-AIMS-calculated band structures. We also provide HSE06-calculated band structures calculated by FHI-AIMS, as well as the associated PBE band structures, citable by Ref. [48]

For materials containing heavier atoms, divergences between the methods using purely SR valence bands (NAO NSC and APW SC SOC) and APW + *p*1*/*<sup>2</sup> NSC SOC are observed. For the heaviest elements (6*p* valence shell) spin-orbit splittings calculated by APW SC SOC deviate from the APW + *p*1*/*<sup>2</sup> reference by as much as 0.69 eV. For the NAO NSC SOC the discrepancy to APW + *p*1*/*<sup>2</sup> in the 6*p* shell is smaller. We thus find qualitative agreement in PBE-calculated band structures predicted by the APW + *p*1*/*<sup>2</sup> SC SOC and NAO NSC SOC treatments for all materials investigated here. For large-scale calculations where self-consistent SOC becomes computationally expensive, non-self-consistent SOC offers a convenient and qualitatively accurate method for approximating the necessary effects of spin-orbit coupling.

We also compared spin-orbit splittings and fundamental gap changes due to SOC calculated using the semilocal PBE and hybrid HSE06 functionals. Close agreement in these quantities was observed between exchange-correlation functionals even for the heaviest materials. However, this agreement requires qualitative agreement in the underlying SR band structures, as energy levels not properly gapped can intermix once SOC is applied. The notion that different functionals yield similar SOC-calculated quantities thus comes with a caveat: qualitatively accurate SR band structures are necessary to ensure that physically meaningful results emerge from second-variational SOC.

# **ACKNOWLEDGMENTS**

The authors would like to thank M. Scheffler and the Fritz-Haber Institut Berlin for funding the early stages of this work via a "fellowship to promote scientific cooperation with foreign countries", as well as Prof. Karsten Reuter and Matthias Gramzow, whose initial SOC implementation in FHI-aims we built upon. This work was partially supported by the LDRD Program of ORNL managed by UT-Battle, LLC, for the U.S. DOE and by the Oak Ridge Leadership Computing Facility, which is a DOE Office of Science User Facility supported under Contract No. DE-AC05-00OR22725.

<sup>[1]</sup> G. Dresselhaus, A. F. Kip, and C. Kittel, Phys. Rev. **95**, 568 (1954).

<sup>[2]</sup> G. Dresselhaus, Phys. Rev. **100**, 580 (1955).

<sup>[3]</sup> M. S. Dresselhaus, G. Dresselhaus, and A. Jorio, *Group Theory: Application to the Physics of Condensed Matter* (Springer, Berlin, 2008).

<sup>[4]</sup> D. Bercioux and P. Lucignano, Rep. Prog. Phys. **78**, 106001 (2015).

<sup>[5]</sup> M. Kepenekian, R. Robles, C. Katan, D. Sapori, L. Pedesseau, and J. Even, ACS Nano **9**, 11557 (2015).

<sup>[6]</sup> G. Bihlmayer, O. Rader, and R. Winkler, New J. Phys. **17**, 050202 (2015).

<sup>[7]</sup> C. L. Kane and E. J. Mele, Phys. Rev. Lett. **95**, 146802 (2005).

<sup>[8]</sup> D. Xiao, M.-C. Chang, and Q. Niu, Rev. Mod. Phys. **82**, 1959 (2010).

<sup>[9]</sup> W. Kohn and L. J. Sham, Phys. Rev. **140**, A1133 (1965).

- [10] A. D. Becke, J. Chem. Phys. **98**, 5648 (1993).
- [11] A. Seidl, A. Görling, P. Vogl, J. A. Majewski, and M. Levy, Phys. Rev. B **53**, 3764 (1996).
- [12] I. Opahle and P. M. Oppeneer, Phys. Rev. Lett. **90**, 157001 (2003).
- [13] H. Eschrig, M. Richter, and I. Opahle, in *Relativistic Electronic Structure Theory. Part 2. Applications*, edited by P. Schwerdtfeger (Elsevier, Amsterdam, 2004), pp. 723–776.
- [14] DIRAC, a relativistic *ab initio* electronic structure program, Release DIRAC16 (2016), written by H. J. Aa. Jensen, R. Bast, T. Saue, and L. Visscher, with contributions from V. Bakken, K. G. Dyall, S. Dubillard, U. Ekström, E. Eliav, T. Enevoldsen, E. Faßhauer, T. Fleig, O. Fossgaard, A. S. P. Gomes, T. Helgaker *et al.* (see http://www.diracprogram.org).
- [15] R. Zhao, Y. Zhang, Y. Xiao, and W. Liu, J. Chem. Phys. **144**, 044105 (2016).
- [16] E. van Lenthe, J. G. Snijders, and E. J. Baerends, J. Chem. Phys. **105**, 6505 (1996).
- [17] P. Nichols, N. Govind, E. J. Bylaska, and W. A. de Jong, J. Chem. Theory Comput. **5**, 491 (2009).
- [18] A. H. MacDonald, W. E. Pickett, and D. D. Koelling, J. Phys. C: Solid State Phys. **13**, 2675 (1980).
- [19] D. J. Singh and L. Nordström, *Planewaves, Pseudopotentials and the LAPW Method*, 2nd ed. (Springer, New York, 2006).
- [20] L. Kleinman, Phys. Rev. B **21**, 2630 (1980).
- [21] G. B. Bachelet and M. Schlüter, Phys. Rev. B **25**, 2103 (1982).
- [22] A. Dal Corso and A. Mosca Conte, Phys. Rev. B **71**, 115106 (2005).
- [23] M. Dolg and X. Cao, Chem. Rev. **112**, 403 (2011).
- [24] J. Kuneš, P. Novák, R. Schmid, P. Blaha, and K. Schwarz, Phys. Rev. B **64**, 153102 (2001).
- [25] P. Carrier and S.-H. Wei, Phys. Rev. B **70**, 035212 (2004).
- [26] R. Sakuma, C. Friedrich, T. Miyake, S. Blügel, and F. Aryasetiawan, Phys. Rev. B **84**, 085144 (2011).
- [27] I. Aguilera, C. Friedrich, and S. Blügel, Phys. Rev. B **91**, 125129 (2015).
- [28] F. W. Averill and D. E. Ellis, J. Chem. Phys. **59**, 6412 (1973).
- [29] A. Zunger and A. J. Freeman, Phys. Rev. B **15**, 4716 (1977).
- [30] B. Delley and D. E. Ellis, J. Chem. Phys. **76**, 1949 (1982).
- [31] B. Delley, J. Chem. Phys. **92**, 508 (1990).
- [32] G. te Velde, F. M. Bickelhaupt, E. J. Baerends, C. F. Guerra, S. J. A. van Gisbergen, J. G. Snijders, and T. Ziegler, J. Comput. Chem. **22**, 931 (2001).
- [33] K. Koepernik and H. Eschrig, Phys. Rev. B **59**, 1743 (1999).
- [34] A. P. Horsfield, Phys. Rev. B **56**, 6594 (1997).
- [35] O. F. Sankey and D. J. Niklewski, Phys. Rev. B **40**, 3979 (1989).
- [36] J. M. Soler, E. Artacho, J. D. Gale, A. García, J. Junquera, P. Ordejón, and D. Sánchez-Portal, J. Phys.: Condens. Matter **14**, 2745 (2002).
- [37] T. Ozaki and H. Kino, Phys. Rev. B **72**, 045121 (2005).
- [38] I. Y. Zhang, X. Ren, P. Rinke, V. Blum, and M. Scheffler, New J. Phys. **15**, 123033 (2013).
- [39] V. Blum, R. Gehrke, F. Hanke, P. Havu, V. Havu, X. Ren, K. Reuter, and M. Scheffler, Comput. Phys. Commun. **180**, 2175 (2009).
- [40] K. Lejaeghere, G. Bihlmayer, T. Björkman, P. Blaha, S. Blügel, V. Blum, D. Caliste, I. E. Castelli, S. J. Clark, A. Dal Corso *et al.*, Science **351**, aad3000 (2016).
- [41] S. R. Jensen, S. Saha, J. A. Flores-Livas, W. Huhn, V. Blum, S. Goedecker, and L. Frediani,J. Phys. Chem. Lett. **8**, 1449 (2017).

- [42] L. Nemec, V. Blum, P. Rinke, and M. Scheffler, Phys. Rev. Lett. **111**, 065502 (2013).
- [43] A. Marek, V. Blum, R. Johanni, V. Havu, B. Lang, T. Auckenthaler, A. Heinecke, H.-J. Bungartz, and H. Lederer, J. Phys.: Condens. Matter **26**, 213201 (2014).
- [44] S. V. Levchenko, X. Ren, J. Wieferink, R. Johanni, P. Rinke, V. Blum, and M. Scheffler, Comput. Phys. Commun. **192**, 60 (2015).
- [45] J. P. Perdew, K. Burke, and M. Ernzerhof, Phys. Rev. Lett. **77**, 3865 (1996).
- [46] The NOMAD Laboratory: A European Centre of Excellence, http://nomad-repository.eu
- [47] W. P. Huhn and V. Blum, 103 Compound Band Structure Benchmark Set, With and Without Spin-Orbit Coupling (FHIaims, DFT, PBE, Benchmark Settings), NOMAD Repository, doi:10.17172/NOMAD/2017.04.27-2 (2017).
- [48] W. P. Huhn and V. Blum, 103 Compound Band Structure Benchmark Set, With and Without Spin-Orbit Coupling (FHI-aims, DFT, HSE06 and PBE, Tight Production Settings), NOMAD Repository, doi:10.17172/NOMAD/2017.04.27-3 (2017).
- [49] W. P. Huhn and V. Blum, 103 Compound Band Structure Benchmark Set, With and Without Spin-Orbit Coupling (WIEN2k, DFT, PBE, Benchmark Settings), NOMAD Repository, doi:10.17172/NOMAD/2017.04.27-1 (2017).
- [50] O. K. Andersen, Phys. Rev. B **12**, 3060 (1975).
- [51] E. Sjöstedt, L. Nordström, and D. Singh, Solid State Commun. **114**, 15 (2000).
- [52] G. K. H. Madsen, P. Blaha, K. Schwarz, E. Sjöstedt, and L. Nordström, Phys. Rev. B **64**, 195134 (2001).
- [53] P. Blaha, K. Schwarz, G. K. H. Madsen, D. Kvasnicka, and J. Luitz, wien*2*k*, An Augmented Plane Wave* + *Local Orbitals Program for Calculating Crystal Properties*(Karlheinz Schwarz, Techn. Universitat Wien, Austria, 2001).
- [54] J. Heyd, G. E. Scuseria, and M. Ernzerhof, J. Chem. Phys. **118**, 8207 (2003).
- [55] J. Heyd, G. E. Scuseria, and M. Ernzerhof, J. Chem. Phys. **124**, 219906 (2006).
- [56] A. V. Krukau, O. A. Vydrov, A. F. Izmaylov, and G. E. Scuseria, J. Chem. Phys. **125**, 224106 (2006).
- [57] A. K. Rajagopal and J. Callaway, Phys. Rev. B **7**, 1912 (1973).
- [58] A. K. Rajagopal, J. Phys. C: Solid State Phys. **11**, L943 (1978).
- [59] A. H. MacDonald and S. H. Vosko, J. Phys. C: Solid State Phys. **12**, 2977 (1979).
- [60] E. Engel, *Relativistic Electronic Structure Theory. Part 1: Fundamentals*, edited by P. Schwerdtfeger (Elsevier, Amsterdam, 2002), pp. 523–621.
- [61] T. Saue and T. Helgaker, J. Comput. Chem. **23**, 814 (2002).
- [62] K. G. Dyall and J. K. Fægri,*Introduction to Relativistic Quantum Chemistry* (Oxford University Press, Oxford, 2007).
- [63] W. Liu, Mol. Phys. **108**, 1679 (2010).
- [64] T. Saue, Chem. Phys. Chem. **12**, 3077 (2011).
- [65] M. Reiher and A. Wolf, *Relativistic Quantum Chemistry: The Fundamental Theory of Molecular Science* (Wiley, Weinheim, 2009).
- [66] D. D. Koelling and B. N. Harmon, J. Phys. C: Solid State Phys. **10**, 3107 (1977).
- [67] V. Havu, V. Blum, P. Havu, and M. Scheffler, J. Comput. Phys. **228**, 8367 (2009).

- [68] J. P. Perdew and Y. Wang, Phys. Rev. B **45**, 13244 (1992).
- [69] See Supplemental Material at http://link.aps.org/supplemental/ 10.1103/PhysRevMaterials.1.033803 for geometries and computational settings used in this study, calculated spin-orbit splittings and fundamental gaps, and additional convergence studies.
- [70] P. Villars and L. Calvert, *Pearson's Handbook of Crystallographic Data for Intermetallic Phases*, 1st ed. (American Society for Metals, Materials Park, Ohio, 1985).
- [71] P. Villars and J. L. C. Daams, J. Alloys Compd. **197**, 177 (1993).
- [72] R. W. G. Wyckoff, *Crystal Structures*, 2nd ed., Vol. 1 (Wiley, Easton, PA, 1963).
- [73] W. Setyawan and S. Curtarolo, Comput. Mater. Sci. **49**, 299 (2010)
- [74] X. Ren, P. Rinke, V. Blum, J. Wieferink, A. Tkatchenko, A. Sanfilippo, K. Reuter, and M. Scheffler, New J. Phys. **14**, 053020 (2012).
- [75] A. C. Ihrig, J. Wieferink, I. Y. Zhang, M. Ropo, X. Ren, P. Rinke, M. Scheffler, and V. Blum, New J. Phys. **17**, 093020 (2015).
- [76] S. R. Jensen, S. Saha, J. A. Flores-Livas, W. Huhn, V. Blum, S. Goedecker, and L. Frediani, GGA-PBE and hybrid-PBE0 energies and dipole moments with MRChem, FHI-aims, NWChem and ELK, DataverseNO, doi:10.18710/0EM0EL (2017).
- [77] H. J. Monkhorst and J. D. Pack, Phys. Rev. B **13**, 5188 (1976).
- [78] K. Lejaeghere, V. van Speybroeck, G. van Oost, and S. Cottenier, Crit. Rev. Solid State Mater. Sci. **39**, 1 (2014).
- [79] O. Certík, J. E. Pask, and J. Vacká ˇ ˇr, Comput. Phys. Commun. **184**, 1777 (2013).
- [80] E. van Lenthe, E. J. Baerends, and J. G. Snijders, J. Chem. Phys. **99**, 4597 (1993).

- [81] E. van Lenthe, E. J. Baerends, and J. G. Snijders, J. Chem. Phys. **101**, 9783 (1994).
- [82] S. Adachi, *Handbook on Physical Properties of Semiconductors* (Kluwer Academic, Dordrecht, 2004).
- [83] O. Madelung, *Semiconductors* (Springer, Berlin, 1991).
- [84] M. Dobrowolska, W. Dobrowolska, and A. Mycielski, Solid State Commun. **34**, 441 (1980).
- [85] R. R. Gałazka, W. Dobrowolski, and J. C. Thuillier, Phys. Status Solidi B **98**, 97 (1980).
- [86] A. Mycielski, J. Kossut, M. Dobrowolska, and W. Dobrowolska, J. Phys. C: Solid State Phys. **15**, 3293 (1982). .
- [87] N. Orlowski, J. Augustin, Z. Gołacki, C. Janowitz, and R. Manzke, Phys. Rev. B **61**, R5058 (2000).
- [88] C. Janowitz, N. Orlowski, R. Manzke, and Z. Gołacki, J. Alloys Compd. **328**, 84 (2001).
- [89] J. E. Peralta, J. Heyd, G. E. Scuseria, and R. L. Martin, Phys. Rev. B **74**, 073101 (2006).
- [90] J. C. Boettger, Phys. Rev. B **62**, 7809 (2000).
- [91] P. Larson, Phys. Rev. B **68**, 155121 (2003).
- [92] T. Grandke, L. Ley, and M. Cardona, Phys. Rev. B **18**, 3847 (1978).
- [93] V. Hinkel, H. Haak, C. Mariani, L. Sorba, K. Horn, and N. E. Christensen, Phys. Rev. B **40**, 5549 (1989).
- [94] A. Svane, N. E. Christensen, M. Cardona, A. N. Chantis, M. van Schilfgaarde, and T. Kotani, Phys. Rev. B **81**, 245120 (2010).
- [95] A. Svane, N. E. Christensen, M. Cardona, A. N. Chantis, M. van Schilfgaarde, and T. Kotani, Phys. Rev. B **84**, 205205 (2011).
- [96] F. Aryasetiawan and S. Biermann, Phys. Rev. Lett. **100**, 116402 (2008).
- [97] F. Aryasetiawan and S. Biermann, J. Phys.: Condens. Matter **21**, 064232 (2009).