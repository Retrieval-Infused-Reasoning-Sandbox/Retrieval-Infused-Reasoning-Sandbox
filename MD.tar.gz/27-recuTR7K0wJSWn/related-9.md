![](_page_0_Picture_2.jpeg)

![](_page_0_Picture_3.jpeg)

## **Polyvalent s-block elements: A missing link challenges the periodic law of chemistry for the heavy elements**

Chang-Su Caoa,1 , Jing Zhao<sup>a</sup> , Han-Shi Hu<sup>a</sup> , W. H. Eugen Schwarza,b,2 , and Jun Li<sup>a</sup>,c,2

Edited by Markus Reiher, Swiss Federal Institute of Technology, Zurich, Switzerland; received March 14, 2023; accepted September 6, 2023 by Editorial Board Member Shaul Mukamel

**The Periodic Law of Chemistry is one of the great discoveries in cultural history. Elements behaving chemically similar are empirically merged in groups** *G* **of a Periodic Table, each element with** *G* **valence electrons per neutral atom, and with upper limit** *G* **for the oxidation and valence numbers. Here, we report that among the usually mono**- **or di**-**valent s**-**block elements (***G* **= 1 or 2), the heaviest members (87Fr, 88Ra, 119E, and 120E) with atomic numbers Z = 87, 88, 119, 120 form unusual 5**- **or 6**-**valent compounds at ambient conditions. Together with well**-**reported basic changes of valence at the end of the 6d**-**series, in the whole 7p**-**series, and for 5g6f**-**elements, it indicates that at the bottom of common Periodic Tables, the classic Periodic Law is not as straightforward as commonly expected. Specifically, we predict the feasible experimental synthesis of polyvalent [RaL<sup>−</sup>** *<sup>n</sup>***] (***n* **= 4, 6) compounds.**

Periodic Table | s-block chemistry | polyvalent metalloids | spin–orbit effects | relativistic quantum chemistry

Valence and oxidation numbers of the chemical elements have become key concepts in modern chemistry since the late 1860s, when all known elements were arranged in Periodic Tables. These tables visualize various rules of chemistry by grouping elements of similar properties and similar chemical behavior in the same column or group *G* (1–7). The regular arrangement of the elements in Periodic Tables is determined by the quantum physical laws, as first noted by Niels Bohr (8–14). Nonrelativistic quantum mechanics accounts for the basic properties of the elements in the upper and middle parts of the Periodic Table. The majority opinion is easily uncovered by AI, which scans the common textbook and journal narratives: "the Periodic Table is believed to continue indefinitely" since "there is no limit to the periodicity of chemical elements known so far," except for small variations due to electron interactions, and due to relativistic effects for high element numbers *Z*.

Relativistic corrections in the valence shell vary approximately proportional to *Z*<sup>2</sup> for increasing element number Z; hence, relativistic corrections become increasingly relevant for the heavier elements (*SI Appendix*, section S1). The core–valence energy gap (CVG) that determines the number of atomic valence electrons *G* decreases at the nonrelativistic level of theory approximately as *n*−3 to *n*−2 with period number *n* and principal quantum number *n* of the valence electrons. In addition, the relativistic spin–orbit splitting (and relativistic level shifts) diminishes the energy gaps. Consequently, the observed periodic rules of the light elements cannot simply be extrapolated into the realm of the very heavy elements, where new chemistry may arise in an unexpected manner, following relativistic quantum mechanics.

It had already been recognized since the early 1970s that the patterns of the atomic orbital energies and wavefunctions of the heaviest elements change (15–21). For instance, about 80% of the voltage of the lead battery is due to relativistic modifications of the valence activity of the heavy p-block element Pb (22). The s-block elements of groups 1 and 2 of the Periodic Table (Li, Na, K, Rb, Cs; and Be, Mg, Ca, Sr, Ba) possess the highest oxidation states +1 and +2, respectively, commonly taught in the textbooks (23, 24). Here, we report that relativistic quantum chemistry in contrast predicts the heaviest s-block elements 87Fr, 88Ra, and 119E, 120E behaving in molecules more like p-block elements with the highest oxidation states +5 and +6, even under ambient conditions. The conventional Periodic Law becomes modified for the heaviest elements, mainly due to the CVG reduction and the s1/2 and p1/2 orbital stabilization and contraction.

#### **Electronic Structure of Group**-**1 Elements**

For current Periodic Tables with elements Z = 1 to 118 in periods *n* = 1 to 7, the lightest and also the heaviest element of each group shows a peculiar chemistry, because of atypical

### **Significance**

Many chemistry textbooks assume the unreserved validity of the Periodic Law, placing elements of valence *G* in group column *G* of the Periodic Table. The physical origin is the large energy Gap between the atomic core and valence shells. Combining literature data on superheavy p-, d-, and fg-block compounds with present results on s-block polyfluorides shows that the decrease of the Gap with increasing nonrelativistic quantum numbers and relativistic spin–orbit splittings of the heavy atoms changes the chemical periodicity: i) The valences of the superheavy s/p-elements are raised/reduced, deviating from group labels *G*. ii) New periods no longer begin at groups 1 and 12. Both "failures" indicate the fading-out of the classic Periodic Law for elements above Z around 110.

Author contributions: W.H.E.S. and J.L. designed research; C.-S.C., J.Z., and H.-S.H. performed research; C.-S.C., J.Z., H.-S.H., W.H.E.S., and J.L. analyzed data; and C.-S.C., J.Z., H.-S.H., W.H.E.S., and J.L. wrote the paper.

The authors declare no competing interest.

This article is a PNAS Direct Submission. M.R. is a guest editor invited by the Editorial Board.

Copyright © 2023 the Author(s). Published by PNAS. This article is distributed under Creative Commons Attribution-NonCommercial-NoDerivatives License 4.0 (CC BY-NC-ND).

Present address: ByteDance Research, Haidian District, Beijing 100 089, China.

To whom correspondence may be addressed. Email: eugen.schwarz@uni-siegen.de or junli@tsinghua.edu.cn.

This article contains supporting information online at https://www.pnas.org/lookup/suppl/doi:10.1073/pnas. 2303989120/-/DCSupplemental.

Published October 19, 2023.

![](_page_1_Figure_0.jpeg)

**Fig. 1.** One-electron energies ( $\epsilon$  in eV) of group-1 alkali metal atoms. Atomic orbital energies  $\epsilon$  of (n-1)s,p outer-core and ns valence shells of the alkali metal atoms from  ${}_3$ Li to  ${}_{119}$ E in periods n = 2 to 8 (for  $\epsilon$ , an appropriate square-root scale  $\sqrt{\epsilon}$  à la Niels Bohr; spin-unrestricted noncollinear X2C-Dirac-Fock, QZ basis, more computational details see *SI Appendix*, section S2.2). The background colors indicate the energies where the orbitals typically change over from inert core–shell character (bluish) to valence activity (yellow) under common chemical conditions.

energetic and radial patterns of their outer-core and valence orbitals (25–30). In Fig. 1, we display the upper one-electron orbital energies of group-1 elements in periods n=2 to 8, including  $_{87}$ Fr and superheavy  $_{119}$ E. The core–valence gaps (CVG) lead to the emergence of chemically inert  $(n-1)s^2p^6$  noble-gas core–shells and chemically active valence-shells such as  $[Xe(1s^2-5p^6)]-6s^1$  of  $_{55}$ Cs or  $[Xe(1s^2-5p^6)]-6s^2$  of  $_{56}$ Ba.

Such CVGs between the (n-1)sp core and ns valence levels tend to fade away at the beginning of a new period of the very heavy elements. First, according to nonrelativistic quantum mechanics, the CVG gradually decreases with increasing principal valence quantum number *n* in period *n*, becoming less than 1 Rydberg at the bottom of the s-block (see SI Appendix, section S3, in particular SI Appendix, Fig. S2B). Second, the strong relativistic spinorbit destabilization of the  $(n-1)p_{3/2}$  core level and the scalar relativistic (SR) stabilization of the *n*s valence level together reduce the CVG below the critical empirical chemical limit, so that the (*n*-1)p<sup>6</sup> "noble gas core shells" of the alkali (A) and alkaline-earth (Ae) atoms become gradually more active toward ionization and chemical bond formation even under common conditions. From approximate superheavy atomic calculations, Fricke, Pyykkö, and others had found that the  $8p_{1/2}$  energy level falls below the 6f and 7d levels near Z = 139, and the  $9s,9p_{1/2}$  levels even fall below the  $8p_{3/2}$  level near Z = 168, inverting the common orbital energy order (31, 32). In order to validate the hypothesis of a chemically active  $(n-1)p_{3/2}$  "noble gas shell" for the superheavy elements Z > 118, we here investigate the *molecular* polyfluorides of elements 119 and 120. In the early 1970s, Fricke and others had already supposed their 3 and 4 valency (25–29).

#### Molecular 119 E Polyfluorides

The CVG between the  $7p_{3/2}$  and  $8s_{1/2}$  orbitals of the heaviest alkali element  $_{119}E$  is only about 7 eV (Fig. 1), indicating an unusually valence-active  $7p_{3/2}$  pseudocore shell. Hence, we performed molecular quantum-chemical calculations to explore the chemical oxidation of  $_{119}E$ . We studied the stepwise fluorination of  $_{119}E^-(ns^2)$ , forming the series of polyfluoride anions  $[_{119}EF_k]^-$ :

$$_{119}\mathrm{E}\left(ns^{2}\right)^{-}+\frac{k}{2}\mathrm{F}_{2}+\Delta\mathrm{E}_{k}\to\left[_{119}\mathrm{EF}_{k}\right]^{-}.$$

Both the reaction energy (negative  $\Delta E_k$  in Fig. 2A) and the effective orbital population  $\Delta Q_{ ext{eff}}$  on the central alkali metal atom (Fig. 2B) drop, the more F atoms coordinate (increasing k). The polar bond energies of the first two F atoms in  $[_{119}E^{+}(F^{-})_{2}]^{-}$ , somewhat stabilized by covalent orbital interaction of diffuse E(ns)(SI Appendix, Fig. S2) with F(2p), are around  $-3\frac{1}{2}$  eV. The  $7p_{3/2}$ shell of 119E is close enough in energy to the 8s1/2 valence shell (Fig. 1) to become chemically active, too. The E-7p<sub>3/2</sub> spinors are also sufficiently expanded (SI Appendix, Fig. S13) to overlap with ligand orbitals (F-2p). As a result, not only the weakly bound  $ns_{1/2}^{2}$ valence shell of the central A (or Ae) atom is easily oxidized off in the first two fluorination steps but also the  $(n-1)p_{3/2}^{4}$  "outer core" shell in the subsequent four fluorination steps, contributing bond energies of ca.  $3 \times -2\frac{1}{2}$  eV and  $1 \times -5$  eV. The most stable species is  $[\![_{119}EF_6]\!]$  with pentavalent  $_{119}E^{5+}$  (or  $_{120}EF_6$  with hexavalent 120E, see below), showing a total fluorination energy gain of more than -18 eV. Each further fluorination costs ca.  $+2\frac{1}{2}$  eV. The stable octahedral closed-shell EF<sub>6</sub> complexes appear akin to common hexafluoro p-element anions, such as [51SbF6] or  $[_{35}BrF_6]^-$  (23, 24), although  $[_{119}EF_6]^-$  has less covalent and more polar character than, for instance, [SbF<sub>6</sub>]<sup>-</sup>.

For coordination numbers k > 6, the fluorination energies become destabilizing by  $\pm 1/2$  to  $\pm 1$  eV (Fig. 2A) because it costs a huge energy to oxidize the electrons off the spin—orbit stabilized  $7p_{1/2}$  and the relativistic kinematically stabilized  $7s_{1/2}$  orbitals. Correspondingly, the population  $\Delta Q_{\rm eff}$  of the p orbitals decreases only slightly for k > 6 (Fig. 2B). This result corroborates the maximum oxidation state  $\pm 5$  and the pronounced pentavalence of

![](_page_1_Figure_10.jpeg)

Fig. 2. Alkali polyfluoride anions  $[_{119}EF_k]^-$  for k=0 to 9. (A) Formation energies  $\Delta E$  (in  $eV \approx 10^2$  kJ/mol) of successive fluorination,  $_{119}E(8s^2)^- + {}^k/{}_2$   $F_2 \rightarrow [_{119}EF_k]^-$  (CAS-SI/SO, for computational details see *SI Appendix*, section S7). (*B*) Atomic orbital populations  $\Delta Q_{eff}$  (in e) of the alkali 8s-valence (red) and 7p-pseudocore orbitals (blue), with reference to  $_{119}E^+-7p_{1/2}^-7p_{3/2}^-48s^0$  (for more details, see *SI Appendix*, sections S2, S4, and S7).

element  $_{119}$ E. In contrast to the typical monovalent alkali metal elements with an inert  $(n-1)(\mathrm{sp})^8$  core shell and an  $n\mathrm{s}^1$  valence shell, the heaviest member of the group-1 elements in the eighth period utilizes  $7\mathrm{p}_{3/2}^{\phantom{3}4}8\mathrm{s}_{1/2}^{\phantom{3}1}$  as its valence shells (see the red coloured levels in Fig. 1) with  $(n-1)(\mathrm{s}_{1/2}\mathrm{p}_{1/2})^4$  as the outer atomic core. This finding implies that some other heavy elements may also feature higher than normal oxidation states due to the valence activity of the  $(n-1)\mathrm{p}_{3/2}^{\phantom{3}4}$  pseudo-core shell.

# Isomeric Hexafluoro Molecules of $[EF_6]^{-1;0}$ (E = $_{87}$ Fr, $_{88}$ Ra, $_{119}$ E, $_{120}$ E)

The behaviour of  $_{119}$ E as a p-block element with a valence-active  $(n-1)p_{3/2}$ -shell motivated us to explore the polyvalency of other s-block elements with potentially high oxidation states +5 and +6 and 3 frontier spinor orbitals  $(n-1)p_{3/2,3/2}$ ,  $(n-1)p_{3/2,1/2}$  and  $ns_{1/2}$ . Halide anions  $X^-$  combine slightly exothermally with dihalogen molecules  $X_2$ , forming linear trihalide anions  $X_3^-$  (33–36). Hence, the addition of  $F_2$  molecules to the alkali (A) and alkaline-earth (Ae) species AF, AF $_2^-$ , and AeF $_2$  unsurprisingly yields the experimentally or theoretically known species  $[A^+(F_3^-)]$ ,  $[A^+(F_3^-)_2]^-$  and  $[Ae^{2+}(F_3^-)_2]$ . We have calculated energies, geometric and electronic structures, and oxidation states of various isomers of the polyfluoro complexes of  $A^-$  and Ae. The favoured structures of the hexafluorides are, throughout,  $D_{2d}$ -E( $F_3^-$ ) $_2$  for the lighter s-elements E and  $O_b$ -E( $F^-$ ) $_6$  for the heaviest ones (Fig. 3).

We note the energetic trends of the competitive formation of the isomeric bis-trifluorides versus the hexa-monofluorides of the alkali/alkaline-earth elements, for instance,

$$Ae^{2+}(F^{-})_{2} + 2F_{2} + \Delta E_{bis-tri} \rightarrow [Ae^{2+}(F_{3}^{-})_{2}],$$

$$\mathrm{Ae^{2+}(F^-)_2 + 2F_2 + \Delta E_{hex-mono} \rightarrow \left[\mathrm{Ae^{6+}(F^-)_6}\right]}.$$

The energetic results ( $\Delta E_{bis-tri}$  vs.  $\Delta E_{hex-mono}$ ) for  $_3$ Li to  $_{119}$ E are shown in Fig. 4A and the same trend is found for the alkaline-earth metals  $_{56}$ Ba to  $_{120}$ E (SI Appendix, section S5).

Our calculations reconfirm that the common oxidation states +1 and +2 are favored by the hexafluoro complexes of the light and medium-heavy s-elements (E = A<sup>+</sup>, Ae<sup>2+</sup>) with  $O_h$ -E(F<sup>1/3-</sup>)<sub>6</sub> and  $D_{2d}$ -E(F<sub>3</sub>  $^-$ )<sub>2</sub> structures. A special case is the lightest alkali element Li, where both Li(F)<sub>6</sub> and Li(F<sub>3</sub>)<sub>2</sub> are unstable with respect to LiF<sub>2</sub> + 2F<sub>2</sub>, due to the extremely small radius of the helium-like Li<sup>+</sup>(1s<sup>2</sup>) cation. However, for the superheavy s-elements at the start of the 8<sup>th</sup> period, the high oxidation states

![](_page_2_Picture_8.jpeg)

**Fig. 3.** Geometric structures of hexafluoro complexes of the alkali (E = A¯) and alkaline-earth (E = Ae $^{6}$ ) elements. From quantum chemical calculations (*SI Appendix*, sections S2.2 and S4). In the  $D_{2d}$ -symmetric E(F $_{3}$ )<sub>2</sub> species, two common (slightly bent) F $_{3}$ ¯ anions are ligated to the E cations in common oxidation states A $^{+}$  and Ae $^{2+}$  (*SI Appendix*, section S5). Unusually high oxidation states of the central E $^{5+,6+}$  cations are observed for the predicted octahedral  $O_{h}$ -E(F $_{0}$ )<sub>6</sub> species.

+5 and +6 become energetically strongly preferred, for  $[_{119}E^{+5}(F^{-})_6]^{-}$  and  $[_{120}E^{+6}(F^{-})_6]$  by  $\Delta E$  at the order of –15 eV! The heaviest, chemically known elements Fr and Ra in period 7 represent the border cases.

The large difference of the preferred oxidation states of the common versus the superheavy s-elements is unprecedented. It is corroborated by the E–F bond distances of the various structures (Fig. 4B). The lilac, blue, and red lines refer, respectively, to  $[A^+(F^{1/3-})_6]^-$ ,  $[A^+(F_3^-)_2]^-$ , and  $[A^{5+}(F^-)_6]^-$ . As a reference for the A–F bond lengths, the black line shows the interatomic distances of  $[A^+(F^-)]^0$ , which increase smoothly up to  $_{119}$ E. The bond distances of the strongly polar-bonded A–F molecules vary with the  $(n-1)p_{3/2}$  outer-core orbital radii, increasing with period number n up to  $_{119}$ E. In contrast, the covalent A–H distances in the hydride molecules reach their maximum at Cs and decrease for the heavier Fr and  $_{119}$ E because of the strong relativistic contraction of the outer  $ns_{1/2}$  orbital (29, 37, 38). It follows that Cs is the biggest atom, but Cs<sup>+</sup> is not the biggest atomic cation!

biggest atom, but  $Cs^+$  is not the biggest atomic cation! For the isomeric species  $[A^+(F^{1/3}^-)_6]^-$  and  $[A^+(F_3^-)_2]^-$  (lilac and blue lines in Fig. 4B), the A–F distances steadily increase from Li to Cs. As usual, the distances of the species with coordination number (CN) = 6 are larger than the distances of  $[A^+(F^-)]^0$  with smaller CN = 1 (here by ca. ½Å). However, when the oxidation state increases by four units from +1 to +5 for the heaviest elements  $_{87}$ Fr and  $_{119}$ E, corresponding to the oxidation of the  $7p_{3/2}^{-4}$  semicore shell to  $7p_{3/2}^{-0}$ , with structural rearrangement of  $A(F_3)_2$  to  $A(F)_6$ , a dramatic contraction of nearly –1 Å happens (from blue to red in Fig. 4B). This is the manifestation of the fully oxidized-off  $7p_{3/2}$  subshell.

#### **Summary and Conclusions**

Common Periodic Tables display many rules of chemistry, which apply primarily to the more frequent elements, i.e., the light and medium-heavy ones. An element of number Z has Z electrons in total for each neutral atom, held together by a nucleus with Z protons. Only G valence electrons are chemically active, energetically weakly bound, and well separated by a large gap from the chemically inactive core shells,  $1s^2$  or  $1s^2$ - $(n-1)(sp)^8$  [or (n-1) $(spd)^{18}$  or  $(n-2)f^{14}(n-1)(sp)^{8}$ ]. Elements with G valence electrons are placed in *group G* (and period *n*) of the Periodic Table, with valence and oxidation numbers both capped by maximum value G. The core shells codetermine the effective ionic and covalent radii, the bond forces, and thereby the structures and reactivities (15, 30, 39). The energetic core–valence gap (CVG) must be large enough in comparison to activation energies under common conditions of temperature and pressure to guarantee molecular stability (for common time periods) typically larger than about a Rydberg. Hence, 1 step after each "noble gas" core shell filling, a period of elements with valences G = 1, 2, ..., 7, or 8 begins at alkali metal group G = 1 (and from period 4 onward also 12 steps later with valences G = 2, 3, ..., 7 at zinc metal group G = 12).

At the bottom of the Periodic Table, the elements have large Z and n values, with various  $\ell j$  (angular momenta) in the outer core and valence shells. The  $(n-1)p^6$  - ns and  $(n-1)d^{10}$  - ns CVGs decrease for two reasons. i) At the nonrelativistic approximation, the leading  $\sim n^{(-2 \text{ to } -3)}$  term for the size of the CVG decreases toward the critical Rydberg limit at the bottom of the Periodic Table (*SI Appendix*, section S2). ii) At the more realistic relativistic level of theory, the outer-core  $(n-1)p_{3/2}$  (and  $(n-1)d_{5/2}$ ) spin—orbit destabilization and the valence ns stabilization (both scaling with increasing Z approximately as  $\sim Z^2$ ) reduce the (n-1)p - ns and (n-1)d - ns CVGs furthermore. Hence, the  $(n-1)(sp)^8$  and (n-1) (spd)  $^{18}$  core shells gradually lose their "chemically inert" character

![](_page_3_Figure_0.jpeg)

Fig. 4. Formation energies and internuclear distances of alkali polyfluoride anions AF<sub>6</sub><sup>-</sup>. (CAS-SI/SO, for computational details see SI Appendix, section S2). (A) Formation energies  $\Delta E$  (in  $eV \approx 10^2$  kJ/mol) for different isomers:  $[AF_2]^- + 2F_2 \rightarrow D_{2d^-}[A^{A}(F_3)_2]^-$  (blue dots) versus  $O_{h^-}[A^{A}(F^{-1/3})_6]^-$  (iilac dots) or  $O_{h^-}[A^{5+}(F)_6]^-$  (red squares). (B) Shortest distances D(A-F) (in Å) of the most stable isomers; and for comparison of the common diatomic [A+F-] molecules (black dots).

upon increasing Z. As known from recent literature, the outer d<sup>10</sup> shell of 112Cn can easily be oxidized, what is impossible for the lighter homologs  $_{30}$ Zn,  $_{48}$ Cd, and  $_{80}$ Hg under common conditions. In addition,  $_{118}$ Og- $7(sp)^8$  "is neither noble nor a gas" with a  $7p_{3/2}^{4}$  valence shell (40, 41). Between the belated stabilizations of  $6d_{5/2}^{6}$  and  $7p_{3/2}^{2}$  as core shells of the series of 7p elements (13Nh -  $_{118}$ Og), there occur the premature stabilizations of the  $7s_{1/2}$  and 7p<sub>1/2</sub> valence shells (*SI Appendix*, section S1) violating Mendeleev's basic principle of valence = group number.

Half a century ago, the superheavy s-block elements  $_{119}\text{E-}7p_{3/2}$ 8s<sup>1</sup> and <sub>120</sub>E-7p<sub>3/2</sub> <sup>4</sup>8s<sup>2</sup> were supposed being higher-valent than 1 and 2, namely 3 and 4, on the basis of relativistic atomic calculations (25, 26). Here, the first molecular calculations of superheavy alkali and alkaline-earth compounds imply that 119E and 120E do not behave as typical s-block metals, but as a new type of p-block metalloids with valence active  $7p_{3/2}^{\phantom{3/2}4}$  8s<sup>1,2</sup> shells and valences 5 and 6, under common conditions. The diffuse 8s orbital supports ionic bonding, and the two  $7p_{3/2}$  spinors reaching out of the  $7s_{1/2}^2 7p_{1/2}^2$ core shells support covalent bonds (SI Appendix, section S6).

Stable compounds of pentavalent group-1 elements and hexavalent group-2 elements have so far only been found under "exotic" conditions. Cesium  $_{55}\mathrm{Cs}$  appears as multivalent in theoretically predicted meta-stable states of some poly-fluorides and -oxides, stabilized by extreme pressure (42-45). Border-line elements 87 Fr and 88 Ra have so far only been investigated from the traditional viewpoint of low valency. Unfortunately, the lifetime of Fr (<1/2 h) is too short for bulk compounds and for detailed laboratory investigations. However, chemical compounds of 88Ra are less exotic, with a nuclear half-life of approximately 1,600 y. Looking from the present viewpoint, the art of synthesis appears promising for hexavalent radium complexes  $[Ra^{n+}L_{n}]$  (n = 4, 6) with electronegative and appropriately structured (possibly polydentate) ligands.

#### **Methods**

Both ab initio wave-function theory (WFT) and density-functional theory (DFT) approximations have been applied for the present quantum chemical studies,

- L. Gmelin, Handbuch der Chemie (Karl Winter, Heidelberg, ed. 3, 1843). S. Cannizzaro, Letter to professor S. de Luca. Il Nuovo Cimento 7, 321-366 (1858).
- L. Meyer, Die modernen Theorien der Chemie und ihre Bedeutung für die chemische Statik (Maruschke & Berendt, Breslau, 1864).
- D. Mendeleev, Die periodische Gesetzmäßigkeit der chemischen Elemente. Ann. Chem. Pharm. Suppl. 8, 133-229 (1871).
- N. Bohr, Drei Aufsätze über Spektren und Atombau (Vieweg, Braunschweig, 1922).
- J. W. van Spronsen, The Periodic System of Chemical Elements: A History of the First Hundred Years (Elsevier, Amsterdam, 1969).
- E. Scerri, The Periodic Table: Its Story and Its Significance (Oxford University Press, Oxford, GB,

using multiple-zeta polarized basis sets of Gaussian and Slater types, respectively. The DFT calculations were conducted for all molecular electrons with the Amsterdam Density Functional program (46), using PBE, PBEO, B3LYP, and HSE06 functionals (47-51). The scalar and spin-orbit coupled relativistic effects were treated at the level of the two-component zero-order regular approximation (52-54). The geometric structures were then determined at the Born-Oppenheimer level, and the single-determinant wavefunctions

WFT calculations were conducted at these geometries utilizing advanced electron correlation techniques in the molecular program MOLPRO 2018.2 with relativistic effective core potentials (RECP) (55, 56). The energetic stabilities were determined at the SR level by coupled-cluster calculations with single, double, and perturbative triple substitutions (CCSD(T)) and by complete active space (CAS) multiconfiguration calculations. Corrections for spin-orbit coupling were then obtained by State Interaction through RECP spin-orbit Coulomb-Breit coupling and perturbation theoretically (second order) corrected diagonal matrix elements (CASPT2/SI-SO) (57).

For further details, please refer to SI Appendix, in particular SI Appendix, sections S3, S4, and S6.

Data, Materials, and Software Availability. All study data are included in the article and/or supporting information.

**ACKNOWLEDGMENTS.** We thank the three unknown reviewers, and F.M. Bickelhaupt, W. Liu, V. Pershina, P. Pyykkö, G. Restrepo, R.E. Vernon, and P. Schwedtfeger for illuminating discussions over the years. This work was financially supported by the National Natural Science Foundation of China (Grant 22033005), the NSFC Center for Single-Atom Catalysis, and partially sponsored by the Guangdong Provincial Key Laboratory of Catalysis (No. 2020B121201002). Computational resources were supported by the Xuetang Program of Department of Chemistry, Tsinghua University, and Center for Computational Science and Engineering (SUSTech).

Author affiliations: <sup>a</sup>Theoretical Chemistry Center, Department of Chemistry and Engineering Research Center of Advanced Rare-Earth Materials of Ministry of Education, Tsinghua University, Beijing 100084, China; bPhysical and Theoretical Chemistry Lab, Department of Chemistry and Biology, Faculty of Science and Technology, University of Siegen, Siegen 57068, Germany; and Department of Chemistry, Southern University of Science and Technology, Shenzhen 518055, China

- N. Bohr, D. Coster, Röntgenspektren und periodisches System der Elemente. Z. Phys. 12, 342-374 (1923).
- R. Latter, Atomic energy levels for the Thomas-Fermi and Thomas-Fermi-Dirac potential. Phys. Rev. 99, 510-519 (1955).
- S. G. Wang, W. H. E. Schwarz, Icon of chemistry: The periodic system of chemical elements in the new century. Angew. Chem. Int. Ed. 48, 3404-3415 (2009).
- P. Pyykkö, The physics behind chemistry and the periodic table. Chem. Rev. 112, 371-384 (2012).
- C.-S. Cao, H.-S. Hu, J. Li, W. H. E. Schwarz, Physical origin of chemical periodicities in the system of elements. Pure Appl. Chem. 91, 1969-1999 (2019).
- P. Schwerdtfeger, O. R. Smits, P. Pyykkö, The periodic table and the physics that drives it. Nat. Rev. Chem. 4, 359-380 (2020).

- 14. C.-S. Cao, R. E. Vernon, W. H. E. Schwarz, J. Li, Understanding periodic and non-periodic chemistry in periodic tables. *Front. Chem.* 8, 813 (2021).
- 15. P. Pyykkö, J. P. Desclaux, Relativity and the periodic system of elements. *Acc. Chem. Res.* 12, 276–281 (1979).
- 16. K. S. Pitzer, Relativistic effects on chemical properties. *Acc. Chem. Res.* 12, 271–276 (1979).
- 17. N. C. Pyper, Relativistic modifications of covalent bonding in heavy elements: The kappa valence method. *Chem. Phys. Lett.* 73, 385–392 (1980).
- 18. P. Hafner, P. Habitz, Y. Ishikawa, E. Wechsel-Trakowski, W. H. E. Schwarz, Quasi-relativistic model potential approach. Spin-orbit effects on energies and geometries of several di- and tri-atomic molecules. *Chem. Phys. Lett.* 80, 311–315 (1981).
- 19. P. Schwerdtfeger, M. Dolg, W. H. E. Schwarz, G. A. Bowmaker, P. D. W. Boyd, Relativistic effects in gold chemistry. I. Diatomic gold compounds. *J. Chem. Phys.* 91, 1762–1774 (1989).
- 20. W. H. E. Schwarz, *An Introduction to Relativistic Quantum Chemistry. Relativistic Methods for Chemists* (Springer, Dordrecht, 2010), pp. 1–62.
- 21. P. Pyykkö, Relativistic effects in chemistry: More common than you thought. *Annu. Rev. Phys. Chem.* 63, 45–64 (2012).
- 22. R. Ahuja, A. Blomqvist, P. Larsson, P. Pyykkö, P. Zaleski-Ejgierd, Relativity and the lead-acid battery. *Phys. Rev. Lett.* 106, 018301 (2011).
- 23. F. A. Cotton, G. Wilkinson, C. A. Murillo, M. Bochmann, *Advanced Inorganic Chemistry* (John Wiley, New York, 1999).
- 24. N. N. Greenwood, A. Earnshaw, *Chemistry of the Elements* (Elsevier, Amsterdam, 2012).
- 25. B. Fricke, J. T. Waber, Theoretical predictions of the chemistry of superheavy elements. *Actin. Rev.* 1, 433–485 (1971).
- 26. B. Fricke, Superheavy elements, a prediction of their chemical and physical properties. *Struct. Bond.* 21, 89–144 (1975).
- 27. P. Pyykkö, On the interpretation of 'secondary periodicity' in the periodic system. *J. Chem. Res. (S)* 1979, 380–381 (1979).
- 28. V. Pershina, "Theoretical chemistry of the heaviest elements" in *The Chemistry of Superheavy Elements*, M. Schädel, D. Shaughnessy, Eds. (Springer, Berlin, 2014), pp. 135–239.
- 29. V. Pershina, Relativity in the electronic structure of the heaviest elements and its influence on periodicities in properties. *Radiochim. Acta* 107, 833–863 (2019).
- 30. Z.-L. Wang *et al.*, Understanding the uniqueness of 2p elements in periodic tables. *Chem. Eur. J.* 26, 15558–15564 (2020).
- 31. B. Fricke, W. Greiner, On the chemistry of superheavy elements around Z = 164. *Phys. Lett. B* 30, 317–319 (1969).
- 32. P. Pyykkö, A suggested periodic table up to Z≤ 172, based on Dirac-Fock calculations on atoms and ions. *Phys. Chem. Chem. Phys.* 13, 161–168 (2011).
- 33. Z. Sun, H. F. Schaefer, Vibrational frequencies, structures, and energetics of the highly challenging alkali metal trifluorides MF3 (M= Li, Na, K, Rb, and Cs). *Phys. Chem. Chem. Phys.* 20, 18986–18994 (2018).
- 34. F. A. Redeker *et al.*, Theoretical investigation of the structures, stabilities and vibrational properties of triatomic interhalide ions and their alkali ion pairs. *J. Fluor. Chem.* 216, 81–88 (2018).
- 35. K. Sonnenberg, L. Mann, F. A. Redeker, B. Schmidt, S. Riedel, Polyhalogen and polyinterhalogen anions from fluorine to iodine. *Angew. Chem. Int. Ed.* 59, 5464–5493 (2020).
- 36. F. A. Redeker, H. Beckers, S. Riedel, Investigation of alkali metal polyfluorides by matrix-isolation spectroscopy. *RSC Adv.* 5, 106568–106573 (2015).

- 37. V. Pershina, Electronic structure and properties of superheavy elements. *Nucl. Phys. A* 944, 578–613 (2015).
- 38. E. Zurek, Hydrides of the alkali metals and alkaline earth metals under pressure. *Comments Inorg. Chem.* 37, 78–98 (2017).
- 39. P. Schwerdtfeger, "Relativistic effects in molecular structure of s- and p-block elements" in *Strength from Weakness: Structural Consequences of Weak Interactions in Molecules, Supermolecules, and Crystals*, A. Domenicano, I. HargittaiI, Eds., *NATO Science Series* (Kluwer, Dordrecht, 2002), pp. 169–190.
- 40. J. M. Mewes, P. Jerabek, O. R. Smits, P. Schwerdtfeger, Oganesson is a semiconductor: On the relativistic band-gap narrowing in the heaviest noble-gas solids. *Angew. Chem. Int. Ed.* 58, 14260–14264 (2019).
- 41. O. R. Smits, J. M. Mewes, P. Jerabek, P. Schwerdtfeger, Oganesson: A noble gas element that is neither noble nor a gas. *Angew. Chem. Int. Ed.* 59, 23636–23640 (2020).
- 42. A. Y. Rogachev, M.-S. Miao, G. Merino, R. Hoffmann, Molecular CsF5 and CsF2 + . *Angew. Chem. Int. Ed.* 54, 8275–8278 (2015).
- 43. M. G. Goesten, M. Rahm, F. M. Bickelhaupt, E. J. M. Hensen, Cesium's off-the-map valence orbital. *Angew. Chem. Int. Ed.* 56, 9772–9776 (2017).
- 44. M.-S. Miao, Caesium in high oxidation states and as a p-block element. *Nat. Chem.* 5, 846–852 (2013).
- 45. Q. Zhu, A. R. Oganov, Q. Zeng, Formation of stoichiometric CsFn compounds. *Sci. Rep.* 5, 1–6 (2015).
- 46. G. te Velde *et al.*, Chemistry with ADF. *J. Comput. Chem.* 22, 931–967 (2001).
- 47. J. P. Perdew, K. Burke, M. Ernzerhof, Generalized gradient approximation made simple. *Phys. Rev. Lett.* 77, 3865–3868 (1996).
- 48. J. Heyd, G. E. Scuseria, M. Ernzerhof, Hybrid functionals based on a screened Coulomb potential. *J. Chem. Phys.* 118, 8207–8215 (2003).
- 49. M. Ernzerhof, G. E. Scuseria, Assessment of the Perdew–Burke–Ernzerhof exchange-correlation functional. *J. Chem. Phys.* 110, 5029–5036 (1999).
- 50. S. Grimme, Accurate description of van der Waals complexes by density functional theory including empirical corrections. *J. Comput. Chem.* 25, 1463–1473 (2004).
- 51. P. J. Stephens, F. J. Devlin, C. F. Chabalowski, M. J. Frisch, Ab initio calculation of vibrational absorption and circular dichroism spectra using density functional force fields. *J. Phys. Chem.* 98, 11623–11627 (1994).
- 52. E. van Lenthe, E.-J. Baerends, J. G. Snijders, Relativistic regular two-component Hamiltonians. *J. Chem. Phys.* 99, 4597–4610 (1993).
- 53. E. van Lenthe, E.-J. Baerends, J. G. Snijders, Relativistic total energy using regular approximations. *J. Chem. Phys.* 101, 9783–9792 (1994).
- 54. E. van Lenthe, A. Ehlers, E.-J. Baerends, Geometry optimizations in the zero order regular approximation for relativistic effects. *J. Chem. Phys.* 110, 8943–8953 (1999).
- 55. H.-J. Werner *et al.*, MOLPRO, version 2018.2, a package of ab-initio programs (2018), https://www. molpro.net.
- 56. H.-J. Werner, P. J. Knowles, G. Knizia, F. R. Manby, M. Schütz, Molpro: A general-purpose quantum chemistry program package. *Wiley Interdiscip. Rev. Comput. Mol. Sci.* 2, 242–253 (2012).
- 57. A. Berning, M. Schweizer, H.-J. Werner, P. J. Knowles, P. Palmieri, Spin-orbit matrix elements for internally contracted multireference configuration interaction wavefunctions. *Mol. Phys.* 98, 1823–1833 (2000).