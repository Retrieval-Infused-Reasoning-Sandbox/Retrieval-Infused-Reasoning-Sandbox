ELSEVIER

Contents lists available at ScienceDirect

# Applied Catalysis B: Environmental

journal homepage: www.elsevier.com/locate/apcatb

![](_page_0_Picture_5.jpeg)

# $MnO_x$ -support interactions in catalytic bodies for selective reduction of NO with $NH_3$

![](_page_0_Picture_7.jpeg)

Ana Serrano-Lotina<sup>a,\*</sup>, Manuel Monte<sup>b</sup>, Ana Iglesias-Juez<sup>a</sup>, Pablo Pavón-Cadierno<sup>a</sup>, Raquel Portela<sup>a</sup>, Pedro Ávila<sup>a</sup>

- <span id="page-0-0"></span><sup>a</sup> Instituto de Catálisis y Petroleoquímica (CSIC), C/Marie Curie 2 L10, Campus Cantoblanco, 28049 Madrid, Spain
- <span id="page-0-2"></span><sup>b</sup> ESRF-The European Synchrotron, CS40220, 38043 Grenoble, Cedex 9, France

#### ARTICLE INFO

Keywords: Low temperature SCR Manganese oxides Catalytic bodies Operando XAS In situ spectroscopy

#### ABSTRACT

Catalytic bodies for selective reduction of  $NO_x$  with  $NH_3$  based on  $MnO_x$ ,  $TiO_2$  and sepiolite as active phase, support, and binder, respectively, were prepared. The same amount of  $MnO_x$  (5 w%) was added by impregnation of the precursor over a 70/30 titania/sepiolite. One catalyst was obtained by wet equilibrium impregnation of the pre-shaped support, while the other was prepared by incipient wetness impregnation of the  $TiO_2$  and then mixed with the binder and the PGA, and finally extruded. In order to study the role of the binder in the catalytic system, four models were also synthesized. According to characterization data and to catalytic activity results, sepiolite not only confers the rheological properties needed for extrusion, but it also modifies the physicochemical properties of the catalysts: it modulates the acidity and the  $NO_x$  adsorption capacity and lability, and, depending on the synthesis procedure, it enhances catalytic activity.

## 1. Introduction

Air pollution is a complex environmental and social problem posing multiple challenges in terms of management and mitigation [1]. Nitrogen oxides (NO<sub>x</sub>) are among the major atmospheric pollutants due to their chemical transformations in the atmosphere, contributing to acid rain, ozone depletion and photochemical smog. NO is mainly emitted by biomass or fuel combustion, energy generation, and transport, and it is easily oxidized into NO2 by reaction with O2 or other primary pollutants. Despite the increased worldwide effort to reduce NO<sub>x</sub> emissions, tens of million tons of NO<sub>x</sub> are released into the atmosphere every year and the trend is still rising. There are two methods to fight NO<sub>v</sub> emissions: the prevention of NO<sub>x</sub> production or its abatement. Selective catalytic reduction (SCR) with NH3 as the reducer agent has been demonstrated to be the most effective and preferred method worldwide for the treatment of flue gases from stationary sources [2,3]. In this process, NH3 reacts selectively with NOx over a catalyst surface to produce N2 and H2O in presence of excess O2. However, N2O, with high greenhouse and ozone layer depletion potential [4,5], can be generated as undesirable secondary product.

The most common commercial catalysts are  $V_2O_5$  and  $WO_x$  or  $MoO_x$  mixtures supported on  $TiO_2$  due to their high catalytic activity, thermal stability and long life [6–8]. They operate in the high-dust

configuration, where operation temperatures are 300-400 °C. However, the low dust configuration, where the NH3-SCR unit is placed downstream the precipitator and desulfurizer, is preferred to minimize the negative influence of dusts and SO2 on the catalytic performance, and thus extend its lifetime. This reduces the gas temperature below 200 °C [9], and therefore requires the development of low-temperature SCR (LT-SCR) catalysts. Noble metals have excellent catalytic activity at low temperature [10], but with poor selectivity to  $N_2$ , in a narrow operation window, and at high cost. For these reasons, other systems based on transition metals have also been explored, as  $Cr/TiO_2$  [11], iron titanate [12], V-based catalysts [13,14], zeolites doped with Fe and Cu [15–18], zirconium-niobium solid solutions [19], and catalysts based on manganese oxides [20]. Among these systems, the latter seem to be the most promising [2,21,22], and TiO<sub>2</sub> has been reported to be one of the best supports in order to disperse manganese oxides providing the proper acidity and redox properties [23,24].

MnOx-supported catalysts have been mainly tested as powder-type model catalysts, whereas for industrial applications pellets, spheres or channelled monoliths are required. Binders are often necessary to shape the catalysts by extrusion and obtain porous ceramic bodies with high mechanical strength, thermal resistance, and high surface area [25,26].

Catalytic results obtained over model laboratory scale catalysts might be far away from the industrial performance of the shaped

<span id="page-0-1"></span><sup>\*</sup> Corresponding author at: Instituto de Catálisis y Petroleoquímica, C/Marie Curie 2 L10, Campus de Cantoblanco, 28049 Madrid, Spain. E-mail address: asl@icp.csic.es (A. Serrano-Lotina).

systems, where both the preparation method and the composition are necessarily different, and also the thermal, mechanical and fluid-dynamic properties. Moreover, monoliths preparation procedure can be altered in order to tune the nature of the active phases and their macrodistribution within the catalyst body for optimal catalytic performance. A preliminary study with natural clays showed that catalytic bodies prepared using sepiolite (a natural hydrated magnesium silicate clay) as binder were more active and selective to  $\rm N_2$  in the SCR process than those where bentonite, atapulgite or mordenite were used.

The aim of this work was to obtain a catalyst with direct industrial application for LT-SCR. For that purpose, we have synthesized Mn/  ${\rm TiO_2}/{\rm sepiolite}$  bodies by extrusion following different methods in order to study the role of sepiolite binder in the catalytic system with a multitechnique approach. *In situ* synchrotron XAS measurements and *in situ* DRIFTS-MS complemented basic characterization data to correlate the catalytic performance in LT-SCR with the structural and electronic properties of the catalysts. EXAFS was employed to characterize the local structure of the Mn species, while XANES provided information about their electronic properties. *In situ* DRIFTS allowed the study of reaction intermediates and the reactants/surface interactions.

#### 2. Materials and methods

# 2.1. Synthesis of the catalytic bodies

 $TiO_2$  was supplied by Than et Mulhouse (Courvevoie Cedex, France), sepiolite by Tolsa, S.A. (Madrid, Spain), manganese (II) nitrate hexahydrate,  $Mn(NO_3)_2$ ·4H $_2$ O (Purity = 96%) was purchased from Riedel-de Häen and the PGA by Chemviron Carbon (Feluy, Belgium).

Two main catalytic bodies were synthesized by two different methods where the active phase is impregnated either before or after the extrusion process, called B-ext and A-ext catalysts, respectively. Both contained 70:30 TiO<sub>2</sub>: sepiolite wt% ratio and 5 wt% Mn loading. A pore generation agent (PGA) was added (10 wt%) in order to confer macroporosity, but it was not present in the final composition because it was eliminated during the calcination step [27]. B-ext was prepared by incipient wetness impregnation of the powdered titania. The Mn impregnated titania was dried overnight at 110 °C and then grinded using a ceramic mortar. Thereafter, sepiolite and the PGA were added and properly blended. Afterwards, water was added dropwise until a good plasticity for extrusion was achieved. The green bodies were dried overnight at room temperature and calcined at 550 °C for 4 h.

A-ext was prepared by wet equilibrium impregnation of the preshaped titania-sepiolite support. Firstly, the support was shaped: the appropriate amount of  ${\rm TiO_2}$ , sepiolite, PGA, and water was kneaded and extruded. The green bodies were dried overnight at room temperature and calcined at 550 °C for 4 h. For impregnation, the cylinders were dried at 110 °C to eliminate physisorbed water, and then submerged into a solution of the Mn-salt during 60 min under constant stirring at 10 rpm with subsequent filtration. The solid was dried overnight at 110 °C and then calcined at 400 °C during 4 h.

Several model catalysts with the same 5 wt% Mn loading were synthesized without PGA by incipient wetness impregnation of the powders before extrusion (similarly to B-ext catalyst). T and S are catalysts with only  ${\rm TiO_2}$  or only sepiolite as support, respectively (a minimal amount of binder was used in T because pure  ${\rm TiO_2}$  was not mechanically stable). TS and ST are samples with  ${\rm TiO_2}$ :sepiolite mixtures, where the Mn salt was either impregnated over  ${\rm TiO_2}$  and then mixed with sepiolite (TS) or impregnated over sepiolite and then mixed with  ${\rm TiO_2}$  (ST). All these catalysts were calcined at 400 °C for 4 h.

# 2.2. Characterization

Chemical composition was determined by an ICP-OES Analytic Jena PlasmaQuant PQ 9000 after acid digestion of the catalysts. X-ray diffraction (XRD) was performed by an X-ray diffractometer (XPERT-PRO, PANanalytical) using Cu Kα radiation ( $\lambda = 0.154$  nm). Catalysts specific surface areas were measured by the BET method using  $N_2$  at -196 °C in a Micromeritics TriStar 3000. Acidity was determined by ammonia temperature programmed desorption (NH<sub>3</sub>-TPD) using an ASAP 2010, equipment from Micromeritics. Samples were heated at 200 °C to ensure that they were free from any loosely bound adsorbed species. Afterwards, chemisorption was carried out in 5%NH<sub>3</sub>/He at 100 °C for 60 min, then the temperature was raised to 120 °C with a 30 min dwell in He to eliminate fisisorbed NH<sub>3</sub>. Finally, the sample was heated at 10 °C·min  $^{-1}$  up to 400 °C. Total acidity was calculated by integration of the area under the NH<sub>3</sub> desorption curve.

### 2.3. Catalytic tests

The SCR activity measurements with the shaped catalysts were carried out in a test plant within a fixed-bed glass reactor. The reactant gas composition was:  $1000 \, \text{ppm}$  NO,  $1000 \, \text{ppm}$  NH $_3$ ,  $10\% \, \text{O}_2$  and balance N $_2$ . GHSV was  $18,500 \, \text{h}^{-1}$  and the lineal velocity  $0.5 \, \text{m} \, \text{s}^{-1}$ . Temperature was controlled by two thermocouples placed at the beginning and the end of the catalytic bed.

 $NO_x$ ,  $NH_3$  and  $N_2O$  concentration was continuously monitored by a 4000 V M  $NO_x$  analyser, a 418 LUFT IR analyser and a MGA1000 multigas analyser, respectively. The  $NO_x$  conversion and  $N_2$  selectivity were calculated using the following equations:

$$NO_x$$
 conversion  $(X_{NO_x}) = \frac{[NO_x]_{in} - [NO_x]_{out}}{[NO_x]_{in}} \times 100$ 

N2 selectivity

$$= \frac{[NO]_{in} + [NH_3]_{in} - [NO]_{out} - [NH_3]_{out} - [NO_2]_{out} - 2 [N_2O]_{out}}{[NO]_{in} + [NH_3]_{in} - [NO]_{out} - [NH_3]_{out}} \times 100$$

# 2.4. XAS

XAS data were collected for all the samples and also some Mn references at BM23 beamline [28] of the European Synchrotron Radiation Facility (ESRF), Grenoble (the ring energy was 6.0 GeV and the current 150–200 mA). Two crystals of Si (111) were used as a monochromator and a pair of Si-coated mirrors with a glancing angle of 3 mrad was employed to reject high-energy harmonics. The energy was calibrated with a Mn foil so the first maximum of the derivative spectrum was at 6.539 keV. Spectra in transmission were recorded with ionization chambers filled at 2 bar with a  $N_2$ /He mixture with the appropriate ratio to obtain an absorption of 0.3 in the I0 and 0.7 in I1. Spectra in fluorescence mode were recorded with a silicon Vortex detector placed at 90° with respect to the incident X-ray beam.

EXAFS spectra of the calcined samples were taken integrating 2 s per point until the edge and with a linearly increasing integration time until 10 s per point above the edge. Spectra were sampled with different step depending on the region:  $5\,\text{eV}$  in pre-edge,  $0.5\,\text{eV}$  around the edge,  $0.035\,\text{Å}^{-1}$  above the edge. Each EXAFS spectrum was repeated three times and data averaged to obtain a better signal-to-noise ratio. *In situ* temperature programmed reduction (TPR) experiments were performed from room temperature to  $300\,^{\circ}\text{C}$  at  $2\,^{\circ}\text{Cmin}^{-1}$  under  $5\%\,\text{H}_2/\text{He}$ . XANES spectra were taken at a rate of  $3\,\text{min}$  per spectra (1 s per point, with a step of  $5\,\text{eV}$  in the pre-edge region,  $0.5\,\text{eV}$  in the edge region and  $0.03\,\text{Å}^{-1}$  above the edge).

Spectra normalization was performed with Athena program, part of Demeter package 0.9.21 [29]. With the same program, principle component analyses was performed for each TPR set, finding that all samples can be described by four independent components with an accuracy of 0.9999. The XANES spectra of those components correspond to  $\rm MnO_2,\,Mn_2O_3,\,Mn_3O_4$  and MnO, respectively. Thus, these four spectra were used in a linear combination fitting of the XANES spectra recorded during TPR.

Artemis program, also part of Demeter package 0.9.21 [28], was used for EXAFS analysis. The fitting of  $\chi(k)$  was simultaneously performed in three k-weights  $(\chi(k)\cdot k, \chi(k)\cdot k^2)$  and  $\chi(k)\cdot k^3$ , in order to correctly represent both the light and the heavy atoms. Paths phases and amplitudes were calculated, for all models, with the Feff6 program contained in Artemis. To perform the Fourier transform of the k space a Hanning window from 2.9 to 8.1 Å $^{-1}$  (dk = 1.5 Å $^{-1}$ ) was chosen for all spectra. Appropriate window limits in the R space, where the fit took place, were chosen for each spectrum. The amplitude reduction factor (S $_0$ ) was fixed to the value obtained for the references (0.7  $\pm$  0.1). Manganese ( $\sigma_{Mn}^2$ ) neighbours were fit to the same value for all paths and samples but the mean square displacement of oxygen ( $\sigma_0$ ) was fit independently for each spectra.

### 2.5. DRIFTS

In situ DRIFTS (diffuse reflectance infrared Fourier transform spectroscopy) experiments were carried out using a Bruker Equinox 55 FTIR spectrometer fitted with a mercury–cadmium–telluride (MCT) detector and a DRIFTS cell (Harrick). Prior to each experiment, the catalysts were pretreated at 150  $^{\circ}$ C in a flow of He for 60 min and then, background spectra were recorded. All spectra were acquired at a resolution of 4 cm  $^{-1}$  with 100 scans.

Two types of experiments were carried out, both at  $150\,^{\circ}\text{C}$  and GHSV =  $18,000\,h^{-1}$ . The first experiment began with the adsorption of NO (1000 ppm), followed by the sequential introduction of  $O_2$  (10%) and NH $_3$  (1000 ppm) and then the consecutive removal of NO and  $O_2$ . In the second experiment, adsorption of NH $_3$  was first evaluated, followed by the sequential introduction of NO and  $O_2$  and removal of NH $_3$  and  $O_2$ . Each stage was maintained until no changes in the spectra were observed.

# 3. Results and discussion

# 3.1. Characterization

Chemical composition, BET surface area and total acidity of the catalysts are summarized in Table 1. The chemical composition agrees quite well with the nominal value (5 wt% Mn) and specific surface areas do not vary significantly between catalysts.

Fig. 1 depicts the XRD patterns of the samples. S showed the peaks related to anhydrous sepiolite and other impurities such as calcite, ilite or palygorskite among others. The catalysts containing titania (B-ext, A-ext, T, TS and ST) exhibited the characteristic  $\text{TiO}_2\text{-anatase}$  diffraction peaks (JCPDS 00-021-1272), (Fig. 1a). Some of the sepiolite peaks can be also observed in the catalysts containing 70/30 titania/sepiolite mixtures. Fig. 1b shows a magnification of the diffractograms between 35 and 70°. The main diffraction peaks related to hexagonal  $\text{MnO}_2$  crystalline phase (JCPDS 00-030-0820) were detected only in the A-ext, S and ST samples. No  $\text{MnO}_x$  phase was detected in B-ext, T and TS, what may imply a higher dispersion of the active phase or its presence in amorphous form.

 $\mathrm{NH_3}$  adsorption and activation on the catalyst surface is a key step in  $\mathrm{NH_3}\text{-SCR}$  reaction [30], and this is greatly affected by the number and strength of acid sites. Therefore, the adsorption of  $\mathrm{NH_3}$  on the samples

<span id="page-2-0"></span>**Table 1**Chemical composition, BET surface area and total acidity.

| Catalyst | Mn (%wt) | BET Surface area (m <sup>2</sup> ·g <sup>-1</sup> ) | Total acidity (μmol NH <sub>3</sub> ·g <sup>−1</sup> ) |  |  |
|----------|----------|-----------------------------------------------------|--------------------------------------------------------|--|--|
| B-ext    | 4.7      | 109                                                 | 366                                                    |  |  |
| A-ext    | 4.8      | 106                                                 | 351                                                    |  |  |
| T        | 4.1      | 125                                                 | 636                                                    |  |  |
| S        | 4.1      | 134                                                 | 401                                                    |  |  |
| TS       | 4.5      | 121                                                 | 467                                                    |  |  |
| ST       | 4.0      | 122                                                 | 427                                                    |  |  |
|          |          |                                                     |                                                        |  |  |

<span id="page-2-1"></span>![](_page_2_Figure_13.jpeg)

**Fig. 1.** X-ray diffractograms: a)  $4^{\circ} < 2\Theta < 90^{\circ}$ ; b)  $35^{\circ} < 2\Theta < 70^{\circ}$ .

surface was investigated by  $NH_3$ -TPD analysis. The catalyst with bare  $TiO_2$  (T) has higher total acidity than the catalyst with bare sepiolite (S) (Table 1). When both materials are combined the presence of sepiolite modulates the total acidity; B-ext and A-ext are the samples with the lowest value. Regarding the acid strength, three types of sites are present in all catalysts with higher or lower extent. A peak around 190 °C (weak acid site), a peak around 280 °C (medium acid site) and another peak around 320 °C (strong acid site) (Fig. 2). In S model the peak at 280 °C shifted to higher temperatures, which indicates that these medium acid sites are stronger than in T model. However, the total strength is significantly lower due to the small area of this peak, and especially of the peak at 320 °C that is shifted to high temperatures in model T. Despite the fact that the Mn salt was impregnated on titania in TS and on sepiolite on ST, no significant differences in total acidity and

<span id="page-3-0"></span>![](_page_3_Figure_2.jpeg)

strength were detected between these samples. Both showed a higher contribution of strong acid sites, and then the acidity of these catalysts is the strongest, although its amount is only slightly higher than that of S. B-ext (catalyst impregnated before extrusion) showed a broad band where weak and medium acid sites contribution seems to be slightly higher. In A-ext (catalyst impregnated after extrusion), the presence of weak and medium sites is quite similar to T sample, but the peak related to strong acid sites was not detected. Consequently, sepiolite does not only tune the acidity but its strength. In addition, the preparation method also introduces modifications in the acidic properties since Bext and A-ext catalysts, despite having the same composition, present similar total acidity but their centers has different strength.

# *3.2. Catalytic activity tests*

NH3-SCR catalytic tests were performed in order to evaluate the activity and selectivity of each catalyst. [Fig. 3](#page-3-1) shows the temperature at which the conversion of NOx was 50% (T50) and the corresponding N2 selectivity. The evolutions of NOx conversion and N2O concentration vs. temperature for each catalyst are provided in the supporting information (Figure SI1). The catalyst supported on bare TiO2 (T) showed good activity and selectivity to N2, as expected from the literature [[19](#page-9-13)[,22](#page-9-16)]. When MnOx was deposited on sepiolite (S), the activity was similar to T

<span id="page-3-1"></span>![](_page_3_Figure_6.jpeg)

**Fig. 3.** N2 selectivity at 50% NO conversion and the corresponding temperature (T50) during NH3-SCR. Reaction conditions: 1000 ppm NO, 1000 ppm NH3, 10% O2, GHSV = 18,462 h−1.

<span id="page-3-2"></span>![](_page_3_Figure_8.jpeg)

**Fig. 4.** XANES spectra of B-ext, A-ext, T, and S samples, together with the manganese oxide references. First derivative of B-ext and A-ext XANES spectra is displayed in the inset graph.

(T50 ca. 150 °C), but the selectivity to N2 worsened. When both supports were combined (TS and ST), higher temperatures were needed to achieve 50% of NO conversion. A preferential interaction between MnOx and TiO2 (T and TS) favoured the selectivity to N2 compared to MnOx interacting with sepiolite (S and ST).

In the catalyst synthesized by the impregnation of the pre-shaped titania-sepiolite support, A-ext, the highest activity was achieved (50% conversion at around 130 °C), maintaining a good N2 selectivity (95%). The latter value suggests that MnOx is interacting preferentially with TiO2. The poorer performance of B-ext, with the same composition, indicates that the preparation method is decisive for obtaining an active and selective catalyst.

# *3.3. XAS*

The Mn K-edge XANES spectra of the samples (see [Fig. 4](#page-3-2) for B-ext, A-ext, T, S, and MnOx references, and Figure SI2 for ST and TS) resemble that of MnO2, except for B-ext, in which the contribution of MnIII is appreciable. Nevertheless, it is not possible to assign the XANES features to a specific phase of MnO2.

In order to obtain an overview of their electronic properties, the fresh samples were characterized by *in situ* XANES under reaction conditions (no changes in the XANES spectra were detected) and during temperature-programmed reduction in H2 flow. The evolution of the manganese oxidation state during H2-TPR for each sample is shown in [Fig. 5](#page-4-0). The titania support allows manganese reduction at lower temperature (90 °C) than the sepiolite one (150 °C). The behaviour in ST is close to that of the pure S, pointing out that the late addition of titania has a very limited effect in the electronic properties; the final species is

<span id="page-4-0"></span>![](_page_4_Figure_2.jpeg)

**Fig. 5.** Linear combination fitting of the XANES spectra obtained during temperature programmed hydrogen reduction treatment of the samples[1](#page-4-2) .

a mixture of 2–3 oxidation states. On the contrary, when sepiolite is added to Mn-impregnated titania (TS, B-ext) or is mixed with titania during kneading (A-ext), the reduction temperature decreases for all Mn phases, initial and intermediate, leading to a clear dominance of MnII at final temperatures. Moreover, the participation of MnIII during the reduction process is higher in these cases. Therefore, the deposited Mn species present different electronic properties depending on the nature of the support, being more easily reduced in contact with titania, but affected by the presence of sepiolite.

For the sake of simplicity, only for three selected samples (T, S, and A-ext) the Fourier transform and the fitting of the Mn K-edge EXAFS function are shown in [Fig. 6](#page-4-1) (the results for all the samples can be found in the supporting information, Figures SI3 to SI9); as a representation, Figure SI10 shows the magnitude and real part of each path employed in the fitting of A-ext.

[Table 2](#page-5-0) presents the coordination numbers (N) and effective distances (R) of the paths obtained with the EXAFS refinement for all the samples at room temperature (all the fitting parameters are indicated in figures SI4 to SI9 in the Supporting Information). Relative differences in Mn particle size between samples can be estimated from the number of oxygen atoms in the first coordination shell (O1): S > A-ext > ST > TS > B-ext ≈ T. To give a concrete value, it is necessary to know the specific manganese oxide structure in each sample, as this has a critical effect on its density. The manganese neighbour shells can provide a hint about the order and local structure of the manganese phases. Assuming

<span id="page-4-1"></span>![](_page_4_Figure_8.jpeg)

**Fig. 6.** Fourier transform (k2-weighted) and fitting result of the EXAFS function for S, T and A-ext samples.

that MnOx is in MnO2 form, each manganese atom would be surrounded by six oxygen atoms forming an octahedron. The three-dimensional organization of these octahedrons, which defines the crystallographic structure of the material, would depend on how many oxygen atoms are shared between manganese neighbours (details of different crystal phases of MnO2 can be found elsewhere [\[31](#page-9-25)[,32](#page-9-26)]). A representation of the octahedron organization for hexagonal, tetragonal and orthorhombic structures is displayed in Figure SI11 of the Supporting Information. When three oxygen atoms are shared between two

<span id="page-4-2"></span><sup>1</sup> For TS, it was not possible to fit the last spectra of the process due to their poor quality.

<span id="page-5-0"></span>**Table 2** Atom number (N) and effective distance (R) obtained by deconvolution of the Fourier transform of the EXAFS functions of the samples. The numbers between parentheses are the error of the last digit. For comparison, the values for the hexagonal (HX), tetrahedral (TH) and orthorhombic (OR) structures of MnO2 (space group symmetry P63/mmc, P42/mnm and Pnma, respectively; CIF files taken from ICSD-FIZ Karlsruhe) are also shown.

| Catalysts | O1     |          | Mn1    |         | Mn2    |         | Mn3    |         |
|-----------|--------|----------|--------|---------|--------|---------|--------|---------|
|           | N      | R        | N      | R       | N      | R       | N      | R       |
| S         | 5.9(8) | 1.89(1)  | 2(1)   | 2.45(7) | 2(2)   | 3.0(1)  | 7(3)   | 3.43(4) |
| ST        | 5.2(2) | 1.905(3) | 1.5(3) | 2.37(1) | 2.3(5) | 2.97(2) | 7.0(7) | 3.44(1) |
| T         | 4.0(2) | 1.888(5) | 1.8(4) | 2.53(2) | 2.3(6) | 2.96(3) | 2.9(8) | 3.41(3) |
| TS        | 4.3(3) | 1.881(6) | 2.1(6) | 2.53(2) | 4(1)   | 2.97(3) | 3(1)   | 3.38(4) |
| B-ext     | 3.8(2) | 1.930(5) | 1.5(2) | 2.38(1) | 2.1(4) | 3.04(2) | 3.4(8) | 3.86(2) |
| A-ext     | 5.3(4) | 1.905(6) | 2.1(5) | 2.37(2) | 2.9(9) | 2.99(3) | 6(1)   | 3.43(2) |
| MnO2 HX   | 6      | 1.950    | 2      | 2.206   | 6      | 2.786   | 12     | 3.554   |
| MnO2 TH   | 6      | 1.886    | –      | –       | 2      | 2.873   | 8      | 3.426   |
| MnO2 OR   | 6      | 1.899    | –      | –       | 4      | 2.864   | 4      | 3.443   |

manganese atoms (Mn1), the Mn-Mn distance is close to 2.2 Å, when two oxygen atoms are shared (Mn2), the Mn-Mn distance is around 2.8–3.0 Å, and when only one oxygen atom is shared (Mn3) the distance is around 3.4–3.6 Å.

The presence of the Mn1 shell around 2.4 Å corroborates the assignment of manganese particles to the hexagonal phase, in good correspondence with XRD [\(Fig. 1\)](#page-2-1) results, as this shell is absent in the other structures. However, the higher Mn-Mn1 distance with respect to the hexagonal MnO2 bulk reference indicates a significant elongation of the c axis in the samples with respect to the hexagonal MnO2 bulk [\(Table 2](#page-5-0) and Figure SI12). This elongation is slightly higher in T and TS. Therefore, although all the samples presented manganese phases with hexagonal structure, their interaction with the different components (titania or sepiolite) introduces dislocations or structural modifications on those Mn entities. Considering that manganese adopts this configuration, it is possible to estimate the size of manganese particles as the diameter of the particle that contains enough atoms to give the correct number of the first oxygen neighbours, which is 56 nm in S; 11 nm in Aext; 9 nm in ST; 4 in TS; and 3 nm in B-ext and T. Even when a mixture of Mn2O3-MnO2 phases (around 50% according to the XANES spectra) is considered for B-ext, its particle size of B-ext is still around 3 nm. Additionally, although the high errors obtained in the Mn3 neighbours require a careful manipulation to avoid over-analysis, the higher numbers obtained in S and ST corroborate the higher particle size of manganese in those catalysts with respect to the other samples.

# *3.4. DRIFTS*

In order to identify how the different species of interest in NH3-SCR of NO are chemisorbed on the surface, whether the adsorption is competitive, which the reactive species are and the role of each component of the samples, two *in situ* experiments were carried out with DRIFT spectroscopy. B-ext, A-ext and T and S models were exposed to mixtures of the specific gases at relevant reaction concentrations, starting with a single component and then incorporating and removing reagents gradually.

# *3.4.1. Experiment 1*

The spectra of the first *in situ* DRIFTS experiment, consisting on the pre-adsorption of NO followed by the sequential introduction of O2 and NH3 and then the consecutive removal of NO and O2, are shown in [Fig. 7.](#page-6-0)

**During NO adsorption,** the samples containing titania (T, B-ext and A-ext) showed a broad band centered around 3200 cm−1, which probably indicates the presence of NeOH groups [\[33](#page-9-27)]. In addition, T sample showed a band at 1340 cm−1 and a low-intensity band at 1640 cm−1, which can be ascribed to monodentate nitrites and adsorbed NO2, respectively [\[34](#page-9-28)]. This adsorption is promoted by the presence of MnO2, since almost no adsorption was observed on the bare titania support (Figure S13). The presence of adsorbed NO2 points out the capability of the surface to oxidize NO. In S sample two bands appeared, at 1535 and 1300 cm-1, which may be assigned to nitrates species. B-ext and A-ext showed two low-intensity similar bands related to nitrites/nitrates species.

**When O2 was also fed,** new hydroxyl-related bands (3760- 3390 cm−1) appeared in T model, and in a lesser extent in B-ext and Aext. These bands may be associated to water that evolved after the interaction between superficial basic hydroxyls and NO2 (produced as a consequence of NO oxidation) [[35\]](#page-9-29). The bands related to nitrites/nitrates did not increase in S, indicating that MnO2 supported over sepiolite has poor NOx adsorption capacity even in the presence of oxygen, but they increased considerably in the samples containing titania. Three IR absorption zones can be observed in T model: one ascribed to symmetric stretching of nitrates species (bridge: 1605 cm−1, bidentate: 1583 cm−1 and monodentate: 1550 cm−1); a second zone attributed to symmetric and asymmetric stretching of nitrites (monodentate: 1370 and 1340 cm−1) and a third area ascribed to asymmetric stretching of nitrates (bridge: 1224 cm−1, bidentate: 1275 cm−1 and monodentate: 1248 cm−1). The profile of the nitrite/nitrate related bands was similar in B-ext and A-ext, with two broad features: again a band between 1685 and 1440 cm−1 associated to the symmetric stretching of nitrates (bridge, bidentate and monodentate); and a band between 1415 and 1200 cm−1 containing both related to the symmetric and asymmetric stretching of monodentate nitrites and the asymmetric stretching of nitrates (bridge, bidentate and monodentate). The intensity of the peaks is higher in B-ext than in A-ext, indicating a higher potential for nitratres/nitrites formation, though it is lower than in the catalyst supported over bare TiO2 (T), which corroborates that sepiolite presence reduces NOx adsorption.

A detailed exploration of the time-resolved spectra (Figure SI14) provides information about the temporal evolution of the bands assigned to the different adsorbed NOx species: In T sample the band at 1370 and a shoulder at 1340 cm−1 (monodentate nitrites), and that at 1630 cm−1 (adsorbed NO2) increased for the first 50 min. The new bands between 1235 and 1290 cm−1 (asymmetric stretching of nitrates species) appeared from the beginning, while those at 1580 cm−1 (bidentate nitrate), 1550 cm−1 (monodentate nitrates), 1605 cm−1 (bridge nitrates) appeared after 10, 25 and 80 min, respectively. The evolution of B-ext and A-ext was similar to that of T: the band of adsorbed NO2 increased in the first 20 min for B-ext and 10 min for A-ext, the band of bridge nitrates appeared after 50 and 35 min for B-ext and A-ext, respectively, and the band assigned to bidentate nitrates after 20 and 25 min. The band between 1560 and 1440 cm−1 emerged after 20 and 10 min for B-ext and A-ext, respectively.

**When ammonia was introduced,** that is, in SCR conditions, no significant changes in nitrites/nitrates related bands were detected in sample S. Thus, a broad low-intensity band envisaged around 1720 cm−1 may be related to NH4 <sup>+</sup> adsorbed over Brønsted sites

<span id="page-6-0"></span>![](_page_6_Figure_2.jpeg)

Fig. 7. In situ DRIFTS spectra of T, S, B-ext, and A-ext during experiment 1. Sequence: 1) NO, 2) NO +  $O_2$  +  $O_2$  +  $O_3$  NO +  $O_4$  +  $O_3$  +  $O_4$  +  $O_3$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_4$  +  $O_$ 

[36–38]. The growth of a positive peak at  $1640 \,\mathrm{cm}^{-1}$  suggests the consumption of initial surface species such as HO- groups from sepiolite or undissociated water [39]. A strong consumption of hydroxyls was also observed at 3760-3390 cm<sup>-1</sup>. Conversely, in T model some of the pre-adsorbed NOx species almost disappeared (NO2, bridge nitrates and monodentate nitrites), which indicates that the reactivity of the bound NOx species is different. Two new bands emerged at 1690 and 1480 cm <sup>1</sup> upon adsorption of NH<sub>3</sub>. These, as it will be shown later, are shifted and more intense than the ones observed in experiment 2 upon adsorption of NH<sub>3</sub> on a clean surface (without pre-adsorbed NO + O<sub>2</sub>). Therefore, taking this into account and the concomitant disappearance of NOx species, the bands here may be related to the formation of NH<sub>4</sub><sup>+</sup>-NO<sub>y</sub>- complexes by ammonia reaction with pre-adsorbed NOx species. The bands at 3760-3390 cm<sup>-1</sup> formed during co-adsorption of NO + O<sub>2</sub> evolved with time from negative to positive features. This indicates a high consumption of hydroxyl groups, probably due to the reaction of some nitrites and nitrates, and also to the interaction of NH3 with the HO- groups to form NH<sub>4</sub>+. Besides, a positive band related to carboxylates grew at 1330 cm<sup>-1</sup> [40], as in pure TiO<sub>2</sub> (Figure SI13 in the Supporting Information), suggesting the elimination of those species from the support surface by reaction with ammonia. B-ext and Aext showed a similar behavior to T model but with lower consumption of NOx species (mainly nitrites).

Figure SI15 in the Supporting Information shows the time evolution of nitrate/nitrite bands during exposition to  $NO + O_2 + NH_3$ . In T, B-ext, and A-ext the proportion of symmetric and asymmetric components of nitrites is modified. This may be related to the emergence of a new band at  $1360\,\mathrm{cm}^{-1}$  ascribed to nitrite species formed by  $NO_2$  and bridge nitrates reduction with ammonia [41,42]. The reactivity of

ammonia with pre-adsorbed  $\mathrm{NO_x}$  species suggests a Langmuir-Hinselwood mechanism, where  $\mathrm{NO_x}$  and  $\mathrm{NH_3}$  adsorbed on different active sites

When  $O_2$  and NO were removed from the gas feed no significant spectral changes were appreciated, indicating than there is no release of available centers for  $NH_3$  adsorption due to the high stability of the remaining chemisorbed species.

# 3.4.2. Experiment 2

The results of the second experiment, consisting on the pre-adsorption of  $NH_3$ , followed by the sequential introduction of NO and  $O_2$  and then the consecutive removal of  $NH_3$  and  $O_2$ , are shown in Fig. 8.

**During NH**<sub>3</sub> **adsorption** on T model, a main band around 1595 cm  $^{-1}$  was ascribed to the asymmetric deformation of coordinated NH<sub>3</sub> in Lewis acid sites [43,44]. The corresponding symmetric deformation mode that should appear around 1260 cm  $^{-1}$  may be overlapping with the positive band around 1330 cm  $^{-1}$  attributed to superficial carboxylates consumption. Another low-intensity band at 1730 cm  $^{-1}$  corresponds to the symmetric bending of NH<sub>4</sub>  $^+$  on Brønsted acid sites. Again, the carboxylate band masks its asymmetric counterpart. Brønsted acidity is provided by manganese oxide, since no band ascribed to NH<sub>4</sub>  $^+$  was observed with the bare titania support (Figure SI13 in the Supporting Information), in agreement with the literature [45]. As it was commented in experiment 1, all these bands are less intense and appear at different wavelengths than those observed in samples with pre-adsorbed NO + O<sub>2</sub>.

Conversely, in S model, the different nature and reactivity of the surface allows to visualize the intense band at  $1258\,\mathrm{cm}^{-1}$  related to the symmetric deformation of coordinated NH $_3$  adsorbed on Lewis acid

<span id="page-7-0"></span>![](_page_7_Figure_2.jpeg)

Fig. 8. In situ DRIFTS spectra of T, S, B-ext and A-ext during experiment 2. Sequence: 1)  $NH_3$ , 2)  $NH_3$  + NO, 3)  $NH_3$  + NO +  $O_2$ , 4) NO +  $O_2$ , and 5) NO. Conditions:  $[NO] = [NH_3] = 1000$  ppm,  $[O_2] = 10\%$ , balance = He, T = 150 °C and GHSV = 18,000 h<sup>-1</sup>.

sites, but not the asymmetric counterpart, which overlaps with the positive band around 1640 cm $^{-1}$  related to the consumption of surface OH groups and/or non-dissociated water. As in T model, a low-intensity band ascribed to  $\rm NH_4^{\phantom{0}+}$  on Brønsted acid sites is envisaged at  $1730~\rm cm^{-1}$ . In B-ext and A-ext, the bands related to coordinated  $\rm NH_3$  on Lewis acid sites and  $\rm NH_4^{\phantom{0}+}$  on Brønsted acid sites were also observed, although for A-ext to a much lower extent. The positive feature at  $1640~\rm cm^{-1}$  was present as well in B-ext.

Upon NH $_3$  adsorption, all samples showed a positive contribution between 3760 and 3410 cm $^{-1}$  due to the consumption of hydroxyl groups, and also bands at 3410-3000 cm $^{-1}$  assignable to –NH groups and new hydroxyls formation were detected. The shift to higher frequencies in T and B-ext of the bands related to Brønsted sites can be explained by stronger H-bonds due to a high probability of proton donation from NH $_4$  $^+$ .

When NO was introduced to the feed, no significant changes in the NH<sub>3</sub> adsorbed species were detected in S, B-ext and A-ext. However, in T model the bands ascribed to coordinated NH<sub>3</sub> adsorbed on Lewis acid sites decreased, while those related to NH<sub>4</sub> <sup>+</sup> on Brønsted acid sites remained constant. No nitrates/nitrites were found in any sample.

When  $O_2$  was added to the feed, that is, SCR conditions, almost no changes in the bands related to derived NH $_3$  species were detected in samples T, B-ext and A-ext. However, MS spectra showed a consumption of NO $_x$  and NH $_3$  (Figure S16), what may indicate that the SCR reaction is proceeding via Elay-Riedel mechanism.

In T sample, when  $NH_3$  was removed from the feed, the band ascribed to  $NH_4^+$  on Brønsted acid sites disappeared. In addition, all the positive bands vanished due to overlapping with the new rising

bands. As in the co-adsorption of NO +  $\rm O_2$  in experiment 1, new hydroxyl bands appeared. These bands may be related to water that evolved after the interaction between superficial basic hydroxyls and NO<sub>2</sub> (produced from NO oxidation) after ammonia desorption. Nitrates/nitrites species adsorbed over the samples are very similar to those detailed in experiment 1. In all samples, the evolution of nitrite/nitrate species (Figure SI17) was similar to that detailed in experiment 1 (Figure SI14). The results suggest that the adsorption of NH<sub>3</sub> and NO<sub>x</sub> is competitive, since only when coordinated NH<sub>3</sub> species desorb NO<sub>x</sub> species can adsorb. In experiment 1 it was concluded that NOx and NH<sub>3</sub> adsorbed on different sites, since ammonia was able to react with adsorbed NOx species. Then, it seems that pre-adsorbed ammonia fills all the active sites, hindering NOx adsorption. However, pre-adsorbed NO only interacts with one type of centers (probably Brønsted sites), and then the Lewis centers are still available for NH<sub>3</sub> adsorption.

When  $O_2$  is also removed from the feed, no significant changes were observed in S and B-ext. However, a decrease in the bands related to  $NO_x$  adsorbed species (adsorbed  $NO_2$ , bridge nitrates and monodentate nitrites) was detected in T and A-ext confirming its higher lability.

# 4. Discussion

The synthesis method and the components of the support greatly influence the physicochemical properties of the Mn-based monolithic systems, and therefore their catalytic performance in the selective reduction of  $NO_x$  with  $NH_3$ . The **active phase** of the samples is hexagonal  $MnO_2$  (Fig. 1), except for B-ext, where mixtures of Mn (IV) and Mn (III)

oxides were formed. In this case, a reductive atmosphere was generated by the carbonaceous PGA elimination during the calcination step [46] and led to the partial reduction of the  $\mathrm{Mn^{4}}^+$  species in B-ext. The detection of the  $\mathrm{MnO_2}$  diffraction peaks only in S, ST, and A-ext is in agreement with the size of manganese particles calculated from XAS data, which was significantly higher in these samples, especially in the one where titania was not present. Therefore, titania interaction favours a better dispersion of the Mn species.

The interactions between  $MnO_x$  and the components of the support introduce structural dislocations and determine the **electronic properties of the Mn species**. The temperature needed to reduce the  $MnO_2$  is lower when it is supported on  $TiO_2$  than on sepiolite (Fig. 5), and when both titania and sepiolite are present the reduction profile depends on the interaction between both components and their interplay with  $MnO_2$ : TS and A-ext, where Mn species interact predominately with  $TiO_2$ , are reduced even at lower temperature than T, while ST is reduced at higher temperatures than S. According to the literature, easily reducible centers are needed for the selective reduction of  $NO_x$  with  $NH_3$  [22,23]. Then, the more difficult reducibility of ST corresponds to a worse performance of the sample (Fig. 3).

The active phase-support interaction also influences the **acidity**. According to  $NH_3$ -TPD (Fig. 2), the highest and strongest (Lewis) acidity is detected in the  $TiO_2$ -supported catalyst (T), and the presence of sepiolite modifies the acid properties in a way that depends on the synthesis method: while TS and ST showed few but very strong acid sites, in A-ext those strongest acid sites are not present (Figs. 2 and 8).

The aforementioned properties determine the adsorption behaviour of the samples, which is key to the catalytic activity. The results indicate, that there is an inverse correlation between acidity and **catalytic activity**, because catalysts with strong acid centers (TS and ST) showed higher  $T_{50}$  compared to catalysts without those strong centers (A-ext). In agreement with our result, several works have showed that NH<sub>3</sub> adsorbed on strong acid sites cannot react with NO<sub>x</sub>. Nova *et al* [47] found that strong and excessive adsorption of NH<sub>3</sub> could inhibit the catalyst performance at lower temperatures because this may block the activation of NO. Tronconi *et al* [48] also reported an ammonia blocking effect when ammonia and nitrate species are present in the catalyst surface, which was associated to a strong interaction between them.

The surface adsorbed species identified in the *in situ* DRIFTS experiments explain the reaction mechanism and the different **adsorption properties**, and thus performance, of the catalysts. **NO uptake** takes place only when both  $O_2$  is present in the feed and  $MnO_x$  in the sample, indicative of the  $MnO_x$  promoter effect on NO oxidation and consecutive nitrites and nitrates formation.  $NO_x$  adsorption is higher when  $MnO_x$  interacts preferably with  $TiO_2$  than when it interacts with sepiolite. The surface  $NO_x$  species are also of different nature: while in the  $TiO_2$ -supported catalyst nitrates and nitrites were detected, in the sepiolite-supported one only nitrates appear. When both components are mixed the presence of sepiolite has a great influence on the  $NO_x$  adsorption properties of the catalysts. On the one hand, it moderates the  $NO_x$  species adsorption capacity compared to bare  $TiO_2$ , and on the other hand, the formation of nitrates increases (although both species were found).

 $NH_3$  can adsorb on both Lewis and Brønsted acid sites (Fig. 8). On one hand, when  $NO_x$  is adsorbed first (on Brønsted sites),  $NH_3$  can only adsorb onto Lewis sites to react with the adsorbed  $NO_x$  species. (via Langmuir-Hinselwood mechanism). However, the reactivity when  $NH_3$  adsorbed in Brønsted centers is favoured due to the lower adsorption strength. Therefore, the blocking of these sites by  $NO_x$  may hinder the catalytic performance. On the other hand, if  $NH_3$  adsorbed first, it covers all the active sites (Brønsted and Lewis) and blocks the adsorption of  $NO_x$  species. However, MS spectra showed certain consumption of  $NO_x$  and  $NH_3$  (Figure S16) which suggests that  $NO/NO_2$  still react with adsorbed  $NH_3$  via Elay-Rideal mechanism.

NO2, monodentate nitrites and bridge nitrates are the reactive

species, as they are consumed in the presence of  $NH_3$ , forming new  $NH_4^+$ - $NO_x^-$  intermediate species. The nature of these complexes determines the selectivity to  $N_2$ . While  $NH_4^+NO_2^-$  intermediate generated from nitrites produces  $N_2$  when it is decomposed (Eq. (1)),  $NH_4^+NO_3^-$  originating form nitrates leads to  $N_2O$  formation (Eq. (2)) [34,40,49].

<span id="page-8-0"></span>
$$NH_4^+NO_2^- \to N_2 + 2H_2O$$
 (1)

<span id="page-8-1"></span>
$$NH_4^+NO_3^- \to N_2O + 2H_2O$$
 (2)

When  $MnO_x$  is interacting with  $TiO_2$  (T, B-ext, and A-ext)  $NH_4^+NO_2^-$  intermediate is preferably formed, and thus higher selectivity to  $N_2$  is obtained. When  $MnO_x$  interacts with sepiolite,  $NH_4^+NO_3^-$  complex is formed to a higher extent, leading to more  $N_2O$  generation. T and B-ext were the samples with higher formation of  $NH_4^+-NO_x^-$  intermediates, related to high NOx adsorption. However, these species are strongly adsorbed, and therefore higher temperatures were needed to decompose them.

A-ext is more active than B-ext, although they present the same composition (Fig. 3). Therefore, the synthesis procedure strongly modifies the materials properties and, consequently, also their catalytic performance is affected. Similar  $\mathrm{NO}_x$  species were formed on the surface of B-ext and A-ext. However, while the better reducibility of Mn species in B-ext (Fig. 5) led to a higher formation of nitrites/nitrates, these species were less strongly bound in A-ext, due to the weaker acidity of this material. Therefore, they require lower temperatures to desorb and react, and to release active centers capable to further activate  $\mathrm{NH}_3$ . In addition, the weaker  $\mathrm{NH}_3$  adsorption on A-ext favours a higher interaction between the reactants.

## 5. Conclusions

In this work, two shaped catalyst for industrial application were prepared by two different methods, using sepiolite as binder. Although both catalysts have the same chemical composition, the nature of the samples is quite different. When the catalytic body was prepared by MnO<sub>x</sub> impregnation after extrusion of a titania support using sepiolite as binder (A-ext) the catalytic activity was high maintaining a good selectivity to N2. However, when the catalytic body was prepared by MnO<sub>x</sub> impregnation of titania and then extruded with the binder and the PGA, catalytic activity decrease although the selectivity to N2 was good. The active phase of A-ext was MnO2, while a mixture of Mn (IV) and Mn (III) oxides was found in B-ext. In both cases, MnOx interacts preferentially with TiO<sub>2</sub>. The better performance of A-ext in the selective reduction of NO with NH3 may be linked to its lower Lewis acidity and the higher reactivity of the adsorbed NO<sub>x</sub> species. These facts drive to better T50, since lower temperatures are needed to dissociate the ammonia-nitrate complexes.

Four models were also synthetized in order to discriminate between the interactions of the manganese oxides with the different components of the support and elucidate the role of the clay in the catalytic and structural properties of the samples. The study concludes that:

- MnO<sub>x</sub> species are responsible for NO activation through nitrates/ nitrite species formation.
- The nature of these active species and their interaction with the support components are determined by the synthesis method and strongly affect their properties
- Titania helps dispersing Mn species and provides the supported sample with greater acidity and NO<sub>x</sub> adsorption capacity than sepiolite.
- Sepiolite can be used as binder to obtain  $MnO_x$ /titania monoliths; it modulates both the acidity of the catalyst and the Mn reducibility, and therefore modifies the  $NO_x$  formation, the adsorption capacity and the strength of the adsorbed species.
- MnO<sub>2</sub> reducibility is favoured when this active phase interacts with

- $TiO_2$  instead of sepiolite, and this is associated to a higher catalytic activity for the selective catalytic reduction of  $NO_x$  with  $NH_3$ .
- The presence of strong acid sites (Lewis acidity) is detrimental for the catalytic activity at low temperature
- A higher selectivity to  $N_2$  is linked to the formation of nitrites upon NO adsorption (favoured when  $MnO_x$  interacts with  $TiO_2$ ) because  $NH_4^{\phantom{A}}NO_2^{\phantom{A}}$  are generated as intermediates, producing  $N_2$  after their decomposition. However, the formation of  $NH_4^{\phantom{A}}NO_3^{\phantom{A}}$  complexes (favoured by sepiolite) leads to  $N_2O$  generation, decreasing the selectivity.

### Acknowledgements

Financial support from the Spanish Government (LTNOx, CTQ2014-57578-R; RIEN2O, CTQ2017-82335-R), and "Comunidad de Madrid" and European Structural Funds (ACES2030, S2018/EMT-4319) is gratefully acknowledged. The authors thank Professor A. Martínez-Arias from Instituto de Catálisis y Petroleoquímica (CSIC) for lending us the Bruker Equinox 55 FTIR spectrometer for performing DRIFTS studies. We thank the ESRF for access to the facilities (BM23) and we would also like to thank Debora Meira for her help during the XAS experiments.

# Appendix A. Supplementary data

Supplementary material related to this article can be found, in the online version, at doi:https://doi.org/10.1016/j.apcatb.2019.117821.

#### References

- <span id="page-9-0"></span> European Environment Agency, Air Quality in Europe, 2016 Report, Denmark (2016).
- <span id="page-9-1"></span>[2] C. Liu, J.-W. Shi, C. Gao, C. Niu, Manganese oxide-based catalysts for low-temperature selective catalytic reduction of NO<sub>x</sub> with NH<sub>3</sub>: a review, Appl. Catal. A Gen. 522 (2016) 54–69.
- <span id="page-9-2"></span>[3] J. Fan, M. Lv, W. Luo, X. Ran, Y. Deng, W.-X. Zhang, J. Yang, Exposed metal oxide active sites on mesoporous titania channels: a promising design for low-temperature selective catalytic reduction of NO with NH<sub>3</sub>, Chem. Commun. 54 (2018) 3783–3786.
- <span id="page-9-3"></span>[4] Intergovernmental Panel on Climate Change [IPCC], Climate Change 2014: Synthesis Report. Fifth Assessment Report, Switzerland, (2014).
- <span id="page-9-4"></span>[5] Drawing Down N<sub>2</sub>O To Protect Climate and the Ozone Layer. A UNEP Synthesis Report, (2013) ISBN: 978-92-807-3358-7.
- <span id="page-9-5"></span>[6] J. Blanco; P. Avila; A. Bahamonde; C. Chacon; J.M. Ramos; Catalytic systems for the selective catalytic reduction of nitrogen oxides at high temperature. SP Patent ES2140268B1, September 16, 1999.
- [7] J. Due-Hansen, S.B. Rasmussen, E. Mikolajska, M.A. Bañares, P. Ávila, R. Fehrmann, Redox behaviour of vanadium during hydrogen–oxygen exposure of the V<sub>2</sub>O<sub>5</sub>-WO<sub>3</sub>/ TiO<sub>2</sub> SCR catalyst at 250°C, Appl. Catal. B 107 (2011) 340–346.
- [8] F.J.J.G. Janssen, F. Van den Kerkhof, H. Bosch, J.R.H. Ross, Mechanism of the reaction of nitric oxide, ammonia, and oxygen over vanadia catalysts. 1. The role of oxygen studied by way of isotopic transients under dilute conditions, J. Phys. Chem. 91 (1987) 5921–5927.
- <span id="page-9-6"></span>[9] A. Uddin, K. Shimizu, K. Ishibe, E. Sasaoka, Characteristics of the low temperature SCR of  $NO_x$  with  $NH_3$  over  $TiO_2$ , J. Mol. Catal. A 309 (2009) 178–183.
- <span id="page-9-7"></span>[10] M. Kang, D.J. Kim, E.D. Park, J.M. Kim, J.E. Yie, S.H. Kim, L. Hope-Weeks, E.M. Eyring, Two-stage catalyst system for selective catalytic reduction of NO<sub>x</sub> by NH<sub>3</sub> at low temperatures, Appl. Catal. B 68 (2006) 21–27.
- <span id="page-9-8"></span>[11] H. Schneider, M. Maciejewsk, K. Köhler, A. Wokaun, A. Baiker, Chromia supported on titania: VI. Properties of different chromium oxide phases in the catalytic reduction of NO by NH<sub>3</sub> studied by in situ diffuse reflectance FTIR spectroscopy, J. Catal. 157 (1995) 312–320.
- <span id="page-9-9"></span>[12] F. Liu, H. He, C. Zhang, Z. Feng, L. Zheng, Y. Xie, T. Hu, Selective catalytic reduction of NO with NH<sub>3</sub> over iron titanate catalyst: catalytic performance and characterization, Appl. Catal. B 96 (2010) 408–420.
- <span id="page-9-10"></span>[13] M.J. Lazaro, M.E. Galvez, C. Ruiz, R. Juan, R. Moliner, Vanadium loaded carbon-based catalysts for the reduction of nitric oxide, Appl. Catal. B 68 (2006) 130–138.
- <span id="page-9-11"></span>[14] T. Boningari, R. Koirala, P.G. Smirniotis, Low-temperature catalytic reduction of NO by NH<sub>3</sub> over vanadia-based nanoparticles prepared by flame-assisted spraypyrolysis: influence of various supports, Appl. Catal. B 140 – 141 (2013) 289–298.
- <span id="page-9-12"></span>[15] A. Grossale, I. Nova, E. Tronconi, Study of a Fe-zeolite-based system as NH<sub>3</sub>-SCR catalyst for diesel exhaust after treatment, Catal. Today 136 (1-2) (2008) 18–27.
- [16] J.H. Kwak, R.G. Tonkyn, D.H. Kim, J. Szanyi, C.H.F. Peden, Excellent activity and selectivity of Cu-SSZ-13 in the selective catalytic reduction of NO<sub>x</sub> with NH<sub>3</sub>, J. Catal. 275 (2010) 187–190.
- [17] J. E. Collier; P. Diddams; D. Duran-Martin; X. Mo; R. R. Rajaram. SCR catalysts

- having improved low temperature performance, and methods of making and using the same. Patent WO 2015128668 A1.
- [18] P.R. Ettireddy, P. R.; A.J. Kotrba; T.L. Spinks; T. Boningari; P.G. Smirniotis. Exhaust after-treatment system having low temperature SCR catalyst. Patent WO 2016018778 A1.
- <span id="page-9-13"></span>[19] I. Cayirtepe, A. Naydenov, G. Ivanov, M. Kantcheva, Characterization of niobium-zirconium mixed oxide as a novel catalyst for selective catalytic reduction of NO<sub>x</sub>, Catal. Lett. 132 (2009) 438–449.
- <span id="page-9-14"></span>[20] E.P. Reddy, N. Ettireddy, S. Mamedov, P. Boolchand, P.G. Smirniotis, Surface characterization studies of TiO<sub>2</sub> supported manganese oxide catalysts for low temperature SCR of NO with NH<sub>3</sub>, Appl. Catal. B 76 (2007) 123–134.
- <span id="page-9-15"></span>[21] T. Boningari, P.G. Smirniotis, Impact of nitrogen oxides on the environment and human health: Mn-based materials for the NOx abatement, Curr. Opin. Chem. Eng. 13 (2016) 133–141.
- <span id="page-9-16"></span>[22] S.R. Putluru, L. Schill, A.D. Jensen, B. Siret, F. Tabaries, R. Fehrmann, Mn/TiO<sub>2</sub> and Mn–Fe/TiO<sub>2</sub> catalysts synthesized by deposition precipitation—promising for selective catalytic reduction of NO with NH<sub>3</sub> at low temperatures, Appl. Catal. B 165 (2015) 628–635.
- <span id="page-9-17"></span>[23] P.G. Smirniotis, P.M. Sreekanth, D.A. Peña, R.G. Jenkins, Manganese oxide catalysts supported on TiO<sub>2</sub>, Al<sub>2</sub>O<sub>3</sub>, and SiO<sub>2</sub>: a comparison for low-temperature SCR of NO with NH<sub>3</sub>, Ind. Eng. Chem. Res. 45 (19) (2006) 6436–6443.
- <span id="page-9-18"></span>[24] S. Deng, T. Meng, B. Xu, F. Gao, Y. Ding, L. Yu, Y. Fan, Advanced  $MnO_x/TiO_2$ Catalyst with preferentially exposed Anatase {001} facet for low-temperature SCR of NO, ACS Catal. 6 (2016) 5807–5815.
- <span id="page-9-19"></span>[25] V.G. Milt, E.D. Banus, E.E. Miro, M. Yates, J.C. Martin, S.B. Rasmussen, P. Avila, Structured catalysts containing Co, Ba and K supported on modified natural sepiolite for the abatement of diesel exhaust pollutants, Chem. Eng. J. 157 (2010) 530–538.
- <span id="page-9-20"></span>[26] R. Portela, I. Jansson, S. Suarez, M. Villarroel, B. Sanchez, P. Avila, Natural silicate-TiO<sub>2</sub> hybrids for photocatalytic oxidation of formaldehyde in gas phase, Chem. Eng. J. 310 (2017) 560–570.
- <span id="page-9-21"></span>[27] S. Suarez, M. Yates, P. Avila, J. Blanco, New TiO<sub>2</sub> monolithic supports based on the improvement of the porosity, Catal. Today 105 (2005) 499–506.
- <span id="page-9-22"></span>[28] O. Mathon, A. Beteva, J. Borrel, D. Bugnazet, S. Gatla, et al., The time-resolved and extreme conditions XAS [TEXAS] facility at the European Synchrotron Radiation Facility: the general-purpose EXAFS bending-magnet beamline BM23, J. Synchrotron Radiat. 22 (2015) 1548–1554.
- <span id="page-9-23"></span>[29] B. Ravel, M. Newville, Athena, artemis, hephaestus: data analysis for X-ray absorption spectroscopy using IFEFFIT, J. Synchrotron Radiat. 12 (2005) 537–541.
- <span id="page-9-24"></span>[30] N.Y. Topsøe, Mechanism of the selective catalytic reduction of nitric oxide by ammonia elucidated by in situ on-line fourier transform infrared spectroscopy, Science 265 (1994) 1217–1219.
- <span id="page-9-25"></span>[31] S.J.A. Figueroa, F.G. Requejo, E.J. Lede, L. Lamaita, M.A. Peluso, J.E. Sambeth, XANES study of electronic and structural nature of Mn-sites in manganese oxides with catalytic properties, Catal. Today 107–108 (2005) 849–855.
- <span id="page-9-26"></span>[32] K.-W. Nam, M.G. Kim, K.-B. Kim, In situ Mn K-edge X-ray absorption spectroscopy studies of electrodeposited manganese oxide films for electrochemical capacitors, J. Phys. Chem. C 111 (2007) 749–758.
- <span id="page-9-27"></span>[33] K. Hadjivanov, V. Buschev, M. Kantcheva, D. Klissurski, Infrared spectroscopy study of the species arising during nitrogen dioxide adsorption on titania [anatase], Langmuir 10-12 (1994) 464–471.
- <span id="page-9-28"></span>[34] A. Davydov, N.T. Sheppard (Ed.), Molecular Spectroscopy of Oxide Catalyst Surfaces, Wiley, Chichester, 2003.
- <span id="page-9-29"></span>[35] V. Bushev, K. Hadjiivanov, M. Kantcheva, D. Klissurski, An IR spectroscopic study of NO<sub>2</sub>-NH<sub>3</sub> interaction on TiO<sub>2</sub> [Anatase], Z. Phys. Chem. [Leipzig] 173 (1991) 217–223.
- <span id="page-9-30"></span>[36] R. Jin, Y. Liu, Y. Wang, W. Cen, Z. Wu, H. Wang, X. Weng, The role of cerium in the improved SO<sub>2</sub> tolerance for NO reduction with NH<sub>3</sub> over Mn-Ce/TiO<sub>2</sub> catalyst at low temperature, Appl. Catal. B 148–149 (2014) 582–588.
- [37] D.A. Pena, B.S. Uphade, E.P. Reddy, P.G. Smirniotis, Identification of suface species on titania-supported manganese, chromium, and copper oxide low temperature SCR catalysts, J. Phys. Chem. B 108 (2004) 9927–9936.
- [38] L. Qiu, D. Pang, C. Zhang, J. Meng, R. Zhu, F. Ouyang, In situ IR studies of Co and Ce doped Mn/TiO<sub>2</sub> catalyst for low-temperature selective catalytic reduction of NO with NH<sub>3</sub>, Appl. Surf. Sci. 357 (2015) 189–196.
- <span id="page-9-31"></span>[39] M.A. Vicente-Rodriguez, M. Suarez, M.A. Bañares-Muñoz, J. Lopez-Gonzalez, Comparative FT-IR study of the removal of octahedral cations and structural modifications during acid treatment of several silicates, Spectrochim. Acta A. 52 (1996) 1685–1694.
- <span id="page-9-32"></span>[40] A.U. Baes, P.R. Bloom, Diffuse reflectance and transmission fourier transform infrared [Drift] spectroscopy oh humic and fulvic acids, Soil Sci. Soc. Am. J. 53 (1989) 695–700.
- <span id="page-9-33"></span>[41] R. Pérez Vélez, U. Bentrup, W. Grünert, A. Brückner, The role of NO<sub>2</sub> in the fast NH<sub>3</sub>-SCR of NOx: a combined in situ FTIR and EPR spectroscopic study, Top. Catal. 60 (2017) 641–1652.
- <span id="page-9-34"></span>[42] M.P. Ruggeri, A. Grossale, I. Nova, E. Tronconi, H. Jirglova, Z. Sobalik, FTIR in situ mechanistic study of the NH<sub>3</sub> NO/NO<sub>2</sub> "Fast SCR" reaction over a commercial Fe-ZSM-5 catalyst, Catal. Today 184 (2012) 107–114.
- <span id="page-9-35"></span>[43] X. Yao, T. Kong, S. Yu, L. Li, F. Yang, L. Dong, Influence of different supports on the physicochemical properties and denitration performance of the supported Mn-based catalysts for NH<sub>3</sub>-SCR at low temperature, Appl. Surf. Sci. 402 (2017) 208–217.
- <span id="page-9-36"></span>[44] Z. Wu, B. Jiang, Y. Liu, H. Wang, R. Jin, DRIFT study of manganese/titania-based catalysts for low-temperature selective catalytic reduction of NO with NH<sub>3</sub>, Environ. Sci. Technol. 41-16 (2007) 5812–5817.
- <span id="page-9-37"></span>[45] J.M.G. Amores, V.S. Escribano, G. Ramis, G. Busca, An FT-IR study of ammonia adsorption and oxidation over anatase-supported metal oxides, Appl. Catal. B 13

[\(1997\) 45–58.](http://refhub.elsevier.com/S0926-3373(19)30567-3/sbref0225)

- <span id="page-10-0"></span>[46] [R. Portela, V.E. García-Sánchez, M. Villarroel, S.B. Rasmussen, P. Ávila, Influence of](http://refhub.elsevier.com/S0926-3373(19)30567-3/sbref0230) [the pore generation method on the metal dispersion and oxidation activity of](http://refhub.elsevier.com/S0926-3373(19)30567-3/sbref0230) [supported Pt in monolithic catalysts, Appl. Catal. A Gen. 510 \(2016\) 49–56.](http://refhub.elsevier.com/S0926-3373(19)30567-3/sbref0230)
- <span id="page-10-1"></span>[47] [I. Nova, C. Diardelli, E. Tronconi, NH3‐SCR of NO over a V‐based catalyst: low‐T](http://refhub.elsevier.com/S0926-3373(19)30567-3/sbref0235) redox kinetics with NH3 [inhibition, AlCHE J. 52 \(2006\) 3222–3233.](http://refhub.elsevier.com/S0926-3373(19)30567-3/sbref0235)
- <span id="page-10-2"></span>[48] [E. Tronconi, I. Nova, Chapter 9. The role of NO2](http://refhub.elsevier.com/S0926-3373(19)30567-3/sbref0240) in the NH3-SCR catalytic chemistry, [in: I. Nova, E. Tronconi \(Eds.\), Urea-SCR Technology for DeNOx after Treatment of](http://refhub.elsevier.com/S0926-3373(19)30567-3/sbref0240) [Diesel Exhaust. Fundamental and Applied Catalysis, Springer, New York, 2014.](http://refhub.elsevier.com/S0926-3373(19)30567-3/sbref0240)
- <span id="page-10-3"></span>[49] [R.Q. Long, R.T. Yang, Reaction mechanism of selective catalytic reduction of NO](http://refhub.elsevier.com/S0926-3373(19)30567-3/sbref0245) with NH3 [over Fe-ZSM-5 catalyst, J. Catal. 207 \(2002\) 224–231.](http://refhub.elsevier.com/S0926-3373(19)30567-3/sbref0245)