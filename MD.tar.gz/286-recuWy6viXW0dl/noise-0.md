![](_page_0_Figure_0.jpeg)

# ORDINARY DIFFERENTIAL EQUATIONS

JACK K. HALE

![](_page_1_Picture_2.jpeg)

KRIEGER PUBLISHING COMPANY MALABAR, FLORIDA

Original Edition 1969 Second Edition 1980

Printed and Published by ROBERT E. KRIEGER PUBLISHING COMPANY, INC. KRIEGER DRIVE MALABAR, FLORIDA 32950

Copyright © 1969 (Original Material) by JOHN WILEY & SONS, INC. Copyright © 1980 (New Material) by ROBERT E. KRIEGER PUBLISHING COMPANY, INC.

All rights reserved. No reproduction in any form of this book, in whole or in part (except for brief quotation in critical articles or reviews), may be made without written authorization from the publisher.

Printed in the United States of America

## Library of Congress Cataloging in Publication Data

Hale, Jack K.

Ordinary differential equations.

Second edition of original published by Wiley-Interscience, New York, which was issued as v. 21 of Pure and applied mathematics.

Bibliography: p.

Includes index.

1. Differential equations. I. Title.

[QA372.H184 1980] 515'.352 79-17238

ISBN 0-89874-011-8

10 9 8 7 6

## Preface

This book is the outgrowth of a course given for a number of years in the Division of Applied Mathematics at Brown University. Most of the students were in their first and second years of graduate study in applied mathematics, although some were in engineering and pure mathematics. The purpose of the book is threefold. First, it is intended to familiarize the reader with some of the problems and techniques in ordinary differential equations, with the emphasis on nonlinear problems. Second, it is hoped that the material is presented in a way that will prepare the reader for intelligent study of the current literature and for research in differential equations. Third, in order not to lose sight of the applied side of the subject, considerable space has been devoted to specific analytical methods which are presently widely used in the applications.

Since the emphasis throughout is on nonlinear phenomena, the global theory of two-dimensional systems has been presented immediately after the fundamental theory of existence, uniqueness, and continuous dependence. This also has the advantage of giving the student specific examples and concepts which serve to motivate study of later chapters. Since a satisfactory global theory for general n-dimensional systems is not available, we naturally turn to local problems and, in particular, to the behavior of solutions of differential equations near invariant sets. In the applications it is necessary not only to study the effect of variations of the initial data but also in the vector field. These are discussed in detail in Chapters III and IV in which the invariant set is an equilibrium point. In this way many of the basic and powerful methods in differential equations can be examined at an elementary level. The analytical methods developed in these chapters are immediately applicable to the most widely used technique in the practical theory of nonlinear oscillations, the method of averaging, which is treated in Chapter V. When the invariant set corresponds to a periodic orbit and only autonomous perturbations in the vector field are permitted, the discussion is similar to that for an equilibrium point and is given in Chapter VI. On the other hand, when the perturbations in the vector field are nonautonomous or the invariant set is a closed curve with equilibrium points, life is not so simple. In Chapter VII an attempt has been made to present this more complicated

x PREFACE

and important subject in such a way that the theory is a natural generalization of the theory in Chapter IV. Chapter VIII is devoted to a general method for determining when a periodic differential equation containing a small parameter has a periodic solution. The reason for devoting a chapter to this subject is that important conclusions are easily obtained for Hamiltonian systems in this framework and the method can be generalized to apply to problems in other fields such as partial differential, integral, and functional differential equations. The abstract generalization is made in Chapter IX with an application to analytic solutions of linear systems with a singularity, but space did not permit applications to other fields. The last chapter is devoted to elementary results and applications of the direct method of Lyapunov to stability theory. Except for Chapter I this topic is independent of the remainder of the book and was placed at the end to preserve continuity of ideas.

For the sake of efficiency and to acquaint the student with concrete applications of elementary concepts from functional analysis, I have presented the material with an element of abstraction. Relevant background material appears in Chapter 0 and in the appendix on almost periodic functions, although I assume that the reader has had a course in advanced calculus. A one-semester course at Brown University usually covers the saddlepoint property in Chapter III; the second semester is devoted to selections from the remaining chapters. Throughout the book I have made suggestions for further study and have provided exercises, some of which are difficult. The difficulty usually arises because the exercises are introduced when very little technique has been developed. This procedure was followed to permit the student to develop his own ideas and intuition. Plenty of time should be allowed for the exercises and appropriate hints should be given when the student is prepared to receive them.

No attempt has been made to cover all aspects of differential equations. Lack of space, however, forced the omission of certain topics that contribute to the overall objective outlined above; for example, the general subject of boundary value problems and Green's functions belong in the vocabulary of every serious student of differential equations. This omission is partly justified by the fact that this topic is usually treated in other courses in applied mathematics and, in addition, excellent presentations are available in the literature. Also, specific applications had to be suppressed, but individuals with special interest can -easily make the correlation with the theoretical results herein.

I have received invaluable assistance in many conversations with my colleagues and students at Brown University. Special thanks are due to C. Olech for his direct contribution to the presentation of two-dimensional systems, to M. Jacobs for his thought-provoking criticisms of many parts of

PREFACE xi

the original manuscript, and to W. S. Hall and D. Sweet for their comments. I am indebted to K. Nolan for her endurance in the excellent preparation of the manuscript. I also wish to thank the staff of Interscience for being so efficient and cooperative during the production process.

Jack K. Hale

Providence, Rhode Island September, 1969

## Preface to Revised Edition

For this revised edition, I am indebted to several colleagues for their assistance in the elimination of misprints and the clarification of the presentation. The section on integral manifolds has been enlarged to include a more detailed discussion of stability. In Chapter VIII, new material is included on Hopf bifurcation, bifurcation with several independent parameters and subharmonic solutions. A new section in Chapter X deals with Wazewski's principle. The Appendix on almost periodic functions has been completely rewirtten using the modern definition of Bochner.

Jack K. Hale

April1980

## Contents

| CHAPTER 0.                                   |                                                     |    |
|----------------------------------------------|-----------------------------------------------------|----|
|                                              | Mathematical preliminaries                          | 1  |
| 0.1.                                         | Banach spaces and examples                          | 1  |
| 0.2.                                         | Linear transformations                              | 3  |
| 0.3.                                         | Fixed point theorems                                | 4  |
| CHAPTER I.                                   |                                                     |    |
| General properties of differential equations |                                                     |    |
| I.1.                                         | Existence                                           |    |
| 1.2.                                         | Continuation of solutions                           |    |
| 1.3.                                         | Uniqueness and continuity properties                |    |
| 1.4.                                         | Continuous dependence and stability                 |    |
| 1.5.                                         | Extension of the concept of a differential equation |    |
| 1.6.                                         | Differential inequalities                           |    |
| 1.7.                                         | Autonomous systems-generalities                     |    |
| 1.8.                                         | Autonomous systems-limit sets, invariant sets       |    |
| 1.9.                                         | Remarks and suggestions for further study           |    |
| CHAPTER II.                                  |                                                     |    |
|                                              | Two dimensional systems                             | 51 |
| 11.1.                                        | Planar two dimensional systems-the Poincare         |    |
|                                              | Bendixson theory                                    | 51 |
| 11.2.                                        | Differential systems on a torus                     | 64 |
| 11.3.                                        | Remarks and suggestions for further study           | 76 |
| CHAPTER III.                                 |                                                     |    |
|                                              | Linear systems and linearization                    | 78 |
| 111.1.                                       | General linear systems                              | 79 |

xiv CONTENTS

| 111.2.      | Stability of linear and perturbed linear systems                   | 83  |
|-------------|--------------------------------------------------------------------|-----|
| 111.3.      | nth Order scalar equations                                         | 89  |
| 111.4.      | Linear systems with constant coefficients                          | 93  |
| 111.5.      | Two dimensional linear autonomous systems                          | 101 |
| III.6.      | The saddle point property                                          | 106 |
| 111.7.      | Linear periodic systems                                            | 117 |
| III.8.      | Hill's equation                                                    | 121 |
| 111.9.      | Reciprocal systems                                                 | 131 |
|             | III.10. Canonical systems                                          | 136 |
|             | III.11. Remarks and suggestions for further study                  | 142 |
| CHAPTER IV. |                                                                    |     |
|             | Perturbations of noncritical linear systems                        | 144 |
| IV.1.       | Nonhomogeneous linear systems                                      | 145 |
| IV.2.       | Weakly nonlinear equations-noncritical case                        | 154 |
| IV.3.       | The general saddle point property                                  | 156 |
| IV.4.       | More general systems                                               | 162 |
| IV.5        | The Duffing equation with large damping and large                  |     |
|             | forcing                                                            | 168 |
| W.6         | Remarks and extensions                                             | 171 |
| CHAPTER V.  |                                                                    |     |
|             | Simple oscillatory phenomena and the method of averaging           | 175 |
| V.I.        | Conservative systems                                               | 176 |
| V.2.        | Nonconservative second order equations-limit cycles                | 184 |
| V.3.        | Averaging                                                          | 190 |
| V.4.        | The forced van der Pol equation                                    | 198 |
| V.5.        | Duffing's equation with small damping and small                    |     |
|             | harmonic forcing                                                   | 199 |
| V.6.        | The subharmonic of order 3 for Duffing's equation                  | 206 |
| V.7.        | Damped excited pendulum with oscillating support                   | 208 |
| V.8.        | Exercises                                                          | 210 |
| V.9.        | Remarks and suggestions for further study                          | 211 |
| CHAPTER VI. |                                                                    |     |
|             | Behavior near a periodic orbit                                     | 213 |
|             | VI.I. A local coordinate system about an invariant closed<br>curve |     |
|             |                                                                    | 214 |

|               | CONTENTS                                                      | xv   |
|---------------|---------------------------------------------------------------|------|
| VI.2.         | Stability of a periodic orbit                                 | 219  |
| VI.3.         | Sufficient conditions for orbital stability in two            |      |
|               | dimensions                                                    | '224 |
| VI.4.         | Autonomous perturbations                                      | 226  |
| VI.5.         | Remarks and suggestions for further study                     | 227  |
| CHAPTER VII.  |                                                               |      |
|               | Integral manifolds of equations with a small parameter        | 229  |
| VII.1.        | Methods of determining integral manifolds                     | 231  |
| VII.2.        | Statement of results                                          | 236  |
|               | VII.3. A " nonhomogeneous linear " system                     | 239  |
| VII.4.        | The mapping principle                                         | 245  |
| VII.5.        | Proof of Theorem 2.1                                          | 247  |
| VII.6.        | Stability of the-perturbed manifold                           | 248  |
| VII.7.        | Applications                                                  | 250  |
| VII.8.        | Exercises                                                     | 254  |
| VII.9.        | Remarks and suggestions for further study                     | 256  |
| CHAPTER VIII. |                                                               |      |
|               | Periodic systems with a small parameter                       | 258  |
|               | VIII.!. A special system of equations                         | 259  |
| VIII.2.       | Almost linear systems                                         | 275  |
| VIII.3.       | Periodic solutions of perturbed autonomous equations          | 294  |
| VIII.4.       | Remarks and suggestions for further study                     | 296  |
| CHAPTER IX.   |                                                               |      |
|               | Alternative problems for the solution of functional equations | 298  |
| IX.!.         | Equivalent equations                                          | 299  |
|               | IX.2. A generalization                                        | 302  |
| IX.3.         | Alternative problems                                          | 303  |
| IX.4.         | Alternative.problems for periodic solutions                   | 304  |
| IX.5.         | The Perron-Lettenmeyer theorem                                | 307  |
|               |                                                               |      |

IX.6. Remarks and suggestions for further study

309

xvi

#### CONTENTS

| CHAPTER X.<br>The direct method of Liapunov<br>311           |                                                |     |  |  |  |
|--------------------------------------------------------------|------------------------------------------------|-----|--|--|--|
|                                                              |                                                |     |  |  |  |
|                                                              | autonomous systems                             | 311 |  |  |  |
| X.2.                                                         | Circuits containing Esaki diodes               | 320 |  |  |  |
| Sufficient conditions for stability in nonautonomous<br>X.3. |                                                |     |  |  |  |
|                                                              | systems                                        | 324 |  |  |  |
| X.4.                                                         | The converse theorems for asymptotic stability | 327 |  |  |  |
| X.5.                                                         | Implications of asymptotic stability           | 331 |  |  |  |
|                                                              | X.6. Wazewski's principle                      | 333 |  |  |  |
| X.7.                                                         | Remarks and suggestions for further study      | 338 |  |  |  |
| APPENDIX                                                     |                                                |     |  |  |  |
| Almost periodic functions                                    | 339                                            |     |  |  |  |
| References                                                   | 352                                            |     |  |  |  |

Index 360

## CHAPTER 0

## Mathematical Preliminaries

In this chapter we collect a number of basic facts from analysis which play an important role in the theory of differential equations.

### 0.1. Banach Spaces and Examples

Set intersection is denoted by n, set union by u, set inclusion bye and x e S denotes x is a member of the set S. R (or C) will denote the real (or complex) field. An abstract linear vector space (or linear space) £' over R (or C) is a collection of elements {x, y, ... } such that for each x, yin X, the sum x + y is defined, x + y e 27, x + y = y + x and there is an element 0 in E' such that x + 0 = x for all x e X. Also for any number a, b e R (or C), scalar multiplication ax is defined, ax a E' and 1 x = x, (ab)x = a(bx) = b(ax), (a + b)x = ax + by for all x, y e X. A linear space E is a normed linear space if to each x in E', there corresponds a real number jxj called the norm of x which satisfies

- (i) jxj >0 for x 0, 101 =0;.
- (ii) Ix + yl < jxj + jyj (triangle inequality);
- (iii) laxl= lai lxlfor all a in R (or C) and x in X.

When confusion may arise, we will write I x for the norm function on X. A sequence {xn} in a normed linear space E' converges to x in X if lim, I xn - xi = 0. We shall write this as lim xn = x. A sequence {xn} in X'is a Cauchy sequence if. for every e > 0, there is an N(s) > 0 such that jxn - x,nl < e if n, m >\_ N(s). The space 2' is complete if every Cauchy sequence in X converges to an element of X. A complete normed linear space is a Banach space. The s-neighborhood of an element x of a normed linear space E' is {y in X: y - xj < e}. A set S in ° ' is open if for every x e S, an e-neighborhood of x is also contained in X. An element x is a limit point of a set S if each e-neighborhood of x contains points of S. A set S is closed if it contains its limit points. The closure of a set S is the union of S and its limit points. A set S is dense in E' if the closure of S is X. If S is a subset of E',

I

A is a subset of R and Va, a e A is a collection of open sets of X such that Ua E A Va S. then the collection Va is called an open covering of S. A set S in . ' is compact if every open covering of S contains a finite number of open sets which also cover S. For Banach spaces, this is equivalent to the following: a set S in a Banach space is compact if every sequence {xn}, xn E S, contains a subsequence which converges to an element of S. A set S in . 1 ' is bounded if there exists an r > 0 such that S c {x e 2C: IxI < r}.

Example 1.1. Let Rn(Cn) be the space of real (complex) n-dimensional column vectors. For a particular coordinate system, elements x in Rn(Cn) will be written as x = (xi, ... , xn) where each xj is in R(C). If x = (xl, ... , xn), y = (yl, ..., yn) are in Rn(Cn), then ax + by for a, b in R(C) is defined to be (axl + by,, ..., axn + byn). The space Rn(Cn) is clearly a linear space. It is a Banach space if we choose IxI, x = col(xl, ..., xn), to be either supilxil, Yi Ixil or [Ei IxiI2]4. Each of these norms is equivalent in the sense that a sequence converging in one norm converges in any of the other norms. Rn(Cn) is complete because convergence implies coordinate wise convergence and R(C) is complete.

A set S in Rn(Cn) is compact if and only if it is closed and bounded.

EXERCISE 1.1. If E is a finite dimensional linear vector space and I I, are two norms on E, prove there are positive constants m, M such that m I xI < jjxjj < M I xI for all x in E.

Example 1.2. Let D be a compact subset of Rm [or Cm] and %(D, Rn) [or '(D, Cn)] be the linear space of continuous functions which take D into Rn [or Cn]. A sequence of functions (On, n =1, 2, ... } in W(D, Rn) is said to converge uniformly on D if there exists a function 0 taking D into Rn such that for every e > 0 there is an N(e) (independent of n) such that <sup>l</sup> n(x) - O(x)l < e for all n >\_ N(e) and x in D. A sequence Jon) is said to be uniformly bounded if there exists an M > 0 such that 10n(x)I <M for all x in D and all n = 1, 2. .... A sequence is said to be equicontinuous if, for every e > 0, there is a 8 > 0 such that

$$|\phi_n(x)-\phi_n(y)|$$

if Ix - yi < 8, x, y in D. A function f in '(D, Rn) is said to be Lipschitzian in D if there is a constant K such that I f (x) - f (y)I < KI x - yI for all x, y, in D. The most frequently encountered equicontinuous sequences in '(D, Rn) are sequences {tbn} which are Lipschitzian with a Lipschitz constant independent of n.

LEMMA 1.1. (Ascoli-Arzela). Any uniformly bounded equicontinuous sequence of functions in r(D. Rn) has a subsequence which converges uniformly on D.

LEMMA 1.2. If a sequence in '(D, Rn) converges uniformly on D, then the limit function is in '(D, Rn).

If we define

$$|\phi| = \max_{x \in D} |\phi(x)|,$$

then one easily shows this is a norm on W(D, Rn) and the above lemmas show that '(D, Rn) is a Banach space with this norm. The same remarks apply to '(D, Cn).

EXERCISE 1.2. Suppose m = n = 1. Show that le (D, R) is a normed linear space with the norm defined by

$$\|\phi\| = \int_D |\phi(x)| \ dx.$$

Give an example to show why this space is not complete. What is the completion of this space?

### 0.2. Linear Transformations

A function taking a set A of some space into a set B of some space will be referred to as a transformation or mapping of A into B. A will be called the domain of the mapping and the set of values of the mapping will be called the range of the mapping. If f is a mapping of A into B, we simply write f : A -\* B and denote the range off by f (A). If f : A -\* B is one to one and continuous together with its inverse, then we say f is a homeomorphism of A onto B. If .s, GJ are real (or complex) Banach spaces and f: , ' -\* ON is such that f (alxl + a2 x2) = al f (xi) + a2 f (x2) for all xl, x2 in . and all real (or complex) numbers al, a2, then f is called a linear mapping. A linear mapping f of . ' into °J is said to be bounded if there is a constant K such that if (x)I u < KI xI, for all x in ..

LEMMA 2.1. Suppose ', 9 are Banach spaces. A linear mapping f: -->9 is bounded if and only if it is continuous.

EXERCISE 2.1. Prove this lemma.

EXERCISE 2.2. Show that each linear mapping of Rn (or Cn) into R"n (or Cm) can be represented by an m x n real (or complex) matrix and is therefore necessarily continuous.

The norm I f I of a continuous linear mapping f: '-\*OJ is defined as

$$|f| = \sup\{|fx|_{\mathscr{Y}}: |x|_{\mathscr{X}} = 1\}.$$

It is easy to show that I f I defined in this way satisfies the properties (i)-(iii)

in the definition of a norm and also that

$$|fx|_{\mathscr{Y}} \leq |f| \cdot |x|_{\mathscr{X}}$$
 for all  $x$  in  $\mathscr{X}$ .

If a linear map taking an n-dimensional linear space into an m-dimensional linear space is defined by an m x n matrix A, we write its norm as IAI.

EXERCISE 2.3. If ', OY are Banach spaces, let L(X, 9) be the set of bounded linear operators taking T into 9. Prove the L(.T, qi) is a Banach space with the norm defined above.

Example 2.1. Define f: W([0, 1], R) -R by f (q) = f o 0(s) ds. The map f is linear and continuous with I f = 1.

Example 2.2. Define S = {q in 1([O, 1], R) which have a continuous first derivative}. S is dense in W([O, 1], Rn). For any 0 in S, define fq(t) = do(t)Jdt, 0 <\_ t < 1. The function f is linear but not bounded. In fact, the sequence of functions On(t) = tn, 0 <\_ t < 1, satisfies 114 u 11 = 1, but lI f f n 11 = n. Another way to show unboundedness is to prove f is not continuous. Consider the functions On(t) = to - to+1 0<\_ t< 1, n >\_ 1. In 16([0, 1], R), On --0 as n-\* oo, but fon(t) = to-1[n - (n + 1)t] and ffn(1) = -1, which does not approach zero as n - oo.

Another very important tool from functional analysis which can be used frequently in differential equations is the principle of uniform boundedness. In this book, we have chosen to circumvent this principle by using more elementary proofs except in one instance in Chapter IV.

## Principle of uniform boundedness

Suppose sd is an index set and Ta , a in sd, are bounded linear maps from a Banach space e' to a Banach space OJ such that for each x in ', sups in ,I T. xI < oo. Then sup. in TaI < oo.

## 0.3 Fixed Point Theorems

A fixed point of a transformation T: X ->.t is a point x in X such that Tx = x. Theorems concerning the existence of a fixed point of a transformation are very convenient in differential equations even though not absolutely necessary. Such theorems should be considered as a tool which avoids the repetition of standard arguments and permits one to concentrate on the essential elements of the problem.

One standard tool in analysis is successive approximations. The basic elements of the method of successive approximations have been abstracted

into the so called contraction mapping principle by Banach and Cacciopoli.

If  $\mathscr{F}$  is a subset of a Banach space  $\mathscr{X}$  and T is a transformation taking  $\mathscr{F}$  into a Banach space  $\mathscr{B}$  (written as  $T \colon \mathscr{F} \to \mathscr{B}$ ), then T is a *contraction* on  $\mathscr{F}$  if there is a  $\lambda$ ,  $0 \le \lambda < 1$ , such that

$$|Tx - Ty| \le \lambda |x - y|, \quad x, y \in \mathscr{F}.$$

The constant  $\lambda$  is called the *contraction constant* for T on  $\mathscr{F}$ .

THEOREM 3.1. (Contraction mapping principle of Banach-Cacciopoli). If  $\mathscr{F}$  is a closed subset of a Banach space  $\mathscr{X}$  and  $T \colon \mathscr{F} \to \mathscr{F}$  is a contraction on  $\mathscr{F}$ , then T has a unique fixed point  $\bar{x}$  in  $\mathscr{F}$ . Also, if  $x_0$  in  $\mathscr{F}$  is arbitrary, then the sequence  $\{x_{n+1} = Tx_n, n = 0, 1, 2, \ldots\}$  converges to  $\bar{x}$  as  $n \to \infty$  and  $|\bar{x} - x_n| \le \lambda^n |x_1 - x_0|/(1 - \lambda)$ , where  $\lambda < 1$  is the contraction constant for T on  $\mathscr{F}$ .

PROOF. Uniqueness. If  $0 \le \lambda < 1$  is the contraction constant for T on  $\mathscr{F},\ x = Tx,\ y = Ty,\ x,\ y \in \mathscr{F},\ \text{then}\ |x-y| = |Tx-Ty| \le \lambda |x-y|.$  This implies  $|x-y| \le 0$  and thus |x-y| = 0 and x = y.

Existence. Let  $x_0$  be arbitrary, and  $x_{n+1} = Tx_n$ ,  $n = 0, 1, 2, \ldots$ . By hypotheses, each  $x_n$ ,  $n = 0, 1, \ldots$ , is in  $\mathscr{F}$ . Also,  $|x_{n+1} - x_n| \le \lambda |x_n - x_{n-1}| \le \cdots \le \lambda^n |x_1 - x_0|$ ,  $n = 0, 1, \ldots$ . Thus, for m > n,

$$|x_{m} - x_{n}| \leq |x_{m} - x_{m-1}| + |x_{m-1} - x_{m-2}| + \dots + |x_{n+1} - x_{n}|$$

$$\leq [\lambda^{m-1} + \lambda^{m-2} + \dots + \lambda^{n}] |x_{1} - x_{0}|$$

$$= \lambda^{n} [1 + \lambda + \dots + \lambda^{m-n-1}] |x_{1} - x_{0}|$$

$$= \frac{\lambda^{n} [1 - \lambda^{m-n}]}{1 - \lambda} |x_{1} - x_{0}| \leq \frac{\lambda^{n}}{1 - \lambda} |x_{1} - x_{0}|.$$

Thus the sequence  $\{x_n\}$  forms a Cauchy sequence and there is an  $\bar{x}$  in  $\mathscr{X}$  such that  $\lim_{n\to\infty}x_n=\bar{x}$ . Since  $\mathscr{F}$  is closed,  $\bar{x}$  is in  $\mathscr{F}$ . Since T is continuous and  $|\cdot|$  is continuous (the latter because  $|x|-|x_n-x|\leq |x_n|\leq |x_n-x|+|x|$ ), it follows that

$$0 = \lim_{m \to \infty} |x_{m+1} - Tx_m| = \left| \lim_{m \to \infty} [x_{m+1} - Tx_m] \right| = |\bar{x} - T\bar{x}|,$$

which implies  $T\bar{x} = \bar{x}$ . This gives the existence of a fixed point.

To prove the last estimate, take the limit as  $m \to \infty$  in the previous estimate of  $|x_m - x_n|$ . This completes the proof of the theorem.

EXERCISE 3.1. Suppose  $\mathscr X$  is a Banach space,  $T:\mathscr X\to\mathscr X$  is a continuous linear operator with |T|<1. Show that I-T, I the identity operator, has a bounded inverse; that is, prove that the equation (I-T)x=y has a unique solution x in  $\mathscr X$  which depends continuously upon y in  $\mathscr X$ .

Let X, 1 be Banach spaces and D be an open set in X. A function f: D-9 is said to be (Frechet) differentiable at a point x in D if there is a bounded linear operator A (x) taking , ' --\* such that for every he ' with x+h e D,

$$|f(x+h)-f(x)-A(x)h| \leq \rho(|h|,x),$$

where p(IhI, x) satisfies p(jhI, x)/jhI ->0 as IhI -\*0. The linear operator A(x) is called the derivative off at x and A(x)h the differential off at x.

EXERCISE 3.2. Suppose ', & are Banach spaces, d is an open subset of ', f : al--> °J, and

$$\lim_{t\to 0} \frac{f(x_0 + th) - f(x_0)}{t} = \omega(x_0)h$$

exists for every x0 a d, h e X, where the limit is taken for t real. Suppose w(xo) is a continuous linear mapping for all xo a sal and suppose w considered as a mapping from d into L(X, °1J) is continuous, where L(X, ') is defined in Exercise 2.3. Prove that f is (Frechet) differentiable with derivative w(xo) at xo a d.

EXERCISE 3.3. Prove that w(xo) of the previous exercise can exist for every h, be a continuous linear mapping and not be the Frechet derivative off at xoesal.

EXERCISE 3.4. Let 1I([0, 1], Rn) denote the space of continuously differentiable functions x: [0, 1] -\* Rn, with addition and scalar multiplication defined in the usual way and let IxI =supo<t<I Ix(t)I +supo<t<I Ii(t)I where x(t) = dx/dt. Prove "I([0, 1], Rn) is a Banach space.

EXERCISE 3.5. Let w: 'I([0, 1], Rn) X [0, 1] Rn be the evaluation mapping, w(x, t) = x(t). Prove that w is continuously differentiable and compute its derivative. Do this exercise two ways, using the definition of the derivative and also Exercise 3.2.

If f: Rm -\* Rn is differentiable at a point x, then A(x) = 8f (x)/8x = (eft(x)/axj, i = 1, 2, ..., n, j = 1, 2, ..., m), is the Jacobian matrix of f with respect to x.

For later reference, it is convenient to have notation for order relations. We shall say a function f (x) = O(jxj) as IxI -\*0 if If (x)I /jxI is bounded for x in a neighborhood of zero and f (x) = o(lxl) as IxI ->0 if If (x)I /lxl -\*0 as (xI -\*0.

Suppose 3 is a subset of a Banach space T, 9 is a subset of a Banach space °J and {T, y e 9) is a family of operators taking F -\* T. The perator T y is said to be a uniform contraction on F if T y: F -\* F and there is a A, 0 < A < 1 such that

$$|T_y x - T_y \bar{x}| \le \lambda |x - \bar{x}|$$
 for all  $y$  in  $\mathscr{G}$ ,  $x$ ,  $\bar{x}$  in  $\mathscr{F}$ .

In other words, Ty is a contraction for each y in 9r and the contraction constant can be chosen independent of y in 9.

. THEOREM 3.2. If F is a closed subset of a Banach space ', 9F is a subset of a Banach space ON, Ty: , - .F, y in 9 is a uniform contraction on ,F and Tyx is continuous in y for each fixed x in .F, then the unique fixed point g(y) of Ty, y in 4, is continuous in y. Furthermore, if F, 9 are the closures of open sets F°, #° and Tyx has continuous first derivatives A(x, y), B(x, y) in y, x, respectively, then g(y) has a continuous first derivative with respect to yin 9°.

COROLLARY 3.1. Suppose ' is a Banach space, T is a subset of a Banach space J, Ay: ' are continuous linear operators for each y in 9, IAyI < 8 < 1 for all y in G and Ay x is continuous in y for each x in X. Then the operator I -A y has a bounded inverse which depends continuously upony, I(I-Ay)-1I <(l -6)-1

PRooFs. Since Ty:.F -a ,F is a uniform contraction, there is a A, 0:5A<1 such that I T y x - T y x1 5 A I x - xl for all yin 9r, x, x in .F. Let g(y) be the unique fixed point of Ty in ,F which exists from Theorem 3.1. Then

$$g(y+h) - g(y) = T_{y+h}g(y+h) - T_yg(y)$$
  
=  $T_{y+h}g(y+h) - T_{y+h}g(y) + T_{y+h}g(y) - T_yg(y)$ ,

and

$$|g(y+h)-g(y)| \le \lambda |g(y+h)-g(y)| + |T_{y+h}g(y)-T_yg(y)|.$$

This implies

$$|g(y+h)-g(y)| \le (1-\lambda)^{-1} |T_{y+h}g(y)-T_yg(y)|.$$

Since T y x is continuous in y for each fixed x in F, we see that g(y) is continuous. This proves the first part of the theorem.

The proof of Corollary 3.1 is now almost immediate. In fact, we need to show that the equation x - Ay x = z has a unique solution for each z in et and this solution depends continuously upon y, z. This is equivalent to finding the fixed points of the operator T y, z defined by T y, , x = A y x + z, x in T. Since Ay is a uniform contraction, (I -Ay)-1 exists, is bounded and continuous in y. Also, if (I - Ay )x = y, then y I > (1 - S) Ix I and the proof of Corollary 3.1 is complete.

To prove the last part of the theorem, suppose T y x has continuous first derivatives A(x, y), B(x, y) with respect to y, x, respectively, for y e 99°, x e F°. Let us use the fact that g(y) =Tyg(y) and try to find the equation that the differential z = C(y)h, h in OJ of g will have to satisfy if g has a derivative C(y). If the chain rule of differentiation is valid then

$$z = B(g(y), y)z + A(g(y), y)h$$

where h is an arbitrary element of Y. It is easy to show that T y being a uniform contraction implies I B(x, y) I < S < 1 for x in 97°, y in 1°.

Since I B(x, y) I < S < 1 for x in .V, y in '9°, an application of Corollary 3.1 implies, for each y in (9°, h in 4', the existence of a unique solution z(y, h) of (3.1) which is continuous in y, h. From uniqueness, one observes that z(y, ah + flu) = az(y, h) + Pz(y, u) for all scalars a, P and h, u in 9; that is, z(y, h) is linear in h and may be written as C(y)h, where C(y): 9 - X is a continuous linear operator for each y is also `continuous in y. To show that C(y) is the derivative of g(y), let w = g(y + h) - g(y), B(g(y),y) = B(y), A (g(y),y) = A (y) and observe that w satisfies the equation

$$w - B(y)w - A(y)h + f(w,h,y) = 0$$

where, for any e >. 0, there is a v > 0 such that I f(w, h, y) I < e(I w l + I hl) for I hi < v, y in W°. From Corollary 3.1,

$$w - [I - B(y)]^{-1}A(y)w + F(w,h,y) = 0$$

where IF(w,h,y)I < e(1 - 6)-1(Iwl + Ihl) for Ih1 < v,y in (g°. But, this implies

$$|w| \le \mu |h|, \qquad \mu = 2|[I - B(y)]^{-1}A(y)| + 1$$
  
 $|y - [I - B(y)]^{-1}A(y)h| \le \frac{\epsilon(1 + \mu)}{1 - \delta}|h|.$ 

for Ihl < v. This shows that g(y) is continuously differentiable in y and the derivative is given by C(y) satisfying Equation (3.1). This completes the proof of the theorem.

To illustrate the contraction principle, we prove the following important theorem of implicit functions. In the statement of this result det A for an m x m matrix A denotes the determinant of A.

THEOREM 3.3. (of Implicit Functions). Suppose F: Rm x Rn --> Rm has continuous first partial derivatives and F(0, 0) = 0. If the Jacobian matrix 8F(x, y)/8x of F with respect to x satisfies det 8F(0, 0)/8x 0, then there exist neighborhoods U, V of 0 in Rm, Rn, respectively, such that for each fixed y in V the equation F(x, y) = 0 has a unique solution x in U. Furthermore, this solution can be given as x = g(y), where g has continuous first derivatives and g(O) = 0.

PROOF: Let us write

$$F(x, y) = Ax - N(x, y),$$
 
$$A = \frac{\partial F(0, 0)}{\partial x},$$

$$N(x, y) = \frac{\partial F(0, 0)}{\partial x^{2}} x - F(x, y), N(0, 0) = 0.$$

From the expression for N, we have

$$\frac{\partial N(x, y)}{\partial x} = \frac{\partial F(0, 0)}{\partial x} - \frac{\partial F(x, y)}{\partial x}.$$

The hypothesis of continuity of aF(x, y)/ax implies bN(x, y)/ax - 0 as x -\* 0, y -- 0. We therefore have the existence of a function k(y, p) which is continuous in y e Rn and p >\_.0 such that k(0, 0) = 0 and

$$\big|N(x,\,y)-N(\bar x,\,y)\big|\leqq k(y,\,\rho)\big|x-\bar x\big|$$

for all y in Rn and x, x with IxI, IxI < p. Since the matrix A is assumed to be nonsingular, finding a solution to F(x, y) = 0 is equivalent to finding a solution of the equation x = A-1N(x, y), where A-1 is the inverse of A. This is equivalent to finding a fixed point of the operator T y: Rm --\* Rm defined by Tyx = A-1N(x, y). We now show that Ty is a contraction on an appropriate set. There is a constant K (see Exercise 2.2) such that I A-1xi < KIxj for all x in Rm and therefore

$$egin{aligned} |T_y x| &= |A^{-1}N(x,y)| \leq K \, |N(x,y)| \ &= K \, |N(x,y) - N(0,y) + (0,y)| \ &\leq K k(y,
ho) \, |x| + K \, |N(0,y)| \ &|T_y x - T_y ar{x}| \leq K k(y,
ho) \, |x - ar{x}| \end{aligned}$$

for IxI, IxI < p and all y. Choose e, S positive and so small that

$$Kk(y, \rho)\rho + K|N(0, y)| < \varepsilon \text{ for } |y| \le \delta, \rho \le \varepsilon,$$
  
 $\sup\{Kk(y, \rho), |y| \le \delta, \rho \le \varepsilon\} < 1,$ 

and let U = {x in Rm: IxI < e}, V = {y in Rn: IyI < S}. It follows that Ty is a uniform contraction of U into U for y in Vo. Therefore Ty has a unique fixed point g(y) in U from Theorem 3.1. It is clear that g(0) = 0. Since Ty x is continuous in y for each x it follows from Theorem 3.2 that g(y) is continuous in y. Also T y x has continuous first derivatives with respect to x and y with the derivative with respect to x being given by A-1 aN(x, y)/ax. Theorem 3.2 implies therefore the continuous differentiability of g(y) in y and completes the proof of the implicit function theorem.

EXERCISE 3.6. State and prove a generalization of Theorem 3.3 for Banach spaces. Hint: Redo the steps in the proof of Theorem 3.3 for Banach spaces making appropriate changes and hypotheses where necessary.

The contraction mapping principle can be regarded as a fixed point theorem. Other fixed point theorems of a more sophisticated type are very

useful in differential equations. We formulate two more which are used in this book.

An obvious fixed point theorem in one dimension is the following: any continuous mapping of the closed interval [0, 1] into itself must have a fixed point. The proof is obvious if one simply observes that the existence of a fixed point is equivalent to saying that the graph of the function in 2-space must cross the diagonal of the unit square with vertices at (0, 0), (1, 0), (0, 1), (1, 1). After some thought it seems plausible that a similar result should hold in higher dimensions but the proof is difficult. This is the celebrated

BRouwER FIXED POINT THEOREM. Any continuous mapping of the closed unit ball in Rn into itself must have a fixed point.

If a subset A of Rn is homeomorphic to the closed unit ball in Rn and f is a continuous mapping of A into A, then the Brouwer Fixed Point Theorem implies f has a fixed point in A.

Suppose f : Rn -\* Rn is a continuous mapping. The zeros of the function f coincide with the fixed points of the mapping g defined by g(x) = x + f (x). If we can show that there is a set D in Rn which is homeomorphic to the closed unit ball in Rn such that g takes D into D, then the Brouwer fixed point theorem implies that g has a fixed point in D and f has a zero in D. This is a very important application of the Brouwer fixed point theorem.

The Brouwer fixed point theorem has been generalized to Banach spaces by Schauder and even more general spaces by Tychonov. We formulate this result for Banach spaces. Recall that a subset d of a Banach space is compact if any sequence {qn}, n =1, 2, ... in rat has a subsequence which converges to an element of a. A subset sad is convex if for x, y in ,sd it follows that tx + (1 - t)y is in sad for 0 < t < 1; that is, sl contains the " line segment " joining x and y. A mapping f of a Banach space ' into a Banach space 'J is said to be compact if for every bounded set ,0' in ' the closure of the set {f (x), x in sad} is compact. If, in addition, f is continuous, it is called completely continuous.

SCHAUDER FIXED POINT THEOREM. If d is a convex, compact subset of a Banach space in sad. ' and f : sd -> sl is continuous, then f has a fixed point

COROLLARY: If sad is a closed, bounded, convex subset of a Banach space ' and f : d -\* d is completely continuous, then f has a fixed point in d.

The proof of the corollary proceeds as follows: Since f (sad) a d and sat is closed, the closure of f (d) belongs to sad and is compact by hypothesis. Furthermore, the convex closure -4 off (,u?) [the smallest closed convex set containing f (,d)] belongs to sad since sad is convex. A theorem f Mazur states that ad is compact. Since . c si, f (9) e f (sat) c 9 and the previous result implies the existence of a fixed point in -4 e sad.

As remarked earlier, the Schauder theorem was extended to more general spaces (locally convex linear topological spaces) by Tychonov. We do not wish to introduce all of the terminology of locally convex linear topological spaces. In fact, the only such space for which we need the extended form of this theorem is for the space of continuous functions f: R --\* Cn for which convergence in the space is equivalent to uniform convergence on compact subsets. A set is bounded in this space if all elements of the set are uniformly bounded continuous functions. The statement of the extended form of this theorem is now exactly the same as before. We will refer to the fixed point theorem in this situation as the Schauder-Tychonov theorem.

EXERCISE 3.7. Show the Schauder theorem is false if either the compactness or the convexity of A is eliminated.

A very useful compact, convex subset of (I,' Rn), I a closed bounded interval of R1, is obtained in the following manner. Suppose M, f are positive constants and sat is the subset of W(1, Rn) such that 0 in .sd implies 101 < P, 10(t) - ¢(t)l < M It -11, fort, 1 in I. The set ,sat is obviously convex and closed. Furthermore, any sequence {0n} in d is uniformly bounded and equicontinuous. Lemmas 1.1 and 1.2 imply the existence of a 0 in '(I, Rn) such that limn.w 0. = 0. But d is closed so that ¢ belongs to ,sat. This proves compactness of d.

The following books are standard references on analysis and functional analysis.

Dunford, N., and J. T. Schwartz, Linear Operators, Part I: General Theory, Interscience, New York, 1964.

Graves, L. M., The Theory of Functions of Real Variables, 2nd Edition, McGraw-Hill, New York, 1956.

Hurewicz, W., and H. Walman, Dimension Theory, Princeton University Press, Princeton, N.J., 1941.

Liusternik, L. A., and V. J. Sobolev, Elements of Functional Analysis, Ungar, New York, 1965.

Rudin, W., Real and Complex Analysis, McGraw-Hill, New York, 1966.

Yoshida, K., Functional Analysis, Springer-Verlag, Berlin, 1965.

## CHAPTER I

## General Properties of Differential Equations

The purpose of this chapter is to discuss those properties of differential equations which are not dependent upon the specific form of the vector field. The basic existence theorem of Section 1 shows that a differential equation does define a family of functions and Sections 2 and 3 discuss the dependence of this family upon the initial values and parameters. Section 4 contrasts the concept of stability with the concept of continuous dependence upon initial values. Section 5 is concerned with differential equations with vector fields that are only Lebesgue integrable in t. Section 6 is devoted to differential inequalities and their application to the problem of obtaining upper and lower bounds for solutions of differential equations. Sections 7 and 8 deal with some properties of the solution of differential equations which are characteristic of the fact that the vector field is independent of time; namely, the existence of cylinders of orbits near regular points and the concepts of invariant and minimal sets.

## I.I. Existence

Let t be a real scalar; let D be an open set in Rn+1 with an element of D written as (t, x) ; let f : D -. Rn, be continuous and let x = dx/dt. A differential equation is a relation of the form

(1.1) 
$$\dot{x}(t) = f(t, x(t))$$
 or, briefly  $\dot{x} = f(t, x)$ .

We say x is a oluti of (1.1) on an interval I e R if x is a continuously differentiable function defined on I, (t, x(t)) a D, t e I and x satisfies (1.1) on I. We refer to f as a vector field on D.

Example I.I. Let D = R2, f (t, x) = x2. The function 4(t) t } c' c an arbitrary real number, c 0 0, is a solution of i = x2 for t e (-c, oo) if c>0; t e (-co, -c) if c <0. (See Fig. 1.1).

![](_page_22_Figure_2.jpeg)

Figure 1.1.1

Example 1.2. Let D = R2, f (t, x) = Jx for x 0, = 0 for x < 0. The function 0(t) = (t - c)2/4, t >\_ c, is a solution of i = Jx, x >\_ 0. Notice x = 0 is also a solution (see Fig. 1.2).

Suppose (to, xo) e D is given. An initial value problem or equation 1.1 consists of finding an interval I containing to and a solution x of (1.1)

![](_page_22_Figure_6.jpeg)

Figure 1.1.2

satisfying  $x(t_0) = x_0$  . We write this problem symbolically as

(1.2) 
$$\dot{x} = f(t, x), x(t_0) = x_0, t \in I.$$

If there exists an interval I containing  $t_0$  and an x satisfying (1.2), we refer to this as a solution of (1.1) passing through  $(t_0, x_0)$ .

For the initial value problem,  $\dot{x} = x^2$ , x(0) = -c, c real, Example 1.1 shows the interval I may depend upon c and may not be the whole real line.

The initial value problem  $\dot{x} = \sqrt{x}$ ,  $x \ge 0$ , x(0) = 0, has the solution x = 0 on  $(-\infty, \infty)$ . The function

$$x(t) = egin{cases} \dfrac{(t-c)^2}{4}, & t \geq c \geq 0, \\ 0, & t \leq c. \end{cases}$$

is also a solution. Therefore there need not be a unique solution of (1.2) for every continuous function f.

Our first objective in this chapter is to discuss existence, uniqueness, continuation of solutions, and continuous dependence of solutions on initial data and parameters.

First, notice that consideration of vector equations makes it unnecessary to consider  $n^{\text{th}}$  order equations. In fact, if y is a scalar,  $y^{(j)}$  denotes  $d^j y/dt^j$  and

$$y^{(n)} = F(t, y, y', \dots, y^{(n-1)}),$$
  
 $y^{(j)}(t_0) = x_{j+1, 0}, \quad j = 0, 1, \dots, n-1,$ 

then, letting  $x=(y,\ y^{(1)},\ \dots,\ y^{(n-1)}),\ f=(x_2,\ \dots,\ x_n\,,\ F),$  we obtain the equivalent problem

$$\dot{x} = f(t, x), \qquad x(t_0) = x_0 = (x_{10}, \ldots, x_{n0}).$$

Also, complex valued differential equations of the real variable t are included in the discussion of (1.1) since one can obtain a real system by taking the real and imaginary parts.

LEMMA 1.1. Problem (1.2) is equivalent to

(1.3) 
$$x(t) = x_0 + \int_{t_0}^{t} f(\tau, x(\tau)) d\tau$$

provided f(t, x) is continuous.

The proof of this lemma is obvious.

THEOREM. 1.1. (Peano) (Existence). If f is continuous in D, then for any  $(t_0, x_0) \in D$ , there is at least one solution of (1.1) passing through  $(t_0, x_0)$ .

PROOF. Suppose  $\alpha$ ,  $\beta$  are positive numbers chosen so that the closed rectangle  $B(\alpha, \beta, t_0, x_0) = B(\alpha, \beta) = \{(t, x) : t \in I_\alpha, |x - x_0| \le \beta\}$ ,  $I_\alpha = I_\alpha(t_0) = I_\alpha(t_0)$ 

it:  $|t - t_0| \le \alpha$ , belongs to D. Let  $M = \sup\{|f(t, x)|, (t, x) \in B(\alpha, \beta)\}$ . Choose  $\bar{\alpha}$ ,  $\bar{\beta}$  so that  $0 < \bar{\alpha} \le \alpha$ ,  $0 < \bar{\beta} \le \beta$ ,  $M\bar{\alpha} \le \bar{\beta}$  and define the set  $\mathscr{A} = \mathscr{A}(\bar{\alpha}, \bar{\beta})$  of functions  $\phi$  in  $\mathscr{C}(I_{\bar{\alpha}}, R^n)$  which satisfy  $\phi(t_0) = x_0$ ,  $|\phi(t) - x_0| \le \bar{\beta}$  for all t in  $I_{\bar{\alpha}}$ . From Chapter 0 the set  $\mathscr{A}$  is convex, closed and bounded.

For any  $\phi$  in  $\mathscr A$  define the function  $T\phi$  by the relation

$$T\phi(t) = x_0 + \int_{t_0}^t f(s, \phi(s)) ds, \quad t \in I_{\tilde{\alpha}},$$

From Lemma 1.1 finding fixed points of T is equivalent to solving the above initial value problem for (1.1). We now apply the Schauer fixed point theorem to assert the existence of a fixed point of T in  $\mathscr{A}$ .

Obviously  $T\phi$ ,  $\phi$  in  $\mathscr{A}$ , is in  $\mathscr{C}(I_{\bar{\alpha}}, R^n)$  and  $T\phi(t_0) = x_0$ . Also, for  $t \in I_{\bar{\alpha}}$ ,

$$\begin{split} |T\phi(t)-x_0| & \leq \left|\int_{t_0}^t |f(s,\,\phi(s))|\;ds\right| \leq M\,|t-t_0| \\ & \leq M\bar{\alpha} \leq \bar{\beta} \end{split}$$

since  $B(\bar{\alpha}, \bar{\beta}) \subset B(\alpha, \beta)$ . Thus  $T: \mathcal{A} \to \mathcal{A}$ . Also

$$\left|T\phi(t)-T\phi(t)\right| \leq \left|\int_{\bar{t}}^{t} \left|f(s,\,\phi(s))\right|\,ds\,\right| \leq M\,|t-\bar{t}|$$

for all t, t in  $I_{\tilde{\alpha}}$ . This implies the set  $T(\mathscr{A})$  is an equicontinuous family and therefore the closure of  $T(\mathscr{A})$  is compact.

Finally, for any  $\phi$ ,  $\bar{\phi}$  in  $\mathscr{A}$ , it follows from the uniform continuity of f(t, x) on  $B(\alpha, \beta)$  that for any  $\varepsilon > 0$  there is a  $\delta > 0$  such that

$$|T\phi(t) - T\bar{\phi}(t)| \leq \left| \int_{t_0}^t \left| f(s, \phi(s)) - f(s, \bar{\phi}(s)) \right| ds \right| \leq \varepsilon \bar{\alpha},$$

for all t in  $I_{\bar{\alpha}}$  provided that  $|\phi(s) - \bar{\phi}(s)| \leq \delta$  for all s in  $I_{\bar{\alpha}}$ . But this is precisely the statement that T is a continuous mapping; that is, for any  $\varepsilon > 0$ , there is a  $\delta > 0$  such that  $|T\phi - T\bar{\phi}| \leq \varepsilon \bar{\alpha}$  if  $|\phi - \bar{\phi}| \leq \delta$ .

All of the conditions of the Schauder theorem are satisfied and we can assert the existence of a fixed point of  $\mathscr{A}$ . This completes the proof of the theorem.

COROLLARY 1.1. If U is a compact set of D,  $U \subset V$ , an open set in D with the closure  $\overline{V}$  of V in D, then there is an  $\alpha > 0$  such that, for any initial value  $(t_0, x_0) \in U$ , there is a solution of (1.1) through  $(t_0, x_0)$  which exists at least on the interval  $t_0 - \alpha \le t \le t_0 + \alpha$ .

PROOF. One merely repeats the proof of Theorem 1.1 with the further restriction on  $\bar{\alpha}$ ,  $\bar{\beta}$  to ensure that  $B(\bar{\alpha}, \bar{\beta}, t_0, x_0) \subset V$  for all  $(t_0, x_0) \in U$ .

Other proofs of the Peano theorem can be given without using the Schauder theorem. We illustrate the idea for one special construction, the Euler method of numerical analysis. This method consists of dividing the interval  $I_{\alpha} = \{t \colon |t-t_0| \le \alpha\}$  into equal segments of length h and then on each of these small segments approximating the "solution" by a straight line. More specifically, for a given h, define the function  $\phi^h$  on  $I_{\alpha}$  by

$$\phi^h(t) = x_0 + f(t_0, x_0)(t - t_0), \qquad t_0 \le t \le t_0 + h,$$
  $\phi^h(t) = \phi^h(t_0 + h) + f(t_0 + h, \phi^h(t_0 + h))(t - t_0 - h), \qquad t_0 + h \le t \le t_0 + 2h,$ 

and so forth. One may have to choose  $\alpha$  small in order for  $(t, \phi^h(t))$  to be in D. Pictorially, we will have a polygonal function defined which for h small should approximate a solution of (1.1) if it exists. One now chooses a sequence  $\{h_k\}$  such that  $h_k \to 0$  as  $k \to \infty$  and uses the Ascoli-Arzela theorem to show that a subsequence of the sequence  $\phi^{h_k}$  converges to a solution of (1.1).

EXERCISE 1.1. Supply all details of the proof of the Peano theorem of existence using polygonal line segments.

EXERCISE 1.2. State an implicit function theorem whose validity will be implied by the existence Theorem 1.1.

#### I.2. Continuation of Solutions

If  $\phi$  is a solution of a differential equation on an interval I, we say  $\hat{\phi}$  is a continuation of  $\phi$  if  $\hat{\phi}$  is defined on an interval  $\hat{I}$  which properly contains I,  $\hat{\phi}$  coincides with  $\phi$  on I and  $\hat{\phi}$  satisfies the differential equation on  $\hat{I}$ . A solution  $\phi$  is noncontinuable if no such continuation exists; that is, the interval I is the maximal interval of existence of the solution  $\phi$ .

LEMMA 2.1. If D is an open set in  $R^{n+1}$ ,  $f: D \to R^n$  is continuous and bounded on D, then any solution  $\phi(t)$  of (1.1) defined on an interval (a, b) is such that  $\phi(a+0)$  and  $\phi(b-0)$  exist. If  $f(b, \phi(b-0))$  is or can be defined so that f(t, x) is continuous at  $(b, \phi(b-0))$ , then  $\phi(t)$  is a solution of (1.1) on (a, b]. The same remark applies to the left endpoint a.

PROOF. We first show that the limits  $\phi(a+0)$ ,  $\phi(b-0)$  exist. For any  $t_0$  in (a, b),

$$\phi(t) = \phi(t_0) + \int_{t_0}^{t} f(s, \phi(s)) ds, \quad a < t < b,$$

and, for  $a < t_1 \le t_2 < b$ ,

$$|\phi(t_2) - \phi(t_1)| \le \int_{t_1}^{t_2} |f(s, \phi(s))| ds \le M(t_2 - t_1),$$

where M is a bound off (t, x) on D. Therefore ¢(t2) - 0(t1) - 0 as ti, t2 --\* a + 0, which implies (a + 0) exists. A similar argument shows that 0(b - 0) exists.

The last conclusion of the lemma is obvious from the integral equation for 0.

THEOREM 2.1. If D is an open set in Rn+I, f : D -> Rn is continuous and 0(t) is a solution of (1.1) on some interval, then there is a continuation of 0 to a maximal interval of existence. Furthermore, if (a, b) is a . maximal interval of existence of a solution x of (1.1), then (t, x(t)) tends to the boundary of D as t -\*a and t -\* b.

PROOF. Suppose x(t) is a solution of (1.1) on an interval I. If I is not a maximal interval of existence, then x can be extended to an interval properly containing I f Therefore, we may assume I is closed on one end, say to the right. We first show that x can be extended to a maximal right interval of existence and, therefore,, may assume that I = [a, b] and that x has no extension over [a, co). The proof of the extension to the left is very similar.

Suppose U is a compact set of D, U c V, an open set in D with the closure V of V in D. From Corollary 1.1 for any initial value in U there is a solution of (1.1) existing over an interval of length a depending only on U, V and the bound of f on V. Therefore, if x(t), a < t< b, belongs to U, then there is an extension of x to an interval [a, b + a]. Since U is compact, one can continue this process a finite number of times to conclude there is an extension of x(t) to an interval [a, bu] such that (ba, x(bu)) does not belong to U.

Now choose a sequence V. of open sets in D such that Un 1 Vn = D, Vn closed bounded, 1% c Vn+i for n = 1, 2, .... For each Vn, there is a monotone increasing sequence {bn} constructed as above so that the solution x(t) of (1.1) on [a, b] has an extension to the interval [a, bn] and (ba, x(bn)) is not in Vn . Since the bn are bounded above, let co = limn. bn . It is clear that x has been extended to the interval [a, co) and cannot be extended any further since the sequence (bk, x(bk)) is either unbounded or has a limit point on the boundary of the domain of definition of f.

If w = -, the last assertion in the theorem is trivial. Suppose w is finite, U is a compact set of D and there is a sequence (tk,x(tk)),y in R",(w,y) in U, such that tk - w, x(tk) - y ask -> -. The fact that f is bounded in a neighborhood of (w, y) implies x is uniformly continuous on [a, w) and x(t) -\*y as t - c o-. Thus, there is an extension of x to the interval [a, co + a]. Since w + a > co, this is a contradiction and shows there is a tU such that (t,x(t)) is not in U for tp < t < w. Since Uis ap arbitrary compact set, this proves (t,x(t)) tends to the boundary of D. The proof of the theorem is complete.

EXERCISE 2.1. For t, x scalars, give an example of a function f (t, x) which is defined and continuous on an open bounded connected set D and

yet not every noncontinuable solution  $\phi$  of (1.1) defined on (a, b) has  $\phi(a + 0)$ ,  $\phi(b - 0)$  existing.

The above continuation theorem can be used in specific examples to verify that a solution is defined on a large time interval. For example, if it is desired to show that a solution is defined on an interval  $[t_0, \infty)$ , it is sufficient to proceed as follows. If the function f(t, x) is continuous for t in  $(t_1, \infty)$ ,  $t_1 < t_0$ ,  $|x| < \alpha$ , and one can by some means ascertain that a certain solution x(t) must always satisfy  $|x(t)| \le \beta < \alpha$  for all values of  $t \ge t_0$  for which x(t) is defined, then necessarily x(t) is defined on  $[t_0, \infty)$ . In fact, choose any  $T \ge t_0$  and  $\gamma$  such that  $\beta < \gamma < \alpha$  and define the rectangle  $D_1$  as  $D_1 = \{(t, x): t_0 \le t \le T, |x| \le \gamma\}$ . Then f(t, x) is bounded on  $D_1$  and the continuation theorem implies that the solution x(t) can be continued to the boundary of  $D_1$ . But  $\gamma > \beta$  implies that x(t) must reach this boundary by reaching the face of the rectangle defined by t = T. Therefore x(t) exists for  $t_0 \le t \le T$ . Since T is arbitrary, this proves the assertion.

#### I.3. Uniqueness and Continuity Properties

A function f(t, x) defined on a domain D in  $R^{n+1}$  is said to be <u>locally lipschitzian</u> in x if for any closed bounded set U in D there is a  $k = k_U$  such that  $|f(t, x) - f(t, y)| \le k |x - y|$  for (t, x), (t, y) in U. If f(t, x) has continuous first partial derivatives with respect to x in D, then f(t, x) is locally lipschitzian in x.

If f(t, x) is continuous in a domain D, then the fundamental existence theorem implies the existence of at least one solution of (1.1) passing through a given point  $(t_0, x_0)$  in D. Suppose, in addition, there is only one such solution  $x(t, t_0, x_0)$  through a given  $(t_0, x_0)$  in D. For any  $(t_0, x_0) \in D$ , let  $(a(t_0, x_0), b(t_0, x_0))$  be the maximal interval of existence of  $x(t, t_0, x_0)$  and let  $E \subset \mathbb{R}^{n+2}$  be defined by

$$E = \{(t, t_0, x_0) : a(t_0, x_0) < t < b(t_0, x_0), (t_0, x_0) \in D\}.$$

The trajectory through  $(t_0, x_0)$  is the set of points in  $\mathbb{R}^{n+1}$  given by  $(t, x(t, t_0, x_0))$  for t varying over all possible values for which  $(t, t_0, x_0)$  belongs to E. The set E is called the domain of definition of  $x(t, t_0, x_0)$ .

The basic existence and uniqueness theorem under the hypothesis that f(t, x) is locally lipschitzian in x is usually referred to as the *Picard-Lindelöf* theorem. This result as well as additional information is contained in

THEOREM 3.1. If f(t, x) is continuous in D and locally lipschitzian with respect to x in D, then for any  $(t_0, x_0)$  in D, there exists a *unique* solution  $x(t, t_0, x_0)$ ,  $x(t_0, t_0, t_0, x_0) = x_0$ , of (1.1) passing through  $(t_0, x_0)$ . Furthermore,

the domain E in Rn+2 of definition of the function x(t, to, xo) is open and x(t, to, xo) is continuous in E.

PROOF. Define Ia = Ia(to) and B(a, f, to, xo) as in the proof of Theorem 1.1. For any given closed bounded subset U of D choose positive a, P so that B(a, S, to, xo) belongs to D for each (to, xo) in U and if

$$V = \bigcup \{B(\alpha, \beta, t_0, x_0); (t_0, x_0) \text{ in } U\},$$

then the closure of V is in D. Let M = sup{I f (t, x) I , (t, x) in V} and let k be the lipschitz constant of f (t, x) with respect to x on V. Choose &, P so that 0 < & < a, 0 < P, M& <\_ P, k& < 1 and let F = {0 in 6(Ia(0), Rn): 0(0) = 0, 1O(t)I for tin la(0)}. For any 0 in ,F, define a continuous function To taking Ia(0) into Rn by

(3.1) 
$$T\phi(t) = \int_{t_0}^{t+t_0} f(s, \phi(s-t_0) + x_0) \, ds, t \text{ in } I_{\tilde{\alpha}}(0).$$

By Lemma 1.1, the fixed points of T in F coincide with the solutions x(t) = 4(t - to) + xo of (1.1) which pass through (to, xo) and are such that (t, x(t)) is in B(&, P, to, xo). Obviously, TO(0) = 0 and it is easy to see that TO(t)[< M& < \$ for all t in Ia(0). Therefore, TF c ,F. Also, I TO(t) - Tc(t) I < k& JO - J for tin Ia(0) or ITO - k& I ¢ -. Since k& < 1, T is a contraction mapping of .F into ,F. Since F is closed, there is a unique fixed point 9c(t, to, xo) of T in F and therefore there is a unique solution of (1.1) passing through (to, xo) and such that (t, x(t)) belongs to B(&, 9, to, xo).

If the mapping T is considered as a function of (to, xo); that is, T = T (to, X0) , then the above argument shows that T (to, xo) is a uniform contraction on . for (to, xo) in U. Therefore, to, xo) is continuous in (to, xo) from Theorem 0.3.2. This means q(t, to, xo) is continuous in to, xo uniformly with respect to t. But ¢(t, to, xo) is obviously continuous in t and therefore O(t, to, xo) is jointly continuous in (t, to, xo) for t in Ia(0), (to, xo) in U. Finally, the function x(t, to, xo) = O(t - to, to, xo) + xo is a continuous function of (t, to, xo) for tin Ia(to), (to, xo) in U.

The above proof of local uniqueness implies global uniqueness. In fact, if there exist two solutions x(t), y(t) of (1.1) with x(to) = xo, y(to) = yo and a number s such that x(s) = y(s) and, in any neighborhood of s, there exist an s such that x(s) y(s), then we can enclose the trajectories defined by x(t), y(t) for t in a neighborhood of s in a compact set U contained entirely in D. The above proof shows there is a unique solution of (1.1) passing through any point in U. This is a contradiction.

Now suppose (s, to, xo) is any given point in the domain of definition E of x(s, to, xo). For ease in notation suppose s >\_ to. The case s < to is treated in the same manner. This implies the closed set U = {(t, x(t, to, x0), to < t< s } belongs to E. Therefore, we can apply the previous results to see that x(t, , , )

is a continuous function of (t, , q) for It - fI < a, (6, -q) in U. There exists an integer k such that to + k& > s >\_ to + (k - 1)&. From uniqueness, we have x(t + to + &, to, xo) = x(t + to + &, to + &, x(to + a, to, xo)) for any t. But the previous remarks imply this function is continuous for Itl < a. Therefore, x(e, to, xo) is continuous for 16 -toI <\_ 2«, (to, xo) in D as long as (6, to, xo) is in E. An obvious induction argument proves the continuity of x(s, to, xo) at s. The previous argument also implies E is open. This proves the theorem.

THEOREM 3.2. If in addition to the hypotheses of Theorem 3.1 the function f =f (t, x, A) depends upon a parameter A in a closed set G in Rk, is continuous for (t, x) in D, A in G, and has a local lipschitz constant with respect to x independent of A in G, then for each (to, xo) in D, A in 0, there is a unique solution x(t, to, xo, A), x(to, to, xo, A) = xo, passing through (to, xo) and it is a continuous function of (t, to, xo, A) in its domain of definition.

PROOF. The proof is essentially the same as the proof of Theorem 3.1 except one chooses M = sup{ I f (t, x, A )1 : (t, x, A) in V x GI} and k independent of A to be a local lipschitz constant with respect to x on V x GI, where GI is an arbitrary closed bounded set in G.

Since the contraction principle was used in Theorems 3.1 and 3.2 to prove the local existence and uniqueness of the solution passing through (to, xo) the solution can be obtained by the method of successive approximations

(3.2) 
$$x^{(n+1)} = Tx^{(n)}, \qquad n = 0, 1, 2, \dots,$$
 
$$Tx(t) = x_0 + \int_{t_0}^t f(s, x(s)) ds, \qquad |t - t_0| \le \bar{\alpha},$$

where x(0) is an arbitrary continuous function taking the interval It - tol <\_\_ a into Rn with I x(o) (t) - xo I < g for I t - to I < a. The constants a, g were chosen so that M& <\_ \$ and kP < 1 where M and k were bounds on f (t, x) and its lipschitz constant with respect to x over a certain compact set. An obvious choice for x(o)(t) is the constant function xo. Now, if one works directly with the successive approximations (3.2), one can prove the iterations converge and the equation (1.1) has a unique solution on the interval It -to I < & under only the assumption M& < g with the restriction k& < 1 being unnecessary. This makes it appear that the contraction principle is not as effective as successive approximations whereas we implied in Chapter 0 that this principle was introduced so as to replace successive approximations. The discrepancy is resolved by simply observing there are many equivalent norms on the space of continuous functions satisfying Ix(t) - xoI for t in [to, to + &]. In fact, with the constants as above, the norm defined by

$$|x| = \sup_{t_0 \le t \le t_0 + \overline{\alpha}} \{e^{-2k(t-t_0)}|x(t)|\},$$

is equivalent to the supremum norm used earlier. In this norm, one shows easily that T is a contraction only under the assumption  $M\bar{\alpha} \leq \bar{\beta}$ , which is the same result obtained by successive approximations. How do you resolve the above discrepancy on  $[t_0 - \bar{\alpha}, t_0]$ ?

Another remark on successive approximations is the fact that one can obtain convergence of the sequence defined by (3.2) for any initial  $x^{(0)}$  satisfying appropriate bounds. The sequence obviously would converge more rapidly by a more clever choice of  $x^{(0)}(t)$  depending upon f since choosing  $x^{(0)}(t)$  as the solution itself would yield the fixed point in one iteration. Effective use of such a procedure would require tremendous ingenuity.

EXERCISE 3.1. Prove directly that the sequence of successive approximations (3.2) converges for  $M\bar{\alpha} \leq \bar{\beta}$  where M is a bound for f on  $\{(t, x): |t - t_0| \leq \bar{\alpha}, |x - x_0| \leq \bar{\beta}\}.$ 

In the following, we need other results on the dependence of solutions on parameters and initial data.

THEOREM 3.3. If  $f(t, x, \lambda)$  has continuous first derivatives with respect to x,  $\lambda$  for  $(t, x) \in D$ ,  $\lambda$  in an open set  $G \subset R^k$ , then the solution  $x(t, t_0, x_0, \lambda)$ ,  $x(t_0, t_0, x_0, \lambda) = x_0$ , of

$$\dot{x} = f(t, x, \lambda),$$

is continuously differentiable with respect to t,  $t_0$ ,  $x_0$ ,  $\lambda$  in its domain of definition. The matrix  $\partial x(t, t_0, x_0, \lambda)/\partial \lambda$ ,  $\partial x(t_0, t_0, x_0, \lambda)/\partial \lambda = 0$ , satisfies the matrix differential equation

$$(3.4) \qquad \dot{y} = \frac{\partial f(t, x(t, t_0, x_0, \lambda), \lambda)}{\partial x} y + \frac{\partial f(t, x(t, t_0, x_0, \lambda), \lambda)}{\partial \lambda}.$$

The matrix  $\partial x(t, t_0, x_0, \lambda)/\partial x_0$ ,  $\partial x(t_0, t_0, x_0, \lambda)/\partial x_0 = I$ , the identity, satisfies the linear variational equation,

(3.5) 
$$\dot{y} = \frac{\partial f(t, x(t, t_0, x_0, \lambda), \lambda)}{\partial x} y.$$

Furthermore,

(3.6) 
$$\frac{\partial x(t, t_0, x_0, \lambda)}{\partial t_0} = -\frac{\partial x(t, t_0, x_0, \lambda)}{\partial x_0} f(t_0, x_0, \lambda).$$

**PROOF.** As in Theorem 3.2, we apply Theorem 3.2, Chapter 0. If  $\gamma = (x_0, \lambda)$ , and  $T = T_{\gamma}$  is defined by (3.1), then we must compute the derivatives  $A(\gamma, \phi)$ ,  $B(\gamma, \phi)$  of  $T_{\gamma}\phi$  with respect to  $\gamma$ ,  $\phi$ , respectively. One shows easily that  $A(\gamma, \phi)$  can be represented by the  $n \times (n + k)$  matrix

$$A(\gamma, \phi)(t) = \left[ \int_{t_0}^{t_0+t} \left( \frac{\partial f(s, \phi(s-t_0) + x_0, \lambda)}{\partial x} \right) ds, \right. \\ \left. \int_{t_0}^{t_0+t} \left( \frac{\partial f(s, \phi(s-t_0) + x_0), \lambda}{\partial \lambda} \right) ds \right],$$

and the differential B(y, O)o is given by

$$[B(\gamma,\phi)\psi](t)=\int_{t_0}^{t_0+t}rac{\partial f(s,\;\phi(s-t_0)+x_0\,,\,\lambda)}{\partial x}\,\psi(s)\;ds.$$

As in the proof of-Theorem 3.2, the constants M, k are chosen as before relative to the set V x GI with GI a closed bounded set in G. The proof of the differentiability of 0(t, to, xo, A) with respect to xo, A now proceeds exactly as in the proof of Theorem 3.1. The function x(t, to, xo 0(t - to, to, xo, A) + xo is obviously differentiable in (t, xo, A).

Knowing the differentiability immediately implies relations (3.4) and (3.5). To obtain relation (3.6) observe that uniqueness of the solution implies x(t, to, xo, A) = x(t, to + h, x(to + h, to, X0, A), A) for any h sufficiently small since at to + h, these two functions satisfy the equation and take on the same values. Therefore,

$$x(t, t_0 + h, x_0, \lambda) - x(t, t_0, x_0, \lambda)$$
  
=  $x(t, t_0 + h, x_0, \lambda) - x(t, t_0 + h, x(t_0 + h, t_0, x_0, \lambda), \lambda)$ 

and this implies x(t, to, xo, A) is differentiable in to and relation (3.6). The proof of the theorem is complete.

By repeated application of the above theorem, one can obtain higher order derivatives of x(t, to, xo, A) under appropriate hypotheses of f.

EXERCISE 3.2. If f (t, x) has continuous partial derivatives with respect to x up through order k, show that the solution x(t, to, xo), x(to, to, xo) = xo, of (1.1) has continuous derivatives of order k with respect to xo. Find the differential equation for the jth derivatives with respect to xo and observe that the Taylor series for x(t, to, y) in y in a neighborhood of xo is obtained by solving only nonhomogeneous linear equations.

EXERCISE 3.3. If f (t, x) is analytic in x in a neighborhood of xo, show there is an interval around to such that the function x(t, to, xo) of Exercise 3.2 is analytic in a neighborhood of xo.

EXERCISE 3.4. If f (t, x, A) has continuous partial derivatives with respect to x, A up through order k, show that the solution x(t, to, xo , A), x(to , to, xo, A) = xo, of (3.3) has continuous derivatives of order k with respect to xo, A. Find the differential equations for the partial derivatives with respect to A. Discuss the determination of the Taylor series in the neighborhood of some point.

EXERCISE 3.5. As in Exercise 3.2, discuss the analyticity properties of x(t, to, xo, A) in A when f (t, x, A) satisfies some analyticity conditions.

EXERCISE 3.6. Show that the solutions of the equation x = (A(t) + AB(t))x where IB(t)1, I A (t) I are continuous and bounded are entire functions of A. Can you generalize your result?

EXERCISE 3.7. Suppose f (t, x, y) is continuous and has continuous first derivatives with respect to x, y for 0 < t < 1, x, y c- (- oo, 00), and the boundary value problem

$$\ddot{x} = f(t, x, \dot{x}), \qquad x(0) = a, \qquad x(1) = b,$$

has a solution 0(t), 0 <\_ t < 1. If of (t, x, y)/ax > 0 for t e [0, 1] and all x, y, prove there is an e > 0 such that the boundary value problem

$$\ddot{x} = f(t, x, \dot{x}), \qquad x(0) = a, \qquad x(1) = \beta,$$

has a solution for 0 < t < 1 and P - b1 e. Hint: Consider the solution 0(t, a) of the initial value problem

$$\ddot{x} = f(t, x, \dot{x}), \qquad x(0) = a, \qquad \dot{x}(0) = \alpha,$$

and let 0(t, ao) = 0(t). For a - ao sufficiently small, 0(t, a) exists for 0< t < 1. If u(t) = as/i(t, ao)/aa, then

$$|\ddot{u} - \frac{\partial f(t, \phi(t), \dot{\phi}(t))}{\partial y} \dot{u} - \frac{\partial f(t, \phi(t), \dot{\phi}(t))}{\partial x} u = 0,$$

with u(0) = 0, it(O) =1. Show that u is monotone nondecreasing and, thus, u(1) > 0. Use the implicit function theorem to solve s,i(l, a) - P = 0 for a as a function of P.

Equation (3.5) is called the linear variational equation for the following reason. If x(t) = z(t) + x(t, to, xo, A) is a solution of (3.3), then

$$\dot{z}(t) + \frac{\partial x(t, t_0, x_0, \lambda)}{\partial t} = f(t, z(t) + x(t, t_0, x_0, \lambda), \lambda).$$

This implies

$$\begin{split} \dot{z}(t) &= f(t, z(t) + x(t, t_0, x_0, \lambda), \lambda) - f(t, x(t, t_0, x_0, \lambda), \lambda) \\ &= \frac{\partial f(t, x(t, t_0, x_0, \lambda), \lambda)}{\partial x} z(t) + o(|z(t)|) \end{split}$$

as Iz(t) I approaches zero. Equation (3.5) therefore represents the first approximation to the variation z(t) of the true solution of (3.2) from a given solution x(t, to, xo, A). The linear variational equation is obtained by neglecting the terms of order higher than the first in the equation for z.

The conclusions of Theorems 3.1 and 3.2 concerning the continuity properties of x(t, to, xo, A) are valid under much weaker hypotheses than

stated. In fact, if we assume the uniqueness of the solution x(t, to, xo) (which is implied when you have a local lipschitz condition in x) then one can prove directly that it must be continuous in (t, to, xo). We need one such result in the study of differential inequalities which we now formulate.

LEMMA 3.1. Suppose {fn}, n = 1, 2, ... , is a sequence of functions defined and continuous on an open set D in Rn+I with limn- fn =fo uniformly on compact subsets of D. Suppose (tn, xn) is a sequence of points in D converging to (to , xo) in D as n oc and let O ,(t), n = 0, 1 , 2, ... , be a solution of the equation x = fn(t, x) passing through the point (tn, xn). If 00(t) is defined on [a, b] and is unique, then there is an integer no such that each an(t), n >\_ no, can be defined on [a, b] and converges to Oo(t) uniformly on [a, b].

PROOF. Let U be a compact subset of D which contains in its interior the set {(t, Oo(t), a t < b} and suppose I fol <M on U. Then necessarily Ifn I < M on U if n no where no is sufficiently large. Choosing a, 9 as in the proof of the basic existence theorem such that Ma < 9, one can be assured for n sufficiently large that all the On(t) are defined on [tn , to + &]. If [8, y] = nn [tn , to + &], then the fact that to to implies 8 < y. Also, all the 0. for n sufficiently large are defined on [8, y]. The sequence {din} is uniformly bounded and equicontinuous since I fn I < M. Therefore, there exists a subsequence which we label again as On which converges uniformly to a function 0 on [8, y]. Using the integral equation, we see that is Oo. Since every convergent subsequence of On on [8, y] must also converge to qo (by uniqueness of 00) it follows that On converges to 00 on [8, y]. Due to the compactness of the set {t, O(t)j, t in [a, b], one completes the proof by successively stepping intervals of length y - 8 until [a, b] is covered.

THEOREM 3.4. Suppose f (t, x, A) is a continuous function of (t, x, A) for (t, x) in an open set D and A in a neighborhood of A0 in RP. If x(t, to, xo, A0), x(to, to, xo, A0) = xo, is a solution of (3.3) on [a, b] and is unique, then there is a solution x(t, s, 71, A), x(s, s, -q, A) ='7, of (3.3) which is defined on [a, b] for all s, -q, A sufficiently near to, xo, A0 and is a continuous function of (t, s,,q, A) at (t, to, xo, A0)

PROOF. Lemma 3.1 implies that x(t, s, -q, A) is a continuous function of s, 77, A at to, xo, A0 uniformly with respect to t in [a, b]. Thus, for any s > 0 there is a 81 > 0 such that

$$\left|x(t,\,s,\,\eta,\,\lambda)-x(t,\,t_0\,,\,x_0\,,\,\lambda_0)
ight|<rac{arepsilon}{2}$$

if 1(8, 77, A) - (to, X0, A0) I < 81. Since x(t, to, xo, A0) is a continuous function

of t for tin [a, b], there is a 82 such that

$$|x(t, t_0, x_0, \lambda_0) - x(\tau, t_0, x_0, \lambda_0)| < \frac{\varepsilon}{2}$$

if 
$$|t-\tau| < \delta_2$$
. Let  $\delta = \min(\delta_1, \delta_2)$ . Then

$$|x(t, s, \eta, \lambda) - x(\tau, t_0, x_0, \lambda_0)|$$

$$\leq |x(t, s, \eta, \lambda) - x(t, t_0, x_0, \lambda_0)| + |x(t, t_0, x_0, \lambda_0) - x(\tau, t_0, x_0, \lambda_0)|$$

$$< \varepsilon,$$

provided that I (s, 71, A) - (to, xo, Ao) I + It - rI < S. This proves Theorem 3.4.

Under appropriate hypotheses, the solutions of differential equations define homeomorphisms of subsets of Rn into Rn. In fact, let us assume for any (to, xo) in D, the equation (1.1) has a unique solution x(t, to, xo) which is jointly continuous in (t, to', xo) in its domain of definition. If x(t, to, xo) exists on an interval [a, b], then there is a neighborhood U(xo) of xo for which the solution x(t, to, xI) exists for tin [a, b] and xI in U(xo). For fixed to and each tin [a, b], the function x(t, to, ) can be considered as a mapping Tt of U(xo) into a neighborhood of x(t, to, xo). The mapping Tt is one to one and continuous by hypothesis and Tt 1x\* = x(to, t, x\*). Therefore the inverse function is also continuous which implies Tt is a hoineomorphism.

We are now in a position to define a general solution of (1.1). Let U be an open connected set in Rn and 0: R X U - Rn be such that: (a) for any c in U, 0(t, c) is a solution of (1.1); (b) for any to in R, the mapping 0(to, ): U - . Rn is a homeomorphism on its range. Such a function 0 will be referred to as a (local) general solution of (1.1).

### 1.4. Continuous Dependence and Stability

Consider the equation z =f (t, x) with f (t, 0) = 0 for all tin (- oo, oo) and the function f (t, x) defined for all (t, x) in Rn+i. For any (to, xo) in Rn+I, we suppose this equation has a unique solution x(t, to, xo), x(to, to, xo) = xo, which is jointly continuous in (t, to, xo) in its region of definition. Since f (t, 0) = 0 for all t, it follows that x = 0 is a solution on (- oo, co). The hypothesis of continuous dependence implies. that given any real numbers to in (- oo, oo), T >\_ 0, there exists a 8(T) > 0 such that the solution x(t, to, xo), Ixo I < 8(T) exists on Ito, to + T]. Furthermore, I x(t, to, xo) I --0 uniformly in t on [to , to + T] as Ixol -\* 0. In other words, given any T > 0 and any.e > 0, there is a 8 = 8(s, T, to) such that the solution x(t, to, xo) exists on I = [to, to+T], Ix(t, to, xo)I <s on I provided that IxoI <8(e, T, to) (see the accompanying figure).

![](_page_35_Figure_2.jpeg)

Figure 1.4.2

Let us discuss in detail the meaning of continuous dependence on initial data for the equation z = x2. Choose to = 0 and let xo = c. A solution x(t, to, xo) = x(t, 0, c) of this equation is x(t, 0, c) \_ -c/(ct - 1). Uniqueness implies this is the solution with x(0) = c. It is clear that x(t, 0, c) is continuous in t, c in-the domain of definition of x(t, 0, c). Since x(t, 0, 0) = 0, this implies for any T > 0 and any e > 0, there is a 8 = 6(e, T) > 0 so that Ix(t, 0, c)I <e if I cI < 8. The largest value of 8 is 8/(1 - 8T) = e. As T increases, 8 must decrease and, in fact, 8 must approach zero as T -\* oo. This implies the continuity of x(t, 0, c) in c is not uniform with respect to t in the infinite interval 10, ool. For this equation, it is even true that no solution with x (O) = c > 0 exists on [0, oo .

Even though continuous dependence on parameters and initial data is important, it gives information only on finite intervals of time as the above remarks show. An even moreimxnnrta.nt nnncent is nnn4.innrnis de endence on initial data on infinite intervals of time. This is the concept oastabilitvj

in the remainder of this section we assume f smooth enough to ensure existence, uniqueness and continuous dependence on parameters.

Definitions. Suppose f : [0, oo) x Rn - Rn. Consider t =f (t, x), f (t, 0) - 0, t e [0, oo). The solution x = 0 is called L'aa.p u. o v stable. if for any e > 0 and any to >\_ 0, there is a 8 = 8(e, to) such that I xoI < 8 implies jx(t, to, xo) I < e for t e [to, oo). The solution x = 0 is uniformly stable if it is stable and 8 can be chosen independent of to >\_ 0. The solution x = 0 is called asl/mvtotically stable if it is stable and there exists a b = b(to) such that ixol < b implies- l x(t, to, xo) I -\*0 as t -moo. The solution x = 0 is 4niformly, asymvtotically stable if it is uniformly stable, b in the definition of s,srmptotic stability can be chosen independent of to >\_ 0, and for every rl > 0 there is a T(i) > 0 such that Ixol < b implies jx(t, to, xo)j <, if t >\_ to + T(-q). The solution x = 0 is unstable if it is not stable.

Pictorially, stability is the same as in the above diagram except the solution must remain in the infinite cylinder of radius e for t ? to.

We can discuss the stability and asymptotic stability of any other solution x(t) of the equation by replacing x by x + y and discussing the zero solution of the equation y =f (t, x + y) -f (t, x). The definitions of stability of an arbitrary solution t(t) are the same as above except with x replaced by x - x(t).

LEMMA 4.1. 1 If f is either independent of t or periodie in t, then the solution x = 0 of (1.1) being stable (asymptotically stable) implies the solution x =0 of (1.1) is uniformly stable (uniformly asymptotically stable).

### EXERCISE 4.1. Prove Lemma 4.1.

EXERCISE 4.2. Discuss the stability and asymptotic stability of every solution of the equations z = -x(1 - x), x + x = 0, and .x + 2-1[x2 + (x4 + 4x2)'/2]x = 0. The latter equation has the family of solutions x = c sin(ct + d) where c, d are arbitrary constants.

Does stability defined in the above way depend on to in the sense that a solution x = 0 may be stable at one value of to and not at another? The answer is no! For tl <\_ to, this follows immediately from continuity with respect to initial data. In fact, stability of x = 0 implies the existence of a 8(t0 , e) > 0 such that ixol < 8(to, e) implies jx(t, to, xo) < e, t >\_ to. Continuity with respect to initial data implies the existence of a 81 = 81(t1, e, to, S) > 0 so small that 1xl < 81(t1, e) implies Ix(t, ti, xl) < 8(to, e), t1 < t< to. Then ix(t, ti, xl)l < e fort >\_ t1, provided that 1xii <\_ 81(tl, e); that is, stability at t1. For tl >\_ to, it is not quite so obvious. Let V(ti, e) \_ {x in Rn: x = x(ti, to, xo) for xo in the open ball of radius 8(to, s) centered at zero}. Since the mapping x(tl, to, ) is a homeomorphism, there exists a 81(t1, e) such that {x: Ixj <\_ 81(t1, e)} e V(tl, E). With this 81(t1, s) we have jx(t, ti, xi) I < e for t > ti and 1xiI < 8(t1, e); that is, stability at t1.

EXERCISE 4.3. In the above definition of asymptotic stability of the solution x = 0, we have supposed that x = 0 is stable and solutions with initial. values neighborhood of zero approach zero as t ---> oo. Is it possible to have the latter property and also have the solution x = 0 unstable? Show this cannot happen if x is a scalar. Give an example in two dimensions where all solutions approach zero as t --> oo and yet the solution x = 0 is unstable. Is it possible to give- such an example in two dimensions for an equation whose right hand sides are independent of t?

It is not appropriate at this time to have a detailed discussion of stability, but we will continually bring out more of the properties of this concept.

#### I.5. Extension of the Concept of a Differential Equation

In Section 1.1, a differential equation was defined for continuous vector fields f. As an immediate consequence, the initial value problem for (1.1) is equivalent to the integral equation

(5.1) 
$$x(t) = x_0 + \int_{t_0}^{t} f(s, x(s)) ds.$$

For f continuous, any solution of this equation automatically possesses a continuous first derivative. On the other hand, it is clear that (5.1) will be meaningful for a more general class of functions f if it is not required that x have a continuous first derivative. The purpose of this section is to make these notions precise for a class of functions f.

Suppose D is an open set in  $\mathbb{R}^{n+1}$  and  $f: D \to \mathbb{R}^n$  is not necessarily continuous. Our problem is to find an absolutely continuous function x defined on a real interval I such that  $(t, x(t)) \in D$  for t in I and

$$\dot{x}(t) = f(t, x(t))$$

for all t in I except on a set of Lebesgue measure zero. If such a function x and interval I exist, we say x is a solution of (5.1). A solution of (5.1) through  $(t_0, x_0)$  is a solution x of (5.1) with  $x(t_0) = x_0$ . We will not repeat the phrase "except on a set of Lebesgue measure zero" since it will always be clear that this is understood.

Suppose D is an open set in  $R^{n+1}$ . We say that  $f: D \to R^n$  satisfies the Carathéodory conditions on D if f is measurable in t for each fixed x, continuous in x for each fixed t and for each compact set U of D, there is an integrable function  $m_U(t)$  such that

$$|f(t,x)| \leq m_U(t), \qquad (t,x) \in U.$$

For functions f which satisfy the Carathéodory conditions on a domain D, the conclusions of Sections 1 and 2 carry over without change. If the function f(t, x) is also locally Lipschitzian in x with a measurable Lipschitz function, then the uniqueness property of the solution remains valid. These results are stated below, but only the details of the proof of the existence theorem are given, since the other proofs are essentially the same.

THEOREM 5.1. (Carathéodory). If D is an open set in  $\mathbb{R}^{n+1}$  and f satisfies the Carathéodory conditions on D, then, for any  $(t_0, x_0)$  if D, there is a solution of (5.1) through  $(t_0, x_0)$ .

PROOF. Suppose  $\alpha$ ,  $\beta$  are positive numbers chosen so that the rectangle  $B(\alpha, \beta) = \{(t, x) : |t - t_0| \le \alpha, |x - x_0| \le \beta\}$  is in D. Let  $\dot{I}_{\alpha} = \{t : |t - t_0| \le \alpha\}$ ,

M = mB(a, d) , M(t) = Jto m(s) ds. Choose «, \$ so that 0 < « S a, 0 </ S I M(t) I < R, t e Ia . Let .sad be the set offunctions 0 in 9(Ia , Rn) which satisfy 4(to) = xo, Iq(t) - xo1 < g for all t in Ia . The set sad is a closed, bounded, convex subset of '(In , Rn).

For any 0 in sd, define the function To by the relation

$$T\phi(t) = x_0 + \int_{t_0}^t f(s, \phi(s)) ds, \qquad t \in I_{\tilde{\alpha}}.$$

The fixed points of T in d coincide with the solutions in d of (5.1). We now apply the Schauder theorem to prove the existence of a fixed point of T in s4.

For any 0 in sl, the operator T is well defined since f (s, q(s)) is integrable for 0 in d. Also, To(to) = x0, and Ti(t) is continuous for t e I&. Using (5.2), we have

$$\begin{aligned} |T\phi(t) - x_0| &\leq \left| \int_{t_0}^t |f(s, \phi(s))| \, ds \right| \\ &\leq \left| \int_{t_0}^t m(s) \, ds \right| \\ &= |M(t)| \leq \bar{\beta}, \end{aligned}$$

for all tin la . Therefore, T: d -\*

The operator T is continuous on sl. In fact, if 0. e A, 9n in ,4, then f (t, x) continuous in x for each fixed t implies f (t, 9n(t)) -- f (t, 0(t)) as n -\* oo for each tin 1, 2. Since If (t, 9n(t))I < m(t), the Lebesgue dominated convergence theorem implies

$$\int_{t_0}^t f(s, \, \phi_n(s)) \, ds \to \int_{t_0}^t f(s, \, \phi(s)) \, ds,$$

as n --> oc for each tin Ia. This proves the assertion.

For any ¢ in .l,

$$|T\phi(t) - T\phi(\tau)| \le |M(t) - M(\tau)|$$

for all t, r in Ia . Since M is continuous on Id, it is uniformly continuous and, thus, the set Tsar is an equicontinuous set of t(I-, Rn). It is also uniformly bounded, This proves T,d is relatively compact and, thus, T is completely continuous. The Schauder fixed point theorem implies the existence of a fixed point in .4 and the theorem is proved.

THEOREM 5.2. If D is an open set in Rn+l, f satisfies the Caratheodory conditions on D and 0 is a solution of (5.1) on some interval, then there is a continuation of 0 to a maximal interval of existence. Furthermore, if (a, b) is a maximal interval of existence of (5.1), then x(t) tends to the boundary of Dast --\* a andt--b.

PROOF. The proof is essentially the same as the proof of Theorem 2.1 and is left to the reader.

THEOREM 5.3. Suppose D is an open set in  $\mathbb{R}^{n+1}$ , f satisfies the Carathéodory conditions on D and for each compact set U in D, there is an integrable function  $k_U(t)$  such that

$$|f(t, x) - f(t, y)| \le k_U(t) |x - y|, \quad (t, x) \in U, \quad (t, y) \in U.$$

Then, for any  $(t_0, x_0)$  in U, there exists a *unique* solution  $x(t, t_0, x_0)$  of (5.1) passing through  $(t_0, x_0)$ . The domain E in  $R^{n+2}$  of definition of the function  $x(t, t_0, x_0)$  is open and  $x(t, t_0, x_0)$  is continuous in E.

PROOF. This proof is essentially the same as the proof of Theorem 3.1 and the details are left to the reader. One only needs to choose M(t) as in the proof of Theorem 5.1, let  $K(t) = \int_{t_0}^t k_{B(\alpha,\beta)}(s) ds$  and choose  $\bar{\alpha}$ ,  $\bar{\beta}$  so that  $0 < \bar{\alpha} \leq \alpha$ ,  $0 < \bar{\beta} \leq \beta$ ,  $|M(t)| \leq \bar{\beta}$ , K|(t)| < 1 for  $t \in I_{\bar{\alpha}}$ .

Any linear system

$$\dot{x} = A(t)x + h(t),$$

where A(t) is an  $n \times n$  matrix, h(t) is an n-vector whose elements are integrable on every finite interval satisfies the Carathéodory conditions and (5.3). Therefore, the initial value problem has a unique solution.

#### I.6. Differential Inequalities

Let  $D_r$  denote the right hand derivative of a function. If  $\omega(t, u)$  is a scalar function of the scalars t, u in some open connected set  $\Omega$ , we say a function v(t),  $a \le t \le b$ , is a solution of the differential inequality

$$(6.1) D_r v(t) \leq \omega(t, v(t))$$

on [a, b) if v(t) is continuous on [a, b) and has a right hand derivative on [a, b) that satisfies (6.1).

**Lemma 6.1.** If x(t) is a continuously differentiable *n*-vector function on  $a \le t \le b$ , then  $D_r|x(t)|$  exists on  $a \le t < b$  and  $|D_r(|x(t)|)| \le |\dot{x}(t)|$ ,  $a \le t < b$ .

PROOF. For any two n-vectors x, u and  $0 < \theta \le 1$ , h > 0, we have

$$|x + \theta hu| - |\theta x + \theta hu| \le (1 - \theta)|x|$$
.

Therefore,

$$\frac{|x+\theta hu|-|x|}{\theta h} \leq \frac{|x+hu|-|x|}{h};$$

that is, the difference quotient

$$\frac{|x+hu|-|x|}{h}$$

is a nondecreasing function of h. Furthermore, this difference quotient is bounded below by -|u|. Consequently,

$$\lim_{h\to 0^+} \frac{|x+hu|-|x|}{h}$$

exists.

If x(t) is continuously differentiable for  $a \le t \le b$ , then this latter relation implies

$$\lim_{h \to 0^+} \frac{|x(t) + h\dot{x}(t)| - |x(t)|}{h}$$

exists. Since

$$\begin{split} |[|x(t+h)| - |x(t)|] - [|x(t) + h\dot{x}(t)| - |x(t)|]| \\ &= |[|x(t+h)| - |x(t) + h\dot{x}(t)|]| \\ &\leq |x(t+h) - x(t) - h\dot{x}(t)| = o(h) \end{split}$$

as  $h \to 0^+$ , it follows that  $D_r(|x(t)|)$  exists and

$$D_r|x(t)| = \lim_{h\to 0^+} \frac{|x(t) + h\dot{x}(t)| - |x(t)|}{h}.$$

It is clear that  $|D_r(|x(t)|)| \leq |\dot{x}(t)|$  and the lemma is proved.

The same proof also shows that the conclusion of Lemma 6.1 is valid for absolutely continuous functions in the sense that  $D_r(|x(t)|)$  exists and satisfies  $|D_r(|x(t)|)| \le |\dot{x}(t)|$  almost everywhere for  $a \le t \le b$ .

THEOREM 6.1. Let  $\omega(t, u)$  be continuous on an open connected set  $\Omega \subset \mathbb{R}^2$  and such that the initial value problem for the scalar equation

$$(6.2) \dot{u} = \omega(t, u)$$

has a unique solution. If u(t) is a solution of (6.2) on  $a \le t \le b$  and v(t) is a solution of (6.1) on  $a \le t < b$  with  $v(a) \le u(a)$ , then  $v(t) \le u(t)$  for  $a \le t \le b$ .

PROOF. Consider the family of equations

$$\dot{u} = \omega(t, u) + \frac{1}{n}$$

for  $n = 1, 2, \ldots$  We now apply Lemma 3.1 to (6.3).

If un(t) designates the solution of (6.3) with un(a) = u(a), then Lemma 3.1 implies there is an no such that un(t), n > no, is defined on [a, b] and un(t) -> u(t) uniformly on [a, b]. We show v(t) < un(t), for n >\_ no, a < t< b. If this is not so, then there exist t2 < tI in (a, b) such that v(t) > un(t) on t2 < t < t1, v(t2) = un(t2). Therefore, v(t) - v(t2) > un(t) - un(t2), t2 < t < tI, which implies

$$egin{align} D_{ au}v(t_2) & \geq \dot{u}_n(t_2) = \omega(t_2\,,\,u_n(t_2)) + rac{1}{n} \ & = \omega(t_2\,,\,v(t_2)) + rac{1}{n} \ & > \omega(t_2\,,\,v(t_2)), \end{split}$$

which is a contradiction. Consequently, v(t) < un(t) for t in [a, b], n >\_ no. Since un(t) > u(t) uniformly on [a, b], this proves the theorem.

COROLLARY 6.1. A solution of Dr v(t) < 0 on [a, b) is nonincreasing on [a, b).

COROLLARY 6.2. Suppose w(t, u) and u(t) are as in Theorem 6.1. If x(t) is a continuous n-vector function with a continuous first derivative on [a, b] such that I x(a)I < u(a), (t, Ix(t)j) e 0, a:5 t<\_ b, and

$$|\dot{x}(t)| \leq \omega(t, |x(t)|), \quad a \leq t \leq b,$$

then I x(t)I < u(t) on a< t< b.

PROOF. This is immediate from Lemma 6.1 and Theorem 6.1.

COROLLARY 6.3. Suppose w(t, u) satisfies the conditions of Theorem 6.1 for a < t < b, u >\_ 0, and let u(t) >\_ 0 be a solution of (6.2) on a < t < b. If f: [a, b) x Rn > Rn is continuous and

$$|f(t, x)| \leq \omega(t, |x|), \quad a \leq t < b, \quad x \in \mathbb{R}^n,$$

then the solutions of

$$\dot{x} = f(t, x), \quad |x(a)| \leq u(a),$$

exist on [a, b) and Ix(t)I < u(t), tin [a, b).

PROOF. From Corollary 6.2, I x(t)I < u(t) as long as x(t) exists. From Theorem 2.1, the solution x(t) can fail to exist on [a, b) only if there is a c, a < c < b, such that x(t) is defined on [a, c) and urn I x(t) I = oo as t -, c - 0. On the other hand, this is impossible since I x(t)I < u(t), t e [a, c) and tim u(t) exists as t > c - 0.

Notice that Corollary 6.3 gives existence of the solution on [a, b), as well as upper bounds on the solutions.

Another simple application of Corollary 6.2 yields

COROLLARY 6.4. Suppose D is an open connected set in  $\mathbb{R}^{n+1}$ ,  $f: D \to \mathbb{R}^n$  is continuous and f(t, x) is locally lipschitzian in x. If K is any compact set in D and L is the lipschitz constant of f in K, then

$$|x(t, t_0, x_0) - x(t, t_0, x_1)| \le e^{L(t-t_0)} |x_0 - x_1|$$

as long as the solutions  $x(t, t_0, x_0)$ ,  $x(t, t_0, x_1)$  of (1.1) are such that  $(t, x(t, t_0, x_0))$ ,  $(t, x(t, t_0, x_1))$  remain in K.

PROOF. If  $z(t) = x(t, t_0, x_0) - x(t, t_0, x_1)$ , then  $|\dot{z}(t)| \leq L|z(t)|$  as long as  $(t, x(t, t_0, x_0))$ ,  $(t, x(t, t_0, x_1))$  remain in K and Corollary 6.2 gives the result.

As a first illustration of the above results, we prove a result on existence in the large. Suppose  $f: (\alpha, \infty) \times \mathbb{R}^n \to \mathbb{R}^n$  is continuous

$$(6.4) |f(t,x)| \le \phi(t)\psi(|x|),$$

where  $\phi(t) \ge 0$  is continuous for all  $t > \alpha$  and  $\psi(u)$  is continuous for  $u \ge 0$  and positive for all u > 0. Suppose  $u(t, t_0, u_0)$ ,  $t_0 > \alpha$ , is a solution of  $\dot{u} = \phi(t)\psi(u)$ ,  $u(t_0) = u_0 > 0$  and this solution is unique for any  $u_0 > 0$ . If

$$\int_{0}^{\infty} \frac{du}{\psi(u)} = +\infty,$$

then the solution  $u(t, t_0, u_0)$  exists for all  $t > \alpha$ . In fact, u satisfies the equation

$$\int_{u_0}^u \frac{dv}{\psi(v)} = \int_{t_0}^t \phi(s) \ ds,$$

and if u did not exist for all  $t > \alpha$ , then the continuation theorem implies there would exist a  $\tau$  and a sequence  $\{t_n\}, t_n \to \tau$  as  $n \to \infty$  such that  $u(t_n) \to \infty$  as  $n \to \infty$ . But this is impossible since  $\int_{t_0}^{\tau} \phi < \infty$  and  $\int_{u_0}^{\infty} dv/\psi(v) = +\infty$ .

For any given  $x_0 \neq 0$  in  $\mathbb{R}^n$ , choose  $u_0 = |x_0|$  and for  $x_0 = 0$  choose any  $u_0 > 0$ . From Corollary 6.3, it follows that any solution

$$x(t, t_0, x_0), \quad x(t_0, t_0, x_0) = x_0, \quad t_0 > \alpha.$$

of  $\dot{x} = f(t, x)$  exists and satisfies  $|x(t, t_0, x_0)| \le u(t, t_0, u_0)$  on  $[t_0, \infty)$  provided f satisfies (6.4) and (6.5).

As a special case suppose that f(t, x) = A(t)x + h(t) where A(t), h(t) are continuous for all values of t. Then any solution of the linear equation

$$\dot{x} = A(t)x + h(t)$$

exists on  $(-\infty, \infty)$ . In fact,

$$\begin{aligned} |A(t)x + h(t)| &\leq |A(t)| |x| + |h(t)| \\ &\leq \max\{|A(t)|, |h(t)\}(|x| + 1) \\ &= \phi(t)\psi(|x|), \\ \psi(u) &= u + 1. \end{aligned}$$

Since  $\phi(t)$  is continuous and  $\int_{-\infty}^{\infty} du/\psi(u) = +\infty$ , we have the desired result.

Another interesting special case is when  $|f(t, x)| \le K|x|$  for all t in  $(-\infty, \infty)$  and x in  $\mathbb{R}^n$ . For  $\phi(t) = 1$  and  $\psi(u) = Ku$ , the above example shows that all solutions of  $\dot{x} = f(t, x)$  exist on  $(-\infty, \infty)$ .

For later reference, part of these results are summarized in

THEOREM 6.2. If  $f: (\alpha, \infty) \times \mathbb{R}^n \to \mathbb{R}^n$  is continuous, satisfies (6.4) and (6.5) and the solution of  $\dot{u} = \phi(t)\psi(u), u(t_0) = u_0 > 0, t_0 > \alpha$  exists and is unique in  $(\alpha, \infty)$ , then any solution of the equation (1.1) through  $(t_0, x_0)$  exists on  $(\alpha, \infty)$ . In particular, every solution of (6.6) exists on  $(-\infty, \infty)$  provided that A(t), h(t) are continuous.

As another illustration, we prove a simple result on stability. Suppose  $f: R^{n+1} \to R^n$  and there exists a continuous function  $\lambda(t)$ ,  $-\infty < t < \infty$ , such that  $x \cdot f(t, x) \leq -\lambda(t)x \cdot x$  where "·" denotes the scalar product of two vectors. Notice this implies f(t, 0) = 0. If we let  $|x|^2 = x \cdot x$  and suppose x is a solution of x = f(t, x) on an interval I containing  $t_0$ , then

$$\frac{d}{dt}|x|^2 = \frac{d}{dt}(x \cdot x) = 2x \cdot f(t, x) \leq -2\lambda(t)|x|^2.$$

If  $\omega(t, u) = -2\lambda(t)u$  and u is the solution of  $\dot{u} = \omega(t, u)$ ,  $u(t_0) = |x(t_0)|^2$ , then  $u(t) = \{\exp(-2\int_{t_0}^t \lambda(s) ds)\} |x(t_0)|^2$  exists for all t in  $(-\infty, \infty)$ . Therefore, Corollary 6.2 and the continuation theorem implies that the solution x(t) not only exists on I but exists for all t in  $(-\infty, \infty)$  and

$$|x(t)| \le \exp\left(-\int_{t_0}^t \lambda(s) \ ds\right) |x(t_0)|, \quad t \ge t_0.$$

If  $\lambda(t) \geq 0$ , then the solution x = 0 of  $\dot{x} = f(t, x)$  is stable and actually uniformly stable. If  $\lambda(t) \geq 0$  and  $\int_{t_0}^{\infty} \lambda(s) ds = +\infty$ , then the solution x = 0 is asymptotically stable.

EXERCISE 6.1. If  $\lambda(t) \ge 0$  and  $\int_{t_0}^{\infty} \lambda(s) ds = +\infty$  for all  $t_0$ , is the solution x = 0 of the previous discussion uniformly asymptotically stable? Discuss the case where  $\lambda(t)$  is not of fixed sign.

EXERCISE 6.2. Suppose f: Rn+1--> Rn is continuous and there exists a positive definite matrix B such that x Bf (t, x) < -A(t)x x for all t, x where A(t) is continuous for tin (- oo, oo). Prove that any solution of the equation z =f (t, x), x(to) = xo, exists on [to, oo) and give sufficient conditions for stability and asymptotic stability. (Hint: Find the derivative of the function V(x) = x Bx along solutions and use the fact that there is a positive constant a such that x Bx >\_ zx - x for all x.)

EXERCISE 6.3. Consider the equation x =f (t, x), If (t, x)I < 0(t) Ix) for all t, :c in R X R, f - 0(t) dt < oo.

- (a) Prove that every solution approaches a constant as t oo.
- (b) If, in addition,

$$|f(t, x) - f(t, y)| \le \phi(t)|x - y|$$
 for all  $x, y$ ,

prove there is a one to one correspondence between the initial values and the limit values of the solution.

(c) Does the above result imply anything for the equation

$$\dot{x} = -x + a(t)x, \qquad \int_{-\infty}^{\infty} |a(t)| dt < \infty$$
?

(Hint: Consider the transformation x = e-ty.)

(d) Does this imply anything about the system

$$\dot{x}_1=x_2\,,$$
  $\dot{x}_2=-x_1+a(t)x_1,\qquad \int^\infty |a(t)|\;dt<\infty,$ 

where xj, x2 are scalars?

EXERCISE 6.4. Consider the initial value problem

$$\ddot{z} + \alpha(z, \dot{z})\dot{z} + \beta(z) = u(t), \qquad z(0) = \xi, \qquad \dot{z}(0) = \eta,$$

with a(z, w), g,(z) continuous together with their first partial derivatives for all z, w, u continuous and bounded on (- oo, co), a > 0, zf(z) >\_ 0. Show there is one and only one solution to this problem and the solution can be defined on [0, oo). Hint: Write the equation as a system by letting z = x, z = y, define V (X, y.) = y2/2 + f o f(s) ds and study the rate of change of V(x(t), y(t)) along the solutions of the two dimensional system.

COROLLARY 6.5. Let w(t, u) satisfy the conditions of Theorem 6.1 and in addition be nondecreasing in u. If u(t) is the same function as in Theorem

6.1 and v(t) is continuous and satisfies

$$(6.6) v(t) \leq v_a + \int_a^t \omega(s, v(s)) ds, \quad a \leq t \leq b, \quad v_a \leq u(a),$$

then v(t) < u(t), a <\_ t< b.

PROOF. Let V(t) be the right hand side of (6.6) so that v(t) < V(t). Then V(t) = w(t, v(t)) < w(t, V(t)), V(a) = Va < u(a). Theorem 6.1 implies V(t) < u(t) for a < t \_< b and this proves the corollary.

COROLLARY 6.6. (Gronwall's inequality). If a is a real constant, fl(t) >\_ 0, and 4(t) are continuous real functions for a < t < b which satisfy

$$\phi(t) \leq \alpha + \int_a^t \beta(s)\phi(s) ds, \quad a \leq t \leq b,$$

then

$$\phi(t) \le \left(\exp \int_a^t \beta(s) ds\right) \alpha, \quad a \le t \le b.$$

PROOF. We apply Corollary 6.5 with Va = a, w(t, u) = fl(t)u. Then is = fl(t)u, u(a) = a is given by u(t) \_ (exp f a fl(s) ds) a, which proves the corollary.

Actually, Gronwall's inequality is easily proved by other techniques. In the applications to follow, we actually need a generalization of this inequality so we state and prove it without using Theorem 6.1.

LEMMA 6.2. (Generalized Gronwall inequality). If 0, a are real valued and continuous for a < t < b, fl(t) >\_ 0 is integrable on [a, b] and

$$\phi(t) \leq \alpha(t) + \int_a^t \beta(s)\phi(s) \ ds, \quad a \leq t \leq b,$$

then

$$\phi(t) \leq \alpha(t) + \int_a^t \beta(s)\alpha(s) \left(\exp \int_s^t \beta(u) \ du\right) ds, \qquad a \leq t \leq b.$$

PROOF. Let R(t) = ft g(8)0(s) ds. Then a

$$rac{dR(t)}{dt} = eta(t) oldsymbol{\phi}(t) \leqq eta(t) lpha(t) + eta(t) R(t)$$

except for a set of measure zero. Thus,

$$\frac{dR(t)}{dt} - \beta(t)R(t) \leq \beta(t)\alpha(t),$$

$$\frac{d}{ds}\left(\exp-\int_a^s eta(u)\ du\right)R(s) \le \left(\exp-\int_a^s eta(u)\ du\right)eta(s)lpha(s),$$

except for a set of measure zero. Integrating from a to t, we obtain

$$\left(\exp \left(-\int_a^t \beta(u) \ du\right) R(t) \le \int_a^t \left(\exp \left(-\int_a^s \beta(u) \ du\right) \beta(s) \alpha(s) \ ds.\right)$$

and thus

$$R(t) \leqq \int_a^t \left(\exp \int_s^t \beta(u) \ du\right) \beta(s) \alpha(s) \ ds.$$

This estimate proves the lemma.

If  $\alpha$  is continuous with its first derivative  $\dot{\alpha} \ge 0$ , then integrating by parts in Lemma 6.2 gives

$$\varphi(t) \le \alpha(a) \exp\left(\int_a^t \beta\right) + \int_a^t \dot{\alpha}(s) \exp\left(\int_s^t \beta\right) ds$$

$$\le \left[\exp\int_a^t \beta\right] \left[\alpha(a) + \int_a^t \dot{\alpha}(s) ds\right]$$

$$\le \alpha(t) \exp\int_a^t \beta$$

since  $\beta \ge 0$ . Gronwall's inequality is now a special case.

### I.7. Autonomous Systems—Generalities

If x(t) is a solution of (1.1) defined on an interval (a, b), we have previously introduced the concept of a trajectory associated with this solution as the set in  $R^{n+1}$  defined by  $\bigcup_{a \le t \le b}(t, x(t))$ . The path or orbit of a trajectory is the projection of the trajectory into  $R^n$ , the space of dependent variables in (1.1). The space of dependent variables is usually called the state space or phase space. The phase coordinates for a scalar  $n^{\text{th}}$  order equation in x is the vector  $(x, x^{(1)}, x^{(2)}, \ldots, x^{(n-1)})$ . System (1.1) is called autonomous if the vector field, that is, the function f in (1.1), is independent of f. In this section we consider some general properties of autonomous systems; namely, the differential system

$$\dot{x} = f(x)$$

where  $f: \Omega \to \mathbb{R}^n$  is continuous and  $\Omega$  is an open set in  $\mathbb{R}^n$ . A basic property of autonomous systems is the following: if x(t) is a solution of (7.1) on an interval (a, b), then for any real number  $\tau$ , the function  $x(t - \tau)$  is a solution of (7.1) on the interval  $(a + \tau, b + \tau)$ . This is clear since the differential equation remains unchanged by a translation of the independent variable. Thus, from a single solution of (7.1) one can define a one parameter family of solutions.

We shall henceforth assume that for any p in S2, there is a unique solution q(t, p) of (7.1) passing through p at t = 0. The function 0(t, p) is defined on an open set E e Rn+1 and satisfies the properties:

- (i) 0(0, p) =p;
- (ii) 0(t, p) is continuous in E;
- (iii) 0(t + r, p) = 0(t, 0(-r, p)) on

In fact, it follows from Theorem 3.4 that ¢(t, p) is continuous. Relation (iii) holds since both functions satisfy the equation, are equal for t = 0 and we have assumed uniqueness.

From the above definition, the path or orbit V'-- y(p) through a fixed p e S2 is the set in Rn defined by y(p) = {x a Rn: there exist (t, 0) e E with 0(t, p) = x}. It is clear that 0(t, p) and q(t + z, p) are different parametrizations of the same orbit y(p).

There is a unique path y through a given p in 0. Indeed, paths through p are projections of all solutions of (7.1) which pass through any of the points on the line (r, p), -oo <,r < oo. But, /(t + r, p) is the unique solution of (7.1) passing through (r, p) and we have seen above these functions are all parametrizations of the same curve. Notice this last conclusion implies that no two paths can intersect.

An a uilibrium point or critical point r singular point of an n-dimensional vector field (x is a point such that f (p) = 0. If p is a critical point, then x(t) = p, - oo < t < oo, satisfies (7.1). The trajectory of the critical point p is the line in Rn+l given b x = p, - oo < t < ao and the orbit of a critical point is the point itself A re ulcer point is a point which is not critical.

If p is a critical point of (7.1), then no trajectory other than x(t) =p can reach the line x = p, - oo < t < oo by the process of continuation for this would violate uniqueness. This implies: if p is a critical point and x(t) p tends to p, then either t - \* + co or t -\* - oo.

A curve A in Rn is the range of a continuous mapping of an interval I c R into Rn. The curve is said to be differentiable if the associated mapping is differentiable. Given a continuous f: S2 --> Rn, 0 open in Rn, f = (fl, ... ,f.), we say a curve A is a solution of the equations

(7.2) 
$$\frac{dx_1}{f_1(x)} = \frac{dx_2}{f_2(x)} = \dots = \frac{dx_n}{f_n(x)}$$

if A is differentiable and the differential dx along A is parallel to f (x) when f (x) = 0, and A is a point when f (x) = 0.

LEMMA 7.1. The solution of (7.2) at any point p of L is the orbit of (7.1) through p.

PROOF. If p = (pl, ... , pn) is a critical point, then y and A are both equal to p. If p is not a critical point, then one of the components of f say fl

is such that fi(p) \* 0. Therefore, fi(x) 0 for x in a neighborhood U of p. In U system (7.2) is therefore equivalent to the ordinary differential- system

$$rac{dx_{lpha}}{dx_1} = rac{f_{lpha}(x)}{f_1(x)}, \qquad x_{lpha}(p_1) = p_{lpha}, \qquad lpha = 2, 3, \ldots, n.$$

From the existence Theorem 1.1, these equations have a solution xa(xi) which exists for Ixi -pil sufficiently small. We parametrize A in the following way. Consider the autonomous scalar equation

$$\frac{dx_1}{dt} = f_1(x_1, x_2(x_1), \ldots, x_n(x_1)).$$

This equation has a solution xi(t), xi(0) =pi, which exists for Itl small. One now easily shows that xi(t), xa(xi(t)), a = 2, ..., n, is a solution of (7.1). Since the orbit of (7.1) through any point of 0 is a solution of (7.2), this proves A = y and the lemma.

A homeomorphic image of a closed or open line segment is called an arc. A homeomorphic image of the circumference of a circle is called a Jordan curve. A path y is said to be closed if it is a Jordan curve.

LEMMA 7.2. A necessary and sufficient condition for a path of (7.1) to be closed is that it corresponds to a nonconstant periodic solution of (7.1).

PROOF. If y is a closed path of (7.1) and p is a point of y, there is a T = 0 such that Or, p) = 0(0, p) = p. By uniqueness of solutions 0(t + r, p) \_ 0(t, p) for all t which says q(t, p) has period T. Conversely, suppose q(t, p) = 0(t + T, p) for all t, 0(t, p) nonconstant, and r is the least period of 0(t, p); i.e. p :A 0(t, p), 0 < t < T. As t varies in [0, r), 0(t, p) describes a curve in Rn which is the homeomorphic image of the segment [0, r) with 0(0, p) = 0(T, p). On the other hand, the line segment [0, r] with 0 and r identified is homeomorphic to the unit circle. This completes the proof.

EXERCISE 7.1. Suppose the autonomous'equation i = f (x) has a nonconstant periodic solution xc(t). Define stability of this solution. Can the stability ever be asymptotic? What is the strongest type of stability that you would expect in such a situation?

We now give a few examples to illustrate the above concepts.

Example 7.1. If x is a real scalar, i = x, then 0(t, p) = etp, the trajectory through p is the set (t, etp), - co < t < oo and the path through p is the set {x > 0} if p >0, {x = 0} if p =0 and {x < 0} if p <0. See Fig. 7.1 where the arrow on a curve in phase space denotes the manner in which the path is described with increasing time.

Example 7.2. If x is a real scalar, i = -x(1 -- x), then 0(t, p) \_ pe-t f [1 -,p + pe-t]. The paths are the sets {x > 1}, {x =1}, {0 < x < 1},

![](_page_49_Figure_2.jpeg)

Figure 1.7.1

![](_page_49_Figure_4.jpeg)

Figure 1.7.2

{x = 0}, {x < 0}. See Fig. 7.2. The equilibrium point x =1 is unstable and x = 0 is asymptotically stable.

Example 7.3. If y is a real scalar, then the equation y + y = 0 is equivalent to the system x1= X2, x2 = -X1 where xi = y. The phase space is R2. For any real constants a, b one verifies that 01(t) = a sin(t + b), 02(t) = a cos(t + b) is a solution of this system and any solution of the equation can be written in this form. Any trajectory lies on a circular cylinder and the path through any point is a circle passing through this point with center at the origin. See Fig. 7.3. An equilibrium point of a two dimensional autonomous system which has the property that every neighborhood of the point contains an orbit which is a closed curve (periodic solution) is"called a center. Thus, the solution x1 = x2 = 0 of this example is a center.

In this example, we did not need to integrate the equations to obtain the parametric representation of the orbits in phase space. In fact, Lemma 7.1 implies that the orbits are the solutions of the scalar equation

![](_page_50_Figure_2.jpeg)

Figure 1.7.3

$$rac{dx_1}{dx_2} = -rac{x_2}{x_1}$$

which has the solutions x2 + x2 = constant; the constant of course being determined by the initial values. The manner in which the orbits are described with increasing time is easily obtained from the original equations.

Example 7.4. Suppose E > 0 is given, x1, x2 are real scalars, r2 = xi + x2 and consider the system

$$\dot{x}_1=-x_2+arepsilon x_1(1-r^2), \ \dot{x}_2=x_1+arepsilon x_2(1-r^2).$$

The phase space for this system is R2. If XI = r cos 0, x2 = r sin 0, then the system is equivalent to the system

$$\dot{ heta}=1, \ \dot{r}=arepsilon r(1-r^2).$$

One easily verifies that the trajectories and paths are as in Fig. 7.4. In this case, the paths are spirals outside and inside the circle of radius one and the equilibrium point (0, 0) together with the circle of radius one. The equilibrium

![](_page_50_Picture_11.jpeg)

Figure 1.7.4

point (0, 0) is called a focus; that is, solutions in a neighborhood of it spiral toward it as t - + oo (or - oo). To say a solution spirals toward zero as t -\* + oo (or - co) is to say that any ray emanating from zero is crossed by the orbit of the solution an infinite number of times and the solution approaches zero as t - + oo (or - oo). The orbit (r = 1) which is a closed curve in this example is called a limit cycle, the reason for the terminology becoming clear in later discussions.

Notice that, for e = 0 this example is the same as Example 7.3. However, for any e > 0, no matter how small, the phase portrait of the two equations are completely different.

Example 7.5. In this example, we illustrate that the solutions of a differential equation may be much more complicated than any of the previous examples. A torus is the homeomorphic image of the cross product of two circles. Suppose 0, 0 are the angles shown in Fig. 7.5 describing a coordinate

![](_page_51_Picture_5.jpeg)

Figure 1.7.5

system on the torus, If 0, 0 satisfy the differential equation 8 = 1, = w, where w is a constant, then a solution corresponding to an orbit y goes around the torus traversing the angle 0 with period 2ir/w and the angle 0 with period 21r. Therefore, for w irrational, the path is not closed, but it does have the property that the closure of y is the whole torus!

EXERCISE 7.2. Prove the statement in Example 7.5 concerning the closure of y for w irrational. Can you describe the behavior when to is rational?

Example 7.6. In this example, we show in R3 that the complicated behavior in Example 7.5 can be shared by all solutions of an equation in a solid torus. A solid torus is the homeomorphic image of the cross product

of a circle and a disk. Suppose the region is that depicted in Fig. 7.5 and the coordinate system (r, 0, 0) is as shown with 0 < r < 2 and 0 <\_ 0, 0 < 27r. The value r = 0 is a circle C which lies in a plane P and the surface r = constant, 0 0, 0 < 27r is a torus, which has C at its center.

For the differential. equations, choose

$$egin{aligned} \dot{ heta} &= 1, \ \dot{\phi} &= \omega, \ \dot{r} &= r(1-r), \end{aligned}$$

where w is a constant. The torii r = 0 and r =1 are invariant in the sense that any solution with initial value in these surfaces remain in them for all t in (-oo, oo). Except for the periodic solution corresponding to C, all other solutions approach the torus described by r = 1. Therefore, from Example 7.5, the closure of every orbit except C contains the torus r = 1 if co is irrational.

EXERCISE 7.3. Discuss the phase portrait of the solutions of the second order equation

$$\dot{x}_1 = x_2(x_2^2 - x_1^2), \ \dot{x}_2 = -x_1(x_2^2 - x_1^2).$$

What are the orbits and the equilibrium points? Which equilibrium points are stable? What does the application of Lemma 7.1 yield for this system?

Suppose b: Sa -- Rn is a given continuously differentiable function on the ball Sa = {u in Rn-1, Jul < a} with r(0) = p and rank [8o(u)/8u] = n -1 for all u in Sn . The set {x in Rn, x = ali(u), u in S«} is called a differentiable (n -1)-cell En-1 through p. Such an En-1 is said to be transverse to the path yp of (7.1) at p if for each p' E EP-1, the path yp, through p' is not tangent to En-1 at p'. This is equivalent to saying that dx along yp, at the point p' is not a linear combination of the columns of 8+1i(u)/8u for Jul < a and this in turn is equivalent to saying that

$$D(x, u) \stackrel{ ext{def}}{=} \det \left[ rac{\partial \psi(u)}{\partial u} \, , \; f(x) 
ight] 
eq 0 ,$$

for u < a. Suppose D(p, 0) 0. Since D(x, u) is continuous, there is an a sufficiently small so that D(x, u) :0 for Ix - pl < a, Jul < a. For this a, E'-1 is transverse to yp at p. If p is a regular point of (7.1), there always exists an E'-' transverse to y at p. A closed transversal through y at p is defined in the same way using the closed ball of radius a.

An open path cylinder of (7.1) is a set which is homeomorphic to an open cylinder (the cross product of an open ball in Rn-1 and an open interval)

and consists only of arcs of paths of (7.1). A closed path cylinder of (7.1) is a set which is homeomorphic to a closed cylinder and consists only of arcs of paths of (7.1). The bases of a closed path cylinder are the images under the homeomorphism of the bases of the closed cylinder. If C is a path cylinder (either open or closed) the arcs of paths of (7.1) lying in C will be called the generators of C.

LEMMA 7.3. Suppose f has continuous first partial derivatives in  $\Omega$ . If p is a regular point of (7.1) and  $E^{n-1}$  is a differentiable (n-1)-cell transverse at p to the path  $\gamma$  of (7.1) through p, then there is a path cylinder C containing p in its interior. In particular, every path  $\gamma'$  of (7.1) with a point in C must cross  $E^{n-1}$  at a p' where  $E^{n-1}$  is transverse to  $\gamma'$ .

PROOF. Let  $E^{n-1}$  have a parametric representation given by  $E^{n-1} = \{x \text{ in } R^n : x = \psi(u), u \text{ in } S_\alpha\}$ , where  $S_\alpha = \{u \text{ in } R^{n-1} : |u| < \alpha\}$ , and  $\psi$  has a continuous first derivative. Let  $\phi(t, p')$ ,  $\phi(0, p') = p'$ , be the solution of (7.1) which describes the path  $\gamma'$  through p'. There is an interval I containing zero in its interior such that each  $\phi(t, p')$ ,  $p' \in E^{n-1}$  is defined for  $t \in I$ . The function  $\phi(t, p') = \phi(t, \psi(u))$  can therefore be considered as a mapping T of  $I \times S_\alpha$  into  $R^n$ . From Theorem 3.3, this mapping is continuously differentiable in  $I \times S_\alpha$ . If we define

$$F(x, t, u) = -x + \psi(u) + \int_0^t f(\phi(s, \psi(u))) ds$$

for  $x \in \mathbb{R}^n$ ,  $(t, u) \in I \times S_{\alpha}$ , then the fact that  $\phi(t, \psi(u))$  is a solution of (7.1) implies  $F(\phi(t, \psi(u)), t, u) = 0$  for  $(t, u) \in I \times S_{\alpha}$ . We now consider the relation F(x, t, u) = 0 as implicitly defining t, u as a function of x. Since

$$\det\left[\frac{\partial F(x,\,t,\,u)}{\partial(t,\,u)}\right]$$

equals D(p,0) for (x,t,u)=(p,0,0), this determinant must be different from zero in a neighborhood of (p,0,0). The implicit function theorem therefore implies that the inverse mapping of T exists and is continuously differentiable in a neighborhood of p. This shows there are  $\alpha>0$ ,  $\tau>0$  such that the mapping T is a continuously differentiable homeomorphism (or diffeomorphism) of  $I_{\tau}\times S_{\alpha}$ ,  $I_{\tau}=\{t:|t|<\tau\}$ , into a neighborhood of p. Furthermore,  $\{T(t,u),t \text{ in } I_{\tau}\}$  coincides with the arc of  $\gamma'$  described by the solution  $\phi(t,p')$ ,  $-\tau< t<\tau$ . The range of T is an open path cylinder. It is clear there is also a closed path cylinder. This proves the lemma.

We now extend this local result to a global result in the sense that the time interval involved in the description of the path may be arbitrarily large as long as it is finite. First we prove a result for paths which are not closed. More precisely, we prove

Lemma 7.4. Suppose f has continuous first partial derivatives in  $\Omega$ ,  $\gamma$  is any path, p is a regular point, pq is an arc of  $\gamma$ ,  $E_p^{n-1}$ ,  $E_q^{n-1}$  are differentiable (n-1)-cells transverse to  $\gamma$  at p, q, respectively. Then there is a closed path cylinder whose axis is pq and whose bases are in  $E_q^{n-1}$ ,  $E_q^{n-1}$ .

PROOF. We can assume that  $E_p^{n-1} \cap E_q^{n-1}$  is empty. Relative to  $E_p^{n-1}$ ,  $E_q^{n-1}$ , we can construct local open path cylinders  $C_p$ ,  $C_q$ . Let  $t_p$  be the time to traverse the path  $\gamma$  from p to q; i.e.  $\phi(t_p, p) = q$ . From continuity with respect to initial data, one can choose an open (n-1)-cell  $\bar{E}_p^{n-1}$  in  $E_p^{n-1}$  such that  $\phi(t_p, p')$  belongs to  $C_q$  for every p' in  $\bar{E}_p^{n-1}$ .

Lemma 7.3 implies that each point  $\phi(t_p, p')$  must lie on an arc in  $C_q$  of a trajectory of (7.1) and must cross  $E_q^{n-1}$  at a point q'. Let the time to traverse the arc  $\gamma_{p'}$  from p' to q' be  $t_{p'}$ . The mapping  $p' \to t_{p'}$  is continuously differentiable and an application of the implicit function theorem similar to the above implies the mapping  $p' \to \phi(t_{p'}, p')$  is a homeomorphism. Since f in (7.1) is bounded on  $C_q$  and  $C_p$ , there is a  $\nu > 0$  such that the time to leave  $C_p$  along an arc of a path through  $p' \in E_p^{n-1}$  as well as to leave  $C_q$  along an arc of a path through  $q' \in E_q^{n-1}$  is greater than  $\nu$ . Choose  $\nu < t_p$ .

Let us show that p'q' is a closed arc if the diameter of  $\bar{E}_p^{n-1}$  is sufficiently small. If p'q' is not an arc, then  $\gamma_{p'}$  must be a closed curve. Thus, there is a  $\tau_{p'}$ ,  $\nu < \tau_{p'} < t_{p'} - \nu$  such that  $\phi(\tau_{p'}, p') = p'$ . If no such  $\bar{E}_p^{n-1}$  exists so that p'q' is an arc, then there is a sequence of  $p'_k \in \bar{E}_p^{n-1}$ ,  $\tau_{p'_k}$ ,  $\nu < \tau_{p'_k} < t_{p'_k} - \nu$ ,  $p'_k \to p$  as  $k \to \infty$  such that  $\phi(\tau_{p'_k}, p'_k) = p'_k$ . The  $\tau_{p'_k}$  must be bounded since  $t_{p'_k} \to t_p$  as  $k \to \infty$  and  $\nu < \tau_{p'_k} < t_{p'_k} - \nu$ . Therefore, there is a subsequence which we label the same as before such that  $\tau_{p'_k} \to \tau_0$  as  $k \to \infty$  and  $0 < \tau_0 < t_p - \nu/2$ . But this clearly implies that the path  $\gamma_p$  described by  $\phi(t, p)$  satisfies  $\phi(\tau_0, p) = p$ . This is a contradiction since pq was assumed to be an arc.

The path cylinder C is obtained as the union of the arcs of the trajectories p'q' with p' in  $\bar{E}_p^{n-1}$ . It remains only to show that this is homeomorphic to a closed cylinder. For I = [0, 1], define the mapping  $G: \bar{E}_p^{n-1} \times I \to R^n$  by  $G(p', s) = \phi(st_{p'}, p')$ , where  $t'_p$  is defined above. It is clear that this mapping is a homeomorphism and therefore C is a closed path cylinder. This proves the lemma.

Now suppose  $\gamma$  is a closed-path. Lemma 7.2 implies  $\gamma$  is the orbit of a nonconstant periodic solution  $\phi(t,p)$  of (7.1) of least period  $\bar{t}>0$ . Take a transversal  $E_p^{n-1}$  at p. There is another transversal  $\bar{E}_p^{n-1}$  at  $p, \bar{E}_p^{n-1} \subseteq E_p^{n-1}$  such that, for any  $q \in \bar{E}_p^{n-1}$ , there is a  $t_q>0$ , continuously differentiable in  $q, x(t_q,q)$  in  $E_p^{n-1}, x(t,q)$  not in  $E_p^{n-1}$  for  $0 < t < t_q$ , and the mapping  $F: \bar{E}_p^{n-1} \times [0,1) \to R^n$  defined by  $F(q,s) = x(st_q,q)$  is a diffeomorphism. The set  $F(\bar{E}_p^{n-1} \times [0,1))$  is called a path ring enclosing  $\gamma$ . We have proved the following result.

LEMMA 7.5. If  $\gamma$  is a closed path, there is a path ring enclosing  $\gamma$ .

It may be that a solution of an autonomous equation is not defined for all t in R as the example  $x=x^2$  shows. In the applications, one is usually only interested in studying the behavior of the solutions in some bounded set G and it is very awkward to have to continually speak of the domain of definition of a solution. We can avoid this situation by replacing the original differential equation by another one for which all solutions are defined on  $(-\infty, \infty)$  and the paths defined by the solutions of the two coincide inside G. When the paths of two autonomous differential equations coincide on a set G, we say the differential equations are equivalent on G.

**Lemma** 7.6. If f in (7.1) is defined on  $R^n$  and  $G \subset R^n$  is open and bounded, there exists a function  $g: R^n \to R^n$  such that  $\dot{x} = g(x)$  is equivalent to (7.1) on G and the solutions of this latter equation are defined on  $(-\infty, \infty)$ .

**PROOF.** If  $f = (f_1, \ldots, f_n)$ , we may suppose without loss of generality that  $G \subset \{x: |f_j(x)| \leq 1, j = 1, 2, \ldots, n\}$ . Define  $g = (g_1, \ldots, g_n)$  by  $g_j = f_j \phi_j$ , where each  $\phi_j$  is defined by

$$\phi_{j}(x) = egin{cases} 1 & ext{if} & |f_{j}(x)| \leq 1, \ \dfrac{1}{f_{j}(x)} & ext{if} & f_{j}(x) > 1, \ -\dfrac{1}{f_{j}(x)} & ext{if} & f_{j}(x) < -1. \end{cases}$$

Corollary 6.3 implies that g satisfies the conditions of the lemma since |g(x)| is bounded in  $\mathbb{R}^n$ .

## I.S. Autonomous Systems—Limit Sets, Invariant Sets

In this section we consider system (7.1) and suppose f satisfies enough conditions on  $\mathbb{R}^n$  to ensure that the solution  $\phi(t, p)$ ,  $\phi(0, p) = p$ , is defined for all t in R and all p in  $\mathbb{R}^n$  and satisfies the conditions (i)-(iii) listed at the beginning of Section I.7.

The orbit  $\gamma(p)$  of (7.1) through p is defined by  $\gamma(p) = \{x : x = \phi(t, p), -\infty < t < \infty\}$ . If q belongs to  $\gamma(p)$ , then  $\gamma(q) = \gamma(p)$  as remarked earlier. The positive semiorbit through p is  $\gamma^+(p) = \{x : x = \phi(t, p), t \ge 0\}$  and the negative semiorbit through p is  $\gamma^-(p) = \{x : x = \phi(t, p), t \le 0\}$ . If we do not wish to distinguish a particular point on an orbit, we will write  $\gamma$ ,  $\gamma^+$ ,  $\gamma^-$  for the orbit, positive semiorbit, negative semiorbit, respectively.

The positive or  $\omega$ -limit set of an orbit  $\gamma$  of (7.1) is the set of points in

Rn which are approached along y with increasing time. More precisely, a point q belongs to the w-limit set or positive limit set co(y) of an orbit. y if there exists a sequence of real numbers {tk}, tk -a oo as k -->- oo such that 0(tk, p) -\*q as k - oo. Similarly, a point q belongs to the ce-limit set or negative limit set a(y) if there is a sequence of real numbers {tk}, tk - - - 00 as k -\* oo such that 4,(tk, p) -\* q as k -\* oo.

It is easy to prove that equivalent definitions of the w-limit set and a-limit set are

$$\omega(\gamma) = \bigcap_{p \in \gamma} \overline{\gamma^+(p)} = \bigcap_{\tau \in (-\infty, \infty)} \overline{\bigcup_{t \ge \tau}} \phi(t, p)$$

$$\alpha(\gamma) = \bigcap_{p \in \gamma} \overline{\gamma^-(p)} = \bigcap_{\tau \in (-\infty, \infty)} \overline{\bigcup_{t \ge \tau}} \phi(t, p)$$

where the bar denotes closure.

A set M in Rn is called an invariant set f (7.1) if, for any p in M, the solution (t, p) of (7.1 through belongs to M for tin - oo, oo .Any orbit of (7.1) is obviously an invariant set of (7.1). A set M is called positively (negatively) invariant if for each p in M, 0(t, p) belongs to M for t > 0 (t < 0).

THEOREM 8.1. The a- and w-limit sets of an orbit y are closed and invariant. Furthermore, if y+(y-) is bounded, then the w-(a-) limit set is nonempty compact and connected, dist(4(t, p), w(y(p))) --0 as t -> oo and dist( (t, p), a(( ))) -\* 0 as t--> -oo.

PROOF. The closure is obvious from the definition. We now prove the positive limit sets are invariant. If q is in w(y), there is a sequence {tn}, to - . ao as n -> oo such that q(tn , p) -\* q as n -\* oo. Consequently, for any fixed tin (- oo, 00), c(t + to , p) = 0(t, On, p)) -' 0(t, q) as n co from the continuity of 0. This shows that the orbit through q belongs to w(y) or w(y) is invariant. A similar proof shows that a(y) is invariant.

If y+ (y) is bounded, then the co- (a-) limit set is obviously nonempty and bounded. The closure therefore implies compactness. It is easy to see that dist(q(t, p), w(y(p))) -->0 as t \* oo, dist(o(t, p), a(y(p))) -a0 as t --> - oo. This latter property clearly implies that w(y) and a(y) are connected and the theorem is proved.

COROLLARY 8.1. The limit sets of an orbit must contain only complete paths.

A sit M in Rn is called a minimal set of (7.1) if it is nonempty, closed and invariant and has no proper subset which possesses these three properties.

LEMMA 8.1. If A is a nonempty compact, invariant set of (7.1), there is a minimal set M C A.

PROOF. Let F be a family of nonempty subsets of Rn defined by F = {B: B c A, B .compact, invariant}. For any B1, B2 in F, we say B2 < B1 if B2 c B1. For any F1 c F totally ordered by " < ", let C = nB E F.B. The family F1 has the finite intersection property. Indeed, if B1; B2 are in F1, then either B1 < B2 or B2 < B1 and, in either case, B1 o B2 is nonempty and invariant or thus belongs to Fl. The same holds true for any finite collection of elements in Fl. Thus, C is not empty, compact and invariant and for each B in F1, C < B. Now suppose an element D of F is such that D < B for each B in Fl. Then D c B for each B in F1 which implies D C C or D < C. Therefore C is the minimum of Fl. Since each totally ordered subfamily of F admits a minimum, it follows from Zorn's lemma that there is a minimal element of F. It is easy to see that a minimal element is a minimal set of (7.1) and the proof is complete.

Let us return to the examples considered in Section 1.7 to help clarify the above concepts. In example 7.1, the co-limit set of every orbit except the orbit consisting of the critical point {0} is empty. The cc-limit set of every orbit is {0}. The only minimal set is {0}. In example 7.2, the w-limit set of the orbits {0 < x < 1}, {x < 0}, is {0}, the cc-limit set of {x > 1}, {0 < x < 1} is {0} and {0} and {1} are both minimal sets. In example 7.3, the w- and x-limit set of any orbit is itself, every orbit is a minimal set and any circular disk about the origin is invariant. In example 7.4, the circle {r =1} and the point {r = 0} are minimal sets, the circle {r =1} is the w-limit set of every orbit except {r = 0}, while the point {r = 01 is the x-limit set of every orbit inside the unit circle. In example 7.6, the torus r = 1 is a minimal set as well as the circle r = 0, the w-limit set of every orbit except r = 0 is the torus r = 1 and the x-limit set of every orbit inside the torus r = 1 is the circle r = 0.

Let us give one other artificial example to show that the w-limit sets do not always need to be minimal sets. Consider r and 0 as polar coordinates which satisfy the equations

$$\dot{\theta} = \sin^2 \theta + (1 - r)^3,$$

$$\dot{r} = r(1 - r).$$

The w-limit set of all orbits which do not lie on the sets {r =1} and {r = 01 is the circle r =1. The circle r =1 is invariant but the orbits of the equation on r =1 consist of the points {O = 0}, {0 = rr} and the arcs of the circle {0 < 0 < 7r}, {7r < 0 < 2rr}, The minimal sets on this circle are just the two points {0 = 0}, {0 = 7T}.

EXERCISE 8.1. Give an example of a two dimensional system which has an orbit whose w-limit set is not empty and disconnected.

THEOREM 8.2. If K is a positively invariant set of system (7.1) and K is homeomorphic to the closed unit ball in Rn, there is at least one equilibrium point of system (7.1) in K.

PROOF. For anyrI > 0, consider the mappingtaking p in K into 0(rI, p) in K. From Brouwer's fixed point theorem, there is a pI in K such that 0(rI, pi) =pz, and, thus, a periodic orbit of (7.1) of period ri. Choose a sequence rm > 0, rm -\*0 as m -)- oo and corresponding points pin such that q(rm, pm) = pm . We may assume this sequence converges to a p\* in K as m -\* oo since there is always a subsequence of the pm which converge. For any t and any integer m, there is an integer km(t) such that km(t)rm 5 t < km(t)rm + rm and 0(km(t)rm, pm) =pm for all t since 0(t, pm) is periodic of period rm in t. Furthermore,

$$\begin{aligned} |\phi(t, p^*) - p^*| &\leq |\phi(t, p^*) - \phi(t, p_m)| + |\phi(t, p_m) - p_m| + |p_m - p^*| \\ &= |\phi(t, p^*) - \phi(t, p_m)| + |\phi(t - k_m(t)\tau_m, p_m) - p_m| \\ &+ |p_m - p^*| \,, \end{aligned}$$

and the right hand side approaches zero as m oo for all t. Therefore, p\* is an equilibrium point of (7.1) and the theorem is proved.

Some of the most basic problems in differential equations deal with the characterization of the minimal sets and the behavior of the solutions of the equations near minimal sets. Of course, one would also like to be able to describe the manner in which the w-limit set of any trajectory can be built up from minimal sets and orbits connecting the various minimal sets. In the case of two dimensional systems, these questions have been satisfactorily answered. For higher dimensional systems, the minimal sets have not been completely classified and the local behavior of solutions has been thoroughly discussed only for minimal sets which are very simple. Our main goal in the following chapters is to discuss some approaches to these questions.

## 1.9. Remarks and Suggestions for Further Study

For a detailed proof of Peano's theorem without using the Schauder theorem, see Coddington and Levinson [1], Hartman [1]. When uniqueness of trajectories of a differential equation is not assumed, the union of all trajectories through a given point forms a type of funnel. For a discussion of the topological properties of such funnels, see Hartman [1].

There are many other ways to generalize the concept of a differential equation. For example, one could permit the vector field f (t, x) to be continuous in t, but discontinuous in x. Also, f (t, x) could be a set valued function. In spite of the fact that such equations are extremely important in some applications to control theory, they are not considered in this book. The interested reader may consult Flugge-Lotz [1], Andre and Seibert [1], Fillipov [1], Lee and Marcus [1].

The results on differential inequalities in Section 6 are valid in a much more general setting. In fact, one can use upper right hand derivatives in

place of right hand derivatives, the assumption of uniqueness can be eliminated by considering maximal solutions of the majorizing equation and even some types of vector inequalities can be used. Differential inequalities are also very useful for obtaining uniqueness theorems for vector fields which are not Lipschitzian. See Coppel [1], Hartman [1], Szarski [1], Laksmikantham and Leela [1].

Sections 7 and 8 belong to the geometric theory of differential equations begun by Poincare [1] and advanced so much by the books of Birkhoff [1], Lefschetz [1], Nemitskii and Stepanov [1], Auslander and Gottschalk [1]. The presentation in Section 7 relies heavily upon the book of Lefschetz [1]. A function : R X Rn into Rn which satisfies properties (i-iii) listed at the beginning of Section 7 is called a dynamical system. Dynamical systems can and have been studied in great detail without any reference to differential equations (see Gottschalk and Hedlund [1], Nemitskii and Stepanov [1]). All results in Section 7 remain valid for dynamical systems. However, the proofs are more difficult since the implicit function theorem cannot be invoked. The concepts of Section 8 are essentially due to Birkhoff [1].

The definitions of stability given in Section 4 are due to Liapunov [1]. For other types of stability see Cesari [1], Yoshizawa [2].

## CHAPTER II

## Two Dimensional Systems

The purpose of this chapter is to discuss the global behavior of solutions of differential equations in the plane and differential equations without critical points on a torus. In particular, in Section 1, the w-limit set of any bounded orbit in the plane is completely characterized, resulting in the famous Poincare-Bendixson theorem. Then this theorem is applied to obtain the existence and stability of limit cycles for some special types of equations. In Section 2, all possible w-limit sets of orbits of smooth differential equations without singular points on a torus are characterized, yielding the result that the w-limit set of an orbit is either a periodic orbit or the torus itself.

Differential equations on the plane are by far the more important of the two types discussed since any system with one degree of freedom is described by such equations. On the other hand, in the restricted problem of three bodies in celestial mechanics, the interesting invariant sets are torii and, thus, the theory must be developed. Also, as will be seen in a later chapter, invariant torii arise in many other applications.

## M. Planar Two Dimensional Systems-The Poincare-Bendixson Theory

In this section, we consider the two dimensional system

$$\dot{x} = f(x)$$

where x is in R2, f : R2 -a R2 is continuous with its first partial derivatives and such that the solution 0(t, p), 0(0, p) =p, of (1.1) exists for -oo <t Goo. The solution 0(t, p) is the unique solution through (0, p) and, therefore, is continuous for (t, p) in R3. For each fixed t, recall that the mapping 0(t, ): R2 ---> R2 is a homeomorphism.

The beautiful results for 2-dimensional planar systems are made possible because of the Jordan curve theorem which is now stated without proof. Recall that a Jordan curve is the homeomorphic image of a circle.

JORDAN CURVE THEOREM. I Any Jordan curve J in R2 separates the plane; more precisely, R2\J = Se u Si where Se and Si are disjoint open sets, Se is unbounded and called the exterior of J, Si is bounded and called the interior of J and both sets are arcwise connected.

A set B is arcwise connected if p, q in B implies there is an arc pq joining p and q which lies entirely in B.

Let p be a regular point, L be a closed transversal containing p, L° be its interior,

$$V = \{p \text{ in } L_0 : \text{there is a } t_p > 0 \text{ with } \phi(t_p, p) \text{ in } L_0 \text{ and } \phi(t, p) \text{ in } R^2 \setminus L \text{ for } 0 < t < t_p\},$$

and let W =h-1(V) where h: [-1, 1] -3 L is a homeomorphism. Also, let g: W -\* (-1, 1) be defined by g(w) = h-1c6(th(,,,) , h(w)). See Fig. 1.1.

![](_page_61_Figure_7.jpeg)

Figure II.I.I

LEMMA 1.1. The set W is open, g is continuous and increasing on W and the sequence {gk(w)}, k = 0, 1, ... , n < oo is monotone, where gk(w) \_ g(gk-1(w)), k = 1, 2, ... , g°(w) = w.

PROOF. For any p in V c L° let q = 0(tp, p) in L°. From Section 1.7, we have proved that the are pq of the path through p can be enclosed in an open path cylinder with pq as axis and the bases of the cylinder lying in the interior L° of the transversal L. This proves W is open. From continuity with respect to initial data, tp is continuous and we get continuity of g.

To prove the last part of the lemma, consider the Jordan curve J given by C = {x: x = 0(t, p), 0 <\_ t < tp} and the segment of L joining p and q. If p = q, then y(p) is a periodic orbit and the sequence {gk(w)}, w = h-1(p), consists of only one point. Thus, suppose for definiteness h-1(p) <h-1(q); that is, g(w) > wo , w° =h-'(p), w = h-1(q). Let Sj, Se denote the intefior and exterior of J, respectively. From the definition of a transversal L, paths can cross L in only one direction. Therefore, that part of L° given by h[(g(w), 1)] must be completely in either Si or Se since otherwise an orbit would cross the

segment pq of Lo in a direction opposite to the direction the orbit through p crosses L. Therefore, if g2(w) is defined, it must belong to (g(w), 1) which by induction shows that the sequence above is monotone. Suppose wI > w, wI in W. If g(wi) is defined, then g(wl) > g(w) for the same reason as before. This completes the proof of the lemma.

We used the differentiability of f (x) in the above proof when we proved the existence of a path cylinder in Section 1.7. As remarked at the end of Chapter I, this assumption is unnecessary and one can prove the existence of a path cylinder only under the assumption of uniqueness of solutions. In all of the proofs that follow in this section, this is the only place differentiability of f (x) is used. In particular, the Poincare-Bendixson theorem below is valid without differentiability off (x).

COROLLARY 1.1. The w-limit set w(y) of an orbit y can intersect the interior Lo of a transversal L in only one point. If w(y) n Lo =po, y = y(p), then either w(y) = y, and y is a periodic orbit or there exists a sequence {tk}, tk -> oo ask 00 such that p(tk,p) is in Lo, ¢(tk,p) + po monotonically; that is, the sequence h-' (O(tk, p)) is monotone.

PROOF. Suppose w(y) n Lo contains a point po. From the definition of w-limit set, there is a sequence {tk}, tk oo as k -\* oo such that 0(tk , p) -po as k -> oo. But from Section 1.7, there must be a path cylinder containing po such that any orbit passing sufficiently near po must contain an are which crosses the transversal L at some point. Therefore, there exist points qk = 0(tk, p) in Lo, tk -> co as k -\*. oo such that qk -> po as k --> oo. But Lemma 1.1 implies that the qk approach po monotonically in the sense that h-I(qk) is a monotone sequence. Suppose now po is any other point in w(y) n Lo. Then the same argument holds to get a sequence qk -->p0 monotonically. Lemma 1.1 then clearly imples that po = po and the corollary is proved.

COROLLARY 1.2. If y+ and w(y+) have a regular point in common, then y+ is a periodic orbit.

PROOF. If po in y+ n w(y+) is regular, there is a transversal of (1.1) containing po in its interior. From Corollary 1.1, if w(y+) 0 y+, there is a sequence qk = 0A, p) -->po monotonically. Since po is in y+, this contradicts Lemma 1.1. Corollary 1.1 therefore implies the result.

THEOREM 1.1. If M is a bounded minimal set of (1.1), then M is either a critical point or a periodic orbit.

PROOF. If y is an orbit in M, then a(y) and w(y) are not empty and belong to M. Since a(y) and w(y) are closed and invariant we have a(y) = w(y) = M. If M contains a critical point, then it must be the point itself

since, it is equal to w(y) for some y. If M = w(y) does not contain a critical point, then y c w(y) implies y and w(y) have a .regular point in common which implies by Corollary 1.2 that y is periodic. Therefore y = w(y) = M and this proves Theorem 1.1.

LEMMA 1.2. If w(y+) contains regular points and also a periodic orbit yo, then w(y+) = yo.

PROOF. If not, then the connectedness of w(y+) implies the existence of a sequence p in w(y+)\yo and a po in yo such that p. ->po as n --,. oo. Since po is regular, there is a closed transversal L such that po is in the interior Lo of L. From Corollary 1.1, w(y+) r Lo = {po}. From the existence of a path cylinder in Section 1.7, there is neighborhood N of po such that any orbit entering N must intersect Lo. In particular, y(p.n) for n sufficiently large must intersect Lo. But we know this occurs at po. Thus p,a belongs to yo for n sufficiently large which is a contradiction.

THEOREM 1.2 (Poincare-Bendixson Theorem). If y+ is a bounded positive semiorbit and w(y+) does not contain a critical point, then either

(i) 
$$\gamma^+ = \omega(\gamma^+)$$
,

or

(ii) 
$$\omega(\gamma^+) = \bar{\gamma}^+ \backslash \gamma^+$$
.

In either case, the w-limit set is a periodic orbit. The same result is valid for a negative semiorbit.

PROOF. By assumption and Theorem 1.8.1, w(y+) is nonempty, compact invariant and contains regular points only. Therefore, by Lemma 1.8.1, there is a bounded minimal set M in w(y+) and M contains only regular points. Theorem 1.1 implies M is a periodic orbit yo. Lemma 1.2 now implies the theorem.

An invariant set M of (1.1) is said to be stable if for every e-neighborhood U, of M there is a 8-neighborhood U6 of M such that p in U6 implies y+(p) in U,. M is said to be asymptotically stable if it is stable and in addition there is a b > 0 such that p in Ub implies dist(q,(t, p), M) --)- 0 as t -goo. If M is a periodic orbit, one can also define stability from the inside and outside of M in an obvious manner.

COROLLARY 1.3. For a periodic orbit yo to be asymptotically stable it is necessary and sufficient that there is a neighborhood 0 of yo such that w(y(p)) =yo for any p in G.

PROOF. We first prove sufficiency. Clearly dist(o(t, p), yo) --)-0 as t ->oo for every p in G. Suppose L is a transversal at po in yo and suppose p is in

G n Se , q is in G n S\$ , where Se and Si are the exterior and interior of yo, respectively. From Corollary 1.1, there are sequences p), qk= 4 (tk , q) in L approaching po as k -\* oo. Consider the neighborhood Uk of Yo which lies between the curves given by the are pkpk+l of y(p) and the segment of L between pk and Pk+1 and the are gkgk+l of y(p) and the segment of L between qk and qk+1. Uk is a neighborhood of yo. The sequences {tk}, {tk} satisfy tk+l - tk --\* a, tk+1 -t; --> a as k-\* oo where a is the period of yo. This follows from the existence of a path ring around yo. Continuity with respect to initial data then implies for any given e-neighborhood Ue of yo, there is a k sufficiently large so that p in Uk implies q(t, p) in Ue for t >\_ 0 and yo is stable.

To prove the converse, suppose yo is asymptotically stable. Then there must exist a neighborhood G of yo which contains no equilibrium points and G\yo contains no periodic orbits. The Poincare-Bendixson theorem implies the w-limit set of every orbit is a periodic orbit. Since yo is the only such orbit in G, this proves the corollary.

COROLLARY 1.4. Suppose yl, Y2 are two periodic orbits with Y2 in the interior of yl and no periodic orbits or critical points lie between yl and Y2. Then both orbits cannot be asymptotically stable on the sides facing one another.

PROOF. Suppose yl, y2 are stable on the sides facing one another. Then there exist positive orbits yl, y2 in the region between yl, Y2 such that yl = Yi\Yl, Y2 = 2\ Ys For any pl in yl, P2 in Y2 construct transversals L1, L2 . There exist pj 0 pi in yl n L1, p2 0 p2 in y2 n L2. Consider the region S bounded by the Jordan curve consisting of the arc pip" of y, and the segment of the transversal L1 between pi and pi and the curve consisting of the are peps of y2 and the segment of the transversal L2 between p2 and p2 (see Fig. 1.2). The region S contains a negative semiorbit. Thus, the Poincare-Bendixson Theorem implies the existence of a periodic orbit in this region. This contradiction proves the corollary.

THEOREM 1.3. Let y+ be a positive semiorbit in a closed bounded subset K of R2 and suppose K has only a finite number of critical points. Then one of the following is satisfied:

- (i) w(y+) is a critical point;
- (ii) w(y+) is a periodic orbit;
- (iii) w(y+) contains a finite number of critical points and a set of orbits yi with a(Vi) and w(ya) consisting of a critical point for each orbit y{ . See Fig. 1.3.

PROOF. co(y+) contains at most a finite number of critical points. If co(y+) contains no regular points, then it must be just one point since it is

![](_page_65_Picture_2.jpeg)

connected. This is case (i). Suppose w(y+) has regular points and also contains a periodic orbit yo. Tlien w(y+) = yo from Lemma 1.2.

Now suppose w(y+) contains regular points and no periodic orbits. Let yo be an orbit in w(y+). Then w(yo) c w(y+). If po in w(yo) is a regular point and L is a closed transversal to po with interior Lo, then Corollary 1.1 implies w(y+) r Lo = w(yo) n Lo = {p0} and yo must meet Lo at some qo. Since yo belongs to w(y+) we have qo = po which implies by Corollary 1.2 that yo is periodic. This contradiction implies w(yo) has no regular points. But, w(yo) is connected and therefore consists of exactly one point, a critical point. A similar argument applies to the a-limit sets and the theorem is proved.

COROLLARY 1.5. If y+ is a positive semiorbit contained in a compact set in S2 and w(y+) contains regular points and exactly one critical point po, then there is an orbit in w(y+) whose a- and w-limit sets are {po}.

We now discuss the possible behavior of orbits in a neighborhood of a periodic orbit. Let yo be a periodic orbit and Lo be a transversal at po in yo,

h: (-1, 1) -. Lo be a homeomorphism with h(0) = po. If g is the function defined in Lemma 1.1, then g(O) =0 since yo is periodic. Since the domain W of definition of g is open, 0 is in W, g is continuous and increasing, there is an E > 0 such that g is defined and g(w) > 0 for w in (0, e) and g(w) < 0 for w in (- e, 0). We discuss in detail the case g(w) > 0 on (0, e) and the case g(w) < 0 on (- e, 0) is treated in a similar manner. Three possibilities present themselves. There is an rI, 0 < eI < e, such that

- (i) g(w) < w for w in (0, El);
- (ii) g(w) > w for w in (0, el);
- (iii) g(w) =w for a sequence wn >0, W n -\* 0 as n-\* oo.

In case (i), gk(w) is defined for each k > 0, is monotone decreasing and gk(w) -\* 0 as k -\* oo. In fact, it is clear that gk(w) is defined for k > 0. Lemma 1.1 states that gk(w) is-monotone and the hypothesis implies this sequence is decreasing. Therefore, gk(w) -awo > 0 as k -\* oo. But, this implies g(wo) = wo and therefore wo = 0. Similarly, in case (ii), if we define g-k(w) to be the inverse of gk(w) then g-k(w), is defined for each k > 0, is decreasing and g-k(w) --> 0 as k --> oo.

If we interpret these three cases in terms of orbits and limit sets, we have

THEOREM 1.4. If yo is a periodic orbit and G is an open set containing yo, Ge = G n Se , Gi = G n Si where Se and Si are the interior and exterior of yo, then one of the following situations occur:

- (i) there is a G such that either yo = cu(y(p)) for every p in Ge or yo = a(y(p)) for every p in Ge;
- (ii) for each G, there is a p in Ge, p not in yo, such that oc(y(p)) = y(p) is a periodic orbit.

Similar statements hold for Gi.

We call yo a limit cycle if there is a neighborhood G of yo such that either w(y(p)) = ,yo for every p E G or a(y(p) = ,yo for every p E G.

The Poincare-Bendixson theorem suggests a way to determine the existence of a nonconstant periodic solution of an autonomous differential equation in the plane. More specifically, one attempts to construct a domain D in R2 which is equilibrium point free and is positively invariant; that is, any solution of (1.1) with initial value in D remains in D for t z 0. In such a case, we are assured that D contains a positive semiorbit + and thus a periodic solution from the Poincare-Bendixson theorem Furthermore, if we can ascertain that there is only one periodic orbit in D, it will be asymptotically stable from Theorem 1.4 and Corollary 1.3.

These ideas are illustrated for the Lienard type equation

$$\ddot{u} + g(u)\dot{u} + u = 0$$

where g(u) is continuous and the following conditions are satisfied:

- (1.3) (a) G(u) = def fog(s) ds is odd in u,
  - (b) G(u) oo as Jul --± oo and there is a > 0 such that G(u) > 0 for u> S and is monotone increasing.
  - (c) There is an a > 0 such that G(u) <0 for 0 < u < a, G (a) = 0.

Equation 1.2 is equivalent to the system of equations

$$\dot{u}=v-G(u), \ \dot{v}=-u.$$

System (1.4) is a special case of system (1.1) with x = (u, v) and has a unique orbit through any point in R2 since 0 has a continuous first derivative. System (1.4) has only one critical point; namely, u = 0, v = 0, and the orbits of (1.4) are the solutions of the first order equation

$$\frac{dv}{du} = -\frac{u}{v - G(u)}.$$

From (1.4), the function u = u(t) is increasing for v > G(u), decreasing if v < G(u) and the function v = v(t) is decreasing if u > 0, increasing if u < 0. Also, the slopes of the paths v = v(u) described by (1.5) are horizontal on the v-axis and vertical on the curve v = G(u). These facts and hypothesis (1.3b) on G(u) imply that a solution of (1.4) with initial value A = (0, vo) for vo sufficiently large describes an orbit with an arc of the general shape shown in Fig. 1.4.

![](_page_67_Figure_11.jpeg)

Figure 11.1.4

Observe that (u, v) a solution of (1.4) implies (-u, -v) is also a solution from hypothesis (1.3a). Therefore, if we know a path ABECD exists as in Fig. 1.4, then the reflection of this path through the origin is another path. In particular, if  $A = (0, v_0)$ ,  $D = (0, -v_1)$ ,  $v_1 < v_0$ , then the complete positive semiorbit of the path through any point  $A' = (0, v'_0)$ ,  $0 < v'_0 < v_0$  must be bounded. In fact, it must lie in the region bounded by the arc ABECD, its reflection through the origin and segments on the v-axis connecting these arcs to form a Jordan curve. The above symmetry property also implies that (1.4) can have a periodic orbit if and only if  $v_1 = v_0$ .

We show there exists a  $v_0 > 0$  sufficiently large so that a solution as in Fig. 1.4 exists with  $A = (0, v_0)$ ,  $D = (0, -v_1)$ ,  $v_1 < v_0$ . Consider the function  $V(u, v) = (u^2 + v^2)/2$ . If u, v are solutions of (1.4) and (1.5), then

(1.6) 
$$(a) \quad \frac{dV}{dt} = -uG(u),$$

$$(b) \quad \frac{dV}{du} = -\frac{uG(u)}{v - G(u)}$$

$$(c) \quad \frac{dV}{dv} = G(u).$$

Using these expressions, we have

$$V(D)-V(A)=\int_{ABECD}dV=\left(\int_{AB}+\int_{CD}
ight)rac{-uG(u)}{v-G(u)}\,du+\int_{BEC}G(u)\,dv$$

along the orbits of (1.4). It is clear that this first expression approaches zero monotonically as  $v_0 \to \infty$ . If F is any point on the u-axis in Fig. 1.4 between  $(\beta, 0)$  and E, and  $\phi(v_0) = \int_{BEC} G(u) \, dv$ , then

$$-\phi(v_0) = -\int_{BEC} G(u) \ dv = \int_{CEB} G(u) \ dv > \int_{EK} G(u) \ dv > FJ imes FK$$

where FJ, FK are the lengths of the line segments indicated in Fig. 1.4. For fixed F,  $FK \to \infty$  as  $v_0 \to \infty$  and this proves  $\phi(v_0) \to -\infty$  as  $v_0 \to \infty$ . Thus, there is a  $v_0$  such that V(D) < V(A). But this implies  $v_1 < v_0$  and the semi-orbit through A must be bounded. On the other hand, this semi-orbit must also be bounded away from the origin since (1.6a) and hypothesis (1.3c) implies that  $dV/dt \ge 0$  along solutions of (1.4) if  $|u| < \alpha$ . Finally, the Poincaré-Bendixson Theorem implies the existence of a periodic solution of (1.4) and we have

THEOREM 1.5. If G satisfies the conditions (1.3), then equation (1.2) has a nonconstant periodic solution.

![](_page_69_Picture_2.jpeg)

Figure II.1.5

If further hypotheses are made on G, then the above method of proof will yield the existence of exactly one nonconstant periodic solution. In fact, we can prove

THEOREM 1.6. If G satisfies the conditions (1.3) with  $\alpha = \beta$ , then equation (1.2) has exactly one periodic orbit and it is asymptotically stable.

PROOF. With the stronger hypotheses on G, every solution with initial value  $A = (0, v_0), v_0 > 0$ , has an arc of an orbit as shown in Fig. 1.5.

With the notations the same as in the proof of Theorem 1.5 and with  $E = (u_0, 0)$ , we have

$$V(D) - V(A) = \int_{ABECD} G(u) \, dv > 0,$$

if  $u_0 < \alpha$ . This implies no periodic orbit can have  $u_0 < \alpha$ .

For  $u_0 > \alpha$ , if we introduce new variables x = G(u), y = v to the right of line BC in Fig. 1.5 (this is legitimate since G(u) is monotone increasing in this region), then the arc BEC goes into an arc  $B^*E^*C^*$  with end points on the y-axis and the second expression  $\phi(v_0) = \int_{BEC} G(u) \, dv = \int_{B^*E^*C^*} x \, dy$  is the negative of the area bounded by the curve  $B^*E^*C^*$  and the y-axis. Therefore,  $\phi(v_0)$  is a monotone decreasing function of  $v_0$ . It is easy to check that  $\int_{AB} + \int_{BC} G(u) \, du$  is decreasing in  $v_0$  and so V(D) - V(A) is decreasing in  $v_0$ . Also, in the proof of Theorem 1.5, it was shown that V(D) - V(A) approaches  $-\infty$  as  $v_0 \to \infty$ . Therefore, there is a unique  $v_0$  for which  $v_0 = v_0$  and thus a unique nonconstant periodic solution. Theorem 1.4 and Corollary 1.3 imply the stability properties of the orbit and the proof is complete.

An important special case of Theorem 1.6 is the van der Pol equation

(1.7) 
$$\ddot{u} - k(1 - u^2)\dot{u} + u = 0, \quad k > 0.$$

In the above crude analysis, we obtained very little information concerning the location of the unique limit cycle given in Theorem 1.6. When a differential equation contains a parameter, one can sometimes discuss the precise limiting behavior as the parameter tends to some value. This is illustrated with van der Pol's equation. (1.7). Suppose k is very large; more specifically, suppose k = e-1 and let us determine the behavior of the periodic solution as a -->0+. Oscillations of this type are called relaxation oscillations System (1.7) is equivalent to

(1.8) 
$$\varepsilon \dot{u} = v - G(u),$$
 
$$\dot{v} = -\varepsilon u,$$

where G(u) = u3/3 - u. From Theorem 1.6, equation (1.8) has a unique asymptotically stable limit cycle P(e) for every e > 0. From (1.8), if a is small and the orbit is away from the curve v = G(u) in Fig. 1.6, then the u

![](_page_70_Figure_5.jpeg)

coordinate has a large velocity and the v coordinate is moving slowly. Therefore, the orbit-has a tendency to jump in horizontal directions except when it is very close to the curve v = G(u). These intuitive remarks are made precise in

THEOREM 1.7. As s -> 0, the limit cycle of (1.8) approaches the Jordan curve J shown in Fig. 1.6 consisting of arcs of the curve v = G(u) and horizontal line segments.

To prove this, we construct a closed annular region U containing J such that dist(U, J) is any preassigned constant and yet for a sufficiently small, all paths cross the boundary of U inward. U will thus contain (from the Poincare-Bendixson theorem) the limit cycle r(e). The construction of

U is shown in Fig. 1.7 where h is a positive constant. The straight lines 81 and 45 are tangent to v = G(u) + h, v = G(u) - h respectively and the lines 56, 12, 9-10, 13-14, are horizontal while 23, 67, 11-12, 15-16 are vertical. The remainder of the construction should be clear. The inner and outer

![](_page_71_Figure_3.jpeg)

Figure II.1.7

boundaries are chosen to be symmetrical about the origin. Also marked on the figure are arrows designating the direction segments of the boundaries crossed. These are obtained directly from the differential equation and are independent of  $\varepsilon > 0$ . It is necessary to show that the other segments of the boundary are also crossed inward by orbits if  $\varepsilon$  is small. By symmetry, it is only necessary to discuss 34, 45 and 10–11.

At any point (u, G(u) - h) on 34, along the orbits of (1.8), we have

$$\frac{dv}{du} = \frac{-\varepsilon^2 u}{v - G(u)} = \frac{\varepsilon^2 u}{h} < \frac{\varepsilon^2 u(3)}{h}$$

where u(3) is the value of u at point 3. Hence for  $\varepsilon$  small enough, this is less than g(4) < g(u) which is the slope of the curve G(u) - h. Thus,  $\dot{v} < 0$  on this arc implies the orbits enter the region along this arc.

Along the arc 45, we have |v-G(u)|>h and, hence, the absolute value of the slope of the path  $|dv/du|=|-\varepsilon^2u/[v-G(u)]|<\varepsilon^2u(4)/h$  approaches zero as  $\varepsilon\to 0$ . For  $\varepsilon$  small enough this can be made < g(4) which is the slope of the line 45. Thus,  $\dot v<0$  on this arc implies the orbits enter into U if  $\varepsilon$  is small enough.

LetK be the length of the arc 11-12. ForK small enough, Iv - G(u) I > K along the arc 10-11. Hence, Idv/dul along orbits of (1.8) is less than e2,./K < E2u(11)/K, which approaches zero as s --\* 0. Thus, for a small, the orbits enter U since is > 0 on this arc.

This shows that given a region U of the above type, one can always choose a small enough to ensure that the orbits cross the boundary of U inward. This proves the desired result since it is clear that U can be made to approximate J as well as desired by appropriately choosing the parameters used in the construction.

- EXERCISE 1.1. Prove the following Theorem. Any open disk in R2 which contains a bounded semiorbit of (1.1) must contain an equilibrium point. Hint: Use the Poincare-Bendixson Theorem and Theorem I.8.2.'
- EXERCISE 1.2. Give a generalization of Exercise 1.1 which remains valid in R3? Give an example.
- EXERCISE 1.3. Prove the following Theorem. If div f has a fixed sign (excluding zero) in a closed two cell 1, then S2 has no periodic orbits. Hint: Prove by contradiction using Green's theorem over the region bounded by a periodic orbit in 0.
- EXERCISE 1.4. Consider the two dimensional system z =f (t, x), f (t + 1, x) = f (t, x), where f has continuous first derivatives with respect to x. Suppose L is a subset of R2 which is homeomorphic to the closed unit disk. Also, for any solution x(t, xo), x(0, xo) = xo, suppose there is a T(xo) such that x(t, xo) is in 0 for all t >\_ T(xo). Prove by Brouwer's fixed point theorem that there is an integer m such that the equation has a periodic solution of period m. Does there exist a periodic solution of period I?
- EXERCISE 1.5. Suppose f as in exercise (1.4) and there is a A > 0 such that x f (t, x) < -A I X12 for all t, x. If g(t) = g(t + 1) is a continuous function, prove the equation t = f (t, x) + g(t) has a periodic solution of period 1.
- EXERCISE 1.6. Suppose yo is a periodic orbit of a two dimensional system and let- G, and Gi be the sets defined in Theorem 1.4. Is it possible for an equation to have a(y(p)) = yo for all noncritical points p in Gi and co (y(q)) = yo for all q in Ge? Explain.
- EXERCISE 1.7. For Lienard's equation, must there always be a periodic orbit which is stable from the outside? Must there be one stable from the inside? Explain.

EXERCISE 1.8 Is it possible to have a two dimensional system such that each orbit in a bounded annulus is a periodic orbit? Can this happen for analytic systems? Explain.

### 11.2. Differential Systems on a Torus

In this section, we discuss the behavior of solutions of the pair of first order equations

(2.1) 
$$\dot{\phi} = \Phi(\phi, \theta), \\
\dot{\theta} = \Theta(\phi, \theta),$$

where

(2.2) 
$$\Phi(\phi+1, \theta) = \Phi(\phi, \theta+1) = \Phi(\phi, \theta),$$
$$\Theta(\phi+1, \theta) = \Theta(\phi, \theta+1) = \Theta(\phi, \theta).$$

We suppose (D, 0 are continuous and there is a unique solution of (2.1) through any given point in the 0, 0 plane. Since (D, 0 are bounded, the solutions will exist on (- oo, oo).

If opposite sides of the unit square in the (0, 0)-plane are identified, then this identification yields a torus g- and equations (2.1) can be interpreted as a differential equation on a torus. An orbit of (2.1) in the (0, 0)-plane when interpreted on the torus may appear as in Fig. 2.1.

![](_page_73_Figure_10.jpeg)

Figure 11.2.1

We also suppose that (2.1) has no equilibrium points and, in particular, that b(q, 0) 0 0 for all 0, 0. The phase portrait for (2.1) is then determined by

(2.3) 
$$\frac{d\theta}{d\phi} = A(\phi, \theta),$$

$$A(\phi + 1, \theta) = A(\phi, \theta + 1) = A(\phi, \theta),$$

where  $A(\phi, \theta)$  is continuous for all  $\phi$ ,  $\theta$ . The discussion will center around the solutions of (2.3).

The torus  $\mathcal{F}$  can be embedded in  $\mathbb{R}^3$  by the relations

(2.4) 
$$x = (R + r \cos 2\pi \theta) \cos 2\pi \phi.$$

$$y = (R + r \cos 2\pi \theta) \sin 2\pi \phi,$$

$$z = r \sin 2\pi \theta,$$

$$0 \le \phi < 1, 0 \le \theta < 1, 0 < r < R.$$

This embedding is convenient for the sake of terminology only. We shall refer to the circle  $\phi = \text{constant}$  as a meridian and  $\theta = \text{constant}$  as a parallel.

**Example 2.1.** In (2.1), if  $\Phi = 1$ ,  $\Theta = \omega$ , a constant, then  $A(\theta, \phi) = \omega$  in (2.3). The solution  $\theta(\phi, \phi_0, \theta_0)$ ,  $\theta(\phi_0, \phi_0, \theta_0) = \theta_0$  of (2.3) is  $\theta(\phi, \phi_0, \theta_0) = \omega(\phi - \phi_0) + \theta_0$ .

Case (i). If  $\omega$  is rational, say  $\omega = p/q$ , p, q integers, then  $\theta(\phi_0 + q, \phi_0, \theta_0) = \theta_0 + p$ . But, on the torus  $\mathcal{F}$ , the point  $(\phi_0, \theta_0)$  is the same as  $(\phi_0 + q, \theta_0 + p)$  for any integers p, q. Thus, the orbit through  $(\phi_0, \theta_0)$  on  $\mathcal{F}$  is a closed curve for every initial point  $(\phi_0, \theta_0)$ . This implies that the functions in (2.4) expressed as a function of t with the parametric representation of  $\theta$ ,  $\phi$  being given by (2.1) are periodic in t.

Case (ii). If  $\omega$  is irrational, there do not exist integers p, q such that  $\theta(\phi_0 + q, \phi_0, \theta_0) = p + \theta_0$  for any  $\theta_0$ . Therefore, no orbit on  $\mathcal F$  will be closed and the functions in (2.4) will not be periodic. We show in this case that every orbit on  $\mathcal F$  is dense in  $\mathcal F$ . It is sufficient to show that the orbit is dense in the meridian  $\phi = 0$  since the trajectories in the plane all have constant slope  $\omega$ . There is a constant  $\delta > 0$  such that for any  $\gamma$  in [0, 1), there is a sequence of integer pairs  $(q_k, p_k), q_k \to \infty$  as  $k \to \infty$  such that  $|\omega - p_k| q_k - \gamma/q_k| < \delta/q_k^2$ . On  $\mathcal F$ ,  $(q_k, \theta(q_k, 0, 0)) = (0, \omega q_k) = (0, p_k + \gamma + \eta_k) = (0, \gamma + \eta_k)$  where  $\eta_k \to 0$  as  $k \to \infty$ . This proves the orbit through (0, 0) is dense but the same is obviously true for any other orbit. The functions (2.4) will be quasiperiodic in t (for the definition, see the Appendix) with the parametric representation of  $\theta$ ,  $\phi$  being given by (2.1) since for any initial point  $(\phi_0, \theta_0)$  they are obviously representable in the form  $x(t) = \delta_1(t, \omega t)$ ,  $y(t) = \delta_2(t, \omega t)$ ,  $z(t) = \delta_3(t, \omega t)$  where each  $\delta_t$  is periodic in each argument of period 1.

**Example 2.2.** If  $A(\phi, \theta) = \sin 2\pi\theta$ , there are two closed orbits  $\theta = 0$ ,  $\theta = 1/2$  on  $\mathcal{F}$ . It is clear that for any  $\theta_0$ ,  $0 < \theta_0 < 1$ , the corresponding orbit on  $\mathcal{F}$  has  $\omega$ -limit set as the closed orbit  $\theta = 1/2$  and  $\alpha$ -limit set the closed orbit  $\theta = 0$  since the sets  $\theta = 0$  and  $\theta = 1$  on  $\mathcal{F}$  are the same.

There are two striking differences in these examples. In example 2.1 and co irrational, the a- and w-limit set of any orbit on 9- is 9- itself. In example 2.1 with co rational, every orbit is closed whereas in example 2.2, there are isolated closed orbits which are the limit sets of all other orbits. For smooth vector fields, it will be shown below that the w-limit and a-limit sets of any orbit of a general equation (2.3) on 9- must either be 9- itself or a closed orbit.

Since every solution of (2.3) exists on - oo < 0 < oo, it follows that every orbit on 9- must cross the meridian C given by 0 = 0 and therefore it is sufficient to take the initial values as (0, f). Let 6), 0(0, e) = f, designate the solution of (2.3) that passes through (0, 6). From the assumption of uniqueness of solutions of (2.3), the function 0(0, 6) is a monotone increasing function in e for each 0. Also, the mapping e -\* 0(1, f) is a homeomorphism of the real line onto itself and thus induces a homeomorphism T of C onto itself. In fact,

$$TP = P_1, P = (0, \xi), P_1 = (1, \theta(1, \xi)) = (0, \theta(1, \xi)).$$

From the uniqueness of solutions of (2.3), 0(1, 6) is a monotone increasing function and thus T preserves the orientation of C. Also, periodicity of (2.3) and uniqueness of solutions imply

(2.5) 
$$\theta(\phi, \, \xi + m) = \theta(\phi, \, \xi) + m$$

for any integer m.

It is easy to see that

$$T^n P \stackrel{\text{def}}{=} T(T^{n-1}P) = (0, \ \theta(n, \ \xi)); \ T^{m+n}(P) = T^m(T^n P), \ T^0 P = P,$$

for. all m, n = 0, ±1, .... First of all, the definition makes sense for negative values of the integers since 0(1, P) is a homeomorphism and TOP = P imply that P = T(T-1P) uniquely defines T=1. One then inductively defines T-2, T-3, etc. To prove the stated assertions, notice that periodicity in (2.3) and uniqueness of solutions imply that

$$\theta(m, \theta(n, \xi)) = \theta(n, \theta(m, \xi)) = \theta(m + n, \xi).$$

for all integers m, n. This relation immediately yields the above assertions.

THEOREM 2.1. The rotation number of (2.3),

$$ho \stackrel{\mathrm{def}}{=} \lim_{|n| \to \infty} \frac{ heta(n, \xi)}{n},$$

exists and is independent of e. Also, p is rational if and only if some power of T has a fixed point; that is, there is a closed orbit on the torus.

The rotation number can be interpreted as the average rotation about

the meridian for one trip around the parallel or the average slope of the line in the  $(\phi, \theta)$ -plane which passes through the origin and the point  $(n, \theta(n, \xi))$  on the trajectory through  $(0, \xi)$ .

PROOF OF THEOREM 2.1. The proof is in four parts.

(i) If  $\rho$  exists for a  $\xi$ , then it exists for every  $\xi$  and is independent of  $\xi$ . We need only consider  $0 \le \xi$ ,  $\xi < 1$  since  $\theta(\phi, \xi)$  satisfies (2.5). For  $0 \le \xi$ ,  $\xi < 1$ , relation (2.5) and the monotonicity of  $\theta(\phi, \xi)$  in  $\xi$  imply that

$$\theta(\phi,\,\xi)-1=\theta(\phi,\,\xi-1)\leqq\theta(\phi,\,\xi)\leqq\theta(\phi,\,\xi+1)=\theta(\phi,\,\xi)+1,$$

and this gives the desired result.

(ii)  $\rho$  always exists. The following proof was communicated to the author by M. Peixoto. From (i), we need only consider  $\xi = 0$ . For any real  $\xi$  there is an integer m such that  $0 \le \xi - m \le 1$  and thus  $\theta(\phi, 0) \le \theta(\phi, \xi - m) \le \theta(\phi, 1)$  and (2.5) implies

$$\theta(\phi, 0) \le \theta(\phi, \xi) - m \le \theta(\phi, 0) + 1.$$

If  $\gamma = \xi - m$ , then  $0 \le \gamma \le 1$ , and this last relation implies  $\theta(\phi, 0) - \gamma \le \theta(\phi, \xi) - \xi \le \theta(\phi, 0) + 1 - \gamma$ . Since  $0 \le \gamma \le 1$ , we have

$$\theta(\phi, 0) - 1 \le \theta(\phi, \xi) - \xi \le \theta(\phi, 0) + 1$$

for all  $\phi$ ,  $\xi$ . In particular, for any integer m,

(2.6) 
$$\theta(m, 0) - 1 \le \theta(m, \xi) - \xi \le \theta(m, 0) + 1.$$

From this relation, we have  $\theta(2m, 0) = \theta(m, \theta(m, 0))$  satisfies  $2\theta(m, 0) - 2 \le 2\theta(m, 0) - 1 \le \theta(2m, 0) \le 2\theta(m, 0) + 1 \le 2\theta(m, 0) + 2$ .

By successively applying (2.6), we obtain

$$n\theta(m, 0) - n \le \theta(nm, 0) \le n\theta(m, 0) + n$$

for all  $n \ge 0$ , and

$$n\theta(-m, 0) - n \le \theta(-nm, 0) \le n\theta(-m, 0) + n$$

for all  $n \ge 0$ . Thus,

$$\left| \frac{\theta(nm, 0)}{nm} - \frac{\theta(m, 0)}{m} \right| \leq \frac{1}{|m|}$$

for all  $n, m \neq 0$ . Interchanging the role of n, m, we have

$$\left| \frac{\theta(nm, 0)}{nm} - \frac{\theta(n, 0)}{n} \right| \leq \frac{1}{|n|}$$

for all  $n, m \neq 0$ . The triangle inequality implies

$$\left| \frac{\theta(n,0)}{n} - \frac{\theta(m,0)}{m} \right| \leq \frac{1}{|n|} + \frac{1}{|m|},$$

and thus  $\rho$  exists with  $|\rho - \theta(m, 0)/m| \leq 1/|m|$  for all m.

We now give another proof.

The reader may go immediately to part (iii) of the proof of the theorem if he so desires. The idea is best illustrated by another example. The slope of a line L through the origin of the (0, 8)-plane is uniquely determined by the manner in which this line partitions the integer pairs (m, n). More specifically, if Ro is the set of rationals n/m such that the pair (m, n) is below L and B1 the set of rationals such that (m, n) is above L, then one shows that all rational numbers with the possible exception of one are included in R0 or R1, R0 r Rl = o, and therefore the cut defined by R0 and Rl defines a real number which is the slope of the line in question.

This same idea can be used to show that the rotation number p exists. Let L(m, n) be the trajectory of (2.3) through the point (m, n) in the (0, 0) plane and let L = L(0, 0). The curve L(m, n) is the same as L except for a translation. We say L(m, n) is above L if 0(0, in. n) > 0 and below L if 0(0, in, n) < 0, where 8(q, m, n) is the solution of (2.3) with 0(m, m, n) = n. It is clear from uniqueness that this is equivalent to saying that L(m, n) is above (below) L if 0(¢, in, n) > 0(0, 0, 0) (< 0(0,0, 0)). If L(m, n) is above L, then L(km, kn), k a positive integer, is also above L. In fact, L(2m, 2n) is above L(m, n) since L goes to L(m, n) and L(m, n) goes to L(2m, 2n) by the translation (m, n). An induction process gives the result. Applying the translation (-m, -n) to the same curves L and L(m, n), we see that L(-m, -n) is below L and in general L(-km, -kn), k > 0 is below L if L(m, n) is above L. These remarks show there is no ambiguity to the classification of R0 and Rl as before. Namely, n/m belongs to R0 (RI) if L(m, n) is below (above) L. The classes R0 and R1 are nonempty because if n > 0 is sufficiently large, then L(1, n) is above L and L(1, -n) is below L. If n/m is not in R0, and s/r > n/m, then s/r is in R1. In fact, L(rm, rn) is either above L or coincides with L and L(rm, sm) is above L(rm, rn) since it is obtained from it by the translation (0, sm - rn) and sm - rn > 0. Therefore L(rm, sm) is above L which implies rm/sm = r/s belongs to Rl. Similarly, if n/m is not in Rl and s/r < m/n, then s/r is in R0 . Thus, all rational numbers .with possibly one exception are included in R0 or in Rl and Ro and R1 define a real number p.

It remains to show that p is the rotation number defined in the theorem. Suppose m is a given integer and let n be the largest integer such that n/m is in Ro. Then n < pm <\_ n + 1 and every point of L(m, n) is below L and every point of L(m, n + 1) is not below L. Therefore, since the points on L(m, n) are (0 + m, 8(0, 0) + n), we have

$$\theta(\phi, 0) + n < \theta(\phi + m, 0) \le \theta(\phi, 0) + n + 1.$$

In particular, for 0 = 0,

$$n < \theta(m, 0) \leq n + 1,$$

and

$$\left| \frac{\theta(m,0)}{m} - \rho \right| \le \left| \frac{n}{m} - \rho \right| + \frac{1}{|m|}.$$

One can approximate  $\rho$  by a sequence of rationals n/m,  $|m| \to \infty$ , such that  $|\rho - n/m| < \kappa/|m|$  for some constant  $\kappa$ . Thus,

$$\left| \frac{\theta(m,0)}{m} - \rho \right| \leq \frac{\kappa + 1}{|m|}.$$

This clearly implies that  $\rho = \lim_{|m| \to \infty} \theta(m, 0)/m$ .

(iii) If some power of T has a fixed point, then  $\rho$  is rational. In fact, if there is an integer m and a  $\xi$  in [0, 1) such that  $T^m\xi = \xi$ , there is also an integer k such that  $\theta(m, \xi) = \xi + k$ . Since  $\rho = \lim_{|m| \to \infty} \theta(m, \xi)/m$  exists we have

$$\rho = \lim_{|n| \to \infty} \frac{\theta(nm, \xi)}{nm} = \lim_{|n| \to \infty} \frac{\xi + nk}{nm} = \frac{k}{m}$$

and  $\rho$  is rational.

(iv) If  $\rho$  is rational, some power of T has a fixed point. Suppose  $\rho = k/m$ , k, m integers, m>0, and  $T^m$  has no fixed points. Then, for every  $\xi$ ,  $0 \le \xi \le 1$ ,  $\theta(m,\xi) \ne \xi+k$ . If we suppose  $\theta(m,\xi) > \xi+k$  for  $\xi$  in [0,1), then there is an a>0 such that  $\theta(m,\xi)-\xi-k \ge a>0$ ,  $\xi$  in [0,1). For any  $\zeta$  in  $(-\infty,\infty)$ , there are an integer p and a  $\xi$  in [0,1) such that  $\zeta=p+\xi$ . Relation (2.5) then implies  $\theta(m,\zeta)-\zeta-k \ge a$  for all  $\zeta$  in  $(-\infty,\infty)$ . A repeated application of this inequality yields  $\theta(rm,\xi)-\xi \ge r(k+a)$  for any integer r. Dividing by rm and letting  $r\to\infty$  we have  $\rho \ge k/m+a/m$  which is a contradiction. This completes the proof of the theorem.

Corollary 2.1. Among the class of functions  $A(\phi, \theta)$  which are Lipschitzian in  $\theta$ , the rotation number  $\rho = \rho(A)$  of (2.3) varies continuously with A; that is, for any  $\varepsilon > 0$  and A there is a  $\delta > 0$  such that  $|\rho(A) - \rho(B)| < \varepsilon$  if  $\max_{0 \le \phi, \theta \le 1} |A(\phi, \theta) - B(\phi, \theta)| < \delta$ .

PROOF. If  $\theta_A(\phi, 0)$  and  $\theta_B(\phi, 0)$  designate the solutions of (2.3) for A and B, respectively,  $z(\phi) = \theta_A(\phi, 0) - \theta_B(\phi, 0)$ , and L is the Lipschitz constant for A, then

$$\frac{dz}{d\phi} = [A(\phi, z(\phi) + \theta_B(\phi, 0)) - A(\phi, \theta_B(\phi, 0))]$$
$$-[B(\phi, \theta_B(\phi, 0)) - A(\phi, \theta_B(\phi, 0))],$$

and

$$\left|D_r|z\right| \leq \left|\frac{dz}{d\phi}\right| \leq L\left|z\right| + \sup_{0 \leq \phi, \, \theta \leq 1} \left|B(\phi, \, \theta) - A(\phi, \, \theta)\right|$$

for all  $\phi$ . Thus,

$$\left|\theta_A(\phi,\,0)-\theta_B(\phi,\,0)\right|\leqq L^{-1}e^{L\phi}\sup_{0\le\phi,\,\theta\le1}\left|B(\phi,\,\theta-A(\phi,\,\theta))\right|$$

for all  $\phi \geq 0$ .

In the proof of part (ii) of Theorem 2.1, an estimate on the rate of approach of the sequence  $\theta_A(m,0)/m$  to the rotation number  $\rho(A)$  was obtained; namely,  $|\theta_A(m,0)/m - \rho(A)| < 1/|m|$  for all m. Therefore,

$$\begin{aligned} |\rho(A) - \rho(B)| &\leq \left| \rho(A) - \frac{\theta_A(m, 0)}{m} \right| \\ &+ \left| \frac{\theta_A(m, 0) - \theta_B(m, 0)}{m} \right| + \left| \frac{\theta_B(m, 0)}{m} - \rho(B) \right| \\ &\leq \frac{2}{|m|} + \left| \frac{\theta_A(m, 0) - \theta_B(m, 0)}{m} \right| \end{aligned}$$

for all integers m. For any  $\varepsilon > 0$ , choose |m| so large that  $1/|m| < \varepsilon/3$ . For any such given but fixed m, choose  $\delta > 0$  such that  $|\theta_A(m, 0) - \theta_B(m, 0)| \le 1$  if  $\max_{0 \le \theta, \phi \le 1} |A(\phi, \theta) - B(\phi, \theta)| < \delta$ . This fact and the preceding inequality prove the result.

The conclusion of Corollary 2.1 actually is true without assuming  $A(\phi, \theta)$  is Lipschitzian in  $\theta$ . The proof would use a strengthened version of Theorem I.3.4 on the continuous dependence of solutions of differential equations on the vector field when uniqueness of solutions is assumed. It is an interesting exercise to prove these assertions.

Theorem 2.2. If the rotation number  $\rho$  is rational, then every trajectory of (2.3) on the torus is either a closed curve or approaches a closed curve.

PROOF. (Peixoto). Since  $\rho$  is rational, there exists a closed trajectory  $\gamma$  on  $\mathcal F$  which intersects every meridian of  $\mathcal F$ . Therefore,  $\mathcal F\setminus \gamma$  is topologically equivalent to an annulus  $\Gamma$ . The differential equation (2.3) on  $\mathcal F\setminus \gamma$  is equivalent to a planar differential equation on  $\Gamma$ . Since there are no equilibrium points, the Poincaré-Bendixson Theorem, Theorem 1.2, yields the conclusion of the theorem.

The remainder of this chapter is devoted to a discussion of the behavior of the orbits of (2.3) when the rotation number  $\rho$  is irrational.

Let  $T: C \to C$  be the mapping induced by (2.3) which takes the meridian C of  $\mathcal T$  into itself. For any P in C, let

$$D(P) = \{T^n P, n = 0, \pm 1, \pm 2, \ldots\},\$$

and D'(P) be the set of limit points of D(P). Also, let  $\emptyset$  be the empty set.

LEMMA 2.1. Suppose p is irrational, m, n are given integers, P is a given point in C and a, fi are the closed arcs of C with a n fl = {TmP, TnP}, a u \$ = C. Then D(Q) n 0 ° ¢ o, D(Q) n #° 0 0 for every Q in C, where a°, 90 are the interiors of a, P respectively.

PROOF. The set UkTk(m-n)ao covers C. For, if not, the sequence {Tk(m-n)(TnP)} would approach a limit Po and T(m-n)Po = P0 which, from Theorem 2.1, contradicts the fact that p is irrational. Consequently, for any Q in C, there is an integer p such that Q is in TP(m-n)ao; that is, TP(n-m)Q is in a° and D(Q) n 0 ° o. The same argument applies to S.

THEOREM 2.3. If p is irrational, D'(P) = F is the same for all P, TF = F and either

(i) F = C (the ergodic case)

or

(ii) F is a nowhere dense perfect set.

PROOF. If S belongs to D'(P), there is a sequence {Pk} c D(P) approaching S as k -\*co. For any pointsPk, Pk+I of this sequence and Q in C, it follows from Lemma 2.1 that there is an integer nk such that TnkQ belongs to the shortest of the arcs cc, 9 on C connecting these two points. Therefore TnkQ ->S as k --> oo and D'(P) c D'(Q). The argument is clearly the same to obtain D'(Q) c D'(P) which proves the first statement of the theorem.

If Q is in F, then there is a sequence nk and a P such that Tnk P \_\*Q as n oo. This clearly implies TQ belongs to F and T-1Q belongs to F. Therefore T F = F.

If R is an arbitrary element of F, then the fact that F = D'(Q) for every Q implies for any Q e F there is a sequence of integers nk such that TnkQ -. R. Therefore, the set of limit points of F is F itself and F is perfect.

Suppose F contains a closed arc y of C. Then y contains a closed subarc a with endpoints TnP, TmP for some integers n, m and P in C. Therefore, by Lemma 2.1, Uk Tka covers C and since Ta, T2a, ... belong to F we have F = C. This proves the theorem.

Our next objective is to obtain sufficient conditions which will ensure that T is ergodc; that is, the limit set F of the iterates of T is C.

Let Pn = TnP, n = 0, ±1, ±2, .... If p is irrational and a is any closed are of C with P as an endpoint, Lemma 2.1 implies there is an integer n such that either Pn or P\_n is the only point Pk in the interior a° of a for Ikj < n. Since no power of T has a fixed point, for any N > 0, a can be chosen so small that n >\_ N. For definiteness, suppose P\_n is in 0°. Let P0 P\_n denote the are of C with endpoints P°, P\_n and which also belongs to cc. We associate an orientation to this are which is the same as the orientation of

C. Also, let  $P_k P_{k-n}$ ,  $k = 0, 1, \ldots, n-1$ , designate the arc of C joining  $P_k$ ,  $P_{k-n}$  which has the same orientation as C.

LEMMA 2.2. The arcs  $P_k P_{k-n}$ ,  $k = 0, 1, \ldots, n-1$ , are disjoint.

PROOF. If the assertion is not true, then there exists an  $\ell$  from the set  $\{-n, -n+1, \ldots, n-1\}$  and a k from  $\{0, 1, \ldots, n-1\}$  such that  $P_{\ell}$  belongs to the interior  $P_k P_{k-n}^0$  of  $P_k P_{k-n}$ . Therefore,  $P_{\ell-k}$  is in  $P_0 P_{-n}^0$ , from the orientation preserving nature of powers of T. This is impossible in case  $-n \leq l-k < n$  from the choice of n. Suppose  $-2n+1 \leq l-k < -n$ . Since  $P_{\ell}$  belongs to  $P_k P_{k-n}^0$ , it follows that  $P_{\ell+n} P_{\ell}$  and  $\overline{P_k} P_{k-n}$  intersect and, in particular,  $P_k$  is in  $P_{\ell+n} P_{\ell}^0$ . Thus  $P_{k-n-\ell}$  is in  $P_0 P_{-n}^0$  which is impossible since  $0 < k-\ell-n < n$ . This proves the lemma.

THEOREM 2.4. Let  $\psi(\xi) = \theta(1, \xi)$ ,  $0 \le \xi \le 1$ . If  $\rho$  is irrational and  $\psi$  possesses a continuous first derivative  $\psi' > 0$  which is of bounded variation, then T is ergodic.

Proof. Let  $\xi_k = \psi^k(\xi)$ ,  $k = 0, \pm 1, \ldots, \psi^0(\xi) = \xi$ , be recursively defined by choosing  $\psi^{-1}(\xi)$  as the unique solution of  $\psi^0(\xi) = \psi(\psi^{-1}(\xi))$ . Then  $T^k P = (0, \psi^k(\xi))$ ,  $P = (0, \xi)$ . From the product rule for differentiation, we have

$$\frac{d\psi^{k}(\xi)}{d\xi} = \prod_{j=0}^{k-1} \psi'(\xi_{j}), \frac{d\psi^{-k}(\xi)}{d\xi} = \left[\prod_{j=0}^{k-1} \psi'(\xi_{j-k})\right]^{-1}$$

where  $\psi'(\xi) = d\psi(\xi)/d\xi$ . Suppose P and n are chosen as prior to Lemma 2.2. Since  $P_k P_{k-n}$ ,  $k = 0, 1, \ldots, n-1$ , are disjoint we have

$$\left| \log \left( \frac{d\psi^{n}(\xi)}{d\xi} \frac{d\psi^{-n}(\xi)}{d\xi} \right) \right| = \left| \log \left( \prod_{j=0}^{n-1} \psi'(\xi_{j}) \right) - \log \left( \prod_{j=0}^{n-1} \psi'(\xi_{j-n}) \right) \right|$$

$$= \left| \sum_{j=0}^{n-1} [\log \psi'(\xi_{j}) - \log \psi'(\xi_{j-n})] \right|$$

$$\leq V$$

where V is the total variation of  $\log \psi'$ . This function has bounded variation from the hypothesis on  $\psi'$ . Therefore,

$$e^{-V} \le \frac{d\psi^n(\xi)}{d\xi} \frac{d\psi^{-n}(\xi)}{d\xi} \le e^V$$

uniformly on n and  $\xi$ .

Suppose  $\alpha$  is any arc on C of length  $\delta$ . If  $\delta_k$  is the length of  $T^k\alpha$ , then

$$\delta_k + \delta_{-k} = \int_a \! \left( \frac{d\psi^k}{d\xi} + \frac{d\psi^{-k}}{d\xi} \right) d\xi \geqq 2 \int_a \! \left( \frac{d\psi^k}{d\xi} \frac{d\psi^{-k}}{d\xi} \right)^{\!\!\!\!\!\!\!\!\!\!\!\!\!\!\!\!\!\!\!\!\!\!\!\!\!\!\!\!\!\!\!\!\!\!\!\!$$

and, therefore,  $\delta_k + \delta_{-k}$  does not approach zero as  $k \to \infty$ .

If C\F is not empty (that is, T is not ergodic), then take an open are a in C\F with end points in F. This can be done since F is nowhere dense and perfect. Since TF = F and T preserves orientation, all of the arcs Tka, k =0, +1, ... are in C\F. Also Tka o Vex = 0, k =A j, since the end points of these arcs are in F and if one coincided with another the end points would correspond to a fixed point of a power of T. Therefore, compactness of C yields 8k + S\_k -. 0 as k --> oo. This contradiction implies C\F is empty and proves the theorem.

Remark. The smoothness assumptions on 0 in Theorem 2.4 are satisfied if A (0, 8) in (2.3) has continuous first and second partial derivatives with respect to 0. In fact, Theorem 1.3.3 and exercise 1.3.2. imply that 0'(6), 1"(C) are continuous and, in particular, &'(C) is of bounded variation for 0 < 6 < 1. Also, this same theorem states that 80(¢, C)/8e is a solution of the scalar equation

$$\frac{dy}{d\phi} = \frac{\partial A(\phi, \, \theta)}{\partial \theta} \, y,$$

with initial value 1 at = 0. Thus, O'(C) = 80(1, e)/8e > 0, 0 \_< C < 1.

Denjoy [1] has shown by means of an example that Theorem 2.4 is false if the smoothness conditions on 0 are relaxed.

There is no known way to determine the explicit dependence of the rotation number p of (2.3) on the function A(q, 0), and, thus, in particular, to assert whether or not p is irrational. However, the result of Denjoy was the first striking example of the importance of smoothness in differential equations to eliminate unwanted pathological behavior.

Suppose the notation is the same as in Theorem 2.4 and the proof of Theorem 2.4.

LEMMA 2.3. If p is irrational and a is a fixed real number, then the function g(Cn + m) = np + m, en = On (e), n, m integers, is an increasing function on the sequence of real numbers {en + m}.

PROOF. Throughout this proof,. n, m, r, s will denote integers. The order of the elements in {C + m} does not depend upon e; that is, en + m < \$r + s implies 4. + m < + s for any C. This is equivalent to saying that fn - Cr < s - m implies n - r < s - m for any C. If this were not true, there would be an 71 such that '']n -'fir is an integer which in turn implies some power of T has a fixed point, contradicting the fact that p is irrational. It suffices therefore to choose e = 0.

Recall that 0m(0) = 0(m, 0). If p < 0(m, 0) < r, then a repeated application of (2.6) yields

$$\theta(m, 0) + (k-1)p \le \theta(km, 0) \le \theta(m, 0) + (k-1)r$$

for any k > 0. Thus,

$$\frac{\theta(m,\,0)}{k} + \left(1 - \frac{1}{k}\right)p \leq m\,\frac{\theta(km,\,0)}{km} \leq \frac{\theta(m,\,0)}{k} + \left(1 - \frac{1}{k}\right)r.$$

Taking the limit as  $k \to \infty$ , we obtain  $p \le m\rho \le r$ . Since  $\rho$  is irrational,  $p < m\rho < r$ .

Now suppose  $\theta(n, 0) + m < \theta(r, 0) + s$ , that is,  $\theta(n, m) < \theta(r, s)$ . Then  $\theta(n-r, m) < \theta(0, s)$  or  $\theta(n-r, 0) + m < s$ . From the preceding paragraph, this implies  $\rho(n-r) < s - m$ , or  $\rho n + m < \rho r + s$ , which was to be proved.

THEOREM 2.5. If T is ergodic with (irrational) rotation number  $\rho$ , then T is topologically equivalent to a rotation of the circle C by an angle  $2\pi\rho$ ; that is, there is a homeomorphism G of C onto C such that GT = RG where R is the rotation of C through the angle  $2\pi\rho$ .

PROOF. Let g be the increasing function defined in Lemma 2.3,  $A = \{n\rho + m\}$ ,  $B = \{\xi_n + m\}$ , n, m integers. Since T is ergodic, B is dense on the real numbers and since  $\rho$  is irrational, A is also dense on the real numbers. The function g is continuous from B to A. Since B is dense, g has a unique continuous increasing extension to all of the reals. We again designate this function by g.

If 
$$\eta = \xi_n + m$$
,  $g(\eta) = n\rho + m$ , then

(2.7) 
$$g(\eta+1) = n\rho + m + 1 = g(\eta) + 1,$$
$$g(\psi(\eta)) = g(\psi(\xi_n + m)) = g(\psi(\xi_n) + m) = g(\xi_{n+1} + m)$$
$$= (n+1)\rho + m = g(\eta) + \rho.$$

Since B is dense and g is continuous, it follows that  $g(\eta+1)=g(\eta)+1$ ,  $g(\psi(\eta))=g(\eta)+\rho$  for all real  $\eta$ . The homeomorphism  $G\colon C\to C$  is defined by  $G(\eta)=g(\eta), 0\leq \eta<1$ . The relation  $g(\psi(\eta))=g(\eta)+\rho$  implies that GT=RG and the theorem is proved.

THEOREM 2.6. (Bohl). If T is ergodic, there exists a function  $\omega(y, z)$  which is continuous in y, z and

$$\omega(y+1,z) = \omega(y,z+1) = \omega(y,z)$$

for all y, z such that every solution  $\theta$  of (2.3) satisfies

(2.8) 
$$\theta(\phi) = \rho\phi + c + \omega(\phi, \rho\phi + c),$$

where c is a constant and  $\rho$  is the rotation number. Conversely, for any constant c,  $\theta(\phi)$  given in (2.8) satisfies (2.3). Each c in [0, 1) corresponds to a unique  $\theta(0)$  (mod 1).

**PROOF.** Let  $\xi$  be any real number and  $\theta(\phi, \xi)$  be the solution of (2.3)

with  $\theta(0, \xi) = \xi$ . We know that

$$\theta(\phi, \xi + 1) = \theta(\phi, \xi) + 1,$$
  
$$\theta(\phi + 1, \xi) = \theta(\phi, \psi(\xi)),$$

where as before  $\psi(\xi) = \theta(1, \xi)$ . Let g be the function given in the proof of Theorem 2.5 and let h denote the inverse of g. From the properties (2.7) of g, we have

$$h(c+1) = h(c) + 1,$$
  

$$\psi(h(c)) = h(c+\rho).$$

If  $\bar{\theta}(\phi, c) = \theta(\phi, h(c))$ , then

$$\bar{\theta}(\phi, c+1) = \theta(\phi, h(c+1)) = \theta(\phi, h(c)+1) = \theta(\phi, h(c)) + 1 = \bar{\theta}(\phi, c) + 1,$$

and

$$\bar{\theta}(\phi+1, c) = \theta(\phi+1, h(c)) = \theta(\phi, \psi(h(c))) = \theta(\phi, h(c+\rho)) = \bar{\theta}(\phi, c+\rho).$$

If  $\omega(y, z) = \bar{\theta}(y, z - \rho y) - z$  for all real y, z, then one easily observes that  $\omega(y, z + 1) = \omega(y + 1, z) = \omega(y, z)$ . Therefore,

$$\theta(\phi, h(c)) \stackrel{\text{def}}{=} \bar{\theta}(\phi, c) = \rho\phi + c + \omega(\phi, \rho\phi + c),$$

which proves the theorem.

EXERCISE 2.1. All functions below are continuous, periodic in  $\theta$ ,  $\phi$  of period 1 and smooth enough to ensure a unique solution of the equations for any initial values.

- (a) What is the rotation number of  $d\theta/d\phi = \sin 2\pi\theta$ ?
- (b) If  $|g(\theta)| < 1$ ,  $0 \le \theta \le 1$ , what is the rotation number of  $d\theta/d\phi = \sin 2\pi\theta + g(\theta)$ ?
- (c) Using the Poincaré-Bendixson theorem, prove that the rotation number of  $d\theta/d\phi = \sin 2\pi\theta + \epsilon g(\theta, \phi)$  is rational if  $|\epsilon|$  is small enough.
- (d) Use the Brouwer fixed point theorem and the construction used in part (c) to show that the rotation number of the equation in (c) is zero if  $|\varepsilon|$  is small enough.

EXERCISE 2.2. Suppose  $\omega$  is irrational. For any  $\varepsilon > 0$ , show there exists a function  $g(\theta, \phi)$  continuous in  $\theta$ ,  $\phi$  of period 1 such that  $\max\{|g(\theta, \phi)|, 0 \le \theta, \phi \le 1\} < \varepsilon$  and the rotation number of  $d\theta/d\phi = \omega + g(\theta, \phi)$  is rational and not all orbits are closed on the torus. Hint: Choose sequences of integers  $\{p_k\}, \{q_k\}, q_k \to \infty$  as  $k \to \infty$  such that  $|\omega - p_k/q_k| < \gamma/q_k^2$  for some constant  $\gamma$  and consider  $g(\theta, \phi) = a \sin 2\pi(b\theta + c\phi)$  for appropriate constants a, b, c.

EXERCISE 2.3. In Exercise 2.1, arbitrarily small changes in the vector field did not change the rotation number, whereas in Exercise 2.2, an appropriate small change in the vector field did change this number. Can you explain why this is so? Can you give a general result for equation (2.3) which will exhibit the same properties relative to the rotation number as Exercises 2.1 and 2.2? What would you say is the most typical behavior among all vector fields (2.3)?

EXERCISE 2.4. (a) For any continuous function f (0) of period 1, show that the equation dO/do = 27r0 + f (0) has a unique periodic solution of period 1. (Hint: Look at f<sup>0</sup> e2n(0-s)f (s) ds).

- (b) Designate this unique solution by Kf. If P is the Banach space of continuous periodic functions of period 1 with the topology of uniform convergence, show that K: P --\* P is continuous and linear.
- (c) Suppose g(O, 0) has period 1 in 0, 0, is continuous in 0, 0 and lipschitzian in O. Using the contraction principle and part (b), show there is an Eo > 0 such that the equation dO/dc = 27TO + (sin 27rO - 27r0) + eg(O, has a solution which is periodic in 0 of period 1 if JEI < Eo.

## II.3. Remarks and Suggestions for Further Study

For many more details on the general theory of two dimensional systems, see Hartman [1], Lefschetz [1], Sansone and Conti [1]. The book of Sansone and Conti [1] also contains a wealth of applications of the Poincare-Bendixson theory to the existence of periodic solutions of a second order autonomous equation. Finding periodic solutions of nonautonomous equations by extensions of the ideas in Exercises 1.4 and 1.5 can be found, for example, in Cartwright [1], Levinson [1], Lefschetz [1], Sansone and Conti [1]. An interesting discussion of the global stability of the origin in the plane is given by Olech [1].

One result obtained for two dimensional systems in the plane was that the only compact minimal sets are points and closed curves. For a singularity free " smooth " vector field on the torus, the only minimal sets on the torus are closed curves and the torus itself. An outstanding problem for many years was the characterization of the minimal sets of " smooth " vector fields on an arbitrary compact two dimensional manifold. This problem was solved by Schwartz [1] when he proved that the only possible minimal sets are points, closed curves and a torus, the latter being possible only when the manifold is itself a torus.

It is difficult to pose questions in n dimensions with answers as elegant as the ones given in this chapter. One problem that has been studied in

considerable detail arises from a more careful study of Theorems 2.5 and 2.6. Consider a differential equation on an n-dimensional torus

$$\dot{x} = f(x)$$

where x = (xi, ... , xn), f (xl, ... , xn) is periodic in each variable of period 1. Problem: When does there exist a transformation of variables x = g(y) such that the new equation for y is y = w where w is a constant n-vector? If such a transformation exists, then the resulting flow is easy to analyze and one has a generalization of Theorem 2.6. For f (x) = co + eh(x) where a is small and co belonging to a certain class of irrationals,- some results along this line are available (see Arnol'd [1]). The techniques of proof are currently the most important tools in the study of stability in celestial mechanics (see Kolmogorov [1], Arnol'd [2], Moser [1]).

In Section 1, the van der Pol equation (1.7) was discussed when the parameter k was large. In the coordinates described by (1.8), it becomes clear that the asymptotically stable periodic orbit has the property that the system moves along its orbit at a reasonable pace as long as it remains close to a given curve and then moves at a very rapid pace away from this curve. Such relaxation oscillations are very important in the applications and the reader may consult van der Pol [1, 2], LaSalle [1], Minorsky [1], Pontryagin and Mishchenko [1].

## CHAPTER III

## Linear Systems and Linearization

In the previous chapter, much information concerning the qualitative behavior of solutions of two dimensional autonomous systems was obtained without using any particular properties of the vector field. In higher dimensions and even in two dimensions when more specific information is desired, one must resort to techniques which are more analytical in nature and yield information only in a neighborhood of some solution or an invariant set of solutions.

If 0(t) is a solution of

$$\dot{x} = f(x),$$

where f has continuous first derivatives, then x = 0(t) + y in (1) implies

$$\dot{y} = A(t)y + g(t, y)$$

where A(t) = 8f (q(t))/2x and g(t, 0) = 0, ag(t, 0)/ay = 0. It is quite natural to study the linear equation

$$\dot{z} = A(t)z,$$

and to inquire about the relationship between the solution z of (3) and the solution y of (2) in a neighborhood of y = 0. More specifically, is the linear equation (3) a good "approximation" to equation (2) near y = 0? Some questions of this type are considered in this chapter.

More precisely, the theory of general linear systems is given in Section 1 with Section 2 being devoted to characterizations of the concepts of stability for linear systems and the preservation of these stability properties for special perturbations of a linear system. Section 3 is a specialization of the general theory to nth order equations. In Section 4, the fundamental solution of linear autonomous systems is characterized in terms of the elementary functions with the phase portrait of the two dimensional systems iscussed in Section 5. Section 6 is devoted to an autonomous equation (2) with no eigenvalue of A on the imaginary axis. It is shown in this section that many of the qualitative properties of the solutions of the linear and nonlinear equation

are the same near y = 0. Section 7 gives the theory of linear equations with periodic coefficients with the Fli quet representation included. Sections 8, 9 and 10 are devoted to stability theory for special classes of linear equations with periodic coefficients.

### IIl.1. General Linear Systems

Consider the linear system of n first order equations

(1.1) 
$$\dot{x}_j = \sum_{k=1}^n a_{jk}(t)x_k + h_j(t), \quad j = 1, 2, \ldots, n,$$

where the ajk and h1 for j, k = 1, 2, ... , n are continuous real or complex valued functions on the interval (- oo, + co). In matrix notation, equation (1.1) can be written in more compact form as

$$(1.2) \dot{x} = A(t)x + h(t)$$

where A = a k), j, k = 1, 2, ..., n; h = col hl, ..., ha The basic characteristic property of linear systems of the form (1.2) is the IPrinci le of Superposition 1 If x is a solution of (1.2) corresponding to the " forcing function " or " input " h and y is a solution corresponding to g then cx + dy is a solution corresponding to the forcing or input function ch + dg for any real or complex numbers c and d.

This principle is verified by direct computation.

In particular, if c = - d = 1, h = g, then x and y being solutions of (1.2) corresponding to the forcing function h implies that x - y is a solution of the homogeneous equation

$$\dot{x} = A(t)x.$$

If 0(t, c) is a general solution of the homogeneous equation (1.3) and xp(t) is any particular solution of (1.2), then this latter property states that any solution of (1.2) is of the form 0(t, c) +xp(t) for some c. Below, we describe theoretically how to obtain the general solution of (1.3) and then show that a particular solution of (1.2) can be found from the knowledge of the general solution of (1.3) and a quadrature.

From the properties of the coefficient matrix A and the forcing function h in (1.2), the basic existence and uniqueness theorem in Chapter I implies that the initial value problem for (1.2) has a unique solution which exists on an interval containing- the initial time. Theorem 1.6.2 also asserts that every solution of (1.2) exists on the infinite interval (- oo, + oo). -

A set of vectors x1, ..., xn are said to be linearly independent if 1 cp x1 = 0 for any complex constants c2 implies c, = 0 for j = 1, ... , n.

The vectors x1, . . . , xn are said to be linearly dependent if they are not linearly independent. The proof of the following lemma is left as an exercise.

LEMMA 1.1. The vectors x1, ..., xn are linearly independent if and only if det[xl, ... , xn] z/-- 0.

An n x n matrix X (t), t > 0, is said to be an n x n matrix solution of (1.3) if each column of X(t) satisfies (1.3). A fundamental matrix solution of (1.3) is an n x n matrix solution X(t) of (1.3) such that det X(t) =0. A principal matrix solution of (1.3) at initial time to is a fundamental matrix solution such that X(to) = I, the identity matrix. The principal matrix solution at to will be designated by X(t, to).

From the above definition of a fundamental matrix solution it is clear that a fundamental matrix solution is simply a matrix solution of (1.3) such that the n columns of X(t) are linearly independent. An elementary but useful property of a matrix solution of (1.3) is

LEMMA 1.2. If X(t) is an n x n matrix solution of (1.3), then either detX(t)zA 0 for all t or det X(t) = 0 for all t.

PROOF. If there exists a real number r such that the matrix X(r) is singular, then there exists a nonzero vector c such that X (-r)c = 0. For this vector c, linearity of (1.3) implies the function x(t) = X(t)c is a solution of (1.3). Since the function x = 0 is obviously a solution of the equation, uniqueness implies X(t)c = 0 for all t in (- oo, oo) and thus det X (t) = 0 for all t in (- oo, oo ). This proves the lemma.

COROLLARY I.I. If Xo is an n x n nonsingular matrix and if X(t) is the matrix solution of (1.3) with X(0)=Xo, then X(t) is a fundamental matrix solution of (1.3).

Corollary 1.1 shows that the determination of a fundamental matrix solution consists only of selecting n linearly independent initial vectors and finding the corresponding n linearly independent solutions of the system (1.3). The fact that the matrix X(t) is nonsingular for all t yields the following important

LEMMA 1.3. If X(t) is any fundamental matrix solution of (1.3), then a general solution of (1.3) is X(t)c where c is an arbitrary n vector.

PROOF. It is clear that the function x(t) = X(t)c is a solution of (1.3) for any constant n-vector c. Furthermore, if to and xo are given, then X(t)c, c =X-1(to)xo, is the solution of (1.3) which passes through the point (to, xo).

LEMMA 1.4. If X(t) is a fundamental matrix solution of (1.3), then the matrix X-1(t) is a fundamental matrix solution of the adjoint equation

(1.4) 9 = -yA(t)

where y is a row n-vector; that is, each row of X-1 satisfies (1.4) and det X-1(t) 0.

PROOF. Let Y(t) = X-1(t). Since YX = I, the identity, it follows that 1X + YAX = 0. Since X is non-singular this implies that Y = X-1 is a matrix solution of the adjoint equation (1.4). This is equivalent to saying that each row of the matrix X-1 is a solution of (1.4). X-1 is obviously nonsingular.

I THEOREM 1.1. If X is a fundamental matrix solution of (1.3) then every solution of (1.2) is given by formula

(1.5) 
$$x(t) = X(t) \left[ X^{-1}(\tau)x(\tau) + \int_{\tau}^{t} X^{-1}(s)h(s) \ ds \right]$$

for any real number r in (- oo, + co).

Formula (1.5) is referred to as the variation of constants formulalfor (1.2). The reason for this is clear since it implies that every solution has the form X(t)c(t) where c(t) is the function given in the brackets in (1.5). This is the same form as the general solution of (1.3) given by Lemma 1.3 except that the vector c now depends upon the independent variable t.

PROOF OF THEOREM 1.1. If we rewrite equation (1.2) as z - Ax = h and use the fact that X-1 is a matrix solution of the adjoint equation (1.4), then equation (1.2) is equivalent to

$$\frac{d}{ds}[X^{-1}(s)x(s)] = X^{-1}(s)h(s).$$

Integrating this expression from r to t for any real numbers r and t, we obtain

$$X^{-1}(t)x(t) - X^{-1}( au)x( au) = \int_{ au}^{t} X^{-1}(s)h(s) \ ds.$$

A rearrangement of the terms in this expression yields equation (1.5) and the theorem is proved.

We give another proof of this theorem. Since X(t) is nonsingular for each t, it follows that the transformation of variables x = X(t)y defines a homeomorphism of Rn into Rn for each 't. If this transformation is applied to (1.2), then by Lemma 1.4,

$$\dot{y} = rac{d}{dt} [X^{-1}x] = X^{-1}(Ax + h) - X^{-1}Ax = X^{-1}h.$$

This implies that

$$y(t) = X^{-1}( au)x( au) + \int_{ au}^{t} X^{-1}(s)h(s)$$

since y(T) =X-1(T)x(T). The formula x(t) = X(t)y(t) yields relation (1.5). If for any given r in (-oo, co), we let X(t, T), X(T, T) = I, designate the principal matrix solution of (1.3) at T, then

$$(1.6) X(t, \tau) = X(t, s)X(s, \tau)$$

for all t, T, s. In fact, considered as functions of t, both sides of this relation satisfy (1.3) and coincide for t = 8. Uniqueness yields the result. This formula leads to a simplification of the variation of constants formula; namely

(1.7) 
$$x(t) = X(t, \tau)x(\tau) + \int_{-t}^{t} X(t, s)h(s) ds.$$

LEMMA 1.5. If X(t) is an n x n matrix solution of (1.3), then

(1.8) 
$$\det X(t) = [\det X(t_0)] \exp \left( \int_{t_0}^t \operatorname{tr} A(s) \, ds \right)$$

for all t, to in (-oo, oo), where tr A is the sum of the diagonal elements of A.

The proof is easily supplied by showing that det X(t) satisfies the scalar equation z = [tr A(t)]z and is left as an exercise for the reader.

The above theory is valid for linear systems with A(t), h(t) integrable in t. If the elements of the matrix A(t) and the components of h(t) are only Lebesgue integrable on every compact subset of R, then the results of Section 1.5 imply that the initial value problem for (1.2) has a unique solution. If x(t) = x(t, to, xo), x(to, to, xo) = xo, is a solution of (1.2) then

$$|x(t)| \le |x_0| + \int_{t_0}^t |h(s)| \ ds + \int_{t_0}^t |A(s)| \ |x(s)| \ ds, \qquad t \ge t_0,$$

as long as x(t) is defined. The generalized Gronwall inequality (Lemma 1.6.2 and an integration by parts implies

$$|x(t)| \le \left(\exp \int_{t_0}^t |A(s)| ds\right) \left[|x_0| + \int_{t_0}^t |h(s)| ds\right]$$

for all t >\_ to for which x(t) is defined. The continuation theorem implies x(t) is defined for t >\_ to. Replacing t by to - u and using similar estimates one obtains existence of x(t, to, xo) fort < to. The general structure of the solutions of the homogeneous equation (1.3) and the variation of constants formula are proved exactly as before.

We also need some estimates on the dependence of the solutions of (1.2) on the right hand side of the differential equation. Suppose A, B are n x n integrable matrix functions and h, g are n-vector integrable functions on compact subsets of R and consider the equations

(1.9) (a) 
$$\dot{x} = A(t)x + h(t)$$
,

(b) 
$$\dot{y} = B(t)y + g(t)$$
.

If x, y are solutions of (1.9a), (1.9b) respectively, then x - y satisfies the equation

$$\dot{z} = Az + (A - B)y + h - g.$$

Thus,

$$\begin{aligned} |x(t) - y(t)| &\leq |x(t_0) - y(t_0)| + \int_{t_0}^t [|A(s)| |x(s) - y(s)| + |A(s) - B(s)| |y(s)| \\ &+ |h(s) - g(s)|] ds, \qquad t \geq t_0. \end{aligned}$$

Using the generalized Gronwall inequality (Lemma 1.6.2), we have

$$\begin{aligned} |x(t) - y(t)| &\leq \left(\exp \int_{t_0}^t |A(s)| \, ds\right) |x(t_0) - y(t_0)| \\ &+ \int_{t_0}^t \left(\exp \int_s^t |A(u)| \, du\right) [|A(s) - B(s)| \, |y(s)| \\ &+ |h(s) - g(s)|] \, ds. \end{aligned}$$

In particular, if XA(t, to), XA(to to) = I, XB(t, to), XB(to, to) = I, are fundamental matrix solutions of x = A(t)x, y = B(t)y, respectively, then

$$(1.11) |X_A(t, t_0) - X_B(t, t_0)| \le \sup_{t_0 \le u \le t} |X_B(u, t_0)| \left( \exp \int_{t_0}^t |A(s)| \ ds \right)$$

$$\times \int_{t_0}^t |A(s) - B(s)| \ ds,$$

for all t > to. Relation (1.11) implies that the principal matrix solution of x-=Ax is a continuous function of the integrable matrix functions A defined on [0, t] with JAI = f t IA(s)J ds.

When a linear differential equation contains general time varying coefficients, the remarks in this section essentially comprise the theory concerning the specific structure of the solutions. For special equations, much more detailed information is available. For equations with constant or periodic coefficients, the general structure of the solutions is known and discussed in Sections 4 and 7.

## M.2. Stability of Linear and Perturbed Linear Systems

In this section, characterizations of stability for linear systems are given and the results applied to stability of perturbed linear systems. We first remark that the stability of any solution of homoveneous linear equation ii..

determined by the stability of the zero solution. Therefore, for linear systems, it is'permissible to say system (1.3) is stable, uniformly stable, etc.

THEOREM 2.171 Let X(t) be a fundamental matrix solution of (1.3) and let S be any number in (-co, oo). The system (1.3) is

(i) I stabl for any to in (- oo, co) if and only if there is a K = K(to) > 0 such that

$$(2.1) |X(t)| \leq K, t_0 \leq t < \infty;$$

(ii) I- uniformly stable for to >\_ P if and only if there is a K = K(fl) > 0 such that

$$(2.2) |X(t)X^{-1}(s)| \leq K, t_0 \leq s \leq t < \infty;$$

asymptotically for any to in (- oo, oo) if and only if

$$(2.3) |X(t)| \to 0 as t \to \infty;$$

(iv) uniforml asymptotically stable exponentially asymptotically stable; that a(p) > 0 such that for to Z P if and only if it is is, there are K = K(fl) > 0, c x=

$$|X(t)X^{-1}(s)| \leq Ke^{-\alpha(t-s)}, \qquad \beta \leq s \leq t < \infty.$$

PROOF. (i) Suppose to is any given real number in (- oo, oo) and (2.1) holds. Any solution x(t) satisfies x(t) =X(t)X-1(to)x(to). Let IX-1(to)I = L. Then I x(t)I < KL I x(to)I < e if I x(to)I < s/KL and the zero solution of (1.3) is stable. Conversely, if for any e > 0 there is a 8 = S(e, to) > 0 such that IX(t)X-1(to)x(to)I < e for Ix(to)I <8, then

$$|X(t)X^{-1}(t_0)| = \sup_{|\xi| \le 1} |X(t)X^{-1}(t_0)\xi|$$
  
=  $\sup_{|x(t_0)| \le \delta} |X(t)X^{-1}(t_0)\delta^{-1}x(t_0)| \le \varepsilon\delta^{-1}$ 

for t >\_ to. This proves (i).

- (ii) If (2.2) is satisfied, then x(t) =X(t)X-1(to)x(to) for any to >\_ f3 and I x(t)I <\_ K I x(to)I < e, t >\_ T, if I x(to)I < e/K which is uniform stability. The converse follows as in (i) with the observation that S is independent of to.
- (iii) If (2.3) is satisfied, then for any to in (-oo, oo) there is a K = K(to) such that IX(t)I < K, t ? to and (i) implies stability. Since x(t) \_ X(t)X-1(to)x(to) we have Ix(t)I -\* 0 as too. The converse is trivial.
- (iv) If (2.4) is satisfied, then (1.3) is uniformly stable from (ii).. Suppose I x(to)I < 1. For any n > 0, 0 <,] < K, let T = -'log(/K). Then

$$|x(t)| = |X(t)X^{-1}(t_0)x(t_0)| \le Ke^{-\alpha(t-t_0)}|x(t_0)| \le \eta,$$

if t >\_ to + T, to >\_ fi; that is, uniform asymptotic stability of the zero solution of (1.3).

Conversely, suppose the solution x = 0 is uniformly asymptotically stable for to > P. There is a b > 0 such that for any 71, 0 < q < b, there is a T = T(-q) > 0 such that

$$(2.5) |X(t)X^{-1}(t_0)x(t_0)| < \eta \text{for } t \ge t_0 + T,$$

and all to >\_ P, I x(to)I < b. Thus, IX(t)X-1(to)I <'qb-1 for t >\_ to + T, to In particular,

$$|X(t+T)X^{-1}(t)| < \eta b^{-1} < 1, \qquad t \ge \beta.$$

Since the solution x = 0 is uniformly stable, we have from (ii) that there is an M = M(P) such that IX(t)X-1(s)I < M, f < s < t < 00. Suppose

$$lpha = -T^{-1}\log(\eta b^{-1}), 
onumber \ K = Me^{lpha T}.$$

For any t >\_ to, there is an integer k >\_ 0 such that kT < t - to < (k + 1)T. Thus, using (2.6),

$$\begin{split} |X(t)X^{-1}(t_0)| &\leq |X(t)X^{-1}(t_0+kT)| \cdot |X(t_0+kT)X^{-1}(t_0)| \\ &\leq M \cdot |X(t_0+kT)X^{-1}(t_0)| \\ &\leq M(\eta b^{-1})|X(t_0+(k-1)T)X^{-1}(t_0)| \\ &\leq M(\eta b^{-1})^k = Me^{-\alpha kT} \\ &= Ke^{-\alpha(k+1)T} \leq Ke^{-\alpha(t-t_0)}. \end{split}$$

This proves (iv) and Theorem 2.1.

Using the variation of constants formula and Gronwall's inequality (Corollary 1.6.6), it is very easy to obtain the following stability results for perturbed linear systems.

THEOREM 2.2. Suppose P is given in (- oo, oo) and the system (1.3) is uniformly stable for to >\_ P. If the n x n continuous matrix function B(t) satisfies f oo <sup>a</sup> IB(t)I dt < oo, then the system

$$(2.7) \dot{x} = [A(t) + B(t)]x$$

is uniformly stable.

PROOF. If X(t) is a fundamental matrix solution of (1.3), then the variation of constants formula implies that any solution of (2.7) has the form

$$(2.8) x(t) = X(t)X^{-1}(t_0)x(t_0) + \int_{t_0}^t X(t)X^{-1}(s)B(s)x(s) ds,$$

for all t,  $t_0$  in  $(-\infty, \infty)$ . If  $t_0 \ge \beta$ , then Theorem 2.1 implies there is a constant  $K = K(\beta)$  such that  $|X(t)X^{-1}(t_0)| \le K$  for all  $t \ge t_0$ . Consequently,

$$|x(t)| \leq K |x(t_0)| + \int_{t_0}^t K |B(s)| \cdot |x(s)| ds, \qquad t \geq t_0.$$

Gronwall's inequality implies

$$|x(t)| \le K \left( \exp K \int_{t_0}^t |B(s)| ds \right) |x(t_0)|, \qquad t \ge t_0.$$

This clearly implies uniform stability of (2.7) and the theorem.

THEOREM 2.3. Suppose  $\beta$  is given in  $(-\infty, \infty)$  and system (1.3) is uniformly asymptotically stable for  $t_0 \ge \beta$ . If the  $n \times n$  continuous matrix function B(t) satisfies

(2.9) 
$$\int_{t_0}^t |B(s)| ds \leq \gamma(t - t_0) + \tau, \qquad t \geq t_0 \geq \beta$$

for some constants  $\tau = \tau(\beta)$ ,  $\gamma = \gamma(\beta)$ , then there is an r > 0 such that system (2.7) is uniformly asymptotically stable if  $\gamma < r$ .

PROOF. If X(t) is a fundamental matrix solution of (1.3) and (1.3) is uniformly asymptotically stable for  $t_0 \ge \beta$ , then Theorem 2.1 implies there are constants  $K = K(\beta) > 0$ ,  $\alpha = \alpha(\beta) > 0$  such that (2.4) is satisfied. Using (2.8), one observes that the solution x(t) of (2.7) satisfies

$$|x(t)| \le Ke^{-\alpha(t-t_0)}|x(t_0)| + K \int_{t_0}^t e^{-\alpha(t-s)}|B(s)| \cdot |x(s)| ds, \qquad t \ge t_0.$$

If  $z(t) = e^{\alpha t} |x(t)|$ , this inequality implies

$$z(t) \leq Kz(t_0) + \int_{t_0}^t K|B(s)|z(s)|ds, \quad t \geq t_0.$$

An application of Gronwall's inequality and (2.9) yield

$$z(t) \le K \left( \exp K \int_{t_0}^t |B(s)| \ ds \right) z(t_0) \le K_1 e^{K\gamma(t-t_0)} z(t_0), \quad K_1 = K e^{K\tau},$$

which in turn implies  $|x(t)| \leq K_1 |x(t_0)| \exp[-(\alpha - K\gamma)(t - t_0)]$ ,  $t \geq t_0$ . If  $r = \alpha K^{-1}$  and  $\gamma < r$ , then system (2.7) is uniformly asymptotically stable and the theorem is proved.

THEOREM 2.4. Suppose  $\beta$  is given in  $(-\infty, \infty)$  and system (1.3) is uniformly asymptotically stable for  $t_0 \ge \beta$ . If f(t, x) is continuous for (t, x) in  $R \times R^n$  and for any  $\varepsilon > 0$ , there is a  $\sigma > 0$  such that

$$|f(t,x)| \le \varepsilon |x| \quad \text{for} \quad |x| < \sigma, \quad t \text{ in } R,$$

then the solution x = 0 of

$$(2.11) \dot{x} = A(t)x + f(t, x)$$

is uniformly asymptotically stable for to >\_ P.

PROOF. The hypothesis of uniform asymptotic stability for to of the system (1.3) implies there are constants K = K(fl) > 0, a(f) > 0 such that (2.4) is satisfied. Any solution x of (2.11) satisfies

$$(2.12) x(t) = X(t)X^{-1}(t_0)x(t_0) + \int_{t_0}^t X(t)X^{-1}(s)f(s, x(s)) ds.$$

Choose s so that EK < a and let a be chosen so that (2.10) is satisfied. For those values of t >\_ to for which x(t) satisfies I x(t)I < a, we have

$$|x(t)| \leq Ke^{-\alpha(t-t_0)}|x(t_0)| + \int_{t_0}^t \varepsilon Ke^{-\alpha(t-s)}|x(s)| ds.$$

Proceeding exactly as in the proof of the previous theorem, we obtain

$$|x(t)| \leq K |x(t_0)| e^{-(\alpha - \varepsilon K)(t - t_0)}$$

for all values of t >\_ to for which I x(t) I < a. Since a - EK > 0, this inequality implies I x(t)I < a for all t >\_ to as long as I x(to)I < a/K. Consequently (2.13) holds for all t >\_ to provided I x(to) I < a/K. Relation (2.13) clearly implies uniform asymptotic stability of the solution x = 0 and the theorem is proved.

Theorem 2.4 is a generalization of the famous theorem of Lyapunov on stability with respect to the first approximation. The reason for the terminology is the following: Suppose g: Rn+1 \_ Rn is continuous, g(t, x) has continuous first partial derivatives with respect to x and g(t, 0) = 0 for all t. If A(t)x = [ag(t, 0)/8x]x and f (t, x) = g(t, x) - A(t)x, then f (t, 0) = 0, af(t,x)lax approaches zero as x approaches zero uniformly in t and the conditions of Theorem 2.4 are satisfied. The function A(t)x is clearly the linear approximation to the right hand side of the eqatuion z= g(t,x).

There are many more results available on stability of perturbed linear systems and clearly many variants that could be obtained by abstracting the essential elements of the proofs given above. The exercises at the end of this section indicate some of the possibilities.

In spite of the fact that the proofs of the above theorems are extremely simple and the results are not surprising to the intuition, extreme care must be exercised in treating arbitrary perturbed linear systems.

The example ii - 2t-' + u = 0 has a fundamental system of solutions sin t - t cos t, cos t + t sin t and is therefore unstable. This equation can be considered as a perturbation of the uniformly stable system ii + u = 0.

The following example is an equation (1.3) which is asymptotically

stable, but not uniformly, and system (2.7) is unstable for an appropriate B(t) such that  $\int_{-\infty}^{\infty} |B(s)| ds < \infty$  and  $|B(t)| \to 0$  as  $t \to \infty$ . Consider the system (1.3) with

(2.14) 
$$A(t) = \begin{bmatrix} -a & 0 \\ 0 & \sin \log t + \cos \log t - 2a \end{bmatrix},$$

and  $1 < 2a < 1 + e^{-\pi}$ . The solutions of (1.3) are

$$x_1(t) = c_1 \exp(-at),$$
  
 $x_2(t) = c_2 \exp(t \sin \log t - 2at),$ 

where  $c_1$ ,  $c_2$  are arbitrary constants. For any  $c_1$ ,  $c_2$ ,  $x_1(t)$ ,  $x_2(t) \to 0$  as  $t \to \infty$  exponentially. If B(t) is defined by

$$B(t) = \begin{bmatrix} 0 & 0 \\ e^{-at} & 0 \end{bmatrix},$$

then  $\int_{-\infty}^{\infty} |B(s)| ds < \infty$  and  $|B(t)| \to 0$  as  $t \to \infty$ . The solutions of the perturbed equation (2.7) with initial time  $t_0 = 0$  are

$$x_1(t) = c_1 \exp(-at),$$
 
$$x_2(t) = \left[c_2 + c_1 \int_0^t \exp(-s \sin \log s) ds\right] \exp(t \sin \log t - 2at).$$

If  $\alpha$  is chosen so that  $0 < \alpha < \pi/2$ ,  $t_n = \exp[(2n - 1/2)\pi]$ ,  $n = 1, 2, \ldots$ , then  $\sin \log s \le -\cos \alpha$  for  $t_n \le s \le t_n e^{\alpha}$ . Hence,

$$\int_0^{t_n e^{\alpha}} \exp(-s \sin \log s) \, ds > \int_{t_n}^{t_n e^{\alpha}} \exp(-s \sin \log s) \, ds$$

$$\geq \int_{t_n}^{t_n e^{\alpha}} \exp(s \cos \alpha) \, ds$$

$$> t_n(e^{\alpha} - 1) \exp(t_n \cos \alpha).$$

Choose  $c_2 = 0$ ,  $c_1 = 1$ . Since  $\sin \log(t_n e^{\pi}) = 1$ , we have

$$|x_2(t_n e^n)| \ge t_n(e^{\alpha} - 1) \exp(bt_n),$$

where  $b = (1 - 2a)e^{\pi} + \cos \alpha$ . If we choose  $\alpha$  so that b > 0, then  $|x_2(t_n e^{\pi})| \to \infty$  as  $n \to \infty$  and the system is unstable.

EXERCISE 2.1. Suppose there is a constant K such that a fundamental matrix solution X of the real system (1.3) satisfies  $|X(t)| \leq K$ ,  $t \geq \beta$  and

$$\lim_{t\to\infty}\inf_{\beta}\int_{\beta}^{t}tr\ A(s)\ ds>-\infty.$$

Prove that X-1 is bounded on [fl, oo) and no nontrivial solution of (1.3) approaches zero as t -> oo.

EXERCISE 2.2. Suppose A satisfies the conditions in Exercise 2.1 and B(t) is a continuous real n x n matrix for t >\_ P with f IA(t) - B(t)I < oo. Prove that every solution of B(t)y is bounded on [f, oo). For any solution x of (1.3), prove there is a unique solution y of B(t)y such that y(t) - x(t) 0 as t oo.

EXERCISE 2.3. Suppose system (1.3) is uniformly asymptotically stable, f satisfies the conditions of Theorem 2.4 and b(t) --0 as t -> oo. Prove there is a T > 9 such that any solution x(t) of

$$\dot{x} = A(t)x + f(t, x) + b(t)$$

approaches zero as t -->- oo if I x(T) I is small enough.

EXERCISE 2.4. Generalize the result of Exercise 2.3 with b(t) replaced by g(t, x) where g(t, x) -\*0 as t -\* oo uniformly for x in compact sets.

EXERCISE 2.5. Suppose there exists a continuous function c(t) such that ft+1 c(s) ds < y, t >\_ 8, for some constant y = y(fl) and f: Rn+1 -->Rn is continuous with If (t, x) I < c(t)IxI. Prove there is a constant r > 0 such that the solution x = 0 of (2.11) is uniformly asymptotically stable if y < r.

EXERCISE 2.6. Generalize Exercises 2.3 and 2.4 with f satisfying the conditions of Exercise 2.5.

## III.3. n1h Order Scalar Equations

Due to the frequency of occurrence of nth order scalar equations in the applications, it is worthwhile to transform the information obtained in Section 1 to equations of this type. Suppose y is a scalar, al, ... , an and g are continuous real or complex valued functions on (- oo, + oo) and consider the equation

(3.1) 
$$D^{n}y + a_{1}(t)D^{n-1}y + \cdots + a_{n}(t)y = g(t),$$

where D represents the operation of differentiation with respect to t. The function D2y is the second derivative of y with respect to t, and so forth.

Equation (3.1) is equivalent to

$$\begin{cases} x = Ax + h \\ x = \begin{bmatrix} y \\ Dy \\ \vdots \\ D^{n-2}y \\ D^{n-1}y \end{bmatrix}, \quad A = \begin{bmatrix} 0 & 1 & 0 & \cdots & 0 \\ 0 & 0 & 1 & \cdots & 0 \\ \vdots & & & & \\ 0 & 0 & 0 & \cdots & 1 \\ -a_n & -a_{n-1} & -a_{n-2} & \cdots & -a_1 \end{bmatrix} \quad h = \begin{bmatrix} 0 \\ 0 \\ \vdots \\ 0 \\ g \end{bmatrix}.$$

From this representation of (3.1), a solution of (3.2) is a column vector of dimension n, but the  $(j+1)^{\text{th}}$  component of the solution vector is obtained by differentiation of the first component j times with respect to t and this first component must be a solution of (3.1). Consequently, any  $n \times n$  matrix solution  $[\xi^1, \ldots, \xi^n]$ ,  $\xi^j$  an n-vector, of (3.2) must satisfy  $\xi^j = \text{col}(\phi_j, D\phi_j, \ldots, D^{n-1}\phi_j)$ , where  $\phi^j$ ,  $j = 1, 2, \ldots, n$ , is a solution of (3.1).

If  $\phi_1, \ldots, \phi_n$  are *n*-scalar functions which are (n-1)-times continuously differentiable, the *Wronskian*  $\Delta(\phi_1, \ldots, \phi_n)$  of  $\phi_1, \ldots, \phi_n$  is defined by

(3.3) 
$$\Delta(\phi_1, \ldots, \phi_n) = \det \begin{bmatrix} \phi_1 & \phi_2 & \cdots & \phi_n \\ D\phi_1 & D\phi_2 & \cdots & D\phi_n \\ \vdots & \vdots & & \vdots \\ D^{n-1}\phi_1 & D^{n-1}\phi_2 & \cdots & D^{n-1}\phi_n \end{bmatrix}.$$

A set of scalar functions  $\phi_1, \ldots, \phi_n$  defined on  $a \le t \le b$  are said to be linearly dependent on [a, b] if there exist constants  $c_1, \ldots, c_n$  not all zero such that  $c_1\phi_1(t) + \cdots + c_n\phi_n(t) = 0$  for all t in [a, b]. Otherwise, the functions are linearly independent on [a, b].

LEMMA 3.1. If  $\phi_1, \ldots, \phi_n$  are n-1 times continuously differentiable scalar functions on an interval I, then  $\phi_1, \ldots, \phi_n$  are linearly independent on I if the Wronskian  $\Delta$  defined in (3.3) is different from zero on I.

PROOF. Suppose there is a linear combination of the  $\phi_i$  which is zero on I. More precisely, suppose that

$$\sum_{j=0}^n c_j \, \phi_j(t) = 0, \qquad t \text{ in } I,$$

where the  $c_j$  are constant. By repeated differentiation of this relation, the following system of equations for the constants  $c_j$  is obtained:

$$\sum_{j=1}^{n} c_{j} D^{k} \phi_{j}(t) = 0, \qquad k = 0, 1, 2, \dots, n-1.$$

Or, in matrix form,

$$\begin{bmatrix} \phi_1 & \phi_2 & \dots & \phi_n \\ D\phi_1 & D\phi_2 & \dots & D\phi_n \\ \vdots & \vdots & \vdots \\ D^{n-1}\phi_1 & D^{n-1}\phi_2 & \dots & D^{n-1}\phi_n \end{bmatrix} \begin{bmatrix} c_1 \\ \vdots \\ c_n \end{bmatrix} = 0.$$

This latter relation must be satisfied for all t in I. On the other hand, by hypothesis, the determinant of the coefficient matrix is different from zero for all tin I which implies that the only solution of this system of equations is cl = = cn = 0; that is, the functions 01 are linearly independent.

The converse of this statement is not true. In fact, there can be nfunctions with n -1 continuous derivatives on an interval I such that the Wronskian is identically zero for all tin I and yet the functions are linearly independent. For n = 2, one merely has to choose two differentiable functions 01, 02 on [0, 3] such that 01(t) = 0, tin [0, 2], 02(t) = 0, tin [1, 3] and the functions are 0 otherwise.

On the other hand, it is clear from the proof of Lemma 3.1 that linear dependence of 01, ... , On on I implies A - 0 on I.

If 01, ..., 0. are solutions of the homogeneous equation

$$(3.4) D^{n}y + a_{1}(t)D^{n-1}y + \cdots + a_{n}(t)y = 0,$$

then A(q1, ..., on) is the determinant of an n x n matrix solution of the homogeneous system (3.2); that is, system (3.2) with h =0. Lemmas 1.2, 1.5, formula (3.2) and the remarks above imply

THEOREM 3.1. If 01, ..., 0. are n solutions of (3.4), then 0(01, 0n)(t) is 0 for all tin (-oo, oo) or identically zero. More specifically,

$$\Delta(\phi_1,\ldots,\phi_n)(t) = \Delta(\phi_1,\ldots,\phi_n)(0) \exp\left(-\int_0^t a_1(s) ds\right).$$

Thus, the n solutions 01, ... , On of (3.4) are linearly independent if and only if 0{q1, ... , on) (0) 0.

Let us determine the variation of constants formula for the solutions of equation (3.1). Since (3.1) is equivalent to (3.2), it is sufficient to determine only the variation of constants formula for the first component of the vector solution of (3.2). If X(t, T), X(-r, T) = I, is the principal matrix solution of x = Ax, then any solution of (3.2) satisfies relation (1.7). If the first row of the matrix X(t, -r) is designated by (01(t, r), ... , 0n(t, T)), then the first component y of the vector x in (1.7) is given by

(3.5) 
$$y(t) = \sum_{j=1}^{n} [D^{j-1}y(\tau)]\phi_{j}(t, \tau) + \int_{\tau}^{t} \phi_{n}(t, s)g(s) ds,$$

where g is the function given in (3.1). The reason for such a simple expression is due to the fact that the vector h in (2.2) has all components zero except

the last which is g. Since the function  $\phi_n(t,s)$  together with its derivatives up through order n-1 form the last column of the matrix X(t,s) it follows that  $\phi_n(t,s)$  is the solution of the homogeneous equation (3.4) which for t=s vanishes together with all its derivatives up through order n-2, and the derivative of order n-1 with respect to t is equal to one. This is summarized in

THEOREM 3.2. For any real number s in  $(-\infty, +\infty)$ , let  $\phi(t, s)$  be the unique solution of the homogeneous equation (3.4) which satisfies the initial data

$$(3.6) y(s) = Dy(s) = \cdots = D^{n-2}y(s) = 0, D^{n-1}y(s) = 1.$$

Then the unique solution of equation (3.1) which vanishes together with all derivatives up through order n-1 at  $t=\tau$  is given by

(3.7) 
$$y(t) = \int_{\tau}^{t} \phi(t, s)g(s) ds.$$

Another relation which is easily obtained from the general theory of Section 1 is the equation adjoint to equation (3.4). This is derived from the general definition of the adjoint equation given in Section 1. The adjoint to equation (3.2) with h=0 is given by  $\dot{w}=-wA$ ,  $w=(w_1,\ldots,w_n)$ , or, equivalently,

(3.8) 
$$\begin{cases} Dw_1 = a_n w_n \\ Dw_2 = -w_1 + a_{n-1} w_n \\ \cdots \\ Dw_n = -w_{n-1} + a_1 w_n \end{cases}$$

It is not obvious that equation (3.8) is equivalent to an  $n^{\text{th}}$  order scalar equation of any type. However, if each of the functions  $a_k$ ,  $k=1,\ldots,n$ , has a sufficient number of continuous derivatives, this is the case. In fact, differentiation of the  $(k+1)^{\text{th}}$  equation in (3.8) k-times with respect to t yields the equivalent set of equations

(3.9) 
$$Dw_1 = a_n w_n,$$

$$D^{k+1} w_{k+1} = -D^k w_k + D^k (a_{n-k} w_n), \qquad k = 1, 2, \dots, n-1.$$

If  $z = w_n$ , then one easily concludes from (3.9) that

(3.10) 
$$D^{n}z - D^{n-1}(a_1z) + \cdots + (-1)^{n}a_nz = 0.$$

Equation (3.10) is referred to as the adjoint to equation (3.4). If the a's are constant this is the same differential equation as the original one except for some changes in sign in the coefficients.

#### III.4. Linear Systems with Constant Coefficients

In this section, we consider the homogeneous equation

$$\dot{x} = Ax$$

and the nonhomogeneous equation

$$\dot{x} = Ax + h(t)$$

where A is an  $n \times n$  real or complex constant matrix and h is a continuous real or complex *n*-vector function on  $(-\infty, \infty)$ .

The principal matrix solution P(t) of (4.1) at t=0 is such that each column of P(t) satisfies (4.1) and P(0) = I, the identity. The matrix P(t)satisfies the following property: P(t+s) = P(t)P(s) for all t, s in  $(-\infty, \infty)$ . In fact, for each fixed s in  $(-\infty, \infty)$ , both P(t+s) and P(t)P(s) satisfy (4.1) and for t=0 these matrices coincide. Thus, the uniqueness theorem implies the result. This relation suggests that P(t) behaves as an exponential function. Therefore, we make the following

**Definition 4.1.** The  $n \times n$  matrix  $e^{At}$ ,  $-\infty < t < \infty$ ,  $e^0 = I$ , the identity, is defined as the principal matrix solution of (4.1) at t=0.

The matrix  $e^{At}$  satisfies the following properties:

(iii) 
$$\frac{d}{dt}e^{At} = Ae^{At} = e^{At}A$$

(iv) 
$$e^{At} = I + At + \frac{1}{2!}A^2t^2 + \cdots + \frac{1}{n!}A^nt^n + \cdots$$

- The matrix  $e^{At}$  satisfies the following properties:

  (i)  $e^{A(t+s)} = e^{At}e^{As}$ (ii)  $(e^{At})^{-1} = e^{-At}$ (iii)  $\frac{d}{dt}e^{At} = Ae^{At} = e^{At}A$ (iv)  $e^{At} = I + At + \frac{1}{2!}A^2t^2 + \cdots + \frac{1}{n!}A^nt^n + \cdots$ (v) a general solution of (4.1) is  $e^{At}c$  where c is an arbitrary constant n-vector.

  (vi) If X(t), det  $X(0) \neq 0$  is an  $n \times n$  matrix solution of (4.1), then  $e^{At} = X(t)X^{-1}(0).$

Property (i) was proved above and (ii) is a consequence of (i). Property (v) is Lemma 1.3 for this special case. (iii) follows from uniqueness and the observation that both  $Ae^{At}$  and  $e^{At}A$  are matrix solutions of (4.1). This same argument proves (vi).

Before proving (iv), it is necessary to make a few remarks about the meaning of a matrix power series. If f(z) is a function of the complex variable z which is analytic in a neighborhood of z = 0, the power series f(A) is defined as the formal power series obtained by substituting for each term in the power series of f(z) the matrix A for the complex variable z. Of course, such an expression will be meaningful if and only if for the particular matrix A each element of the power series matrix converges. One can actually use such a series as a definition for matrix functions f(A) when f(z) is an analytic function of the complex variable z. On the other hand, it should be noted that property (iv) above is not a definition of  $e^{At}$  but is going to be derived from the fact that  $e^{At}$  is the principal matrix solution of (3.1) at t=0.

**PROOF** OF (IV). Since  $P(t) \stackrel{\text{def}}{=} e^{At}$  is the principal matrix solution of (4.1) at t = 0 it follows that P(t) must satisfy the integral equation

(4.3) 
$$P(t) = I + \int_0^t AP(s) ds.$$

If one attempts to solve equation (4.3) by the obvious method of successive approximations

(4.4) 
$$P^{(0)} = I,$$
 
$$P^{(k+1)}(t) = I + \int_0^t A P^{(k)}(s) ds, \qquad k = 0, 1, 2, \dots,$$

then one observes that the expression for  $P^{(k)}$  is given by the formula

$$P^{(k)}(t) = I + At + \frac{1}{2!}A^2t^2 + \cdots + \frac{1}{k!}A^kt^k.$$

In the proof of the Picard-Lindelöf Theorem in Chapter I, it was shown that this sequence converged for  $|t| \leq \alpha$  and  $\alpha$  small. We now wish to show that the sequence of matrices  $P^{(k)}(t)$  converge uniformly for all t in a compact set in  $(-\infty, \infty)$ . If we let  $P^{(k)}_{ij}(t)$  be the  $(ij)^{\text{th}}$  element of the matrix  $P^{(k)}(t)$ , then there is a constant  $\beta > 0$  independent of k such that  $|P^{(k)}_{ij}(t)| \leq \beta^{-1}|P^{(k)}(t)|$ . Thus,

$$\beta|P_{ij}^{(k)}(t)| \leq 1 + \alpha t + \frac{1}{2!}\alpha^2 t^2 + \cdots + \frac{1}{k!}\alpha^k t^k \leq e^{\alpha t},$$

where for simplicity we have put  $\alpha = |A|$ . Furthermore,

$$\beta |P_{ij}^{(k+1)}(t) - P_{ij}^{(k)}(t)| \le \frac{1}{(k+1)!} \alpha^{k+1} t^{k+1},$$

and the sequence  $(P_{ij}^{(k)}(t))$  converges uniformly for all t in a compact set of  $(-\infty, \infty)$ . This shows that the power series in property (iv) is well defined and thus the sequence of matrices  $\{P^{(k)}(t)\}$  converges uniformly on all compact subsets of  $(-\infty, \infty)$ . From (4.4), it follows that the limit is the principal matrix solution  $P(t) = e^{At}$  of (4.1). This proves property (iv).

In spite of the above apparent simplicity, the matrix  $e^{At}$  is a rather complicated individual. Many of the operations that are valid for the scalar

exponential function are also true for the matrix function eAt. However, other operations do not behave in the same way as for scalars since in general matrix multiplication is not commutative. The following two exercises indicate that caution must be exercised in operating with eAt.

EXERCISE 4.1. Prove that BeAt = eAtB for all t if and only if BA = AB.

EXERCISE 4.2. Prove that eAtest = e(A+s)t for all <sup>t</sup> if and only if BA =AB.

With a general solution of equation (4.1) being given by eAtc, where c is a constant n-vector and the matrix eAt having the power series representation given in property (iv), one might ask if there is anything left to discuss about linear equations with constant coefficients. Unfortunately, the previous notation is very misleading and we have not answered the following questions: In what precise sense does the function x(t) = eAtc where c is a constant n-vector behave as the scalar exponential function? What is an effective means for computing eAt?

Both of the questions are very closely related and reduce to a detailed discussion of the eigenvalues and eigenvectors of a matrix. The general structure of the solutions of the differential equation (3.1) is determined completely from the solution of an algebraic problem. This fact expresses the simplicity of linear systems of differential equations with constant coefficients and also explains why there is always a definite attempt in the applications to simulate models of physical systems by using equations with constant coefficients.

A complex number A is called an eigenvalue (proper value, characteristic value) of an n x n matrix A if there exists a non-zero vector v such that

(4.5) 
$$Av = \lambda v \quad \text{or} \quad (A - \lambda I)v = 0.$$

If A is an eigenvalue of the matrix A and v is any non-zero solution of equation (4.5), then v is called an eigenvector (proper value, characteristic vector) associated with the eigenvalue A. Hence, A is an eigenvalue of the matrix A if and only if A is a solution of the characteristic equation

$$\det(A - \lambda I) = 0.$$

The characteristic equation is a polynomial of degree n in A and, therefore, has n solutions, not all of which may be distinct. On the other hand, if Al, ... , Ak are distinct eigenvalues of the matrix A and VI, ... , vk are corresponding eigenvectors, then v1, ... , vk are linearly independent. The following lemma is" obvious.

LEMMA 4.1. If A is an eigenvalue of the matrix A and v is an eigenvector associated with A, then the function x(t) = exty is a solution of the differential equation z = Ax.

LEMMA 4.2. If A is an n x n matrix with n-distinct eigenvalues Al, ... , A. and v1, ..., vn are the corresponding eigenvectors, then a general solution of equation (4.1) is given by

$$V(t)c = c_1v^1e^{\lambda_1t} + \cdots + c_nv^ne^{\lambda_nt},$$

where V(t) = (vlel1t, ... , vnexnt) and c = (cl, ... , cn) is an arbitrary complex n-vector. Furthermore, eAt = V(t)V(0)-1.

PROOF. If we let V(t) be defined as above, then Lemma 1.3 implies it is sufficient to show that V(t) is a fundamental matrix solution of equation (4.1). Since V(0) = (v', ..., vn) and the vectors v1, ..., vn are linearly independent, V(0) is non-singular. This fact, JJemma 4.1 and Corollary 1.1 imply that V(t) is a fundamental matrix solution of (4.1). A general solution is therefore V(t)c where c is an arbitrary n-vector. The last assertion of the lemma is precisely property (vi) above of eAt.

If the matrix A has real elements then the eigenvalues will occur in complex conjugate pairs. This will imply that the corresponding eigenvectors can be chosen as complex conjugates. Therefore, if only real solutions of (4.1) are desired, the constants cl, ..., cn given in the general solution will need to satisfy some restriction of complex conjugacy. In fact, if Al and A2 are complex conjugates, then the eigenvectors v1, v2 can be chosen as complex conjugates. In the general solution the constants cl and c2 then may be chosen as complex conjugates to obtain a real solution of equation (4.1).

We now describe the general procedure for obtaining eAt. To do this we need some elementary concepts from linear algebra. Let Cn be complex n-dimensional space and let Sl, S2 be linear subspaces of Cn. The subspaces Si and S2 al . linearly independent if ClYl + c2 y2 = 0, yl in S1,112 in S2, implies that c1 = C2 = 0. The direct sum, Si Q S2, of independent subspaces S1, S2 is a subspace S of Cn whose elements y are given by y = yl + y2, yl in S1, Y2 in S2. If A is an n x n matrix and S is a subspace of Cn, then S is invariant under A if for any y in S the vector Ay is in S. If A is an n x n matrix the null space of A, denoted by N(A), is the set of all y in Cn such that Ay = 0. If A is an eigenvalue of the n x n matrix A, r(A) is the least integer k such that N(A - AI )k+1 = N(A - AI )k. The set N(A - AI)r(A) is a subspace of Cn and is called the generalized eigenspace of A corresponding to the eigenvalue A. This generalized eigenspace is denoted by the symbol MA(A). The dimension of MA(A) is equal to the algebraic multiplicity of the eigenvalue A ; that is, the multiplicity of the eigenvalue as a zero of the characteristic polynomial det(A - Y). We say an eigenvalue A of A has simple elementary divisors if MA(A) = N(A - Al). The following result is basic and a proof can be found in any book on linear algebra.

LEMMA 4.3. If A is an n x n matrix and A,\_., A8 are the distinct

eigenvalues of A, then the corresponding generalized eigenspaces  $M_{\lambda_1}(A)$ , ...,  $M_{\lambda_s}(A)$  are linearly independent, are invariant under the matrix A and  $C^n = M_{\lambda_1}(A) \oplus \cdots \oplus M_{\lambda_s}(A)$ .

Since the generalized eigenspaces  $M_{\lambda_1}(A), \ldots, M_{\lambda_s}(A)$  are linearly independent if  $\lambda_1, \ldots, \lambda_s$  are the distinct eigenvalues of A, it follows that any vector  $x^0$  in  $C^n$  can be represented uniquely as

(4.7) 
$$x^0 = \sum_{j=1}^{s} x^{0,j}, \quad x^{0,j} \text{ in } M_{\lambda_j}(A).$$

Since the generalized eigenspaces  $M_{\lambda_i}(A)$  are invariant under the matrix A, any solution of the differential equation (4.1) with initial value in  $M_{\lambda_i}(A)$  will remain in  $M_{\lambda_i}(A)$  for all values of t. This is immediately obvious since the tangent vector to the curve described by the solution of the differential equation in the phase space lies in the subspace  $M_{\lambda_i}(A)$ .

For any  $x^0$  in  $C^n$  and any complex number  $\lambda$ ,

$$egin{aligned} e^{At}x^0 &= e^{(A-\lambda I)t}e^{\lambda t}x^0 \ &= e^{(A-\lambda I)t}x^0e^{\lambda t} \ &= \left(\sum\limits_{k=0}^\infty (A-\lambda I)^k \, rac{t^k}{k!}
ight)\!x^0\!e^{\lambda t} \,. \end{aligned}$$

If  $\lambda$  is an eigenvalue of A and  $M_{\lambda}(A)$  is the corresponding generalized eigenspace, then  $x^0$  in  $M_{\lambda}(A)$  implies that the above infinite series is actually only a polynomial since  $(A - \lambda I)^k x^0 = 0$  for all  $k \ge r(\lambda)$ . Therefore, for any  $x^0$  in  $M_{\lambda}(A)$ ,  $e^{At}x^0$  is given by

(4.8) 
$$e^{At}x^0 = \left[\sum_{k=0}^{r(\lambda)-1} (A - \lambda I)^k \frac{t^k}{k!}\right] x^0 e^{\lambda t}.$$

In summary, if  $\lambda$  is an eigenvalue of the matrix A and  $M_{\lambda}(A)$  is the corresponding generalized eigenspace, then any solution of the differential equation with its initial value in  $M_{\lambda}(A)$  must lie in  $M_{\lambda}(A)$  for all values of t and the solution of the differential equation is a polynomial in t with vector coefficients times  $e^{\lambda t}$ . Furthermore, this polynomial in t can be obtained by a direct evaluation of the infinite series for  $e^{(A-\lambda I)t}$ .

These remarks together with Lemma 4.3 and the decomposition (4.7) yield

THEOREM 4.1. If  $\lambda_1, \ldots, \lambda_s$  are the distinct eigenvalues of the  $n \times n$  matrix A and  $M_{\lambda_1}(A), \ldots, M_{\lambda_s}(A)$  are the corresponding generalized eigenspaces, then the solution of the initial value problem

$$\dot{x} = Ax, \qquad x(0) = x^0,$$

is given by

(4.10) 
$$x(t) = \sum_{j=1}^{s} \left[ \sum_{k=0}^{r(\lambda_j)-1} (A - \lambda_j I)^k \frac{t^k}{k!} \right] x^{0, j} e^{\lambda_j t},$$

where the vector  $x^{0,j}$  belongs to the generalized eigenspace  $M_{\lambda_j}(A)$  and is determined by the unique decomposition of the initial vector  $x^0$  according to equation (4.7).

The specific manner in which one applies this result is as follows. The dimension of the generalized eigenspace  $M_{\lambda}(A)$  of an eigenvalue of A is equal to the algebraic multiplicity of the eigenvalue A. For a given eigenvalue  $\lambda$ of the matrix A one first obtains the null space of the matrix  $A - \lambda I$ . If the dimension of this null space is not equal to the algebraic multiplicity of the eigenvalue  $\lambda$ , one proceeds to calculate the null space of  $(A - \lambda I)^2$ . If the dimension of this subspace is equal to the algebraic multiplicity of the eigenvalue  $\lambda$ , the subspace is  $M_{\lambda}(A)$ . This process is continued until a subspace is obtained which has the dimension of the algebraic multiplicity of the eigenvalue  $\lambda$ . In this process, one also has obtained a basis for the generalized eigenspace  $M_{\lambda}(A)$ . Having done this for each eigenvalue  $\lambda$  of the matrix A, one has a basis for  $C^n$ . In terms of this basis the element  $x^0$  can be expanded uniquely, which determines the  $x^{0,j}$  and therefore the solution x(t) by formula (4.10). The general solution of equation (4.1) is obtained by replacing  $x^{0,j}$  in (4.10) by an arbitrary linear combination of the basis vectors for the generalized eigenspaces  $M_{\lambda_i}(A)$ , j = 1, 2, ..., s.

EXERCISE 4.1. Using Theorem 4.1, find the general real solution of the equation  $\dot{x} = Ax$  with

(a) 
$$A = \begin{bmatrix} 0 & 1 \\ -1 & 0 \end{bmatrix}$$
;  
(b)  $A = \begin{bmatrix} 0 & 1 \\ 0 & 0 \end{bmatrix}$ ;  
(c)  $A = \begin{bmatrix} 1 & 1 \\ 1 & -1 \end{bmatrix}$ ;  
(d)  $A = \begin{bmatrix} 0 & -1 & 2 \\ 0 & 1 & 0 \\ 1 & 1 & -1 \end{bmatrix}$ ;  
(e)  $A = \begin{bmatrix} 0 & 1 & 0 \\ 4 & 3 & -4 \\ 1 & 2 & -1 \end{bmatrix}$ .

Theorem 4.1 gives a complete description of the general form of the solution of a linear equation with constant coefficients; namely, any solution

of (4.1) is a sum of exponential terms with coefficients which are polynomials in t. The exponents of the exponential terms involve the eigenvalues of A. The degree of the corresponding polynomial in t is no more than one less than the dimension of the generalized eigenspace of the eigenvalue. A more complete description of the number of linearly independent solutions of (4.1) of the form  $p(t)e^{\lambda t}$ , where p(t) is a polynomial of a given degree is given by the *Jordan canonical form*: For an  $n \times n$  matrix A, there is a nonsingular matrix Q such that

$$(4.11) Q^{-1}AQ = \operatorname{diag}(C_1, \dots, C_p);$$

$$C_j = \lambda_j I + R_j;$$

$$R_j = \begin{bmatrix} 0 & 1 & 0 & \cdots & 0 & 0 \\ 0 & 0 & 1 & \cdots & 0 & 0 \\ \vdots & \vdots & \ddots & \ddots & \vdots & \vdots \\ 0 & 0 & 0 & \cdots & 0 & 1 \\ 0 & 0 & 0 & \cdots & 0 & 0 \end{bmatrix}.$$

and  $\lambda_j$ , j = 1, 2, ..., p, is an eigenvalue of A. The  $\lambda_1, ..., \lambda_p$  are not necessarily distinct and the dimension  $n_j$  of  $C_j$  is not necessarily equal to the  $r(\lambda_j)$  mentioned above.

If Q, A are related by (4.11), then

$$(4.12) Q^{-1}e^{At}Q = e^{[\operatorname{diag}(C_1, \dots, C_p)]t} = \operatorname{diag}(e^{C_1t}, \dots, e^{C_pt}),$$

$$e^{C_jt} = e^{\lambda_jt}e^{R_jt}, e^{R_jt} = egin{bmatrix} 1 & t & rac{t^2}{2!} & \cdots & rac{t^{n_j-1}}{(n_j-1)\,!} \ 0 & 1 & t & \cdots & rac{t^{n_j-2}}{(n_j-2)\,!} \ & & \ddots & \ddots & \ddots \ 0 & 0 & 0 & \cdots & 1 \end{bmatrix}.$$

The representation (4.12) gives more specific information about  $e^{At}$ , but depicts the same general structure of the solutions of (4.1) as Theorem 4.1.

A similarity transformation is a transformation which takes a matrix A into a matrix  $Q^{-1}AQ$ , Q nonsingular. Similarity transformations are very important in differential equations. In fact, if Q is nonsingular and x = Qy in (4.1), then  $\dot{y} = Q^{-1}AQy$ . The Jordan canonical form implies that such transformations can be used to reduce a differential equation to a very simple form.

THEOREM 4.2. (i) A necessary and sufficient condition that the system (4.1) be stable is that the eigenvalues of A have real parts  $\leq 0$  and those with zero real parts have simple elementary divisors.

(ii) A necessary and sufficient condition that the system (4.1) be asymptotically stable is that all eigenvalues of A have real parts < 0. If this is the case, there exist positive constants K,  $\alpha$  such that

$$(4.13) |e^{At}| \leq Ke^{-\alpha t}, t \geq 0.$$

PROOF. Since (4.1) is autonomous, stability implies uniform stability, asymptotic stability implies uniform asymptotic stability. Theorem. 2.1 implies that stability and boundedness of (4.1) are equivalent and asymptotic stability and exponential asymptotic stability are equivalent.

- (i) If all solutions of (4.1) are bounded, then there can be no eigenvalue of A with positive real parts from Lemma 4.1. Furthermore, if there are eigenvalues with zero real part and  $M_{\lambda}(A) \neq N(A \lambda I)$ , then Theorem 4.1 implies there is a solution with a term  $te^{\lambda t}$  times a nonzero constant vector. Such a solution would not be bounded. Conversely, if all eigenvalues have nonpositive real parts and  $M_{\lambda}(A) = N(A \lambda I)$  for those eigenvalues with zero real parts, then the general representation theorem, Theorem 4.1, implies that no powers of t occur except when multiplied by an  $e^{\lambda t}$  with  $Re\lambda < 0$ . Therefore, the solutions are bounded.
- (ii) This part is proved in the same manner using Theorem 4.1 and Theorem 2.1.

Since  $(e^{At})^{-1} = e^{-At}$ , formula (1.7) implies the variation of constants formula for (4.2) is

(4.14) 
$$x(t) = e^{A(t-\tau)}x(\tau) + \int_{\tau}^{t} e^{A(t-s)}h(s) \ ds.$$

As a particular illustration of this relation, consider the scalar equation

$$\ddot{u}+u=g(t).$$

This equation is equivalent to the system

$$\dot{u}=v, \ \dot{v}=-u+g(t).$$

If x=(u, v),

$$A = \begin{bmatrix} 0 & 1 \\ -1 & 0 \end{bmatrix}, \quad f = \begin{bmatrix} 0 \\ g \end{bmatrix},$$

then

$$e^{At} = \begin{bmatrix} \cos t & \sin t \\ -\sin t & \cos t \end{bmatrix},$$

and the first component of (4.14) is

$$u(t) = u(\tau)\cos(t-\tau) + \dot{u}(\tau)\sin(t-\tau) + \int_{\tau}^{t}\sin(t-s)g(s) ds,$$

a well known formula in elementary differential equations.

### I11.5. Two Dimensional Linear Autonomous Systems

As an application of Theorem 4.1, we classify the different behaviors of the solutions of

$$\dot{x} = Ax, \qquad A = \begin{bmatrix} a & b \\ c & d \end{bmatrix}, \qquad \det A \neq 0.$$

where a, b, c, d are real constants. If Al, A2 designate the eigenvalues of A, there are many cases to consider.

Case 1. Al, A2 real, A2 < Al- Let v1, v2 designate unit eigenveetors of A associated with the eigenvalues Al, A2, respectively. A general real solution of (5.1) is

(5.2) 
$$x(t) = c_1 e^{\lambda_1 t} v^1 + c_2 e^{\lambda_2 t} v^2,$$

where c1, c2 are arbitrary real constants. For a given c1, e2 , ci + c2 > 0, the unit tangent vector to the orbit y described by (5.2) approaches a vector parallel to of as t - ° if cl 0 0 and ±v2 as t -> - oo if c2 0 0.

Case la. Negative roots, A2 < Al < 0 (Stable node). All solutions approach zero as t -> oo and the above information on asymptotic directions allows one to sketch the orbits as in Fig. 5.1. The straight lines LI and L2 are the lines that contain the eigenvector v1 and v2, respectively. The origin is stable and called a stable node.

![](_page_110_Picture_10.jpeg)

Figure 111.5.1 Stable node (A2 < Aj < 0).

![](_page_111_Picture_2.jpeg)

Figure 111.5.2 Unstable node (0 < A2 < A).

Case Ib. Positive roots, 0 < A2 < Al (Unstable node). This is similar to Case la except for reversing the arrows and changing the lines of tangency of the curves. See Fig. 5.2. The origin is unstable and called an unstable nope.

Case Ic. One positive and one negative root, A2 < 0 < Al(Saddle point). From (5.2), those orbits which lie on L2 approach zero as t - + oo and those which lie on L1 approach zero as t -+ - oo. All other orbits are unbounded. The zero solution is unstable and the orbits are depicted in Fig. 5.3. The origin is called a saddle point.

![](_page_111_Picture_6.jpeg)

Figure 111.5.3 Saddle point A2 < 0 < Al .

Case 2. Complex roots. Since A is real, we have Al = a + i,8, A2 = a - ifl, a, S real, P > 0. If v1 and v2 are chosen as complex conjugate, a general solution for the real solutions of (5.1) is

$$x(t) = c_1 e^{(\alpha+i\beta)t} v^1 + \overline{c}_1 e^{(\alpha-i\beta)t} \overline{v}^1 = 2Re(c_1 e^{(\alpha+i\beta)t} v^1),$$

where cl is an arbitrary complex number and b designates the complex conjugate of a vector b.

If vl = u + iv, u, v real, then u, v are linearly independent and if cl = aet5 where a, a are real, then a general real solution of (5.1) is

(5.3) 
$$x(t) = 2ae^{\alpha t}[u\cos(\beta t + \delta) - v\sin(\beta t + \delta)].$$

The expression (5.3) gives all of the essential properties of the solutions. If Pt + 8 = k ir, k an integer, then the orbit of the solution crosses the line U generated by u and if Pt + 8 = (2k + 1)a/2, k an integer, it crosses the line V generated by v. The components of the solution curve in the direction u and v oscillate and are 7r/2 radians out of phase. Therefore, the orbit must resemble a spiral.

Case 2a. Purely imaginary roots (Center). If the eigenvalues of A are ±iP, a general real solution of (5.1) is

$$x(t) = a[u\cos(\beta t + \delta) - v\sin(\beta t + \delta)],$$

where a, 8 are abitrary real constants and u, v are as above. The orbits are closed curves and every solution is periodic of period 21r/0. These curves are ellipses with center at (0,0) (see Fig. 5.4). The origin is stable and called a center.

![](_page_112_Picture_11.jpeg)

Figure 111.5.4 Center Al = \2 , Re Al = 0, Im A 0 0.

Case 2b. Complex roots with negative real parts (Stable focus). If « < 0, it follows from (5.3) that all solutions approach zero as t - oo and the orbits are spirals. The equilibrium point is called a stable focus (see Fig. 5.5).

![](_page_113_Picture_3.jpeg)

Figure 111.5.5 Stable focus.

Case 2c. Complex roots with positive real parts (Unstable focus). If a > 0, then solutions approach zero as t - . - oa and the equilibrium point is called an unstable focus (see Fig. 5.6).

![](_page_113_Picture_6.jpeg)

Case S. Both eigenvalues equal (Improper node). The eigenvalues are real. If there are two real linearly independent eigenvectors v1, v2 associated with the eigenvalue A (i.e., A has simple elementary divisors), then a general

solution is

$$x(t) = (c_1 v^1 + c_2 v^2) e^{\lambda t},$$

where Cl, c2 are arbitrary real constants. The unit tangent vector to the orbit of x is constant for any c1, c2. Therefore, all orbits are on straight lines passing through the origin (see Fig. 5.7).

![](_page_114_Figure_5.jpeg)

Figure III. 5.7 Stable improper node.

If there is only one linearly independent eigenvector v1 of A, then the general solution given by Theorem 4.1 is

$$x(t) = (c_1 + c_2 t)e^{\lambda t}v^1 + c_2 e^{\lambda t}v^2,$$

where V2 is any vector independent of v1. By direct computation, one shows that the tangent to the orbit becomes parallel to v1 oo and t - oo. A typical situation is shown in Fig. 5.8.

![](_page_114_Figure_10.jpeg)

Figure 111.5.8 Stable improper node.

## M.6. The Saddle Point Property

In the previous section, we have given a rather complete characterization of the behavior of the solutions of a two dimensional linear system with constant coefficients. It is of interest to study the conditions under which the behavior of the solutions near an equilibrium point of a particular type is not " changed " by " small " perturbations of the right hand side of the differential equation. By considering only linear perturbations Bx with BI small, it is easy to see that the only types of equilibrium points for two dimensional linear systems which are preserved are the focus proper node and saddle point. On the other hand, the limiting behavior at co is insensitive to small perturbations for all types except the center. In this section, we discuss for linear systems of arbitrary order a special type of equilibrium point which is insensitive to perturbations in the differential equation. The classification of the equilibrium point is crude in the sense that it does not take into account the "fine" structure of the trajectories but only general asymptotic properties of the trajectories. The questions discussed here are treated in a much more general context in a later chapter, but, in spite of the duplication of effort, it seems appropriate to consider the special case at this time.

The equilibrium point x = 0 of (4.1) is called a saddle point of type (k) of (4.1) if the eigenvalues of the matrix A have nonzero real parts with k > 0 eigenvalues with positive real parts. For n = 2, this definition of a saddle point does not coincide with the one in Section 5. In fact, an equilibrium point which is completely stable (k = 0) as well as one which is completely unstable (k = 2) is referred to in this section as a saddle point.

If x = 0 is a saddle point of (4.1) of type (k), the space Cn can be decomposed as

(6.1) 
$$C^{n} = C^{n}_{+} \oplus C^{n}_{-},$$
 
$$C^{n}_{+} = \pi_{+} C^{n}, C^{n}_{-} = \pi_{-} C^{n},$$

where a+, ,7r\_ are projection operators, or++ 1r\_ = I, C+ has dimension k, C' has dimension n - k, C"+, Cn are invariant under A and there are constants K > 0, a > 0 such that

(6.2) (a) 
$$|e^{At}\pi_{+}x| \leq Ke^{\alpha t}|\pi_{+}x|, \qquad t \leq 0,$$
  
(b)  $|e^{At}\pi_{-}x| \leq Ke^{-\alpha t}|\pi_{-}x|, \qquad t \geq 0,$ 

for all x in C". These relations are immediate from the observation that there exists a nonsingular matrix U such that U-'A U = diag(A+, A-) where A+ is a k x k matrix whose eigenvalues have positive real parts and 'A\_ is an (n - k) x (n - k) matrix whose eigenvalues have negative real parts. From

Theorem 4.2, there are constants K1 > 0, a > 0 such that IeA+tl <\_ Kleat t < 0 and IeA-11 <K1e-at, t >\_ 0. The first relation is obtained by replacing t by -t in the equation fi = A+ U. Let Cn+ = {x in C' such that x = Uy, y = (u, 0), u a k-vector} and Cn = {x in Cn such that x = Uy, y = (0, v), v an (n - k)-vector}. Since U is nonsingular Cn+ Q Cn = C" and this defines the projection operators Tr+, 7r\_ above. It is clear that (6.1) and (6.2) are satisfied.

The subspace Cn+ defined in (6.1) is called the unstable manifold passing through zero and Cn is called the stable manifold passing through zero. The orbits of solutions on the unstable manifold approach zero as t --- > - 00 and the orbits of solutions on the stable manifold approach zero as t --. 00. Furthermore, the construction of C+, Cn clearly shows that the only solutions of (4.1) whose orbits remain in a given neighborhood of the origin for all t >\_ 0 (t < 0) must have their initial values on Cn (C+).

What type of behavior is expected when a linear system with x = 0 as a saddle point is subjected to perturbations which are small near x = 0? The following example is instructive. Consider the second order system

$$\dot{x}_1 = x_1, \ \dot{x}_2 = -x_2 + x_1^3,$$

whose general solution is

$$egin{aligned} x_1(t) &= e^t a, \ x_2(t) &= e^{-t} igg( b - rac{a^3}{4} igg) + rac{a^3}{4} \, e^{3t}, \end{aligned}$$

where a, b are arbitrary constants. It is easily seen that x1(t), x2(t)-0 as t oo if and only if a = 0 and b is arbitrary. Also, xl(t), x2(t) - .0 as t - oo if and only if b = a3/4 and a is arbitrary. If b = a3/4, then the corresponding orbit in the phase plane is x2 = xi/4. The phase plane portrait is shown in Fig. 6.1. Notice that the stable and unstable manifolds near x = 0 are essentially the same as the ones for the linear system. This example motivates the following definition of a saddle point for nonlinear equations.

Suppose xo is an equilibrium point of the equation

$$\dot{x} = Ax + f(x),$$

where f is continuous on Cn. We say xo is a saddle point of type (k) of (6.3) if there is a bounded, open neighborhood V of xo and two sets Uk, S,-k, in Cn, Uk n Sn\_k = {xo}, of dimensions k and n - k, respectively, Uk negatively invariant, Sn\_k positively invariant with respect to (6.3), such that the orbit of any solution of (6.3) which remains in V for t < 0 (t >\_ 0) must have initial value in Uk(Sn\_k) and the orbit of any solution with initial value in

![](_page_117_Figure_2.jpeg)

Figure III. 6.1

 $U_k(S_{n-k})$  approaches  $x_0$  as  $t \to -\infty$   $(+\infty)$ . The set  $U_k$  is called the *unstable manifold* and  $S_{n-k}$  the stable manifold.

If x = 0 is a saddle point of (4.1) of type (k), we say that the saddle point property is preserved relative to a given class  $\mathscr{F}$  of functions if, for each f in  $\mathscr{F}$ , the system (6.3) has an equilibrium point  $x_0 = x_0(f)$  which is a saddle point of type (k).

Our main interest centers around the preservation of the saddle point property when the family  $\mathscr{F}$  is a family of "small" perturbations and the equilibrium point  $x_0 = x_0(f)$  satisfies  $x_0(0) = 0$ . If f has continuous first derivatives and we measure f by specifying that the norm of f in a bounded neighborhood V of x = 0 as

$$|f| = \sup_{x \in V} |f(x)| + \sup_{x \in V} \left| \frac{\partial f(x)}{\partial x} \right|.$$

then there is no loss in generality in assuming that f(x) = o(|x|) as  $|x| \to 0$ . In fact, there is a  $\delta > 0$  such that the matrix  $A + \partial f(x)/\partial x$  as a function of x has k eigenvalues with positive real parts, n-k with negative real parts for  $|x| < \delta$ . From the implicit function theorem, the equation Ax + f(x) = 0 has a unique solution  $x_0$  in the region  $|x| < \delta$ . The transformation  $x = x_0 + y$  yields the equation

$$\dot{y} = \left[A + \frac{\partial f(x_0)}{\partial x}\right] y + f(x_0 + y) - f(x_0) - \frac{\partial f(x_0)}{\partial x} y$$

$$\stackrel{\text{def}}{=} By + g(y),$$

where B has k eigenvalues with positive real parts, n-k with negative real parts and g(y) = o(|y|) as  $|y| \to 0$ .

On the strength of this remark, we consider the preservation of the saddle point property for equation (6.3) for families of continuous functions f which at least satisfy f(x) = o(|x|) as  $|x| \to 0$ .

LEMMA 6.1. If  $f: C^n \to C^n$  is continuous, x = 0 is a saddle point of type (k) of (4.1),  $\pi_+$ ,  $\pi_-$  are the projection operators defined in (6.1), then, for any solution x(t) of (6.3) which exists and is bounded on  $[0, \infty)$ , there is an  $x_-$  in  $\pi_- C^n$  such that x(t) satisfies

(6.4) 
$$x(t) = e^{At}x_{-} + \int_{0}^{t} e^{A(t-s)}\pi_{-}f(x(s)) ds + \int_{\infty}^{0} e^{-As}\pi_{+}f(x(t+s)) ds,$$

for  $t \ge 0$ . For any solution x(t) of (6.3) which exists and is bounded on  $(-\infty, 0]$ , there is an  $x_+$  in  $\pi_+C^n$  such that

(6.5) 
$$x(t) = e^{At}x_{+} + \int_{0}^{t} e^{A(t-s)}\pi_{+} f(x(s)) ds + \int_{-\infty}^{0} e^{-As}\pi_{-} f(x(t+s)) ds$$

for  $t \le 0$ . Conversely, any solution of (6.4) bounded on  $[0, \infty)$  and any solution of (6.5) bounded on  $(-\infty, 0]$  is a solution of (6.3).

PROOF. Suppose x(t) is a solution of (6.3) which exists for  $t \ge 0$  and  $|x(t)| \le M$  for  $t \ge 0$ . There is a constant L such that  $|\pi_+ x| \le L|x|$  for all x in  $C^n$  and, thus,  $|\pi_+ x(t)| \le ML$  for all  $t \ge 0$ . Since f is continuous there is a constant N such that  $|f(x(t))| \le N$ ,  $t \ge 0$ . For any  $\sigma$  in  $[0, \infty)$ , the solution x(t) satisfies

$$\pi_+x(t)=e^{A(t-\sigma)}\pi_+x(\sigma)+\int_{\sigma}^t e^{A(t-s)}\pi_+f(x(s))\ ds, \qquad t ext{ in } [0, \infty),$$

since  $A\pi_{+} = \pi_{+}A$ ,  $A\pi_{-} = \pi_{-}A$ .

Since the matrix A satisfies (6.2),

$$|e^{A(t-\sigma)}\pi_+x(\sigma)| \leq Ke^{\alpha(t-\sigma)}|\pi_+x(\sigma)| \leq KLMe^{\alpha(t-\sigma)},$$

for  $t \leq \sigma$  and, therefore, approaches zero as  $\sigma \to \infty$ . Also, for  $t \leq \sigma$ ,

$$\begin{split} \left| \int_{\sigma}^{t} e^{A(t-s)} \pi_{+} f(x(s)) \ ds \right| &\leq K \int_{t}^{\sigma} e^{\alpha(t-s)} |\pi_{+} f(x(s))| \ ds \\ &\leq K L N \int_{t}^{\sigma} e^{\alpha(t-s)} \ ds \\ &= \frac{K L N}{\alpha} \left[ 1 - e^{\alpha(t-\sigma)} \right], \\ &\leq \frac{K L N}{\alpha}. \end{split}$$

Therefore, the integral  $\int_{\infty}^{t} e^{A(t-s)} \pi_{+} f(x(s)) ds$  exists. From the above integral equation for  $\pi_{+} x(t)$ , this implies

$$\pi_+ x(t) = \int_{-\infty}^{0} e^{-As} \pi_+ f(x(t+s)) ds.$$

Since  $x(t) = \pi_+ x(t) + \pi_- x(t)$ , this relation and the variation of constants formula yield (6.4). Relation (6.5) is proved in a completely analogous manner. The last statement of the lemma is verified by direct computation to complete the proof.

Notice that  $x_-$ ,  $x_+$  in (6.4), (6.5) are not the initial values of the solutions at t = 0, but are determined only after the solution is known.

LEMMA 6.2. Suppose  $\alpha > 0$ ,  $\gamma > 0$ , K, L, M are nonnegative constants and u is a nonnegative bounded continuous solution of either the inequality

$$(6.6) u(t) \leq Ke^{-\alpha t} + L \int_0^t e^{-\alpha (t-s)} u(s) ds + M \int_0^\infty e^{-\gamma s} u(t+s) ds, t \geq 0,$$

or the inequality

$$(6.7) u(t) \leq Ke^{\alpha t} + L \int_t^0 e^{\alpha(t-s)} u(s) ds + M \int_{-\infty}^0 e^{\gamma s} u(t+s) ds, t \leq 0.$$

If

$$\beta \stackrel{\text{def}}{=} \frac{L}{\alpha} + \frac{M}{\nu} < 1,$$

then, in either case,

(6.9) 
$$u(t) \leq (1-\beta)^{-1} K e^{-[\alpha - (1-\beta)^{-1}L]|t|}.$$

PROOF. We only need to prove the lemma for u satisfying (6.6) since the transformation  $t \to -t$ ,  $s \to -s$  reduces the discussion of (6.7) to (6.6). We first show that  $u(t) \to 0$  as  $t \to \infty$ . If  $\delta = \overline{\lim}_{t \to \infty} u(t)$ , then u bounded implies  $\delta$  is finite. If  $\theta$  satisfies  $\beta < \theta < 1$ , then  $\delta > 0$  implies there is a  $t_1 \ge 0$  such that  $u(t) \le \theta^{-1}\delta$  for  $t \ge t_1$ . From (6.6), for  $t \ge t_1$ , we have

$$(6.10) u(t) \leq Ke^{-\alpha t} + Le^{-\alpha t} \int_0^{t_1} e^{\alpha s} u(s) ds + \left(\frac{L}{\alpha} + \frac{M}{\gamma}\right) \theta^{-1} \delta.$$

Since the lim sup of the right hand side of (6.10) as  $t \to \infty$  is  $< \delta$ , this is a contradiction. Therefore,  $\delta = 0$  and  $u(t) \to 0$  as  $t \to \infty$ .

If  $v(t) = \sup_{s \ge t} u(s)$ , then  $u(t) \to 0$  as  $t \to \infty$  implies for any t in  $[0, \infty)$ , there is a  $t_1 \ge t$  such that  $v(t) = v(s) = u(t_1)$  for  $t \le s \le t_1$ ,  $v(s) < v(t_1)$  for

 $s > t_1$ . From (6.6), this implies

$$egin{aligned} v(t) &= u(t_1) \leqq Ke^{-lpha t_1} + L \int_0^t e^{-lpha (t_1 - s)} v(s) \ ds \ &+ L \int_t^{t_1} e^{-lpha (t_1 - s)} v(s) \ ds + M \int_0^\infty e^{-\gamma s} v(t + s) \ ds \ &\leqq Ke^{-lpha t_1} + L \int_0^t e^{-lpha (t_1 - s)} v(s) \ ds + eta v(t), \end{aligned}$$

where  $\beta = L/\alpha + M/\gamma < 1$ . If  $z(t) = e^{\alpha t}v(t)$ , then  $t_1 \ge t$  implies

$$z(t) \le (1-\beta)^{-1}K + (1-\beta)^{-1}L \int_0^t z(s) \ ds.$$

From Gronwall's inequality, we obtain  $z(t) \leq (1-\beta)^{-1}K \exp(1-\beta)^{-1}Lt$  and, thus, the estimate (6.9) in the lemma for u(t).

EXERCISE 6.1. Suppose a, b, c are nonnegative continuous functions on  $[0, \infty)$ , u is a nonnegative bounded continuous solution of the inequality

$$u(t) \leq a(t) + \int_0^t b(t-s)u(s) \ ds + \int_0^\infty c(s)u(t+s) \ ds, \qquad t \geq 0,$$

and  $a(t) \to 0$ ,  $b(t) \to 0$  as  $t \to \infty$ ,  $\int_0^\infty b(s) \, ds < \infty$ ,  $\int_0^\infty c(s) \, ds < \infty$ . Prove that  $u(t) \to 0$  as  $t \to \infty$  if

$$\int_0^\infty b(s) \, ds + \int_0^\infty c(s) \, ds < 1.$$

If  $\Gamma$  is any subset in  $C^n$  which contains zero, and  $C^n = \pi_+ C^n \oplus \pi_- C^n$ ,  $\pi_+, \pi_-$  projection operators with  $\pi_+ \pi_- = \pi_- \pi_+ = 0$ , we say  $\Gamma$  is tangent to  $\pi_- C^n$  at zero if  $|\pi_+ x|/|\pi_- x| \to 0$  as  $x \to 0$  in  $\Gamma$ . Similarly, we say  $\Gamma$  is tangent to  $\pi_+ C^n$  if  $|\pi_- x|/|\pi_+ x| \to 0$  as  $x \to 0$  in  $\Gamma$ .

THEOREM 6.1. Suppose  $\eta$  is a continuous, nondecreasing, nonnegative function on  $[0, \infty)$  with  $\eta(0) = 0$  and let  $\mathcal{L}i \not p(\eta)$  designate the family of continuous functions  $f: C^n \to C^n$  such that

(6.11) (a) 
$$f(0) = 0$$
,

(b) 
$$|f(x) - f(y)| \le \eta(\sigma)|x - y|$$
,  $|x|, |y| \le \sigma$ .

If x=0 is a saddle point of type (k) of (4.1), then the saddle point property is preserved relative to the family  $\mathcal{L}i_{n}(\eta)$ . If, for any f in  $\mathcal{L}i_{n}(\eta)$ ,  $U_{k}=U_{k}(f)$ ,  $S_{n-k}=S_{n-k}(f)$  are the unstable and stable manifolds of the equilibrium point x=0 of (6.3), then  $U_{k}$  is tangent to  $\pi_{+}C^{n}$  at x=0 and  $S_{n-k}$  is tangent to  $\pi_{-}C^{n}$  at x=0, where  $\pi_{+}C^{n}$  and  $\pi_{-}C^{n}$  are the unstable

and stable manifolds of the saddle point x = 0 of (4.1). Furthermore, there are positive constants M, y such that

(6.12) (a) 
$$|x(t)| \le Me^{-\gamma t}|x(0)|$$
,  $t \ge 0$ ,  $x(0)$  in  $S_{n-k}$ ,  
(b)  $|x(t)| \le Me^{\gamma t}|x(0)|$ ,  $t \le 0$ ,  $x(0)$  in  $U_k$ .

It is worthwhile to consider the following schematic representation Fig. 6.2 of Theorem 6.1. The picture for f = 0 is global whereas for f 0, it is local. In the diagram, we have indicated orbits of (6.3) other than the ones on Uk and Sn\_k. Actually, we do not prove that the orbits which do not intersect Uk or Sn\_k behave as shown but only assert that these orbits must leave a certain neighborhood of zero with increasing t.

![](_page_121_Figure_5.jpeg)

Figure. 111.6.2

PROOF OF THEOREM 6.1. From Lemma 6.1, for any solution x of (6.3) which is bounded on [0, co), there is an x\_ in a\_Cn such that x(t) satisfies (6.4). We first discuss the existence of solutions of (6.4) on [0, oo) for any x- in ir\_Cn sufficiently small. Since ir\_, ir+ are projections, there is a constant K1 such that I1r+xl < K1JxI, 17r\_x) < K1JxJ for all x in Cn. Suppose K, « are the constants given in (6.2) and rl(a), a >\_ 0, is the function given in (6.11). Choose 8 so that

(6.13) 
$$4KK_1\eta(\delta) < \alpha, \qquad 8K^2K_1\eta(\delta) < 3\alpha$$

With this choice of 8 and for any x\_ in 7r\_Cn with Ix\_1 < 8/2K, define I(x\_, 8) as the set of continuous functions x: [0, oo)--Cn such theit JxJ \_ supost<. Ix(t) 1 < 6 and 7r\_ x(0) =x\_. 5(x\_, 6) is a closed bounded subset of the Banach space of all bounded continuous functions taking [0, oo) into Cn with the uniform topology. For any x in !§(x\_, 8), define Tx by

$$(6.14) \quad (Tx)(t) = e^{At}x_{-} + \int_{0}^{t} e^{A(t-s)}\pi_{-}f(x(s)) \ ds + \int_{\infty}^{0} e^{-As}\pi_{+}f(x(t+s)) \ ds,$$

for  $t \ge 0$ . Since x is in  $\mathcal{G}(x_-, \delta)$ , it is easy to see that Tx is defined and continuous for  $t \ge 0$  with  $[\pi_- Tx](0) = x_-$ . From (6.2), (6.11), (6.13), we obtain

$$\begin{split} |(Tx)(t)| & \leq Ke^{-\alpha t}|x_{-}| + \int_{0}^{t} Ke^{-\alpha(t-s)}|\pi_{-}f(x(s))| \ ds + \int_{0}^{\infty} Ke^{-\alpha s}|\pi_{+}f(x(t+s))| \ ds \\ & \leq Ke^{-\alpha t}|x_{-}| + \frac{KK_{1}}{\alpha} \eta(\delta)|x|[2 - e^{-\alpha t}] \\ & \leq K|x_{-}| + \frac{2KK_{1}}{\alpha} \eta(\delta)\delta \\ & < \frac{\delta}{2} + \frac{\delta}{2} = \delta, \end{split}$$

for  $t \ge 0$ . Thus,  $|Tx| < \delta$  and  $T: \mathcal{G}(x_-, \delta) \to \mathcal{G}(x_-, \delta)$ . Furthermore, the same type of estimates yields

$$|(Tx)(t) - (Ty)(t)| \le \frac{2KK_1}{\alpha} \eta(\delta)|x - y| \le \frac{1}{2} |x - y|,$$

for  $t \ge 0$ . Thus T is a contraction on  $\mathcal{G}(x_-, \delta)$  and there is a unique fixed point  $x^*(\cdot, x_-)$  in  $\mathcal{G}(x_-, \delta)$  and this fixed point satisfies (6.4).

Using the same estimates as above, one shows that the function  $x^*(\cdot, x_-)$  is continuous in  $x_-$  and  $x^*(\cdot, 0) = 0$ . However, more precise estimates of the dependence of  $x^*(\cdot, x_-)$  on  $x_-$  are needed. If we let  $x^* = x^*(\cdot, x_-)$ ,  $\tilde{x}^* = x^*(\cdot, \tilde{x}_-)$ , then, from (6.4),

$$\begin{split} |x^*(t) - \tilde{x}^*(t)| &\leq Ke^{-\alpha t}|x_- - \tilde{x}_-|| + KK_1\eta(\delta) \int_0^t e^{-\alpha(t-s)}|x^*(s) - \tilde{x}^*(s)| \ ds \\ &+ KK_1\eta(\delta) \int_0^\infty e^{-\alpha s}|x^*(t+s) - \tilde{x}^*(t+s)|| \ ds \end{split}$$

for  $t \ge 0$ . We may now apply Lemma 6.2 to this relation. In Lemma 6.2, let  $\gamma = \alpha$ ,  $M = L = KK_1\eta(\delta)$ . If  $u(t) = |x^*(t) - \tilde{x}^*(t)|$ ,  $\delta$  satisfies (6.13) and appropriate identification of constants are made in Lemma 6.2, then

$$(6.15) |x^*(t, x_-) - x^*(t, \tilde{x}_-)| \le 2K \left( \exp \left( -\frac{\alpha t}{2} \right) |x_- - \tilde{x}_-|, \quad t \ge 0.$$

Since  $x^*(\cdot, 0) = 0$ , relation (6.15) implies these solutions satisfy a relation of the form (6.12a) and approach zero exponentially at  $t \to \infty$ .

Let  $B_{\delta/2K}$  denote the open ball of radius  $\delta/2K$  in  $C^n$  with center at the origin. Let  $S_{\hbar-k}$  designate the initial values of all those solutions of (6.3) which

remain inside  $B_{\delta}$  for  $t \geq 0$  and have  $\pi_{-}x(0)$  in  $B_{\delta/2K}$ . From the above proof,  $S_{n-k}^* = \{x: x = x^*(0, x_-), x_- \text{ in } (\pi_{-}C^n) \cap B_{\delta/2K}\}$ . Let  $g(x_-) = x^*(0, x_-), x_- \text{ in } (\pi_{-}C^n) \cap B_{\delta/2K}$ . The function g is a continuous map of  $(\pi_{-}C^n) \cap B_{\delta/2K}$  onto  $S_{n-k}^*$  and is given by

(6.16) 
$$g(x_{-}) = x_{-} + \int_{\infty}^{0} e^{-As} \pi_{+} f(x^{*}(s, x_{-})) ds.$$

From (6.2), (6.11), (6.13), (6.15), we have

$$\begin{split} |g(x_{-}) - g(\tilde{x}_{-})| & \geq |x_{-} - \tilde{x}_{-}| - \int_{0}^{\infty} Ke^{-\alpha s} K_{1} \eta(\delta) |x^{*}(s, x_{-}) - x^{*}(s, \tilde{x}_{-}))| \ ds \\ & \geq |x_{-} - \tilde{x}_{-}| \left[ 1 - \frac{4K^{2} K_{1}^{\cdot} \eta(\delta)}{3\alpha} \right] \\ & \geq \frac{1}{2} |x_{-} - \tilde{x}_{-}|, \end{split}$$

for all  $x_-$ ,  $\tilde{x}_-$  in  $(\pi_-C^n)\cap B_{\delta/2K}$ . Therefore g is one-to-one. Since  $g^{-1}=\pi_-$  is continuous it follows that g is a homeomorphism. This shows that  $S_{n-k}^*$  is homeomorphic to the open unit ball in  $C^{n-k}$  and, in particular, has dimension n-k. However,  $S_{n-k}^*$  may not be positively invariant. If we extend  $S_{n-k}^*$  to a set  $S_{n-k}$  by adding to it all of the positive orbits of solutions with initial values in  $S_{n-k}^*$ , then  $S_{n-k}$  is positively invariant and also homeomorphic to the open unit ball in  $C^{n-k}$  from the uniqueness of solutions of the equation. The set  $S_{n-k}$  coincides with  $S_{n-k}^*$  when x in  $S_{n-k}$  implies  $|\pi_-x|<\delta/2K$ .

From (6.14), (6.15) and the fact that  $x^*(\cdot, 0) = 0$ , we also obtain

$$\begin{split} |\pi_+ x^*(0, x_-)| & \leq KK_1 \int_0^\infty e^{-\alpha s} \eta(|x^*(s, x_-)|) |x^*(s, x_-)| \ ds \\ & \leq KK_1 \int_0^\infty e^{-\alpha s} \eta(2K|x_-|) 2K|x_-| \ ds \\ & = \frac{2K^2K_1}{\alpha} \eta(2K|x_-|) |x_-| \, . \end{split}$$

Consequently  $|\pi_+ x^*(0, x_-)|/|x_-| \to 0$  as  $|x_-| \to 0$  in  $S_{n-k}$  which shows that  $S_{n-k}$  is tangent to  $\pi_- C^n$  at x = 0.

Using relation (6.5), one constructs the set  $U_k$  in a completely analogous manner. This completes the proof of the theorem.

In the proof of Theorem 6.1, it was actually shown that the mapping g taking  $\pi_-C^n \cap B_{\delta/2K}$  into  $S_{n-k}^*$  is Lipschitz continuous [see relations (6.15) and (6.16)]. Since the solutions of (6.3) also depend Lipschitz continuously on the initial data if (6.11) is satisfied, it follows that the *stable manifold* 

Sn\_k and also the unstable manifold Uk are Lipschitz continuous; that is, Sn\_k(Uk) is homeomorphic to the unit ball in Cn-k(Ck) by a mapping which is Lipschitz continuous. It is also clear from the proof of Theorem 6.1 that the Lipschitz condition of the type specified in (6.11b) was unnecessary. One could have assumed only that

$$|f(x)-f(y)| \le \gamma |x-y|,$$

where y satisfies (6.13) with 7)(S) replaced by y. Of course, the assertion of tangency in the theorem may not hold in this more general situation.

An even weaker version of Theorem 6.1 can be proved for functions which may not be lipschitzian but satisfy

$$(6.17) |f(x)| \le \mu |x|$$

for x in some neighborhood V of x = 0 and p satisfies (6.13) with -q(a) replaced by 1z. In fact, let S be chosen such that Ixi < S implies x in V and let 9(x\_, 8) be defined as before as all continuous functions taking [0, oo) into Cn which are bounded by 8, but use the topology of uniform convergence on compact subsets of [0, eo). If the mapping T is defined as in (6.14), one can show that T : I (x\_ , 8) - (x\_ , S) in the same manner as before. For any a > 0, choose r so large that

$$egin{aligned} |(Tx)(t)-(Ty)(t)|&\leq KK_1\int_0^t e^{-lpha(t-s)}|f(x(s))-f(y(s))|\;ds\ &+KK_1\int_0^\tau e^{-lpha s}|f(x(t+s))-f(y(t+s))|\;ds\ &+arepsilon/2 \end{aligned}$$

for any x, y in I(x\_, 8). Therefore, given any compact set 0 in [0, oo), one can always choose a 8 > 0 such that I x(t) - y(t) I < S on G implies I (Tx)(t) - (Ty)(t)i < e on G. This implies T is continuous on 8) in the topology of uniform convergence on compact sets. Since (Tx)(t) is a solution of the equation z = Az +f (x(t)), and I TxI < 8 for all x in S), it follows that I d(Tx)(t)ldtl is uniformly bounded and T is a completely continuous map of I(x\_, 8) into 9(x-, S). Using the Schauder-Tychonov theorem, one can assert the existence of a fixed point x\_) of T in W(x\_, S). Furthermore, since x\_) satisfies (6.4), it follows that

$$|x^*(t, x_-)| \le Ke^{-\alpha t}|x_-| + KK_1\mu \int_0^t e^{-\alpha(t-s)}|x^*(s, x_-)| ds$$
  
  $+ KK_1\mu \int_0^\infty e^{-\alpha s}|x^*(t+s, x_-)| ds.$ 

Again, using Lemma 6.2, one obtains

(6.18) 
$$|x^*(t, x_-)| \le 2K \left(\exp{-\frac{\alpha t}{2}}\right) |x_-|, \quad t \ge 0$$

Also, exactly as in the proof of Theorem 6.1, one obtains

(6.19) 
$$|\pi_+ x^*(0, x_-)| \le \frac{2K^2K_1}{\alpha} \mu |x_-|.$$

Thus, all solutions x(t) of (6.3) such that  $|x(t)| \le \delta$ ,  $t \ge 0$  and  $|\pi_{-}x(0)| \le \delta/2K$  approach zero as  $t \to \infty$  exponentially and in fact satisfy (6.19) for an appropriate  $x_{-}$ . If we designate  $S^*$  as the set of initial values of such solutions and extend  $S^*$  to a set S by adding to it all of the positive orbits of solutions with initial values in  $S^*$ , then it is reasonable to call S a stable manifold of (6.3).

If f satisfies the stronger condition

(6.20) 
$$f(x) = o(|x|)$$
 as  $|x| \to 0$ ,

then there is an  $\eta(\sigma)$  continuous for  $\sigma \ge 0$ ,  $\eta(0) = 0$ , such that  $|f(x)| \le \eta(\sigma)|x|$  for  $|x| \le \sigma$ . The estimate (6.19) can then be improved to

$$|\pi_+ x^*(0, x_-)| \le \frac{2K^2 K_1}{\alpha} \eta(2K|x_-|)|x_-|.$$

Relation (6.21) shows that S is tangent to  $\pi_-C^n$  at x=0. In the same manner, one obtains an unstable manifold U which is tangent to  $\pi_+C^n$  at x=0. One will still have the property  $S \cap U = \{0\}$ , but cannot assert that S has dimension n-k and U has dimension k.

If f satisfies the condition (6.17), the estimate (6.19) shows that the stable manifold must lie in a region containing  $\pi_-C$ , the region being bounded by two planes which approach  $\pi_-C$  as  $\mu \to 0$ . The same remark applies to the unstable manifold.

If f satisfies (6.20), then the tangency of the stable and unstable manifolds of (6.3) to the stable and unstable manifolds of (4.1) at x = 0 implies the following: For any neighborhood N of  $(\pi_-C^n)$  intersected with the ball of radius one with center at the origin, there is a neighborhood V of x = 0 such that the stable manifold of (6.3) relative to the neighborhood V lies in N. The same remark applies to the unstable manifold. An important consequence of this remark is the following corollary, the first part of which is a special case of Theorem 2.4.

COROLLARY 6.1. Suppose  $f: C^n \to C^n$  is continuous and f(x) = o(|x|) as  $|x| \to 0$ . If the eigenvalues of A have negative real parts, then the solution x = 0 of (6.3) is uniformly asymptotically stable. If one eigenvalue of A has a positive real part, then the solution x = 0 is unstable.

The next example due to C. Olech shows that the dimension of the stable and unstable manifolds may increase under perturbations which are continuous and o(|x|) as  $|x| \to 0$ , but which are not differentiable at x = 0. Let  $\xi(x), -\infty < x < \infty$ , be any function with continuous second derivatives in a neighborhood of x = 0,  $\xi(0) = \xi'(0) = 0$ ,  $\xi(x) \neq 0$  for  $x \neq 0$  and  $\xi(x) + x\xi'(x) = o(|x|)$  as  $x \to 0$ . For any a, let  $\psi(a, y)$  be any continuously differentiable function,  $0 \le \psi(a, y) \le 1$ ,  $-\infty < y < \infty$ ,  $\psi(a, 0) = 1$ ,  $\psi(a, -a) = 0$ . Consider the second order equation

(6.22) 
$$\dot{x}_1 = -x_1,$$

$$\dot{x}_2 = x_2 - \psi(\xi(x_1), x_2 - \xi(x_1))[\xi(x_1) + x_1\xi'(x_1)].$$

Under the above hypotheses on  $\xi$ ,  $\psi$ , we see that the perturbation is o(|x|) as  $|x| \to 0$ ,  $x = (x_1, x_2)$ . Also,  $x_2 = 0$ ,  $x_1 = e^{-t}a$ , and  $x_2 = \xi(x_1)$ ,  $x_1 = e^{-t}a$ , where a is arbitrary, are solutions of (6.22). These solutions approach zero as  $t \to \infty$ , the corresponding orbits belong to the stable manifold of x = 0, and obviously these orbits are distinct. The fan near x = 0 consisting of the orbits of the solutions whose initial values are between the curve  $x_2 = 0$  and  $x_2 = \xi(x_1)$  in Fig. 6.3 must also belong to the stable manifold of the solution x = 0 of (6.22). In fact, one easily shows that the perturbation being o(|x|) as  $|x| \to 0$  implies there is a cone enclosing the positive  $x_1$ -axis so that near x = 0 the tangent vector to any orbit cannot be perpendicular to the  $x_1$ -axis. This immediately yields the result.

![](_page_126_Picture_5.jpeg)

Figure III.6.3

## III.7. Linear Periodic Systems

Consider the homeogeneous linear periodic system

(7.1) 
$$\dot{x} = A(t)x, \quad A(t+T) = A(t), \quad T > 0$$

where A(t) is a continuous<sup>1</sup>  $n \times n$  real or complex matrix function of t. Our first objective in this section is to give a complete characterization of the general structure of the solutions of (7.1).

LEMMA 7.1. If C is an  $n \times n$  matrix with det  $C \neq 0$ , then there is a matrix B such that  $C = e^B$ .

PROOF. If P is nonsingular and there is a matrix B such that  $C = e^B$ , then  $P^{-1}CP = e^{P^{-1}BP}$ . Therefore, we may assume that C is in Jordan canonical form; that is,

$$C = \operatorname{diag}(C_1, \dots, C_p),$$

$$C_j = \lambda_j I + R_j,$$

$$R_j = \begin{bmatrix} 0 & 1 & 0 & \cdots & 0 \\ 0 & 0 & 1 & \cdots & 0 \\ \cdot & \cdot & \cdot & & \\ 0 & 0 & 0 & \cdots & 1 \\ 0 & 0 & 0 & \cdots & 0 \end{bmatrix}.$$

By hypothesis, each  $\lambda_j \neq 0$ ,  $j = 1, 2, \dots, p$ . To prove the lemma, it is sufficient to show that each  $C_j$  can be written as  $C_j = e^{B_j}$ . Therefore, we drop the subscripts and suppose  $C = \lambda I + R$  where  $\lambda \neq 0$  and R is a matrix of the same type as the  $R_j$  above; in particular,  $R^k = 0$  for all  $k \geq m$ , for some integer m. Since  $\lambda \neq 0$ ,  $C = \lambda(I + R/\lambda)$ . Let

$$B \triangleq (\log \lambda)I + S,$$
  
$$S = -\sum_{j=1}^{m-1} \frac{(-R)^j}{j\lambda^j}.$$

The matrix S is the matrix power series obtained by taking the power series for  $\log(1+t)$  near t=0 and replacing t by  $R/\lambda$ . Since  $R^k=0$  for  $k \ge m$ , there is no problem of convergence. On the other hand, one can show directly by substitution in the power series for  $e^B$  that  $C=e^B$ . The lemma is proved.

EXERCISE 7.1. For any real matrix D, det  $D \neq 0$ , show there is a real matrix B such that  $e^B = D^2$ . If C is a real matrix in Lemma 7.1 and there is a real matrix B such that  $e^B = C$ , must there exist a real matrix D such that  $C = D^2$ ?

THEOREM 7.1. (Floquet) Every fundamental matrix solution X(t) of (7.1) has the form  $X(t) = P(t)e^{Bt}$  where P(t), B are  $n \times n$  matrices, P(t+T) = P(t) for all t, and B is a constant.

<sup>&</sup>lt;sup>1</sup> This assumption is for simplicity only. The theory is valid for A(t) which are periodic and Lebesgue integrable if (7.1) is required to be satisfied except for a set of Lebesgue measure zero. No changes in proofs are required.

PROOF. Suppose X(t) is a fundamental matrix solution of (7.1). Then X(t + T) is also a fundamental matrix solution since A(t) is periodic of period T. Therefore, there is a nonsingular matrix C such that

$$X(t+T)=X(t)C.$$

From Lemma 7.1, there is a matrix B such that C = eBT. For this matrix B, let P(t) = X(t)e-Bt. Then

$$P(t+T) = X(t+T)e^{-B(t+T)} = X(t)e^{BT}e^{-B(t+T)} = P(t),$$

and the theorem is proved.

COROLLARY 7.1.1 There exists a nonsingular periodic transformation of variables which transforms (7.1) into an equation with constant coefficients.

PROOF. Suppose P(t), B are defined by (7.2) and let x = P(t)y in (7.1). The equation for y is

$$\dot{y}=P^{-1}(AP-\dot{P})y.$$

Since P = Xe-Bt, it follows that P = AP - PB and this proves the result.

EXERCISE 7.2. Prove that B in the representation (7.2) can always be chosen to be a real matrix if A (t) in (7.1) is real and it is only required that P(t + 2T) = P(t).

Theorem 7.1 states that any solution of (7.1) is a linear combination of functions of the form eAtp(t) where p(t) is a polynomial in t with coefficients which are periodic in t of the same period as the period of the coefficients in the differential equation.

The eigenvalues p of a monodromy matrix are called the multi liers of (7.1) and any A such that p = e.T is called a characteristic If (7.1). Notice that the characteristic exponents are not uniquely defined, but the multipliers are. The real parts of the characteristic exponents are uniquely defined and we can always choose the ex onents A as the eigenvalues of B, where B is any matrix so that C = eBT. The characteristic multipliers do not depend upon the particular monodromy matrix chosen; that is, the particular fundamental solution used to define the monodromy matrix. In fact, if X (t) is a fundamental matrix solution, X (t + T) = X(t)C and Y(t) is any other fundamental matrix solution, then there is a nonsingular matrix D such that Y(t) = X(t)D. Therefore, Y(t + T) = X(t + T)D = X(t)CD = Y(t)D-ICD and the monodromy matrix for Y(t) is D-ICD. On the other hand, matrices which are similar have the same eigenvalues. We shall usually use the term monodromy matrix for X(T) where X(t), X(O) =I is a fundamental matrix solution of (7.1).

LEMMA 7.2. A complex number  $\lambda$  is a characteristic exponent of (7.1) if and only if there is a nontrivial solution of (7.1) of the form  $e^{\lambda t}p(t)$  where p(t+T)=p(t). In particular, there is a periodic solution of (7.1) of period T (or 2T but not T) if and only if there is multiplier =+1 (or -1)

PROOF. If  $e^{\lambda t}p(t)$ ,  $p(t+T)=p(t)\neq 0$ , satisfies (7.1), Theorem 7.1 implies there is an  $x_0\neq 0$  such that  $e^{\lambda t}p(t)=P(t)e^{Bt}x_0$ . Thus,  $P(t)e^{Bt}[e^{BT}-e^{\lambda T}I]x_0=0$  and, thus,  $\det(e^{BT}-e^{\lambda T}I)=0$ . Conversely, if there is a  $\lambda$  such that  $\det(e^{BT}-e^{\lambda T}I)=0$ , then choose  $x_0\neq 0$  such that  $(e^{BT}-e^{\lambda T}I)x_0=0$ . One can choose the representation (7.2) so that  $\lambda$  is actually an eigenvalue of B. Then  $e^{Bt}x_0=e^{\lambda t}x_0$  for all t and  $P(t)e^{Bt}x_0=P(t)x_0e^{\lambda t}$  is the desired solution. The last assertion is obvious.

LEMMA 7.3. If  $\rho_j = e^{\lambda_j T}$ , j = 1, 2, ..., n, are the characteristic multipliers of (7.1), then

(7.3) 
$$\prod_{j=1}^{n} \rho_{j} = \exp\left(\int_{0}^{T} tr \ A(s) \ ds\right),$$

$$\sum_{j=1}^{n} \lambda_{j} \equiv \frac{1}{T} \int_{0}^{T} tr \ A(s) \ ds \ \left(\text{mod } \frac{2\pi i}{T}\right).$$

PROOF. Suppose C is the monodromy matrix for the matrix solution X(t), X(0) = I, of (7.1). Then Lemma 1.5 implies

$$\det C = \det X(T) = \exp \left( \int_0^T tr \ A(s) \ ds \right).$$

The statements of the lemma now follow immediately from the definitions of characteristic multipliers and exponents.

THEOREM 7.2. (i) A necessary and sufficient condition that the system (7.1) be uniformly stable is that the characteristic multipliers of (7.1) have modulii  $\leq 1$  (the characteristic exponents have real parts  $\leq 0$ ) and the ones with modulii =1 (the characteristic exponents with real parts =0) have simple elementary divisors.

(ii) A necessary and sufficient condition that the system (7.1) be uniformly asymptotically stable is that all characteristic multipliers of (7.1) have modulii <1 (all characteristic exponents have real parts <0). If this is the case and X(t) is a matrix solution of (7.1), there exist K>0,  $\alpha>0$  such that

$$|X(t)X^{-1}(s)| \le Ke^{-\alpha(t-s)}, \qquad t \ge s.$$

PROOF. The proof is essentially the same as the proof of Theorem 4.2 if one uses Corollary 7.1.

At first glance, it might appear that linear periodic equations share the same simplicity as linear equations with constant coefficients. However, there

is a very important difference-the characteristic exponents are defined only after the solutions of (7.1) are known and there is no obvious relation between the characteristic exponents and the matrix A (t). The following example illustrates that the eigenvalues of the matrix A(t) cannot be used to determine the asymptotic behavior of the solutions.

Example 7.1. (Markus and Yamabe [1]). If

(7.4) 
$$A(t) = \begin{bmatrix} -1 + \frac{3}{2}\cos^2 t & 1 - \frac{3}{2}\cos t \sin t \\ -1 - \frac{3}{2}\sin t \cos t & -1 + \frac{3}{2}\sin^2 t \end{bmatrix},$$

then the eigenvalues Al(t), A2(t) of A(t) are )q(t) = [-1 +i J7]/4, A2(t) = al(t) and, in particular, the real parts of the eigenvalues have negative real parts. On the other hand, one can verify directly that the vector

$$(-\cos t, \sin t) \exp\left(\frac{t}{2}\right)$$

is a solution of (7.1) with A(t) given in (7.4) and this solution is unbounded as t - oo. One of the characteristic multipliers is ea. The other multiplier is e-22i since (7.3) implies that the product of the multipliers is e-x.

The problem of determining the characteristic multipliers or exponents of linear periodic systems is an extremely difficult one. Except for scalar second order equations and, more generally, Hamiltonian and canonical systems, very little is known at all. Even the equations of the form z = Ax + e I (t)x where a is a small parameter, A is a constant matrix and x is a vector of dimension >2 are extremely difficult and exhibit very striking behavior. This shall be illustrated in a later chapter by means of examples.

## Hill's Equation

In this section, we give a rather detailed discussion of the stability properties of the Hill equation,

(8.1) 
$$\ddot{y} + (a + \phi(t))y = 0, \quad \phi(t + \pi) = \phi(t),$$

where a is constant and is assumed real and continuous. Actually, there is no change in the theory if is integrable and bounded, but in such a situation, we have to say the equation is satisfied almost everywhere.

The ultimate goal is to characterize the values of the parameter a for which there is stability of the equation The previous section implies this is

equivalent to determining the qualitative structure of the characteristic multipliers of (8.1) as a function of a.

Equation (8.1) is equivalent to the system

(8.2) 
$$\dot{x} = [C(a) + A(t)]x, \qquad A(t) = \begin{bmatrix} 0 & 0 \\ -\phi(t) & 0 \end{bmatrix}, \qquad x = \begin{bmatrix} y \\ \dot{y} \end{bmatrix},$$

$$C(a) = \begin{bmatrix} 0 & 1 \\ -a & 0 \end{bmatrix}.$$

Suppose

$$(8.3) X(t) \stackrel{\text{def}}{=} \begin{bmatrix} y_1(t) & y_2(t) \\ \dot{y}_1(t) & \dot{y}_2(t) \end{bmatrix}, X(0) = I,$$

is the principal matrix solution of (8.2) at t = 0. The characteristic multipliers of (8.2) are the eigenvalues of the matrix  $X(\pi)$ ; that is, the roots of the equation

$$\det(X(\pi) - \rho I) = 0.$$

Since tr[C(a) + A(t)] = 0, (7.3) implies that the characteristic multipliers are the roots of the equation

(8.4) 
$$\rho^2 - 2B(a)\rho + 1 = 0, \\ 2B(a) = tr \ X(\pi) = y_1(\pi) + \dot{y}_2(\pi)$$

where  $y_1, y_2$  are the solutions of (8.1) defined above. From Chapter I, the function B(a) is entire in the parameter a.

In view of Lemma 7.2 and the fact that the multipliers  $\rho_1$ ,  $\rho_2$  of (8.4) satisfy  $\rho_1\rho_2=1$ , the equation (8.1) can be stable only if  $|\rho_1|=|\rho_2|=1$ . The next lemma shows this can never be the case if  $\alpha$  is complex.

LEMMA 8.1. If a is complex,  $Im\ a \neq 0$ , equation (8.1) is unstable and no characteristic multiplier of (8.4) has modulus 1.

**PROOF.** As remarked above, equation (8.1) can be stable only if both characteristic multipliers have modulii one. Therefore, the lemma is proved if we show no characteristic multiplier has modulus one if a is complex. If a characteristic multiplier has modulus one, then Lemma 7.2 implies there must be a solution of (8.1) of the form  $e^{t\lambda t}p(t)$  where  $\lambda$  is real and  $p(t+\pi) = p(t) \not\equiv 0$ . If  $e^{t\lambda t}p(t) = u + iv$ ,  $a = \alpha + i\beta$ , u, v,  $\alpha$ ,  $\beta$ , real, then

$$\ddot{u} + [\alpha + \phi(t)]u = \beta v,$$
  
$$\ddot{v} + [\alpha + \phi(t)]v = -\beta u.$$

This implies

$$\ddot{u}v - \ddot{v}u = \beta(u^2 + v^2)$$

and, thus, upon integrating,

$$eta \int_0^t |p(s)|^2 ds \stackrel{ ext{def}}{=} eta \int_0^t [u^2(s) + v^2(s)] ds = \dot{u}(t)v(t) - \dot{v}(t)u(t) + c,$$

where c is a constant. Since the right hand side is bounded for all t and p is periodic of period  $\pi$  this gives a contradiction unless either  $\beta = 0$  or p = 0. This proves the lemma.

LEMMA 8.2. The equation  $B^2(a) = 1$  can have only real solutions. B(a) = 1 (or -1) is equivalent to the statement that there is a periodic solution of (8.1) of period  $\pi$  (or  $2\pi$ ). If a is real, then  $B^2(a) < 1$  implies all solutions of (8.1) are bounded and quasiperiodic on  $(-\infty, \infty)$ . If a is real and  $B^2(a) > 1$ , there is an unbounded solution of (8.1).

PROOF. The roots  $\rho_1$ ,  $\rho_2$  of (8.4) are  $\rho_1 = B(a) + \sqrt{B^2(a) - 1}$ ,  $\rho_2 = B(a) - \sqrt{B^2(a) - 1}$ . If  $B^2(a) = 1$ , then  $\rho_1 = \rho_2 = B(a) = \pm 1$  and Lemma 7.2 yields the statement concerning periodic solutions. This implies  $B^2(a) = 1$  can have only real solutions from Lemma 8.1. If a is real, then B(a) is real and  $B^2(a) < 1$  is equivalent to  $\rho_1 = \bar{\rho}_2$ ,  $\rho_1 \neq \rho_2$ ,  $|\rho_1| = 1$ . Lemma 7.2 implies the existence of two linearly independent solutions which are quasiperiodic. Thus, every solution is quasiperiodic. If  $B^2(a) > 1$ , then one characteristic multiplier is > 1 and one is < 1. Theorem 7.2 completes the proof of the lemma.

Lemmas 8.1 and 8.2 imply that system (8.1) can never be asymptotically stable. In the remainder of the discussion, the parameter a is taken to be real. An interval I will be called an a-interval of stability (instability) of (8.1) if for each a in I, equation (8.1) is stable (unstable). Lemma 8.2 implies that the transition from an a-interval of stability to an a-interval of instability can only occur at those values of a for which  $B^2(a) = 1$ . Therefore, the basic problem is to find those values of a for which  $B^2(a) = 1$  and discuss the behavior of the function B(a) in a neighborhood of such values. Theorem 8.1 below gives a qualitative description of the manner in which the a-stability and a-instability intervals of (8.1) are situated on the real line. The following lemmas lead to a proof of this theorem.

LEMMA 8.3. If  $a + \phi(t) \leq 0$  for all t in  $[0, \pi]$ , then there is an unbounded solution of (8.1). If, in addition,  $a + \phi(t)$  is not identically zero, then B(a) > 1.

PROOF. As before, let  $y_1(t)$  be the solution of (8.1) with  $y_1(0) = 1$ ,  $\dot{y}_1(0) = 0$ , and let  $\psi(t) = -(a + \phi(t)) \ge 0$ . From (8.1),

(8.5) 
$$(\dot{y}_1(t))^2 = 2 \int_0^t \psi(s) y_1(s) \dot{y}_1(s) ds$$

for all  $t \ge 0$ . Since  $y_1(0) = 1$ ,  $\ddot{y}_1(0) = \psi(0)y_1(0) \ge 0$ . Thus,  $\dot{y}_1(t) \ge 0$  on an interval  $0 \le t \le \eta$ . If  $\dot{y}_1(t) = 0$  for all  $t \ge 0$ , then  $y_1(t) = 1$  is a solution of

(8.1) which implies a + q(t) = 0 for all t and conversely. In this case, there are unbounded solutions since y(t) = t is a solution. Suppose a + q(t) is not identically zero and let 71 be such that y1(t) = 0 for 0 <\_ t <\_ 71 and, for any r > 0, there is a tin (71, 77 + r) such that yi(t) 0 0. Such an i always exists. One can choose r so small that yi(s) > 0 for 0 <\_ 8:5 'q + T. Since i/r(s) >\_ 0, it follows from (8.5) that yi(t) > 0 on (ii, -7 + T). The right hand side of (8.5) is a nondecreasing function of t and, therefore, y1(t) > 0 for all t >'1 and yi(t) is monotone increasing for t >\_ i . Finally

$$y_1(t) = 1 + \int_0^t \dot{y}_1(s) \ ds \ge 1 + \int_{\eta + au}^t \dot{y}_1(s) \ ds \ge 1 + \dot{y}_1(\eta + au)(t - \eta - au)$$

for t Z77 + T, r > 0. Since yi(' + r) > 0, this shows yi(t) is unbounded and proves the first part of the lemma.

To prove the second part of the lemma, we first recall the fact that we have just proved that y1(t) Z 0 for all t and, also, yi(1r) > 1. Now, consider the solution y2(t) of (8.1) with y2(0) =0, 92(0) =1. The function y2(t) will satisfy

$$(\dot{y}_2(t))^2 = 1 + 2 \int_0^t \psi(s) y_2(s) \dot{y}_2(s) ds.$$

Since a/r(s) >0 and is not identically zero, it follows that 92(7r) > 1. Therefore, 2B(a) = yi(ir) + y2(1r) >2 and the lemma is proved.

Lemma 8.3 shows that a +O(t) must take on some positive values if the solutions of (8.1) are to remain bounded. Since 0 is bounded, there is an a\* such that a\* + i(t) <0. Thus B(a) >1 and the equation (8.1) is unstable for - oo < a <a\*. We show below that this a- instability interval is bounded above.

LEMMA 8.4. The functions B(a) - 1, B(a) + 1 have an infinite number of real zeros {ao < ai < a2 }, {ai < az < }, respectively, and ak, ak approach + oo as k oo.

PROOF. We actually show that B(a) is an entire function of order 1/2, that is, B(a) is an entire function and, for any e > 0, JB(a)J exp[lale+1/2] \_\*0 as Jal-aoo and, for <0, this function is unbounded. Sinceanyentirefunction of fractional order must have an infinite number of zeros, it follows that the functions B(a) - 1, B(a) + 1 must have an infinite number of zeros. Lemma 8.2 implies these zeros are real. The only possible accumulation point of the zeros is + oo, but the remark after Lemma 8.3 implies the accumulation point must be ±oo.

If X(t) is defined as in (8.3), then

$$X(t) = I + \int_0^t [C(a) + A(s)]X(s) ds.$$

Denote the right hand side of this integral equation by (TX)(t) and define the sequence {X (k)} of functions by X (O) = I X(k+i) = TX(k), k = 0, 1, ... . Each function X (k) is an entire function of a. Suppose a belongs to a compact set V and t is in a compact set U. Exactly as in the proof of the power series, representation of eAt (see Section 4), one shows the sequence X(k)(t) \_ X(k)(t, a) converges uniformly to X(t) =X(t, a) for tin U, a in V. Therefore, X(t, a) is an entire function of a and B(a) is an entire function of a.

To show the order relation, let cue =a and consider the variation of constants formula for (8.2) treating A(t)x as the forcing function. If y1, y2 are defined as above, then

$$(8.6) y_1(t, a) = \cos \omega t - \int_0^t \omega^{-1} \sin \omega (t - s) \phi(s) y_1(s, a) ds,$$

$$y_2(t, a) = \omega^{-1} \sin \omega t - \int_0^t \omega^{-1} \sin \omega (t - s) \phi(s) y_2(s, a) ds.$$

Since I(A)-1 sin cotI <eIwtt, Icos cotI \_<el wl t, t >\_ 0, if jwl 1, it follows that

$$|y_j(t,a)| \leq e^{|\omega|t} + K \int_0^t e^{|\omega|(t-s)} |y_j(s,a)| ds, \qquad j=1, 2,$$

for 0< t<\_ Tr, where K is a bound on 0. If z(t) =e-IwItlyj(t, a)j, then

$$z(t) \leq 1 + K \int_0^t z(s) \, ds.$$

Gronwall's inequality implies z(t) < eKt < e1 , 0 < t < ir, and, therefore, I yj(t, a)l <\_ eKneiwlt, 0:5 t< ir, j =1, 2. Since y2(t, a) satisfies

$$\dot{y}_2(t, a) = \cos \omega t - \int_0^t \cos \omega (t - s) \phi(s) y_2(s, a) ds,$$

we have the existence of a constant L such that I y2(t, a)l <Leiwit 0:5 t <n.. Therefore, the order of B(a) is <\_ 1/2.

To prove the order is >\_ 1/2, it is no loss in generality to assume that q(t) < -1 for all t. In fact, we can always replace 0 by 0 - M -1, a by a + M + 1, where M is a bound on I0(t)i . Also, choose a < 0 so that ,/a-a- = iN, with p. > 0. For a < 0, 0(t) < -1, it was shown in the proof of Lemma 8.3 that y1(t, a) > 1, y2(t, a) > 1 for t > 0. This fact, -q(t) >\_ 1 and (8.6) imply that

$$\dot{y}_1(t, a) \ge \int_0^t \cosh \mu(t - s) y_1(s, a) ds$$

$$\ge \int_0^t \cosh \mu(t - s) ds$$

$$= \frac{\sinh \mu t}{\mu}$$

Thus,  $y_1(t, a) \ge (e^{\mu t} - 1)/2\mu^2 + 1$  for all t in  $[0, \pi]$ . Since  $\dot{y}_2(\pi, a) \ge 0$ , it follows that B(a) is of order at least 1/2. This completes the proof of the lemma.

**Lemma** 8.5. If b is a root of B(a) = 1 such that  $B'(b) \stackrel{\text{def}}{=} dB(b)/db \le 0$  then B'(a) < 0 for  $b < a < c^*$  provided B(a) > -1 on this interval. If  $b^*$  is a root of B(a) = -1 such that  $B'(b^*) \ge 0$ , then B'(a) > 0 for  $b^* < a < c$  provided B(a) < 1 on this interval.

PROOF. Let X(t, a) = X(t) be defined as in (8.3). From Lemma 1.5, det X(t) = 1 for all t, and, thus,

$$X^{-1}(t) = egin{bmatrix} \dot{y}_2(t) & -y_2(t) \ -\dot{y}_1(t) & y_1(t) \end{bmatrix}.$$

Also, from Theorem I.3.3 and the variation of constants formula for a linear system,

$$\frac{\partial X(t,a)}{\partial a} = X(t,a) \int_0^t X^{-1}(s,a) \, \frac{\partial C(a)}{\partial a} \, X(s,a) \, ds,$$

where C(a) is the matrix in (8.2). Thus,

$$\frac{\partial C(a)}{\partial a} = \begin{bmatrix} 0 & 0 \\ -1 & 0 \end{bmatrix}.$$

In the same way,

$$\frac{\partial^2 X(t,\,a)}{\partial a^2} = 2X(t,\,a)\,\int_0^t X^{-1}(t,\,a)\,\frac{\partial C(a)}{\partial a}\,\frac{\partial X(s,\,a)}{\partial a}\,ds.$$

From the definition of B(a), these relations imply

$$(8.7) 2B'(a) = (\alpha - \dot{\beta}) \int_0^\pi y_1 y_2 \, ds - \beta \int_0^\pi y_1^2 \, ds + \dot{\alpha} \int_0^\pi y_2^2 \, ds,$$

$$B''(a) = \alpha \int_0^\pi y_2 \, \frac{\partial y_1}{\partial a} \, ds - \beta \int_0^\pi y_1 \, \frac{\partial y_1}{\partial a} \, ds + \dot{\alpha} \int_0^\pi y_2 \, \frac{\partial y_2}{\partial a} \, ds - \dot{\beta} \int_0^\pi y_1 \, \frac{\partial y_2}{\partial a} \, ds,$$

where for simplicity in notation  $\alpha = \alpha(a) = y_1(\pi, a)$ ,  $\beta = \beta(a) = y_2(\pi, a)$ ,  $\dot{\alpha} = \dot{\alpha}(a) = \dot{y}_1(\pi, a)$ ,  $\dot{\beta} = \dot{\beta}(a) = \dot{y}_2(\pi, a)$ . Using the fact that det X(t) = 1 for all t, we have

(8.8) 
$$4(B^2-1) = (\alpha + \dot{\beta})^2 - 4(\alpha \dot{\beta} - \beta \dot{\alpha}) = (\alpha - \dot{\beta})^2 + 4\dot{\alpha}\beta.$$

Suppose b is such that B(b) = 1 and  $B'(b) \le 0$ . We wish to prove there is a  $\delta > 0$  such that B'(a) < 0 for  $b < a < b + \delta$ . If B'(b) < 0, it is clear that such a  $\delta$  exists. Suppose B'(b) = 0, B(b) = 1. For this value of b, Relation (8.8)

implies  $4\dot{\alpha}\beta = -(\alpha - \dot{\beta})^2$ . From (8.7), we have

$$2\dot{\alpha}B'(b) = \int_0^{\pi} \left[ \dot{\alpha}y_2 + \frac{1}{2}(\alpha - \dot{\beta})y_1 \right]^2 = 0$$

and thus,  $\dot{\alpha}y_2(s) + (\alpha - \dot{\beta})y_1(s)/2 = 0$  for  $0 \le s \le \dot{\pi}$ . Since  $y_1, y_2$  are linearly independent, we have  $\dot{\alpha} = 0$ ,  $\alpha = \dot{\beta}$ . Since  $\overline{B}'(b) = 0$ , relation (8.7) implies  $\beta = 0$ . The fact that  $\alpha + \dot{\beta} = 2B(b) = 2$  implies  $\alpha = \dot{\beta} = 1$ . Also, direct evaluation in (8.7) and an integration by parts yields

$$B''(b) = \left(\int_0^\pi y_1 \, y_2 \, ds\right)^2 \, - \int_0^\pi y_1^2 \, ds \, \int_0^\pi y_2^2 \, ds.$$

The Schwarz inequality implies B''(b) < 0 since the functions  $y_1, y_2$  are linearly independent. Therefore, there must be a  $\delta$  such that B'(a) < 0 for  $b < a < b + \delta$ .

Suppose now there is a  $c^*$  such that B'(a) < 0 for  $b < a < c^*$  and  $B'(c^*) = 0$  with  $B(c^*) > -1$ . Then  $B^2(c^*) - 1 < 0$  and (8.8) implies  $\dot{\alpha}(c^*)\beta(c^*) < 0$  and, in particular,  $\dot{\alpha}(c^*) \neq 0$ . One easily shows from (8.7) and (8.8) that

$$2\dot{\alpha}B'(a) = \int_0^{\pi} \left(\dot{\alpha}y_2 + \frac{1}{2}(\alpha - \dot{\beta})y_1\right)^2 ds - \frac{1}{4}(B^2 - 1)\int_0^{\pi} {y_1}^2 ds$$

for any a such that  $\dot{a}(a) \neq 0$ . Since  $B^2(c^*) < 1$ ,  $\dot{a}(c^*) \neq 0$ , it is clear that  $B'(c^*) \neq 0$ , which is a contradiction. This proves the lemma for the case B(b) = 1. The case B(b) = -1 is treated in essentially the same manner to complete the proof of the lemma.

In the middle part of the proof of this lemma, the following relationship was proved.

LEMMA 8.6 If for a particular b,  $B^2(b) = 1$ , B'(b) = 0, then B''(b) < 0 if B(b) = 1, and B''(b) > 0 if B(b) = -1. In particular, a root of  $B^2(b) = 1$  can be at most double. A necessary and sufficient condition for a double root at b is

$$y_1(\pi, b) = \dot{y}_2(\pi, b) = 1 \text{ (or } -1), \qquad \dot{y}_1(\pi, b) = y_2(\pi, b) = 0.$$

LEMMA 8.7. If  $a_0$  is the smallest root of the equation  $B^2(a) = 1$ , then  $a_0$  is simple and  $B'(a_0) < 0$ .

PROOF. From Lemma 8.3, B(a) > 1 for  $a < a_0$ . If  $a_0$  were a double root of B(a) = 1, then Lemma 8.6 would imply it is a maximum, which is impossible. This proves the lemma.

By combining the information in the above lemmas we obtain

THEOREM 8.1. There exist two sequences  $\{a_0 < a_1 \le a_2 \le \cdots\}$ ,  $\{a_1^* \le a_2^* \le a_3^* \le \cdots\}$  of real numbers,  $a_k$ ,  $a_k^* \to \infty$  as  $k \to \infty$ ,

$$a_0 < a_1^* \le a_2^* < a_1 \le a_2 < a_3^* \le a_4^* < a_3 \le a_4 < \cdots,$$

such that equation (8.1) has a periodic solution of least period  $\pi$  (or  $2\pi$ ) if and only if  $a = a_k$  for some  $k = 0, 1, 2, \ldots$  (or  $a_k^*$  for some  $k = 1, 2, \ldots$ ). The equation (8.1) is stable in the intervals

$$(a_0^{\phantom{*}}, a_1^{\phantom{*}}), \qquad (a_2^{\phantom{*}}, a_1), \qquad (a_2^{\phantom{*}}, a_3^{\phantom{*}}), \qquad (a_4^{\phantom{*}}, a_3), \ldots$$

and unstable in the intervals

$$(-\infty, a_0], \quad (a_1^*, a_2^*), \quad (a_1, a_2), \quad (a_3^*, a_4^*), \quad (a_3, a_4), \ldots$$

The equation (8.1) is stable at  $a_{2k+1}$  or  $a_{2k+2}$  (or  $a_{2k+1}^*$  or  $a_{2k+2}$ ) if and only if  $a_{2k+1} = a_{2k+2}$  (or  $a_{2k+1}^* = a_{2k+2}^*$ ),  $k \ge 0$ . Equation (8.1) is always unstable if a is complex.

PROOF. We remark first of all that (8.1) is unstable if a is complex (Lemma 8.1). Lemma 8.4 implies the existence of the two infinite sequences  $\{a_k\}$ ,  $\{a_k^*\}$ . Lemma 8.3 implies  $a_0 \neq -\infty$ . Lemma 8.3 and 8.7 imply that the first zero of  $B^2(a) = 1$  is  $a_0$ , it is simple and  $(-\infty, a_0]$  is an interval of instability. Lemma 8.5 implies  $a_0 < a_1^*$  and Lemmas 8.5 and 8.2 imply  $(a_0, a_1^*)$  is an interval of stability. If the equation (8.1) is stable at  $a_1^*$ , then B(a) = -1 would have a double root at  $a_1^*$ . Lemma 8.6 would imply B(a) has a minimum at  $a_1^*$  and then Lemma 8.5 implies  $a_1^* = a_2^*$ . If  $a_1^* < a_2^*$  then B(a) < -1 for  $a_1^* < a < a_2^*$  and Lemma 8.2 implies  $(a_1^*, a_2^*)$  is an interval of instability. Lemma 8.5 implies  $a_2^* < a_1$  and the argument proceeds inductively to yield the theorem.

The accompanying Fig. 8.1 is a possible graph of the function B(a).

The previous analysis of the general equation (8.1) has shown that it is extremely difficult to decide whether or not the solutions of (8.1) are bounded for a given a and  $\phi$ . On the other hand, the general theory has pinpointed the computations that are necessary to decide this question; namely, the determination of those special values of a for which there exist solutions of period  $\pi$  or  $2\pi$  and the number of such linearly independent solutions for these values.

One very important special case of (8.1) for which we can give some explicit conditions on the coefficients for which there is stability is the Mathieu equation

(8.9) 
$$\frac{d^2y}{d\tau^2} + (\sigma^2 + 2q\cos\omega\tau)y = 0,$$

![](_page_138_Figure_2.jpeg)

Figure III.8.1

where  $\sigma \ge 0$ , q,  $\omega$  are real constants. If we let  $\omega \tau = 2t$ , this equation is equivalent to

$$\ddot{y} + \left(\left(\frac{2\sigma}{\omega}\right)^2 + \frac{8q}{\omega^2}\cos 2t\right)y = 0,$$

which is a special case of (8.1) with  $a = (2\sigma/\omega)^2$ ,  $\phi = (8q/\omega^2)\cos 2t$ . Let us investigate this equation for q near 0. The equation for the characteristic multipliers is

$$\rho^2-2B\rho+1=0,$$

where  $B = B(\sigma, q, \omega)$  is a continuous function of  $\sigma, q, \omega^{-1}$ . For q = 0, a principal matrix solution of (8.10) is

$$X = \begin{bmatrix} \cos \frac{2\sigma}{\omega} t & \frac{\omega}{2\sigma} \sin \frac{2\sigma}{\omega} t \\ -\frac{2\sigma}{\omega} \sin \frac{2\sigma}{\omega} t & \cos \frac{2\sigma}{\omega} t \end{bmatrix}$$

Therefore,  $B(\sigma, 0, \omega) = \cos 2\pi\sigma/\omega$  and  $B^2(\sigma, 0, \omega) < 1$  if  $2\sigma \neq k\omega$  [or  $a \neq k^2$ ],  $k = 0, 1, 2, \ldots$  Thus, for any  $\sigma$  and  $\omega$  for which  $2\sigma \neq k\omega$ , there is a  $q = q(\sigma, \omega)$  such that  $B^2(\sigma, q, \omega) < 1$  and the equation (8.9) is stable (Lemma 8.2). These stability regions are shown in the  $(\sigma^2, q)$ -plane in Fig. 8.2.

One can give a very geometric proof of this stability result in the

![](_page_139_Figure_2.jpeg)

following way. If Pi' P2 are characteristic multipliers of (8.9), then pi 1, p21 are also characteristic multipliers since p1p2 = 1. Also, since a, q, w are real p1, p2 are multipliers. Therefore, if P1 =A P2, Ip1I = Ip2I =1 for q =0, then IPII = Ip2I =1, p1 P2 for q sufficiently small since the multipliers are continuous functions of q.

To determine whether or not (8.9) is stable or unstable for a2 = (kcu/2)2, k an integer, is extremely difficult. Analytical methods applicable to this problem will be discussed in a later chapter. For equation (8.9), in any neighborhood of any of the points (0, [kcu/2]2), k an integer, it can actually be shown there are values of (a2, q) such that (8.9) is unstable.

There are a large number of results in the literature which are concerned with the estimation of the stability regions in Theorem 8.1 in terms of the function a+ q(t) in (8.1). We give a theorem of Borg [1] on the first stability region which generalizes a result of Liapunov [1].

THEOREM 8.2. If p(t + a) = p(t) 0 for all t, op(t) dt 0, p(t) is coninuous, real and

$$\pi \int_0^\pi |p(t)| \ dt \le 4,$$

then all solutions of the equation

$$\ddot{u}+p(t)u=0,$$

are bounded on (-oo, oo).

PROOF. It is only necessary to show that no characteristic multiplier of (8.11) is real. If a characteristic multiplier p of (8.11) is real, then there is a real solution u(t) 0, u(t + rr) = pu(t) for all t. Either u(t) 0 0 for all t or it has infinitely many zeros with two consecutive zeros a, b, 0 < b -a S IT. In the first case u(ar) = pu(0), k(7T) = p2i(0) and 2i(7r)/u(7r) = u(0)/u(0). Since ii/u + p = 0, an integration by parts yields

$$\int_0^\pi \frac{\dot{u}^2(t)}{u^2(t)} dt + \int_0^\pi p(t) dt = 0,$$

which is impossible from the hypothesis on p. In the second case, we may assume that u(t) > 0 on a < t < b. Let  $u(c) = \max_{a < t < b} |u(t)|$ . The hypothesis on p implies

$$\begin{split} \frac{4}{\pi} & \geq \int_0^{\pi} |p(t)| \; dt \geq \int_a^b \frac{|\ddot{u}(t)|}{|u(t)|} \; dt \\ & > \frac{1}{u(c)} \int_a^b |\ddot{u}(t)| \; dt \geq \frac{1}{u(c)} \, |\dot{u}(\alpha) - \dot{u}(\beta)|, \end{split}$$

for any  $\alpha$ ,  $\beta$  in (a, b). From the mean value theorem, there exist  $\alpha$ ,  $\beta$  such that  $\dot{u}(\alpha) = u(c)/(c-a)$ ,  $-\dot{u}(\beta) = u(c)/(b-c)$ . Therefore,

$$\frac{4}{\pi} > \frac{1}{c-a} + \frac{1}{b-c} = \frac{b-a}{(c-a)(b-c)} \ge \frac{4}{b-a} \ge \frac{4}{\pi},$$

since  $4xy \le (x+y)^2$  for all x, y. This contradiction shows that the characteristic multipliers are complex and proves the result.

EXERCISE 8.1. Consider the equation

(8.12) 
$$\ddot{u} + [a - 2qS(t)]u = 0,$$

where S(t)=+1 if  $-\pi/2 \le t < 0$ , =-1 if  $0 \le t < \pi/2$ ,  $S(t+\pi)=S(t)$  for all t. Show that every neighborhood of a point  $(a_0,0)$ ,  $a_0>0$ , in the (a,q) plane where  $\cos \pi \sqrt{a_0}=\pm 1$  contains points for which (8.12) has unbounded solutions. Hint: If a>|2q|,  $r^2=a+2q$ ,  $s^2=a-2q$ , one can show that  $A=(\rho_1+\rho_2)/2$  is given by

$$A = \frac{1}{4rs} \left[ (s+r)^2 \cos \frac{\pi}{2} (s+r) - (s-r)^2 \cos \frac{\pi}{2} (s-r) \right].$$

## III.9. Reciprocal Systems

Consider the system

(9.1) 
$$\dot{x} = A(t)x, \ A(t+T) = A(t), \ -\infty < t < \infty,$$

where A(t) is a continuous real or complex  $n \times n$  matrix and T > 0 is a constant. Following Lyapunov, system (9.1) is called *reciprocal* if for every characteristic multiplier  $\rho$  of (9.1) the number  $\bar{\rho}^{-1}$  is also a characteristic multiplier. If A is real, the characteristic multipliers occur in complex conjugate pairs and (9.1) will be reciprocal if  $\rho$  a characteristic multiplier implies  $\rho^{-1}$  is a characteristic multiplier. Let  $\mathscr A$  designate the Banach space

of continuous real or complex valued n x n matrix functions A(t), - oo < t < oo, A(t + T) = A(t) with JAI =sup A(t)I.2

If A in sad is reciprocal, then Theorem 7.2 implies that (9.1) is stable if and only if all characteristic multipliers of (9.1) have simple elementary divisors and modulii equal to 1. Therefore, stability of reciprocal systems (9.1) is equal to boundedness of the solutions on (-oo, oo). We shall say (9.1) is stable on (- oo, oo) when all solutions are bounded on (- oo, oo). An element A of sad is said to be strongly stable on (-oo, oo) relative to a set -4 in sad if there is a S > 0 such that the system

$$\dot{x} = B(t)x,$$

is stable on (-oo, oo) for all B in -4 with I A - BI < S. We let 2.4 designate the set of A in d for which (9.1) is reciprocal.

LEMMA 9.1. If A is in Rd and po =po(A), Ipol =1, is a simple characteristic multiplier of (9.1), then there is a So > 0 such that the system (9.2) has a simple characteristic multiplier po(B), jpo(B)I = 1, for every B in 9,4 withIA - BI < So.

PROOF. Suppose A in gtd and po = po(A) is a simple characteristic multiplier of (9.1), Ipol = 1. Formula (1.11) implies that the matrix solution XA(t); XA(0) = I, of (9.1) is a continuous function of A in d. In particular, the characteristic multipliers of (9.1) are continuous functions of A in a. Therefore, there is a disk DE(po), E > 0, in the complex plane of radius s and center po and a SI > 0 such that (9.2) has exactly one characteristic multiplier pp(B) in DE(po) for all B in Rsaf, I A - BI < S1. Since (9.2) is reciprocal, p 1(B), is also a characteristic multiplier. But, po 1(B) \_ po(B)II po(B)I2 po(B) unless Ipo(B)I = 1. On the other hand, the hypothesis Ipo(A)I =1 implies po 1(A) = p0(A) and by continuity of p0(A) in A, we can find a So < S1 such that po 1(B), p0(B) belong to DE(p0) if I A - BI < So , B in 9si. This implies Ipo(B)I = 1 for I A - BI < So, B in gtsad, and proves the lemma.

THEOREM 9.1. If A is in 3tsad and all of the characteristic multipliers of (9.1) are distinct and have unit moduhi, thenA is strongly stable relative to 3tsa1.

PROOF. This is immediate from Lemma 9.1 and the Floquet representation of the solutions of a periodic system.

LEMMA 9.2. If A in .4 is real and there exists an n x n nonsingular

<sup>2</sup> If A is not continuous but only Lebesgue integrable, then the results below are valid with JAS = fo JA(8)J d8.

matrix D such that either

(i) DA(t) = -A(-t)D

 $\mathbf{or}$ 

(ii) 
$$DA(t) = -A'(t)D$$
, (A' is the transpose of A)

then A is in  $\mathcal{R}\mathscr{A}$ . In (i) the principal matrix solution X(t) satisfies  $X^{-1}(-t)DX(t) = D$  and in (ii) it satisfies X'(t)DX(t) = D for all t.

PROOF. Let X(t), X(0) = I, be a matrix solution of (9.1). If Y(t),  $Y(0) = Y_0$  is an  $n \times n$  matrix solution of the adjoint equation  $\dot{y} = -yA(t)$ , then  $Y(t)X(t) = Y_0$  for all t.

Case i. If DA(t) = -A(-t)D, then  $Y(t) = X^{-1}(-t)D$  satisfies the adjoint equation. In fact,  $\dot{Y}(t) = -\dot{X}^{-1}(-t)D = X^{-1}(-t)A(-t)D = -X^{-1}(-t)DA(t) = -Y(t)A(t)$ . Therefore,  $X^{-1}(-t)DX(t) = D$  which implies X(t) is similar to X(-t) for all t. If  $X(t) = P(t)e^{Bt}$ , then P(0) = I and X(t) similar to X(-t) implies the roots of  $\det(e^{BT} - \rho I) = 0$  and  $\det(e^{-BT} - \mu I) = 0$  are the same. Obviously, these roots are the reciprocals of each other and this proves case (i).

Case ii. If DA(t) = -A'(t)D, then Y(t) = X'(t)D is a solution of the adjoint equation. In fact,  $\dot{Y} = \dot{X}'D = X'A'D = -X'DA = -YA$ . Thus, X'(t)DX(t) = D for all t and X'(t) is similar to  $X^{-1}(t)$  for all t. The remainder of the argument proceeds as in case (i).

By far the most important reciprocal systems are Hamiltonian systems namely, the systems

$$(9.3) E\dot{x} = H(t)x,$$

where H' = H is a real  $2k \times 2k$  matrix of period T,

$$E = \begin{bmatrix} 0 & I_k \\ -I_k & 0 \end{bmatrix},$$

and  $I_k$  is the  $k \times k$  unit matrix. Since  $E^2 = -I_{2k}$ , E' = -E system (9.3) is a special case of system (9.1) with A = -EH and EA = H = H' = A'E' = -A'E. Thus, (9.3) is reciprocal since this is a special case of case (ii) of Theorem 9.2 with D = E. Furthermore, the matrix solution X(t), X(0) = I of (9.3) satisfies

$$(9.4) X'(t)EX(t) = E.$$

The set of all matrices which satisfy (9.4) is called the *real symplectic group* or sometimes such a matrix is called *E-orthogonal*.

A general class of complex reciprocal systems consists of the *canonical* systems,

$$(9.5) J\dot{x} = H(t)x,$$

where H is Hermitian (i.e.  $H^* = H$ , where  $H^*$  is the conjugate transpose of H) and

$$(9.6) J = i \begin{bmatrix} I_p & 0 \\ 0 & -I_q \end{bmatrix}, i = \sqrt{-1},$$

To prove this system is reciprocal, let X(t), X(0) = I, be a principal matrix solution of (9.5). Then A = -JH is the coefficient matrix in (9.5) and

$$\frac{d}{dt} X^*(t) J X(t) = -X^*(t) H^*(t) J^* J X(t) - X^*(t) J^2 H(t) X(t) = 0,$$

and  $X^*(t)JX(t)$  is a constant. Since X(0) = I, we have

$$(9.7) X^*(t)JX(t) = J,$$

for all t. Thus X(T) is similar to  $X^{*-1}(T)$  and the result follows immediately. Matrices which satisfy (9.7) are called J-unitary. Notice that J-unitary matrices are nonsingular.

System (9.5) includes as a special case system (9.3) for the following reason. Any two skew Hermitian matrices A, B with the same eigenvalues with the same multiplicity are unitarily equivalent; that is, if  $A^* = -A$ ,  $B^* = -B$ , then there is a matrix U such that  $U^*U = UU^* = I$  and  $U^*AU = B$ . If, in addition, A and B are real, there is a real unitary (orthogonal) matrix U such that U'AU = B. Since E is skew Hermitian with the eigenvalue i of multiplicity k there is a unitary U such that  $UEU^* = J$ , where J is given in (9.6) with p = q = k. If we let  $x = U^*y$  then (9.3) is transformed into (9.5) with H replaced by  $UHU^*$ . A matrix U which accomplishes this is

(9.8) 
$$U = \frac{1}{\sqrt{2}} \begin{bmatrix} I_k & -iI_k \\ -iI_k & I_k \end{bmatrix}.$$

A special case of (9.5) is the second order system

$$(9.9) \ddot{u} + Q\dot{u} + P(t)u = 0,$$

where u is a k-vector, Q is a constant matrix,  $Q^* = -Q$ ,  $P^*(t) = P(t)$ . In fact, system (9.9) can be written in the form

$$K\dot{x} = H(t)x$$

where

$$x = \begin{bmatrix} u \\ \dot{u} \end{bmatrix}, \qquad K = \begin{bmatrix} -Q & -I_k \\ I_k & 0 \end{bmatrix}, \qquad H(t) = \begin{bmatrix} P(t) & 0 \\ 0 & I_k \end{bmatrix}.$$

There is a nonsingular matrix P such that  $PKP^* = J$  and, therefore, the transformation  $x = P^*y$  reduces (9.9) to a special case of (9.5).

Case (i) in Lemma 9.2 expresses some even and oddness properties of the coefficient matrix A(t). To illustrate, consider the second order matrix system

$$(9.10) \ddot{u} + P(t)u = 0,$$

where P(t + T) = P(t) is a k x k continuous real matrix. This is equivalent to the system of order 2k,

(9.11) 
$$\dot{x} = A(t)x, \qquad A(t) = \begin{bmatrix} 0 & I_k \\ -P(t) & 0 \end{bmatrix}.$$

If P =(PPk), j, k =1, 2 is partitioned so that P11 is an r x r matrix and P22 is an s x s matrix with PJk(t) = (-1)1+kPtk(-t), then (9.11) is reciprocal. In fact, case (i) of Lemma 9.2 is satisfied with D = diag(Ir, -Is , -Ir, Is).

An even more special reciprocal system is the system

(9.12) 
$$\ddot{u} + Fu = 0,$$
 
$$F = \operatorname{diag}(\sigma_1^2, \ldots, \sigma_n^2), \qquad \sigma_i > 0.$$

The matrix F is periodic of any period. For any period T > 0, the characteristic multipliers of (9.12) are p2J-1 = p2J, p2t\_1 = eia,T, j =1, 2, ..., n. These multipliers are distinct if and,only if

$$(9.13) 2\sigma_j \not\equiv 0 \pmod{\omega}, \sigma_j \pm \sigma_k \not\equiv 0 \pmod{\omega}, j \neq k,$$

where T = 2a/w. Consequently, if (9.13) is satisfied, Theorem 9.1 implies there is a S >'O such that all solutions of (9.2) are bounded in (-oo, oo) provided that B is in 9 d and

$$|B-A|<\delta, \qquad A=egin{bmatrix} 0 & I \ -F & 0 \end{bmatrix},$$

and F is defined in (9.12). In particular, if'(t) = c(t + 7) is real, symmetric or satisfies the even and oddness conditions above and (9.13) is satisfied, there is an co > 0 such that all solutions of the system

(9.14) 
$$\ddot{u} + (F + \varepsilon \Phi(t))u = 0$$

are bounded in (- oo, oo) for all sl < so. Compare this result with the one at the end of Section 8 for a single second order equation.

If some of the conditions (9.13) are not satisfied, it is very difficult to determine whether there is an so > 0 such that solutions of (9.14) are bounded for 1el < eo. For Hamiltonian systems, some general results are available (see Section 10) but, for the other cases, only special equations have been discussed. Iterative schemes for reaching a decision are available and will be discussed in a subsequent chapter.

If system (9.14) is not a reciprocal system, it can be shown by example (see Chapter VIII) that even when (9.13) is satisfied, solutions of (9.14) may be unbounded for any e ; 0.

EXERCISE 9.1. Suppose B(t) is an integrable T-periodic matrix such that the characteristic multipliers of x = B(t)x are distinct and have unit modulii. If A(t) is an integrable T-periodic matrix such that z =A (t)x is reciprocal, then there is a S > 0 such that f o JA(s) - B(s)1 ds < S implies the equation x=A(t)x is stable on (-oo, oo). Hint: Use the continuity of the fundamental matrix solution of z =A (t)x in A which is implied by formula (1.11).

### II1.10. Canonical Systems

As in Section 9, let sl be the Banach space of n x n complex integrable matrix functions of period T with JAI = fo IA(t)Idt. Let Wof be the subspace consisting of those matrices of the'form -JH, H\* = H and

(10.1) 
$$J = i \begin{bmatrix} I_p & 0 \\ 0 & -I_q \end{bmatrix}.$$

If A belongs to 'd, then the associated periodic differential system is a canonical system

$$(10.2)^{\dot{}} \qquad J\dot{x} = H(t)x, \qquad H^* = H,$$

Our main objective in this section is to give necessary and sufficient conditions in order that system (10.2) be strongly stable on (-oo, oo) relative to 9d.

We have seen in Section 9 that a canonical system (10.2) is reciprocal and, therefore, stable on (- oo, co) if and only if all characteristic multipliers of (10.2) are on the unit circle and have simple elementary divisors; or, equivalently, that all eigenvalues of the monodromy matrix S have simple elementary divisors and modulii 1. This latter statement is equivalent to saying there is a nonsingular matrix U such that

$$U^{-1}SU = \operatorname{diag}(e^{i\nu_1}, \ldots, e^{i\nu_n}), \quad \nu_j \text{ real.}$$

It was also shown in Section 9 that the monodromy matrix S of a principal matrix solution of (10.2) is J-unitary; that is,

$$S*JS = J.$$

Since the stability properties of (10.2) depend only upon the eigenvalues of S, we use the following terminology: A J-unitary matrix S i8 stable if all

eigenvalues have modulii 1 and simple elementary divisors. A J-unitary matrix S is strongly stable if there is a 8 > 0 such that every J-unitary matrix R for which R - SI < 8 is stable.

Preliminary to the discussion of stability, we introduce the following terminology. For any x, y in Cn, define the bilinear form

$$\langle x,y \rangle = i^{-1}y^*Jx.$$

For Hamiltonian systems, the expression <x, y> is related to the Lagrange bracket. In fact, if U is given in (9.8) and x = U\*u, y\* = v\* U, then <u, v> = i-lv\*Eu. For real vectors v, u, v\*Eu is the Lagrange bracket.

Since i-1J is Hermitian, it is clear that <x, y> = <y, x> and <x, x> is real. The J-norm of x is <x, x)'. A subspace V of Cn is called non-negative if <x, x> >\_ 0 for all x in V and positive if <x, x> > 0 for all x 0 0 in V. Two vectors x, y are called J-orthogonal if <x, y> = 0. If <x, y> = 0 for all y, then Jx = 0 which implies x = 0. This immediately implies that S is J-unitary if and only if <Sx, Sy> = <x, y> for all x, y. It is immediate from the definition of J that the vectors e1 = (1, 0, ..., 0), e2 = (0, 1, ... , 0), ... , en = (0, 0, ..., 1) satisfy

(10.4) 
$$\langle e^j, e^k \rangle = 0, \qquad j \neq k,$$
  $\langle e^j, e^j \rangle = 1, \qquad 1 \leq j \leq p,$   $\langle e^j, e^j \rangle = -1, \qquad p < j \leq n.$ 

LEMMA 10.1. Eigenvectors associated with distinct eigenvalues of a stable J-unitary matrix are J-orthogonal. The eigenvectors of a stable J-unitary matrix span Cn.

PROOF. If x, y are eigenvectors associated with A, p, respectively, <sup>A</sup> µ and JAI = 1, then <x, y> = <Sx, Sy> = Aµ<x, y>. If AA 0 1, then <x, y> = 0. Since the system is assumed stable 4-1 = a and A p imply A11= A/p 1. This proves <x, y> = 0. The proof that the eigenvectors of a stable J-unitary matrix span the space is now supplied in exactly the same way that one proves the corresponding result for unitary matrices in linear algebra.

LEMMA 10.2. A nonnegative eigenspace V of a stable J-unitary matrix is positive. A nonpositive eigenspace of a stable J- unitary matrix is negative.

PROOF. Suppose V is nonnegative. If x is in V and <x, x> = 0, then for any y in V and any complex number A,

$$0 \leq \langle y + \lambda x, y + \lambda x \rangle = \langle y, y \rangle + 2 \operatorname{Re} \lambda \langle x, y \rangle.$$

We must have <x, y> = 0 for otherwise A could be chosen in such a manner as to make this expression negative. Therefore, <x, y> = 0 for all y in V. This

fact together with Lemma 10.1 imply (x, y) = 0 for all y. Thus, x = 0. A similar argument applies when V is nonpositive and proves the lemma.

THEOREM 10.1. A matrix S is a stable J-unitary matrix if and only if there is a J-unitary matrix U such that

(10.5) 
$$U^{-1}SU = diag(e^{iv_1}, \ldots, e^{iv_n}),$$

where each v1 is real.

PROOF. Let 0 = diag(e{Vi, ... , e{rn). If S = UGU-1 and U is J-unitary, it is clear that S is stable and J-unitary.

Conversely, suppose S is a stable J-unitary matrix and A = etv is an eigenvalue of multiplicity r. One can choose a J-orthonormal basis v1, ..., yr for the eigenspace VA so that <vi, vk> = 0, j 0 k, = ±1 if j = k; j, k =1, 2, .... r. For if not, there would be an eigenvector v such that v is J-orthogonal to VA. This is impossible from Lemma 10.1 since it would imply v is Jorthogonal to the whole space Cn. Some of the v1 may have <vi, vi> = +1 and some may have this expression equal -1. From Lemma 10.1, we can choose a J-orthonormal basis u1, ..., un of eigenvectors for the whole space and we can order these vectors in such a way that <ui, nk> = 0, j : k, <ul, u1) = 1, j:5 p' and = -1 for p' < j 5 n. But the law of inertia for Hermitian forms and (10.4) imply that p' = p. If U = (u1, , un), then (10.5) is satisfied. Furthermore, for the vectors e1 in (10.4), <Uei, Uek> = <u1, uk> = <ei, ek> for all j, k. Thus, <Ux, Uy> = <x, y> for all x, y and U is J-unitary. This proves the theorem.

It was shown in the proof of the above theorem that for any stable J-unitary matrix, a complete set of J-orthonormal eigenvectors u1 and corresponding eigenvalues A1= es " can' be obtained. We shall say that the eigenvalue Al is of positive type (or negative type) if <ui, ul> =1 (or -1). In the Russian literature, the terminology is first kind (or second kind). There are p eigenvalues of positive type and n -p of negative type. The following theorem asserts that a stable J-unitary matrix is strongly stable if and only if a multiple eigenvalue is not of both positive and negative type.

THEOREM 10.2. A stable J-unitary matrix is strongly stable if and only if each of its eigenspaces is definite (that is, either positive or negative).

PROOF. Suppose S is a stable J-unitary matrix and has an eigenvalue A, JAS = 1, whose eigenspace is not definite. Lemma 10.2 implies there are eigenvectors v1, v2 such that <v1, v2> =0, <v1, v1> = 1, <v2, v2 = -1.

Choose v3, ... , vn, J-orthogonal to v1, v2 so that v1, ..., vn form a basis for Cn. For any a Z 0, define the linear transformation R: Cn-> Cn by

$$egin{aligned} Rv^1 &= S[(\cosh lpha)v^1 + (\sinh lpha)v^2], \ Rv^2 &= S[(\sinh lpha)v^1 + (\cosh lpha)v^2], \ Rv^k &= Sv^k, \qquad k = 3, \ldots, n. \end{aligned}$$

One easily verifies that  $\langle Rv^j, Rv^k \rangle = \langle v^j, v_k \rangle$  for all j, k and, thus, the matrix associated with the transformation R is J-unitary. Also,  $v^1 + v^2$  is an eigenvector of R associated with the eigenvalue  $\lambda e^{\alpha}$ , and R has an eigenvalue with modulus >1 for any  $\alpha > 0$ . Thus, R is not stable on  $(-\infty, \infty)$ . Since R approaches S as  $\alpha \to 0$ , this implies S is not strongly stable.

Conversely, suppose S is a stable J-unitary matrix whose eigenspaces are definite. Let  $\lambda_k$ ,  $k=1,2,\ldots,r$ , be the distinct eigenvalues of S with multiplicity  $n_k$  and let  $V_k$  of dimension  $n_k$  be the corresponding eigenspaces. Then

$$C^n = V_1 \oplus V_2 \oplus \cdots \oplus V_r$$
,

and we let  $P_k$  denote the corresponding projection operators of  $C^n$  onto  $V_k$ ; that is, for any x in  $C^n$ ,  $P_k x$  is in  $V_k$  and  $P_k x = x$  if x is in  $V_k$ . These projection operators satisfy  $P_k P_j = 0$ ,  $j \neq k$ ,  $P_k^2 = P_k$ , and can be defined by the formula

(10.6) 
$$P_{k} = \frac{1}{2\pi i} \int_{\gamma_{k}} (\zeta I - S)^{-1} d\zeta,$$

where  $\gamma_k$  is a positively oriented circumference of a circle with center  $\lambda_k$  and radius so small that it contains no other eigenvalue of S. If R is any  $n \times n$  matrix with |R - S| sufficiently small, then each of circumferences  $\gamma_k$  encloses exactly  $n_k$  eigenvalues (counted with their multiplicities) of R. Therefore, the integrals

$$Q_k = \frac{1}{2\pi i} \int_{\gamma_k} (\zeta I - R)^{-1} d\zeta,$$

define projection operators  $Q_k$  of  $C^n$  onto subspaces  $W_k$  of dimension  $n_k$  such that the  $W_k$  are invariant under R and  $C^n = W_1 \oplus W_2 \oplus \cdots \oplus W_r$ . The subspace  $W_k$  is the algebraic sum of the generalized eigenspaces of R associated with the eigenvalues of R enclosed by  $\gamma_k$ . Also, this formula shows that  $Q_k$  is a continuous function of R and  $|Q_k - P_k| \to 0$  as  $R \to S$ .

Our next objective is to show that  $\langle x, x \rangle$  is definite on each  $W^k$ . For x in  $W_k$ ,

$$\langle x, x \rangle = \langle Q_k x, Q_k x \rangle$$
  
=  $\langle P_k x, P_k x \rangle + \langle (Q_k - P_k) x, (Q_k - P_k) x \rangle$   
+  $2 Re \langle P_k x, (Q_k - P_k) x \rangle$ .

From the definition of <x, y>, we have I <x, y>I < IJI ' IxI ' Iyi for all x, yin Cn. Also. since S is definite on eigenspaces, there is an « > 0 such that I <x, x>I z aclxI2 for all x in Vk and each k =1, 2, ... , r. Therefore, for x in Wk,

$$\begin{aligned} |\langle x, x \rangle| & \ge \alpha |P_k x|^2 - |J| \cdot |Q_k - P_k|^2 \cdot |x|^2 - 2|J| \cdot |P_k| \cdot |Q_k - P_k|^2 |x|^2 \\ & \ge [\alpha (1 - |Q_k - P_k|)^2 - |J| \cdot |Q_k - P_k|^2 - 2|J| \cdot |P_k| \cdot |Q_k - P_k|] |x|^2. \end{aligned}$$

Consequently, if IS - RI is small enough, the continuity of the projections Qk in B implies that

$$|\langle x, x \rangle| \ge \frac{1}{2} \alpha |x|^2, \quad x \text{ in } W_k, \quad k = 1, 2, \dots, r.$$

Since each Wk is invariant under B, for any integer m, it follows that

$$|R^mx|^2 \leq 2\alpha^{-1}|\langle R^mx, R^mx \rangle| = 2\alpha^{-1}|\langle x, x \rangle| \leq 2\alpha^{-1}|J| \cdot |x|^2,$$

f o r all x in Wk, k =1, 2, ... , r, if B is J-unitary. For any x in Cn we have x = Q1x + + Qr x and, thus,

$$|R^m x|^2 \le 2\alpha^{-1} |J| [|Q_1| + \cdots + |Q_r|]^2 |x|^2.$$

It is easy to see this implies all eigenvalues must have simple elementary divisors and modulus 1. Thus, B is stable which in turn implies S is strongly stable. This proves the theorem.

THEOREM 10.3. System (10.2) is strongly stable on (- oo, oo) if and only if the monodromy matrix is strongly stable.

PROOF. It was remarked at the beginning of this section that (10.2) is stable on (- oo, oo) if and only if the monodromy matrix is stable. Since the solutions of (10.2) depend continuously upon A in s4, then (10.2) is strongly stable on (- oo, co) if the monodromy matrix is strongly stable.

Suppose now that the monodromy matrix S of the solution X(t), X(0) = I, of (10.2) is stable and not strongly stable. In the proof of Theorem 10.2, it was shown that any neighborhood of S contains a J-unitary matrix B which has an eigenvalue with modulus >1. Since S-1R is nonsingular, Lemma 7.1 implies there is a matrix F such that S-1R = eF. For I R - SI sufficiently small, one can show directly from the power series representation of eF or from the implicit function theorem that F can be chosen to be a continuous function of R which vanishes for R=S. Furthermore, S-1R being J-unitary implies e-F =J-1eF'J=eJ-' F'J and we can choose F so that -F = J-1F\*J. Therefore, F can be written as F = TJ-1G where G is Hermitian and T is the period.

If we define Y(t) = X(t)etJ-'G, then Y(O) = I, Y(T) = R, and Y(t) is a

fundamental matrix solution of the canonical system

$$J\dot{x}=L(t)x$$
,

where L = H + X\*-1GX-1. However, L(t) may not be periodic of period T. On the other hand, we can alter L(t) by a symmetric perturbation Li(t) such that L(t) + L1(t) is periodic of period T, f T I L1(t)I dt < S for any preassigned S. If we let Y1(t), Y1(0) = I, be the fundamental matrix solution with L replaced by L + L1, then formula (1.11) implies there is a constant K such that

$$|Y_1(T)-Y(T)|\leq \delta K.$$

Therefore, for S sufficiently small the monodromy matrix Yi(T) will have an eigenvalue with modulus >1 and (10.2) is not strongly stable. This proves the theorem.

If the eigenvalues a{", of S in the representation (10.5) are ordered so that the first p are of positive and the remaining n -p are of negative type, then Theorem 10.2 states that a stable J-unitary matrix S is strongly stable if and only if

(10.7) 
$$\nu_j \not\equiv \nu_k \pmod{2\pi}, \qquad 1 \leq j \leq p < k \leq n.$$

If S is the monodromy matrix of a stable canonical system (10.2) and the eigenvalues of S are denoted by e10iT, j = 1, 2, ..., n, and ordered in the same way as above, then Theorem 10.3 implies that the canonical system is strongly stable on (- oo, oo) if and only if

(10.8) 
$$\theta_j \not\equiv \theta_k \pmod{2\pi/T}, \qquad 1 \leq j \leq p < k \leq n.$$

EXERCISE 10.1. Show that inequalities (10.8) are equivalent to the inequalities

(10.9) 
$$\sigma_j + \sigma_k \not\equiv 0 \pmod{\omega}, \quad j, k = 1, 2, \ldots, n,$$

for system (9.12), and, thus, (9.12) is strongly stable if and only if (10.9) is satisfied. Compare these inequalities with (9.13).

Theorem 10.3 answers many of the questions concerned with the qualitative properties of the stability of canonical systems. It states very clearly the critical positions of the characteristic multipliers for which one can always find a canonical system that is unstable and yet arbitrarily near to the original one. One of the basic remaining problems is the determination of an efficient procedure to obtain these critical positions of the multipliers. A method for doing this for equations which contain a small parameter is given in Chapter VIII.

## M.11. Remarks and Suggestions for Further Study

The reader interested in more results for the stability of perturbed linear systems may consult Bellman [1], Cesari [1], Coppel [1].

In the case of linear systems with constant or periodic coefficients, the stability properties of the linear system were completely determined by the characteristic exponents of the equation. Furthermore, if all characteristic exponents have negative real parts, then the linear equation is uniformly asymptotically stable. Consequently, the linear system can be subjected to a perturbation of the type given by relation (2.9) and the property of being uniformly asymptotically stable is preserved for the perturbed system. If the coefficients of the matrix A(t) in (1.3) are bounded, then every solution of (1.3) is bounded by an exponential function. Therefore, it is possible to associate with each solution x of (1.3) a number A = Ax defined by

$$\lambda = \lim \sup_{t \to \infty} \frac{1}{t} \log |x(t)|.$$

This number A was called by Lyapunov [1] the characteristic number of the solution x. If A < 0, then I x(t) I -> 0 as t -- oo. If Ax < 0 for all solutions x of (1.3), then all solutions approach zero exponentially. On the other hand, the example of Perron for A(t) as in (2.14) has the property that perturbations satisfying (2.9) can lead to unbounded solutions in contrast to the above remarks for periodic systems. There is an extensive theory of the characteristic numbers of Lyapunov and their application to stability (see Cesari [1], Malkin [1], Nemitskii and Stepanov [1], Lillo [1]).

In the discussion of the preservation of the saddle point property in Theorem 6.1, we were only concerned with the orbits on the stable and unstable manifolds. Of course, one could consider the following problem: Suppose x = 0 is a saddle point of (4.1) and f : Rn Rn has continuous first derivatives such that f (0) = 0, 8f (0)/8x = 0. Does there exist a neighborhood V of x = 0 such that for any f of the above class, there is a transformation h which takes the trajectories of (4.1) onto the trajectories of the perturbed equation (6.3) in the neighborhood V? This problem has a long and interesting history. The reader may consult Poincare [1] and Lyapunov [1] for the analytic case, Sternberg [11, Chen [11 for the case where h may have a finite number of derivatives and Hartman [1] for the general case.

The problem posed in the previous paragraph in a local neighborhood of a critical point can be made much more general. In fact, one can say two n-dimensional differential equations

$$\dot{x} = f(x),$$

$$\dot{y} = g(y),$$

are equivalent in a region G of Rn if there is a homeomorphism h which takes the trajectories of (11.1) onto the trajectories of (11.2) in G. Suppose the vector fields f, g belong to some topological space -4. A system (11.1) is said to be structurally stable if there is a neighborhood N(f) off in .4 such that (11.1) and (11.2) are equivalent for every g in N(f). The study of structural stability and equivalent systems of differential equations is at present one of the most exciting topics in differential equations. All of the concepts are equally meaningful for vector fields on arbitrary n-dimensional manifolds. The reader is referred to the basic paper of Peixoto [1] for two-dimensional systems and the paper of Smale [1] for the general problem. See also the book of Netecki [1].

The presentation of the stability theory of Hill's equation given in Section 8 relies very heavily upon the book of Magnus and Winkler [1], but does not begin to indicate the tremendous number of results that are available for this equation. The precise determination of the a-intervals of stability and instability for a given function q(t) is extremely important in the applications. Each function 0(t) defines a class of functions depending upon a and the particular of, a\* of Theorem 8.1 yield special periodic functions of period TT or 27r. It is important to discuss the expansion of arbitrary functions in terms of these special periodic functions in the same way that one develops a function in a Fourier series. For a more complete discussion as well as many references, see Arscott [1], Cesari [1], Magnus and Winkler [1], McLachlan [1].

The presentation in Section 10 follows the thesis of Howe [1 ] and should be considered only as introduction to the theory of stability of Hamiltonian and canonical systems. The topological characteristics of the class of strongly stable systems have been discussed as well as the regions of stability and instability for given equations. Computational methods also have been devised for equations with a small parameter. The reader is referred to Gelfand and Lidskii [1], Yakubovich [1, 2], Krein [1], Diliberto [2], Coppel and Howe [1] for results as well as further references.

## CHAPTER IV

## Perturbations of Noncritical Linear Systems

It is convenient to have

Definition 1. If A(t) is an n x n continuous matrix function on (- oo, oo ) and -9 is a given class of functions which contains the zero function, the homogeneous system

$$\dot{x} = A(t)x,$$

is said to be noncritical with respect to -9 if the only solution of (1) which belongs to .9 is the solution x = 0. Otherwise, system (1) is said to be critical with respect to .9.

Throughout the following, M(- oo, co) \_ {f: (- co, oo) -- Cn, f continuous and bounded} and for any f in R(- oo, co), I f I =sup,,t<.I f (t)j. The subset .slY of .4(- co, oo) denotes the set of almost periodic functions (for definition, see Appendix) and for any fin s 1g, m[f] denotes the module of f. If f, g are in sdY, then m[f, g] denotes the smallest module containing m[f] u m[g]. The subset 93T of s19 denotes the set of periodic functions of period T. The spaces .4(-co, oo), WY and 9T with I I defined as above are Banach spaces. An n x n matrix function on (-oo, co) is said to belong to one of these spaces if each column belongs to the space.

This chapter centers around the study of the existence and stability properties of solutions of

$$\dot{x} = A(t)x + f(t, x),$$

which belong- to one of the classes .(- oo, oo), s19 or 9DT for the case in which the matrix A is in YT, system (1) is noncritical with respect to the class under discussion and f is " small " in a sense to be made precise later.

The presentation will proceed as follows.' The nonhomogeneous linear system is studied first in great detail. It is shown that system (1) being noncritical with respect to -9, one of the classes 9(-oo, oo), .49 or 93T, implies that the nonhomogeneous linear equation has a unique solution in -9 which depends linearly and continuously upon the forcing function in .9.

For f in (2) "small," the contraction principle yields the existence of a solution of (2). By extending the saddle point property of Chapter III, Section 6, to nonautonomous equations, one obtains the stability properties of the solution of (2). Some generalizations of the results are given in Section 4 together with some elementary properties of Duffing's equation with large forcing and large damping in Section 5. At the end of Section 1, there is also a stability result for the case when A is not in IT .

LEMMA 1. (a) System (1) with A in 1T is noncritical with respect to \_V(-oo, oo) [or s19] if and only if the characteristic exponents of (1) have nonzero real parts. (b) System (1) with A in9T is noncritical with respect to 9T if and only if I - X(T) is nonsingular, when X(t), X(O) = I, is a fundamental matrix solution of (1).

PROOF. (a) If the characteristic exponents of (1) are assumed to have nonzero real parts, then the Floquet representation of the solutions implies that the only solution of (1) in M(- oo, co) is x = 0 and (1) is noncritical with respect to -4(- co, oo) and, therefore, also with respect to d . Conversely, if there is no solution x 0 of (1) in -4(- oo, oo), then the Floquet representation implies there cannot be a characteristic exponent A of (1) with A = iO since equation (1) would then have a nonzero solution edetp(t), p(t + T) =p(t).

(b) With X(t) defined as in the lemma, the general solution of- (1) is X (t)xo , where xc is an arbitrary constant vector. System (1) has a nonzero periodic solution of period T if and only if there is an xc 0 0 such that [X(t + T) - X(t)]xo = 0 for all t. Since A is assumed to belong to 97', this is equivalent to the existence of an xc 0 0 such that [X (T) - I]xo = 0; that is, X (T) - I is singular. This proves the lemma.

Remark 1. If A in equation (1) is a constant, then (1) is noncritical with respect to 9(-oo, co) or dY if and only if all eigenvalues of A have nonzero real parts. The equation (1) is noncritical with respect to 9T if and only if all eigenvalues A of A satisfy AT 0 (mod 2ai).; or equivalently, the purely imaginary eigenvalues iw of A satisfy co 0 (mod 2a/T).

## IV. 1. Nonhomogeneous Linear Systems

Basic to any discussion of problems concerned with perturbed linear systems is a complete understanding of the nonhomogeneous linear system

$$(1.1) \dot{x} = A(t)x + f(t),$$

where f is a given function in some specified class.

Let us recall that the equation adjoint to (1) is y = -yA(t) and X-1(t) is a fundamental matrix solution of this equation if X (t) is a fundamental matrix solution of (1). Since A belongs to YT, it follows that the adjoint equation has a nontrivial solution y with y' in eT (' is the transpose of y) if and only if y(0)[X-1(T) - I] = 0; that is, if and only if X-1(T) - I is singular. Equation (1) has a solution x in 'T if and only if [X(T) - I]x(0) = 0. Since the matrices X-1(T) - I and X(T) - I are the same except for multiplication by a nonsingular matrix, it follows that the dimensions of the set of yo such that yo[X-1(T) - I] = 0 and the set of xo such that [X (T) - I]xo = 0 are the same. Therefore, the adjoint equation and equation (1) always have the same number of linearly independent T-periodic solutions.

LEMMA 1.1. (Fredholm's alternative). If A is in -q T and f is a given element of 9T, then equation (1.1) has a solution in PiT if and only if

$$\int_0^T y(t)f(t) dt = 0,$$

for all solutions y of the adjoint equation

$$\dot{y} = -yA(t),$$

such that y' is in PT . If (1.2) is satisfied, then system (1.1) has an r-parameter family of solutions in PiT , where r is the number of linearly independent solutions of (1) in PiT .

PROOF. Since A and f belong to PiT, x(t) is a solution of (1.1) in PiT if and only if x(0) = x(T). If X(t, r), X(T, -r) = I, is a matrix solution of (1), and x(0) = x0, then

$$x(t) = X(t, 0)x_0 + \int_0^t X(t, s)f(s) ds.$$

Since X(t, T)X(T, S) = X(t, s) for all t, T, s, the condition x(T) =xo is equivalent to

$$[X^{-1}(T,0)-I]x_0 = \int_0^T X^{-1}(s,0)f(s) ds.$$

If B = X-1(T, 0) - I, b = f o X-1(s, O) f (s) ds, then (1.4) is equivalent to Bx0 = b. From elementary linear algebra, this matrix equation has a solution if and only if ab = 0 for all row vectors a such that aB = 0. Since X-1(t, 0) is a principal matrix of (1.3), the set of vectors a for which aB = 0 coincides with the set of initial values of those solutions y of (1.3) which are T-periodic; that is, the solution y(t) =aX-1(t, 0) is a T-periodic solution of (1.3) if and only if aB = 0. Using the definition of b, we obtain the first part of the lemma.

If (1.2) is satisfied and  $\phi(t)$  is a solution of (1.1) in  $\mathscr{P}_T$ , then any other solution in  $\mathscr{P}_T$  must be given by  $x = z + \phi$ , where z is a solution of (1) in  $\mathscr{P}_T$ . This proves the lemma.

EXERCISE 1.1. What is the analogue of Lemma 1.1 for the case in which A is in  $\mathcal{P}_T$  and f is in  $\mathcal{AP}$ ?

#### Example 1.1. Consider the second order scalar equation

$$\ddot{u} + u = \cos \omega t, \qquad \omega > 0.$$

If  $x_1 = u$ , an equivalent system is

$$(1.5)'$$
  $\dot{x}_1 = x_2,$   $\dot{x}_2 = -x_1 + \cos \omega t, \quad \omega > 0.$ 

The adjoint equation is  $\dot{y}_1 = y_2$ ,  $\dot{y}_2 = -y_1$  which has the general solution  $y_1 = a \cos t + b \sin t$ ,  $y_2 = -a \sin t + b \cos t$  where a, b are arbitrary constants. If  $\omega \neq 1$ , there are no nontrivial solutions of the adjoint equation of least period  $T = 2\pi/\omega$ . Thus, (1.2) is satisfied. Since the homogeneous equation has no nontrivial periodic solutions, the equation (1.5) has a unique periodic solution of period  $2\pi/\omega$ . If  $\omega = 1$ , then every solution of the adjoint equation has period  $2\pi$ . On the other hand relation (1.2) is not satisfied since

$$\int_0^{2\pi} y(t)f(t) \ dt = \int_0^{2\pi} (-a \sin t \cos t + b \cos^2 t) \ dt = \pi b$$

and this is not zero unless b=0. Therefore, the equation (1.5) has no solution of period  $2\pi$  and, in fact, all solutions are unbounded since the general solution is  $u=a\sin t + b\cos t + (t\sin t)/2$ .

#### **Example 1.2.** Consider the system (1.1) with

(1.6) 
$$A = \frac{1}{2} \begin{bmatrix} -1 & 2 & 1 \\ -1 & 0 & -1 \\ -1 & 2 & 1 \end{bmatrix}, \quad f(t) = \sin t \begin{bmatrix} -1 \\ -1 \\ 1 \end{bmatrix}.$$

One can easily show that

(1.7) 
$$e^{At} = \frac{1}{2} \begin{bmatrix} 1 + \cos t - \sin t & 2\sin t & -1 + \cos t + \sin t \\ 1 - \cos t - \sin t & 2\cos t & -1 + \cos t - \sin t \\ -1 + \cos t - \sin t & 2\sin t & 1 + \cos t + \sin t \end{bmatrix}.$$

Since the rows of  $e^{-At}$  are solutions of the adjoint equation, it follows that all solutions of the adjoint equation have period  $2\pi$ , the same period as the forcing function f, and the solutions are linear combinations of the rows of  $e^{-At}$ . To check the orthogonality condition (1.2), we need to verify that  $\int_0^{2\pi} e^{-At} f(t) dt = 0$ . One easily finds that  $e^{-At} f(t) = z \sin t$ , z = (-1, -1, 1)

and the orthogonality condition is satisfied. Therefore, system (1.1) with A and f given in (1.6) has a periodic solution of period 21r, and, in fact, every solution has period 21r.

ExERCISE 1.2. In example 1.2, is there a unique solution of period 27r which is orthogonal over [0, 2Tr] to all of the 21r-periodic solutions of the homogeneous equation-which is orthogonal to all of the 27r-periodic solutions of the adjoint equation? How does one obtain such a solution?

EXERCISE 1.3. Show that every solution of (1.1) is unbounded if relation (1.2) is not satisfied and A, f are in 9T .

THEOREM I.I. Suppose A is in YT and -9 is one of the classes aoo), dPi or PT. The nonhomogeneous equation (1.1) has a solution (-co, Y f in -9 for every f in .9 if and only if system (1) is noncritical with respect to -9. Furthermore, if system (1) is noncritical with respect to -9, then M f is the only solution of (1.1) in .' and is linear and continuous in f; that is, .%((af + bg) = a. ' f + bYg for all a, b in C, f, g in -9 and there is a constant K such that

$$(1.8) |\mathscr{K}f| \leq K|f|,$$

for all f in -9. Finally, if -9 = xlPi, then m[.7l' f ] c m [f, A].

PROOF. Case 1.21 = PiT . If f belongs to YT, then Lemma 1.1 implies that equation (1.1) has a solution in 9T if and only if f is orthogonal in the sense of (1.2) to all T-periodic solutions of (1.3). But i = A(t)x and y = -yA(t) have the same number of linearly independent T-periodic solutions. Therefore, equation (1.1) has a solution in 5T for every f in 2T if and only if equation (1) has no nontrivial solutions in Pip; that is, (1) is noncritical with respect to Y!,. If system (1) is noncritical with respect to 9T, then Lemma 1.1 implies system (1.1) has a unique solution V 'f in YT for every f in 2T . It is clear from the uniqueness that if is a linear mapping of PiT into PiT .

If X(t, -r), X(T, T) = I, is, the principal matrix solution of (1), then the function Y f f can be written explicitly as

(1.9) 
$$(\mathscr{X}f)(t) = \int_0^T [X^{-1}(t+T,t) - I]^{-1}X(t,t+s)f(t+s) ds.$$

The kernel function in this expression is known as the Green's fun\$ion for the boundary value problem x(O) = x(T) for (1.1). The explicit computations for obtaining (1.9) proceed as follows.

If we let (i f)(0) \_ xo, then

$$(\mathscr{X}f)(t) = X(t, 0)x_0 + \int_0^t X(t, s)f(s) ds.$$

Since (i f)(t + T) = (. 'f)(t), and X(t,s) = X(t,r)X(r,s) for any t,r,s, we have

$$[I - X(t+T,t)]X(t,0)x_0 = -[I - X(t+T,t)] \int_0^t X(t,s)f(s) ds + X(t+T,t) \int_t^{t+T} X(t,s)f(s) ds.$$

Multiplication by [I - X(t + T, f)] -1 and a substitution in the formula for (it'f)(t) yields (1.9).

Formula (1.9) obviously implies there is a constant K such that (1.8) is satisfied. In fact, K can be chosen as

$$T^{-1}K = \sup_{0 \le s, t \le T} |[X^{-1}(t+T,t) - I]^{-1}X(t,t+s)|$$
.

This proves Case 1.

Case 2. -' = -I(- oo, oo). Let X (t) be a fundamental matrix solution of (1). The Floquet representation implies X(t) = P(t)eBt where P(t + T) = P(t) and B is a constant. Furthermore, the transformation x = P(t)y applied to (1.1) yields

$$\dot{y} = By + P^{-1}(t)f(t) \stackrel{\text{def}}{=} By + g(t),$$

where g is in - 4 ( - oo, oo) (or 19a) if f is in 9 ( - oo, oo) (or .sat °./). Since P(t) is nonsingular, it is therefore sufficient for the first part of the theorem to show that (1.10) has a solution in -4(- oo, oo) for every g in 9(- oo, co) if and only if y = By is noncritical with respect to I(-oo, oo); that is, no eigenvalues of B have zero real parts.

By a similarity transformation, we may assume that

$$B=\operatorname{diag}(B_{+}\,,\,B_{0}\,,\,B_{-})$$

where all eigenvalues of B+(Bo)(B\_) have positive (zero) (negative) real parts. If y = (u, v, w), g = (g+, go, g\_) are partitioned so that block matrix multiplication will be compatible with the partitioning of B, then (1.10) is equivalent to the system

(1.11) (a) 
$$\dot{u} = B_+ u + g_+$$
,

(b) 
$$\dot{v} = B_0 v + g_0$$
,

(c) 
$$\dot{w} = B_- w + g_-$$
.

There are positive constants K, a so that

(1.12) (a) 
$$|e^{B+t}| \le Ke^{\alpha t}, \quad t \le 0,$$
 (b)  $|e^{B-t}| \le Ke^{-\alpha t}, \quad t \ge 0.$ 

Equations (1.lla), (1.11c) have unique bounded solutions on (-oo, oo) given, respectively, by

(1.13) (a) 
$$(\mathscr{K}_+ g_+)(t) = \int_{\infty}^{0} e^{-B_+ s} g_+(t+s) ds$$
,

(b) 
$$(\mathscr{K}_{-}g_{-})(t) = \int_{-\infty}^{0} e^{-B-s}g_{-}(t+s) ds.$$

One can either verify this directly or apply Lemma III.6.1. These remarks show that if y = By is noncritical'with respect to \_V(-oo, oo) then there is a unique solution Y f of (1.10) in 9(-oo, oo). Furthermore, using (1.12) we see that J.'r+ g+J < (K/a) Ig+J, Iir\_ g-1 < (K/-) Ig-J. Therefore, Y f satisfies (1.8).

If the matrix B has any eigenvalues with zero real parts; that is, the vector v in (1.11b) is not zero dimensional, we show there is ago in \_V(- 00, 00) such that all solutions of (1.10) are unbounded in (- co, oo). This will complete the proof of Case 2. Without loss in generality, we may assume that B0 = diag(Bol, ..., Bo8), where Bog = icop I + Rg and Rg has only zero as an eigenvalue. It is enough to consider only one of the matrices Bog since icug may be eliminated by the multiplicative transformation exp(iwg t). Thus, we consider the equation

$$\dot{x} = Rx + g$$
,

where R has only zero as an eigenvalue and g is in M(- oo, co). For any row vector a,

$$a\dot{x} = aRx + ag$$

for all t. If a # 0 is chosen so that aR = 0 and g = a\*, where a\* is the conjugate transpose of a, then ax = Ia12 > 0 which implies ax(t) oo for every solution x(t). Therefore, every solution is unbounded as t -\* 00. This completes the proof of case 2. Notice that the g chosen in (1.10) to make all solutions unbounded if B has eigenvalues with zero real parts was actually periodic and, therefore, f = P(t)g is an almost periodic (quasiperiodic) function which makes all solutions of (1.1) unbounded if (1) has purely imaginary characteristic exponents.

Case 3. -9 =.49. The previous remark implies that (1.1) has a solution in -I(- oo, oo) for all f in d1 if and only if no characteristic exponents of (1) have zero real parts or, equivalently, (1) is noncritical with respect

to .sd9. If (1) is noncritical with respect to .0'9, then the unique solution ''f in 9(-oo, cc) is a periodic transformation of the functions given in (1.13) where g+, g\_ are almost periodic with their modules contained in m[f, A] Therefore, it remains only to show that the functions in (1.13) are in sdY and their modules are in m[f, A]. We make use of Definition 1 of the Appendix.

Suppose a' = {4} is a sequence in R. Since g is almost periodic there is a subsequence a = {a1,} of a' such that {g(t + a,)} converges uniformly on Since is a continuous linear operator on (-°°,°°), this implies {(. '+g+)(t + N)}, converges uniformly on (-00,00). Thus, Definition 1 of the Appendix implies .%'+g+ is almost periodic. Theorem 8 of the Appendix implies m[.'+g+] C m[g+] C m[f,A]. The same argument applies to. g\_ to complete the proof of Case 3 and the theorem.

EXERCISE 1.4. Let -\*'be the operator defined in Theorem 1.1. Prove or disprove the relation m[\_ff ] = m[f, A] for every f in sig.

Theorem 1.1 clearly illustrates that requiring a certain behavior for some solutions of the nonhomogeneous equation (1.1) for forcing functions f in a large class of solutions imposes strong conditions on the homogeneous equation (1). For the case in which A does not belong to 9T, similar conclusions can be drawn but the analysis becomes more difficult. Preliminary to the statement of the simplest result of this type are some lemmas of independent interest.

LEMMA 1.1. If A(t) is a continuous n X n matrix, IA(t)I<M, 0 <-- t < oo, and X(t, T), X(T, T) = I, is the principal matrix solution of (1), then there is a 8 > 0 such that

$$\left|X(t,s)-X(t,\, au)
ight| \leq rac{1}{2} \left|X(t,\, au)
ight|,$$

forallt, T, sy'0and Is - TI

PROOF. Since X(t, s) = X(t, T)X(T, s) for all t, T, s in [0, oo), it is sufficient to show there is a 8 > 0 such that IX(T, S) - 11 < 1/2 for T, s >\_ 0, I T - sI < S. Since

$$X( au,s)-I=\int_s^ au A(u)[X(u,s)-I]\ du+\int_s^ au A(u)\ du,$$

an application of Gronwall's inequality yields  $|X(\tau, s) - I| \leq M |\tau - s| e^{M|\tau - s|}$  for all  $\tau$ , s. If  $\delta$  is such that  $M\delta e^{M\delta} \leq 1/2$ , the lemma is proved.

Lemma 1.2. With A and  $X(t, \tau)$  as in Lemma 1.1, the condition  $\int_0^t |X(t, s)| \ ds < c, \text{ a constant, for all } t \geq 0 \text{ implies } |X(t, s)| \text{ uniformly bounded for } 0 \leq s \leq t < \infty; \text{ that is, the equation (1) is uniformly stable for } t_0 \geq 0.$ 

PROOF. Since X(t, s)X(s, t) = I for all s, t, it follows that X(t, s) as a function of s is a fundamental matrix solution of the adjoint equation. Therefore,

$$X(t, s) = I + \int_{s}^{t} X(t, \xi) A(\xi) d\xi$$

for all t, s. In particular, for  $o \le s \le t$ , the hypotheses of the theorem imply  $|X(t, s)| \le 1 + Mc$ . The uniform stability follows from Theorem III.2.1. This proves the lemma.

THEOREM 1.2. If A(t) is a continuous  $n \times n$  matrix, |A(t)| < M,  $0 \le t < \infty$ , then every solution of (1.1) is bounded on  $[0, \infty)$  for every continuous f bounded on  $[0, \infty)$  if and only if system (1) is uniformly asymptotically stable.

PROOF. We first prove that if every solution of (1.1) is bounded on  $[0, \infty)$  for every continuous f bounded on  $[0, \infty)$ , then  $\int_0^t |X(t, s)| ds < c$ , a constant, for  $t \ge 0$ . The solution of (1.1) with x(0) = 0 is given by

$$x(t) = \int_0^t X(t, s) f(s) ds.$$

Let  $\mathscr{B}[0, \infty)$  be the class of functions  $f:[0, \infty) \to C^n$ , f continuous and bounded and let  $|f| = \sup_{0 \le t < \infty} |f(t)|$ . For any fixed t in  $[0, \infty)$ , consider the mapping  $T_t: \mathscr{B}[0, \infty) \to \mathscr{B}[0, \infty)$  given by

$$(T_t f)(\alpha) = \begin{cases} \int_0^{\alpha} X(\alpha, s) f(s) ds, & 0 \leq \alpha \leq t \\ \int_0^t X(t, s) f(s) ds, & t \leq \alpha < \infty. \end{cases}$$

For each fixed t,  $T_t$  is a continuous linear map. Furthermore, by hypothesis, for each f in  $\mathcal{B}[0, \infty)$ , there is a constant N such that  $|T_t f| \leq N$ ,  $0 \leq t < \infty$ . Consequently, the principle of uniform boundedness implies there is a constant K such that  $|T_t f| \leq K|f|$  for all t in  $[0, \infty)$ , f in  $\mathcal{B}[0, \infty)$ . In particular,

$$\left| \int_0^t X(t,s)f(s)ds \right| \le K|f|, \qquad 0 \le t < \infty.$$

If  $X = (x_{jk})$ , let  $f_t^{j,k}(s)$  be the function which is the sign of  $x_{jk}(t,s)$ , j, k = 1, 2, ..., n, for a fixed t. Choose a sequence of uniformly bounded continuous functions  $f_{t,r}^{j,k}(s)$  which approach  $f_t^{j,k}(s)$  pointwise almost everywhere on [0, t]. Choose the norm of a vector  $x = (x_1, ..., x_n)$  to be  $|x| = \max_j |x_j|$ . For any given j, k, let  $f_t(s), f_{t,r}(s)$  be the n-vectors with all components zero except the kth which is  $f_t^{j,k}(s), f_{t,r}^{j,k}(s)$ , respectively. Then

$$\lim_{t\to\infty}\int_0^t X(t,s)f_{t,r}(s)\ ds = \int_0^t X(t,s)f_t(s)\ ds.$$

From the above definition of the norm of a vector and the fact that

$$\int_0^t X(t,s)f_{t,r}(s) ds | \leq K |f_{t,r}| \leq K_1, \qquad 0 \leq t < \infty,$$

it follows that

$$\int_0^t |x_{jk}(t,s)| \ ds \le \left| \int_0^t X(t,s) f_t(s) \ ds \right| \le K_1,$$

for all  $t \ge 0$  and j, k = 1, 2, ..., n. Since all norms in  $C^n$  are equivalent, this clearly implies there is a constant c such that  $\int_0^t |X(t, s)| ds < c$ ,  $0 \le t < \infty$ .

From Lemma 1.2, this relation implies  $X(s, \tau)$  is uniformly bounded by a constant N for  $0 \le \tau \le s < \infty$  and, thus, equation (1) is uniformly stable for  $t_0 \ge 0$ . Therefore,

$$\left| \int_{\tau}^{t} X(t, s) X(s, \tau) \, ds \right| \leq \int_{\tau}^{t} |X(t, s)| \cdot |X(s, \tau)| \, ds \leq Nc,$$

for all  $t \ge \tau$ . But the first expression in this inequality is equal to  $(t-\tau)|X(t,\tau)|$ . Therefore,  $|X(t,\tau)|$  approaches zero as  $t\to\infty$  uniformly and equation (1) is uniformly asymptotically stable.

Conversely, suppose system (1) is uniformly asymptotically stable for  $t_0 \ge 0$ . From Theorem III.2.1, there are positive constants K,  $\alpha$  such that

$$|X(t, \tau)| \le Ke^{-\alpha(t-\tau)}, \qquad 0 \le \tau \le t < \infty.$$

The general solution of (1.1) is

$$x(t) = X(t, 0)x(0) + \int_0^t X(t, s)f(s) ds, \qquad t \ge 0.$$

If f is in  $\mathscr{B}[0, \infty)$ , then  $|x(t)| \leq K|x(0)| + |f| \cdot (K/\alpha)$  for all  $t \geq 0$  and thus every solution of (1.1) is in  $\mathscr{B}[0, \infty)$ . This proves the theorem.

Theorem 1.2 is due to Perron [1] and was the first general statement dealing with the determination of the behavior of the solutions of a homogeneous equation by observing the behavior of the solutions of a nonhomogeneous

geneous equation for forcing functions in a certain given class of functions. Investigations along this line have continued to this day with the most significant recent contributions being made by Massera and Schaffer [1]. For a better appreciation of the problem, we rephrase it in another way. Let (9, 9) be two Banach spaces of functions mapping [a, co) into On where a may be finite or infinite. The pair (9, -9) is said to be admissible for equation (1.1) if for every f in .9, there is at least one solution x of (1.1) in a. Theorem 1.1 states that (M(-oo, co), M-co, oo)), (d9, sir)), (YT, 9T) are admissible for equation (1.1) if and only if equation (1) is noncritical with respect to l(-eo. OD), sad-0, YT, respectively. Theorem 1.2 shows that (-4[0, co), -4[0, oo)) is admissible-for (1.1) if equation (1) is uniformly asymptotically stable. The further investigation of such admissible pairs is extremely interesting and the reader is referred to Coppel [1, Chap. V], Hartman [1, Chap. 13] and Massera and Schaffer [1], Antosiewicz [2].

## IV.2. Weakly Nonlinear Equations-Noncritical Case

Throughout this section, it will be assumed that A is a continuous n x n matrix in 9T, S2(p, a) ={x in On, s in Cr: jxj < p, jsi <\_ a}, 7)(p, a), M(a), p >\_ 0, a >\_ 0, are continuous functions which are nondecreasing in both variables, 71(0, 0) = 0, M(0) = 0, and 2'i fi(ij, M) = {q: R X S2(po, so) -\* On: q continuous, jq(t, 0, s)l < M(I el ), jq(t, x, e) - q(t, y, e)l <\_ ,i(p, a)l x - yl, for all (t, x, e), (t, y, e) in R X SZ(p, u), 0 < p < pc, 0 < a < ec and q(t, x, e) is continuous in x,e uniformly for t in R}.

If q is in'ifi(7], M), then automatically x, e) is in . (-co, oo). In factjq(t, x, a)l < al(p, a) jxj + M(1sl) for (t, x, a) in B x S2(p, a). A function q will be said to be in sd9i fl9'il?(?), M) if q is in2i fi(,j,M) and, for each fixed a, q(t,x,8) is almost periodic in t uniformly with respect to x for x in compact sets. A function q will be said to be in 1T n 2'i/l(71, M) if q is in 2i/a(71, M) and q(t + T, x, a) = q(t, x, a) for all (t, x, a) in B x S2(po, so).

A function q will clearly be in 2'i h(rt, M) for some -q, M if q(t, x, a) -\*0 and eq(t, x, a)/&x-\*0 as x-\*0, a-\*0 uniformly in t.

In this section, results are given concerning the existence of bounded, almost periodic and periodic solutions of the nonlinear' equation

$$(2.1) \dot{x} = A(t)x + q(t, x, \varepsilon),$$

where q is in 2i/l(rl, M) and the homogeneous equation (1) is noncritical. More specifically, we prove

THEOREM 2.1. Suppose -9 is one of the classes \_4(- oo, oo), or .9T. If q is in -9 n 2ifi(q, M) and system (1) is noncritical with respect to -9, then there are constants pi > 0, 81 > 0 and a function x\*(t, a) continuous in t, a for -oo <t < oo, 0 < Iel < ei, x\*(t, 0) =0, x\*(-, s) in -9, lx\*(-, e)I < pi, 0 < Iel < e1, such that x\*(t, e) is a solution of (2.1) and is the only solution of (2.1) in -9 which has norm <pl. If - \_ jVY then m[x\*(., e)] - m[q, A], 0:5 1sl <ei.

PROOF. For a given pi, 0 < pl < po, let 9p, ={x in 9: IxI pi}. Then 9p, is a closed, bounded subset of the Banach space -9. For any x in 9p,, the function e) belongs to .9. Since system (1) is assumed to be noncritical with respect to -9, we may consider the transformation w =.Tx, x in -9, defined by

$$(2.2) w = \mathscr{T}x = \mathscr{K}q(\cdot, x(\cdot), \varepsilon),$$

where AA' is the operator uniquely defined by Theorem 1.1. From Theorem 1.1, 9-: 9p, -> -9. Furthermore, the fixed points of 9- in -9p, coincide with the solutions of (2.1) which are in -9p,. We now use the contraction principle to show that has a unique fixed point in -9p, for pi and Iki sufficiently small.

Since q is in M),

(2.3) 
$$|q(t, x, \varepsilon)| \leq |q(t, x, \varepsilon) - q(t, 0, \varepsilon)| + |q(t, 0, \varepsilon)| \\ \leq \eta(\rho_1, \varepsilon_1) |x| + M(\varepsilon_1),$$

for (t, x, s) in R x S2(pi, ei). Let K be the constant defined in (1.8) and choose pi < po, ei <so positive and so small that

$$K[\eta(\rho_1,\,\varepsilon_1)\rho_1+M(\varepsilon_1)]<
ho_1.$$

For this choice of pi, ei, it follows from relations (1.8), (2.2), (2.3) and the fact that q is in Yi h(q, M) that

$$egin{aligned} |\mathscr{T}x| & \leq K \left| q(\cdot,\,x(\cdot),\,arepsilon) 
ight| \leq K [\eta(
ho_1,\,arepsilon_1) \left| x 
ight| + M(arepsilon_1) 
ight| \ & < 
ho_1, \ & & & & & & & & & & & & & & & & & &$$

for all x, y in -9p,, 0 < Ici < si and 0 < 1 is a positive constant. Therefore, J is a uniform contraction on 9p, for I eI \_< ei and has a unique fixed point x\*(t,e) in IfFIPl. Since q(t,x,e) is continuous in x,e uniformly in t, x\*(t,e) is continuous in t,81 - oo < t < oo, 0 < 181 < si. For e = 0, x = 0 is obviously a solution of (2.1) and, therefore, 0) = 0. To prove the last statement of the theorem, suppose a' \_ {an } is a sequence in (-cc, 00). Let M be a compact set containing {x\*(t, e), te(-oo, 00), I e < el }. Theorem 11 of the Appendix implies there is a subsequence a = {a, } of a such that {q(t + an, x,e)} converges uniformly for te(-oo,oo),xeMandeach fixed e. Since x\*(t, e) \_ .Vq(,x\*(,e),e)

and .\*'is continuous and linear on R(--, 00), this implies {x\*(t + a,,, e)} converges uniformly for tin (--, -) for each fixed e. The fact that

$$m[x^*(\cdot,\epsilon)] \subseteq m[q,A]$$

follows from Theorem 8 of the Appendix.

Theorem 2.1 has interesting implications for the equation

$$(2.4) \dot{x} = A(t)x + b(t) + \varepsilon h(t, x, \varepsilon),$$

where e is a scalar, h belongs to jZ99, s (ri, tlf), b is in kr and system (1) is noncritical with respect to \_4Vj. Of course, as before ' is one of the classes M(-oo, oo), sang or 9T. Under these hypotheses, Theorem 1.1 implies that the equation

$$\dot{x} = A(t)x + b(t),$$

has a unique solution .7E''b in .9. If I , 'bj < po and x = y + .fb in (2.4), then

$$\dot{y} = A(t)y + \varepsilon h(t, y + \mathscr{K}b, \, \varepsilon) \stackrel{\mathrm{def}}{=} A(t)y + q(t, y, \, \varepsilon).$$

The function q is in Yifi(q, M) with 9(p, a) =arjl(p, a), where qj(p, a) is a continuous function of p, a, since q(t, y, a) approaches zero as a -\* 0 at least as fast as a linear function in a. Therefore, Theorem 2.1 implies the existence of a solution x\*(t, e, b) of (2.4), s, b) in -9, 0, b) =. ''b and this is the only solution of (2.4) which is in 9 and at the same time in a pl-neighborhood of A b.

### IV.3. The General Saddle Point Property

Theorem 2.1 of the previous section asserts the existence of a distinguished solution a) of (2.1) in a class 9 of functions. What are the stability properties of the solution e)? If the real parts of the characteristic exponents of the linear system (1) have nonzero real parts, one would expect the stability properties of a) to be the same as those of the solution x = 0 of (1). The purpose of this section is to prove this is actually the case and also to discuss some of the geometrical properties of the solutions of (2.1) near x\*(., s) in the same manner as the saddle point property was treated in Section 111.6. The proofs will follow the ones in Section 111.6. very closely but are slightly more complicated due to the fact that the differential equations depend explicitly upon t.

To reduce the equations to a simpler form, let

$$(3.1) x = x^*(\cdot, \varepsilon) + y,$$

where a) is the function given in Theorem 2.1. If x is a solution of

equation (2.1), then y is a solution of

$$\dot{y} = A(t)y + p(t, y, \varepsilon),$$

where p(t, y, E) = q(t, x\*(t, s) + y, E) - q(t, x\*(t, s), E). Consequently, if q is in 2ili(n, M), then p is in .'i 0). To simplify the equations even further let X(t) = P (t)eBt, P(t + T) = P(t), B a constant matrix, be a fundamental matrix solution of (1) and let y = P(t)z. If y is a solution of (3.2), then z is a solution of

$$\dot{z} = Bz + f(t, z, \varepsilon),$$

where f (t, z, s) = P-1(t)p(t, P(t)z, E).,Finally, we can assert that if -9 is one of the classes - 4 ( - oo, oo), s49 or 00T, and q is in -9 n Ti1i(q, M), then f is in -9 n 2'i/i(7), 0). Any assertions made about system (3.3) yield implications for system (2.1) which are easily traced through the above transformations.

The remainder of the discussion centers around (3.3) under the hypothesis that f is in 2'i il(q, 0) and the eigenvalues of the matrix B have nonzero real parts, k with positive real parts and n - k with negative real parts. As in Sect on 111.6, the space Cn can be decomposed as

$$C^n = C^n_+ \oplus C^n_- \,,$$
  $C^n_+ = \pi_+ C^n, \, C^n_- = \pi_- C^n,$ 

where 'r+ , 7r\_ are projection operators, C+ , Cn have dimensions k, n - k, respectively, are invariant under B and there are positive constants K, a such that

(3.5) (a) 
$$|e^{Bt}\pi_{+}z| \le Ke^{\alpha t} |\pi_{+}z|, \quad t \le 0,$$
  
(b)  $|e^{Bt}\pi_{-}z| \le Ke^{-\alpha t} |\pi_{-}z|, \quad t \ge 0.$ 

For any a in (-oc, oo), let z(t, a, za, s) designate the solution of (3.3) satisfying z(a, a, za, s) = za, let K designate the constant in (3.5) and, for any 5 > 0, define

$$(3.6) (a) S(\sigma, \delta, \varepsilon) = \left\{ z^{\sigma} \text{ in } C^{n} \colon |\pi_{-}z^{\sigma}| < \frac{\delta}{2K}, |z(t, \sigma, z^{\sigma}, \varepsilon)| < \delta, t \geq \sigma \right\},$$

$$(\mathrm{b})\quad U(\sigma,\,\delta,\,\varepsilon) = \Bigl\{z^\sigma \text{ in } C^n \colon \bigl|\pi_+ z^\sigma\bigr| < \frac{\delta}{2K}, \, \bigl|z(t,\,\sigma,\,z^\sigma,\,\varepsilon)\bigr| \, < \, \delta, \, t \leqq \sigma\Bigr\}.$$

Also, let BP designate {z in Cn: Izl < p}.

THEOREM 3.1. If f is in 2i/(, 0) and the eigenvalues of B have nonzero real parts, then there are 5 > 0, el > 0, S > 0 such that for any a in (-oo, oo), 0<\_ IEI < el, the mapping Tr- is a homeomorphism of S(a, 8, onto (a\_Cn) n B61 2%, S(a, 5, 0) is tangent to 7r\_Cn at zero and

$$|z(t$$

for any zo in S(a, 8, E). The mapping ir+ is a homeomorphism of U(a, 8, E) onto (rr+Cn) n BN, , U(a, 8, 0) is tangent to 7r+Cn at zero and

$$|z(t, \sigma, z^{\sigma}, \varepsilon)| \leq 2K |\pi_{+}z^{\sigma}| e^{\beta(t-\sigma)}, \qquad t \leq \sigma,$$

for any za in U(a, 8, s).

Furthermore, if a, s): (rr\_Cn) n Ba12K --S(a, e) is the inverse of the homeomorphism IT-, then g(z\_, a, E) is lipschitzian in z\_ with lipschitz constant 2K. If f is in dY n Yile(rl, 0), then g(z\_, a, E) is almost periodic in a with module contained in m[f ]. If f is in YT n 2i fi(ri, 0), then g(z\_, or, E) is periodic in a of period T. The same conclusions hold for the inverse of the homeomorphism ?r+ of U(a, 8, E) onto (7r+Cn) n Ba12K .

Before proving this theorem, let us make some remarks about its geometric meaning and some of its implications. The accompanying Fig. 3.1

![](_page_167_Picture_7.jpeg)

Figure IV.3.1

may be useful in visualizing the following remarks. For any a e (- co, oo), the set {a} x S(a, 8, s) is a subset of Rn+i. For any Tin [a; t], z(t, a, za, E) \_ z(t, T, z(T,a, za, E), s), and, therefore, any solution of (3.3) with initial value in {a} x S(a, 8, E) must cross {T} x S(r, 8, E) for any T > 0 for which 7r- z(7-, a, za, e) has norm less than 8/2K. Since this may not occur for all r >- a, the set consisting of the union of the {a} x S(a, 8, e) for all Cr in (-c0, co) may not be an integral manifold in the sense that the trajectory of any solution with initial value (-r, zT) on the manifold remains on the manifold for all t > r. On the other hand, this set can be extended to an integral

manifold by extending the set {a} X S(a, 8, e) to a set {a} X S\*(a, 8, e) where S\*(a, 8, e) =S(a, \$, e) u {z: z =z(a, r, zT, e), (T, zT) in {T} x S(T, 8, e) for some T \_<a}. The set S(8, e) consisting of the union of the {a} X S\*(a, 8, e) is then an integral manifold of (3.3) and is rightfully termed a stable integral manifold since all solutions on this manifold approach zero as t -> oo and these are the only solutions which lie in a certain neighborhood of zero for increasing, time. In the same way one defines the corresponding sets U\*(a, 5, e) = U{6, 5", e) U {z: z = z(a, r, zT, s), (T, zT) it ?'U(7-, 5, e) for some T >\_ a} and an unstable integral manifold U(5, e). The sets S(5, e) and U(5, e) are hypersurfaces homeomorphic to R X B'-k and R X .Bi, respectively, and S(5, e) n U(5, e) is the t-axis.

If k >\_ 1 the above remarks imply the solution z = 0 of (3.3) is unstable for IsI < el and any a in (-co, oo). From (3.7), if k =0, the solution z =0 of (3.3) is uniformly asymptotically stable for IeI < sl and to >\_ a for any a in (-oo, oo).

If B and f are real in (3.3), then the sets S(a, 5, e), U(a, 6, e) defined by taking only real initial values are in Rn. If system (3.2) is real, then the decomposition X(t) = P(t)eBt of a fundamental matrix solution of (1) may not have P(t), B real if it is required that P(t + T) = P(t) for all T (see Section 111.7). On the other hand, this decomposition can be chosen to be real if it is only required that P(t + 2T) = P(t) for all t. In such a case, system (3.3) will be real, butt f belongs to Y2T r i1i(rl, 0) if p is in 9T n 0). This implies that the sets S(a, 6, e), U(a, 5, e) will be periodic in a of period 2T rather than T.

It is not asserted in the statement of the theorem that S(a, 5, e) is tangent to 7r-Cu at zero. This may not be true since f (t, y, e) could contain a term which is linear in y and yet approaches zero when e 0. Theorem 3.1 is clearly a strong generalization of Theorem 111.6.1 due to the fact that the perturbation term f (t, z, e) may depend explicitly upon t.

PROOF OF THEOREM 3.1. Since this proof is so similar to the proof of Theorem 111.6.1, it is not necessary to give the details but only indicate the differences. In the same way as in the proof of Lemma 6.1, one easily shows that, for any solution z(t) of (3.3) which is bounded on [a, oo), there must exist a z\_ in C'z such that

$$(3.9) z(t) = e^{B(t-\sigma)}z_{-} + \int_{\sigma}^{t} e^{B(t-s)}\pi_{-} f(s, z(s), \varepsilon) ds$$

$$+ \int_{\sigma}^{0} e^{-Bs}\pi_{+} f(t+s, z(t+s), \varepsilon) ds, t \ge \sigma,$$

and for any solution z(t) of (3.3) `which is bounded on (-oo, a], there is a z+ in C+ such that z(t) satisfies the relation

$$(3.10) z(t) = e^{B(t-\sigma)}z_{+} + \int_{\sigma}^{t} e^{B(t-s)}\pi_{+} f(s, z(s), \varepsilon) ds$$
$$+ \int_{-\infty}^{0} e^{-Bs}\pi_{-} f(t+s, z(t+s), \varepsilon) ds, t \leq \sigma.$$

We first discuss the existence of solutions of (3.9) on  $[\sigma, \infty)$  for any  $z_-$  in  $\pi_-C^n$ . There is a constant  $K_1$  such that  $|\pi_+z| \leq K_1|z|$ ,  $|\pi_-z| \leq K_1|z|$  for any z in  $C^n$ . If K,  $\alpha$  are the constants given in (3.5), and  $\eta$  is the lipschitz constant of  $f(t, z, \varepsilon)$  with respect to z, choose  $\delta$ ,  $\varepsilon_1$ , so that

$$(3.11) 4KK_1\eta(\delta, \varepsilon_1) \leq \alpha, 8K^2K_1\eta(\delta, \varepsilon_1) < 3\alpha.$$

With this choice of  $\delta$ ,  $\varepsilon_1$  and for any  $z_-$  in  $\pi_-C^n$  with  $|z_-| \leq \delta/2K$ , define  $\mathscr{G}(\sigma, z_-, \delta)$  as the set of continuous functions  $z: [\sigma, \infty) \to C^n$  such that  $|z| = \sup_{\sigma \leq t} |z(t)| \leq \delta$  and  $\pi_-z(\sigma) = z_-$ .  $\mathscr{G}(\sigma, z_-, \delta)$  is a closed bounded subset of the Banach space of all bounded continuous functions taking  $[\sigma, \infty)$  into  $C^n$  with the uniform topology. For any z in  $\mathscr{G}(\sigma, z_-, \delta)$  define  $\mathscr{T}z$  by

(3.12) 
$$(\mathcal{F}z)(t) = e^{B(t-\sigma)}z_{-} + \int_{\sigma}^{t} e^{B(t-s)}\pi_{-} f(s, z(s), \varepsilon) ds$$
 
$$+ \int_{\infty}^{0} e^{-Bs}\pi_{+} f(t+s, z(t+s), \varepsilon) ds, \qquad t \ge \sigma.$$

Exactly as in the proof of Theorem III.6.1, one uses the contraction principle to show that  $\mathcal{F}$  has a unique fixed point  $z^*(\cdot, \sigma, z_-, \varepsilon)$  for  $|\varepsilon| \leq \varepsilon_1$ ,  $z^*(\cdot, \sigma, 0, \varepsilon) = 0$ ,  $z^*(t, \sigma, z_-, \varepsilon)$  depends continuously upon  $t, \sigma, z_-, \varepsilon$  and

$$(3.13) \quad |z^*(t,\,\sigma,\,z_-,\,\varepsilon)-z^*(t,\,\sigma,\,\tilde{z}_-,\,\varepsilon)| \leq 2K \left[\exp\frac{-\alpha(t-\sigma)}{2}\right]|z_--\tilde{z}_-|$$

for  $t \geq \sigma$ .

From the definition of  $S(\sigma, \delta, \varepsilon)$  and the above construction of  $z^*(\cdot, \sigma, z_-, \varepsilon)$ , it follows that

$$(3.14) S(\sigma, \delta, \varepsilon) = \{z: z = z^*(\sigma, \sigma, z_-, \varepsilon), z_- \text{ in } (\pi_- C^n) \cap B_{\delta/2k}\}$$

for  $|\varepsilon| \le \varepsilon_1$ . Relation (3.14), (3.13) and the fact that  $z^*(\cdot, \sigma, 0, \varepsilon) = 0$  implies relation (3.7) with  $\beta = \alpha/2$ . If we let  $g(z_-, \sigma, \varepsilon) = z^*(\sigma, \sigma, z_-, \varepsilon)$ , then

$$(3.15) g(z_{-}, \sigma, \varepsilon) = z_{-} + \int_{\infty}^{0} e^{-Bs} \pi_{+} f(\sigma + s, z^{*}(\sigma + s, \sigma, z_{-}, \varepsilon), \varepsilon) ds.$$

As in the proof of Theorem III.6.1,

$$|g(z_{-}, \sigma, \varepsilon)| - g(\tilde{z}_{-}, \sigma, \varepsilon)| \ge \frac{|z_{-} - \tilde{z}_{-}|}{2}$$

for any  $\sigma$  in  $(-\infty, \infty)$  and  $|\varepsilon| \leq \varepsilon_1$ . This shows that  $g(\cdot, \sigma, \varepsilon)$  is a one-to-one map of  $(\pi_-C^n) \cap B_{\delta/2K}$  into  $S(\sigma, \delta, \varepsilon)$ . Since the inverse of this map is  $\pi_-$  and therefore is continuous, it follows that it is a homeomorphism. The following estimate is also easy to obtain:

$$\left|\pi_{+}z^{*}(\sigma,\,\sigma,\,z_{-}\,,\,\varepsilon)\right|\leqq\frac{4K^{2}K_{1}}{\alpha}\,\eta(2K\left|z_{-}\right|,\,\left|\varepsilon\right|)\left|z_{-}\right|.$$

Since  $\pi_{-}z^{*}(\sigma, \sigma, z_{-}, \varepsilon) = z_{-}$ , it follows from the properties of  $\eta$  that  $S(\sigma, \delta, 0)$  is tangent to  $\pi_{-}C^{n}$  at zero. Relation (3.13) implies that the set  $S(\sigma, \delta, 0)$  is a lipschitzian manifold.

Now suppose f is in  $\mathscr{AP} \cap \mathscr{Lip}(\eta, 0)$ . We now prove the representation  $g(z_-, \sigma, \varepsilon)$  of  $S(\sigma, \delta \varepsilon)$  is almost periodic in  $\sigma$  with module contained in m[f]. From (3.15), it will be necessary to estimate  $z^*(\sigma + s, \sigma, z_-, \varepsilon)$  as a function of  $\sigma$  and s. To simply the notation, let  $z(t, \sigma) = z^*(t, \sigma, z_-, \varepsilon)$ ,  $f(t, z) = f(t, z, \varepsilon)$ . The equation for  $z(\sigma + t, \sigma)$  becomes

(3.16) 
$$z(\sigma + t, \sigma) = e^{Bt}z_{-} + \int_{0}^{t} e^{B(t-s)}\pi_{-} f(\sigma + s, z(\sigma + s, \sigma)) ds$$
$$+ \int_{0}^{0} e^{-Bs}\pi_{+} f(\sigma + t + s, z(\sigma + t + s, \sigma)) ds.$$

The objective is to show that  $z(\sigma+t, \sigma)$  is almost periodic in  $\sigma$  if f is in  $\mathscr{AP} \cap \mathscr{Lip}(\eta, 0)$ . Suppose  $\alpha' = \{\alpha'_n\}$  is a sequence in  $(-\infty, \infty)$ . There is a subsequence  $\alpha = \{\alpha_n\}$  of  $\alpha'$  such that  $\{f(t + \alpha_n, z)\}$  converges uniformly for  $t \in (-\infty, \infty), |z| \leq \delta$ . For any n, m, let

$$\gamma_{n,m} = \sup_{-\infty < s < \infty, |z| \le \delta} |f(s + \alpha_n, z) - f(s + \alpha_m, z)|$$

$$u_{n,m}(t, \sigma) = |z(\sigma + t + \alpha_n, \sigma + \alpha_n) - z(\sigma + t + \alpha_m, \sigma + \alpha_m)|$$

Then (3.16) implies that

$$\begin{split} u_{n,m}(t,\sigma) & \leq KK_1 \int_0^t e^{-\alpha(t-s)} \eta(\delta,\epsilon_1) u_{n,m}(s,\sigma) \\ & + KK_1 \int_0^\infty e^{-\alpha s} \eta(\delta,\epsilon_1) u_{n,m}(t+s,\sigma) + \frac{2KK_1}{\alpha} \gamma_m \;, \end{split}$$

Using the inequalities (3.11), one easily observes that  $u_{n,m}(t,\sigma) \leq 4KK_1\gamma_m/\alpha$  for all m. Since  $\gamma_m \to 0$  as  $m \to \infty$ , it follows that  $u_{n,m}(t,\sigma) \to 0$  as  $m \to \infty$  and, therefore,  $z(\sigma + t, \sigma)$  is almost periodic in  $\sigma$  with module contained in the module of f. In particular,  $g(z_-, \sigma, \epsilon) = z^*(\sigma, \sigma, z_-, \epsilon)$  is almost periodic with module contained in m[f].

If f is in  $\mathscr{P}_T \cap \mathscr{L}_{\ell} \not p(\eta, 0)$ , then  $g(z_-, \sigma + T, \varepsilon) = g(z_-, \sigma, \varepsilon)$  for all  $\sigma$ , since one sees directly from the uniqueness of the solution of (3.16) that  $z(\sigma + t + T, \sigma + T) = z(\sigma + t, \sigma)$  for all  $\sigma$ , t.

In the same manner as above, one uses (3.10) to prove the assertions on U(a, S, e) to complete the proof of the theorem.

A simple example illustrating the above results is the forced van der Pol equation

$$\dot{x}_1 = x_2\,, \ \dot{x}_2 = -x_1 + k(1-x_1^2)x_2 + \varepsilon g(t),$$

'where k 0 0, e are real parameters and g is in dg. If x = (xl, x2), this system is of the form (2.1) with

$$A = \begin{bmatrix} 0 & 1 \\ -1 & k \end{bmatrix}, \qquad q(t, x, \, arepsilon) = \begin{bmatrix} 0 \\ -kx_1^2x_2 + arepsilon g(t) \end{bmatrix}.$$

Since k ; 0, the eigenvalues of A have nonzero real parts and q is in V9 n with j(p) = Kp2 for some constant K and M = e sups jg(t)j. Therefore, Theorem 2.1 implies there are pi > 0, ei > 0 such that system (3.17) has an almost periodic solution x\*(t, e) with m[x\*(., e)] a m[g], 0) = 0 and this solution is unique in the pi-neighborhood of xl = x2 = 0. Since the eigenvalues of A have negative real parts if k < 0 and positive real parts if k > 0, Theorem 3.1 asserts that the solution x\*(t, e) is asymptotically stable if k < 0 and unstable if k > 0.

For e = 0, we have seen in Theorem H. 1.6 that the van der Pol has a unique asymptotically orbitally stable limit cycle for any k > 0. This implies geometrically that the cylinder generated by the limit cycle in (xl, X2, t) space is asymptotically stable. Therefore it is intuitively clear (and could be made very precise). that for s small there must be a neighborhood of this cylinder in which solutions of (3.17) enter and never leave. This " stable " neighborhood. is certainly more interesting than the almost periodic e) determined above since e) is unstable for k > 0. A discussion of what happens in this neighborhood is much more difficult than the above analysis for almost periodic solutions and will be treated in Chapter VII.

## IV.4. More General Systems

The first interesting modifications of the results of the previous sections are obtained by considering the parameter a as appearing in the system in a different manner than in (3.1).

Consider the system

$$\varepsilon \dot{x} = A(t)x,$$

where e > 0 is a real parameter and A belongs to 9T . In general, it is almost impossible to determine necessary and sufficient conditions on the matrix A

which insure that system (4.1) is noncritical with respect to one of the classes - 4 ( - oo, oo), s.19 or 9DT for all e in some interval 0 < s < so. On the other hand, if A is a constant matrix, the following result is true.

LEMMA 4.1. If A is a constant matrix and so > 0 is given, then system (4.1) is noncritical with respect to R(- oo, oo) (or .49) (or .#T) for 0 < e <\_ so if and only if the eigenvalues of A have nonzero real parts.

PROOF. The assertions concerning R(- oo, oo) or s19 are obvious from Lemma 1 since the eigenvalues of Ale are 1/e times the eigenvalues of A. Also, from Lemma 1, (4.1) is noncritical with respect to 9PT if and only if det[I - exp(A/e)T] 0 0; that is, if and only if AT/e 0 2k7ri, k =±1, ±2, .. . for all eigenvalues A of A. If Re A zA 0 for all A, this relation is satisfied. If there is a A = iw, w real, then these relations become e 0 wT/2kir, k =0, +1, .... It is clear these relations cannot be satisfied for all e in an interval (0, so]. This completes the proof of the lemma.

LEMMA 4.2. If A is a constant matrix, -9 is one of the classes g(- oo, oo), sd.9 or YT, and system (4.1) is noncritical. with respect to 9 for 0 < e < eo , then the system

(4.2) 
$$\varepsilon \dot{x} = Ax + f(t), \quad f \text{ in } \mathcal{D},$$

has a unique solution ir f in !2, 0 < e \_< so, ', :.9 -\*-9 is a continuous linear map and there is a K > 0 (independent of e) such that Ii(e f I <\_ K If I for 0<s<so.

PROOF. The hypothesis and Lemma 4.1' imply the eigenvalues of A have nonzero real parts. If t = er, y(T) = x(c r), g(-r) =f (cr), and x is a solution of (4.2)1\* then

$$rac{dy}{d au} = Ay + g( au),$$

where g e 9(- oo, oo). Theorem 1.1 implies the existence of a unique V'g e 9(-oo, oo) satisfying this equation, with 1,1'gl < .x'' IgI. Since IgI = If I , it follows that A'E fdeei(g satisfies the properties of the lemma.

EXERCISE 4.1. Discuss the manner in which the solutions of (4.2) approach the solution of the equation Ax + f (t) = 0 as e -\* 0 under the hypothesis that the eigenvalues of A have negative real parts (positive real parts). What happens if A has eigenvalues of both positive and negative real parts?

Lemma 4.2 and the same proofs as used in Theorems 2.1 and 3.1 yield an immediate extension of those results to the system

$$\varepsilon \dot{x} = Ax + f(t, x, \varepsilon),$$

where f satisfies the same conditions as stated in those theorems.

This result is stated in detail for further reference. Suppose the eigenvalues of A have nonzero real parts, let 7r+, Tr\_ be the projection operators taking Cn onto the invariant subspaces of A corresponding to the eigenvalues with positive, negative real parts, respectively, and let K, « be positive constants so that

(4.4) 
$$|e^{At}\pi_{-}x| \leq Ke^{-\alpha t}, \qquad t \geq 0,$$

$$|e^{At}\pi_{+}x| \leq Ke^{\alpha t}, \qquad t \leq 0.$$

For any a. in (-oo, oo), let x(t, a, xa, E) designate the solution of (4.3) satisfying x(a, a, xa, e) = xa and, for any S > 0 and any function VR --)- Cn, let

$$(4.5) \quad \text{(a)} \quad S(\phi, \, \sigma, \, \delta, \, \varepsilon) = \left\{ x = x^{\sigma} - \phi(\sigma) \text{ in } C^{n} \colon |\pi_{-}[x^{\sigma} - \phi(\sigma)]| < \frac{\delta}{2K} \right.$$

$$\left. |x(t, \, \sigma, \, x^{\sigma}, \, \varepsilon) - \phi(t)| < \delta, \qquad t \ge \sigma \right\},$$

$$(b) \quad U(\phi, \, \sigma, \, \delta, \, \varepsilon) = \left\{ x = x^{\sigma} - \phi(\sigma) \text{ in } C^{n} \colon |\pi_{+}[x^{\sigma} - \phi(\sigma)]| < \frac{\delta}{2K} \right.$$

$$\left. |x(t, \, \sigma, \, x^{\sigma}, \, \varepsilon) - \phi(t)| < \delta, \qquad t \le \sigma \right\},$$

In words, the set S(0, a, S, E) is the set of initial values at Cr of those solutions of (4.3) which have their ,r\_ projections in a 8/2K neighborhood of ir\_ 0(a) and remain in a 8-neighborhood of the curve qi(t) for all t >\_ a. A similar statement concerns U(4, a, 8, e) for ir+ and t <\_ a. If BP designates the set {x in Cn: ixi < p}, then the following proposition holds.

THEOREM 4.1. Suppose .9 is one of the classes 9 ( - oo, oo), d or YT. If f is in -9 n M) and the eigenvalues of A have nonzero real parts, then there are 8 > 0, el > 0, P > 0 and. function x\*(t, E) continuous in t, s for . -oo <t < oo, 0 < e < eI, x\*(t, 0) = 0, x\*( , e) in -9, Ix\*(-, E)I < 8, 0 < e <\_ El, such that x\*(t, e) is a solution of (4.3) and is the only solution of (4.3) in .9 which has norm < S. If -9 = sdY, then e)] e m[f ], 0<s :!9 El.

Furthermore, the mapping ar- is a homeomorphism of e), a, 8, E) onto (nr\_Cn) n B812A and

(4.6) 
$$|x(t, \sigma, x^{\sigma}, \varepsilon) - x^{*}(y, \varepsilon)| \leq 2K |\pi_{-}[x^{\sigma} - x^{*}(\sigma, \varepsilon)]| e^{-\varepsilon^{-1}\beta(t-\sigma)}, \quad t \geq \sigma,$$
 for any  $x^{\sigma} - x^{*}(\sigma, \varepsilon)$  in  $S(x^{*}(\cdot, \varepsilon), \sigma, \delta, \varepsilon), \quad 0 < \varepsilon \leq \varepsilon_{1}$ . The mapping  $\pi_{+}$  is a homeomorphism of  $U(x^{*}(\cdot, \varepsilon), \sigma, \delta, \varepsilon)$  onto  $(\pi_{+}C^{n}) \cap B_{\delta/2K}^{n}$ ,

$$\begin{aligned} (4.7) \quad & \left| x(t,\,\sigma,\,x^\sigma,\,\varepsilon) - x^*(t,\,\varepsilon) \right| \leq 2K \left| \pi_+[x^\sigma - x^*(\sigma,\,\varepsilon)] \right| e^{\epsilon^{-1}\beta\,(t-\sigma)}, \qquad t \leq \sigma, \\ \text{for any } x^\sigma - x^*(\sigma,\,\varepsilon) \text{ in } U(x^*(\cdot,\,\varepsilon),\,\sigma,\,\delta,\,\varepsilon), \ 0 < \varepsilon \leq \varepsilon_1. \end{aligned}$$

The dependence of the stable and unstable manifolds of  $u^*(\cdot, \varepsilon)$  upon  $\sigma$  is exactly the same as in the statement of Theorem 3.1.

The only part of the proof of the above theorem which is not exactly the same as the proofs of Theorem 2.1 and 3.1 is the fact that the statements are asserted to be true on the closed interval  $0 \le \varepsilon \le \varepsilon_1$  rather than the interval  $0 < \varepsilon \le \varepsilon_1$ . The proof for the interval  $0 < \varepsilon \le \varepsilon_1$  is the same as before and from the proof itself one observes that  $x^*(\cdot, \varepsilon) \to 0$  as  $\varepsilon \to 0$ . If one defines  $x^*(\cdot, 0) = 0$ , it will obviously be a continuous function on  $0 \le \varepsilon \le \varepsilon_1$ .

Lemma 4.3. If A is constant matrix and  $\varepsilon_0 > 0$  is given, then the system

$$\dot{x} = \varepsilon A x,$$

is noncritical with respect to  $\mathscr{B}(-\infty, \infty)$  or  $\mathscr{AP}$  for  $0 < \varepsilon \le \varepsilon_0$  if and only if the eigenvalues of A have nonzero real parts. There is an  $\varepsilon_0 > 0$  such that system (4.8) is noncritical with respect to  $\mathscr{P}_T$  for  $0 < \varepsilon \le \varepsilon_0$  if and only if det  $A \ne 0$ .

PROOF. The first part is a restatement of Lemma 1. Also, Lemma 1 implies (4.8) is noncritical with respect to  $\mathscr{P}_T$  if and only if  $\varepsilon\omega T \neq 2k\pi$  for all  $k=0,\pm 1,\ldots$  and all real  $\omega$  such that  $\lambda=i\omega$  is an eigenvalue of A. If  $\omega=0$  is not an eigenvalue of A, there is always an  $\varepsilon_0>0$  such that these inequalities are satisfied for  $0<\varepsilon\le\varepsilon_0$ . If  $\omega=0$  is an eigenvalue, there is never such an  $\varepsilon_0$  and the lemma is proved.

EXERCISE 4.2. For what values of  $\varepsilon$  in  $[0, \infty)$  is system (4.8) non-critical with respect to  $\mathscr{P}_T$ ? For what complex values of  $\varepsilon$  is system (4.8) noncritical with respect to  $\mathscr{P}_T$ ?

Lemma 4.4. If A is a constant matrix,  $\mathcal D$  is one of the classes  $\mathscr B(-\infty,\infty)$ ,  $\mathscr A\mathscr P$  or  $\mathscr P_T$ , and system (4.8) is noncritical with respect to  $\mathscr D$  for  $0<\varepsilon\le\varepsilon_0$ , then the system

(4.9) 
$$\dot{x} = \varepsilon (Ax + f(t)), \quad f \text{ in } \mathcal{D},$$

has a unique solution  $\mathscr{K}_{\varepsilon}f$  in  $\mathscr{D}$ ,  $0<\varepsilon\leq\varepsilon_0$ ,  $\mathscr{K}_{\varepsilon}:\mathscr{D}\to\mathscr{D}$  is a continuous linear map and there is a K>0 (independent of  $\varepsilon$ ) such that  $|\mathscr{K}_{\varepsilon}f|\leq K|f|$  for  $0<\varepsilon\leq\varepsilon_0$ .

If, in addition, f is in  $\mathscr{AP}$  (or  $\mathscr{P}_T$ ) and  $\int_0^t f$  is in  $\mathscr{AP}$  (or  $\mathscr{P}_T$ ) then  $|\mathscr{K}_{\varepsilon} f| \to 0$  as  $\varepsilon \to 0$ .

PROOF. Since (4.8) is assumed to be noncritical with respect to  $\mathscr{D}$ , Theorem 1.1 implies the existence of the continuous linear operators  $\mathscr{K}_{\varepsilon}$ ,  $0 < \varepsilon \le \varepsilon_0$ . The existence of a K as specified in the lemma for the case when  $\mathscr{D}$  is  $\mathscr{B}(-\infty, \infty)$  or  $\mathscr{A}\mathscr{P}$  is verified exactly as in the proof of Lemma 4.2. If

-9 = YT, then formula (1.9) yields .71''E for the special case (4.9) as

$$(4.10) (\mathscr{K}_{\varepsilon}f)(t) = \int_0^T \varepsilon [e^{-\varepsilon AT} - I]^{-1} e^{-\varepsilon As} f(t+s) ds, 0 < \varepsilon \le \varepsilon_0.$$

Since [e-EAT - I]-l is a continuous function of e on 0 < e <\_ so, 1'E f is continuous for 0 < e < so. We now show that Y, f defined by (4.10) has a limit as s -\* 0. Since system (4.8) is noncritical with respect to YT, Lemma 4.3 implies A is nonsingular. Also, lim8,o+ e[e-EAT -I]-l = -(AT)-l. This shows Y,, has a uniform bound on (0, so] and completes the first part of the lemma.

To prove the last part of the lemma, let x = y + e f'f and y will satisfy the equation

$$\dot{y} = A \varepsilon \Big( y + \varepsilon \int^t f \Big).$$

An application of the first part of the lemma to this equation shows that the unique solution of s19 (or GT) approaches zero as a --\* 0 and the lemma is proved.

The condition that f <sup>c</sup>f be in d for f in d1 is equivalent to saying that the integral of f is bounded and in particular, implies

(4.11) 
$$M[f] \stackrel{\text{def}}{=} \lim_{t \to \infty} \frac{1}{t} \int_0^t f(s) \, ds = 0.$$

In Chapter V, we show that (4.11) is sufficient to draw the same conclusion as in the last part of Lemma 4.4.

EXERCISE 4.3. Discuss the manner in which the solutions of (4.9) approach the solutions of the equation x = 0. Can you give any reason in the almost periodic or periodic case besides the one discussed in Lemma 4.4 for why all solutions approach the zero solution of x = 0 if f<sup>t</sup>f is bounded ?

Lemma 4.4 and the same proofs as used in Theorems 2.1 and 3.1 yield an immediate extension of those results to the system

(4.12) 
$$\dot{x} = \varepsilon (Ax + f(t, x, \varepsilon)),$$

where f satisfies the same conditions 4s stated in those theorems.

This result is the basis for the method of averaging given in the next chapter and is therefore stated in detail ,for further reference. The operators 7r+, ,r\_, constants K, a and sets S(0, a, 8, e), U(O, a, 8, e) are assumed to be the same as the ones given in (4.4) and (4.5).

THEOREM 4.2. Suppose 0 is one of the classes 9(-oo, oo), slY or YT and system (4.8) is noncritical with respect to -9 for 0 < e <\_ so. If f is in

 $\mathcal{D} \cap \mathcal{L}i_{p}(\eta, M)$ , then there are  $\delta > 0$ ,  $\varepsilon_{1} > 0$ ,  $\beta > 0$  and a function  $x^{*}(t, \varepsilon)$  continuous in t,  $\varepsilon$  for  $-\infty < t < \infty$ ,  $0 \le \varepsilon \le \varepsilon_{1}$ ,  $x^{*}(t, 0) = 0$ ,  $x^{*}(\cdot, \varepsilon)$  in  $\mathcal{D}$ ,  $|x^{*}(\cdot, \varepsilon)| < \delta$ ,  $0 \le \varepsilon \le \varepsilon_{1}$ , such that  $x^{*}(t, \varepsilon)$  is a solution of (4.12) and is the only solution of (4.12) in  $\mathcal{D}$  with norm  $< \delta$ . If  $\mathcal{D} = \mathcal{AP}$ , then  $m[x^{*}(\cdot, \varepsilon)] \subset m[f], 0 \le \varepsilon \le \varepsilon_{1}$ .

Furthermore, if the eigenvalues of A have nonzero real parts, then the mapping  $\pi_-$  is a homeomorphism of  $S(x^*(\cdot, \varepsilon), \sigma, \delta, \varepsilon)$  onto  $(\pi_-C^n) \cap B^n_{\delta/2K}$  and

$$(4.\dot{1}3) \quad |x(t,\sigma,x^{\sigma},\varepsilon)-x^{*}(t,\varepsilon)| \leq 2K |\pi_{-}[x^{\sigma}-x^{*}(\sigma,\varepsilon]| \, e^{-\epsilon\beta(t-\sigma)}, \qquad t \geq \sigma,$$

for all  $x^{\sigma} - x^*(\sigma, \varepsilon)$  in  $S(x^*(\cdot, \varepsilon), \sigma, \delta, \varepsilon)$ ,  $0 < \varepsilon \le \varepsilon_1$ . The mapping  $\pi_+$  is a homeomorphism of  $U(x^*(\cdot, \varepsilon), \sigma, \delta, \varepsilon)$  onto  $(\pi_+ C^n) \cap B^n_{\delta/2K}$  and

$$(4.14) \quad \left|x(t,\,\sigma,\,x^{\sigma},\,\varepsilon)-x^{*}(t,\,\varepsilon)\right|\leqq 2K\left|\pi_{+}[x^{\sigma}-x^{*}(\sigma,\,\varepsilon)]\right|e^{\epsilon\beta(t-\sigma)}, \qquad t\leqq\sigma,$$

for any  $x^{\sigma} - x^*(\sigma, \varepsilon)$  in  $U(x^*(\cdot, \varepsilon), \sigma, \delta, \varepsilon)$ ,  $0 < \varepsilon \le \varepsilon_1$ .

The dependence of the stable and unstable manifolds of  $x^*(\cdot, \varepsilon)$  upon  $\sigma$  is exactly the same as in the statement of Theorem 3.1.

Using the remark following Lemma 4.4, one easily sees that the conclusions of Theorem 4.2 remain valid in the periodic and almost periodic case for the system

$$\dot{x} = \varepsilon (Ax + h(t) + f(t, x, \varepsilon)),$$

provided that  $\int_{0}^{t} h$  is bounded. Extensions of Theorem 4.2 to the case where  $f = f(t, x, \epsilon, \mu)$  and the vector  $e' = (\epsilon, \mu)$  is small are also easily given.

EXERCISE 4.4. Consider the equation

(4.16) 
$$\dot{x} = Ax + h(\omega t) + f(\omega t, x, \varepsilon),$$

where  $\omega$  is a large parameter, the eigenvalues of A have negative real parts, h is in  $\mathscr{P}_T$ ,  $\int_0^T h(s) \, ds = 0$ , and f is in  $\mathscr{P}_T \cap \mathscr{Lip}(\eta, M)$ . Assuming Theorem 4.2 is valid when f depends upon more than one small parameter, prove there is an  $\omega_1 > 0$ ,  $\varepsilon_1 > 0$  such that (4.16) has an asymptotically stable periodic solution  $x^*(\cdot, \omega; \varepsilon)$  in  $\mathscr{P}_{T/\omega}$  for  $\omega \ge \omega_1$ ,  $0 < |\varepsilon| \le \varepsilon_1$  and  $x^*(\cdot, \omega, \varepsilon) \to 0$  as  $\omega \to \infty$ ,  $\varepsilon \to 0$ . In particular, consider the forced van der Pol equation

$$\dot{x}_1 = x_2 \,, \ \dot{x}_2 = -x_1 + k(1 - x_1^2)x_2 + \varepsilon g(\omega t) \,,$$

where  $k \neq 0$ , g is in  $\mathscr{P}_T$  and  $\int^t g(s)$  is bounded.

Using Lemmas 1, 4.2 and 4.4 and the proof of Theorem 2.1, one can prove the following general result for systems which are coupled versions of the above types.

THEOREM 4.3. Suppose 9 is one of the classes . (-oo, oo), .49 or 9T, u is an n-vector, u = (x, y, z) where x, y, z are ni-, n2-, n3-vectors respectively, f =f (t, u, e) = (X, Y, Z) is in -9 n M), e = (µ, v), tt a real scalar, B is an n2 x n2 matrix in 9T, and A, C are constant ni x ni, n3 x n3 matrices, respectively, such that the system

$$\dot{x} = \mu A x, \qquad \dot{y} = B(t) y, \qquad \mu \dot{z} = C z,$$

is noncritical with respect to - for 0 < µ < po Then there are constants pi > 0, µi > 0, vi > 0 and a function u\*(t, e) continuous in t, s for - oo < t < oo, 0 <µ < µi, 0 <\_ I vl < vi, u\*(t, 0) =0, u\* e) in !2, Iu\*(., e)1 < pi, such that u\*(t, e) is a solution of the equations

$$egin{align} \dot{x} &= \mu[Ax + X(t,\,x,\,y,\,z,\,arepsilon)] \ \dot{y} &= B(t)y + \,Y(t,\,x,\,y,\,z,\,arepsilon), \ \mu \dot{z} &= Cz + \,Z(t,\,x,\,y,\,z,\,arepsilon), \ \end{pmatrix}$$

and is the only solution of (4.18) in -9 which has norm < pl. If -9 = .2f q, then e)] a m[f, B], 0 <µ <\_ µi, 0 <\_ 1 v1 < vi.

The stability properties of the solution e) of (4.18) are discussed exactly in the same manner as in Section 3. The stable and unstable manifolds of the solution e) can be characterized as in Theorems 4.1 and 4.2. In particular, if all eigenvalues of A, C have negative real parts and all characteristic exponents of y = B(t)y have negative real parts, then the solution e) is exponentially asymptotically stable. If at least one of the eigenvalues of A or C or the characteristic exponents of B(t)y have a positive real part, then the solution s) is unstable.

As mentioned earlier, it is difficult to remove the restriction in (4.18) that A be constant. On the other hand, it is possible to allow C to be a function of t, say C = C(t), provided either that the eigenvalues A(t) of C(t) have real parts bounded away from zero or, more generally, that

$$C(t) = \operatorname{diag}(D(t), E(t))$$

where the eigenvalues of both D(t) and E(t) have real parts (not necessarily of the same sign) bounded away from zero. For references concerning problems in the spirit of this section, see Hale [6].

## IV.5. The Duf ng Equation with Large Damping and Large Forcing

Consider the equation

$$(5.1) \ddot{y} + c\dot{y} + y + \varepsilon by^3 = B\cos\nu t,$$

where c > 0, b, e, B and v > 0 are constants. The equivalent second order

system is

(5.2) 
$$\dot{y} = z,$$
  $\dot{z} = -y - cz - \varepsilon b y^3 + B \cos \nu t.$ 

The methods of this chapter and some elementary facts about quadratic forms will be used to prove there is an ro > 0 such that for any r >\_ ro, there is an eo e0(r) > 0 such that, for Iel < e0(r), system (5.2) has a unique periodic solution of period 21r/v in the disk <sup>112</sup>, with center zero and radius r. This solution is uniformly asymptotically stable and any solution of (5.2) with initial value in B; , must approach this periodic solution as t -+ oe.

Consider the linear nonhomogeneous system

(5.3) y = z, i= -y-cz+BBoos vt.

Since the eigenvalues of the coefficient matrix of the homogeneous equation

$$\begin{array}{ll} \dot{y}=z,\\ \dot{z}=-y-cz, \end{array}$$

have negative real parts, Theorem 1.1 implies there is a unique periodic solution of (5.3) of period 27r/v. If this solution is designated by yO(t), zo(t), then the transformation of variables y = yO(t) + u, z = zo(t) + v applied to (5.2) yields the equivalent system

(5.5) 
$$\dot{u} = v + \varepsilon f_1(t, u, v),$$
 
$$\dot{v} = -u - cv + \varepsilon f_2(t, u, v),$$

where fl, f2 are periodic in t of period 2a/v, continuous in t, u, v and continuously differentiable in u, v. Actually, fI - 0, f2 = -b(yo(t) + u)3, but it is convenient for notational purposes to consider the more general system (5.5).

Since c > 0, Theorem 2.1 implies there is it pi > 0 and eI > 0 such that system (5.5) has a unique periodic solution (u\*(t, e), v\*(t, e)), jej <ej of period 27r/v in the disk BPI, this periodic solution is uniformly asymptotically stable, and u\*(t, 0) = 0 = v\*(t, 0). To prove the above mentioned result for (5.2), it is sufficient to show that, for any two disks B2 and Br, rI < r,there exists an e2 > 0 such that, for I e I < e2, any solution of (5.5) with initial value in B2 must eventually enter and remain in the ball B;,. In fact, suppose ro is such that the periodic solution (y\*(t, e), z\*(t, e)) of (5.2) given by y\*(t, e) \_ yo(t) + u\*(t, e), z\*(t, e) = zo(t) + v\*(t, e), lies in B;, for 0:9t5 2ir/v and Iel 5 el. Choose ri < pl. For any r >\_ ro, the choice' eo(r) = min(e2, cI) gives the desired result.

We now prove the assertion about (5.5). Since the linear system (5.4) is asymptotically stable, it is intuitively clear that there should be a family

of ellipses encircling the origin so that the solutions of (5.4) cross the boundaries of these ellipses from the outside to the inside with increasing time. If this is the case, then for any given ellipse one can choose  $\varepsilon$  small so that the solutions of (5.5) also cross the boundary of this ellipse in the same direction as for the linear system (5.4). These ideas are now made precise by actually constructing such a family of ellipses.

Consider the quadratic form

(5.6) 
$$V(u,v) = \frac{c^2+2}{c}u^2 + 2uv + \frac{2}{c}v^2.$$

This quadratic form is positive definite and therefore the level curves of this function are ellipses with center at the origin. The derivative of V along the solutions of (5.5) is

(5.7) 
$$\dot{V}(u,v) = -2(u^2+v^2) + 2\varepsilon \left[\frac{c^2+2}{c} uf_1 + uf_2 + vf_1 + \frac{2}{c} vf_2\right].$$

For any positive r,  $r_1$ ,  $r_1 < r$ , choose positive constants  $c_1 > c_2$  so that the region U contained between the curves  $V(u, v) = c_1$  and  $V(u, v) = c_2$  contains the region between the boundaries of the disks  $B_r^2$ ,  $B_{r_1}^2$  (see Fig. 5.1). Suppose

![](_page_179_Picture_8.jpeg)

Figure IV.5.1

 $\min(u^2 + v^2) = \alpha$  for u, v ranging over the set  $V(u, v) = c_2$ . Then  $\alpha > 0$  and one can find an  $\varepsilon_2 > 0$  such that the right hand side of (5.7) is less than  $-\alpha/2$  for  $0 \le |\varepsilon| \le \varepsilon_2$ ,  $-\infty < t < \infty$  and all (u, v) in U. For any  $(u^0, v^0)$  in U, the solution u(t), v(t),  $u(0) = u^0$ ,  $v(0) = v^0$ , of (5.5) remains in the interior of the ellipse  $V(u, v) = c_1$  and satisfies

$$\begin{split} V(u(t), v(t)) &\leq V(u(0), v(0)) + \int_0^t \dot{V}(u(s), v(s)) \, ds \\ &\leq V(u(0), v(0)) - \frac{\alpha}{2} \, t. \end{split}$$

Since V is positive in U, and the solution cannot reach the ellipse  $V(u, v) = c_1$ , there must be a  $t_0 > 0$  such that (u(t), v(t)) remains in the interior of the ellipse  $V(u, v) = c_2$  for all  $t \ge t_0$ . This proves the result.

## IV.6. Remarks and Extensions

The technique presented in this chapter is applicable to many other types of problems. To illustrate this, let us give a brief abstract summary of the basic ideas.

Suppose I is an interval in Rn, A(t) is an n X n matrix function continuous on I and ., 9 are given Banach spaces of continuous n-vector functions on I. For every f E=- -9, suppose the equation

$$\dot{x} = A(t)x + f(t)$$

has a unique solution .\*'.f in .7 and.\*': '9 is a continuous linear operator. At the end of section 1, we said (W, 9).was admissible if, for every f E 2, there is at least one solution of Eq. (6.1) in .T. Here, we are requiring uniqueness of the solution in .47. In this case, we say (.V, 2) is strongly admissible.

Let 'fI(I X Rn,Rn) = {f:I X Rn -> Rn,f(t,x) continuous and continuously differentiable in x}. Let

$$|f|_1 = \sup\{|f(t,x)| + |\partial f(t,x)/\partial x|, (t,x) \text{ in } I \times \mathbb{R}^n\}.$$

If 0 is in T, let us suppose the function is in -9 and consider the problem of the existence of solutions in ' of the equation

$$\dot{x} = A(t)x + f(t, x)$$

If there exists a solution x of Eq. (6.2) in .T, then x must satisfy the equation

(6.3) 
$$G(x,f) \stackrel{def}{=} x - \mathcal{K}F(x,f) = 0$$

where.V-: -9 - A is the continuous linear operator defined above and

(6.4) 
$$F: \mathscr{B} \times \mathscr{C}^{1}(I \times R^{n}, R^{n}) \to \mathscr{D}$$
$$F(x, f)(t) = f(t, x(t)), \qquad t \in I.$$

Let us suppose the function F(x,f) is continuous together with its Frechet derivative.

To solve Eq' (6.3) for IfII small, one can use the contraction mapping principle to obtain a generalization of Theorem 2.1.Or, one can use the Implicit Function Theorem in Banach spaces observing that G(0,0) = 0, aG(0,0)/ax = I, where G is defined in Eq. (6.3). The results may then be summarized as

THEOREM 6.1. Suppose (',9) is strongly admissible for system (6.1) and the function F defined in Relation (6.4) is continuous together with its Frechet derivative. Then there is a 6 > 0, 17 > 0, and a unique function

$$x^*:\{f\in\mathscr{C}^1(I\times R^n,R^n):|f|_1<\delta\}\to\mathscr{B}$$

such that x\*(f) is continuous together with its derivative in f, x\*(0) = 0, x\*(f ) satisfies Eq. (6.2) and is the only solution of Eq. (6.2) in with norm less than rl.

Theorem 6.1 includes Theorem 2.1 in the case where f(t,x) has a continuous first derivative in x. We give a few examples of other applications of Theorem 6.1.

Suppose I = [0,1] , M,N are n X n constant matrices, A(t) is an n X n continuous matrix on I, f is a continuous n-vector function on I and consider the boundary value problem

(6.5) 
$$\dot{x} = A(t)x + f(t), \qquad t \text{ in } I,$$

$$Mx(0) + Nx(1) = 0$$

If X(t) is the fundamental matrix solution of the homogeneous equation, X(0) = I, then

$$x(t) = X(t)x(0) + \int_0^t X(t)X^{-1}(s)f(s)ds$$

satisfies the boundary conditions if and only if

$$[M + NX(1)] x(0) = -X(1) \int_{0}^{1} X^{-1}(s) f(s) ds$$

If f (s) = -X(s)X- 1 (1)b for a given vector b in R', then

$$-X(1)\int_0^1 X^{-1}(s)f(s)ds = b$$

This implies that Eq. (6.7) has a unique solution for every continuous function f on I if and only if [M + NX(1)] -1 exists. If this inverse exists, then the boundary value problem (6.5) has a unique solution .t''f given by

$$(\mathscr{X}f)(t) = -X(t)[M + NX(1)]^{-1}X(1)\int_0^1 X^{-1}(s)f(s)ds + \int_0^t X(t)X^{-1}(s)f(s).$$

These results are summarized in the following:

### LEMMA 6.1. Let

$$\mathcal{D} = \{ f : [0,1] \to R^n, f \text{ cont.} \}, |f| = \sup_t |f(t)|,$$

$$\mathcal{B} = \{ x \in \mathcal{D} : Mx(0) + Nx(1) = 0 \}.$$

If X(t),X(0) = I, is a fundamental matrix solution of,z = A (t)x, then (, , is strongly admissible for the equation

$$\dot{x} = A(t)x + f(t)$$

if and only if [M + NX (1)] exists.

With this lemma, one can obtain the existence of a solution of the boundary value problem

$$\dot{x} = A(t)x + f(t,x)$$

$$Mx(0) + Nx(1) = 0$$

if the matrix [M + NX (1)] exists and I f (t, x) 1, I a f (t, x)/a x 1 are small.

As another illustration, let us briefly. indicate how the saddle point property may be obtained in this way. Consider the equation

$$\dot{x} = A x + f(t)$$

where the eigenvalues of A have nonzero real parts and f is in VY.T([0,-)), the space of continuous bounded n-vector functions on [0,o). We know Eq. (6.7) has at least one solution in -9 for every fin 147. However, the equation

$$\dot{x} = A x$$

has a finite dimensional subspace .9S of solutions which are in AT and so the solutions in of Eq. (6.7) are not unique unless 9"S = {0}. The pair ( r, ) is admissible but generally not strongly admissible. On the other hand, we can d e f i n e , IF so that (,21,0) is strongly admissible. In fact, let 7 r , : T- . 411, be a continuous projection operator and define ,21 = (I - 7r,)kl. The pair (,21,x) is then strongly admissible and there is a continuous linear operator-IV: x[.21 such that.Y/'f is the unique solution of Eq. (6.7) with rrr'f = 0. The operator ,7/,' of sourse, depends on the projection 7r,., but one can clearly choose 7r, so that,X-f consists of the sum of the two integrals in Formula (6.4) of Chapter III. With this definition of J, every solution of Eq. (6.7) in is given by

$$(6.9) x = \pi_s e^A \cdot x_0 + \mathscr{X} f.$$

Let us now consider the nonlinear problem

$$(6.10) \dot{x} = A x + f(x)$$

where f (O) 0, of (0)/a x = 0 and try to prove the existence of a saddle point at x = 0. In particular, let us obtain the stable manifold. We know from. Eq. (6.9) that every solution in . must satisfy

$$x = \pi_s e^A \cdot x_0 + \mathscr{X} f(x)$$

If y = x - 7T eA' xo, then y E ,21 and we have

(6.11) 
$$G(y,f,x_0) \stackrel{\text{def}}{=} y - \mathcal{X} f(y + \pi_s e^{A} \cdot x_0) = 0.$$

One can now use the Implicit Function Theorem to determine y\*(f, x0) in as a continuously differentiable function of f, xo, y\*(0,0) = 0, G(y\*(f, xo), f, xo) = 0. This shows there is a family of solutions for each f, which are bounded and remain in a neighborhood of zero. The dimension of the family is the dimension of the family 7reA-x0; that is, the dimension of the stable manifold of x = Ax. To show these solutions approach zero, one can put more restrictions on the space -0 and repeat the same argument.

This idea can be generalized to the abstract case where (.Q7,o is admissible and not strongly admissible (see, for example, Antosiewicz [2] , Hartman [I] ).

## CHAPTER V

## Simple Oscillatory Phenomena and the Method of Averaging

In Chapter II, it was shown how the Poincare-Bendixson theory could be used to determine the existence and stability properties of periodic orbits of autonomous two dimensional systems. For systems of higher dimension and even for nonautonomous two dimensional systems, the methods of Chapter II are of no assistance in the discussion of the existence of periodic or almost periodic solutions.

In Chapter IV, the existence of periodic and almost periodic solutions were discussed for systems of differential equations which were perturbations of linear systems of arbitrary order. On the other hand, it was assumed that the trivial solution was the only solution of the linear system which belonged to the class of desired solutions; that is, the system was noncritical. Applications are very common for which the linear part of the system contains nontrivial periodic solutions and the system is critical with respect to some class of forcing functions. The methods of Chapter IV are not applicable directly to such problems. However, there may be appropriate transformations of variables which bring a critical system into the framework of Chapter IV. This is precisely the basis for the method of averaging discussed in Section 3 below. The method of averaging is a general method for determining sufficient conditions for the existence and stability of periodic and almost periodic solutions of a class of nonlinear vector differential equations which contain a small parameter. It is possible to discuss the existence of periodic solutions without invoking the results of Chapter IV. In fact, a much more general theory is given in Chapter VIII for the periodic case.

Before discussing the method of averaging, general properties of conservative systems and simple nonconservative systems are treated in Sections 1 and 2. The remaining sections of the chapter are devoted to specific applications.

### V.I. Conservative Systems

Suppose f : Rn -± Rn is continuous and for any xe in Rn the system

$$(1.1) \dot{x} = f(x),$$

has a unique solution x (t) = x (t, xo) with x(0, xe) = x0. A function E: D C Rn R is said to be an inte ral of 1.1 on a region D e Rn if E is continuous together with its first partial derivatives, E is not constant on any open set in D, and E(x t) = constant along the solutions of (1.1).I Since E is assumed to have continuous first derivatives, the last property is equivalent to [8E(x(t))/8x] f (x(t)) = O. System (1.1) is said to be onservative if it has an integral E on Rn. The orbits in Rn of a conservative system must therefore lie on level curves of the integral E.

Suppose x = (xi, ..., xn), E is an integral of (1.1) on D and xe in D is such that 8E(xe)/axn ; 0. Let c = E(xO). From the implicit function theorem, it follows that the equation E(x) = c can be solved for xn as a function xn of the xk, k < n, xe and x in a sufficiently small neighborhood U of x0. Since E is assumed to be a first integral, E(x(t)) = c if x(t) is the solution of (1.1.) with x(0) = xc. Substituting xn in (1.1) results in a system of (n - 1) equations for the determination of the solution of (1.1) through xA. The dimension of (1.1) is therefore decreased by one on U. In particular, if n = 2, the existence of an integral reduces the solution of the equation to a quadrature.

In the following, the notation introduced in Chapter I is employed by letting y+ = y+(x), y = y -(x) denote respectively the positive, negative orbit of (1.1) through x, co(y+) and a(y) denote the w- and a-limit sets, respectively, of the orbit y+, y-.

LEMMA 1.1. Suppose E is an integral of (1.1) on an open set D containing an equilibrium point xO of (1.1). There is no neighborhood U of xO for which x° belongs to one of the sets co(y+(x)) or oc(y (x)) for all x in U.

PROOF. If there are a sequence of {tn}, to - . oo as n -\* oo, and an xI in D such that x(tn , xI) -\* xe as n -\* oo, then continuity of E implies E(x(t, x1)) = E(xc) for all t. The same statement is true for to -. - oo. Therefore, if there were a neighborhood U of xe such that xe belongs to one of the sets cw(y+(x)) or a(y (x)) for all x in U, then E would be constant on U. Since this is contrary to the definition of an integral, the lemma is proved.

Lemma 1.1 implies in particular that an equilibrium point of a conservative system can never be asymptotically stable.

LEMMA 1.2. Suppose B is an integral of (1.1) in a bounded, open neigh-

borhood D of an equilibrium point x = 0 of (1.1). If E(0) = 0 and E(x) > 0 for  $x \neq 0$  in D, then x = 0 is a stable equilibrium point.

PROOF. If E(0) = 0, E(x) > 0 for  $x \neq 0$  in D, then for any  $\varepsilon > 0$ ,  $\alpha \stackrel{\text{def}}{=} \min_{|x| = \varepsilon, x \text{ in } D} E(x) > 0$ . Choose  $0 < \delta < \varepsilon$  so that  $\{x: |x| \leq \delta\} \subset D$ ,  $\max_{|x| \leq \delta} E(x) < \alpha$ . Since E is an integral this implies  $|x(t, x^0)| < \varepsilon$ ,  $t \geq 0$ , if  $|x^0| < \delta$ . Thus, x = 0 is stable and the lemma is proved.

Lemma 1.3. For n=2, all orbits in a neighborhood of a stable isolated equilibrium point of a conservative system must be periodic orbits and the equilibrium point is a center.

PROOF. In this proof, a bar over a set denotes closure. Suppose x=0 is an isolated stable equilibrium point of (1.1) for n=2. Then there are neighborhoods U, V, of zero such that  $V \setminus \{0\}$  is equilibrium point free and for every x in U, the positive orbit  $\gamma^+ = \gamma^+(x)$  through x belongs to V. From the Poincaré-Bendixson theory, the  $\omega$ -limit set  $\omega(\gamma^+(x))$  of  $\gamma^+(x)$  must be either  $\{0\}$  or a periodic orbit. Lemma 1.1 implies  $\omega(\gamma^+(x))$  cannot be  $\{0\}$  for every x in U. If there is an x in U such that  $\Gamma = \omega(\gamma^+(x)) = \bar{\gamma}^+(x) \setminus \gamma^+(x)$  is a periodic orbit, then  $\Gamma$  is asymptotically stable from either the inside or outside and, thus, there is an open set on which the integral E is constant. This contradiction shows that any trajectory which does not approach zero is a periodic orbit. Since every periodic orbit obviously has zero in its interior, this proves the lemma.

A very important class of conservative systems are Hamiltonian systems with n degrees of freedom. If  $q=(q_1,\ldots,q_n)$  are the generalized position coordinates of n-particles and  $p=(p_1,\ldots,p_n)$  are the generalized momentum, H(p,q)=T(p)+V(q) where T is the kinetic energy and V is the potential energy, then the equations of motion are

$$\dot{q} = \frac{\partial H}{\partial p}, \qquad \dot{p} = -\frac{\partial H}{\partial q}.$$

This is a special case of system (1.1) with x = (q, p). The Hamiltonian H(p, q) is an integral of the system (1.2). The kinetic energy T(p) is assumed always positive if  $p \neq 0$  with T(0) = 0,  $\partial T(0)/\partial p = 0$ . If  $\partial T(p)/\partial p \neq 0$  for  $p \neq 0$ , the extreme points  $q^0$  of V(q) therefore yield the equilibrium points  $(q^0, 0)$  of (1.2).

For Hamiltonian systems, we can prove

Lemma 1.4. Suppose q=0 is an extreme point of the potential energy V(q) with V(0)=0. If zero is locally an absolute minimum of V(q), then (0,0) is a stable point of equilibrium of (1.2). The equilibrium point (0,0) is unstable if zero is not a minimum of V(q) if T(p) and V(q) have the form  $T(p)=T_2(p)+T_3(p)$ ,  $V(q)=V_k(q)+V_{k+1}(q)$  where  $T_2$  is a positive definite quadratic

form, Vk is a homogeneous polynomial of degree k > 2, T5(p) = o(1p12), Vk+ 1(q) = o(I q I k) as l p 1, I q I - 0 and there is a neighborhood U of (0,0) such that

$$\Omega_U = \{ (p,q) \in U : H(p,q) < 0 \} \neq \emptyset$$

and Vk(q) < 0 if (p,q) is in S2u.

PROOF. The assertion concerning stability is an immediate consequence of Lemma 1.2. Suppose zero is not a minimum of V(q). Let W(p,q) = p'q. The point (0,0) is a boundary point of 92 u. Using the fact that His an integral of (1.2), the derivative W(p,q) along the solutions of (1.2),is easily seen to be

$$\dot{W}(p,q) = 2T_2(p) - kV_k(q) + \cdots,$$

where designates terms which are o(1 p 12) and o(I q I k) as I p 1, 'I q I -+ 0. In 92U, T2(p) > 0 and Vk(q) < 0. Furthermore, one can choose the neighborhood U of (0,0) sufficiently small that W(p,q) > 0 in S2U. Since W(p,q) > 0, W(p,q) > 0 in S2U, any solution with initial value in &2U must leave the set S2U through the boundary of U since the boundary of S2U in the interior of U consists of points where W(p,q) = 0, or H(p,q) = 0. Since (0,0) is in the boundary of S2U, this proves instability and the lemma.

More specific information on the nature of the integral curves for second order conservative systems can be given. Consider the second order scalar equation

$$\ddot{u}+g(u)=0,$$

or the equivalent system

$$egin{aligned} \dot{u} = v, \ \dot{v} = -g(u), \end{aligned}$$

where g is continuous and a uniqueness theorem holds for (1.4). System (1.4) is a Hamiltonian system with the Hamiltonian function or total energy given by E(u, v) = v2/2 + G(u) where G(u) = fu g(s)ds. The orbits of solutions of (1.4) in the (u, v)-plane must lie on the level curves of the function E(u, v); that is, the curves described by E(u, v) = h, a constant. The equilibrium points of (1.4) are points (uc, 0) where g(ua) = 0. If G(u) has an absolute minimum at uc, then (uc, 0) is stable (Lemma 1.2) and all orbits in a neighborhood of (u°, 0) must be periodic orbits (Lemma 1.3); that is, (u°, 0) is a center. Since the solutions of E(u, v) = h, a constant, are

(1.5) 
$$v = \pm \sqrt{2[h - G(u)]},$$

it follows that any isolated equilibrium point (uc, 0) such that uc is not a minimum of G must be unstable. In fact, the curves v = + 2[h - G(u)],

v = --,/2[h - G(u)] are homeomorphic images of a segment of the real line in a neighborhood of (u°, 0). -If a solution starting on these curves does not leave a neighborhood of (u°, 0), then the w-limit set of the solution curve would be an equilibrium point. Since (u°, 0) is assumed isolated, this immediately gives a contradiction.

A point u° is a local absolute minimum of G(u) if g(u) < 0 for u < u° and g(u) > 0 for u > u° and u in a neighborhood of u°. The reverse inequalities apply for a local absolute maximum of G(u). If G(u) has a local absolute maximum at u°, then the equilibrium point (u°, 0) is a saddle point in the sense that the set of all solutions which remain in a small neighborhood of (0, 0) fort >\_ 0 (t:5 0) must lie on an arc passing through (0, 0). This follows directly from formula (1.5). We can therefore state

LEMMA 1.5. The stable equilibrium points of (1.4) are centers and all of the unstable equilibrium points of (1.4) are saddle points if the only extreme points of G(u) are local absolute minimum and local absolute maximum.

Particular examples illustrate how easily information about a two dimensional conservative system is obtained without any computations whatsoever. The sketch of the level curves of E are easily deduced using (1.5).

Example 1.1. Suppose the function G(u) has the graph shown in Fig. L la with A, B, C, D being extreme points of G. The orbits of solution curves are sketched in Fig. 1.1b, all curves of course being symmetric with respect to the u-axis. The equilibrium points corresponding to A, B, C, D are labeled as A, B, C, D on the phase plane also. The points A, C are centers, B is a saddle point and D is like the coalescence of a saddle point and a center. The curves joining B to B and D to D in Fig. 1.lb are called separatrices. A separatrix is

![](_page_188_Figure_7.jpeg)

Figure V.1.1

a curve consisting of orbits of (1.3) which divides the plane into two parts and there is a neighborhood of this curve such that not all orbits in this neighborhood have the same qualitative behavior. Separatrices must therefore always pass through unstable equilibrium points.

Example 1.2. Suppose equation (1.3) is the equation for the motion of a pendulum of length l in a vacuum and u is the angle which the pendulum makes with the vertical. If g is the acceleration due to gravity, then  $g(u) = k^2 \sin u$ ,  $k^2 = g/l$ ,  $G(u) = k^2(1 - \cos u)$  and G(u) has the graph shown in Fig. 1.2a. The curves E(u, v) = h clearly have the form shown in Fig. 1.2b. Explain the physical meaning of each of the orbits in Fig. 1.2b.

![](_page_189_Figure_4.jpeg)

Figure V.1.2

It is not difficult to determine implicit formulas for the periods of the periodic solutions of equation (1.3) for an arbitrary g(x). Any periodic solution has an orbit which must be a closed curve and conversely. From (1.5), it follows that a closed orbit must intersect the u axis at two points (a, 0), (b, 0), a < b, and must be symmetrical with respect to the u-axis. If T is the period of the periodic solution, then  $T = 2\omega$  where  $\omega$  is the time to traverse that part of the orbit where v > 0. Since v is given by (1.5) it follows from (1.4) that

(1.6) 
$$T = 2 \int_{a}^{b} \frac{du}{\sqrt{2(h - G(u))}}.$$

If G(u) is even in u and the periodic orbit encircles the origin, then symmetry implies a=-b and

(1.7) 
$$T = 4 \int_0^b \frac{du}{\sqrt{2(h - G(u))}}.$$

For the pendulum equation, example 1.2,  $g(u) = k^2 \sin u$ ,  $G(u) = k^2(1 - \cos u)$ , and if  $u(0) = b < \pi$ , v(0) = 0, then  $h = E(u(t), v(t)) = E(u(0), v(0)) = E(b, 0) = k^2(1 - \cos b)$ . Consequently, the period T of the periodic orbit passing through this point (b, 0) is

$$T=4\int_0^b rac{du}{[2k^2(\cos u-\cos b)]^{1/2}}=rac{2}{k}\int_0^b rac{du}{\left[\sin^2\left(rac{b}{2}
ight)-\sin^2\left(rac{u}{2}
ight)
ight]^{1/2}}.$$

If  $\sin(u/2) = (\sin \psi) \sin(b/2)$ , then

(1.8) 
$$T = \frac{4}{k} \int_0^{\pi/2} \frac{d\psi}{\left[1 - \sin^2\left(\frac{b}{2}\right)\sin^2\psi\right]^{1/2}}.$$

This integral cannot be evaluated in terms of elementary functions, but if b is sufficiently small, then it is easy to find an approximate value of the period. Expanding in series, we obtain

$$egin{aligned} T = &rac{2\pi}{k}\left[1 + rac{1}{4}\sin^2\left(rac{b}{2}
ight) + \cdots
ight] \ = &rac{2\pi}{k}\left[1 + rac{1}{16}\,b^2 + \cdots
ight], \end{aligned}$$

if b is sufficiently small. To the first approximation  $T=2\pi/k$ ; that is, the frequency k is approximately  $\sqrt{g/l}$ , which is almost the first lesson in every course in elementary mechanics. From this example and the above computation, it is seen that the period of a periodic solution of an autonomous differential equation may vary from one solution to another (contrast this fact to the linear equation).

EXERCISE 1.1. For  $g(u) = u + \gamma_0 u^3$ , show that the period  $T(b, \gamma_0)$  given by formula (1.7) is a decreasing function of b (increasing function of b) if  $\gamma_0 > 0$  ( $\gamma_0 < 0$ ). The first situation is called a hard spring and the second a soft spring. Hard implies the frequency increases with the amplitude b. Soft implies the frequency decreases with the amplitude b.

In the general case, if  $(u^0, 0)$  is a stable equilibrium point of (1.3), then the restoring force g(u) is said to correspond to a hard spring (soft spring) at  $u^0$  if the frequency of the periodic solutions in a neighborhood of  $(u^0, 0)$  is an increasing (decreasing) function of the distance of the periodic orbit from  $(u^0, 0)$ .

Example 1.3. Consider a pendulum of mass m and length l constrained to oscillate in a place rotating with angular velocity w about a vertical line. If u denotes the angular deviation of the pendulum from the vertical line (see Fig. 1.3), the moment of centrifugal force is mw212 sin u cos u, the

![](_page_191_Picture_3.jpeg)

Figure V.1.3

moment of the force due to gravity is mgl sin u and the moment of inertia is I = m12. The differential equation for the motion is

(1.9) 
$$I\ddot{u} - m\omega^2 l^2 \sin u \cos u + mgl \sin u = 0.$$

If µ = mw212/I and A = g/w21, then this equation is equivalent to the system

$$\dot{u}=v, \ \dot{v}=\mu(\cos u-\lambda)\sin u,$$

which is a special case of (1.4) with g(u) = g(u, A) = -µ(cos is - A)sin u. The dependence of g upon A is emphasized since the number of equilibrium points of (1.10) depends upon A. The equilibrium points of (1.10) are points (uc, 0) with g(uc, A) = 0 and are plotted in Fig. 1.4. The shaded regions correspond to g(u, A) < 0. For any given A, the equilibrium points are (0, 0), (7T, 0) and (cos-1A, 0), the last one of course appearing only if JAI < 1. For IAA 1, Lemma 1.5 implies the points on the curves labeled in Fig. 1.4 with black dots (circles) are stable (unstable), the stable points being centers and the unstable points being saddle points. From this diagram one sees that when 0 A < 1, the stable equilibrium points are not (0, 0) or (77, 0) but the points (c6s-1A, 0). Physically, one can have A < 1 if the angular velocity co is large enough. Analyze the behavior of the equilibrium points for A = 1, A = -1.

![](_page_192_Figure_2.jpeg)

Figure V.1.4

![](_page_192_Figure_4.jpeg)

An integral for this system is easily seen to be

$$E(u,v)=rac{v^2}{2}-rac{\mu}{2}\sin^2u-\mu\lambda\,\cos\,u.$$

Suppose 0 < A < 1. The equilibrium points (0, 0) and (0, IT) are saddle points

and the level curves of E(u, v) passing through these points are, respectively,

$$v^2 = \mu[\sin^2 u + 2\lambda(\cos u - 1)],$$
  
 $v^2 = \mu[\sin^2 u + 2\lambda(\cos u + 1)].$ 

Both of these curves contain the points (cos-1 A, 0) in their interiors and the latter one also passes through (-7r, 0). A sketch of the orbits is given in Fig. 1.5. The two centers correspond to the two values of u for which cos u = A. Interpret the physical meaning of all of the orbits in Fig. 1.5 and also sketch the orbits in the phase plane when A > 1.

### V.2. Nonconservative Second Order Equations-Limit Cycles

Up to this point, three different types of oscillations which occur in second order real autonomous differential systems have been discussed. For linear systems, there can be periodic solutions if and only if the elements of the coefficient matrix assume very special values and, in such a situation, all solutions are periodic with exactly the same period. For second order conservative systems, there generally are periodic solutions. These periodic solutions occur as a member of a family of such solutions each of which is uniquely determined by the initial conditions. The period in general varies with the initial conditions but not all solutions need be periodic. In Section 1.7, artificial examples of second order systems were introduced for which there was an isolated periodic orbit to which all solutions except the equilibrium solution tend as t - oo. In Chapter II, as an application of the Poincare-Bendixson theory, it was shown that the same situation occurs for a large class of second order systems which include as a special case the van der Pol equation. Such an isolated asymptotically stable periodic orbit was termed a limit cycle and is also sometimes referred to as a self-sustained oscillation. The phenomena exhibited by such systems is completely different from a conservative system since the periodic motion is determined by the differential equation itself in the sense that the differential equation determines a region of the plane in which the w-limit set of any positive orbit in this region is the .periodic orbit.

In many applications, these latter systems are more important since the qualitative behavior of the solutions is less sensitive to perturbations in the differential equation than conservative systems. To illustrate how the structure of the solutions change when a conservative system is subjected to small perturbations, consider the problem of the ordinary pendulum subjected to a frictional force proportional to the rate of the change of the angle u with respect to the vertical. The equation of motion is

$$(2.1) \ddot{u} + \beta \dot{u} + k^2 \sin u = 0,$$

where P > 0 is a constant. The equivalent system is

(2.2) 
$$\dot{u} = v,$$
 
$$\dot{v} = -k^2 \sin u - \beta v.$$

If E(u, v) = v2/2 + k2(1 - cos u) is the energy of the system, then dE/dt along the solution of (2.2) is dE/dt = -,v2 < 0.

We first show that v(t) -\* 0 for all solutions of (2.2). Since dE/dt < 0, E is nonincreasing along solutions of (2.2) and v(t) is bounded. Equation (2.2) and the boundedness of sin u(t) implies v(t) is bounded. If v(t) does not approach zero as t --> oo, then there are positive numbers s, S and a sequence to , n = 1, 2, ... , t,a -- oo as n -\* oo such that the intervals I,a = [tn, - S, t,a + S] are nonoverlapping and v2(t) > e for tin In, n = 1, 2, .... Let p(t) be the integer such that to < t for all n < p(t). Then,

$$\begin{split} E(u(t), v(t)) - E(u(0), v(0)) &= \int_0^t \left(\frac{dE}{dt}\right) ds \\ &\leq -\int_0^t \beta v^2(s) ds \\ &\leq -2\beta \delta \varepsilon p(t). \end{split}$$

Since p(t) -- co as t oo and E(u(t), v(t)) is bounded, this contradicts the fact that v(t) does not approach zero as t eo. Thus, v(t) 0 as t oo.

With E(u(t), v(t)) nonincreasing and v(t) --> 0 as t - eo, the nature of the level curves of E implies that every solution of (2.2) is bounded. Also, since the energy is nonincreasing and bounded below, it must approach a constant as t -\* co. Since E is continuous and the limit set of any solution is invariant, the limit set must lie on a level curve of E; that is, the limit set of each solution must have .9 = 0 and, therefore, v = 0. Since the limit set of each solution is invariant and must have v = 0, it follows that u is either 0, ±ir, ±2ir, etc. All solutions of (2.2) bounded implies they have a nonempty limit set and, therefore, each solution of (2.2) must approach one of the equilibrium points (0, 0), (a, 0), (-7r, 0), etc. To understand the qualitative behavior of the solutions, it remains only to discuss the stability properties of the equilibrium points and use the properties of the level curves of E(u, v) depicted in Fig. 1.2b.

The linear variational equation relative to (0, 0) is

$$\dot{u}=v, \ \dot{v}=-k^2u-eta v,$$

and the eigenvalues of the coefficient matrix have negative real parts. Therefore, by the theorem of Liapunov (Theorem 111.2.4), the origin for the nonlinear system is asymptotically stable. The linear variational equation

relative to the equilibrium point (or, 0) is

$$\dot{u}=v, \ \dot{v}=k^2u-eta v,$$

and the eigenvalues of the coefficient matrix are real, with one positive and one negative. Since the saddle point property is preserved (Theorem 111.6.1), this equilibrium point is unstable and only two orbits approach this point as t -\* oo. Periodicity of sin u yields the stability properties of the other equilibrium points.

This information together with the level curves of E(u, v) allows one to sketch the approximate orbits in the phase plane. These orbits are shown in Fig. 2.1 for the case fg < 2k.

![](_page_195_Picture_6.jpeg)

This example illustrates very clearly that a change in the differential equation of a conservative system by the introduction of a small nonconservtive term alters the qualitative behavior of the phase portrait of the solutions tremendously. It also indicates that a limit cycle will not occur by the introduction of a truly dissipative or frictional term. In such a case, energy is always taken from the system. To obtain a limit cycle in an equation, there must be a complicated transfer of energy between the system and the external forces. This is exactly the property of van der Pol's equation where the dissipative term 0 is such that 0 depends upon u and does not have constant sign.

Basic problems in the theory of nonlinear oscillations in autonomous systems with one degree of freedom are to determine conditions under which the differential equation has limit cycles, to determine the number of limit cycles and to determine approximately the characteristics (period, amplitude,

shape) of the limit cycles. One useful tool in two dimensions is the Poincar< - Bendixson theory of Section II.1. Other important methods involve perturbation techniques, but can be proved to be applicable in general only when the equation contains either a small or a large parameter. The great advantage of such methods is the fact that the dimension of the system is not important and the equations may depend explicitly upon time in a complicated manner.

One general perturbation technique known as method of averaging will be described in the next section. As motivation for this theory, consider the van der Pol equation

$$(2.3) \ddot{u} - \varepsilon (1 - u^2) \dot{u} + u = 0,$$

where e > 0 is a small parameter. From Theorem 11.1.6, this equation has a unique limit cycle for every e > 0. Our immediate goal is to determine the approximate amplitude and period of this solution as a -->. 0. Equation (2.3) is equivalent to the system

$$\dot{u}=v, \ \dot{v}=-u+arepsilon(1-u^2)v.$$

For e = 0, the general solution of (2.4) is

$$(2.5) u = r \cos \theta, v = -r \sin \theta,$$

where 0 = t + 0, 0 and r are arbitrary constants. If the periodic solution of (2.4) is a continuous function of e, then the orbit of this solution should be close to one of the circles described by (2.5) by letting r = constant and 0 vary from 0 to 21T. The first basic problem is to determine which constant value of r is the candidate for generating the periodic solution of (2.4) for e 0.

If r, 0 are new coordinates, then (2.4) is transformed into the system

(2.6) (a) 
$$\dot{\theta} = 1 + \varepsilon (1 - r^2 \cos^2 \theta) \sin \theta \cos \theta$$
,  
(b)  $\dot{r} = \varepsilon (1 - r^2 \cos^2 \theta) r \sin^2 \theta$ .

For r in a compact set, a can be chosen so small that 1 + e(1 - r2 cos2 0) - sin 0 cos 0 >, 0 and the orbits of the solutions described by (2.6) are given by the solutions of the scalar equation

(2.7) 
$$\frac{dr}{d\theta} = \varepsilon g(r, \, \theta, \, \varepsilon)$$

where

(2.8) 
$$g(r, \theta, \varepsilon) = \frac{(1 - r^2 \cos^2 \theta) r \sin^2 \theta}{1 + \varepsilon (1 - r^2 \cos^2 \theta) \sin \theta \cos \theta}.$$

The problem of determining periodic solutions of van der Pol's equation for a small is equivalent to finding periodic solutions r\*(O, e) of (2.7) of period 21r in 0. In fact, if r\*(6, e) is such a 2a-periodic solution of (2.7) and 8\*(t, e), 8\*(0, e) = 0, is the solution of the equation

(2.9) 
$$\dot{\theta} = 1 + \varepsilon (1 - [r^*(\theta, \varepsilon)]^2 \cos^2 \theta) \sin \theta \cos \theta,$$

then u(t) = r\*(8\*(t, e), e) cos 8\*(t, s), v(t) = -r\*(8\*(t, e), e) sin 8\*(t, e) is a solution of (2.4). Let T be the unique solution of the equation 8\*(T, e) = 27r. Uniqueness of solutions of equation (2.9) then implies 8\*(t + T, e) \_ 8\*(t, e) + 2a for all t. Therefore, u(t + T) = u(t), v(t + T) = v(t) for all t and u, v is a 'periodic solution of (2.4) of period T. Conversely, if u, v is a periodic solution of (2.4) of period T, then r(t + T) = r(t) and one can choose 0 so that 8(t + T) = 6(t) + 2a for all t. The functions r and 0 satisfy (2.6) and, for e small, t can be expressed as a function of 8 to obtain r as a periodic function of 21r in 8. Clearly, this function satisfies (2.7).

Let us attempt to determine a solution of (2.7) of the form

(2.10) 
$$r = \rho + \varepsilon r^{(1)}(\theta, \rho) + \varepsilon^2 r^{(2)}(\theta, \rho) + \cdots,$$

where each r(1)(8, p) is required to be 27r-periodic in 8, and p is a constant. If this expression is substituted into (2.7) and like powers of a are equated then

$$\frac{\partial r^{(1)}(\theta, \, \rho)}{\partial \theta} = g(\rho, \, \theta, \, 0).$$

This equation will have a 2.7r-periodic solution in 8 if and only if f o lTg(p, 8, 0)d8 = 0. If this expression is not zero, then it is called a secular term. If a secular term appears, then a solution of the form (2.10) is not possible for an arbitrary constant p. The constant p must be selected so that it at least satisfies the <sup>2</sup> equation f<sup>c</sup> +rg(p, 0, 0)d8 = 0. Having determined p so that this relation is satisfied (if possible), then r(1)(8, p) can be computed and one can proceed to the determination of r(2)(9, p). However, the same type of equation results for r(2)(6, p) and more secular terms may appear. One way to overcome these difficulties is to use a method divised by Poincar6 which consists in the following: let r be expanded in a series as in (2.10) and also let p be expanded in a series in a as p = po + ep, + e2p2 + - - and apply the same process as before successively determining po, pi, P2, in such a way as to eliminate all secular terms. If the pj can be so chosen, then one obtains a periodic solution of (2.7). This method will be discussed in a much more general setting in a later chapter.

We discuss in somewhat more detail another method due to Krylov and Bogoliubov which is generalized in the next section. Consider (2.10) as &

transformation of variables taking r into  $\rho$  and try to determine  $r^{(1)}(\theta, \rho)$ ,  $r^{(2)}(\theta, \rho)$ , ... so that the differential equation for  $\rho$  is autonomous and given by

(2.11) 
$$\frac{d\rho}{d\theta} = \varepsilon R^{(1)}(\rho) + \varepsilon^2 R^{(2)}(\rho) + \cdots$$

If such a transformation can be found, then the  $2\pi$ -periodic solutions of (2.7) coincide with the equilibrium points of (2.11). Also, the transient behavior of the solutions of (2.7) will be obtainable from (2.11).

If (2.10) is substituted into (2.7),  $\rho$  is required to satisfy (2.11) and

$$g(r, \theta, \varepsilon) = \sum_{k=0}^{\infty} \varepsilon^k g^{(k)}(r, \theta),$$

then

(2.12) 
$$R^{(1)}(\rho) + \frac{\partial r^{(1)}(\theta, \rho)}{\partial \theta} = g^{(0)}(\rho, \theta),$$

$$R^{(2)}(\rho) + \frac{\partial r^{(2)}(\theta, \rho)}{\partial \theta} = -\frac{\partial r^{(1)}}{\partial \rho} (\theta, \rho) R^{(1)}(\rho) + g^{(1)}(\rho, \theta) + \frac{\partial g^{(0)}}{\partial r} (\rho, \theta) r^{(1)}(\theta, \rho).$$

Since  $g^{(0)}(\rho, \theta) = g(\rho, \theta, 0)$ , the first equation in (2.12) always has a solution given by

(2.13) 
$$R^{(1)}(\rho) = \frac{1}{2\pi} \int_0^{2\pi} g(\theta, \rho, 0) d\theta,$$
 
$$r^{(1)}(\theta, \rho) = \int [g(\rho, \theta, 0) - R^{(1)}(\rho)] d\theta,$$

where " $\int$ " denotes the  $2\pi$ -periodic primitive of the function of mean value zero. Similarly, the second equation can be solved for  $R^{(2)}(\rho)$  as the mean value of the right hand side and  $r^{(2)}(\theta, \rho)$  defined in the same way as  $r^{(1)}(\theta, \rho)$ . This process actually converges for  $\varepsilon$  sufficiently small, but this line of investigation will not be pursued here.

Let us recapitulate what happens in the first approximation. Suppose  $R^{(1)}(\rho)$ ,  $r^{(1)}(\theta, \rho)$  are defined by (2.13) and consider the exact transformation of variables

$$(2.14) r = \rho + \varepsilon r^{(1)}(\theta, \rho)$$

applied to (2.7). For  $\varepsilon$  small, the equation for  $\rho$  is

$$\left(1\,+\,\varepsilon\,\frac{\partial r^{(1)}}{\partial\rho}\right)\dot{\rho}=\varepsilon[g(\rho+\varepsilon r^{(1)},\,\theta,\,\varepsilon)-g(\rho,\,\theta,\,0)+R^{(1)}(\rho)],$$

and thus,

(2.15) 
$$\dot{\rho} = \varepsilon R^{(1)}(\rho) + \varepsilon^2 R^{(2)}(\rho, \theta, \varepsilon)$$

where R(2)(p, 0, e) is continuous at e = 0. Consequently, the transformation (2.14) reduces (2.7) to a higher order perturbation of the autonomous equation

$$\dot{\rho} = \varepsilon R^{(1)}(\rho),$$

where R(1)(p) is the mean value of g(p, 0, 0).

Suppose R(1)(pc) = 0, dR(1)(pc)/dp <0 for some pc. Then pc is a stable equilibrium point of (2.16) and the equation (2.15) satisfies the conditions of Theorem IV.4.3 with x = p and the equations for y and z absent. Consequently, there is an asymptotically stable 21T-periodic solution of (2.15) and therefore an asymptotically stable 27r-periodic solution of (2.7) given by (2.15).

If this is applied to van der Pol's equation where g is given by (2.8), then

$$R^{(1)}(
ho) = rac{1}{2\pi} \int_0^{2\pi} g(
ho, \, heta, \, 0) \, d heta = rac{
ho}{2} \left(1 - rac{
ho^2}{4}
ight).$$

This function R(1)(p) is such that R(1)(2) = 0, dR(1)(2)/dp = -1 <0. Therefore, the van der Pol equation (2.3) has an asymptotically stable periodic solution which for e = 0 is u = 2 cos t. Zero is also a solution of R(1)(p) = 0 and dR(1)(0)/dp > 0. An application of Theorem IV.4.3 implies that zero corresponds to the unstable equilibrium point u = 0 of (2.3).

## V.3. Averaging

One of the most important methods for the determination of periodic and almost periodic solutions of nonlinear differential equations which contain a small parameter is the so-called method of averaging. The method was motivated in the last section by trying to determine under what conditions one could perform a time varying change of variables which would have the effect of reducing a nonautonomous differential equation to an autonomous one. This idea will be developed to a further extent in this section, but our main interest will lie in the information that can be obtained from only taking the first approximation.

Suppose x in an, e >\_ 0 is a real parameter, f: R x an x [0, co) -\* Cn is continuous, f (t, x, e) is almost periodic in t uniformly with respect to x in compact sets for each fixed e, has continuous first partial derivatP+es with respect to x and f (t, x, e) - f (t, x, 0), af(t, x, e)/a x - af(t, x, 0)/a x ass -> 0 uniformly for t in x in compact sets. Along with the system of equations,

$$\dot{x} = \varepsilon f(t, x, \varepsilon),$$

consider the " averaged " system,

$$\dot{x} = \varepsilon f_0(x),$$

where

(3.3) 
$$f_0(x) = \lim_{T \to \infty} \frac{1}{T} \int_0^T f(t, x, 0) dt.$$

The basic problem in the method of averaging is to determine in what sense the behavior of the solutions of the autonomous system (3.2) approximates the behavior of the solutions of the more complicated nonautonomous system (3.1). There are two natural types of interpretations to give to the connotation "approximates ". One is to ask that the approximation be valid on a large finite interval and the other is to ask that it be valid on an infinite interval. The results given here deal only with the infinite time interval.

Every solution of the equation x = 0 is a constant. Therefore, system (3.1) is a perturbation of a system which is critical with respect to the class of periodic functions of any period whatsoever and, in particular, with respect to the class of almost periodic systems. On the other hand, it will be shown below that there is an almost periodic transformation of variables which takes x -\* y and system (3.1) into a system of the form

$$\dot{y} = \varepsilon [f_0(y) + f_1(\varepsilon, t, y)]$$

where fl(0, t, y) = 0. If there is a yo such that fo(yo) = 0 and y = yo + z, then this system can be written as

$$\dot{z}=arepsilon\left[rac{\partial f_0(y_0)}{\partial y}z+\left\{f_0(y_0+z)-f_0(y_0)-rac{\partial f_0(y_0)}{\partial y}z
ight\}+f_1(arepsilon,\,t,\,y_0+z)
ight].$$

Therefore, in a neighborhood of yo the methods of Chapter IV can be applied if the linear system

$$\dot{z}=arepsilon rac{\partial f_0(y_0)}{\partial y}z$$

is noncritical with respect to the class of functions being considered. In this way, we obtain sufficient conditions for the existence and stability of periodic and almost periodic solutions of (3.1). The reasoning above is the basic idea in the method of averaging. Throughout the remainder of this chapter, we assume the norm in Cn is the Euclidean norm.

The following lemma is fundamental in the theory.

LEMMA 3.1. Suppose g: R X Cn -\*Cn is continuous, g(t, x) is almost periodic in t uniformly with respect to x in compact sets, has continuous first

derivatives with respect to x and the mean value of g(t, x) with respect to t is zero; that is,

(3.4) 
$$\lim_{T \to \infty} \frac{1}{T} \int_0^T g(t, x) dt = 0.$$

For any e > 0, there is a function u(t, x, e), continuous in (t, x, e) on B x C++ x (0, co), almost periodic in t for x in compact sets and e fixed, having a continuous derivative with respect to t and derivatives of an arbitrary specified order with respect to x such that, if

$$h(t, x, \varepsilon) = \frac{\partial u(t, x, \varepsilon)}{\partial t} - g(t, x),$$

then all of the functions h, 8h/8x, eu, Bu/8x approach 0 as a -> 0 uniformly with respect to tin R and x in compact sets.

This lemma is proved in Lemma 5 of the Appendix. It is advantageous at this point to discuss the meaning of Lemma 3.1 when the function g(t, x) satisfies some additional properties. Suppose g(i, x) is a finite trigonometric polynomial with coefficients which are entire functions of x. Then

(3.5) 
$$g(t, x) = \sum_{1 \le k \le N} a_k(x)e^{i\lambda_k t}, \ \lambda_k \ne 0,$$

where the Ak are real and each ak(x) is an entire function of x. If

(3.6) 
$$u(t, x) = \sum_{1 \le k \le N} \frac{a_k(x)}{i\lambda_k} e^{i\lambda_k t},$$

then u satisfies all of the conditions stated in the lemma. In addition, u is independent of a and

(3.7) 
$$\frac{\partial u(t,x)}{\partial t} - g(t,x) = 0.$$

In most applications, the manner just indicated is the method for the construction of a function u with the properties stated in the lemma. For a general function g, one may not be able to solve (3.7) in spite of the fact that the mean value of g is zero. In fact, there are almost periodic functions g(t) (see the Appendix) such that M[g] = 0 and f tg is an unbounded function. The lemma states that, even in this case, one can "approximately " solve (3.7) by an almost periodic function u(t, e). Of course, u(t, e) will become unbounded as a - 0, but eu(t, e) -> 0 as a -- 0.

LEMMA 3.2. Suppose f satisfies the properties stated before equation (3. 1), fo is defined in (3.3) and f2 is any compact set in Cn. Then there exist an eo > 0 and a function u(t, x, e) continuous for (t, x, s) in R x Cn x (0, co],

almost periodic in t for x in compact sets and e fixed and satisfying the conclusions of Lemma 3.1, with g(t, x) =f (t, x, 0) - fo (x) such that the transformation of variables

(3.8) 
$$x = y + \varepsilon u(t, y, \varepsilon), \qquad (t, y, \varepsilon) \in R \times \Omega \times [0, \varepsilon_0]$$

applied to (3.1) yields the equation

$$\dot{y} = \varepsilon f_0(y) + \varepsilon F(t, y, \varepsilon),$$

where F(t, y, e) satisfies the same conditions as f (t, y, e) for (t, y, e) e B X S2 X [0, so], and, in addition, F(t, y, 0) - 0.

PROOF. If g(t, x) =f (t, x, 0) -fo(x), then the conditions of Lemma 3.1 are satisfied. Let u(t, x, e) be the function given by that lemma. Since eu(t, y, e), eau(t, y, \_-)/ay, f (t, y, 0) -f (y) - au(t, y, e)fat -+0 as e -->. 0 uniformly with respect to t in R and y in compact sets, we define eu(t, y, e), eau(t, y, e)fay, f (t, y, 0) -fo(y) - au(t, y, e)fay at e = 0 to be zero. For any ei > 0, let c be a compact set in Cn containing the set {x: x = y + eu(t, y. E), (t, y, e) e R x S2 x [0, sl]}. Choose e2 > 0 so that I + e au(t, y, e) f ay has a bounded inverse for (t, y, a) e R X S2 x [0, e2]. This implies (3.8) can have at most one solution y e S2 for each (t, x, e) C\*-' R X 921 x [0, e2]. For any xo e 9211, the contraction mapping principle implies there is an a3(xo) > 0 such that (3.8) has a unique solution y = y(t, x, a) defined and continuous for I y - x0I < a3(xo), IX - X01:\_5 e3(xo), 0 < e < a3(x0). Since L21 is compact, we can choose an e4 > 0 independent of xo such that the same property holds with e3(xo) replaced by e4 . If so = min(e1, e2, 84), then (3.8) does define a homeomorphism. Therefore, the transformation (3.8) is well defined for 0 <\_ s< to, y e S2, t e R. If x = y + su(t, y, e), then

$$\Big(I + \varepsilon \frac{\partial u}{\partial y}\Big)\dot{y} = \varepsilon f_0(y) + \varepsilon \Big[f(t, y, 0) - f_0(y) - \frac{\partial u}{\partial t}\Big] + \varepsilon [f(t, y + \varepsilon u, \varepsilon) - f(t, y, 0)].$$

From the properties of u in Lemma 3.1 and the continuity of f, the indicated property of the equation for y follows immediately.

Lemma 3.2 is most important from the point of view of the differential equations since it shows that the transformation of variables (3.8), which is almost the identity transformation for a small, when applied to (3.1) yields a differential equation which is the same as the averaged system (3.2) up through terms of order e. We emphasize again that for functions f (t, x, e) which are trigonometric polynomials with coefficients entire functions of x, the expression for the transformation (3.8) is obtained by taking u to be given by (3.6) where g(t, x) =f (t, x, 0) -fo(x).

Let Re A(A) designate the real parts of the eigenvalues of a matrix A.

THEOREM 3.1. Suppose f satisfies the conditions enumerated before (3.1). If there is an x° such that fo(x°) = 0, and Re A[8fo(x°)/8x] 0 0, then there are an so > 0 and a function x\*(-, e): R -\*Cn, satisfying (3.1), x\*(t, E) is continuous for (t, s) in R x [0, so], almost periodic in t for each fixed e, s)] c m[f ( , x, e)], x\*(-, 0) = x°. The solution x\*(-, e) is also unique in a neighborhood of x°. Furthermore, if Re .1[8 fo(x°)/8x] < 0, then x\* ( , e) is uniformly asymptotically stable for 0 < E < so and if one eigenvalue of this matrix has a positive real part, x\*(-, e) is unstable.

THEOREM 3.2. Suppose f satisfies the conditions enumerated before (3.1). If f (t + T, x, e) = f (t, x, e) for all (t, x, E) in R x Cn X [0, co) and there is an x° such that fo(x°) = 0, det[efo(x°)/8x] 0, then there are an so > 0 and a function x\*(t, s), continuous for (t, E) in R X [0, so], x\*(-, 0) = x°, x\*(t + T, e) = x\*(t, e), for all t, a and x\*(t, e) satisfies (3.1). This solution X\*(-, e) is also unique in a neighborhood of x°.

The proofs of both of these theorems are immediate consequences of previous results. In fact, choose any compact set S2 in Cn containing x° in its interior. Lemma 3.2 implies that we may assume equation (3.1) is in the form (3.9) for (t, x, E) e R X 92 x [0, so]. If x° is such that fo(x°) = 0, then y = x° + z in (3.9) implies

$$\dot{z} = arepsilon Az + arepsilon F(t,x^0+z,arepsilon) + arepsilon [f_0(x^0+z) - f_0(x^0) - Az] \ \stackrel{ ext{def}}{=} arepsilon Az + arepsilon q(t,z,arepsilon),$$

where A = e fo(x°)/8x. One can now apply Lemma IV.4.3 and Theorem IV.4.2 directly to the equation for z to complete the proofs of Theorems 3.1 and 3.2.

In the applications, many problems cannot be phrased in such a way that the equations of motion are equivalent to a system of the form (3.1). However, the underlying ideas in the proof of Theorems 3.1 and 3.2 can be used effectively in more complicated situations. One should therefore keep in mind these basic principles and look upon the discussion here as a possible method of attack for the treatment of oscillatory phenomena in weakly nonlinear systems. Another application is now given to a class of equations which seems to occur frequently in the applications.

Consider the system

$$\dot{x} = \varepsilon f(t, x) + \varepsilon h(\varepsilon t, x),$$

where e > 0 is a real parameter, ,f (t, x), h(t, x) are continuous and have continuous first derivatives with respect to x, h(t,x) has continuou ..second partial derivatives with respect to x for (t, x) in R X Cn, f (t, x) is almost periodic in t uniformly with respect to x in compact sets and there is a T > 0 such that h (t + T, x) = h(t, x) for all t, X.

System (3.10) contains both a "fast" time t and a "slow" time at. The

averaging procedure is applied to only the fast time to obtain the non-autonomous "averaged" equations

(3.11) 
$$\dot{x} = \varepsilon f_0(x) + \varepsilon h(\varepsilon t, x) \stackrel{\text{def}}{=} \varepsilon G(\varepsilon t, x),$$

where

(3.12) 
$$f_0(x) = \lim_{T \to \infty} \frac{1}{T} \int_0^T f(t, x) \ dt.$$

If system (3.11) has a periodic solution  $x^0(\varepsilon t)$  of period  $T/\varepsilon$ , then the linear variational equation for  $x^0(\varepsilon t)$  is given by

(3.13) 
$$\frac{dy}{d\tau} = \frac{\partial G(\tau, x^{0}(\tau))}{\partial x} y$$

where  $\tau = \varepsilon t$ .

The next result states conditions under which the equation (3.10) has an almost periodic solution which approaches the periodic solution of the averaged equation (3.11) as  $\varepsilon \to 0$ .

Theorem 3.3. Suppose f, h satisfy the conditions enumerated after (3.10). If  $x^0(\varepsilon t)$  is a periodic solution of (3.11) of period  $T/\varepsilon$  such that no characteristic exponents of the linear variational equation (3.13) have zero real parts, then there are an  $\varepsilon_0 > 0$  and a function  $x^*(\,\cdot\,,\,\varepsilon)$ :  $R \to C^n$ , satisfying (3.10),  $x^*(t,\,\varepsilon)$  is continuous for  $(t,\,\varepsilon)$  in  $R \times [0,\,\varepsilon_0]$ , almost periodic in t for each fixed  $\varepsilon$ ,  $m[x^*(\,\cdot\,,\,\varepsilon)] \subset m[f(\,\cdot\,,\,x),\,h(\varepsilon\,\cdot\,,\,x)]$ ; and  $x^*(t,\,\varepsilon) - x^0(\varepsilon t) \to 0$  as  $\varepsilon \to 0$  uniformly on R. This solution is also unique in a neighborhood of  $x^0(\,\cdot\,)$ . Furthermore, if all characteristic exponents of (3.13) have negative real parts,  $x^*(\,\cdot\,,\,\varepsilon)$  is uniformly asymptotically stable and if one exponent has a positive real part, it is unstable.

The proof of this result proceeds as follows. Choose any compact set  $\Omega$  in  $C^n$  which contains  $x^0(t)$ ,  $0 \le t \le T$ , in its interior. If  $g(t, x) = f(t, x) - f_0(x)$  and  $u(t, x, \varepsilon)$  is the function given by Lemma 3.1, then as in the proof of Lemma 3.2, there is an  $\varepsilon_0 > 0$  such that the transformation of variables  $x = y + \varepsilon u(t, y, \varepsilon)$  is well defined for  $(t, y, \varepsilon) \in R \times \Omega \times [0, \varepsilon_0]$ . This transformation applied to system (3.10) yields the equivalent equation

$$\dot{y} = \varepsilon G(\varepsilon t, y) + \varepsilon H(t, \varepsilon t, y, \varepsilon),$$

where  $H(t, \tau, y, 0) = 0$  and  $H(t, \tau, y, \varepsilon)$  satisfies the same smoothness properties in y as f, h, is almost periodic in t and periodic in  $\tau$  of period T. If  $y(t) = x^0(\varepsilon t) + z(t)$ , then

$$\dot{z} = \varepsilon A(\varepsilon t)z + \varepsilon Z(t, \varepsilon t, z, \varepsilon),$$

where A(r) = t^G(r, xo(-r))/8x and Z(t, et, z, E) satisfies the conditions of Theorem IV.4.2. Suppose P(r)eBr is a fundamental matrix solution of (3.13) with P(r + T) = P(r) and B a constant matrix. From the hypothesis of the theorem, the eigenvalues of B have nonzero real parts. If z = P(et)w, then

$$\dot{w} = \varepsilon B w + \varepsilon W(t, \, \varepsilon t, \, w, \, \varepsilon)$$

where W(t, Et, w, e) satisfies the conditions of Theorem IV.4.2. The proof of Theorem 3.3 is completed by a direct application of-this result.

Another type of equation that is very common is the system

$$\dot{x}=arepsilon X(t,\,x,\,y,\,arepsilon), \ \dot{y}=Ay+arepsilon Y(t,\,x,\,y,\,arepsilon),$$

where e is a real parameter, x, X are n-vectors, y, Y are m-vectors, A is a constant n X n matrix whose eigenvalues have nonzero real parts, X, Y are continuous on R X Cn X Cm x [0, oo), have continuous first derivatives with respect to x, y and are almost periodic in t for x, y in compact sets and each fixed E. The "averaged" equation for (3.14) is defined to be

$$\dot{x} = \varepsilon X_0(x),$$

where

(3.16) 
$$X_0(x) = \lim_{T \to \infty} \frac{1}{T} \int_0^T X(t, x, 0, 0) dt.$$

THEOREM 3.4. Suppose X, Y satisfy the conditions enumerated after (3.14). If there is an x0 such that Xo(x0) = 0 and Re A(8Xo(x0)/8x) 0 0, then there are an eo > 0 and vector functions x\*(-, e), y\*(-, e) of dimensions n, m respectively, satisfying (3.14), continuous on R x [0, eo], almost periodic in t for each fixed e, x\*(-, 0) = x0, y\*(-, 0) = 0. This solution is also unique in a neighborhood of (x0, 0). Furthermore, if Re A(8Xo(x0)/8x) <0, Re A(A) <0, then this solution is uniformly asymptotically stable for 0 < e <\_ so and if one eigenvalue of either of these matrices has a positive real part, it is unstable.

The proof follows the same lines as before. Suppose 0 is a compact set of Cn containing x0 in its interior. If g(t, x) = X(t, x, 0, 0) - Xo(x) and u(t, x, e) is the function given in Lemma 3.1, then as in the proof of Lemma 3.2, there is an eo > 0 such that the transformation

$$x \rightarrow x + \varepsilon u(t, x, \varepsilon), y \rightarrow y,$$

is well defined. for (t, x, y, e) e R x L x Cm x [0, eo]. This transformation applied to (3.14) yields the equivalent system

$$\dot{x}=arepsilon X_0(x)+arepsilon X_1(t,\,x,\,y,\,arepsilon)+arepsilon X_2(t,\,x,\,y,\,arepsilon), \ \dot{y}=Ay+arepsilon Y_1(t,\,x,\,y,\,arepsilon),$$

where  $X_1(t, x, y, 0) = 0$  and  $X_2(t, x, 0, 0) = 0$  and all functions have the same smoothness and almost periodicity properties as before. If the further transformation  $x \to x$ ,  $y \to \sqrt{\varepsilon y}$  is made, then the equations become

$$\dot{x} = \varepsilon X_0(x) + \varepsilon X^*(t, x, y, \varepsilon),$$
  
 $\dot{y} = Ay + Y^*(t, x, y, \varepsilon),$ 

where  $X^*(t, x, y, 0) = 0$ ,  $Y^*(t, x, y, 0) = 0$ . If  $x \to x^0 + x$ ,  $y \to y$ , then Theorem IV.4.3 with the variable z absent applies directly to the resulting system to yield Theorem 3.4.

Using the same proof, one also obtains

Theorem 3.5. If X, Y satisfy the conditions enumerated after (3.14), are periodic in t or period T and there is an  $x^0$  such that  $X_0(x^0) = 0$  and  $\det[\partial X_0(x^0)/\partial x] \neq 0$ , then there are an  $\varepsilon_0 > 0$  and vector functions  $x^*(\cdot, \varepsilon)$ ,  $y^*(\cdot, \varepsilon)$  of dimensions n, m, respectively, satisfying (3.14), continuous on  $R \times [0, \varepsilon_0]$ , periodic in t of period T and  $x^*(\cdot, 0) = x^0$ ,  $y^*(\cdot, 0) = 0$ . Furthermore this solution is unique in a neighborhood of  $(x^0, 0)$ .

An interesting application of Theorem 3.4 to stability of linear systems is

Theorem 3.6. Suppose  $D=\operatorname{diag}(B,A)$  where B is  $n\times n$ , A is  $m\times m$ , all eigenvalues of B have simple elementary divisors and zero real parts and all eigenvalues of A have negative real parts. If the  $(n+m)\times (n+m)$  almost periodic matrix  $\Phi$  is partitioned as  $\Phi=(\Phi_{jk}), j, k=1, 2$ , where  $\Phi_{11}$  is  $n\times n$ ,  $\Phi_{22}$  is  $m\times m$  and if all eigenvalues of the matrix

(3.17) 
$$E = \lim_{T \to \infty} \frac{1}{T} \int_0^T e^{-Bt} \Phi_{11}(t) e^{Bt} dt,$$

have negative real parts, then there is an  $\varepsilon_0 > 0$  such that the system

$$\dot{u} = Du + \varepsilon \Phi(t)u,$$

is uniformly asymptotically stable for  $0 < \varepsilon \le \varepsilon_0$ . If one eigenvalue of E has a positive real part, then system (3.18) is unstable for  $0 < \varepsilon \le \varepsilon_0$ .

The proof of this result proceeds as follows. Let u = (x, y) where x is an n-vector. The matrix  $e^{Bt}$  is almost periodic in t and therefore the bounded linear transformation  $x \to e^{Bt}x$ ,  $y \to y$  yields the equivalent system

$$\begin{split} \dot{x} &= \varepsilon e^{-Bt} \Phi_{11}(t) e^{Bt} x + \varepsilon e^{-Bt} \Phi_{12}(t) y, \\ \dot{y} &= A y + \varepsilon \Phi_{21}(t) e^{Bt} x + \varepsilon \Phi_{22}(t) y. \end{split}$$

This is a special case of system (3.14) and the averaged system (3.15) for this situation is  $\dot{x} = Ex$ . From the hypothesis on E, this averaged system satisfies the hypotheses of Theorem 3.4. It is clear from uniqueness of the solution

x\*(-, e), y\*(-, e) guaranteed by Theorem 3.4 that x\*(-, e) = 0, y\*(-, e) = 0, 0::!g e < so. This proves the result.

The remainder of this chapter is devoted to applications of the results in this section.

### V.4. The Forced Van Der Pol Equation

Consider the equation

(4.1) 
$$\dot{z}_1 = z_2\,,$$
  $\dot{z}_2 = -z_1 + \varepsilon(1-z_1^2)z_2 + A\sin\omega_1 t + B\sin\omega_2 t,$ 

where e > 0, wi > 0, w2 > 0, A, ,8 are real constants and

$$(4.2) m + m_1 \omega_1 + m_2 \omega_2 \neq 0,$$

for all integers m, mi, m2 with ImI + Imi1 + Im2I < 4. For e = 0, the general solution of (4.1) is

$$\begin{aligned} z_1 &= x_1 \cos t + x_2 \sin t + A_1 \sin \omega_1 t + B_1 \sin \omega_2 t, \\ z_2 &= -x_1 \sin t + x_2 \cos t + A_1 \omega_1 \cos \omega_1 t + B_1 \omega_2 \cos \omega_2 t, \end{aligned}$$

where A,= A(1 - wl)-i, Bi = B(1 - w22 )-l and xi, x2 are arbitrary constants. To discuss the existence of almost periodic solutions of system (4.1) by using the results of the previous section, consider relations (4.3) as a transformation to new coordinates xi, X2. After a few straightforward calculations, the new equations for xi, x2 are

$$\dot{x_1} = -arepsilon (1-z_1^2)z_2\sin t, \ \dot{x_2} = arepsilon (1-z_1^2)z_2\cos t,$$

where zi, z2 are the complicated functions given in (4.3). System (4.4) is a special case of (3.1) and the quasi-periodic coefficients in the right hand sides of (4.4) have basic frequencies 1, wi, w2.

The average of the right hand side of (4.4) with respect to t will have different types of terms depending upon whether the frequencies 1, wi, w2 satisfy (4.2) or do not satisfy (4.2). If (4.2) is satisfied, then the averaged equations of (4.4) are

(4.5) 
$$8\dot{x}_1 = \varepsilon x_1[2(2-A_1^2-B_1^2)-(x_1^2+x_2^2)],$$
 
$$8\dot{x}_2 = \varepsilon x_2[2(2-A_1^2-B_1^2)-(x_1^2+x_2^2)].$$

Equations (4.5) always have the constant solution xi = x2 = 0 and both eigenvalues of the linear variational equation are 2(2 - Al - B2). If

A2 + Bi 2, then Theorem 3.1 implies the existence of an almost periodic solution of (4.4) with frequencies contained in the module of 1,wl, "2' which is zero for s = 0, is uniformly asymptotically stable if A 1 + Bi > 2 and unstable if A 1 + Bi < 2. This implies the original equation (4.1) has an almost periodic solution which is uniformly asymptotically stable (unstable) for A 2 + Bi > (<)2 and this solution for s = 0 is given by

$$z_1(t)=A_1\sin\,\omega_1 t+B_1\sin\,\omega_2\,t,$$
  $z_2(t)=\dot{z}_1(t).$ 

Notice that the condition A2 + A2 > 2 can be achieved if either A or B is sufficiently large for given wi, W2, or if either wi or w2 is sufficiently close to 1 (resonance) for a given A, B. Also, notice that A2 + A2 < 2 implies that the averaged equations have a circle of equilibrium points given by x2i+ x2 = 2(2 -A 2 2) 1 - Bi. There are very interesting oscillatory phenomena associated with this set of equilibrium points, but the discussion is much more complicated and is treated in the chapter on integral manifolds.

## V.5. Dufrmg's Equation with Small Damping and Small Harmonic Forcing

Consider the buffing equation

(5.1) 
$$\ddot{u} + \varepsilon \delta \dot{u} + u + \varepsilon \gamma u^3 = \varepsilon B \cos \omega t,$$

or the equivalent system

(5.2) u = v (v = -u - Equ3 - ESv + EB cos wt.

where E > 0, y, 8 >\_ 0, B, w 0 are real parameters. For w2 = 1 + Ef, we wish to determine conditions on the parameters which will ensure that equation (5.1) has a periodic solution of period 21r/w. Since for E = 0, co = 1, the forcing function has a frequency very close to the free frequency of the equation. The free frequency is the frequency of the periodic solutions of the equation (5.1) when s = 0. Such a situation is referred to as harmonic forcing. We have seen previously that the linear equation ii + it = cos t has no periodic solutions and in fact all solutions are unbounded. This is due to the resonance effect of the forcing function. As we will see, the nonlinear equation has some fascinating properties and, in particular, more than one isolated periodic solution may exist. Contrast this statement to the results of Section IV.5. To apply the results of Section 3, we make the van der Pol

transformation

(5.3) 
$$\begin{cases} u = x_1 \sin \omega t + x_2 \cos \omega t \\ v = \omega [x_1 \cos \omega t - x_2 \sin \omega t] \end{cases}$$

in (5.2) to obtain an equivalent system

(5.4) 
$$\begin{cases} \dot{x}_1 = \frac{\varepsilon}{\omega} [\beta u - \gamma u^3 - \delta v + B \cos \omega t] \cos \omega t \\ \\ \dot{x}_2 = -\frac{\varepsilon}{\omega} [\beta u - \gamma u^3 - \delta v + B \cos \omega t] \sin \omega t \\ \\ \beta = \frac{\omega^2 - 1}{\varepsilon}, \end{cases}$$

where u, v are given in (5.3). To average the right hand sides of these equations with respect to t, treating  $x_1, x_2$  as constant, it is convenient to let

(5.5) 
$$x_2 = r \cos \psi, \ x_1 = r \sin \psi,$$

$$u = x_1 \sin \omega t + x_2 \cos \omega t = r \cos (\omega t - \psi),$$

$$v = \omega[x_1 \cos \omega t - x_2 \sin \omega t] = -\omega r \sin(\omega t - \psi).$$

This avoids cubing u and complicated trigonometric formulas. The averaged equations associated with (5.4) are now easily seen to be

$$\dot{x}_1 = \frac{\varepsilon}{2\omega} \left[ \beta x_2 - \frac{3\gamma r^2}{4} x_2 - \delta\omega x_1 + B \right],$$

$$\dot{x}_2 = -\frac{\varepsilon}{2\omega} \left[ \beta x_1 - \frac{3\gamma r^2}{4} x_1 + \delta\omega x_2 \right],$$

$$r^2 = x_1^2 + x_2^2.$$

Since  $x_2 = r \cos \psi$ ,  $x_1 = r \sin \psi$ , the equilibrium points of (5.6) are the solutions of the equations

$$\left(eta-rac{3\gamma r^2}{4}
ight)r\cos\psi-\delta\omega r\sin\psi+B=0, \ \left(eta-rac{3\gamma r^2}{4}
ight)r\sin\psi+\delta\omega r\cos\psi=0.$$

These latter equations are equivalent to the equations

(5.7) 
$$G(r, \psi, \omega) \stackrel{\text{def}}{=} \omega^2 - 1 - \frac{3\gamma_0 r^2}{4} + \frac{F_0}{r} \cos \psi = 0,$$
$$F(r, \psi, \omega) \stackrel{\text{def}}{=} F_0 \sin \psi - \delta_0 \omega r = 0,$$

where we have put yo = ey, so = sS, Fo = eB, parameters which have a good physical interpretation in equation (5.1).

If yo, So , Fo are considered as fixed parameters in (5.7); then (5.7) can be considered as two equations for the three unknowns ,b, co, r.\_ If there exist 00, coo, ro such that the matrix

(5.8) 
$$\begin{bmatrix} \frac{\partial(rG)}{\partial r} & \frac{\partial(rG)}{\partial \psi} \\ \frac{\partial F}{\partial r} & \frac{\partial F}{\partial \psi} \end{bmatrix}$$

has rank 2 for r = ro, 0 \_ 00, w = wo, then Theorem 3.2 implies there is an eo > 0 such that equation (5.1) has a periodic solution of period 21r/wo which for e = 0 is given by u = ro cos(coo t - Rio) = ro cos(t - Oo) since coo = 1 for e = 0. In the equations (5.7), one usually considers the approximate amplitude r of the solution of (5.1) as a parameter and determines the frequency co(r) and approximate phase e (r) of the solution of (5.1) as functions of r. The plot in the co, r plane of the curve co(r) is called the frequency response curve.

The stability properties of the above periodic solution can sometimes be discussed by making use of Theorem 3.1. Some special cases are now treated in detail.

Case 1. S = 0 (No Damping). One solution of (5.7) for a = So = 0 is given by 0 = 0 and

(5.9) 
$$\omega^2 = 1 + \frac{3\gamma_0 r^2}{4} + \frac{F_0}{r}.$$

As mentioned earlier, relation (5.9) is called the frequency response curve. The rank of the matrix in (5.8) is two if yo = 0, Fo 0 0 or yo 0, Fo/yo sufficiently small. From Theorem 3.2, there is an CO > 0 such that for S = 0, 0 = a S eo, and each value of w, r which lies on the frequency response curve, there is a &rr/wperiodic solution of (5.1) which for e = 0 is u = r cos wt = r cos t since co = 1 for e = 0. There is also the solution of (5.7) corresponding to 0 = a, but this corresponds to (5.9) with r replaced by -r. The uniqueness property guaranteed by Theorem 3.2 and the equation (5.2) for S = 0 imply this solution is the negative of the one for +/i = 0.

If Fo < 0, the plots of the frequency response curves in a neighborhood of co = 1 for both the hard spring (yo > 0) and the soft spring (yo < 0) are given in Fig. 5.1. The pictures are indicative of what happens near w = 1.

The frequency response curves in Fig. 5.1 are usually plotted with Irl rather than r and are shown in Fig. 5.2. Notice how the nonlinearity (yo :0) bends the response curve for the linear equation. The curve F0 = 0 depicts the

![](_page_211_Figure_2.jpeg)

Figure V.5.1

relationship between the frequency co and the amplitude r of the periodic solutions of the 'unforced conservative system ii + u + yo u3 = 0. For each given w near w = 1, there is exactly one periodic solution of period 21;r/w. or a given F0 0 0, there are three such periodic solutions for some values of w and only one for others.

![](_page_212_Figure_2.jpeg)

Let us emphasize another striking property of this example which is a direct consequence of the fact that the equation is nonlinear. For e = 0, system (5.1) has a free frequency which is equal to 1; that is, all solutions of the linear equation are periodic of period 27r. On the other hand, it was shown above that for w2 - 1 of order e there are periodic solutions of period 27r/w.. In other words, the free frequency is suppressed and has been " locked " with the forcing frequency. This phenomena is sometimes referred to as the locking-in phenomena or entrainment of frequency and, of course, can only occur when the equations are nonlinear.

Case 2. 8 > 0 (Damping). If So > 0 and Fo = 0, then using the same analysis as in the discussion of equation (2.1), one sees that equation (5.1) has no periodic solution except u = 0. This is reflected also in equations (5.7) which in this case, have no solution except r = 0. If So Fo 0, there always exist values of r such that Iri < I Fo/So wl and the second of equations (5.7) can be solved for :/s as a function of w6or/Fo. Using such a 0, the first equation yields, up to terms of order e2,

(5.10) 
$$\omega^2 = 1 + \frac{3\gamma_0 r^2}{4} \pm \sqrt{\frac{F_0^2}{r^2} - \delta_0^2}.$$

This frequency response curve for the hard spring (yo > 0) is shown in Fig. 5.3. The dotted line corresponds to the curve cue = 1 + 3yo r2/4. Thus, as for S = 0, for given Fo, So with F0 So 0, Theorem 3.2 implies there are three periodic solutions of period 27r/w for some values of w and only one for others. For a given w, which of these solutions are stable and which are unstable? To discuss this, we investigate the linear variational equation associated with these equilibrium points of the averaged equations and apply Theorem 3.1. As is to be expected the analysis will be complicated. Another type of coordinate system which is widely used in applying the method of averaging turns out to be useful for this discussion.

![](_page_213_Figure_3.jpeg)

Figure V.5.3

In (5.2), introduce new variables r, t/i by the relations

(5.11) 
$$u = r \cos(\omega t - \psi),$$

$$v = -r\omega \sin(\omega t - \psi),$$

to obtain an equivalent set of equations (Ep = w2 - 1)

(5.12) 
$$\dot{r} = \frac{1}{\omega} \left[ -\frac{\varepsilon \beta}{2} \sin 2(\omega t - \psi) - \varepsilon f \sin(\omega t - \psi) \right],$$

$$\dot{\psi} = \frac{1}{\omega} \left[ \frac{\varepsilon \beta}{2} + \frac{\varepsilon \beta}{2} \cos 2(\omega t - \psi) + \frac{\varepsilon}{r} f \cos(\omega t - \psi) \right],$$

where f = -yu3 - Sv + B cos wt and it, v are given in (5.11). The averaged equations associated with (5.12) are

(5.13) 
$$\dot{r} = -\frac{1}{2\omega} \left[ \varepsilon \delta \omega r - \varepsilon B \sin \psi \right] = \frac{1}{2\omega} F(r, \psi, \omega),$$

$$\dot{\psi} = \frac{1}{2\omega} \left[ \varepsilon \beta - \frac{3}{4} \varepsilon \gamma r^2 + \frac{\varepsilon B}{r} \cos \psi \right] = \frac{1}{2\omega} G(r, \psi, \omega),$$

where F, G are defined in (5.7). The equilibrium points of (5.13) are therefore the solutions r, 0, w of (5.7). If the eigenvalues of the coefficient matrix of the linear variational equation of any such equilibrium point have nonzero real parts, then Theorem 3.1 gives not only the existence but the stability properties of a periodic solution of period 2ir/w of (5.1). The solution is uniformly asymptotically stable if these eigenvalues have negative real parts and unstable if one has a positive real part. A necessary and sufficient condition for the eigenvalues of this matrix to have negative real parts is that the trace of this matrix be negative and the determinant be positive. In terms of F, Gin (5.13), one has an asymptotically stable solution if and only if

$$F_r + G_{\psi} < 0,$$
  $F_r G_{\psi} - F_{\psi} G_r > 0,$ 

where the subscripts denote partial derivatives and, of course, the functions are evaluated at the equilibrium point. These partial derivatives are easily seen to be

$$egin{align} F_r &= -\delta_0 \, \omega, \; F_\psi = F_0 \cos \psi, \ & \ G_r &= -rac{3}{2} \, \gamma_0 r - rac{F_0}{r^2} \cos \psi, \; G_\psi = -rac{F_0}{r} \sin \psi. \ & \ \end{array}$$

Therefore, Fr + Gy, \_ -250 w < 0 at an equilibrium point and the stability or instability can be decided by investigating the sign of F,. G,, - Or F. as long as it is different from zero.

It is possible to express this last condition for stability in terms of where the point r, co is situated on the frequency response curve. To see this, consider the equilibrium points of (5.13); that is, the solutions of F(r, 0, w) = 0 = G(r, 0, co), as functions of co. Differentiating these equations with respect to a. and letting subscripts denote differentiation, one obtains

$$-F_{\omega} = F_r r_{\omega} + F_{\psi} \psi_{\omega},$$
  
 $-G_{\omega} = G_r r_{\omega} + G_{\psi} \psi_{\omega},$ 

and thus,

$$(5.14) r_{\omega}(F_r G_{\psi} - G_r F_{\psi}) = G_{\omega} F_{\psi} - F_{\omega} G_{\psi}.$$

The stability properties of the solution can therefore be translated into the sign of rw(Gw Fw - F. O v). This expression being positive corresponds to stability and this being negative corresponds to instability. Since F. = -S0 r, Gw = 2w, it follows that

$$egin{align} G_{\omega}\,F_{arphi}-F_{\omega}\,G_{arphi}&=2\omega F_0\cos\psi+\delta_0\,F_0\sin\psi\ &=2\omega r(
u^2-\omega^2)+\delta_0^2\,\omega r. \end{gathered}$$

where v2 = I + 3yo r2/4. From (5.10), w2 - v2 = 0(e) and since So is 0(e2), the sign of this expression is determined by w2 - v2 if a is sufficiently small. Using (5.14), we finally have:

A periodic solution of Duf ng's equation (5.1) with 8 > 0 is stable if (dr/dw) (v2 - (02) > 0 and unstable if (dr/dw)(v2 - w2) < 0, where v2 = 1 + 3yo r2/4 and r is given as a function of co by the frequency response curve (5.10).

Pictorially, the situation is shown in Fig. 5.4 for a hard spring. Solid black dots represent unstable points. The arrows - represent a typical manner in which the amplitude of the stable periodic motion would change with increasing w and the backward F- depicts the situation for decreasing w.

![](_page_215_Figure_5.jpeg)

Figure V.5.4

## V.6. The Subharmonic of Order 3 for Duffling's Equation

Consider the equation

(6.1) 
$$\ddot{u} + \varepsilon c \dot{u} + \frac{1}{9} u + \varepsilon \gamma u^3 = B \cos \omega t$$

or the equivalent system

(6.2) 
$$\dot{u}=v,$$
 
$$\dot{v}=-\frac{1}{9}u-\varepsilon cv-\varepsilon \gamma u^3+B\cos\omega t,$$

where e >\_ 0, c >\_ 0, y, B and, co are constants, w -1 = 0(e) as e -\* 0. The problem is to determine under what conditions there exists a solution of (6.1) which is periodic of period 667r/w and whose zeroth order terms in s are given by

(6.3) 
$$u = r \sin\left(\frac{\omega}{3}t + \phi\right) + A \cos \omega t,$$
$$v = \frac{\omega}{3} r \cos\left(\frac{\omega}{3}t + \phi\right) - \omega A \sin \omega t.$$

Such a solution if it exists is called a subharmonic solution of order 3. If any such solution exists, then clearly A must equal  $-B/(\omega^2-1/9)$ . The free frequency of equation (6.1) is (1/3) and the forcing frequency is  $\omega$  which is approximately 1. Therefore, if a subharmonic solution exists, then the free frequency is again suppressed and is locked with the forcing frequency  $\omega$  in the sense that a solution appears which is periodic of period three times the period of the forcing frequency. The form of (6.1) is important for the existence of a subharmonic solution. In fact, if the damping coefficient in (6.1) is a constant  $\varepsilon_1 > 0$  for all  $\varepsilon \ge 0$ , then it was shown in Section IV.5 that no such subharmonic solution can exist.

If  $r, \phi$  in (6.3) are chosen as new coordinates, the new equations are

$$\begin{aligned} \dot{r} &= \frac{\varepsilon}{\omega} \left[ \frac{\beta}{6} \, r \sin 2 \left( \frac{\omega}{3} \, t + \phi \right) - 3 (cv + \gamma u^3) \, \cos \left( \frac{\omega}{3} \, t + \phi \right) \right], \\ \dot{\phi} &= \frac{\varepsilon}{\omega} \left[ -\frac{\beta}{3} \sin^2 \left( \frac{\omega}{3} \, t + \phi \right) + 3 \, \frac{(cv \, + \, \gamma u^3)}{r} \, \sin \left( \frac{\omega}{3} \, t + \phi \right) \right], \\ \omega^2 &- 1 = \varepsilon \beta, \end{aligned}$$

where u, v are given in (6.3).

The averaged equations are (except for some terms of order  $\varepsilon^2$ )

(6.5) 
$$\dot{r} = \frac{\varepsilon r}{2\omega} \left[ -c + \frac{27\gamma rA}{2} \cos 3\phi \right],$$

$$\dot{\phi} = \frac{\varepsilon}{6\omega} \left[ -\beta + \frac{27\gamma A}{2} (A - r\sin 3\phi) + \frac{27\gamma r^2}{4} \right]$$

Using the fact that  $\omega^2 - 1 = \varepsilon \beta$  and letting  $\gamma_0 = \varepsilon \gamma$ ,  $c_0 = \varepsilon c$ , the equations for the equilibrium points of (6.5) are

(6.6) (a) 
$$\cos 3\phi = \frac{2c}{27\gamma Ar}$$
,  
(b)  $\omega^2 = 1 + \frac{27\gamma_0}{4} [r^2 + 2A^2] \mp \left[ \left( \frac{27\gamma_0 Ar}{2} \right)^2 - c_0^2 \right]^{1/2}$ ,

where up to terms of order  $\varepsilon^2$ , the latter expressions are evaluated with A = -9B/8. For c = 0 (no damping), the formula for the frequency response

curve (6.6b) simplifies to

(6.7) 
$$\omega^2 = 1 + \frac{27\gamma_0 A^2}{4} + \frac{27\gamma_0}{4} (r \pm A)^2.$$

A sketch of the frequency response curves is given in Fig. 6.1.

![](_page_217_Figure_5.jpeg)

Figure V.6.1

One now uses Theorem 3.2 and Theorem 3.1 exactly as in the previous section to obtain the existence of an exact solution of (6.1) and the stability properties of such a solution for values of  $\omega$ , r,  $\varphi$  satisfying (6.6).

The frequency response curves suggest the fact confirmed in Section IV.5 that the equation (6.1) may not have a subharmonic of order 3 if c gets too large, since the above analysis has been shown to be valid only for  $\varepsilon$  small and, thus,  $\omega$  close to 1. Also, notice that once a subharmonic solution is known to exist, two other distinct ones are obtained simply by translating time by  $2\pi/\omega$ .

#### V.7. Damped Excited Pendulum with Oscillating Support

A linear damped sinusoidally excited pendulum with a rapidly vertically oscillating support of small amplitude can be represented approximately by the equation

(7.1) 
$$\ddot{u} + c\dot{u} + \left(1 + \varepsilon \frac{d^2h(\nu t)}{dt^2}\right) \sin u - F \cos \omega t = 0,$$

where u is the angular coordinate measured from the bottom position,  $h(\tau) = h(\tau + 2\pi)$ ,  $\nu = \varepsilon^{-1}$ ,  $0 < \varepsilon \leqslant 1$  and c, F,  $\omega$  are real positive parameters independent of  $\varepsilon$ .

To transform (7.1) into a form (3.10) for which Theorem 3.3 is applicable,

it is convenient to treat all but the term in c as derivable from the Hamiltonian

(7.2) 
$$H(v, u, t) = \frac{1}{2} \left[ v^2 - 2\varepsilon v \frac{dh}{dt} \sin u - \varepsilon^2 \left( \frac{dh}{dt} \right)^2 \cos^2 u \right] + (1 - \cos u) - uF \cos \omega t,$$

where v is the momentum conjugate to u and the argument of h is vt. The equations of motion are, therefore,

(7.3) 
$$\dot{u} = v - \varepsilon \frac{dh}{dt} \sin u,$$

$$\dot{v} = -\left[ -\varepsilon v \frac{dh}{dt} \cos u + \frac{\varepsilon^2}{2} \left( \frac{dh}{dt} \right)^2 \sin 2u + \sin u - F \cos \omega t \right]$$

$$-c \left( v - \varepsilon \frac{dh}{dt} \sin u \right),$$

where the argument of h is  $\nu t$ .

If  $\nu t = \tau$  and differentiation with respect to  $\tau$  is denoted by prime, then equations (7.3) become

(7.4) 
$$u' = \varepsilon[v - h' \sin u],$$

$$v' = \varepsilon \left[ vh' \cos u - \frac{1}{2} (h')^2 \sin 2u - \sin u - cv + ch' \sin u \right] + \varepsilon F \cos \varepsilon \omega \tau.$$

where the argument of h is  $\tau$ . Equations (7.4) are a special case of the system (3.10), the expressions in the square brackets being periodic in fast time  $\tau$  and the other expression is periodic in the slow time  $\varepsilon\tau$ .

Considering the special case where  $h(\tau) = A \sin \tau$  and A is a constant, the averaged equations (3.11) corresponding to equations (7.4) are

(7.5) 
$$u' = \varepsilon v,$$
 
$$v' = -\varepsilon \left[ \frac{A^2}{2} \sin u \cos u + \sin u + cv \right] + \varepsilon F \cos \varepsilon \omega \tau.$$

In terms of the original time t, these equations are equivalent to the equation

(7.6) 
$$\dot{u} = v,$$
  $\dot{v} = -\left(1 + \frac{A^2}{2}\cos u\right)\sin u - cv + F\cos \omega t,$ 

or the single second order equation

(7.7) 
$$\ddot{u} + c\dot{u} + \left(1 + \frac{A^2}{2}\cos u\right)\sin u = F\cos\omega t.$$

If equation (7.7) has a periodic solution of period  $2\pi/\omega$  such that the characteristic exponents of its linear variational equation have negative real parts, then Theorem 3.3 implies the original equation (7.1) has an asymptotically stable, almost periodic solution which approaches this solution as  $\varepsilon \to 0$ . To find conditions under which (7.7) has such a periodic solution, one can use the results of Chapter IV or the method of averaging (Theorems 3.1 and 3.2) directly on (7.7). For example, if F is small, one can use the results of Chapter IV very efficiently as follows: For F=0, the equilibrium solutions of (7.7) are u=0,  $u=\pi$  and  $u=\cos^{-1}(2/A^2)$  if  $A^2>2$ . If  $u=\pi+w$ , then (7.7) becomes

(7.8) 
$$\ddot{w} + c\dot{w} + \left(\frac{A^2}{2}\cos w - 1\right)\sin w = F\cos \omega t,$$

and this may be rewritten as

$$\ddot{w}+c\dot{w}+\Big(rac{A^2}{2}-1\Big)w=F\cos\omega t+\Big(rac{A^2}{2}-1\Big)(w-\sin w) \ +rac{A^2}{2}\left(1-\cos w\right)\sin w.$$

If  $A^2/2 > 1$  and F is small, this equation satisfies the conditions of Theorem IV.2.1 and Theorem IV.3.1. One can therefore assert the existence of an asymptotically stable periodic solution of (7.8) of period  $2\pi/\omega$ . This implies in turn that the pendulum described by (7.1) can execute stable motions in a neighborhood of the upright position.

#### V.8. Exercises

EXERCISE 8.1. An infinite conductor through which there flows a current of magnitude I attracts a conductor AB of length l and mass m along which there flows a current i. In addition, the conductor AB is attracted by a spring C whose force of attraction is proportional to its deflection with proportionality constant k. With x=0 chosen as the position of AB when the spring is undeflected, the equations of motion of AB are

(8.1) 
$$\dot{x} = y, \ \dot{y} = -\frac{k}{m} \left( x - \frac{\lambda}{a - x} \right),$$

where  $\lambda = 2Iil/k$ . Discuss the behavior of the solutions of this equation along the lines of example 1.3.

EXERCISE 8.2. For  $c>0,\,h>0,\,\omega-1=0(\varepsilon)$  as  $\varepsilon\to0,\,$  find the periodic solutions of

(8.2) 
$$\ddot{x} + x = \varepsilon \left[ -c\dot{x} + hx^3 + x\cos 2\omega t \right].$$

Plot the frequency response curves, find the intervals on the  $\omega$ -axis for which

there are one, two and three periodic solutions and discuss the stability properties of these solutions.

EXERCISE 8.3. The equation of a plane pendulum with vertically oscillating sinusoidal support can be written as

(8.3) 
$$\ddot{\theta} + c\dot{\theta} + \frac{g - I\omega^2 \sin \omega t}{I} \sin \theta = 0.$$

If  $\tau = \omega t$ ,  $I/l = \varepsilon$ ,  $\varepsilon^2 k^2 = g/l\omega^2$ ,  $c/\omega = 2\varepsilon \alpha$  we have

$$\theta'' + 2\varepsilon\alpha\theta' + (\varepsilon^2k^2 - \varepsilon\sin\tau)\sin\theta = 0, \qquad = d/d\tau.$$

Show that the system for  $\varepsilon$  small has periodic solutions of period  $2\pi/\omega$  when  $\theta$  is in the neighborhood of either 0,  $\pi$  or  $2\pi$  and  $\cos^{-1}(-2k^2)$ . Determine the stability properties as functions of  $\alpha$  and k. Introduce variables  $\phi$  and  $\Omega$  by

$$\theta = \phi - \varepsilon \sin \tau \sin \phi,$$
  
 $\theta' = \varepsilon \Omega - \varepsilon \cos \tau \sin \phi.$ 

and use averaging.

EXERCISE 8.4. Consider the second order system

(8.4) 
$$\ddot{x} + x = \varepsilon [f(x) - c\dot{x} + \sin \omega t],$$

where c>0,  $0<\varepsilon\ll 1$ , f(x) is a continuous function of x and  $\omega-1=O(\varepsilon)$ . For  $\varepsilon$  small, determine  $\omega$  so that the equation has periodic solutions of period  $2\pi/\omega$ . Determine the expression for the approximate frequency response. Study the stability of the solutions. Show that if  $\gamma=\varepsilon^{-1}(\omega^2-1)$  then the periodic solutions are asymptotically stable if c>0 and

$$\frac{da}{d\gamma}[\gamma+G(a)+O(\varepsilon)]<0,$$

where  $G(a) = (1/\pi a) \int_0^{2\pi} f(a \cos \phi) \cos \phi \, d\phi$ . Use the transformation  $x = A(t) \cos (\omega t + \Theta(t))$ ,  $\dot{x} = -\omega A(t) \sin (\omega t + \Theta(t))$ . Note that  $\gamma + G(a) = 0$  is the approximate relationship between the amplitude and frequency of the periodic motion of the autonomous problem with c = 0.

## V.9. Remarks and Suggestions for Further Study

The results of Section 1 on conservative systems are extremely simple but at the same time not very informative except for dimension 2. For high dimensional conservative systems, the theory has been and will continue to be a challenge for many years to come. Recently, Palmore [1] and Palamodov [1] have proved H(p,q) = p'p/2 + V(q) real analytic and q not a minimum of V

implies the equilibrium point (0,0) is unstable. Laloy [1] gave a simple example showing this result is false if one only assumes V is C°°. For further references on this problem, see Rouche, Habets and Laloy [1]. For other fascinating aspects of conservative systems, see Poincare [2] , Birkhoff [1] , Kolmogorov [1] , Arnol'd [2] , Moser [13] , Siegel and Moser [1] .

The method of averaging of Section 3 evolved from the famous paper of Krylov and Bogoliubov [1] and is contained in the book of Bogoliubov and Mitropolski [1]. The basic Lemma 3.1 is due to Bogoliubov [1]. Theorem 3.3 as well as the example in Section 7 are due to Sethna [1]. There are many variants of the method of averaging and the reader may consult Mitropolski [1] and Morrison [1] for further discussion as well as additional references. Other illustrations of equations which exhibit interesting oscillatory phenomena may be found in the books of Bogoliubov and Mitropolski [1], Malkin [2], Minorsky [1], Andronov, Vitt and Khaikin [1], Hale [7].

## CHAPTER VI

## Behavior Near a Periodic Orbit

In Section III.6 and Chapter IV, a rather extensive theory of the behavior of solutions of a system (and perturbations of a system) near an equilibrium point has been developed. In this and the following chapter, we consider the same questions except for a more complicated invariant set; namely, a closed curve.

Suppose u: R - Rn is a periodic function of period w which is continuous together with its first derivative, du(9)/df zA0 for all 0 in (-oo, oo) and u: [0, co) -\* Rn is one-to-one. If

(1) 
$$\Gamma = \{x \in R^n : x = u(\theta), \qquad 0 \le \theta \le \omega\},$$

then F is a closed curve and is actually a Jordan curve.

Suppose f : Rn -- Rn is continuous and satisfies enough smoothness properties to ensure that a unique solution of

$$\dot{x} = f(x)$$

passes through any point in Rn.

Throughout this chapter, it will be assumed that the curve F is invariant with respect to the solutions of (2); that is, any solution of (2) with initial value on r remains on I' for all tin (-co, oo). If r is a periodic orbit of (2-), then there is a periodic solution 0(t) of (2) such that

$$\Gamma = \{x : x = \phi(t), \quad -\infty < t < \infty\}.$$

In this case, we may choose the parametric representation of r to be given by the function ; that is, we may choose u = 0. For periodic orbits, such a parametric representation always will be chosen in the sequel. If r is not a periodic orbit, then it must contain equilibrium points and orbits whose and w-limit sets are equilibrium points.

From the previous remarks, if x\*(t), - oo < t < oo, is any solution of (2) with x\*(0) in r, then there are three possibilities: (i) there is a r > 0 such that x\*(t) is periodic of least period -r, (ii) x\*(t) is an equilibrium point; (iii) x\*(t) has its a- and w-limit sets as equilibrium points. In the first case, the curve r can be represented parametrically by x = x\*(0), 0 <\_ 0 <T and any solution of (2) on P [such a solution must be x\*(t + a) for some constant a] defines a function 0(t), -co < t < co, such that B = 1. In either case (ii) or (iii) any solution x\*(t) of (1) on P defines a continuously differentiable function 0(t) \_ u-1(x\*(t)), - co < t < co, and B = g(8) where g(0) = [8u-1(u(0))/8x] f (u(8)) = [du(0)1d0]-1f (u(0)). In particular, in case (ii), there must be a zero of g(0). In all three cases, we can, therefore, assert the existence of a continuous function g(0) such that

(3) 
$$\frac{du(\theta)}{d\theta}g(\theta) = f(u(\theta)), \quad g(\theta + \omega) = g(\theta), \quad 0 \leq \theta \leq \omega.$$

Furthermore, if r is generated by a periodic solution of (2), then g(0) can be taken -1 and if P contains an equilibrium point of (2), there must be a zero of g(0).

In this chapter, our main concern is the behavior of the solutions of (2) near a periodic orbit (sufficient conditions for stability and the saddle point property) and the existence of a periodic orbit for the system

$$\dot{x} = f(x) + F(x, t),$$

for the case in which F is a small perturbation independent of t. In the next chapter, the discussion will allow r to be an arbitrary invariant curve and the perturbations F to depend on t. In both cases, the first step will be the introduction of a convenient coordinate system in a neighborhood of P. Such a coordinate system is introduced in this chapter.

## VI.1, A Local Coordinate System about an Invariant Closed Curve

By a moving orthonormat system along P is meant an orthonormal coordinate system {e,(0), ..., en(0)} in Rn for each 0 in [0, w] which is periodic in 0 of period w and one of the ej(0) is equal to [du(O)/dO]/ Jdu(0)/d0J.

The first objective is to show there are moving orthonormal systems for P. For this purpose, the following lemma is needed.

LEMMA 1.1. If n',?: 3 and v(0) is a unit vector in Rn which has period w and satisfies a lipschitz condition, then there exists a unit vector e (independent of 0) such that v(O) =,;4-- ±6 for all 0.

PROOF. This lemma is a consequence of well known facts from real variables. In fact, the set x = v(0), Jv(0)J = 1, 0 < 0 < w, is a curv'on the unit sphere Sn-1 in Rn. Since v(0) is lipschitzian, this curve is rectifiable and a rectifiable curve on a sphere in Rn, n > 3, covers a set of measure zero. Therefore, there always exists a vector 6 in Sn-1 which is not on this curve or the curve defined by -v(O).

Rather than invoke this result, a proof is given here. If S is any set on the unit sphere in Rn of diameter <d, then there is a constant K (independent of S) and a spherical cap S, such that S e S, and the area of S, is less than Kdn-1. If M is the lipschitz constant for v; that is, I v(0) - v(O')I < MI 0 - 0'1, and if the interval [0, w) is divided into N equal parts, then the curve defined by v(8), 0 < 0 < w, may be covered by spherical caps whose total area is less than NK(Mw/N)n-1. Similarly, the curve defined by -v(0), 0 5 0 <w may be covered by spherical caps whose total area is less than the same quantity. Since n >\_ 3, this upper bound on the area approaches zero as N -\* 00, which implies that the vector e can be chosen from " almost " any place on the unit sphere. This proves the lemma.

For the statement of the next result, let'P(R, Rn) designate the space of functions taking R -. Rn which are continuous together with all derivatives up through order p.

THEOREM 1.1. If u e'P(R, Rn), p >\_ 2, u(0 + w) = u(O), ->O, du(0)/d0 0, 0 < 0 < w, and r is defined in (1), then there is a moving orthonormal system along r which is 'P-'(R, Rn).

PROOF. Suppose n >\_ 3. If v(0) = [du(0)/dO]/ Jdu(0)/d0J, then the hypotheses on u imply that v is periodic of period w and lipschitzian. Let eI be a constant unit vector (the existence of which is assured by Lemma 1.1) such that el = ± v(0), 0 < 0 < co. Adjoin to el any constant vectors e2, ..., en such that {el, ..., en} is an orthonormal basis for Rn. The moving orthonormal system along r is then obtained in the following manner: let S be the (n - 2) dimensional subspace of Rn orthogonal to the plane formed by el and v(0). Rotate the coordinate system about S in the positive sense until el coincides with v(0) (see Fig. 1.1). If e2(0), ... , n(0) are the rotated positions of e2, ... , e' n, then the moving orthonormal system is given by

$$(1.1) \{v(\theta), \, \xi_2(\theta), \, \ldots, \, \xi_n(\theta)\}, \quad 0 \leq \theta \leq \omega.$$

If Y1(O), j = 1, 2, ..., n, are the direction angles of v(0), e1 v(0) = cos y1(B), j = 1, 2, ... , n then one can show that the vectors are given by

$$(1.2) \hspace{1cm} \xi_j(\theta) = e_j - \frac{\cos\gamma_j(\theta)}{1+\cos\gamma_1(\theta)} \, (e_1+v(\theta)), \hspace{0.5cm} j=2,3,\ldots,n.$$

The derivation of (1.2) proceeds as follows. Suppose

$$e_j = \bar{e}_j + \lambda_j e_1 + \mu_j v_j$$

where e1 belongs to S. The final position of e1 is then

$$\xi_j = \bar{e}_j + \lambda_j' e_1 + \mu_j' v,$$

![](_page_225_Picture_2.jpeg)

Figure VI.1.1

where A', µ' are determined from A1,µ, by a rotation in the e1, v plane by an angle y1 with cos y1 = Therefore

$$\lambda_j' = -\mu_j \,, \qquad \mu_j' = \lambda_j + 2\mu_j \cos \gamma_1 ,$$

and

$$\xi_j = e_j - (\lambda_j + \mu_j)e_1 + [\lambda_j + \mu_j(2\cos\gamma_1 - 1)]v.$$

Since S is orthogonal to e1, v, it follows that

$$e_1 \cdot [e_j - \lambda_j e_1 - \mu_j v] = 0,$$
  
 $v \cdot [e_j - \lambda_j e_1 - \mu_j v] = 0,$ 

and this implies

$$\lambda_j = -rac{\cos\gamma_1\cos\gamma_j}{\sin^2\gamma_1}, \qquad \mu_j = rac{\cos\gamma_j}{\sin^2\gamma_1}.$$

Substituting in the expression for 61, one obtains (1.2).

For the case n = 2, the moving orthonormal system is easily constructed as

$$(1.3) (v(\theta), \, \xi_2(\theta)), \quad \xi_2(\theta) = \pm (-v_2(\theta), \, v_1(\theta)),$$

where the coordinates of v are v1, v2 .

The explicit formulas (1.1)-(1.3) for the moving orthonormal system

along r clearly imply that the system is 'P-1(R, Rn) if u is'P(R, Rn). This completes the proof of the theorem.

Once a moving orthonormal system along a closed curve r is known, it is possible to use this system to obtain a coordinate system for a "tube " around r. In fact, with u(0) as in Theorem 1.1, v(0) = [du(0)/d0]/ Jdu(0)/d0J, let (v, e2 , ... , 6n) be a moving orthonormal system along r. Consider the transformation of variables taking x into (0, p), p = COl(p2, ... , pn) given by

(1.4) 
$$x = u(\theta) + Z(\theta)\rho, \qquad Z = [\xi_2, \ldots, \xi_n], \qquad 0 \leq \theta < \omega.$$

The matrix Z is the n x (n - 1) dimensional matrix whose columns are the vectors 62 , ... , 6. .

To show that this transformation is well defined in a sufficiently small neighborhood of r, that is, p sufficiently small, let

$$F(x, \theta, \rho) \stackrel{\text{def}}{=} u(\theta) + Z(\theta)\rho - x.$$

The partial derivatives of F with respect to 0, p are

$$rac{\partial F}{\partial heta} = rac{du( heta)}{d heta} + rac{dZ( heta)}{d heta} 
ho,$$

$$\frac{\partial F}{\partial \rho} = Z(\theta).$$

For p = 0, det[8F/80, 8F/8p] = Jdu(0)/d0J det[v(0), Z(0)] 0 0 for 0 <\_ 0 <\_ w since du(0)/d0 0 for all 0 and v(0), Z(0) is a moving orthonormal system. Therefore, there is a 8 > 0 independent of 0 such that det[8F/80, 8F/8p] 0 0 for JpJ < 8, 0 < 0 < co. Since the closed curve r is compact, a finite number of applications of the implicit function theorem shows that (1.4) is a well defined transformation for 0 < 1p < pi, pi > 0, 0 < 0 < w.

We now make the transformation (1.4) on the differential equation (4) using the fact that u satisfies (3) to obtain new differential equations for 0, p. It is assumed that f has continuous first derivatives with respect to x and u satisfies the conditions of Theorem 1.1.

If 
$$x(t) = u(\theta(t)) + Z(\theta(t))\rho(t)$$
 satisfies (4), then

$$(1.5) \quad \left[\frac{du(\theta)}{d\theta} + \frac{dZ(\theta)}{d\theta}\rho\right]\dot{\theta} + Z(\theta)\dot{\rho} = f(u(\theta) + Z(\theta)\rho) + F(t, u(\theta) + Z(\theta)\rho).$$

In a pi-neighborhood rp, of r, the coefficient matrix of 6, p is nonsingular. Therefore, equation (1.5) can be solved for O, p as a function of 0, p, t. The explicit form of the equations are obtained as follows. Using (4) and projecting both sides of (1.5) onto v(0), one obtains

$$(1.6) \qquad \dot{\theta} = g(\theta) + f_1(\theta, \rho) + h'(\theta, \rho)F(t, u(\theta) + Z(\theta)\rho),$$

where h' is the transpose of h,

$$(1.7) h(\theta, \rho) = \left[ \left| \frac{du(\theta)}{d\theta} \right| + v'(\theta) \frac{dZ(\theta)}{d\theta} \rho \right]^{-1} v(\theta),$$

$$f_1(\theta, \rho) = -h'(\theta, \rho) \frac{dZ(\theta)}{d\theta} \rho g(\theta) + h'(\theta, \rho) [f(u(\theta) + Z(\theta)\rho) - f(u(\theta))],$$

By projecting both sides of (1.5) onto  $Z(\theta)$ , and using the fact that  $Z'(\theta)f(u(\theta))=Z'(\theta)g(\theta)\ du(\theta)/d\theta=0$ , where Z' is the transpose of Z, one obtains

$$(1.8) \quad \dot{\rho} = A(\theta)\rho + f_2(\theta, \rho) + Z'(\theta) \left[ I - \frac{dZ(\theta)}{d\theta} \rho h'(\theta, \rho) \right] F(t, u(\theta) + Z(\theta)\rho).$$

where Z' is the transpose of Z and

$$(1.9) A(\theta) = Z'(\theta) \left[ -\frac{dZ(\theta)}{d\theta} g(\theta) + \frac{\partial f(u(\theta))}{\partial x} Z(\theta) \right],$$

$$f_2(\theta, \rho) = -Z'(\theta) \frac{dZ(\theta)}{d\theta} \rho f_1(\theta, \rho)$$

$$+ Z'(\theta) \left[ f(u(\theta) + Z(\theta)\rho) - f(u(\theta)) - \frac{\partial f(u(\theta))}{\partial x} Z(\theta)\rho \right].$$

From the above expressions for these functions, it is easily seen that  $f_1(\theta, \rho)$ ,  $f_2(\theta, \rho)$  have continuous partial derivatives with respect to  $\rho$  up through order  $k \ge 1$  if f(x) has continuous partial derivatives with respect to x up through order  $k \ge 1$ . Furthermore,  $f_1(\theta, \rho) = O(|\rho|)$  as  $\rho \to 0$  and  $f_2(\theta, 0) = 0$ ,  $\partial f_2(\theta, 0)/\partial \rho = 0$ . The number of derivatives of these functions with respect to  $\theta$  is one less than the minimum of the derivatives of f and  $du(\theta)/d\theta$ . Also, the equations in  $\theta$ ,  $\dot{\rho}$  contain F in a linear fashion multiplied by matrices which have an arbitrary number of derivatives with respect to  $\rho$  and (p-1) derivatives with respect to  $\theta$  if u has p derivatives with respect to  $\theta$ . These results are summarized in

Theorem 1.2. If u satisfies the conditions of Theorem 1.1 with  $p \ge 2$  and  $f \in \mathscr{C}^{p-1}(\mathbb{R}^n, \mathbb{R}^n)$ , then there exist a  $\delta > 0$ , n-vectors  $f_2(\theta, \rho)$ ,  $h(\theta, \rho)$  a scalar  $f_1(\theta, \rho)$ , an  $(n-1) \times (n-1)$  matrix  $A(\theta)$  and an  $(n-1) \times n$  matrix  $B(\theta, \rho)$  with all functions being periodic in  $\theta$  of period  $\omega$  and having continuous derivatives of order p-1 with respect to  $\rho$  and p-2 with respect to  $\theta$  for  $0 \le |\rho| \le \delta$ ,  $-\infty < \theta < \infty$ ,

(1.10) 
$$f_1(\theta, \rho) = O(|\rho|) \quad \text{as } |\rho| \to 0,$$
 
$$f_2(\theta, 0) = 0, \frac{\partial f_2(\theta, 0)}{\partial \rho} = 0,$$

such that the transformation (1.4) applied to equation (4) for  $|\rho| \leq \delta$  yields the equivalent system,

(1.11) 
$$\dot{\theta} = g(\theta) + f_1(\theta, \rho) + h'(\theta, \rho) F(t, u(\theta) + Z(\theta)\rho),$$

$$\dot{\rho} = A(\theta)\rho + f_2(\theta, \rho) + B(\theta, \rho) F(t, u(\theta) + Z(\theta)\rho),$$

where  $g(\theta)$  is given in (3).

#### VI.2. Stability of a Periodic Orbit

In this section, the case is discussed in which the closed curve  $\Gamma$  is generated by a nonconstant  $\omega$ -periodic solution  $x^0$  of (2) and f has continuous first derivatives with respect to x. As mentioned before, we can assume that the parametric representation of  $\Gamma$  is  $x=x^0(\theta),\ 0\leq \theta<\omega$ ; that is, u can be chosen as  $x^0$  and u satisfies (3) with  $g(\theta)=1$  for  $0\leq \theta\leq \omega$ . Since f(x) has continuous first derivatives in x, the function  $u(\theta)$  has continuous second derivatives in  $\theta$ . In terms of the local coordinate system (1.4), the behavior of the solutions of (2) near  $\Gamma$  are given by the solutions of the differential system

(2.1) 
$$\dot{ heta} = 1 + f_1( heta, 
ho),$$
  $\dot{
ho} = A( heta)
ho + f_2( heta, 
ho),$   $A( heta) = Z'( heta) \Big[ -rac{dZ( heta)}{d heta} + rac{\partial f(u( heta))}{\partial x} Z( heta)) \Big],$ 

where  $f_1(\theta, \rho)$ ,  $f_2(\theta, \rho)$  are continuous in  $\theta$ ,  $\rho$ , have continuous first derivatives, with respect to  $\rho$ , and have period  $\omega$  in  $\theta$ . These functions satisfy (1.10); that is,

(2.2) 
$$|f_1(\theta, \rho)| = O(|\rho|), \quad \text{as } |\rho| \to 0,$$
$$f_2(\theta, 0) = 0, \quad \frac{\partial f_2(\theta, 0)}{\partial \rho} = 0.$$

Also associated with the periodic solution  $u(\theta)$  of (2) is the linear variational equation

(2.3) 
$$\frac{dy}{d\theta} = \frac{\partial f(u(\theta))}{\partial x} y.$$

This linear system with periodic coefficients always has a nontrivial  $\omega$ -periodic solution. In fact,  $du(\theta)/d\theta$  is a nontrivial  $\omega$ -periodic solution of this equation since (2) implies  $d^2u/d\theta^2 = [\partial f(u(\theta))/\partial x] du/d\theta$ . Therefore, at least one characteristic multiplier of (2.3) is equal to unity.

LEMMA 2.1. If the characteristic multipliers of the n-dimensional system (2.3) are µl, ... ,µn\_1 1, then the characteristic multipliers of the (n -1)-dimensional system

$$\frac{d\rho}{d\theta} = A(\theta)\rho,$$

where A(O) is given in (2.1), are µl, ..., µn\_1.

PROOF. Suppose Z is then x (n - 1) dimensional matrix defined in (1.4). The vector du(0)/d0 and the columns of Z(O) are orthogonal since v(O), Z(B) is a moving orthonormal system. Thus, for any n-vector y, there is uniquely defined a scalar P and (n -1)-vector p such that y = P du(O)/d8 + Z(O)p. If y is a sohition of (2.3), then using the fact that d2u/d62 = [8f (u(6))/8x] du/dO and the columns of the matrix (v, Z) are orthogonal, one immediately deduces that p satisfies (2.4). This shows that the normal component of the solution of the linear variational equation coincides with the solution of the linear variational equation of the normal variation.

Now suppose w2, ..., wn are (n - 1) solutions of (2.3), Yl is then x n -1 matrix defined by Y1= [w2, ..., wn] and Y(O) = [du(O)/d6, Y1(0)] is a fundamental matrix solution of (2.3). If K is defined by Y(w) = Y(0)K, then the eigenvalues of K are the characteristic multipliers of (2.3). From the definition of Y, it follows immediately that K must be of the form

$$K = \begin{bmatrix} 1 & K_2 \\ 0 & K_1 \end{bmatrix},$$

and, therefore, the multipliers µl, ... , It,, of (2.3) defined in the statement of the lemma are the eigenvalues of K1. If Y1= [du/dO]a + ZR, where row(a2, ..., an) and R is an (n - 1) x (n - 1) matrix, then the remarks at the beginning of this proof imply that R is a matrix solution of (2.4) with R(w) = R(0)K1. The matrix R(0) is nonsingular. In fact, if there exists an (n -1)-vector c such that R(0)c = 0, then Yl(0)c - [du(0)/d6]cac = 0. Since Y(0) is nonsingular, this implies c = 0 and, therefore, R(0) is nonsingular. Since R(0) is nonsingular, R(O) is a fundamental matrix solution of (2.4) and K1 is the monodromy matrix of R. Thus, the eigenvalues of K1 are the multipliers of (2.4) and the proof of the lemma is complete.

Let us recall some of the previous concepts of stability. If M is a set in Rn, an 9-neighborhood U,(M) is the set of x in Rn such that dist(x, M) <7). An invariant set M of (2) is said to be stable if for any e > 0, there is a a > 0 such that, for any xc in U5(M), the solution x(t, x°) is in UE(M) for all t >\_ 0. An invariant set M of (2) is said to be asymptotically stable if it is stable and in addition there is b > 0 such that for any xO in Ub(M) the solution x(t, xc) approaches M as t -i- oo. If u(t) is a nonconstant. periodic solution of (2), one says the periodic solution u(t) is orbitally stable, asymptotically orbitally stable if the corresponding invariant closed curve r generated by u is stable,

asymptotically stable, respectively. Such a periodic solution is said to be asymptotically orbitally stable with asymptotic phase if it is asymptotically orbitally stable and there is a b > 0 such that, for any xo with dist(xo, F) < b, there is a -r = T(xo) such that l x(t, xo) - u(t - T)l -- 0 as t --- oo.

THEOREM 2.1. If f is in '1(Rn, Rn), u is a nonconstant w-periodic solution of (2), the characteristic multiplier one of (2.3) is simple and all other characteristic multipliers have modulus less than 1 (characteristic exponents have negative real parts), then the solution u is asymptotically orbitally stable with asymptotic phase.

PROOF. The solutions in a neighborhood of the orbit r of u can be described by equation (2.1). The above hypotheses and Lemma 2.1 imply that the characteristic multipliers of (2.4) have modulus less than 1. For a sufficiently small neighborhood of r; that is, p sufficiently small, t may be eliminated in (2.1) so that the second equation in (2.1) has the form

(2.5) 
$$\frac{d\rho}{d\theta} = A(\theta)\rho + f_3(\theta, \rho),$$

where f3(0, p) has continuous first partial derivatives with respect to p, f3(0, 0) = 0, ef3(0, 0)/8p = 0. Theorems 111.2.4 and 111.7.2 imply "there are K > 0, a > 0, rl > 0 such that for lpol < rl the solution p(0, 0o , po), p(Oo, 00, po) = po, of (2.5) satisfies

$$|\rho(\theta, \, \theta_0, \, \rho_0)| \leq Ke^{-\alpha(\theta-\theta_0)} |\rho_0|, \qquad \theta \geq \theta_0.$$

This proves the asymptotic stability of the solution p = 0 of (2.5). Since B > 1/2, we have asymptotic orbital stability of F.

Equations (2.5) yield the orbits of (2) near F. The actual solutions of (2) near r are obtained from the transformation formulas (1.4) and the vector (0(t), p(O(t), Oo, po)) where p(0, 00 , po) satisfies (2.5) and 0(t), 0(to) = 00, is the solution of the first equation in (2.1) with p replaced by p(0, 0o, po). To prove there is an asymptotic phase shift associated with each solution of (2), it is sufficient to show that 0(t) - t approaches a constant as t -i oo. If 0 = t + b, then

(2.7) 
$$\dot{\psi}(t) = f_1(t + \psi, \, \rho(t + \psi, \, t_0 + \psi_0, \, \rho_0)).$$

Since 4 > 1/2, the map taking t to 0(t) has an inverse. Making use of this fact and recalling that 0(t) = t + /i(t), we have

(2.8) 
$$\psi(t) = \psi(t_0) + \int_{t_0}^t f_1(\theta(t), \rho(\theta(t), \theta_0, \rho_0)) dt$$
$$= \psi(t_0) + \int_{\theta(t_0)}^{\theta(t)} f_1(\theta, \rho(\theta), \theta_0, \rho_0)) \frac{dt}{d\theta} d\theta.$$

Since if, (O,p) I < L I p 1, relation (2.6) and I dtfdO i < 2 imply

$$\left| f_1(\theta, \rho(\theta, \theta_0, \rho_0)) \frac{dt}{d\theta} \right| \leq 2LK e^{-\alpha(\theta - \theta_0)} |\rho_0|.$$

Since 0(t) -> 00 if and only if t -> 00 and

$$\int_{0}^{\infty} 2LK e^{-\alpha(\theta-\theta_0)} |\rho_0| d\theta < \infty,$$

we have

$$\lim_{t\to\infty}\int_{t_0}^t f_1(\theta(t),\rho(\theta(t),\theta_0,\rho_0))dt$$

exists. From (2.8), this implies fi(t) approaches a constant as t This completes the proof of Theorem 2.1.

EXERCISE 2.1. Give an example of an autonomous system which has an asymptotically orbitally stable periodic solution but there is no asymptotic phase.

THEOREM 2.2. If u is a nonconstant w-periodic solution of (2) with (n - 1) characteristic multipliers of (2.3) having modulii different from one, then there exist a neighborhood Wr of the closed orbit F in (1) and two sets Sr, Ur such that Sr n Ur = F and any solution of (2) which remains in Wr for t >\_ 0 (t < 0) must lie on Sr (Ur). If a solution x of (2) has its initial value in Sr (Ur) then x(t) --a F as t -± oo (t -->- - oo). Furthermore, if p (q) characteristic multipliers of (2.3) have modulii <1 (>1) then Sr (Ur) is either a p-dimensional (q-dimensional) ball times a circle or a generalized Mobius band.

PROOF. In a neighborhood of the periodic orbit, r, the orbits of (2) are given by the transformation (1.4) and the solutions p(O) of the real system of differential equations (2.5). The Floquet representation theorem implies that the principal matrix solution of (2.4) can be expressed as P(0)ea0 where P(0) is periodic of period co. Furthermore, Exercise 111.7.2. asserts that P(0) can always be chosen real if it is only required that P be periodic of period 2w. If P has been chosen in this manner, the real transformation p = P(0)r applied to (2.5) yields the equivalent real system

$$\dot{r} = Br + f_4(\theta, r),$$

where f4(0, 0) = 0, ef4(0, 0)/8r = 0, f4(0, r) is periodic in 0 of period 2w, and the eigenvalues of B have nonzero real parts. The conclusion of the theorem now follows immediately by the application of Theorem IV.3.1 to (2.9) and using the transformation p = P(0)r.

It is reasonable to call Sr and Ur the stable and unstable manifolds, respectively, of the periodic orbit F.

The following example illustrates that Sr may be a Mobius band. It looks complicated, but actually isn't if one looks at the example in the manner in which it was invented; namely, the development was from the final result desired to the differential equation. Consider the equations

(2.10) (a) 
$$\dot{r} = A(\theta)r$$
,  
(b)  $\dot{\theta} = 1$ ,

where r = (ri, r2), 0 are given in terms of the coordinates x, y, z in R3 by x = (r1 + 1) cos 47r8, y = (rj + 1) sin 47r8, z = r2, and A(0 + 1/2) = A(8) with

$$A(\theta) = 2 egin{bmatrix} -\cos 4\pi \theta & \pi + \sin 4\pi \theta \ -\pi + \sin 4\pi \theta & \cos 4\pi \theta \end{bmatrix}.$$

In R3, there is a periodic solution of period 1/2 and the periodic orbit r is the circle of radius one in the (x, y)-plane with center at the origin. It will be shown that this periodic orbit has stable and unstable manifolds which are Mobius bands.

The principal matrix solution of the equation (2.10a) is P(O) exp BO where

$$P( heta) = egin{bmatrix} \cos 2\pi heta & \sin 2\pi heta \ -\sin 2\pi heta & \cos 2\pi heta \end{bmatrix}, \ B = egin{bmatrix} -2 & 0 \ 0 & 2 \end{bmatrix}.$$

The matrix A(8) has period 1/2 whereas the matrix P(8) has period 1 in 0. Furthermore, it is easily seen that no Floquet decomposition of the principal matrix solution can have real periodic part and at the same time have period 1/2. The characteristic multipliers of the system are the eigenvalues of P(1/2) exp B which are -e-I, - e.

The stable and unstable manifolds of r are given by

$$egin{align} S_{\Gamma} = & \{(x,\,y,\,z) : r = e^{-2 heta} \; (\cos\,2\pi heta,\,\,-\sin\,2\pi heta) a,\, 0 \leqq heta < rac{1}{2},\,\,-a_0 < a < a_0\}, \ & U_{\Gamma} = & \{(x,\,y,\,z) : r = e^{2 heta} \; \; (\sin\,2\pi heta,\,\cos\,2\pi heta) b,\, 0 \leqq heta < rac{1}{2},\,\,-b_0 < b < b_0\}, \ & \{(x,\,y,\,z) : r = e^{2 heta} \; \; (\sin\,2\pi heta,\,\cos\,2\pi heta) b,\, 0 \leqq heta < rac{1}{2},\,\,-b_0 < b < b_0\}, \ & \{(x,\,y,\,z) : r = e^{2 heta} \; \; (\sin\,2\pi heta,\,\cos\,2\pi heta) b,\, 0 \leqq heta < rac{1}{2},\,\,-b_0 < b < b_0\}, \ & \{(x,\,y,\,z) : r = e^{2 heta} \; \; (\sin\,2\pi heta,\,\cos\,2\pi heta) b,\, 0 \leqq heta < rac{1}{2},\,\,-b_0 < b < b_0\}, \ & \{(x,\,y,\,z) : r = e^{2 heta} \; \; (\sin\,2\pi heta,\,\cos\,2\pi heta) b,\, 0 \leqq heta < rac{1}{2},\,\,-b_0 < b < b_0\}, \ & \{(x,\,y,\,z) : r = e^{2 heta} \; \; (\sin\,2\pi heta,\,\cos\,2\pi heta) b,\, 0 \leqq heta < rac{1}{2},\,\,-b_0 < b < b_0\}, \ & \{(x,\,y,\,z) : r = e^{2 heta} \; \; (\sin\,2\pi heta,\,\cos\,2\pi heta) b,\, 0 \leqq heta < rac{1}{2},\,\,-b_0 < b < b_0\}, \ & \{(x,\,y,\,z) : r = e^{2 heta} \; \; (\sin\,2\pi heta) b,\, 0 \leqq heta < rac{1}{2},\,\,-b_0 < b < b_0\}, \ & \{(x,\,y,\,z) : r = e^{2 heta} \; \; (\sin\,2\pi heta) b,\, 0 \leqq heta < rac{1}{2},\,\,-b_0 < b < b_0\}, \ & \{(x,\,y,\,z) : r = e^{2 heta} \; \; (\sin\,2\pi heta) b,\, 0 \leqq \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \$$

where ao, be are positive constants. It is clear that these surfaces are Mobius bands.

EXERCISE 2.2. Prove that any solution of the stable (unstable) manifold Sr(Ur) of F in Theorem 2.2 must approach the orbit r with asymptotic phase as t --\* co (t -- - oo).

#### VI.3. Sufficient Conditions for Orbital Stability in Two Dimensions

Consider the real two dimensional system

(3.1) 
$$\dot{x} = X(x, y),$$
 
$$\dot{y} = Y(x, y),$$

where X, Y are continuous together with their first partial derivatives in  $\mathbb{R}^2$ . Suppose  $x^0(t)$ ,  $y^0(t)$  is a nonconstant periodic solution of period  $\omega$  of (3.1) whose orbit in the (x, y)-plane is  $\Gamma$ . The linear variational equations of this solution are

(3.2) 
$$\dot{x} = \frac{\partial X}{\partial x} x + \frac{\partial X}{\partial y} y,$$

$$\dot{y} = \frac{\partial Y}{\partial x} x + \frac{\partial Y}{\partial y} y,$$

where the functions are evaluated at  $x^0(t)$ ,  $y^0(t)$ . Lemma III.7.3 implies that the product of the characteristic multipliers of (3.2) is

$$\exp \left[ \int_{\Gamma} (\partial X/\partial x + \partial Y/\partial y) \ dt \right].$$

Since 1 is a characteristic multiplier of (3.2), this exponential must be the other multiplier. Using Theorems 2.1 and 2.2, we can therefore state the following sufficient conditions for stability and instability of  $\Gamma$ .

LEMMA 3.1. An  $\omega$ -periodic solution  $x^0(t)$ ,  $y^0(t)$  of (3.1) has a multiplier of (3.2) less than 1 and, thus, is asymptotically orbitally stable with asymptotic phase if

$$\int_0^\omega \left[ \frac{\partial X(x^0(t),\,y^0(t))}{\partial x} + \frac{\partial Y(x^0(t),\,y^0(t))}{\partial y} \right] dt < 0,$$

and has a multiplier of (3.2) greater than 1 and hence unstable if this integral is positive.

To illustrate the application of this lemma, consider the scalar equation

(3.3) 
$$\ddot{x} + f(x)\dot{x} + g(x) = 0$$

or the equivalent system

$$\dot{x} = y,$$

$$\dot{y} = -g(x) - f(x)y,$$

where f, g are continuous together with their first derivatives on R, and f has isolated zeros.

If E(x, y) = y2/2 + G(x), G(x) = fag(s) ds, then the derivative 2 of E along the solutions of.(3.4) is given by

(3.5) 
$$\dot{E} = -f(x)y^2 = 2f(x)[G - E].$$

If x(t) is a nonconstant solution of (3.3), then there can be no I such that z(1) = z(1) = 0. Ih fact, if this were the case, then xO = x(1) would be a zero of g and uniqueness would imply x(t) = xc for all t. Suppose z(l) = 0 and z(1) 0. Then the solution x(t) has a local extremum at I and must be either greater or less than x(l) in a neighborhood of 1. Since the zeros off (x) are isolated, it follows that f (x(t)) must be of constant sign near 1 and consequently E cannot have an extremum at 1.

If P is a closed orbit of (3.4) determined by a periodic solution x°(t) of (3.3), then E assumes a minimum value on r for t =I and the above remark implies that f (x0(1)) = 0, y(1) = 0(1) 0. Therefore, if G(xs(t)) = h, then E(t) > h for all t. From (3.5), it follows that

$$rac{\dot{E}}{E-h} + 2f = rac{2(G-h)f}{E-h},$$

and integration over r yields

(3.6) 
$$\int_{\Gamma} f dt = \int_{\Gamma} \frac{(G-h)f}{E-h} dt.$$

From Lemma 3.1 and the special form of (3.4), the linear variational equation of the orbit F will have a multiplier <1 if (3.6) is positive and >1 if (3.6) is negative. In particular, this multiplier will be <1 if G(x) takes the same value y for all zeros of f (x) and [G(x) -y] f (x) is positive when f (x) 0 0. As a particular case which will be useful in the sequel, we state

LEMMA 3.2. If f, g have continuous first derivatives in R a4d

(i) 
$$f(x) < 0$$
 for  $\alpha < x < \beta$ ,  $f(x) > 0$  for  $x < \alpha$ ,  $x > \beta$  and  $\alpha < 0 < \beta$ ,

(ii) xg(x) > O for x zA 0,

(iii) 
$$G(\alpha) = G(\beta)$$
 where  $G(x) = \int_0^x g(s) \ ds$ ,

then any closed orbit of (3.4) has a characteristic multiplier in (0, 1) and is thus asymptotically orbitally stable with asymptotic phase.

An important special case of Lemma 3.2 is the van der Pol equation k(1 -x2)x+x=0, k>0.

## VIA. Autonomous Perturbations

Consider the system of equations

$$\dot{x} = f(x) + F(x, \varepsilon),$$

where  $f: \mathbb{R}^n \to \mathbb{R}^n$ ,  $F: \mathbb{R}^{n+1} \to \mathbb{R}^n$  are continuous, f(x),  $F(x, \varepsilon)$  have continuous partial derivatives with respect to x and F(x, 0) = 0 for all x. If system (2) has a nonconstant periodic solution u(t) of period  $\omega$  whose orbit is  $\Gamma$ , then the linear variational equation for u is

$$\dot{y} = \frac{\partial f(u(t))}{\partial x} y.$$

THEOREM 4.1. If n-1 of the characteristic multipliers  $\mu_1, \ldots, \mu_{n-1}$  of (4.2) are  $\neq 1$ , then there is an  $\varepsilon_0 > 0$  and a neighborhood W of  $\Gamma$  such that equation (4.1) has a periodic solution  $u^*(\cdot, \varepsilon)$  of period  $\omega^*(\varepsilon)$ ,  $0 \leq |\varepsilon| \leq \varepsilon_0$ , such that  $u^*(\cdot, 0) = u(\cdot)$ ,  $\omega^*(0) = \omega$ ,  $u^*(t, \varepsilon)$  and  $\omega^*(\varepsilon)$  are continuous in t.  $\varepsilon$  for t in  $R, 0 \leq |\varepsilon| \leq \varepsilon_0$ . If none of  $\mu_1, \ldots, \mu_{n-1}$  is a root of one, then for any constant k > 0, the neighborhood W can be chosen so that  $u^*(\cdot, \varepsilon)$  is the only periodic solution of (4.1) of period  $\leq k$  in W. If  $\mu_1, \ldots, \mu_{n-1}$  have modulii < 1, then  $u^*(\cdot, \varepsilon)$  is asymptotically orbitally stable with asymptotic phase and is unstable if any  $\mu_i$  has modulus > 1.

PROOF. Theorem 1.2 and the transformation (1.4) imply that system (4.1) is equivalent to the system (1.11) with F(t, x) replaced by  $F(x, \varepsilon)$  above. Elimination of t in these equations yields a system

(4.3) 
$$\frac{d\rho}{d\theta} = A(\theta)\rho + R(\theta, \rho, \varepsilon),$$

where  $A(\theta)$ ,  $R(\theta, \rho, \varepsilon)$  are  $\omega$ -periodic in  $\theta$  and R is in  $\mathscr{Lip}(\eta, M)$  where  $\mathscr{Lip}(\eta, M)$  is defined in Section IV.2. Lemma 2.1 implies that the characteristic multipliers of  $d\rho/d\theta = A(\theta)\rho$  are the numbers  $\mu_1, \ldots, \mu_{n-1}$ . Theorem IV.2.1 implies the existence of an  $\varepsilon_0 > 0$ ,  $\rho_0 > 0$  and an  $\omega$ -periodic solution  $\rho^*(\theta, \varepsilon)$  of (4.3) continuous in  $\theta$ ,  $\varepsilon$ ,  $0 \le |\varepsilon| \le \varepsilon_0$ ,  $\rho^*(\theta, 0) = 0$ , and  $\rho^*(\theta, \varepsilon)$  is the only  $\omega$ -periodic solution in the region  $|\rho| < \rho_0$ . Theorem IV.3.1 yields the stability properties of  $\rho^*(\theta, \varepsilon)$  when  $\mu_1, \ldots, \mu_{n-1}$  have modulii different from one. Using this  $\rho^*(\theta, \varepsilon)$  in the first equation in (1.11) and letting  $\theta(t)$  be the solution of this equation with  $\theta(0) = 0$ , one finds there is a unique continuous  $\omega^*(\varepsilon)$ ,  $0 \le |\varepsilon| \le \varepsilon_0$ ,  $\omega^*(0) = \omega$ , such that  $\theta(\omega^*(\varepsilon)) = \omega$ ,  $0 \le |\varepsilon| \le \varepsilon_0$ . The function  $\theta(t)$ ,  $\rho^*(\theta(t), \varepsilon)$ , and the transformation (1.4) yield the desired periodic solution of (4.1) and the stability properties are as stated in the theorem.

Suppose now that no  $\mu_j$ ,  $j=1,2,\ldots,n-1$ , is a root of 1. For any integer k, the periodic solution u of (2) has period  $k\omega$  and, therefore, all of the functions in the equations of the above proof can be considered as periodic in  $\theta$  of period  $k\omega$ . The hypothesis on the  $\mu_j$  imply by Theorem IV.2.1 that there is a periodic solution of (4.3) of period  $k\omega$  for  $0 \le |\varepsilon| \le \varepsilon_0$  and this solution is unique in the region  $|\rho| < \rho_0$ . Therefore, this solution must be the

p\*(0, e) given above. But, any periodic solution x of (4.1) which lies in a sufficiently small neighborhood of F must define a closed curve in Rn with a parametric representation of the form x = u(O) + Z(0)p(0, e) where p(0, e) is a periodic solution of (4.3) of period kw for some integer k. This completes the proof of the theorem.

EXERCISE 4.1. Suppose g(x, y) has continuous first derivatives with respect to x, y. Show there is an so > 0 such that for I e I < eo the equation '

$$\ddot{x}-k(1-x^2)\dot{x}+x=\varepsilon g(x,\,\dot{x}),\,k>0,$$

has a unique periodic solution in a neighborhood of the unique periodic orbit of the van der Pol equation

$$\ddot{x}-k(1-x^2)\dot{x}+x=0.$$

Can you prove that this orbit is asymptotically orbitally stable with asymptotic phase?

EXERCISE 4.2. Give an example of an autonomous system t = f (x) which has an w-periodic orbit IF whose linear variational equation has 1 as a simple multiplier and yet, in any neighborhood of r, there are other periodic orbits.

EXERCISE 4.3. Is it possible for an equation x = f (x) to have an isolated w-periodic orbit P whose linear variational equation has 1 as a simple multiplier and yet, there is a perturbation sg(x) such that in any neighborhood of F there is more than one periodic orbit?

## VI.S. Remarks and Suggestions for Further Study

The particular construction of the moving orthonormal system given in Section 1 is based on a presentation given by Urabe [1] for the case in which the closed curve F is a periodic orbit. The manner in which the coordinate system is used'to obtain a set of differential equations equivalent to (4) in a neighborhood of r is different. Since Urabe discusses only the case of a periodic orbit, it is possible to obtain the equations for the normal variation explicitly in terms of t and not 0 as in (1.11). Lemma 1.1 was given by Diliberto and Hufford [1]. Lemma 3.2 is due to Coppel [1, p. 86]. The stability Theorem 2.1 was known to Poincare for analytic systems.

In general, it is very difficult to discuss the behavior of solutions of (2) in a neighborhood of an orbit when more than one characteristic multiplier of (2.3) has modulus equal to one. Hale and Stokes [1] have given the following

result. If system (1) has a k-parameter family of periodic solutions, then the linear variational equation has k characteristic multipliers equal to one. If the remaining multipliers have modulus less than one, then every orbit in this family is stable and, in fact, the solutions of (2) near this family approach a member of this family asymptotically with asymptotic phase.

Autonomous perturbations of nonlinear systems which possess a k-parameter family of periodic solutions is extremely difficult and is discussed at great length in the book of Urabe [1]. Under the hypothesis that only one multiplier of the linear variational equation has modulus one, the behavior of solutions near a periodic orbit of a nonautonomous perturbation of (2) will be discussed in the next chapter. If the nonautonomous perturbation is " small " for large t; that is, the system is " asymptotically " autonomous, then one can discuss the qualitative relationship between all solutions of the nonautonomous equation and the autonomous one without any hypotheses regarding the solutions of the autonomous one (see Markus [1], Opial [1], Yoshizawa [1]). For nonautonomous perturbations of k-parameter families of periodic solutions, see Hale and Stokes [1], Yoshizawa and Kato [1].

## CHAPTER VII

## Integral Manifolds of Equations with a

## Small Parameter

Assuming that system (VI.2) has an invariant set which is a smooth Jordan curve r, it was shown in Chapter VI that a transformation of variables could be introduced in such a way that the behavior near r of the solutions of a perturbation of (VI.2), namely (VI.4), is reduced to a study of the equations

$$\dot{ heta} = g( heta) + \Theta(t, \, heta, \, 
ho), \ \dot{
ho} = C( heta)
ho + R(t, \, heta, \, 
ho),$$

where p represents the normal deviation from r and g(O) represents the behavior of the solutions of the unperturbed equation on F. If g(O) -1, the curve r corresponds to a periodic orbit and if g vanishes at some point, then an equilibrium point lies on F.

For g(O) =1 and the perturbations independent of t, some specific results were given in Chapter VI for the above equation. The analysis for this case is extremely simple since the problem is easily reduced to the study of the behavior near an equilibrium point of a nonautonomous system. On the other hand, if 0, R contain t explicitly, then one cannot reduce the question to such a local problem since t cannot be eliminated from the equations even if g(O) - 1. One must study the behavior near the invariant set itself. If g(O) has a zero for some value of 0, then the problem remains nonlocal even if 0, R are independent of t. Other difficulties also arise in this latter case and will be discussed later.

The purpose of this chapter is to study such nonlocal problems for even more general systems than the above. More specifically, we will be concerned with equations of the form

(1) 
$$\begin{aligned} \dot{\theta} &= \Theta^*(t, \, \theta, \, x, \, y, \, \varepsilon) = w(t, \, \theta, \, \varepsilon) + \Theta(t, \, \theta, \, x, \, y, \, \varepsilon), \\ \dot{x} &= A(\theta, \, \varepsilon)x + F(t, \, \theta, \, x, \, y, \, \varepsilon), \\ \dot{y} &= B(\theta, \, \varepsilon)y + G(t, \, \theta, \, x, \, y, \, \varepsilon), \end{aligned}$$

where (E, 0, x, y) is in R X Rk X Rn x R'n, the matrix A(0, E) is of such a nature that the solutions of x =A (0, E)x approach zero exponentially as t -a oo, the solutions of y = B(0, E)y approach zero exponentially as t -\* - oo, for some class of functions 0(t), and F, G, O are sufficiently small in some sense for x, y, E small. These statements will be made more precise later.

It will not be assumed that the functions in (1) are periodic in the vector 0 although it will be assumed they are bounded for x, y in compact sets. In specific applications, a frequently occurring special case of (1) does have all functions periodic in 0. Such problems arise naturally from the study of the local perturbation theory of differential equations near an invariant torus. In many important situations, the flow on the invariant torus is parallel in the sense that all solutions are either periodic or quasiperiodic and then w(t, 0, E) in (1) is a constant vector. If equations (1) arise from the local perturbation theory of a periodic orbit, then 0 is a scalar, w is a constant and the Floquet theory for periodic systems permits one to take the matrices A(0, e), B(0, E) independent of 0. For the general perturbation theory of invariant torii with parallel flow, the matrices A(0, e), B(0, E) cannot be taken independent of 0 because there is no Floquet theory for general almost periodic systems. The exercises in Section 8 illustrate the many ways in which equations of type (1) arise.

Definition 1. A surface S in (z, t)-apace is an integral manifold of a system of ordinary differential equations z = Z(z, t) if for any point P in S, the solution z(t) of the equation through P is such that (z(t), t) is in S for all t in the domain of definition of the solution z(t).

Our interest in this chapter lies in determining in what sense the qualitative behavior of the solutions of (1) and the system

(2) 
$$\begin{aligned} \theta &= w(t, \, \theta, \, 0), \\ \dot{x} &= A(\theta, \, 0)x, \\ \dot{y} &= B(\theta, \, 0)y, \end{aligned}$$

are the same. This system has an integral manifold S in B x Rk X Rn x Rwhose parametric representation is given by

$$S = \{(t, \, \theta, \, x, \, y) \colon x = 0, \, y = 0\}.$$

Furthermore, under the stability properties alluded to earlier, the manifold S has a ,type of saddle point structure associated with it. In fact, there is an -R X Bk x Rn dimensional manifold of solutions of (2) which approach S as t -\* oo and an B x Bk x Bnl dimensional manifold of solutions of (2) which approach S as t - - oo. Intuitively, one expects that O, F, and G small enough for e, x, y small will imply the existence of some other integral

manifold Sr of (1) which is close to S for s small and has the same type of stability properties as the integral manifold S of (2).

Therefore, in this chapter, we determine conditions on 0, F, G which ensure that (1) has an integral manifold of the form x =f (t, 0, s), y = g(t, 0, s), (t, 0) in R x Rk, which for s = 0 reduce to x = 0, y = 0. For this specific case,. such a surface will be an integral manifold for (1) if the triple of functions

$$[\theta(t) = \theta(t, \theta_0, t_0), \qquad x(t) = f(t, \theta(t), \varepsilon), \qquad y(t) = g(t, \theta(t), \varepsilon)],$$

is a solution of (1) for every to in R, 00 in Rk.

Section 1 consists of a historical and intuitive discussion of the problems involved in determining integral manifolds for (1) as well as possible approaches to the solutions of these problems. The main theorems are stated in Section 2 with the proof being delegated to Sections 3, 4, 5, 6. In Section 7, applications of the results of Section 2 are given for equations which are perturbations of equations possessing an elementary periodic orbit. Also, in Section 7, the methdd of averaging of Chapter V is extended to averaging with respect to t as well as the variables 0 in (1). The exercises in Section 8 illustrate more fully the implications of the results of this chapter.

## Vll.1. Methods of Determining Integral Manifolds

This section is devoted to an intuitive discussion. of integral manifolds as well as some methods that have proved successful in the determination of-integral manifolds. We choose for our discussion the problem of perturbing an autonomous system

$$(1.1) \dot{x} = X(x),$$

which has a nonconstant coo-periodic solution u(t) such that n -1 of the characteristic exponents of the linear variational equation

$$\dot{y} = \frac{\partial X(u(t))}{\partial x} y$$

have negative real parts. As we have seen in Chapter VI, this implies the orbit described by u is asymptotically stable and this in turn implies that the cylinder

(1.3) 
$$S = \{(t, x) : x = u(\theta), 0 \le \theta \le \omega_0, -\infty < t < \infty\},$$

in (t, x)-space is asymptotically stable. The cylinder S is an integral manifold of (1.1) in R x Rn.

If we introduce the coordinate system

$$(1.4) x = u(\theta) + Z(\theta)\rho$$

of Chapter VI, then in a neighborhood of S the solutions of the equation are described by

(1.5) 
$$\begin{aligned} \theta &= 1 + \Theta(\theta, \rho), \\ \dot{\rho} &= A(\theta)\rho + R(\theta, \rho), \end{aligned}$$

where 0(0, p) = Oflpl), R(0, p) = Oflp12) as JpJ --\*0, all functions are tooperiodic in 0, and the characteristic exponents of dp/dO = A(0)p have negative real parts. From the Floquet theory, a fundamental system of solutions of this linear equation is of the form P(0)eBO, P(0+wo) = P(0). If we let p(t) = P(0)z(t) and use the fact that 6 = 1 + O(I pl ), we obtain an equivalent system

(1.6) 
$$\dot{\theta} = 1 + \Theta_1(\theta, z),$$

$$\dot{z} = Bz + Z(\theta, z),$$

where 01(0, z) = Oflzl), Z(0, Z) = O(Iz12) as JzJ -\*0 and the eigenvalues of B have negative real parts.

For the sake of our intuitive exposition, we need the following elementary result proved in Chapter X, Lemma 1.6. There is a positive definite matrix C such that any solution of the linear system z = Bz with initial value on the ellipsoid z'Cz = c > 0, a constant, must enter the interior of this ellipsoid for increasing time. In Lemma X.1.6, it is shown that the matrix C = J0w eB'teBtdt satisfies the desired properties. Since Z(0, Z) = O(Iz12) as IzI ->0, there is a co > 0 sufficiently small such that any solution of (1.6) with initial value on the set

$$U_s(c) = \{(t, x) : x = u(\theta) + Z(\theta)P(\theta)z, 0 \le \theta \le \omega_0, z'Cz = c, \\ -\infty < t < \infty\}, 0 < c \le c_0,$$

must enter this set for increasing t (and therefore remain inside this set). The set U8(c) projected into the x-space is a tube surrounding the closed curve W = {x : x = u(0), 0 <\_ 0:!9 wo}. In two dimensions, it is an annulus around W. In this case, the geometry is very simple since U8(c) represents a cylinder inside S and a cylinder outside S.

Now if the original differential equation (1.1) is perturbed to the form

$$\dot{x} = X(x) + \varepsilon X^*(t, x)$$

where X\*(t, x) is bounded in a neighborhood of S, then for a given c > 0 and E sufficiently small, the solutions will still be entering U8(c) as time increases. Therefore, for a fixed c > 0, we would expect some kind of integral surface inside U8(c) for s small and it should look similar to a cylinder. However, even if such a surface exists we would not expect the solutions on this surface to behave in a manner similar to the behavior of the solutions on the original

S since these solutions have no strong stability properties associated with them. This is precisely why we discuss the preservation of the structure and stability properties of the set S rather than the preservation of any such properties for a particular solution on S.

Some methods for asserting the existence of integral manifolds for the perturbed equation are now given. If the transformation (1.4) is applied to (1.7), the equivalent equations are

(1.8) 
$$\begin{aligned} \dot{\theta} &= 1 + \Theta(\theta, \rho) + \varepsilon \Theta^*(t, \theta, \rho), \\ \dot{\rho} &= A(\theta) \rho + R(\theta, \rho) + \varepsilon R^*(t, \theta, \rho). \end{aligned}$$

Method 1 (Levinson-Diliberto). If we assume that the perturbation term is to,-periodic in t, then the above discussion of the geometric implications of stability allows one to obtain an annulus map via the differential equation (1.7) in the following way. Let U8i(c) be U8(c) n {t =T}; that is, the cross section of U8(c) at t = T. Actually, all of these cross sections are the same and equal to Ua0(c). If x(t, xo) is the solution of the perturbed equation (1.7) with initial value xo at t = 0 and e is sufficiently small, 'then for any T > 0, the function x(r, ) is a mapping of U8o(c) into the interior of U8z(c) = U80(c); that is, a mapping of U8o(c) into itself. Because of the strong stability properties of the curve le and the fact that solutions " rotate " around this curve, one would suspect that there is a curve `FEZ such that x(r, FEZ) = leET and fos = W. If this is true and if T is chosen to be wI, then the periodicity in the equation implies x(kwl, We.)) = `0E(0, for every integer k. By considering the " cylinder " generated by the solutions which start on We,,,,, we obtain an invariant manifold of the equation. In this case, the solutions on the cylinder can be described by the solutions of an equation on a torus, the torus being obtained by identifying the cross sections of the cylinder at t = 0 and t = col. The basis of this idea was proposed and exploited in a beautiful paper of Levinson (1950). Using the idea of the proof of Levinson, Diliberto and his colleagues greatly simplified and improved the work of Levinson as well as discussing integral manifolds of a much more complicated type. In fact, if the perturbation-term X\* in (1.7) is an arbitrary quasi-periodic., function, then it can be written in the form F(t, t, ..., t, x) where F(tl, ... , tp, x) is periodic in tf of period coy , j = 1, ... , p. The functions 0\*, R\* in (1.8) have this same periodicity structure in t. By artificially introducing variables j such that = 1, we obtain from (1.8) a system

$$egin{aligned} \dot{\zeta}_j &= 1, \qquad j = 1, \, 2, \, \ldots, \, p, \ \dot{ heta} &= 1 + \Theta( heta, \, 
ho) + arepsilon P^*( heta, \, \zeta, \, 
ho), \ \dot{
ho} &= A( heta) 
ho + R( heta, \, 
ho) + arepsilon Q^*( heta, \, \zeta, \, 
ho), \end{aligned}$$

where P\*(0, , p), Q\*(0. , p), = gyp), are periodic in 0 and . This

is a special case of (1) with 0 in (1) a (p + 1)-vector consisting of the scalar 0 above and the p-vector . Notice that the equations no longer contain t explicitly. Diliberto has introduced an ingenious device to discuss integral manifolds for such equations by generalizing the idea of the period map. The interested reader may consult the references for the details of this method as wells the applications.

Method 2 (Partial Differential Equations). Suppose we have a system

(1.9) (a) 
$$\dot{\theta} = w(\theta) + \Theta(\theta, x),$$
  
(b)  $\dot{x} = A(\theta)x + F(\theta, x),$ 

where 0 in Rk, x in Rn are vectors, and all functions are periodic in 0 of vector period w. If S = {(0, x) : x = f (Q), f (0 + co) = f (0), 0 in Rk} is to be an integral manifold of this equation, then x(t) =f (0(t)), where 0(t) is a solution of

$$(1.10) \dot{\theta} = w(\theta) + \Theta(\theta, f(\theta)),$$

must satisfy (1.9b). Performing the differentiation, we find that f must satisfy the partial differential equation

$$(1.11) \qquad \frac{\partial f}{\partial \theta} \left[ w(\theta) + \Theta(\theta, f) \right] - A(\theta) f = F(\theta, f), \, f(\theta + \omega) = f(\theta).$$

This method has not been completely developed at this time but a beginning has-been made by Sacker [1]. The case where w, A are independent of 0 is not too difficult with this approach since one can integrate along characteristics to obtain essentially the same method presented below. If there are values of 0 for which w(0) = 0, then the problem is much more difficult since the solution will not in general be as smooth as the coefficients in the equation. The smoothness properties depend in a delicate manner upon w, A. Another difficulty that arises in this problem is that the usual iteration procedures involve a loss of derivatives. To circumvent this difficulty, Sacker solves in each iteration the elliptic equation

$$\mu\Delta_{\theta}f + rac{\partial f}{\partial heta}[w( heta) + \Theta( heta, f)] - A( heta)f = F( heta, f), \qquad f( heta + oldsymbol{\omega}) = f( heta),$$

for µ small and DB the Laplacian operator. The solutions then have as many derivatives, as desired, but there is a delicate analysis involved in goosing IL -\* 0 in such a way as to obtain a solution of the original equation. Further research needs to be done with this method to see if it is possible to obtain results When the perturbation terms depend upon t in a general way and also to discuss the stability properties of the manifold.

Method 3. (Krylov-Bogoliubov-Mitropolski). Circa 1934, Krylov and Bogoliubov made a significant contribution to this problem in the following way. They defined a mapping of "cylinders" into "cylinders" via the differential equation (1.8) such that the fixed points of this map are integral manifolds of the equation which for  $\varepsilon = 0$  reduce to S. They also discussed the stability properties of this manifold. These methods do not use any particular properties of the dependence of the perturbation terms upon t.

To illustrate the ideas, consider the equation

(1.12) 
$$\begin{aligned} \dot{\theta} &= 1 = \Theta(t, \theta, \rho, \epsilon) \\ \dot{\rho} &= A \rho + R(t, \theta, \rho, \epsilon) \end{aligned}$$

where A is an  $n \times n$  constant matrix,  $Re\lambda A < 0$ ,  $\Theta(t,\theta,0,0) = 0$ ,  $R(t,\theta,0,0)/\partial \rho = 0$ . We look for integral manifolds of (1.12) of the form  $\rho = f(t,\theta,\epsilon)$  with  $|f(t,\theta,\epsilon)|$  bounded for  $(t,\theta) \in R^2$ ,  $f(t,\theta,\epsilon)$  lying in a small neighborhood of  $\rho = 0$  for  $\epsilon$  small.

Let  $S = \{f: R \times R \to R^n \text{ continuous and bounded}\}$  with the topology of uniform convergence. Suppose (1.12) has an integral manifold  $f(t,\theta,\epsilon)$ , with  $f(\cdot,\cdot,\epsilon) \in S$ . If  $\theta(t,t_0,\theta_0,f)$  is the solution of the equation

(1.13) 
$$\dot{\theta} = 1 + \Theta(t, \theta, f(t, \theta, \epsilon), \epsilon), \qquad \theta(t_0, t_0, \theta_0, f) = \theta_0,$$

then  $(\theta(t,t_0,\theta_0,f), f(t,\theta(t,t_0,\theta_0,f),\epsilon)$  must satisfy (1.12) for all  $(t_0,\theta_0) \in \mathbb{R}^2$ . Therefore, the variation of constants formula implies

$$f(t,\theta(t,t_0,\theta_0,f),\epsilon) = e^{A(t-t_0)} f(t_0,\theta_0,\epsilon)$$

$$+ \int_{t_0}^t e^{A(t-s)} R(s,\theta(s,t_0,\theta_0,f),f(s,\theta(s,t_0,\theta_0,f),\epsilon),\epsilon) ds$$

and

$$\begin{split} e^{-A(t-t_0)}f(t,\theta(t,t_0,\theta_0,f),\epsilon) &= f(t_0,\theta_0,\epsilon) \\ &+ \int_{t_0}^t e^{A(t_0-s)}R(s,\theta(s,t_0,\theta_0,f),\epsilon) \\ & f(s,\theta(s,t_0,\theta_0,f),\epsilon),\epsilon) \, ds. \end{split}$$

Since  $f(t,\theta,\epsilon)$  is bounded and  $\exp(-A(t-t_0)) \to 0$  as  $t \to -\infty$ , we have a formula for the function  $f(t_0,\theta_0,\epsilon)$ ; namely,

(1.14) 
$$f(t_0, \theta_0, \epsilon) = \int_{-\infty}^{t_0} e^{A(t_0 - s)} R(s, \theta(s, t_0, \theta_0, f), f(s, \theta(s, t_0, \theta_0, f), \epsilon) ds.$$

For a given  $f \in S$ , the right hand side of Eq. (1.14) can be considered as a transformation  $\mathscr{F}: S \to S$  and the sought for integral manifolds are fixed points of  $\mathscr{F}$ . By careful estimation, one can apply the contraction mapping principle

to obtain fixed points of .F in an appropriate bounded subset of S consisting of functions with a sufficiently small lipschitz constant in 0.

### VII.2. Statement of Results

In this section, we give detailed results on the existence and stability of integral manifolds of (1). Let Q (or, so) = {(x, y, E): I xI < (7, I yI < a, 0 < E <\_ Eo}. The following hypotheses on the functions in (1) will be used:

- (Hl) All functions A, B, w, 0, F, G are continuous and bounded in R X Rk X SZ(a, ED).
- (H2) The functions A, B, w, 0, F, G are lipschitzian in 0 with lipschitz constants r(ej), r(Ei), L(Ei), 9(p, El), y(p, El), y(p, El) respectively, in R X Rk X S2(p, El) where r(El), L(E1), , (p, El), y(p, Ei) are continuous and nondecreasing for 0 <\_ p < a, 0 < el Eo.
- (H3) The functions 0, F, G are lipschitizian in x, y with lipschitz constants µ(p, El), 8(p, El), S(p, El), respectively, in R x Rk X S2(p, El), where µ(p, El), S(p, El) are continuous and nondecreasing for 0 < p < a, 0 < ei < Eo
- (H4) The functions IF(t, 0, 0, 0, s) 1, IG(t, 0, 0, 0, e) I are bounded by N(E) for (t, 0) in R X Rk, 0 < E <\_ Eo where N(E) is continuous and nondecreasing for0<e<Eo.
- (H5) There exist a positive constant K and a continuous positive function a(E), 0 < E < eo, such that, for any continuous function 0(t) defined on (-eo, co), and any real number r, the principal matrix solution t(t, T), W(t, r) of z = A(0(t), E)x, y = B(0(t), E)y, respectively, satisfy

(2.1) 
$$|\Phi(t, \tau)| \le Ke^{-\alpha(\varepsilon)(t-\tau)}, \qquad t \ge \tau, \\ |\Psi(t, \tau)| \le Ke^{\alpha(\varepsilon)(t-\tau)}, \qquad t \le \tau.$$

(H6) Let p(1, D, s), q(0. D, E) be defined by

$$(2.2) p(\Delta, D, \varepsilon) = \gamma(D, \varepsilon) + \delta(D, \varepsilon)\Delta + \frac{Kr(\varepsilon)}{\alpha} [\delta(D, \varepsilon)D + N(\varepsilon)],$$

$$q(\Delta, D, \varepsilon) = L(\varepsilon) + \eta(D, \varepsilon) + \mu(D, \varepsilon)\Delta,$$

and suppose that

(2.3) (a) 
$$\alpha(\varepsilon) - q(\Delta, D, \varepsilon) > 0$$
,

$$(\mathrm{b}) \quad \delta(D,\,\varepsilon)D + N(\varepsilon) < \alpha(\varepsilon)D/K,$$

(c) 
$$Kp(\Delta, D, \varepsilon) < [\alpha(\varepsilon) - q(\Delta, D, \varepsilon)]\Delta$$
,

$$(\mathrm{d}) \quad \frac{p(\Delta,\,D,\,\varepsilon)\mu(D,\,\varepsilon)}{\alpha(\varepsilon)-q(\Delta,\,\mathrm{D},\,\varepsilon)} + \delta(D,\,\varepsilon) < \frac{\alpha(\varepsilon)}{2K},$$

for  $0 < \varepsilon \leq \varepsilon_0$ .

We are now in a position to state

Theorem 2.1. If system (1) satisfies hypotheses  $(H_1) - (H_6)$ , then there exist functions  $f(t, \theta, \varepsilon)$  in  $R^n$ ,  $g(t, \theta, \varepsilon)$  in  $R^m$  which are continuous in  $R \times R^k \times (0, \varepsilon_1]$ , bounded by D, lipschitzian in  $\theta$  with lipschitz constant  $\Delta$ , such that the set

$$S_{\varepsilon} = \{(t, \theta, x, y) : x = f(t, \theta, \varepsilon), y = g(t, \theta, \varepsilon), (t, \theta) \text{ in } R \times R^k\}$$

is an integral manifold of (1). If the functions in (1) are periodic in  $\theta$  with vector period  $\omega$ , then  $f(t, \theta, \varepsilon)$ ,  $g(t, \theta, \varepsilon)$  are also periodic in  $\theta$  with vector period  $\omega$ . If the functions in (1) are T-periodic in t then  $f(t, \theta, \varepsilon)$ ,  $g(t, \theta, \varepsilon)$  are T-periodic in t. If the functions in (1) are almost periodic in t, then so are t, t.

Before proving this theorem, we state some immediate Corollaries which we again state as theorems because of their importance in the applications.

Theorem 2.2. Suppose system (1) satisfies  $(H_1)$ - $(H_5)$  even for  $\varepsilon = 0$  and  $\alpha(\varepsilon) = \alpha$  a constant. If  $\eta(0, 0) = \gamma(0, 0) = \delta(0, 0) = N(0) = 0$  and  $\alpha - L(0) > 0$ , then there are  $\varepsilon_1 > 0$  and continuous functions  $D(\varepsilon)$ ,  $\Delta(\varepsilon)$ ,  $0 < \varepsilon \le \varepsilon_1$ , approaching zero as  $\varepsilon \to 0$  such that the conclusions of Theorem 2.1 are valid for this  $D(\varepsilon)$ ,  $\Delta(\varepsilon)$ .

Proof. From the hypothesis of Theorem 2.2,  $\alpha - L(0) > 0$ . Therefore, we may take  $\varepsilon_0$  such that  $\alpha - L(\varepsilon) > 0$ ,  $0 \le \varepsilon \le \varepsilon_0$ . Since  $\eta(0,0) = 0$ , there are positive  $\varepsilon_1$ ,  $\Delta_1$ ,  $D_1$  so that (2.3a) is satisfied for  $0 < \varepsilon \le \varepsilon_1$ ,  $\Delta \le \Delta_1$ ,  $D \le D_1$ . Since  $\delta(0,0) = 0$  and N(0) = 0, it follows that one can further restrict  $\varepsilon_1$  and choose  $D(\varepsilon)$  so that  $D(\varepsilon) \to 0$  as  $\varepsilon \to 0$  and (2.3b) is satisfied for  $0 < \varepsilon \le \varepsilon_1$ . Since  $\gamma(0,0) = 0$ ,  $\delta(0,0) = 0$  it follows that  $\varepsilon_1$  and a function  $\Delta(\varepsilon) \to 0$  as  $\varepsilon \to 0$  can be chosen so that (2.3c) is satisfied for  $0 < \varepsilon \le \varepsilon_1$ . Since  $p(\Delta(\varepsilon), D(\varepsilon), \varepsilon)$ ,  $\delta(D(\varepsilon), \varepsilon) \to 0$  as  $\varepsilon \to 0$  if  $\Delta(\varepsilon)$ ,  $D(\varepsilon)$  are chosen as above, it follows that one can further restrict  $\varepsilon_1 > 0$  such that (2.3d) is satisfied for  $0 < \varepsilon \le \varepsilon_1$ . Theorem 2.1 is therefore applicable to complete the proof of Theorem 2.2.

If  $w(t, \theta, \varepsilon)$  is a constant in (1) then L = 0 and the condition  $\alpha - L > 0$  is automatically satisfied from  $(H_5)$ . The hypotheses  $(H_1)$ - $(H_4)$  in Theorem 2.2 merely express smoothness and smallness conditions on the perturbation functions  $\Theta$ , F, G.

COROLLARY 2.1. Suppose  $\Theta, F, G$  satisfy hypotheses  $(H_1) - (H_4)$  even for  $\epsilon = 0$ . Suppose w is a constant k-vector, A is an  $n \times n$  constant matrix whose eigenvalues have negative real parts, B is an  $m \times m$  constant matrix whose eigenvalues have positive real parts. Then the conclusions of Theorem 2.2 are valid for the system

$$\dot{\theta} = w + \Theta(t, \theta, x, y, \epsilon)$$

$$\dot{x} = Ax + F(t, \theta, x, y, \epsilon)$$

$$\dot{y} = By + G(t, \theta, x, y, \epsilon)$$

Consider the system

(2.4) 
$$\begin{split} \dot{\theta} &= w + \varepsilon \Theta(t,\,\theta,\,x,\,y,\,\varepsilon), \\ \dot{x} &= \varepsilon A(\theta) x + \varepsilon F(t,\,\theta,\,x,\,y,\,\varepsilon), \\ \dot{y} &= \varepsilon B(\theta) y + \varepsilon G(t,\,\theta,\,x,\,y,\,\varepsilon), \end{split}$$

where w is a constant.

THEOREM 2.3. Suppose A, B, w, 0, F, 0 in system (2.4) satisfy hypotheses (Hl)-(H4) even for e = 0 and y(0, 0) = 8(0, 0) = N(0) = 0. If a =eal, al > 0, a constant, in (H5) and al - e) > 0, then the conclusions of Theorem 2.2 are valid for system (2.4).

PROOF. It is sufficient to satisfy relations (2.3) with L = 0 and a(E) replaced by al since the form of equation (2.4) implies that E is a common factor of all functions in (2.3). The proof proceeds now exactly as in the proof of Theorem 2.2.

Consider the system

$$egin{align} arepsilon hinspace & arepsilon hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspace hinspa$$

where w is a constant.

THEOREM 2.4. Suppose A, B, w, 0, F, G in system (2.5) satisfy (Hl)-(H4) even for e = 0, y(0, 0) = 5(0, 0) = N(0) = 0. If a = al/E, al > 0, a constant in (H5) and al - limEyer1(0. e) > 0, then the conclusions of Theorem 2.2 are valid for system (2.5).

PROOF. The proof is essentially the same as the proof of Theorem 2.3. The proof of Theorem 2.1 will be broken down into simple steps in order to clarify the basic ideas. Some of these steps are of interest in themselves and are stated as lemmas. One could use the same method of proof as given below to state results on integral manifolds involving systems which are combinations of systems (1), (2.4) and (2.5). These results are easily obtained when the need arises and it does not seem worthwhile to state them in detail.

## VII.3. A "Nonhomogeneous Linear" System

In the proof of Theorem 2.1, we will use successive approximations in a manner very similar to that used in Chapter IV for the results on the behavior near an equilibrium point. Let Sn={f: (-oo, co) x Rk --> Rn which are continuous and bounded). For any f in Sn, define Ilf II = sup{I If (t, 0)j, (t, 0) in B x Rk}. The idea for successive approximations in (1) for an integral manifold is to let x =f (t, 0), fin Sn, y = g(t, 0), g in Sm, in the first equation in (1) to obtain an equation in 0 alone say A = h(t, 0, f, g). This equation can be solved for 0(t, r, , f, g) where e(T) = C for any r, 4 in R x Rk. This function of 0 is then substituted in the second and third eon-,tions in (1) to obtain equations of the form

$$\dot{x} = A( heta(t))x + \dot{f}(t, \, heta(t)), \ \dot{y} = B( heta(t))y + \dot{g}(t, \, heta(t)),$$

where f, g depend upon f, g, but, more importantly, the initial data for 0(t); namely r, . The problem is then to determine a bounded solution of this system as a function of (r, C).

Thus, we are led to a type of " nonhomogeneous linear" system. We refer to the equations in this manner because at each stage in the iteration process the equations are linear in x, y; that is, linear in the coordinates through which the integral manifold is defined. For simplicity in the notation, we will assume that the y-equation in (1) is absent. The general case follows along the same lines. For any P in Sk, Q in Sn, we first consider the " nonhomogeneous linear " system

(3.1) 
$$\begin{aligned} (\mathbf{a}) \quad & \dot{\theta} = P(t,\,\theta), \\ (\mathbf{b}) \quad & \dot{x} = A(\theta)x + Q(t,\,\theta). \end{aligned}$$

For any (T, in R x Bk, let 0\*(t) = 0\*(t, T, , P) be the solution of (3.1a) with 0\*(T) \_ . Since P(t, 0) is bounded, such a solution always exists on (- co, oo )."We wish to find a function X(-, ,P, Q) in Sn such that

$$(\theta^*(t), X(t, \theta^*(t), P, Q)), \quad t \text{ in } (-\infty, \infty),$$

is a solution (3.1) for tin (-oo, oo) and all (T, ) in R x Rk. If we can accomplish this, then the set 9 = {(t, 0, x) : x = X(t, 0, P, Q), (t, 0) in B X R k} is an integral manifold of (3.1). To derive the equation for such a function X, let D(t, r, , P) be the principal matrix solution of the linear system

$$\dot{x} = A(\theta^*(t, \tau, \zeta, P))x$$

The variation of constants formula applied to (3.1b) yields

$$X(t, \theta^*(t, \tau, \zeta, P), P, Q) = \Phi(t, \tau, \zeta, P)X(\tau, \zeta, P, Q) + \int_0^t \Phi(t, s, \zeta, P)Q(s, \theta^*(s, \tau, \zeta, P)) ds, \qquad t \in (-\infty, \infty).$$

If A is independent of 0, then this relation is much simpler since I(t, r, , P) = exp[A(t -T)]. Multiplying the above relation by-1(t, T, , P) and using the properties of a principal matrix solution, one sees that the variation of constants formula can be written as

$$\begin{split} X(\tau,\,\zeta,\,P,\,Q) &= \Phi(\tau,\,t,\,\zeta,\,P) X(t,\,\theta^*(t,\,\tau,\,\zeta,\,P),\,P,\,Q) \\ &- \int_{\tau}^{t} \Phi(\tau,\,s,\,\zeta,\,P) Q(s,\,\theta^*(s,\,\tau,\,\zeta,\,P)) \; ds, \qquad t \in (-\infty,\,\infty). \end{split}$$

Since X is assumed to belong to Sn and, in particular, is bounded, we can let t approach - co in this relation and use hypothesis (H5) to obtain

$$(3.3) \quad X(t,\,\theta,\,P,\,Q) = \int_{-\,\infty}^{0}\,\Phi(t,\,u+t,\,\theta,\,P)Q(u+t,\,\theta^{*}(u+t,\,t,\,\theta,\,P))\,du,$$

where we have replaced T, C in the end result by t, 0.

In the manner in which relation (3.3) was obtained, it follows that (3.3) defines an integral manifold of (3.1) and, furthermore, it is the only such integral manifold which remains in a region for which the x-coordinate is bounded. These facts are summarized in

LEMMA 3.1. If (H5) is satisfied, then for any P in Sk, Q in Sn, equation (3.1) has an integral manifold defined parametrically by X(t, 0, P, Q) in (3.3) and it is the only integral manifold of (3.1) for which the x coordinate is bounded.

Our initial goal is to derive some properties of the function X(t, 0, P, Q) defined by (3.3). In particular, we wish to discuss bounds and smoothness properties of X as a function of the bounds and smoothness properties of P, Q. The basic result for the " nonhomogeneous linear " system (3.1) is the following:

LEMMA 3.2. Suppose A(0), P(t, 0), Q(t, 0) are lipschitzian in 0 with lipschitz constants r, L(P), M(Q), respectively, and hypotheses (H5) is satisfied with a > L(P). If X(-, , P, Q) is defined by (3.3), then X(-, , P, Q) belongs to Sn, defines an integral manifold of (3.1) and satisfies

(3.4)

(a) 
$$|X(t, \theta, P, Q) - X(t, \bar{\theta}, P, Q)| \le \frac{K}{\alpha - L(P)} \left[ M(Q) + \frac{Kr}{\alpha} \|Q\| \right] |\theta - \bar{\theta}|,$$

$$(b) \quad \|X(\cdot,\,\cdot,\,P,\,Q) - X(\cdot,\,\cdot,\,P,\,\bar{Q})\| \leqq \frac{K}{\alpha}\,\|Q - \bar{Q}\|,\,X(\cdot,\,\cdot,\,P,\,0) = 0,$$

$$\begin{split} \text{(c)} \quad & \|X(\cdot,\,\cdot,\,P,Q) - X(\cdot,\,\cdot,\,\vec{P},Q)\| \leq \frac{K}{\alpha(\alpha - L(P))} \\ & \times \left\lceil M(Q) + \frac{Kr}{\alpha} \, \|Q\| \right\rceil \|P - \vec{P}\|, \end{split}$$

for all t in R,  $\theta$ ,  $\bar{\theta}$  in  $R^k$ , P,  $\bar{P}$  in  $S^k$ , Q,  $\bar{Q}$  in  $S^n$ . If  $P(t, \theta)$ ,  $Q(t, \theta)$  are periodic in  $\theta$  with vector period  $\omega$ , then  $X(t, \theta, P, Q)$  is periodic in  $\theta$  with vector period  $\omega$ . If  $P(t, \theta)$ ,  $Q(t, \theta)$  are T-periodic (or almost periodic) in t, then  $X(t, \theta, P, Q)$  is T-periodic (or almost periodic) in t. If  $P(t, \theta)$ ,  $Q(t, \theta)$  are independent of t, then  $X(t, \theta, P, Q)$  is independent of t.

PROOF. Relation (3.4b) is almost immediate since  $X(\cdot, \cdot, \cdot, Q)$  is linear in Q and hypothesis  $(H_5)$  implies that

$$||X(\cdot, \cdot, \cdot, Q)|| \leq \frac{K||Q||}{\alpha}$$

The relations (3.4a), (3.4c) are more difficult to obtain since  $\theta^*(\cdot, \cdot, \theta, P)$  depends in a nonlinear fashion on  $\theta$  and P. This nonlinear dependence is also reflected in the function  $\Phi(\cdot, \cdot, \theta, P)$  if A depends on  $\theta$ . Our first objective is to obtain estimates of this dependence on  $\theta$ , P.

Since  $P(t, \theta)$  is lipschitzian in  $\theta$  with lipschitz constant L(P), a simple application of differential inequalities to (3.1a) yields the estimates

$$(3.5) \quad (a) \quad |\theta^*(t,\tau,\zeta,P) - \theta^*(t,\tau,\bar{\zeta},P)| \leq e^{L(P)|t-\tau|}|\zeta - \bar{\zeta}|,$$

$$(b) \quad \left|\theta^*(t,\,\tau,\,\zeta,\,P) - \theta^*(t,\,\tau,\,\zeta,\,\bar{P})\right| \leq \frac{e^{L(P)\,|t-\tau|}-1}{L(P)}\,\|P - \bar{P}\|,$$

for all t,  $\tau$  in R and P,  $\overline{P}$  in  $S^k$ . In fact, both of these relations are easily obtained from the relation

$$D^+\gamma(u) \leq L(P)\gamma(u) + \|P - \bar{P}\|$$

where  $D^+$  is the right hand derivative,  $\gamma(u) = |\theta^*(u, \tau, \zeta, P) - \theta^*(u, \tau, \zeta, \bar{P})|$  to obtain (3.5b) and  $\gamma(u) = |\theta^*(u, \tau, \zeta, P) - \theta^*(u, \tau, \bar{\zeta}, P)|$ ,  $P = \bar{P}$  to obtain (3.5a)

We now obtain estimates for the dependence of  $\Phi(t, \tau, \theta, P)$  on  $\theta, P$ . If we use the fact that this is a principal matrix solution of (3.2) and the difference  $\Phi(u, \tau, \theta, P) - \Phi(u, \tau, \bar{\theta}, \bar{P})$  is a solution of the matrix equation

$$\frac{dx}{du} = A(\theta^*(u, \tau, \theta, P)) x + [A(\theta^*(u, \tau, \theta, P)) - A(\theta^*(u, \tau, \bar{\theta}, \bar{P}))]\Phi(u, \tau, \bar{\theta}, \bar{P}),$$

then the variation of constants formula yields

$$\begin{split} \Phi(t,\,u+t,\,\theta,\,P) - \Phi(t,\,u+t,\,\bar{\theta},\,\bar{P}) &= \int_u^0 \Phi(t,\,v+t,\,\theta,\,P) \\ &\times [A(\theta^*(v+t,\,u+t,\,\theta,\,P)) - A(\theta^*(v+t,\,u+t,\,\bar{\theta},\,\bar{P})] \\ &\times \Phi(v+t,\,u+t,\,\bar{\theta},\,\bar{P})\,dv \end{split}$$

for all  $u \in \mathbb{R}$ . Therefore, from  $(H_5)$  and the lipschitzian hypothesis on A, we obtain

$$\begin{aligned} (3.6) \qquad |\Phi(t, u+t, \theta, P) - \Phi(t, u+t, \overline{\theta}, \overline{P})| \\ &\leq K^2 r e^{\alpha u} \int_u^0 |\theta^*(v+t, u+t, \theta, P) - \theta^*(v+t, u+t, \overline{\theta}, \overline{P})| \ du \end{aligned}$$

for  $u \leq 0$ .

If we let  $P = \overline{P}$  and use (3.5a) and (3.6), then

$$(3.7) \quad |\Phi(t, u+t, \theta, P) - \Phi(t, u+t, \bar{\theta}, P)| \leq \frac{K^2 r}{L(P)} e^{\alpha u} [e^{-L(P)u} - 1] |\theta - \bar{\theta}|$$

for all  $u \leq 0$ . If we let  $\theta = \bar{\theta}$  and use (3.5b) and (3.6), then

$$|\Phi(t, u+t, \theta, P) - \Phi(t, u+t, \theta, \bar{P})| \leq \frac{K^2 r}{L^2(P)} e^{\alpha u} [e^{-L(P)u} - 1 + L(P)u] \|P - \bar{P}\|$$

for all  $u \leq 0$ .

From (3.3) and  $(H_5)$  we have

$$\begin{split} |X(t,\,\theta,\,P,\,Q) - X(t,\,\bar{\theta},\,P,\,Q)| \\ & \leq \int_{-\,\infty}^{0} Ke^{\alpha u} M(Q) |\theta^*(u+t,\,t,\,\theta,\,P) - \theta^*(u+t,\,t,\,\bar{\theta},\,P)| \; du \\ & + \int_{-\,\infty}^{0} |\Phi(t,\,u+t,\,\theta,\,P) - \Phi(t,\,u+t,\,\bar{\theta},\,P)| \; \|Q\| \; du. \end{split}$$

Using (3.5a) and (3.7), we obtain relation (3.4a). Similar estimates using (3.5b) and (3.8) give (3.4c). This completes the proof of the first part of the lemma.

Now suppose that P,Q in (3.1) have vector period  $\omega$  in  $\theta$ . The uniqueness theorem implies  $\theta^{*, \gamma}$ ,  $\zeta + \omega$ ,  $P) = \theta^*(t, \tau, \zeta, P) + \omega$  and, thus  $\Phi(t, \tau, \theta + \omega, P) = \Phi(t, \tau, \theta, P)$ . From formula (3.3), one obtains  $X(t, \theta + \omega, P, Q) = X(t, \theta, P, Q)$ . If P,Q in (3.1) are T-periodic in t, then uniqueness of solutions yields  $\theta^*(t + \tau + T, \tau + T, \zeta, P) = \theta^*(t + \tau, \tau, \zeta, P)$ . This fact in turn implies  $\Phi(t + \tau, \tau, \theta, P)$  is T-periodic in  $\tau$ . Since

 $\Phi(\tau, t + \tau, \theta, P)\Phi(t + \tau, \tau, \theta, P) = I$ , the function  $\Phi(\tau, t + \tau, \theta, P)$  is T-periodic in  $\tau$ . Using (1.3), one has  $X(t, \theta, P, Q)$  is T-periodic in t. If  $P(t, \theta)$ ,  $Q(t, \theta)$  are independent of t, then the same argument yields  $X(t, \theta, P, Q)$  is periodic in t with an arbitrary period and, therefore, must be independent of t.

The case where P,Q are almost periodic in t is handled as follows. If  $\delta$  is any real number, we define  $P_{\delta}$  in  $S^k$ ,  $Q_{\delta}$  in  $S^n$  by  $P_{\delta}(t,\theta) = P(t+\delta,\theta)$ ,  $Q_{\delta}(t,\theta) = Q(t+\delta,\theta)$ . Using the same process as in the estimation of the lipschitz function of  $\theta^*(t,\tau,\zeta,P)$  in P, one easily obtains

$$\left|\theta^*(u+t+\delta,t+\delta,\theta,P)-\theta^*(u+t,t,\theta,P)\right| \leqq \frac{e^{L(P)|u|}-1}{L(P)} \|P_\delta-P\|$$

for all  $u, t, \theta$ . Now using the same type of argument that was used to obtain (3.8), one obtains

$$\begin{split} |\Phi(t+\delta,\,u+t+\delta,\,\theta,\,P) - \Phi(t,\,u+t,\,\theta,\,P)| \\ &\leq \frac{K^2 r}{L^2(P)} \,e^{\alpha u} [e^{-L(P)u} - 1 + L(P)u] \, \|P_\delta - P\| \end{split}$$

for all  $u \leq 0$ . Using these two relations in (3.3), we arrive at the following inequality

$$\begin{split} |X(t+\delta,\,\theta,\,P,\,Q) - X(t,\,\theta,\,P,\,Q)| \\ &\leq \frac{K}{\alpha} \, \|Q_{\delta} - Q\| + \frac{K}{\alpha(\alpha - L(P))} \, [M(Q) + \frac{Kr}{\alpha} \, \|Q\|] \, \|P_{\delta} - P\| \end{split}$$

for all  $t, \delta, \theta$ . This inequality and the same type of argument as used in the proof of Theorems 1.1 and 2.1 of Chapter IV complete the proof of Lemma 3.2.

The constant  $\alpha$  in the statement of Lemma 3.2 is a measure of the rate of approach of the solutions of (3.1) to the integral manifold and the constant L(P) is a measure in some sense of the maximum rate at which solutions on the manifold can converge or diverge from one another. A natural question to ask is whether the condition  $\alpha - L(P)$  is necessary to obtain lipschitz smoothness of the parametric representation of the manifold.

To understand some of the difficulties that might be encountered if  $\alpha - L(P) < 0$ , let us discuss the following example in the two-dimensional (u, v)-space. If  $u = r \cos \theta$ ,  $v = r \sin \theta$ , the system is

$$\dot{\theta} = k \sin \theta - \frac{\cos \theta}{r \sin \theta} (r - 1)^2,$$
 $\dot{r} = r(1 - r).$ 

The circle r=1 is an integral manifold of this system. If  $r=1+\rho$ , then the linear variational equation for the manifold r=1 is  $\dot{\rho}=-\rho$  and the constant

a in hypothesis Hs) is +1. On the other hand, on the manifold r = 1, the Liptschitz constant L(P) can be taken to be k. Also, on r = 1, there are the stable node (-1, 0) and the saddle point (1, 0). The trajectories of this system near r = 1 for k < 1 and >I are shown in Fig. 3.1. For k < 1 all

![](_page_253_Picture_3.jpeg)

Figure VII.3.1

orbits enter the node (-1, 0) tangent to the circle r = 1 and for k > 1 all orbits enter the node (-1, 0) perpendicular to the circle r = 1. A small perturbation in the equation for k > 1 could possibly lead to an invariant curve which has a cusp at (-1, 0).

The following example shows that a cusp can arise. Consider the system

$$egin{aligned} \dot{ heta} &= k \sin \, heta, \ \dot{x} &= -x + f( heta), \end{aligned}$$

where f has a continuous first derivative and  $f(\theta + 2\pi) = f(\theta)$ . The first equation has the solution

$$\theta^*(t, \tau, \zeta) = 2 \arctan \left(e^{k(t-\tau)} \tan \frac{\zeta}{2}\right),$$

and therefore the integral manifold is given from (3.3) by

$$X(t,\, heta,\,k)\equiv X( heta,\,k)=\int_{-\,\infty}^{0}e^{u}figgl[2rc aniggl(e^{ku} anrac{ heta}{2}iggr)iggr]du.$$

For any closed interval in the interior of  $(-\pi, \pi)$ ,

$$\frac{\partial X(\theta,\,k)}{\partial \theta} = \int_{-\,\,\infty}^0 \,e^{(1-k)\,u}\,\frac{df}{d\theta} \bigg[\sin^2\frac{\theta}{2} + e^{-2k\,u}\,\cos^2\frac{\theta}{2}\bigg]^{-1}\,du$$

exists and is continuous for any k. If k > 1, this integral becomes unbounded as  $\theta \to \pi$  or  $-\pi$  if  $df/d\theta$  is different from zero in a neighborhood of these points and  $X(\theta, k)$  is not lipschitzian.

#### VII.4. The Mapping Principle

To apply Lemma 3.2 to prove Theorem 2.1, we define a mapping whose fixed points coincide with the integral manifold of (1) and prove this mapping is a contraction. It is convenient to formulate this mapping in more general terms and specialize it to system (1) later. For given constants  $\Delta$ , D, let

$$(4.1) S^n(\Delta, D) = \{f \text{ in } S^n : ||f|| \leq D, |f(t, \theta) - f(t, \overline{\theta})| \leq \Delta |\theta - \overline{\theta}|$$
 for all  $(t, \theta, \overline{\theta})$  in  $R \times R^k \times R^k\}.$ 

Let  $P: R \times R^k \times S^n(\Delta, D) \to R^k$ ,  $Q: R \times R^k \times S^n(\Delta, D) \to R^n$  and for any f in  $S^n(\Delta, D)$  suppose that  $P(\cdot, \cdot, f)$  is in  $S^k$  and  $Q(\cdot, \cdot, f)$  is in  $S^n$ . For any f in  $S^n(\Delta, D)$ , we know from the discussion of system (3.1) that the system

(4.2) 
$$\dot{\theta} = P(t, \theta, f),$$

$$\dot{x} = A(\theta)x + Q(t, \theta, f),$$

has an integral manifold defined parametrically by (3.3). We rewrite (3.3) again to emphasize the dependence upon f as

(4.3) 
$$X^*(t, \theta, f) = \int_{-\infty}^{0} \Phi_1(t, u + t, \theta, f) Q(u + t, \theta_1(u + t, t, \theta, f)) du,$$

where we are using the simplified but hopefully not confusing notation

$$\begin{split} \theta_1(t,\,\tau,\,\zeta,f) &= \theta^*(t,\,\tau,\,\zeta,\,P(\,\cdot\,,\,\cdot\,,f)),\\ \Phi_1(t,\,\tau,\,\zeta,f) &= \Phi(t,\,\tau,\,\zeta,\,P(\,\cdot\,,\,\cdot\,,f)),\\ X^*(t,\,\theta,f) &= X(t,\,\theta,\,P(\,\cdot\,,\,\cdot\,,f),\,Q(\,\cdot\,,\,\cdot\,,f)) \end{split}$$

If there exists an f in Sn(A, D) such that f (t; 0) = X\*(t, 0, f ), then f will ,define an integral manifold of (4.2). It is clear that such a procedure will be applicable to system (1) without the y equation simply by defining

(4.4) 
$$P(t, \theta, f) = w(t, \theta, \varepsilon) + \Theta(t, \theta, f(t, \theta), \varepsilon),$$
$$Q(t, \theta, f) = F(t, \theta, f(t, \theta), \varepsilon).$$

We now derive some conditions on P, Q which will ensure that the map X\*(-, ,f ), f in Sn(0, D) is a contraction.

Assume the following: there are constants f(D), M(0, D), L(0, D) and a(D), b(D) such that

$$\begin{aligned} \|Q(\cdot,\cdot,f)\| &\leq \beta(D), \\ \|Q(\cdot,\cdot,f) - Q(\cdot,\cdot,\bar{f})\| &\leq a(D)\|f - \bar{f}\|, \\ \|P(\cdot,\cdot,f) - P(\cdot,\cdot,\bar{f})\| &\leq b(D)\|f - \bar{f}\|, \\ \|Q(t,\theta,f) - Q(t,\bar{\theta},f)\| &\leq M(\Delta,D)\|\theta - \bar{\theta}\|, \\ \|P(t,\theta,f) - P(t,\bar{\theta},f)\| &\leq L(\Delta,D)\|\theta - \bar{\theta}\|, \end{aligned}$$

for all (t, 0, 8) in R X Rk X Rk and f, f in S- (A, D).

If we now use (3.4) with M(Q), L(P) replaced by M(L, D), L(0, D), respectively,

$$\begin{split} (\|X^{\textstyle *}\cdot,\,\cdot,f)\| & \leq \frac{K}{\alpha}\beta(D), \\ |X^{\textstyle *}(t,\,\theta,f) - X^{\textstyle *}(t,\,\bar{\theta},f)| & \leq \frac{KM_1(\Delta,\,D)}{\alpha - L(\Delta,\,D)} \,|\,\theta - \bar{\theta}|, \\ \|X^{\textstyle *}(\cdot,\,\cdot,f) - X^{\textstyle *}(\cdot,\,\cdot,\bar{f})\| & \leq \frac{K}{\alpha} \left[\frac{M_1(\Delta,\,D)b(D)}{\alpha - L(\Delta,\,D)} + a(D)\right] \|f - \bar{f}\|, \\ M_1(\Delta,\,D) & = M(\Delta,\,D) + \frac{Kr}{\alpha}\,\beta(D). \end{split}$$

for all (t, 0, 8) in R X Rk X Rk and f, f in Sn(A, D) provided that L(i, D) > 0. From these relations we can state the following

LEMMA 4.1. Suppose Q, P satisfy (4.5) and for any f in Sn(A, D), the unique integral manifold X\* f) of (4.2) is defined by (4.3). The mapping

T : Sn(A, D) ->.Sn(A, D) defined by Tf = f) is a contraction provided that A, D satisfy the relations

$$(4.7) \qquad (a) \quad \alpha - L(\Delta, D) > 0,$$

$$(b) \quad K\beta(D) < \alpha D,$$

$$(c) \quad KM_1(\Delta, D) < [\alpha - L(\Delta, D)]\Delta,$$

$$(d) \quad \frac{K}{\alpha} \left[ \frac{M_1(\Delta, D)b(D)}{\alpha - L(\Delta, D)} + a(D) \right] < \frac{1}{2}.$$

If conditions (4.7) are satisfied, then X\*(-, , f) has a unique fixed point in Sn(&, D).

## VII.5. Proof of Theorem 2.1

We are now in a position to prove Theorem 2.1 for the case when y is absent. The only thing to do is to find the constants in (4.5) with P, Q defined by (4.4) and substitute these in (4.7). From hypotheses (H2)-(H4), one obtains, for 0 < e 5 Eo,

$$\begin{array}{ll} \text{(5.1)} & \text{(a)} \quad \beta(D) = \delta(D,\,\varepsilon)D + N(\varepsilon), \\ \text{(b)} \quad a(D) = \delta(D,\,\varepsilon), \\ \text{(c)} \quad b(D) = \mu(D,\,\varepsilon), \\ \text{(d)} \quad M(\Delta,\,D) = \gamma(D,\,\varepsilon) + \delta(D,\,\varepsilon)\Delta, \end{array}$$

(e) L(0, D) = L(e) +77(D, e) + µ(D, e)0.

If (5.1) is used in (4.7), one obtains relation (2.3) in hypotheses (Hs). This completes the proof of Theorem 2.1 when the vector y is absent. The case with y present follows along the same lines if use is made of the

fact that the equation 
$$egin{aligned} & heta = P(t,\, heta), \ &\dot x = A( heta)x + Q(t,\, heta), \ &\dot y = B( heta)y + R(t,\, heta), \end{aligned}$$

has a unique integral manifold given by X(t, 0, P, Q), Y(t, 0, P, R) with X given by (3.3) and

$$Y(t, \, \theta, \, P, \, R) = \int_0^\infty \Psi(\dot{t}, \, u+t, \, \theta, \, P) R(u+t, \, \theta^*(u+t, \, t, \, \theta, \, P)) \, du$$

where 'Y(t, r, , P) is the principal matrix solution of the linear system

$$\dot{y} = B(\theta^*(t, \tau, \zeta, P))y.$$

## VII.6. Stability of the Perturbed Manifold

For the unperturbed part of system (1), namely,

(6.1) 
$$\begin{split} \dot{\theta} &= w(t,\,\theta,\,\varepsilon), \\ \dot{x} &= A(\theta,\,\varepsilon)x, \\ \dot{y} &= B(\theta,\,\varepsilon)y, \end{split}$$

there is a unique integral manifold with the x and y coordinates bounded and this is given by x = 0, y = 0. This manifold has a saddle point structure in the sense that any solution of (6.1) is such that x -- 0 exponentially as t -\* 00 and y -a 0 exponentially as t -\* - oo. One can prove that the saddle point structure is also preserved for the perturbed manifold whose existence is assured by Theorem 2.1.

We do not prove this fact in detail, but only indicate the proof for the special case

(6.2) 
$$\begin{aligned} \dot{\theta} &= 1 + \Theta(t, \theta, \rho, \epsilon) \\ \dot{\rho} &= A\rho + R(t, \theta, \rho, \epsilon) \end{aligned}$$

where O(t,0,p,e), R(t,0,p,e) are continuous, bounded and continuously differentiable in 0,p in R X R X SZ(p, eo), periodic in 0 of period w, e(t, 0, 0, 0) = 0, R(t,0,0,0) = 0, aR(t,0,0,0)/ap = 0, and the eigenvalues of A have negative real parts.

Corollary 2.1 implies there exists an integral manifold SE = {(t,0,x): x = f(t,0,e), (t,0) G R2}' 0 < Iel < eo, f(t,0,e) is periodic in 0 of period w and ft,0,0) = 0. Our first objective is to show there is a neighborhood V C R22 X R" of {(t,0,p):p = 0} such that if (to,00, po) E V, then the solution (0(t),p(t)) of (6.2) through (t0,00,po) satisfies

$$|\rho(t) - f(t, \theta(t), \epsilon)| \to 0$$
 as  $t \to \infty$ .

This shows that solutions go back to the integral manifold as t °°. We will also show that this approach is at an exponential rate.

To do this, we consider all solutions of the equations (6.2). The variation of constants formula gives

(6.3) 
$$\rho(t) = e^{A(t-t_0)}\rho_0 + \int_{t_0}^t e^{A(t-s)}R(s,\theta(s),\rho(s),\epsilon)ds$$

$$\dot{\theta}(t) = 1 + \Theta(t,\theta(t),\rho(t),\epsilon), \qquad \theta(t_0) = \theta_0.$$

We first show there is a function '(t,0,t0,P0,e), w-periodic in 0, such that the solution of (6.3) can be represented as

(6.4) 
$$\rho(t) = \Psi(t, t_0, \theta(t), \rho_0, \epsilon).$$

As in the proof of the existence of the integral manifold S, we transform this to a problem of finding a fixed point of a certain mapping. Let

$$\tilde{S}^1 = \{\Psi : \{(t, t_0) : t \ge t_0\} \times R \times R^n \to R^n, \text{ continuous, bounded,} \}$$

together with first derivatives in 0, p}.

For 'I' in S1, let

$$|\Psi| = \sup\{|\Psi(t, t_0, \theta, \rho)| + |\partial \Psi(t, t_0, \theta, \rho)/\partial \theta| + |\partial \Psi(t, t_0, \theta, \rho)/\partial \rho| : t \ge t_0, (\theta, \rho) \in R \times R^n\}.$$

The smoothness assumptions here are only to make the notation simpler. For 'Pin S1 and t <,r, let

$$(T\Psi)(\tau, t, \theta, \rho) = e^{A(\tau - t)}\rho + \int_{t}^{\tau} e^{A(\tau - s)}R(s, \theta * (s), \Psi(s, t, \theta * (s), \rho), \epsilon)$$

$$\theta * (s) = 1 + \Theta(s, \theta(s), \Psi(s, t, \theta * (s), \rho), \epsilon), \qquad \theta * (t) = \theta.$$

One can now proceed as before to show that T is a contraction on an appropriate subset of 91 to obtain a fixed point of T (or one can use the implicit function theorem). If 'P = T'Y, we have shown that (6.4) is satisfied. There is a continuous function M(o,eo), o > 0, lel <eo,M(0,0) = 0, constants k> 0, u> 0 such that, for 1 po I < o, I e I < eo,

$$\begin{aligned} |\partial \Psi(t, t_0, \theta, \rho_0, \epsilon)/\partial \theta| &\leq M(\sigma, \epsilon_0) \\ |\partial \Psi(t, t_0, \theta, \rho_0, \epsilon)/\partial \rho| &\leq K e^{-\alpha(t - t_0)/2}, \qquad t \geq t_0 \\ |e^{At}| &\leq K e^{-\alpha t}, \qquad t \geq 0. \end{aligned}$$

For po sufficiently small, we know that the solution of (6.2) through (to,00,po) satisfies (6.4) for t > to. Thus, our integral manifold SE must also have this property; that is, for any t > to, 0 E R, there is a 0' = 0o(t,0) such that the solution (0'(s),p'(s)) of (6.2) through (to,0'o, f (to, 0'o, e)) satisfies 0'(t) = 0, p'(t) = f(t,0,e). To obtain this assertion, we have simply integrated backwards from- t to to starting from the point (t,0,f(t,0,e)). Thus, if po =f(to,0o,e), then

$$f(t,\theta,\epsilon) = \Psi(t,t_0,\theta,\rho',\epsilon)$$

for all t,0 and

$$|f(t,\theta,\epsilon) - \Psi(t,t_0,\theta,\rho_0,\epsilon)| \le Ke^{-\alpha(t-t_0)/2} |\rho_0' - \rho_0|.$$

If (0(t),p(t)) is any solution of (6.2) with 0(t0) = 00, p(to) = Po, PO sufficiently small, we have

$$|f(t,\theta(t),\epsilon) - \Psi(t,t_0,\theta(t),\rho_0,\epsilon)| \\ \leq Ke^{-\alpha(t-t_0)/2}|f(t_0,\theta'_0(t,\theta(t),\epsilon) - \rho_0| \\ \leq 2Ke^{-\alpha(t-t_0)/2}, \qquad t \geq t_0.$$

This proves the asserted stability of the integral manifold  $S_{\epsilon}$ .

#### VII.7. Applications

In this section, we give some applications of the theory of this chapter. There is such a large variety of applications that it is impossible to do them justice without devoting a treatise to the subject. However, it is hoped that the few mentioned below together with the ones delegated to the exercises in Section 8 may indicate the possible scope of the theory and stimulate further reading in the literature.

Suppose the equation

$$\dot{x} = f(x)$$

where f has continuous first derivatives in  $\mathbb{R}^n$ , has a nonconstant  $\omega$ -periodic solution u whose linear variational equation

$$\dot{y} = \frac{\partial f(u(t))}{\partial x} y$$

has n-1 characteristic multipliers not on the unit circle. Suppose also that g(t, x) is continuous for (t, x) in  $R \times R^n$ , has continuous first derivatives with respect to x and is bounded for t in R and x in any compact set.

THEOREM 7.1 Under the above hypotheses, there are a neighborhood U of the periodic orbit  $\mathscr{C} = \{x : x = u(\theta), 0 \le \theta \le \omega\}$  and an  $\varepsilon_1 > 0$  such that the system

$$\dot{x} = f(x) + \varepsilon g(t, x)$$

has an integral manifold  $S_{\varepsilon}$  in  $R \times U$ ,  $0 \le |\varepsilon| \le \varepsilon_1$ ,  $S_0 = R \times \mathscr{C}$  (a cylinder),  $S_{\varepsilon}$  is asymptotically stable if n-1 multipliers of (7.2) are inside the unit circle and unstable if one is outside the unit circle. The set  $S_{\varepsilon}$  has a parametric representation given by

$$S_{\varepsilon} = \{(t, x) : x = u(\theta) + v(t, \theta, \varepsilon), (t, \theta) \text{ in } R \times R\},\$$

where  $v(t, \theta, 0) = 0$ ,  $v(t, \theta, \varepsilon) = v(t, \theta + \omega, \varepsilon)$  and is almost periodic (*T*-periodic) in t if  $g(t, \theta)$  is almost periodic (*T*-periodic) in t.

PROOF. This is a simple consequence of the previous results. In fact, using the coordinate transformation in Chapter VI, one obtains a special

case of system (1). The above hypotheses permit a direct application of Theorem 2.2 to obtain existence of the manifold for the interval 0 < e < el. Replacing e by -e one obtains the result on -el < -s <0. Defining the manifold of (1) to be zero at e = 0 completes the proof of existence. Stability is a consequence of the remarks in Section 6.

In case g in (7.3) is periodic in t of period T, then the integral manifold SE given in Theorem 7.1 has a parametric representation which is periodic in t of period T. The cross section of SE at t = 0 and t = T are therefore the same and the fact that it is an integral manifold implies this cross section is mapped into itself through the solutions of the differential equation. Since the differential equation is T-periodic, following a solution x(t, xo), x(0, xo) = xo, from t = 0 to t = 2T is the same as following the solution from t = 0 to t = T and then following the solution x(t, x(T, xo)) from t = 0 to t = T. The solutions of (7.3) on SE in this case can therefore be considered as a differential equation without critical points on the torus obtained by taking the section of the surface SE from t = 0 to t = T and identifying the ends of this section. The theory of Chapter II then gives the possible behavior of the solutions on SE .

THEOREM 7.2. Suppose f (x) satisfies the conditions of Theorem 7.1 and let,g(t, x) be continuous and uniformly bounded together with its first partial derivatives with respect to x in a neighborhood of W. If g(t, x) is almost periodic in t uniformly with respect to x and

$$M[g(\cdot, x)] = \lim_{T \to \infty} \frac{1}{T} \int_0^T g(t, x) dt = 0,$$

then there are a neighborhood U of f and an coo > 0 such that the system

$$\dot{x} = f(x) + g(\omega t, x)$$

has an integral manifold So) in R X U, co >\_ coo, S. -\* R x' as w -a oo, S. is asymptotically stable if n - 1 multipliers of (7.2) are inside the unit circle and unstable if one is outside the unit circle. The set S. has a parametric representation given by

$$S_{\omega} = \{(t, x) : x = u(\theta) + v(\omega t, \theta, \omega^{-1}), (t, \theta) \text{ in } R \times R\},$$

where v(t, 0, 0) = 0, v(t, 0, a) = v(t, 0 + co, a) and is almost periodic in t.

PROOF. From Lemma 5 of the Appendix, for any -9 > 0, there are a function w(t, x, 71) with as many derivatives in x as desired and a function 0 as 0 such that

$$|\partial w(t, x, \eta)/\partial t - g(t, x)| < \sigma(\eta)$$

for all t e R and x in a neighborhood of W. Also 77w, qaw/ax -\* 0 as q -\* 0. Therefore, as in the proof of Lemma V.3.2, there is an coo > 0 such that the transformation

$$x = y + \frac{1}{\omega} w \left( \omega t, y, \frac{1}{\omega} \right)$$

is a homeomorphism in a neighborhood of  $\mathscr{C}$ . If this transformation is applied to (7.4) one obtains a system

$$\dot{y} = f(y) + G(\omega t, y, \omega^{-1}),$$

where  $G(\tau, y, \omega^{-1})$  is continuous in  $\tau, y, \omega$  together with its first derivative with respect to y, is uniformly bounded for  $\tau$  in R, y in a neighborhood of  $\mathscr C$  and  $\omega \geq \omega_0$ , and  $G(\tau, y, 0) = 0$ . If one uses the coordinate transformation in Chapter VI and lets  $\omega t = \tau$ ,  $\omega^{-1} = \varepsilon$ , then the new system is a special case of system (1) for which Theorem 2.3 applies directly. This will complete the proof of existence of an integral manifold. The stability follows from Section 6.

Another application of the previous results concerns a generalization of the method of averaging. Consider the system

(7.5) 
$$\dot{\psi} = e + \varepsilon \Psi(\psi, \rho),$$
 
$$\dot{\rho} = \varepsilon R(\psi, \rho),$$

where  $\psi$  is in  $R^k$ ,  $\rho$  is in  $R^p$ ,  $e=(1,\ldots,1)$ , and  $\Psi(\psi,\rho)$ ,  $R(\psi,\rho)$  are multiply periodic in  $\psi$  of period  $\omega$  and have continuous first derivatives with respect to  $\rho$ . Let

(7.6) 
$$\Psi_0(\psi, \rho) = \lim_{T \to \infty} \frac{1}{T} \int_0^T \Psi(\psi + et, \rho) dt,$$

$$R_0(\psi, \rho) = \lim_{T \to \infty} \frac{1}{T} \int_0^T R(\psi + et, \rho) dt.$$

From the Appendix, for any  $\eta > 0$ , there are functions  $u(\psi, \rho, \eta)$ ,  $v(\psi, \rho, \eta)$  with as many derivatives in  $\psi$ ,  $\rho$  as desired and a function  $\sigma(\eta) \to 0$  as  $\eta \to 0$  such that

$$igg|rac{\partial u}{\partial \psi} e - \Psi(\psi,
ho) + \Psi_0(\psi,
ho)igg| < \sigma(\eta),$$
  $igg|rac{\partial v}{\partial \psi} e - R(\psi,
ho) + R_0(\psi,
ho)igg| < \sigma(\eta),$ 

and the functions  $\eta u$ ,  $\eta v$ ,  $\eta \partial u/\partial \psi$ ,  $\eta \partial v/\partial \psi$ ,  $\eta \partial u/\partial \rho$ ,  $\eta \partial v/\partial \rho \to 0$  as  $\eta \to 0$  uniformly for  $\psi$  in  $R^k$ ,  $\rho$  in a bounded set. Therefore, as in the proof of Theorem V.3.2, there is an  $\varepsilon_0 > 0$  such that the transformation

(7.7) 
$$\psi = \phi + \varepsilon u(\phi, r, \varepsilon),$$

$$\rho = \phi + \varepsilon v(\phi, r, \varepsilon),$$

is a homeomorphism for Is I < so, :u, 0 in Rk and p, r is a bounded set.

If the transformation (7.7) is applied to (7.5), then a few simple computations yield

(7.8) 
$$\dot{\phi} = e + \varepsilon \Psi_0(\phi, r) + \varepsilon \Psi_1(\phi, r, \varepsilon), \\ \dot{r} = \varepsilon R_0(\phi, r) + \varepsilon R_1(\phi, r, \varepsilon),$$

where'F1, R1 have the same smoothness properties as 'F, B, but now satisfy 'F1(o, r, 0) = 0, R1(o, r, 0) = 0. In other words, by a transformation (7.7) which is essentially the identity transformation near E = 0, the system (7.5) is transformed into an equation which is a higher order,, perturbation of the averaged equations

(7.9) 
$$\begin{aligned} \dot{\theta} &= e + \varepsilon \Psi_0(\theta, \, \rho), \\ \dot{\rho} &= \varepsilon R_0(\theta, \, \rho). \end{aligned}$$

One is now in a position to state results concerning the existence of integral manifolds by asserting the averaged equations have certain properties. For example, suppose there is a po such that Ro(0, po) = 0 and furthermore,

(7.10) 
$$R_0(\theta, \rho_0 + z) = C(\theta)z + H(\theta, z),$$
 
$$C(\theta) = \begin{bmatrix} A(\theta) & 0 \\ 0 & B(\theta) \end{bmatrix}, \quad H(\theta, z) = \begin{bmatrix} F(\theta, z) \\ G(\theta, z) \end{bmatrix}, \quad z = \begin{bmatrix} x \\ y \end{bmatrix},$$
 
$$\Psi_0(\theta, \rho_0 + z) = \Theta(\theta, z),$$

where all matrices are partitioned so that any matrix operations will be compatible. As an immediate consequence of Theorem 2.3 and the form of transformed equations (7.8), one can state

THEOREM 7.3. Suppose A, B in (7.10) satisfy hypothesis (H5) in Section 1 with a = Eal, al > 0, a constant. If the lipschitz constant L of 0(0, 0) satisfies al - L > 0, then there are el > 0, continuous functions D(E), 0(E), 0 < E < El, approaching zero as E - 0 and a function f (0, E) in RP which is continuous in Rk x [0, El],

$$egin{aligned} |f(\psi,\,arepsilon)-
ho_0| &< D(arepsilon), \ |f(\psi,\,arepsilon)-f(ar{\psi},\,arepsilon)| &< \Delta(arepsilon)|\psi-ar{\psi}|, \end{aligned}$$

such that f (0, e) is multiply periodic in 0 of vector period co and the set

$$S_{m{arepsilon}} = \{(\psi, \, 
ho) : 
ho = 
ho_0 + f(\psi, \, arepsilon), \, \psi ext{ in } R^k\}$$

is an integral manifold of (7.5). If the y component of z is present in (7.10), then the manifold is unstable and if it is absent, the manifold is stable.

A simple corollary of Theorem (7.3) which is useful for the applications is

COROLLARY 7.1. Suppose the averaged equations (7.9) are independent of s ; that is, the averaged equations are

(7.11) 
$$\begin{aligned} \dot{\theta} &= e + \varepsilon \Psi_0(\rho), \\ \dot{\rho} &= \varepsilon R_0(\rho). \end{aligned}$$

Also, suppose there is a po such that Ro(po) = 0 and the real parts of the eigenvalues of the matrix C = Mo(po)/8p are nonzero. Then the conclusions of Theorem 7.3 remain valid with the manifold being stable if all eigenvalues of C have negative real parts and unstable if one eigenvalue has a positive real part.

### VII.8. Exercises

Some of the exercises listed below are rather difficult and a complete discussion of some could lead to interesting new results in the theory of oscillations.

EXERCISE 8.1. Use Section VI.3 to show that the hypotheses of Theorem 7.1 imposed on (7.1) are satisfied for the van der Pol equation

(8.1) 
$$\dot{x}_1 = x_2,$$
  $\dot{x}_2 = -x_1 + k(1 - x_1^2)x_2, \qquad k > 0.$ 

Use Theorems 7.1 and 7.2 to discuss the existence and stability of integral manifolds of the system

(8.2) 
$$\dot{x}_1 = x_2,$$
  $\dot{x}_2 = -x_1 + k(1 - x_1^2)x_2 + \varepsilon \sin \omega t,$ 

when either E is small or co is large.

Use the theory of Chapter IV to discuss the existence and stability properties of a periodic solution of (8.2) of period 2a/w for either IEI small or w large.

In Chapter II it was shown that every solution of (8.1) except the zero solution approaches the periodic orbit 'I as t -\* oo. Can you use the previous discussion to give the qualitative behavior of all solutions of (8.2) in some large domain of R2 for IEI small? Hint: Show there is an open set U in R2 such that the tangent vector to the solution curves of (8.1) on the boundary of U point toward the interior of U. This implies that the tangent vector to the solutions of (8.1) in (t, x)-space is pointing toward the interior' of the "cylinder" R x W. Therefore for JEI small or w large, the same will be true of the solutions of (8.2). Now use continuity with respect to the vector field.

EXERCISE 8.2. Suppose both of the vector systems t = f (x), y = F(y) satisfy the condition of Theorem 7.1. What types of integral manifolds does the system

$$\dot{x} = f(x) + \varepsilon g(t, x, y), \ \dot{y} = F(y) + \varepsilon G(t, x, y)$$

possess fore small if g, G are bounded for t in R and x, y in compact sets? What are the stability properties of each of the manifolds? Generalize this result. Hint: Use the coordinate system of Chapter VI for each periodic orbit.

EXERCISE 8.3. For co large, discuss the existence and nature of integral manifolds of the system

$$\dot{x}_1 = x_2$$
,  
 $\dot{x}_2 = -x_1 + k[1 - (x_1 + B\sin \omega t)^2]x_2$ ,

as a function of B.

EXERCISE 8.4. For w large, discuss the question of the existence and the dependence of integral manifolds of the system

$$\ddot{x} + 2 \, \ddot{x} + \dot{x} + Kf(x + B \sin \omega t) = 0$$

on the constants K and B for odd functions f (x) which are monotone nondecreasing and approach a limit as x --> oo. This problem is difficult and one could never solve it in this general context. Take special functions f.

EXERCISE 8.5. Discuss the existence of integral manifolds of the equation

$$egin{aligned} \dot{x}_1 &= x_2\,, \ \dot{x}_2 &= -x_1 + arepsilon (1-x_1^2)x_2 + A \sin \omega t, \end{aligned}$$

fore small and various values of A and co. Let

$$egin{aligned} x_1 &= 
ho \sin \, heta_1 + A (1-\omega^2)^{-1} \sin \, \omega t \ x_2 &= 
ho \, \cos \, heta_1 + A \omega (1-\omega^2)^{-1} \cos \, \omega t \end{aligned}$$

and 02 = t to obtain a system of differential equations for 01, 02, p and then apply Corollary 7.1. What are the stability properties of the manifolds? What happens geometrically as A, co vary?

EXERCISE 8.6. Fore small, discuss the existence and stability properties of integral manifolds of the system

$$\ddot{x} - \varepsilon (1 - x^2 - ay^2)\dot{x} + x = 0,$$
  
$$\ddot{y} - \varepsilon (1 - y^2 - \alpha x^2)\dot{y} + \sigma^2 y = 0,$$

as a function of a, a, a. Let x = p1 cos 01, x = - p1 sin 01, y = p2 cos a02 , y = -ape sin a02 to obtain a system of the same form as system (7.8). Now apply the method of averaging described above and, in particular, Corollary 7.1 for the case when k + la 0 for all integers k, l for which Jkl +I11 < 3. What are the periodic solutions? Can you describe geometrically what happens when the stability properties of the periodic orbits change under variation of the constants a and a ? What happens when k + la = 0 for some integers k and 1 with I kI + Ill < 3 ? In the equation, change 1 - x2 - aye to 1 - x2 - ay2 + bx2y2 and discuss what happens as a function of a, b, a.

EXERCISE 8.7. Carry out the same analysis as in Exercise 8.6 for the equations

$$\ddot{x} - \varepsilon \left(\dot{x} - \frac{\dot{x}^3}{3}\right) + \sigma x + \mu y = 0,$$

$$\ddot{y}-arepsilonigg(\dot{y}-rac{\dot{y}^3}{3}igg)-\mu x+
u y=0,$$

for those values of the parameters a, µ, v for which the characteristic roots of the equation for e = 0 are simple and purely imaginary, say ±iwl, ±ico2. Under this hypothesis, this system can be transformed by a linear transformation to a system which for e = 0 is given by ii + wiu = 0, v + w2 v = 0. Now apply the same type of argument as in Exercise 8.6.

## VII.9. Remarks and Suggestions for Further Study

Detailed references to the method of Krylov-Bogoliubov may be found in the books of Bogoliubov and Mitropolski [1] or Hale [3]. The original results on integral manifolds using this method considered only the case in which the flow on the unperturbed manifold was a parallel flow; that is, w(t, 0, e) in (1) is a constant. 11owever, the method of proof given in the text is basically the same as the original proof for parallel flow except for the technical details. Other results along this line were obtained by Diliberto [3] and Kyner [1]. Kurzweil [1, 2] has given another method for obtaining the existence of integral manifolds and has the problem formulated in such a general framework as to have applications to partial differential equations, difference equations and some types of functional differential equations. Further results may be found in Pliss [1 ].

It is not assumed in system (1) that the functions are periodic in t he vector 0. The results have implications to the theory of center manifolds and stability theory (Puss [21, Kelley [1]) and the theory of bifurcation (Chafee [11, Lykova [1] ).

Hypothesis (H5) in Section 2 is too strong. For example, if w(t, 0, e) = 1, one need only assume the exponential estimates are valid for functions 0(t) = t + Bp (see Montandon [1] ). For a more general case, see Coppel and Palmer [11, Henry [1].

The basic result in the proof of the theorems on integral manifolds was Lemma 3.2. The proof of this lemma shows that the Lipschitz constant L(P) was used only to obtain estimates on the dependence of the solution B\*(t, r, 0, P) of 6 = P(t, 0) upon 6. There are many ways to obtain estimates of this dependence without using the lipschitz constant of P. For example, if P(t, 0) has continuous partial derivatives with respect to 0, then 86\*(t, T, 0,,P)/80 is a solution of the equation

$$\dot{\zeta} = \left[ \frac{\partial P(t, \, \theta^*)}{\partial \theta} \right] \zeta.$$

Consequently, one can use the eigenvalues of the symmetric part of 8P/86 to estimate the rate of growth of C. The hypothesis (H5) can also be verified by using the eigenvalues of the symmetric part of the matrices A(6), B(6). Using the method of partial differential equations mentioned in Section 1, Sacker [1] has exploited these concepts to great advantage to discuss the existence and smoothness properties of integral manifolds for equations (1) winch are inaepenctent oft and periodic in 0. Diliberto [3] has also used these same concepts and the method of the text to find integral manifolds.

The first example in Section 3 after Lemma 3.2 is due to McCarthy [1] and the second to Kyner [1]. The generalized average defined in relation was first introduced by Diliberto [1]. Some of the exercises in Section 8 can be found in Hale [7].

## CHAPTER VIII

## Periodic Systems with a Small Parameter

In Chapter IV, we discussed the existence of periodic solutions of equations containing a small parameter in noncritical cases; that is systems

$$\dot{x} = Ax + \varepsilon f(t, x),$$

where f (t + T, x) =f (t, x) and no solution except x = 0 of the unperturbed equation

$$\dot{x} = Ax,$$

is T-periodic. In Chapter V, the method of averaging was applied to some systems for which (2) has nontrivial T-periodic solutions. The basis of this method is to make a change of variables which transforms the system into one which can be considered as a perturbation of the averaged equations. If the averaged equations are noncritical with respect to the class of T-periodic functions, then the results of Chapter IV can be applied. If the averaged equations are critical with respect to T-periodic functions, then the process can be repeated. In addition to being a very cumbersome procedure, it is very difficult to use averaging and reflect any qualitative information contained in the differential equation itself into the iterative scheme. For example, if system (1) has a first integral, what is implied for the iterations?

For periodic systems, other more efficient procedures are available. The present chapter is devoted to giving a general method for determining periodic solutions of equations including -(1) which may be critical with respect to T-periodic functions. This method gives necessary and sufficient conditions for the existence of a T-periodic solution of (1) fore small. These conditions consist of transcendental equations (the bifurcation or determining equations) for the determination of a T-periodic function which is a solution of (2). The bifurcation equations are given in such a way as to permit a qualitative discussion of their dependence upon properties of the right hand side of ,(j). This is illustrated very well when f in (1) enjoys some even and oddness properties or system (1) possesses a first integral. In general, such systems have families of T-periodic solutions.

In addition to the advantage mentioned in the previous paragraph, the method of this chapter can be generalized to arbitrary nonlinear systems. This topic as well as a more general formulation of the method in Banach spaces will be treated in the next chapter.

For A = 0, the, basic ideas are very elementary and easy to understand geometrically. For this reason, this case is treated in detail in Section 1. Also, in Section 1, it is shown how to reduce the study of periodic solutions of many equations as well as the determination of characteristic exponents of linear periodic systems to this simple form. Section 2 is devoted to a discussion of the general system (1) as well as results on systems possessing either symmetry properties or first integrals. In Section 3, we reprove a result of Chapter VI using the method of this chapter rather than a coordinate system around a periodic orbit.

## VIII.!. A Special System of Equations

Suppose f: R x an ->Cn is a continuous function with 8f (t, x)lax also continuous, f (t + T, x) =f (t, x), a is a parameter and consider the system of equations

$$\dot{x} = \varepsilon f(t, x).$$

Our problem is to determine whether or not system (1.1) has any T-periodic solutions fore small. For E = 0 all solutions of (1.1) are T-periodic; namely, they are constant functions. The basic question is the following: if there are T-periodic solutions of (1.1) which are continuous in e, which solutions of the degenerate equation do they approach as a -\* 0? One precedure was indicated for attacking this question in Chapter V. Another method is due to Poincare in which a periodic power series expansion is assumed for the solution as well as the initial data. The initial data is then used to eliminate the secular terms that naturally arise in the determination of the coefficients in the power series of the solutions.

In this section, we indicate another method for solving this problem which seems to have some qualitative advantages over the method of Poincare. Let YT = {g: R -\*Cn, g continuous, g(t + T) = g(t)}, 1 1 9 For any g in 9T, define Pg to be the mean value of g; that is,

(1.2) 
$$Pg = \frac{1}{T} \int_{0}^{T} g(t) dt, \qquad ||Pg|| \leq ||g||.$$

If g is T-periodic, then the system

$$\dot{x} = g(t)$$

has a T-periodic solution if and only if Pg = 0. Furthermore, if Pg = 0, let .(g be the unique T-periodic solution of (1.3) which has mean value zero; that is,

(1.4) 
$$\mathscr{K}g = (I - P) \int_0^{\cdot} g(s) \, ds, \qquad \|\mathscr{K}g\| \le K \|g\|, \qquad K = 2T.$$

Every T-periodic solution of (1.3) can then be written as

$$x = a + \mathscr{K}g$$

where a is a constant n-vector and a = Px.

These simple remarks imply the following:

LEMMA 1.1. Suppose P and .7£r are defined in (1.2), (1.4). Then

- (i) x(t) is a T-periodic solution of (1.1) only if Pf ( , x(-)) = 0; that is, only
- (ii) System (1.1) has a T-periodic solution x if and only if x satisfies the system of equations

(1.5) (a) 
$$x = a + \varepsilon \mathcal{K}(I - P)f(\cdot, x);$$
  
(b)  $\varepsilon Pf(\cdot, x) = 0,$ 

where a is a constant n-vector given by a = Px.

PROOF. If x is a T-periodic solution of (1.1), let g(t) =f (t, x(t)) and assertion (i) follows immediately. The fact that x satisfies (1.5) is just as obvious. If x is a solution of (1.5), then f ( , x) = (I - P) f ( , x) and, therefore, x is a T-periodic solution of (1.1). This proves the lemma.

LEMMA 1.2. For any a > 0, there is an eo > 0 such that for any a in Cn with jai < a, Jel <\_ co, there is a unique function x\* = x\*(a, E) which satisfies (1.5a). Furthermore, x\*(a, E) has a continuous first derivative with respect to a, E and x\*(a, 0) = a. If there is an a = a(E) with la(E)l <\_ a for 0<\_ let <\_ co and

(1.6) 
$$G(a, \varepsilon) \stackrel{\text{def}}{=} Pf(\cdot, x^*(a, \varepsilon)) = 0,$$

then x\*(a, e) is a T-periodic solution of (1.1). Conversely, if (1.1) has a T-periodic solution x(e) which is continuous in s and has Pg(E) = a(E), la(E)l 5 a, 0:5 kEJ < eo, then x(e) = x\*(a(e), E) where x\*(a, E) is the function given above and a(e) satisfies (1.6) for 0 <tEJ < Eo.

PROOF. Suppose a > 0 is given, P is any number >0 and a is an n-vector with jai < a. Define .5"(f) = {y in 9T: IIy II < f, Py = 0) and the operator F: So(p) -> 9T by

(1.7) 
$$\mathscr{F}y = \varepsilon \mathscr{K}(I - P)f(\cdot, y + a)$$

for y in  $\mathcal{S}(\beta)$ . If y is a fixed point of  $\mathscr{F}$ , then y+a satisfies (1.5a). Let M, N be bounds on |f(t,x)|,  $|\partial f(t,x)/\partial x|$ , respectively, for t in R,  $|x| \leq \beta + \alpha$  and choose  $\varepsilon_1$  so that  $4\varepsilon_1 TM < \beta$ ,  $4\varepsilon_1 TN < 1/2$ . One easily shows that  $\mathscr{F} \colon \mathcal{S}(\beta) \to \mathcal{S}(\beta)$  and is a uniform contraction with respect to a,  $\varepsilon$  for  $|a| \leq \alpha$ ,  $|\varepsilon| \leq \varepsilon_1$ . Let  $y^*(a, \varepsilon)$  be the unique fixed point of  $\mathscr{F}$  in  $\mathscr{S}(\beta)$ . The existence and properties of  $x^*(a, \varepsilon) = y^*(a, \varepsilon) + a$  stated in the lemma are now a consequence of the uniform contraction principle. If  $a(\varepsilon)$  satisfies (1.6), then  $x^*(a(\varepsilon), \varepsilon)$  is a solution of (1.1) from Lemma 1.1. Conversely, if  $\bar{x}(\varepsilon)$  satisfies the properties in the statement of the lemma, then there is a  $\beta > \alpha$  such that  $|\bar{x}(\varepsilon) - a(\varepsilon)| \leq \beta$  for  $0 \leq |\varepsilon| \leq \varepsilon_1$ . For this  $\beta$  choose  $\varepsilon_0 \leq \varepsilon_1$  so that  $\mathscr{F}$  is a contraction on  $\mathscr{S}(\beta)$  for  $0 \leq |\varepsilon| \leq \varepsilon_0$ . Then  $\bar{x}(\varepsilon) - a(\varepsilon) = y^*(a(\varepsilon), \varepsilon)$  and  $\bar{x}(\varepsilon) = x^*(a(\varepsilon), \varepsilon)$ . The conclusion of the lemma follows from Lemma 1.1.

Lemma 1.2 asserts the following: one can specify an arbitrary n-vector a and then determine uniquely a T-periodic function  $x^*(a, \varepsilon)$  with mean value a in such a way that all of the Fourier coefficients of the function  $\dot{x}^*(t) - f(t, x^*(t))$  are zero except for the constant term (this is the same as saying (1.5a) is satisfied). The n-vector a is then used to try to make the constant term equal to zero (that is, satisfy (1.6)). Equations (1.6) are sometimes referred to as the determining equations or bifurcation equations of (1.1).

As a consequence of the above proof, the function  $x^*(a, \varepsilon)$  can be obtained as the limit of the sequence  $\{x^{(k)}\}$ ,  $x^{(k)} = y^{(k)} + a$  where the  $y^{(k)}$  are defined successively by  $y^{(k+1)} = \mathscr{F}y^{(k)}$ ,  $k = 0, 1, 2, \ldots, y^{(0)} = 0$ , and  $\mathscr{F}$  is defined in (1.7). Using only the first approximation, one arrives at

THEOREM 1.1. Suppose  $x^*(a, \varepsilon)$  is defined as in Lemma 1.2 and let  $G(a, \varepsilon)$  be defined by (1.6). If there is an n-vector  $a_0$  such that

(1.8) 
$$G(a_0, 0) = 0, \qquad \det \left[ \frac{\partial G(a_0, 0)}{\partial a} \right] \neq 0,$$

then there are an  $\varepsilon_1 > 0$  and a *T*-periodic solution  $x^*(\varepsilon)$ ,  $|\varepsilon| \le \varepsilon_1$ , of (1.1),  $x^*(0) = a_0$ , and  $x^*(\varepsilon)$  is continuously differentiable in  $\varepsilon$ .

PROOF. The hypothesis (1.8) and the implicit function theorem imply there is an  $\varepsilon_1$ ,  $0 < \varepsilon_1 \le \varepsilon_0$ , such that equation (1.6) has a continuously differentiable solution  $a(\varepsilon)$ ,  $|a(\varepsilon)| < \alpha$ ,  $0 \le |\varepsilon| \le \varepsilon_1$ . Lemma 1.2 implies the remaining assertions of the theorem.

Notice that

(1.9) 
$$G(a, 0) = \frac{1}{T} \int_{0}^{T} f(t, a) dt,$$

and therefore can be calculated without knowing anything about the solutions of (1.1). Compare Theorem 1.1 with Theorem V.3.2. Can you prove Theorem V.3.2 by the above method?

In the applications, Theorem 1.1 is not sufficiently general even for equation (1.1). More specifically, it is sometimes necessary to take the terms in the Taylor expansion of G(a, e) in (1.6) of the first, second, or even higher order in a. Except for the numerical computations involved, there is conceptually no difficulty in obtaining these terms. To obtain the first order terms of G(a, e) in e, one must compute the first order terms in a in x\*(a, a), etc. This is accomplished by the iteration procedure x(k) = y(k) + a, yak+I> = ,Fy(k), k = 0, 1, 2, ..., y(O) = a, where the mapping F is defined in (1.7).

It is easy to generalize the above results to a system of the form

$$(1.10) \dot{z} = Bz + \varepsilon h(t, z),$$

where h(t + T, z) = h(t, z), h and 8h/8z are continuous in R X Cm+n, B = diag(0n , BI), On is the n x n zero matrix, BI is an m X m constant matrix such that eBiT -I is nonsingular. This latter condition states that the system y = Bly is noncritical with respect to 9T . If z = (x, y), h = (f, g) where x, f are n-vectors, then the above system is equivalent to

$$egin{aligned} \dot{x} &= arepsilon f(t,\,x,\,y), \ \dot{y} &= B_1 y + arepsilon g(t,\,\dot{x},\,y). \end{aligned}$$

For any h = (f, g) in 9T define Ph to be the (n + m)-dimensional constant vector given by

(1.11) 
$$Ph = \begin{bmatrix} \frac{1}{T} \int_0^T f(t) dt \\ 0 \end{bmatrix}.$$

The nonhomogeneous linear system

$$(1.12) \dot{z} = Bz + h(\dot{t})$$

has a T-periodic solution if and only if Ph = 0. Furthermore, if Ph = 0, let .%('h be the unique solution z of (1.12) with Pz = 0. For any h in 9T , one can therefore define , ' (I - P)h and there is a constant K > 0 such that

$$(1.13)$$

that is .Y (I - P) is a continuous linear mapping of YT into YT. Every T-periodic solution of (1.12) can be written as

$$z=a^*+arepsilon\mathscr{K}h,\,a^*=egin{bmatrix} a \ 0 \end{bmatrix},$$

where a is a constant n-vector with a\* = Pz.

LEMMA 1.3. Suppose P is defined by (1.11), H is in T and .7Y (I -P)H is the unique T-periodic solution z of

$$\dot{z} = Bz + (I - P)H$$

with Pz = 0. Then z(t) is a T-periodic solution of (1.10) only if  $Ph(\cdot, z(\cdot)) = 0$ ; that is, only if  $h(\cdot, z(\cdot)) = (I - P)h(\cdot, z(\cdot))$ . Also, system (1.10) has a T-periodic solution z if and only if the system of equations

$$(1.14) \hspace{1cm} (\mathbf{a}) \quad z = a^* + \varepsilon \mathcal{K}(I-P)h(\cdot,z(\cdot)), \qquad a^* = (a,0),$$

(b) 
$$\varepsilon Ph(\cdot, z(\cdot)) = 0$$
,

is satisfied, where a is a constant n-vector given by  $a^* = Pz$ .

LEMMA 1.4. For any  $\alpha > 0$ , there is an  $\epsilon_0 > 0$  such that for any a in  $\mathbb{R}^n$  with  $|a| \leq \alpha$ ,  $|\epsilon| \leq \epsilon_0$ , there is a unique function  $z^* = z^*(a, \epsilon)$  which satisfies (1.14a). Furthermore,  $z^*(a, \epsilon)$  has a continuous first derivative with respect to  $a, \epsilon$  and  $z^*(a, 0) = a^*$ . If there is an  $a(\epsilon)$  with  $|a(\epsilon)| \leq \alpha$  for  $0 \leq |\epsilon| \leq \epsilon_0$  and

(1.15) 
$$G(a, \varepsilon) = \frac{1}{T} \int_0^T f(t, z^*(a, \varepsilon)(t)) dt = 0,$$

then  $z^*(a, \varepsilon)$  is a T-periodic solution of (1.10). Conversely, if (1.10) has a T-periodic solution  $\bar{z}(\varepsilon)$  which is continuous in  $\varepsilon$  and has  $P\bar{z}(\varepsilon) = a^*(\varepsilon)$ ,  $a^* = (a, 0), |a(\varepsilon)| \le \alpha$ ,  $0 \le |\varepsilon| \le \varepsilon_0$ , then  $\bar{z}(\varepsilon) = z^*(a(\varepsilon), \varepsilon)$  where  $z^*(a, \varepsilon)$  is the function given above and  $a(\varepsilon)$  satisfies (1.15) for  $0 < |\varepsilon| \le \varepsilon_0$ .

THEOREM 1.2. Suppose  $z^*(a, \varepsilon)$  is defined as in Lemma 1.4 and  $G(a, \varepsilon)$  is defined as in (1.15). If there is an *n*-vector  $a_0$  such that

$$G(a_0, 0) = 0, \qquad \det \left[ \frac{\partial G(a_0, 0)}{\partial a} \right] \neq 0,$$

then there is an  $\varepsilon_1 > 0$  and a *T*-periodic solution  $z^*(\varepsilon)$ ,  $|\varepsilon| \le \varepsilon_1$ , of (1.10),  $z^*(0) = a_0^*$ ,  $a_0^* = (a_0, 0)$  and  $z^*(\varepsilon)$  is continuously differentiable in  $\varepsilon$ .

EXERCISE 1.1 Verify all statements made above concerning system (1.10) and prove in detail Lemmas 1.3, 1.4, and Theorem 1.2.

Exercise 1.2. Consider the equations

$$\dot{x}_1 = x_2$$
,  
 $\dot{x}_2 = -x_1 + \varepsilon(1 - x_1^2)x_2 + \varepsilon p \cos(\omega t + \alpha)$ ,

where  $p \neq 0$ ,  $\varepsilon > 0$ ,  $\omega$ ,  $\alpha$  are real numbers with  $\omega^2 = 1 + \varepsilon \beta$ ,  $\beta \neq 0$ . Find conditions on p,  $\omega$ ,  $\alpha$  which will ensure that this equation has a periodic solution of period  $2\pi/\omega$  for  $\varepsilon$  small. Draw the frequency response curve. Let

$$x_1 = z_1 \sin \omega t + z_2 \cos \omega t,$$
  
$$x_2 = \omega(z_1 \cos \omega t - z_2 \sin \omega t).$$

and apply Theorem 1.1.

EXERCISE 1.3. Discuss the possibility of the existence of a subharmonic solution of order 2 (that is, a solution whose period is twice the period of the vector field) for the equation

(1.16) 
$$\dot{x}_1 = x_2$$
,  
 $\dot{x}_2 = -\sigma^2 x_1 + \varepsilon (3\nu \cos 2t - x_1^2) - \varepsilon^2 (\lambda x_2 + \mu x_1) - \varepsilon^3 \mu x_1^2$ ,

where a = 1. Let

$$x_1 = z_1 \sin t + z_2 \cos t,$$
  
 $x_2 = z_1 \cos t - z_2 \sin t,$ 

and apply Theorem 1.1.

EXERCISE 1.4. For a=2/3, A = eAi in (1.16) discuss the existence of a subharmonic solution of order 3 of (1.16). Let

$$x_1 = z_1 \sin \sigma t + z_2 \cos \sigma t,$$
  
 $x_2 = \sigma(z_1 \cos \sigma t - z_2 \sin \sigma t),$ 

and determine the Taylor expansion of G(a, e) in (1.6) up through terms of order a and apply an appropriate implicit function theorem.

EXERCISE 1.5. For a= 2/n, n a positive integer, show that (1.16) possessing a subharmonic of order n implies that A must be O(en-2) as a -. 0. You cannot possibly find n terms in the Taylor expansion of G(a, e) so you must discuss the qualitative properties of the expansion.

EXERCISE 1.6. Using the method of Exercise 1.5, show that the Duffing equation

$$egin{aligned} \dot{x}_1 &= x_2\,, \ \dot{x}_2 &= -(2n+1)^{-2}x_1 - arepsilon^s c x_2 + arepsilon a x_1 + arepsilon b x_1^3 + B\cos t, \end{aligned}$$

can have a subharmonic solution of order 2n + 1 only ifs > n.

EXERCISE 1.7. Suppose f (x, y) is a continuously differentiable scalar function of the scalars x, y, f (0, 0) = 0 and either f (x, -y) =f (x, y) or f (-x, y) = -f (x, y) for all x, y. Given any a > 0, show there is an eo > 0 such that for any (xo , yo) with xo + yo G a2, there is a periodic solution of the system

$$\dot{x}=y, \ \dot{y}=-x+arepsilon f(x,y),$$

for I e 1 <\_ so. This implies the equilibrium point (0, 0) is a center. Let

 $x = \rho \sin \theta$ ,  $y = \rho \cos \theta$  to obtain the equation

$$rac{d
ho}{d heta} = arepsilon F(
ho,\, heta,\,arepsilon)$$

for the orbits of (1.17). If f(-x, y) = -f(x, y), observe that  $F(\rho, -\theta, \varepsilon) = -F(\rho, \theta, \varepsilon)$ . Show that the transformation  $\mathscr{F}$  in (1.7) in this special case maps even  $2\pi$ -periodic functions of  $\theta$  into even functions of  $\theta$  and, therefore, the fixed point must be even. This implies  $G(a, \varepsilon) \equiv 0$ . If f(x, -y) = f(x, y), then let  $\theta = \phi + \pi/2$  and apply the same argument.

EXERCISE 1.8. Consider the system

$$\dot{x}_1 = x_2 \, , \ \dot{x}_2 = -\mu x_1^3 \, ,$$

where  $\mu>0$  is a small parameter. A first integral of this equation is  $E(x_1,x_2)=x_2^2/2+\mu x_1^4/4$  and, thus, all of the orbits are periodic orbits. For  $\mu=0$ , the only periodic orbits are the equilibrium points which lie on the  $x_1$ -axis. Can you deduce this result by using the above perturbation theory? If  $\varepsilon=\sqrt{\mu}$ ,  $x_1=z_1$ , and  $x_2=\varepsilon z_2$ , then  $\dot{z}_1=\varepsilon z_2$ ,  $\dot{z}_2=-\varepsilon z_1^3$  which is a special case of system (1.1).

The above theory is also useful for determining the characteristic exponents of certain types of linear systems with periodic coefficients. More specifically, consider the system of equations

$$\dot{w} = Cw + \varepsilon \Phi(t)w$$

where  $\varepsilon$  is a parameter,  $0 \le |\varepsilon| \le \varepsilon_0$ , w is an (n+m)-vector,  $\Phi(t) = \Phi(t+T)$ ,  $T = 2\pi/\omega$ , is a continuous  $(n+m) \times (n+m)$  matrix and  $C = \operatorname{diag}(C_1, C_2)$  is an  $(n+m) \times (n+m)$  constant matrix such that all eigenvalues of the  $n \times n$  matrix  $e^{C_1T}$  are  $\rho_0$  and no eigenvalue of  $e^{C_2T}$  is  $\rho_0$ . The problem is to determine the characteristic multipliers of (1.18) which are close to  $\rho_0$  for  $\varepsilon \ne 0$ .

Suppose  $\lambda_1$  is an eigenvalue of  $C_1$  and then  $\rho_0 = e^{\lambda_1 T}$ . From the continuity of the principal matrix solution of (1.18) in  $\varepsilon$  and the Floquet theory, it follows that there is a multiplier  $\rho(\varepsilon) = e^{\mu(\varepsilon)T}$  which is continuous in  $\varepsilon$  and  $\mu(0) = \lambda_1$ . Furthermore, to this multiplier there must exist a T-periodic (n+m)-vector  $p(t,\varepsilon)$  such that  $e^{\mu(\varepsilon)t}p(t,\varepsilon)$  is a solution of (1.18). Conversely, any such solution of (1.18) yields a characteristic exponent of (1.18). Therefore, if one makes the transformation  $w = e^{\mu t}p$  in (1.18), then

(1.19) 
$$\dot{p} = (C - \mu I)p + \varepsilon \Phi(t)p,$$

<sup>&</sup>lt;sup>1</sup> Φ could be an integrable function.

and the problem is to determine p in such a way that (1.19) has a T-periodic solution.

In order to make the previous theory directly applicable, suppose that the eigenvalues of C1 have simple elementary divisors. Then the matrix e(c=-AlI)t is T-periodic. If w = (u, v), where u is an n-vector, v is an m-vector, and P is any complex number, the transformation

(1.20) 
$$u = e^{(\lambda_1 + \varepsilon \beta)t} e^{(C_1 - \lambda_1 I)t} x,$$
$$v = e^{(\lambda_1 + \varepsilon \beta)t} y.$$

in (1.18) yields

$$\begin{aligned} (1.21) \quad \dot{x} &= -\varepsilon \beta x + \varepsilon e^{-(C_1 - \lambda_1 I)t} \Phi_{11}(t) e^{(C_1 - \lambda_1 I)t} x + \varepsilon e^{-(C_1 - \lambda_1 I)t} \Phi_{12} y, \\ \dot{y} &= [C_2 - (\lambda_1 + \varepsilon \beta) I] y + \varepsilon \Phi_{21}(t) e^{(C_1 - \lambda_1 I)t} x + \varepsilon \Phi_{22}(t) y, \end{aligned}$$

where we have partitioned 4) as (D = ((Dtp).

Since e(Cl-A,I)t is T-periodic, system (1.21) can be written as

$$(1.22) \dot{z} = Bz + \varepsilon \Psi(t, \beta)z,$$

where B = diag(0,, C2 - A1I), z = (x, y) and ¶(t + T, P) ='1'(t, fi) for all t, P. The explicit expression for 'F is easily obtained from (1.21). If P can be determined in such a way that system (1.22) has a T-periodic solutionp(t), then this solution yields from (1.20) a solution of (1.18) of the form

$$w(t) = e^{(\lambda_1 + \varepsilon \beta)t} p(t), \qquad p(t+T) = p(t).$$

Therefore, Al + ep is a characteristic exponent of (1.18). Conversely, we have seen above that every such characteristic exponent can be obtained in this way.

Since system (1.22) is a special. case of system (1.10), we may apply the preceding theory. The function z\* given in Lemma 1.4 will now be a function of a, P and a and the linearity of (1.22) implies that z\*(a, S, e) = Z\*(19, e)a, where Z\*(p, s) is a T-periodic (n + m) x n matrix. If Z\* = col (X\*, Y\*) where X\* is n x n then the function G(a, P, e) in (1.15) is also linear in a; that is, G(a, P, E) = D(S, e)a, where D(fl, e) can be computed directly from (1.22) as

$$(1.23) \quad D(\beta, \, \varepsilon) = \frac{1}{T} \int_0^T \left[ \Psi_{11}(t, \, \beta) X^*(\beta, \, \varepsilon)(t) + \Psi_{12}(t, \, \beta) Y^*(\beta, \, \varepsilon)(t) \right] dt,$$

where 'F is partitioned as 'F = ('Ftg). Lemma 1.4 then implies that any fl for which det D(P, e) = 0 will yield a characteristic exponent Al + efi of (1.18).

EXERCISE 1.9. Suppose D(P, e) is given in (1.23). Prove that the n characteristic multipliers of (1.18) which for e = 0 are equal to po are the n roots of the equation det D(fl, e) = 0.

EXERCISE 1.10. Consider the system

$$\dot{w} = Cw + \varepsilon \Phi(t)w,$$

where I (t + T) = (D (t) is continuous, C = diag(ar, ..., An) and for some fixed j,

$$e^{\lambda_j T} \neq e^{\lambda_k T}, \qquad k = 1, 2, \ldots, n, \qquad k \neq j.$$

Show that the characteristic multiplier p(e) of (1.24) such that p(O) = eA,T is given by

$$\rho(\varepsilon) = e^{\mu(\varepsilon)T}, \qquad \mu(\varepsilon) = \lambda_j + \frac{\varepsilon}{T} \int_0^T \phi_{jj}(t) \ dt + o(\varepsilon) \qquad \text{as } \varepsilon \to 0,$$

where I = (Ok), i, k =1, 2, ... , n.

EXERCISE 1.11. Suppose that the system

$$\ddot{x} + x = \varepsilon f(x, \dot{x}, y, \dot{y}), \ \ddot{y} + \sigma^2 y = \varepsilon g(x, \dot{x}, y, \dot{y}),$$

has a periodic solution of period 21r/w(8), w(0) = 1, which for s = 0 is given by x = a sin t, y = 0. Prove that this solution is asymptotically orbitally stable with asymptotic phase if

$$\varepsilon \int_0^{2\pi} \frac{\partial f}{\partial \dot{x}} (a \sin t, a \cos t, 0, 0) dt < 0,$$

$$\varepsilon \int_0^{2\pi} \frac{\partial g}{\partial \dot{y}} (a \sin t, a \cos t, 0, 0) dt < 0,$$

and a 0 an integer. The characteristic multipliers. of the linear variational equation relative to this periodic solution are given by 1, 1, e2nha e-2nia for s = 0. The hypothesis on a implies that the roots e2nia and e-2nia are simple. Therefore, Exercise 1.10 can be applied to obtain the first order change in these multipliers with s provided the constant part of the variational equation is transformed to a diagonal form. Since one multiplier remains identically one for ,E V- 0 and the product of the multipliers is given by a well known formula, one can evaluate the first order change in the other multiplier.

EXERCISE 1.12. Generalize the result of Exercise 1.11 to a system of n-second order equations.

EXERCISE 1.13. Show that the system

$$\ddot{x}+x=arepsilon(1-x^2-y^2)\dot{x}, \ \ddot{y}+2y=arepsilon(1-x^2-y^2)\dot{y}, \qquad arepsilon>0,$$

has two nonconstant periodic solutions both of which are asymptotically orbitally stable with asymptotic phase.

EXERCISE 1.14. Consider the Mathieu equation

$$\dot{x_1}=x_2\,, \ \dot{x_2}=-\sigma^2x_1-arepsilon(\cos\,2t)x_1,$$

where a = a(e) and a(O) = m, a nonnegative integer. From the general theory of this equation in Chapter III, we know that these values of a are precisely the ones which may give rise to instability. In fact, the instability zones are determined from those values of or for which equation (1.25) has a periodic solution of period 7r or 27r; that is, the multipliers are +1 or -1. Determine approximately these values of a(e) as a function of a for the case when a(O) = 1, a(0) = 2. Are the solutions unbounded in a neighborhood of the points (1, 0), (2, 0) in the (a, e)-plane? Let

$$x_1 = z_1 \sin mt + z_2 \cos mt$$
,  
 $x_2 = m[z_1 \cos mt - z_2 \sin mt]$ ,

and m2 - a2 = EP and apply the above theory for determining P in such a way that the resulting equations have a periodic solution.

EXERCISE 1.15. For a(0) = m in Exercise 1.14, show that a2(e) = m2 +0(em) as 6 -+0.

EXERCISE 1.16. Discuss as in Exercise 1.14 the equation (1.25) with a(0) = 0. Suppose e >\_ 0, let a2 = Efl, X1 = Z1, x2 = . JEZ2 and analyze the resulting equations for periodic solutions.

EXERCISE 1.17. For what values of w are all of the solutions of the equation

$$\ddot{x} + \sigma^2 x = \varepsilon(\sin \omega t) y,$$
  
$$\ddot{y} + \mu^2 y = \varepsilon(\cos \omega t) x,$$

bounded for s small and 0 0?

Let us use the same ideas as above to discuss the existence of periodic solutions for equations which may contain several independent parameters rather than just a single parameter e as in (1.1), (1.10). Consider the equation

$$\dot{x} = f(t, x, \lambda)$$

where A in R k is a parameter, x is in R', f (t, x, A) is continuous in t, xs A together with at least first derivatives in x, A, f (t + T, x, A) = f (t, x, A),

(1.27) 
$$f(t,0,0) = 0, \quad \partial f(t,0,0)/\partial x = 0$$

Equation (1.26) is a generalization of (1.1) since, for example, for A = (A1,A2), it could be of the form

$$\dot{x} = \lambda_1 f^{(1)}(t, x) + \lambda_2 f^{(2)}(t, x)$$

which makes (1.1) correspond to f (2)(t, x) = 0. Equation (1.26) could also be of the form

$$\dot{x} = f^{(0)}(x) + \sum_{j=1}^{k} \lambda_j f^{(j)}(t, x)$$

where f(0)(0) = 0, af(0)(0)/ax = 0. If f (0)(x) 0, this latter equation corresponds to an f (t, x, A) which can be made small together with its first derivative by choosing A small and x small. In problems of this type, we will be interested in T-periodic solutions with small norm.

Lemmas 1.1, 1.2 have an analogue for system (1.26), (1.27) which we state without proof since the proof will be the same.

LEMMA 1.3. Suppose P,.9Yare defined in (1.2), (1.4). Then x(t) is a T-periodic solution of (1.26) if and only if

(1.28) (a) 
$$x = a + \mathcal{K}(I - P) f(\cdot, x(\cdot), \lambda)$$
  
(b)  $Pf(\cdot, x(\cdot), \lambda) = 0$ 

where a is a constant n-vector given by a = Px.

LEMMA 1.4. If (1.27) is satisfied, then there are A0 > 0, ao > 0 such that, for any a in Rn, Ial < ao, any A in Rk, IAI < Ap, there is a unique T-periodic function x\* = x\*(a,A) continuous together with its first derivatives, satisfying (1.28a), x\*(0,0) = 0. If there exist (a,A) such that lal < ao, Al I< A0 and

(1.29) 
$$G(a,\lambda) \stackrel{\text{def}}{=} \frac{6}{T} \int_0^T f(t, x^*(a,\lambda)(t), \lambda) dt = 0$$

then x\*(a,A) is a T-periodic solution of (1.26). Conversely, if (1.26) has a T-periodic solution x(A) which is continuous in A and has Px(A) = a(A), la(A)l < ao, Al I< Xo,. then x(A) = x\*(a(A),A) where x\*(a,A) is the function given above and a(A) satisfies (1.29) for 0 < I A I < A0.

One can also give an analogous extension of Lemmas 1.1, 1.2 to a system of the form

(1.30) 
$$\dot{x} = f(t, x, y, \lambda)$$

$$\dot{y} = B_1 y + g(t, x, y, \lambda)$$

where eB 1 T - I is nonsingular if one supposes f,g and - their derivatives with respect to x, y vanish at x = 0, y = 0, A = 0. We do.state the results explicitly.

Having the method formulated so as to apply to (1.26) and (1.30) gives the opportunity to discuss more general problems as well as to discuss old problems more completely. We illustrate this with some examples.

The simplest example is the so-called Hopf bifurcation. Suppose A is a scalar, A(A) is a x X 2 matrix continuously differentiable in A with the eigenvalues of A(O) being ±i. Then there is a neighborhood of A = 0 for which the matrix A(A) has two complex conjugate eigenvalues µ(A) ± iv(A), continuous and continuously differentiable in A such that µ(0) = 0, v(0) = i. Let us suppose dµ(0)/dA 0 0. This hypothesis implies that we may redefine the eter A in a neighborhood of zero by replacing A by µ(A), j3(A) = f v(p-1(X))] 2 and assume A(A) has the form

(1.31) 
$$A(\lambda) = \begin{pmatrix} \lambda & \beta(\lambda) \\ -\beta(\lambda) & \lambda \end{pmatrix}, \qquad \beta(0) = 1$$

Consider the second order equation

$$\dot{x} = A(\lambda)x + f(x,\lambda)$$

where

(1.33) 
$$f(0,\lambda) = 0, \qquad \partial f(0,\lambda)/\partial x = 0$$

andA(A) is given in (1.31).

The Hopf Bifurcation Theorem is stated explicitly in the following way.

THEOREM 1.3. Consider system (1.31), (1.32), (1.33) and suppose f has continuous second derivatives in x. Then there are Ao > 0, ao > 0, So > 0, scalar functions A\*(a), w\*(a) and an w\*(a)-periodic function x\*(a) with all functions being continuously differentiable in a for I a I < ao such that x\*(a) is a solution of the equation

$$\dot{x} = A(\lambda^*(a))x + f(x, \lambda^*(a))$$

and

$$\lambda^*(0) = 0, \qquad \omega^*(0) = 2\lambda,$$

$$x^*(a) = \binom{a\cos t}{-a\sin t} + o(|a|).$$

Furthermore, for IAI < A0, Iw - 21rI < So, every w-periodic solution of (1.32) with norm <S0 must be of the above type except for a translation in phase.

PROOF. Since we are in the plane, every periodic orbit of (1.32) must encircle an equilibrium point. The hypothesis on A(A) implies detA(A) 0 0 for A close to zero. Thus, the solution x = 0 of (1.32) is isolated for I A I sufficiently small

and any solution of (1.32) with sufficiently small norm must encircle x = 0. This justifies the introduction of polar coordinates

$$(1.34) x_1 = \rho \cos \theta, x_2 = -\rho \sin \theta$$

to obtain the equivalent system

(1.35) 
$$\dot{\theta} = \beta(\lambda) - \frac{1}{\rho} \left[ f_1 \sin \theta + f_2 \cos \theta \right]$$

$$\dot{\rho} = \lambda \rho + f_1 \cos \theta - f_2 \sin \theta$$

For I X I , I p I small, B >0 and so we can eliminate t to obtain

(1.36) 
$$\frac{d\rho}{d\theta} = \alpha(\lambda)\rho + R(\theta, \rho, \lambda)$$

where R(0 + 27r,p,X) = R(0,p,X), R(0,0,X) = 0, aR(8,0,X)/ap = 0, a(0) = 0, a'(0) = 1.

Finding periodic solutions of period 27r of (1.36) is equivalent to finding periodic orbits of the original equation (1.32). If p(O) is a 27r-periodic solution of (1.36), one obtains the period of the periodic orbit x1 = p(0)cos 0, x2 = -p(O)sin 0 by finding that value of co for which 0(w) = 21r where 0(t), 0(0) = 0, satisfies the first equation in (1.35) with p = p(O).

Lemma 1.4 is applicable directly to (1.36). Let p\*(0,a,X) be the unique solution for a. X small of the equation

$$\rho = a + \mathcal{Y}(I - P)[\alpha(\lambda)\rho + R(\cdot, \rho, \lambda)]$$

Then p\*.(0,0, X) = 0 since x = O is a solution of (1.32). The bifurcation function GH(a,X) in (1.29) is

$$G_H(a,\lambda) = \frac{1}{2\pi} \int_0^{2\pi} \left[ \alpha(\lambda) \rho^*(\theta,a,\lambda) + R(\theta,\rho^*(\theta,a,\lambda),\lambda) \right] d\theta.$$

Since p\*(0,0,X) = 0, we have GH(0,X) = 0. If we define the function GH(a,X) = GH(a,X)la, then GH(0,0) = 0, aGH(0,0)/aX = 1. The Implicit Function Theorem implies there is a unique X\*(a), Ial <ao such that X\*(O) = 0 and GH(X \*(a), a) = 0. The fact that this function X\*(a) leads to functions w\*(a), x\*(a) as stated in the theorem is left for the reader to verify.

EXERCISE 1.18. Verify that GH(a,X) in (1.37) is an odd function of a.

From Exercise 1.18, GH(a,X) = agH(a2, X). Suppose A(A), f (x, X) in (1.32) have derivatives continuous up through order four and

(1.38) 
$$g_H(r,\lambda) = \alpha(\lambda) - \gamma(\lambda)r + o(|r|) \quad \text{as } |r| \to 0$$

where y(0) = yo # 0; that is, GH(a,X) = a(X)a - y(X)a3 + o(I al3) as lal - 0. Then, gH(r,X) satisfies gH(0,0) = 0, agH(0,0)/ar = -yo : 0. The Implicit

Function Theorem implies there is a unique r\*(X), I A I < A0 , continuously difffrentiable in A, r\*(0) 0, r\*(A) \* 0 for 0 < I A I < Ao and gH(r\*(A), A) = 0. If r\*(X) > 0 for 0 < I AI < Ao, then we can define a\*(X) by the relation a2 = r\*(X) to obtain GH(a\*(X),X) = 0 for I A I < Ao. Furthermore, ± r\*(A) and a = 0 are the only solutions of G(a, A) = 0 for I A I < Ao, I a I < ao. The condition r\*(A) > 0 for 0 < I A I < Ao is equivalent to (sgn70)A > 0, 0 < I A I < Ao. Furthermore, +V/r (A) and -./r\*(A) correspond to the same periodic orbit of (1.32). Consequently, there is a unique nonconstant periodic solution of (1.32) in a neighborhood of x = 0 if the following conditions are satisfied

(1.39) 
$$\gamma_0 > 0, \qquad 0 < \lambda < \lambda_0$$

$$\gamma_0 < 0, \qquad -\lambda_0 < \lambda < 0$$

Let us now investigate the stability of this periodic orbit. It is sufficient to investigate the stability of the corresponding 27r-periodic solution p\*(a\*(A),A) of Equation (1.36). We will use averaging to determine the stability properties.

Make a 21r-periodic transformation of variables in (1.36) of the form

(1.40) 
$$\rho = s + u_1(\theta)s^2 + u^2(\theta)s^3$$

and choose u10), u2(8) to be 27r-periodic and choose a constant 70 so that the differential equation for s has the form

(1.41) 
$$\frac{ds}{d\theta} = \lambda s - \gamma_0 s^3 + S(\theta, s, \lambda)$$

where S(6,s,A) = o(IsI(IAI + s2)) as IAI - 0, 1 s I - 0. This is always possible. To be specific in the discussion of stability suppose 70 > 0. Equation (1.41) can be considered as a perturbation of the equation

$$\dot{y} = -\gamma_0 y^3$$

which has y = 0 uniformly asymptotically stable. Thus, there is a neighborhood of y = 0 say l y l < S such that for I A I < X0(6), every solution y(O) of (1.41) with initial value satisfying l y(0) I < S must satisfy l y (B) I < S for t> 0. Suppose ly(0)I .<S. Since (1.41) is 27r-periodic, y(O + 21r) is also a solution and y(O) <y(2Tr) implies y(2Trk) < y(27r(k + 1)) for k = 0,1,2, ... . Thus, y(21rk) - y,o as k - - and it is easy to show that the solution of (1.41) with initial value yo is 2,7r-periodic. A similar argument holds if y(O) > y(27r). Since the equation is 27r-periodic, this implies that, for every solution y(t) of (1.41) with ly(0)I < S, IAI < Ao, there is a 27r-periodic solution cy(O) such that y(O) - 4y(O) -a 0, as 0 This means the corresponding periodic orbit of (1.32) in R2 corresponding to Oy(O) is attracting the orbit corresponding to y(O). Since 70 0 0, there is only one nontrivial periodic orbit. Since 70 > 0, the trivial solution is always unstable for 0 < A < Ao and we have the nontrivial periodic orbit is asymptotically orbitally stable.

If y0 < 0, one argues in a similar way to obtain the nontrivial periodic orbit is unstable. We summarize these remarks as follows.

COROLLARY 1.1. Suppose A(A), f (z,A) have derivatives continuous up through order four and suppose GH(a,A) in (1.37) satisfies GH(a,A) = agH(a2,A) where gH(r,A) satisfies

$$g_H(r,\lambda) = \lambda - \gamma(\lambda)r + o(|r|)$$
 as  $r \to 0$   
 $\gamma(0) = \gamma_0 \neq 0$ .

Then there is a neighborhood of A = 0, x = 0 in which equation (1.32) has the following properties:

(i) y0 > 0, -A0 < A < 0, x = 0 is asymptotically stable and there is no periodic orbit. 0 < A < A0, x = 0 is unstable and there is an asymptotically orbitally stable periodic orbit. (ii) 70 < 0, -A0 < A < 0, x = 0 is asymptotically stable and there is an unstable periodic orbit. 0 < A < A0, x = 0 is unstable and there is no periodic orbit.

EXERCISE 1.19. Prove there exists asymptotic phase in Corollary I.I. Hint: Show the characteristic exponent for the solution s of (1.41) is not zero.

EXERCISE 1.20. Suppose GH(a,A) in (1.37) satisfies GH(a,A) = agH(a2,A) with g(r,0) = crm + o(I rl m) as r - 0 for some c \* 0 and integer m> 1. State and prove the analogue of Corollary I.I.

EXERCISE 1.21. Generalize the Hopf bifurcation theorem to a system

$$\dot{x} = A(\lambda)x + f(x, y, \lambda)$$

$$\dot{y} = B(\lambda)y + g(x, y, \lambda)$$

where f,g, and their partial derivatives vanish for x = 0, y = 0, x in R2, y in R. Suppose A(A) as before and det [I - expB(0)27r] = 0. Give conditions which will ensure there is a unique nonconstant period orbit for a given A sufficiently small. Discuss the stability properties of this orbit.

EXERCISE 1.22. Consider the scalar equation x2 + f (t, x, A) where f (t + 1, x, A) = f (t, x, A) has continuous derivatives up through order two in

x, A; f (t, x, 0) = o(1x12) as Ix I - 0, f (t, O, A) = 0 (I A I) as X -0. Prove there is a Ap > 0, So > 0, and a continuously differentiable function 'y(A), I X I < Ap, y(0) = 0, such that the following properties hold with respect to 1-periodic solutions of the above equation with norm <50:

- (i) y(A) > 0 implies no 1-periodic solution
- (ii) y(A) = 0 implies one 1-periodic solution
- (iii) y(X) < 0 implies two 1-periodic solutions.

Note that your results are true for X a parameter in a Banach space. Discuss the stability properties in case (ii). In case (iii), if x1(t,A) < x2(t,A) are the 1 periodic solutions, show that xl(t,A) is uniformly asymptotically stable and x2(t,A) is unstable. Hint: Obtain the bifurcation function G(a,X) from (1.29) and observe that G(a, 0) = a2 + o(1a12) as 1 a I -0. Thus, G(a, A) has a minimum at some a\*(X) for IAI small, a\*(0) = 0. Let y(X) = G(a\*(X),X). For case (ii), note that every bounded solution of the differential equation must approach a 1-periodic solution. At a zero a of G(a, X), note that the sign of aG(a,A)/aa is the same as the sign of the characteristic exponent of the corresponding periodic solution if this characteristic exponent is not zero. If two distinct periodic solutions exist and one characteristic exponent is zero, show that an appropriate small perturbation of the vector field will yield at least three periodic solutions near zero, which is a contradiction.

EXERCISE 1.23. Give an appropriate generalization of Exercise 1.22 to the equation in R2,

$$\dot{x} = x^2 + f(t, x, y, \lambda)$$

$$\dot{y} = -y + g(t, x, y, \lambda)$$

EXERCISE 1.24. Consider the scalar equation

$$\dot{x} = -x^3 + \lambda_1 f_1(t, x) + \lambda_2 f_2(t, x)$$

where A = (XI, A2) is in R 2, f (t + 1, x) = f (t, x) for all t, x, j = 1, 2,

$$\gamma_1 = \int_0^1 f_2(t,0)dt \neq 0$$

$$f_1(t,0) = 0,$$
  $\gamma_2 = \int_0^1 [\partial f_1(t,0)/\partial x] dt \neq 0$ 

Discuss the existence of 1-periodic solutions in a neighborhood of x = 0, X = 0. Show there is a cusp F in X-space such that on one side of r there is one 1 periodic solution and the other side there are three. Show the cusp is,rapproximately given by A2 = (4, /27y2)X . Hint: Show that the bifurcation' function G(a,X) is approximately given by -a3 + X272a + Alyl and determine those AI, A2 as functions of a so that G(a,X) = 0, aG(a,X) = 0.

EXERCISE 1.25. Discuss the stability of the periodic solution in Exercise 1.24.

EXERCISE 1.26. Generalize Exercise (1.24) to the equation

$$\dot{x} = -x^3 + f(t, x, \lambda)$$

where A is a parameter varying in a Banach space.

EXERCISE 1.27. Generalize Exercise (1.24) to the planar system

$$\dot{x} = -x^3 + f(t, x, \lambda)$$

$$\dot{y} = -y + g(t, x, \lambda)$$

where A = (A1,A2) is in R2.

## VM.2. Almost Linear Systems

In this section, the general perturbation scheme given in Section 1 will be generalized to the system

(2.1) 
$$\dot{x} = B(t)x + \varepsilon f(t, x),$$

where B(t -}- T) = B(t), f (t + T, x) = f (t, x) and 8f (t, x)/8x are continuous for all tin R, x in Cn.

Let the columns of '(t), a matrix of dimension n x p, be a basis for the T-periodic solutions of

$$(2.2) \dot{x} = B(t)x,$$

and let the rows of 'Y(t), a matrix of dimension p x n, be a basis for the T-periodic solutions of the adjoint equation

$$\dot{y} = -yB(t).$$

The p x p matrices (' denotes transpose)

(2.4) 
$$C = \int_0^T \Phi'(t)\Phi(t) dt, \qquad D = \int_0^T \Psi(t)\Psi'(t) dt$$

are nonsingular. In fact, if q(t) ='(t)a and Ca = 0, then f o q'(t)q(t) dt = 0 which implies q(t) = 0 for all t in [0, T]. But this implies a = 0. The same argument holds for the matrix D.

As before, let 1T be the space of continuous T-periodic n-vector functions with the uniform topology. The fact that C, D in (2.4) are nonsingular allows one to define two projection operators P, Q on 1T in the following way:

(2.5) 
$$Pf = \Phi(\cdot)a, \qquad a = C^{-1} \int_0^T \Phi'(t) f(t) dt,$$
$$Qf = \Psi'(\cdot)b, \qquad b = D^{-1} \int_0^T \Psi(t) f(t) dt.$$

It is easy to check that these are projections. Notice that P takes 'T onto the subspace of 1T spanned by the T-periodic solutions of (2.2) and Q takes 9T onto the subspace of 1T spanned by the transpose of the T-periodic solutions of (2.3). The justification for these definitions lies in the following lemma.

LEMMA 2.1. If f is a given element of 9T, then a necessary and sufficient condition that the equation

$$(2.6) \dot{x} = B(t)x + f(t)$$

has a T-periodic solution is that Qf = 0. If Qf = 0, then there is a unique T-periodic solution Y(f such that P.Y(f = 0. Furthermore, -''(I - Q) is a continuous linear operator taking 9T into MIT.

PROOF. The first part of the lemma is a restatement of Lemma IV.1.1. If Qf = 0, then there is a solution of (2.6) in PiT . If x0 is the initial value of any solution in 9T, then x0 must satisfy the equation Ex0 = b, where E = X(T) - I, b fo X(T)X-1(s)f(s)ds and X(t) is the principal matrix solution of x = B(t)x. Let E\* be a right inverse of E; that is, a matrix taking the range of E into Cn such that EE\* = I. Since Qf = 0 implies b is in the range of E, the vector x0 = E\*b corresponds to the initial value of a solution x\*(f) of (2.6) in 9T . If , ' f = (I - P)x\*(f) then the operator J f takes PIT into PiT and is clearly linear and continuous. Also, P.1' f = 0 and Yf is the only solution of (2.6) in 9T whose P-projection is zero. This completes the proof of Lemma 2.1.

COROLLARY 2.1. If f is in PIT and a is a given p-dimensional vector, then the unique solution of B(t)x + (I - Q) f with Px = (D( - )a is given by (Da+ '(I - Q)f

Example 2.1. Suppose B = B(t) is a constant n x n matrix, B = diag(0p , B1) where Op is the p-dimensional zero matrix and eB1T \_I is nonsingular. Then D, `F may be chosen as

$$\Phi = \begin{bmatrix} I_p \\ 0 \end{bmatrix}, \quad \Psi = \Phi' = [I_p, 0],$$

where Ip is the p x p identity matrix. It is easy to see that the matrices C, D in (2.4) and operators P, Q in (2.5) are given by C = D = TIp

$$Pf = Qf = \begin{bmatrix} \frac{1}{T} \int_0^T f_{\mathcal{P}}(t) dt \\ 0 \end{bmatrix},$$

where  $f_p$  denotes the first p components of f. This is the same operator defined in Section 1 for equation (1.10). If Qf = 0, then the explicit expression for  $\mathcal{K}f$  is

$$(\mathscr{K}f)(t) = \left[ egin{array}{c} \int^t f_{p}(s) \; ds \ \\ (e^{-B_1T} - I)^{-1} \int_0^T e^{-B_1s} f_{n-p}(t+s) \; ds \end{array} 
ight],$$

where  $\int_{-p}^{t} f_{p}$  is the unique primitive of  $f_{p}$  of mean value zero, and  $f_{n-p}$  denotes the last n-p components of f.

**Example 2.2.** Suppose B = B(t) is constant and

$$B = \begin{bmatrix} 0 & 1 \\ 0 & 0 \end{bmatrix}.$$

We may choose  $\Phi = \operatorname{col}(1, 0)$  and  $\Psi = \operatorname{row}(0, 1)$ . Then C = D = T and

$$Pf = \Phi(\cdot)a = \begin{bmatrix} 1 \\ 0 \end{bmatrix} \left( \frac{1}{T} \int_0^T f_1(s) \ ds \right),$$

$$Qf = \Psi'(\cdot)b = \begin{bmatrix} 0 \\ 1 \end{bmatrix} \left( \frac{1}{T} \int_0^T f_2(s) \ ds \right),$$

where  $f = (f_1, f_2)$ . If Qf = 0, one easily computes  $\mathcal{K}f$  to be

$$(\mathscr{K}f)(t) = egin{bmatrix} \int_0^t \left[ f_1(s) - rac{1}{T} \int_0^T f_1 + \int_s^s f_2 
ight] ds \ - rac{1}{T} \int_0^T f_1 + \int_s^t f_2 \end{cases},$$

where "f" again denotes the primitive of the integrand of mean value zero.

LEMMA 2.2. If the operators P, Q and  $\mathcal{K}$  are defined as in (2.5) and Lemma 2.1, then system (2.1) has a T-periodic solution x if and only if x satisfies the system of equations

(2.7) (a) 
$$x = Px + \varepsilon \mathcal{K}(I - Q)f(\cdot, x),$$
  
(b)  $\varepsilon Qf(\cdot, x) = 0.$ 

PROOF. Suppose x is any element of YT T. We first show that Q(x - Bx) = 0. In fact, from (2.5),

$$egin{align} Q(\dot{x}-Bx) = & \Psi' D^{-1} \int_0^T \Psi(t) [\dot{x}(t)-B(t)x(t)] \ dt \ \ & = & \Psi' D^{-1} \int_0^T [\Psi(t)\dot{x}(t) + \dot{\Psi}(t)x(t)] \ dt \ \ & = & \Psi' D^{-1} [\Psi(t)x(t)]_0^T = 0. \end{split}$$

An element x of 9T is a solution of (2.1) if and only if

$$Q(\dot{x}-Bx)=arepsilon Qf(\cdot\,,\,x), \ (I-Q)(\dot{x}-Bx)=arepsilon (I-Q)f(\cdot\,,\,x).$$

Since Q(x - Bx) = 0, these equations are equivalent to (2.7b) and x - Bx = (I - Q) f ( , x). Corollary 2.1 implies this latter equation is equivalent to (2.7a) and this proves the lemma.

LEMMA 2.3. For any a > 0, there is an to > 0 such that for any constant p-vector a, jal < a, Isl < to, there is a unique function x\* = x\*(a, e) which satisfies

(2.8) 
$$x^* = \Phi a + \varepsilon \mathcal{K}(I - Q) f(\cdot, x^*).$$

Furthermore, x\*(a, e) has a continuous first derivative with respect to a, a and x\*(a, 0) = a. If there is an a = a(e) with I a(e)I 5 a, 0 <\_ Is <\_ to and

(2.9) 
$$G(a, \varepsilon) \stackrel{\text{def}}{=} Qf(\cdot, x^*(a, \varepsilon)) = 0,$$

then x\*(a, e) is a T-periodic solution of (2.1). Conversely, if (2.1) has a T-periodic solution x(e) which is continuous in a and has P2(e) = (Da(s), ja(e)l < a, 0< Iel < to, then x(e) = x\*(a(e), e) where x\*(a, e) is the function defined above and a(e) satisfies (2.9) for 0 < 181:!9 Co.

PROOF. Suppose a > 0 is given and a is anyp-vector with jal ;Sot. Let be a positive number such that I11 a 11 < P for jal < a. For any y > 0, define ,So(y) = {y in YT: Py = 0, 11y11 :5 y} and the operator. : So(y) -\*9T by

(2.10) 
$$\mathscr{F}y = \varepsilon \,\mathscr{K}(I - Q)f(\cdot, y + \Phi a)$$

for y in 5o(y). If y\*(a, e) is a fixed point of .F in So(y), then x\*(a, e) (Da + y\*(a, e) is a solution of (2.8). The proof now proceeds exactly as in the proof of Lemma 1.2.

From the point of view of applications, it is convenient to observe that relation (2.5) implies that G(a, e) = 0 in (2.9) is equivalent to

(2.11) 
$$F(a, \varepsilon) \stackrel{\text{def}}{=} \int_0^T \Psi(t) f(t, x^*(a, \varepsilon)(t)) dt = 0.$$

Lemma 2.3 asserts the following: one can arbitrarily preassign an element  $x_P = \Phi a$  of the subspace of  $\mathscr{P}_T$  defined by  $\{f \text{ in } \mathscr{P}_T \colon Pf = f\}$  and then uniquely determine a solution of (2.7a) with Px replaced by  $x_P$ . The element  $x_P$  is then used to attempt to solve the remaining equation (2.7b).

Equations (2.9) or (2.11) are called the determining equations or bifurcation equations of (2.1) and can be determined approximately by successive approximations since  $\mathcal{F}$  in (2.10) is a contraction operator. Taking only the first approximation  $\Phi a$  for  $x^*(a, \varepsilon)$  and using the implicit function theorem, one arrives at

THEOREM 2.1. Suppose  $x^*(a, \varepsilon)$  is defined as in Lemma 2.3 and let  $F(a, \varepsilon)$  be defined by (2.11). If there is a *p*-vector  $a_0$  such that

$$F(a_0, 0) = 0, \qquad \det \left[ \frac{\partial F(a_0, 0)}{\partial a} \right] \neq 0,$$

then there are an  $\varepsilon_1 > 0$  and a *T*-periodic solution  $x^*(\varepsilon)$ ,  $0 \le |\varepsilon| \le \varepsilon_1$ , of (2.1),  $x^*(0) = \Phi a_0$  and  $x^*(\varepsilon)$  is continuously differentiable in  $\varepsilon$ .

EXERCISE 2.1. If f is in  $\mathcal{P}_T$  and Qf = 0, give a constructive procedure for determining the function  $\mathcal{X}f$  in  $\mathcal{P}_T$  given in Lemma 2.1.

EXERCISE 2.2. State and prove the appropriate generalizations of the results of this section for the equation

$$\dot{x} = B(t)x + f(t, x, \varepsilon),$$

where B(t+T) = B(t),  $f(t+T, x, \varepsilon) = f(t, x, \varepsilon)$  are continuous for  $(t, x, \varepsilon)$  in  $R \times C^n \times C$ , and

$$\begin{split} f(t,\dot{0},0) &= 0, \\ |f(t,x,\varepsilon) - f(t,y,\varepsilon)| &\leq \eta(|\varepsilon|,\sigma)|x-y|, \end{split}$$

for t in R,  $\varepsilon$  in C, x, y in  $C^n$ ,  $|x| < \sigma$ ,  $|y| < \sigma$  and  $\eta(\alpha, \sigma)$  is a continuous non-decreasing function for  $\alpha \ge 0$ ,  $\sigma \ge 0$ ,  $\eta(0, 0) = 0$ .

EXERCISE 2.3. Consider the system

(2.12) 
$$\dot{x}_1 = x_2$$
,  $\dot{x}_2 = \varepsilon[(\sigma + \alpha \cos 2t)x_1 + bx_1^3 + cx_2]$ ,

where  $\sigma$ ,  $\alpha$ , b, c are constants. Find conditions on these constants which will ensure that  $\pi$ -periodic solutions exist. What are their stability properties?

EXERCISE 2.4. Find conditions on  $\sigma$  so that (2.12) for b=c=0 has a  $\pi$ -periodic solution. Interpret your result in the light of the theory of the Mathieu equation.

If the system (2.1) possesses some additional properties, it is sometimes possible to make qualitative statements about the bifurcation equations (2.9) or (2.11) without any successive approximations. The next few pages are devoted to this question.

**Definition 2.1.** A system of differential equations  $\dot{x} = g(t, x)$  where x, g are n-vectors is said to have property (E) with respect to S if there exists a symmetric, constant  $n \times n$  matrix S such that  $S^2 = I$  and

$$Sg(-t, Sx) = -g(t, x)$$

for all t, x.

If x(t) is a solution of a system which has property (E) with respect to S, notice that Sx(-t) is also a solution. In fact, if x is a solution of such a system and w(t) = Sx(t), then

$$\dot{w}(t) = S\dot{x}(t) = Sg(t, x(t)) = Sg(t, S^{-1}w(t)) = Sg(t, Sw(t)) = -g(-t, w(t)).$$

This implies w(-t) = Sx(-t) is a solution of the original equation.

Lemma 2.4. Suppose S is an  $n \times n$  symmetric matrix,  $S^2 = I$ , B(t) = B(t+T) is an  $n \times n$  continuous matrix and f(t) = f(t+T) is a continuous n-vector such that

(2.13) (a) 
$$SB(-t) = -B(t)S$$
,

(b) 
$$Sf(-t) = -f(t)$$
.

Let the columns of the  $n \times p$  matrix  $\Phi$  be a basis for the T-periodic solutions of (2.2),  $\mathscr{K}$  be defined as in Lemma 2.1 and Q as in (2.5). Then

(2.14) (a) 
$$S\Phi(-t)a = \Phi(t)a$$
 for all  $t$  if  $S\Phi(0)a = \Phi(0)a$ ,

(b) S(Qf)(-t) = -(Qf)(t),

(c) 
$$S[\mathcal{K}(I-Q)f](-t) = [\mathcal{K}(I-Q)f](t).$$

PROOF. The fact that B satisfies (2.13) implies that system (2.2) has property (E) with respect to S and thus, if  $S\Phi(0)a = \Phi(0)a$ , then uniqueness of the solutions implies  $S\Phi(-t)a = \Phi(t)a$  for all t. This proves (2.14a). The matrix  $S\Phi(-t)$  is a basis for the T-periodic solutions of (2.2) and, consequently, there is a  $p \times p$  nonsingular matrix  $\Gamma$  such that  $S\Phi(-t) = \Phi(t)\Gamma$  for all t. In the same way, there is a  $p \times p$  nonsingular matrix M such that  $\Psi(-t)S = M\Psi(t)$  for all t.

For any f satisfying (2.13b), we have from (2.5), and S' = S that

$$\begin{split} S(Qf)(-t) &= S\Psi'(-t)D^{-1}\int_0^T \Psi(\alpha)f(\alpha) \ d\alpha \\ &= \Psi'(t)M'D^{-1}\int_0^T \Psi(-\alpha)f(-\alpha) \ d\alpha \end{split}$$

$$egin{aligned} &= -\Psi'(t)M'D^{-1}\int_0^T \Psi(-lpha)Sf(lpha)\;dlpha \ \\ &= -\Psi'(t)M'D^{-1}M\int_0^T \Psi(lpha)f(lpha)\;dlpha \end{aligned}$$

On the other hand, from (2.4) and S' = S,  $S^2 = I$ , one shows that MDM' = D. Therefore,  $M'D^{-1}M = D^{-1}$  and

$$S(Qf)(-t) = -\Psi'(t)D^{-1} \int_0^T \Psi(\alpha)f(\alpha) d\alpha$$
$$= -(Qf)(t).$$

This proves (2.14b).

If f satisfies (2.13b), then (2.14b) implies that (I-Q)f satisfies

$$S(I-Q)f(-t) = -(I-Q)f(t).$$

Therefore, to prove (2.14c), it is sufficient to show that (2.14c) is satisfied with (I-Q)f replaced by f and Qf=0. We first show that  $PS(\mathscr{K}f)(-\cdot)=0$ . From (2.5), this is true if and only if

$$\begin{split} 0 &= \int_0^T \Phi'(t) S(\mathscr{K}f)(-t) \ dt \\ &= \Gamma' \int_0^T \Phi'(-t) (\mathscr{K}f)(-t) \ dt \\ &= \Gamma' \int_0^T \Phi'(t) (\mathscr{K}f)(t) \ dt. \end{split}$$

Since  $P\mathcal{K}f = 0$  it follows that  $\int_0^T \Phi'(t)(\mathcal{K}f)(t) dt = 0$ . Therefore,  $PS(\mathcal{K}f)(-\cdot) = 0$ . Since  $\mathcal{K}f$  is the unique solution of (2.6) with  $P\mathcal{K}f = 0$  and  $S\mathcal{K}f(-\cdot)$  is also a solution of this same equation with P-projection zero, it follows that (2.14c) is true. This proves the lemma.

THEOREM 2.2. Let the columns of the  $n \times p$  matrix  $\Phi$  be a basis for the T-periodic solutions of (2.2) and let the rows of the  $p \times n$  matrix  $\Psi$  be a basis for the T-periodic solutions of (2.3). Let  $x^*(a, \varepsilon)$  be the function determined in Lemma 2.3 and suppose system (2.1) has property (E) with respect to S. Then

(2.15) 
$$Sx^*(a, \varepsilon)(-t) = x^*(a, \varepsilon)(t)$$

for all t provided that  $(I - S)\Phi(0)a = 0$ . In addition, if  $F(a, \varepsilon)$  is defined as in (2.11), then

$$(2.16) (I+M)F(a, \varepsilon) = 0.$$

where M is the matrix such that  $\Psi(-t)S = M\Psi(t)$ .

PROOF. Suppose  $S\Phi(0)a = \Phi(0)a$ ; let  $\mathscr{S}(\gamma)$  be defined as in the proof of Lemma 2.3 and  $\mathscr{S}^*(\gamma)$  be the subset of  $\mathscr{S}(\gamma)$  consisting of those y in  $\mathscr{S}(\gamma)$  which satisfy Sy(-t) = y(t). From Lemma 2.4,  $\mathscr{F}y = \varepsilon \mathscr{K}(I-Q)f(\cdot, y+\Phi a)$  belongs to  $\mathscr{S}^*(\gamma)$  for  $|\varepsilon| \le \varepsilon_0$  where  $\varepsilon_0$  is given in Lemma 2.3. Since this operator has a unique fixed point  $y^*(a, \varepsilon)$  in  $S(\gamma), Sy^*(a, \varepsilon)(-t) = y^*(a, \varepsilon)$  (t). Therefore (2.14a) implies  $x^*(a, \varepsilon) = y^*(a, \varepsilon) + \Phi a$  satisfies relation (2.15). Using (2.15), property (E) and the fact that  $\Psi(-t)S = M\Psi(t)$ , one obtains

$$\begin{split} F(a,\,\varepsilon) &= \int_0^T \Psi(t) f(t,\,x^*(a,\,\varepsilon)(t)) \; dt \\ &= \int_0^T \Psi(t) f(t,\,Sx^*(a,\,\varepsilon)(-t)) \; dt \\ &= -\int_0^T \Psi(t) S f(-t,\,x^*(a,\,\varepsilon)(-t)) \; dt \\ &= -M \int_0^T \Psi(-t) f(-t,\,x^*(a,\,\varepsilon)(-t)) \; dt \\ &= -M F(a,\,\varepsilon). \end{split}$$

This proves the theorem.

In the applications, Theorem 2.2 can be very useful and especially the conclusion expressed in (2.16). This relation says that the bifurcation functions given by the components of the vector F in (2.11) are dependent provided that the p-vector a satisfies  $(I-S)\Phi(0)a=0$ . This can lead to results for (2.1) involving the existence of families of periodic solutions. The following exercises illustrate this point and involve situations in which property (E) expresses some even and oddness properties of the functions in (2.1).

EXERCISE 2.5. Suppose f(-t, x) = -f(t, x) for all t in R, x in  $R^n$ . Show that the system  $\dot{x} = \varepsilon f(t, x)$  has an n-parameter family of periodic solutions for  $\varepsilon$  small. If f(t, x) = A(t)x and A(-t) = -A(t), this implies in particular all characteristic multipliers are 1.

EXERCISE 2.6. Reconsider Exercise 1.7 in the light of Theorem 2.2.

EXERCISE 2.7. Show that all solutions of the equation

$$\ddot{y} + \sigma^2 \dot{y} = \varepsilon g(y, \dot{y}, \ddot{y}), \qquad \sigma \neq 0,$$

in a neighborhood of  $y = \dot{y} = \ddot{y} = 0$  are periodic for  $\varepsilon$  small if  $g(y, -\dot{y}, \ddot{y}) = -g(y, \dot{y}, \ddot{y})$ . Write the equation as a third order system  $\dot{x} = A(\sigma^2)x + \varepsilon f(t, x)$ , let  $x = [\exp A(\tau^2)t]z$ ,  $\tau^2 = \sigma^2 + \varepsilon \beta$  and apply the previous results to the equation for z using  $\beta$  as one of the undetermined parameters.

EXERCISE 2.8. Consider the system of second order equations

$$\ddot{u}+\sigma^2 u=arepsilon g_1(u,\,\dot{u},\,v,\,\dot{v}), \ \ddot{v}+\mu^2 v=arepsilon g_2(u,\,\dot{u},\,v,\,\dot{v}),$$

where a mµ,µ \* ma for m = 0, +1, ... and

$$egin{align} g_1(-u,\,\dot{u},\,v,\,-\dot{v}) &= -g_1(u,\,\dot{u},\,v,\,\dot{v}), \ &g_2(-u,\,\dot{u},\,v,\,-\dot{v}) &= g_2(u,\,\dot{u},\,v,\,\dot{v}). \ \end{array}$$

Show that this system has two 2-parameter families of periodic solutions. Let x1= u, x2 = afi, x3 = V, v4 = µv to obtain a fourth order system t = A(a, µ)x + of (x) where A(a, µ) = diag(B(a), B(µ)), x = (y, z), y, z two-vectors and let y = [exp B(-r)t] Y, z = Z, z = a + e/3 and apply Theorem 2.2 to the equation for (Y, Z) using f as one of the undetermined parameters. Generalize this result to other types of symmetry as well as a system of n-second order equations.

## Definition 2.2. 1 A first integral of a system

$$(2.17) \dot{x} = g(t, x)$$

is a function u: R X Cn - C which has continuous first partial derivatives such that

$$\frac{\partial u(t, x)}{\partial x} g(t, x) + \frac{\partial u(t, x)}{\partial t} = 0$$

for all t, x.

If x(t, to, xo), x(to, to, xo) = xo is a solution of (2.17) and u is a first integral of (2.17), then u(t, x(t, to, xo)) = u(to, xo) for all t for which x(t, to, xo) is defined. If to = 0, we write x(t, xo), x(0, xo) = xo, for a solution of (2.17).

Let V (t, xo) = ax(t, xo)/axo. In Chapter I, we have seen that V is a principal matrix solution of the equation

$$(2.18)$$

LEMMA 2.5. If u is a first integral of (2.17) which has continuous second partial derivatives, then uz(t, xo) defau(t, x(t, xo))/ax is a solution of the adjoint equation

$$(2.19) \dot{w} = -wH,$$

where H is defined in (2.18).

PROOF. Since u(t, x(t, xo)) = u(0, xo) for all t and all xo, it follows that ux(t, x(t, xo)) V(t, xo) = ux(0, xo) for all t. Differentiating this relation with respect to t, one obtains

$$0 = \dot{u}_x V + u_x \dot{V} = [\dot{u}_x + u_x H]V$$

for all t. Since V is nonsingular, ux must satisfy (2.19) and the lemma is proved.

LEMMA 2.6. If u(t + T, x, s) = u(t, x, e) is a first integral of (2.1) which has continuous second partial derivatives with respect to t and x and x\*(a, s) is the T-periodic function given in Lemma 2.3, then

(2.20) 
$$\int_0^T [u_x Qf]_{x=x \cdot (a, \epsilon)}(t) dt = 0$$

for e 0, where Q is defined in (2.5).

PROOF. Since u is a first integral of (2.1), we have in particular that

$$\int_0^T [u_x(Bx+\varepsilon f)+u_t]_{x=x\bullet(a,\ \varepsilon)}(t)\ dt=0.$$

Since x\*(a, e)(t) and u(t, x, e) are T-periodic in t, we also have

$$\begin{split} 0 &= \int_0^T \frac{d}{dt} [u(t, x^*(a, \varepsilon)(t), \varepsilon)] dt \\ &= \int_0^T [u_x \dot{x}^* + u_t]_{x = x \cdot (a, \varepsilon)}(t) dt \\ &= \int_0^T [u_x (Bx + \varepsilon f - \varepsilon Q f) + u_t]_{x = x \cdot (a, \varepsilon)}(t) dt. \end{split}$$

Subtracting these two expressions gives (2.20) and proves the lemma.

Suppose x\*(a, s) is the T-periodic function given in Lemma 2.3 and suppose u(t, x, e) = u(t + T, x, e) is a first integral of (2.1) with ux(t, 0, 0) 0. From Lemma 2.5, it follows that ux(t, 0, 0) is a nontrivial T-periodic solution of tv = -wB(t). Since x\*(0, 0) = 0, ux(t, x\*(0, 0)(t), 0) = ux(t, 0, 0) 0 0 is a T-periodic solution of the adjoint equation t8 = -wB(t). With the rows of the p x n matrix `F defining a basis for the T-periodic solutions of this equation, this implies there is a p-dimensional row vector h zi6 0 such that ux(t, 0, 0) = h'F(t). Obviously, there is a continuous function µ(t, a, e) = µ(t + T, a, e) such that µ(t,0,0)=0 and

$$u_x(t, x^*(a, \varepsilon)(t), \varepsilon) = u_x(t, 0, 0) + \mu(t, a, \varepsilon)$$
  
=  $h\Psi(t) + \mu(t, a, \varepsilon)$ .

If F(a, s) is defined as in (2.11), then (2.5) implies that equation (2.20) can be written as

$$egin{aligned} 0 &= \int_0^T [h\Psi(t) + \mu(t,a,\,arepsilon)]\Psi'(t)D^{-1}F(a,\,arepsilon) \,dt \ &= iggl[ h + \int_0^T \mu(t,a,\,arepsilon)\Psi'(t)D^{-1} \,dt iggr] F(a,\,arepsilon) \end{aligned}$$

for 0 < I EI <\_ Eo : Since h is nonzero and p (t, 0, 0) == 0, it follows there are al 0, El 0 such that h + f T µ(t, a, E)'F'(t)D-1 dt = hl is zA 0 for Jai < al, EI El. Therefore, there is a linear relation among the components of F; that is, a linear relation among the bifurcation functions of (2.1). One of the bifurcation functions is therefore redundant if there is a first integral u(t, x, E) \_ u(t + T, x, E) of (2.1) with ux (t, 0, 0) zA 0.

If ul, ... , uk are first integrals of (2.1), we say they are linearly independent if the matrix uz(t, 0, 0) = 8u(t, 0, 0)/8x, u = (u1, ... , uk) has rank k. Using the same argument as above, one obtains

THEOREM 2.3. Let u= (ul, ... , uk) be k <p p linearly independent first integrals of (2.1), u(t + T, E) = u(t, x, E) be continuous and have continuous second partial derivatives with respect to t, x. Then there are an al > 0, el > 0 and a k x p matrix H of rank k such that HF(a, e) = 0 for jai < al, JEJ < El and F(a, e) defined in (2.11). If k = p, then there exists a p-parameter family of T-periodic solutions x\*(a, e), Jai < al, JEJ < El, where x\*(a, e) is given in Lemma 2.3.

The proof of the first part of this theorem is essentially the same as the above argument for k = 1. If k = p, then H is a nonsingular matrix and HF(a, E) = 0 implies F(a, E) = 0 for jai < al, I el < el; that is, the bifurcation equations are automatically satisfied. An application of Lemma 2.3 completes the proof of the theorem.

EXERCISE 2.9. (Liapunov's theorem) Suppose the system

(2.21) 
$$\begin{aligned} \dot{x}_1 &= \sigma x_2 + f_1(x_1, x_2, y), \\ \dot{x}_2 &= -\sigma x_1 + f_2(x_1, x_2, y), \\ \dot{y} &= Cy + g(x_1, x_2, y), \end{aligned}$$

where a > 0, x1, x2 are scalars, y is an m-vector, fl, f2, g are analytic in a neighborhood of x1= 0 = X2, y = 0 with the power series beginning with terms of degree at least two. Suppose this system has a first integral W (XI, X2, y) which has continuous second derivatives with respect to x1, X2, y and the eigenvalues A1, ..., Am of the constant matrix C satisfy Ak :56 ion for k = 1, 2, ..., m, and every integer n. Prove that this system has a two parameter family of periodic solutions. Introduce polar type coordinates XI = p cos aB, x2 = -p sin aB in (2.21) and eliminate tin the resulting equations to obtain differential equations for p, y as functions of 0. Let p -\* ep, y -\* ey and apply Theorem 2.3. If all eigenvalues of C are purely imaginary, do there exist other families of periodic solutions? What additional conditions are sufficient for the existence of other families of periodic solutions? Is it necessary to assume that f1, f2, g are analytic?

EXERCISE 2.10. Interpret the general theory of this section for the particular nth order scalar equation

$$\frac{d^n y}{dt^n} = \varepsilon f(t, y).$$

EXERCisE 2.11. Consider the system

$$\dot{w} = A_0 w + \varepsilon \Phi(t) w,$$

where 1(t + T) \_ b(t) is a continuous n x n matrix and A0 is a constant matrix. Give a constructive procedure which is in the spirit of this section for obtaining a principal matrix solution of (2.22) of the form U(t, e) exp[B(e)t] with U(t + T, s) = U(t, e), U(t, 0) = I, B(0) = Ao. Consider then x n matrix equation

$$\dot{W} = AW + \varepsilon\Phi(t)W$$

and, for any given n x n constant matrix A1, let W = U exp[Ao - Ai]t. The differential equation for U is

$$\dot{U} = A_0 U - U A_0 + U A_1 + \varepsilon \Phi(t) U.$$

Determine necessary and sufficient conditions that the nonhomogeneous matrix equation

$$\dot{U} = A_0 U - U A_0 + F(t).$$

$$F(t+T) = F(t),$$

have a T-periodic solution. Use this fact to obtain a set of matrix equations P(A1i s) = 0 whose solution is necessary and sufficient for obtaining a T-periodic matrix solution of (2.24). Show there is always a matrix function A1(e) such that I'(A1(e), e) = 0 for a small.

EXERCISE 2.12. Generalize exercise 2.11 to a class of almost periodic matrix perturbations D(t).

EXERCISE 2.13. If Ae in (2.22) is a T-periodic matrix function, how could the procedure of exercise (2.11) be modified to obtain the principal matrix solution?

In Exercise 2.2, the reader was supposed to prove that one could use the methods of this chapter to obtain T-periodic solutions for equations which contained nonlinear terms when e = 0. Of course, one must then discuss those solutions which remain in a sufficiently small neighborhood of e = 0, x = 0. As in Section 1, a further generalization is needed to discuss equations which contain several independent parameters. In the next pages, we give this generalization and a few illustrations.

Consider the T-periodic system

$$(2.25) \dot{x} = B(t)x + f(t, x, \lambda)$$

where B(t + T) = B(t) is a continuous n X n matrix, A is in Rk, f(t + T,x,A) = f (t, x, A) has continuous derivatives up through order one in x, A,

$$(2.26) f(t,0,0) = 0, \, \partial f(t,0,0)/\partial x = 0.$$

The analogue of Lemma 2.3 is the following which is stated without proof.

LEMMA 2.7. If P, Q are defined in (2.5), . :. T -> T in Lemma 2.1, and (2.26) is satisfied, then there are Ap > 0, ao > 0, such that, for any a in R' lal < ao; any A in Rk, IAI < Ap, there is a unique T-periodic function x\* = x\*(a,A) continuous together with its first derivative satisfying x\*(0,0) = 0,

$$x^* = \Phi_a + \mathcal{K}(I - Q)f(\cdot, x^*, \lambda).$$

If there exist a,A such that

$$G(a,\lambda) \stackrel{\text{def.}}{=} \frac{1}{T} \int_0^T \Psi(t) f(t, x^*(a,\lambda)(t), \lambda) dt = 0$$

then x\*(a,X) is a T-periodic solution of (2.25). Conversely, if (2.25) has a T-periodic solution x(X) which is continuous in A and has Px(A) = (Da(A),' ja(A)I < ao, IAI < A0, then x(X) = x\*(a(X), X) where x\*(a, X) is the function given above and a(X) satisfies (2.27) for 0 < I A I G A0.

Let us illustrate the use of this lemma for Duffmg's equation. In Section V.5, we have discussed Duffing's equation with a small harmonic forcing by the method of averaging. In order to do this, we assumed all of the parameters were multiples of a single small parameter e. Also, because of the nature of averaging, we could only discuss a periodic solution if its characteristic multipliers were not on the unit circle. This implies that the information obtained is incomplete in the neighborhood of the points in parameter space where the number of periodic solutions changes from one to three. A more complete discussion can be given based on Lemma 1.4. We give an indication of the procedure below for the case of no damping.

Consider the equation

(2.28) 
$$\frac{d^2u}{d\tau^2} + u + \gamma u^3 = F\cos\omega\tau$$

where y \* 0 is a fixed real number, F, w - 1 are small real parameters-The

objective is to obtain the  $2\pi/\omega$ -periodic solutions of (2.28) which have small norm. If

$$\omega^2 = 1 + \beta$$
,  $\omega \tau = t$ ,  $\lambda_1 = \frac{\beta}{1+\beta}$ ,  $\mu_0 = \frac{\gamma}{1+\beta}$ ,  $\mu_2 = \frac{F}{1+\beta}$ 

then

(2.29) 
$$\frac{d^2u}{dt^2} + u = -\mu_0 u^3 + \lambda_1 u + \mu_2 \cos t$$

and we determine  $2\pi$ -periodic solutions of (2.29) of small norm. Since  $\gamma \neq 0$ , the transformation  $u = |\mu_0|^{-1/2}x$  for  $\beta$  small can be made to obtain

$$(2.30) \qquad \ddot{x} + x = -(\operatorname{sgn} \gamma)x^3 + \lambda_1 x + \lambda_2 \cos t,$$

where  $\lambda_2 = |\mu_0|^{1/2}\mu_2$ . Therefore, we must analyze the existence of small  $2\pi$ -periodic solutions of (2.30) for the parameter  $\lambda = (\lambda_1, \lambda_2)$  varying in a neighborhood of  $\lambda = 0$ .

We could transform (2.30) to a system of two first order equations, but it is actually more convenient to work directly with (2.30). Let  $\mathscr{P}_{2\pi} = \{x: R \to R, \text{ continuous, } 2\pi\text{-periodic}\}\)$  with the usual norm. If

(2.31) 
$$P: \mathscr{P}_{2\pi} \to \mathscr{P}_{2\pi}$$

$$(Ph)(t) = \frac{1}{\pi} \cos t \int_0^{2\pi} h(s) \cos s \, ds + \frac{1}{\pi} \sin t \int_0^{2\pi} h(s) \sin s \, ds$$

then P is a continuous projection and the equation

$$(2.32) \ddot{x} + x = h(t)$$

for h in  $\mathscr{P}_{2\pi}$  has a  $2\pi$ -periodic solution if and only if Ph = 0. If Ph = 0, then we can obtain a unique  $2\pi$ -periodic solution  $\mathscr{K}h$  of (2.32) which is orthogonal to  $\sin t$ ,  $\cos t$ . The general  $2\pi$ -periodic solution of (2.32) is

(2.32) 
$$x(t) = a\cos(t - \phi) + (\mathcal{Y}h)(t)$$

where  $a, \phi$  are arbitrary real numbers.

Therefore, a  $2\pi$ -periodic solution of (2.30) is given by

$$x(t) = a\cos(t - \phi) + \mathcal{K}(I - P)[-(\operatorname{sgn}\gamma)x^3 + \lambda_1 x + \lambda_2 \cos \cdot](t)$$
$$P[-(\operatorname{sgn}\gamma)x^3 + \lambda_1 x + \lambda_2 \cos \cdot] = 0$$

for some  $a, \phi$ . The parameters  $a, \phi$  must be determined through the bifurcation equations  $P[\ ]=0$ . For the method, it is convenient to put the parameter  $\phi$  in the perturbation term by replacing t by  $t+\phi$ ; that is, consider the equation

(2.33) 
$$\ddot{x} + x = -(\operatorname{sgn} \gamma)x^{3} + \lambda_{1}x + \lambda_{2}\cos(t + \phi)$$

and a  $2\pi$ -periodic solution x so that  $Px = a \cos t$  for some a. Such a solution x must satisfy

(2.34) (a) 
$$x(t) = a\cos t + \mathcal{X}(I - P)[-(\operatorname{sgn}\gamma)x^3 + \lambda_1 x + \lambda_2 \cos(\cdot + \phi)](t)$$
  
(b)  $P[-(\operatorname{sgn}\gamma)x^3 + \lambda_1 x + \lambda_2 \cos(\cdot + \phi)] = 0$ 

In the usual way, solve equation (2.34a) for a  $2\pi$ -periodic function,  $x^*(\phi, a, \lambda)$  for  $a, \lambda$  small,  $x^*(\phi, a, \lambda) = a\cos t + o(|a|)$  as  $a \to 0$ .

Then the bifurcation equations are

(a) 
$$\lambda_2 \cos \phi + \frac{1}{\pi} \int_0^{2\pi} [\lambda_1 x^*(t) - (\operatorname{sgn} \gamma) x^{*3}(t)] \cos t dt = 0$$

(b) 
$$\lambda_2 \sin \phi + \frac{1}{\pi} \int_0^{2\pi} [\lambda_1 x^*(t) - (\operatorname{sgn} \gamma) x^{*3}(t)] \sin t dt = 0$$

EXERCISE 2.14. Prove  $x^*(\phi, a, \lambda)$  is an even function of t.

From Exercise (2.14), Equation (2.35b) is equivalent to  $\lambda_2 \sin \phi = 0$  or  $\phi = 0$  if  $\lambda_2 \neq 0$ . If  $\lambda_2 = 0$ , then the only  $2\pi$ -periodic solution of (2.33) near x = 0,  $\lambda_1 = 0$  is x = 0. Thus, we may assume  $\phi = 0$  and have the result that there is a  $2\pi$ -periodic solution of Equation (2.30) near x = 0,  $\lambda = 0$  if and only if this solution is even,  $x(t) = x^*(0, a, \lambda)(t)$  and  $(a, \lambda)$  satisfy the equation

$$(2.36) \quad G(a,\lambda) \stackrel{\text{def}}{=} \lambda_2 + \frac{1}{\pi} \int_0^{2\pi} [\lambda_1 x^*(0,a,\lambda)(t) - (\operatorname{sgn} \gamma) x^{*3}(0,a,\lambda)(t)] \cos t \, dt = 0$$

It remains to analyze Equation (2.36). It is not difficult to show that

$$G(a,\lambda) = \alpha_0(\lambda) + \alpha_1(\lambda)a + \alpha_2(\lambda)a^2 + \alpha_3(\lambda)a^3 + o(|a|^3)$$

where

$$\alpha_0(\lambda) = \lambda_2 + o(|\lambda_1| + |\lambda_2|)$$

$$\alpha_1(\lambda) = \lambda_1 + o(|\lambda_1| + |\lambda_2|)$$

$$\alpha_2(\lambda) = 0(|\lambda|)$$

$$\alpha_3(0) = -\frac{3}{4} \operatorname{sgn} \gamma$$

The first objective is to obtain the values of  $\lambda$  which give rise to multiple solutions of  $G(a,\lambda)=0$ ; that is, those values of  $\lambda$  for which

(2.37) 
$$G(a,\lambda) = 0, \quad \partial G(a,\lambda)/\partial a = 0$$

The Jacobian of these two functions with respect to  $\lambda$  is given by

$$\det\begin{bmatrix} 0 & 1 \\ 1 & 0 \end{bmatrix} = -1.$$

Consequently, there are unique solutions Xl(a),X2(a) of (2.37) near a = 0 and they are given approximately by

(2.38) 
$$\lambda_1(a) = \frac{9}{4}(\operatorname{sgn} \gamma)a^2 + o(|a|^2), \qquad \lambda_2(a) = -\frac{3}{2}(\operatorname{sgn} \gamma)a^3 + o(|a|^3)$$

Formulas (2.38) are the parametric representation of a cusp given approximately by X2 = (16/81)(sgny)Xi in the (X1,X2)-plane. Since aG(0,0)/aX2 = 1, it follows that there is one solution on one side of this cusp and three on the other. This analysis gives a complete picture of the small 27r-periodic solutions in a neighborhood of x = 0 for X = (X1,X2) varying independently over a full neighborhood of zero.

EXERCISE 2.15. (General) Analyze all the exercises in this chapter in the spirit of the above discussion for Duffing's equation.

Let us consider another example which will illustrate in a more dramatic way the importance of considering independent variations in the parameters. Suppose g(x) has continuous derivatives up through order 2 in the scalar variable x and the equation

$$(2.39) \qquad \ddot{x} + g(x) = 0$$

has a family of periodic solutions O(w(a)t+ a,a) for a in R, la - a0,1 < S, for some fixed ao,6,w(ao) = 1, ((0,a) = 0(0 + 21r,a); that is, the solutions have period 27r/w(a) where a can be considered as the amplitude of the solution and a the phase. We assume the period 27r/w (a) is the least period. Suppose f (t) is a continuous 27r-periodic function (27r is not necessarily the least period), ?1,X2 are small real parameters and consider the equation

$$(2.40) \ddot{x} + g(x) = -\lambda_1 \dot{x} + \lambda_2 f(t).$$

Let r = tin R} be the 27r-periodic orbit in the phase space (x, x) corresponding to the amplitude a0. The problem is to determine all the 21r-periodic solutions of (2.40) which lie in a neighborhood of IF for X = (X1,X2) in a neighborhood of zero. If the least period of F is 27r and the least period of f is 21r, then we are looking for harmonic solutions near r. If the least period of r is 27r and the least period off is 21r/k for some integer k > 1, we are looking for subharmonics of order k near P.

We need the following pypotheses:

$$(H_1) \qquad \qquad \omega(a_0) = 1, \qquad \omega'(a_0) \neq 0$$

(H<sub>2</sub>) If 
$$p(t) = \phi(t, a_0)$$
 and  $h(\alpha) = \int_0^{2\pi} \dot{p}(t) f(t - \alpha) dt / \int_0^{2\pi} \dot{p}^2(t) dt$ 

then h(a) has a unique maximum at aM in [0,21r), a unique minimum at a, in [0,27r), V (am) 0 0, h" (am) 0.

We can then state

THEOREM 2.4. If (HI), (H2) are satisfied, then there exist enighborhoods U of P, V of X = 0 and curves Cm C V, CM C V, defined respectively by NI = cm(X2), Xi = cM(X2) with cm, CM continuously differentiable in X2, Cm,CM respectively are tangent to the lines XI = h(am)X2, Xi = h(aM)X2 at AI = X2 = 0, these curves intersect only at zero, the sectors between these curves containing X2 = 0 has no 21r-periodic solutions and the other sectors contain at least two solutions. If the least period of f (t) is k, k > 1 an integer, then x(t) a 27r-periodic solution implies x(t + m/k), m = 0,1, ... , k - I is also a 27r-periodic solution.

PROOF. Our first objectivels-to. obtain a convenient coordinate system near P. The vector -r(6) = (p(O), p(O)) is tangent to r and y(9) = (p(8),-p(O)) is orthogonal to r(O). For a fixed a0, an application of the Implicit Function Theorem shows that the mapping

(2.41) 
$$x = p(\alpha) + a\ddot{p}(\alpha)$$
$$y = \dot{p}(\alpha) - a\dot{p}(\alpha)$$

is a homeomorphism of a neighborhood of (a0,0) into a neighborhood of (p(a0),b(a0)). By using the compactness of r and further restricting the size of a, one easily concludes that there is an a0 > 0 such that the set

$$U = \{(x, y) \text{ given by } (2.41) \text{ for } 0 \le \alpha < 2\pi, |a| < a_0\}$$

is an open neighborhood of r and, for any (x,y) E U, there is a unique (a,a) such that (x,y) satisfies (2.41); that is, (a,a), 0 < a < 27r, lal < a6, serves as a coordinate system for a neighborhood of P.

If (x(t), y(t)), y(t) = z(t), is a 27r-periodic solution of (2.40) which lies in a sufficiently small neighborhood of r, then the initial value (x(0), y(0)) uniquely determines an (a, a) such that (x(0), y(0)) is given by (2.41). Therefore, it is sufficient to consider only those 27r-periodic solutions of (2.41) of the form

$$x(t) = p(t + \alpha) + z(t + \alpha)$$
  
$$y(t) = \dot{p}(t + \alpha) + \dot{z}(t + \alpha)$$

where (z(a),z(a)) = ay(a)for some constant a; that is,(z(0),z(0)) is orthogonal to T(a) = (vi(a), p(a)). If x(t + a) = p(t + a) + z(t + a), t + a is replaced by t and f«(t) = f (t - a), then

$$(2.42) \ddot{z} + g'(p)z = \lambda_1 \dot{z} + \lambda_1 \dot{p} + \lambda_2 f_{\alpha}(t) + G(t, z)$$

where G(t + 27r, z) = G(t, z) and G(t, z) = 0(Iz 12) as I z I -+ 0.

We now apply our basic method to Equation (2.42).

Hypothesis (HI) implies that all 27r-periodic solutions of the linear equation

$$\ddot{v} + g'(p)v = 0$$

are constant multiples of p. Let us define f "132 = 17 and define the continuous projection P:. 2,r -. 2a by the relation

$$(2.44) P\phi = \dot{p} \int_0^{2\pi} \phi \dot{p} / \eta.$$

For a given 0 E ,912,8, the Fredholm alternative implies that the nonhomogeneous equation

$$(2.45) \ddot{v} + g'(p)v = \phi(t)$$

has a 21r-periodic solution if and only if P0 = 0. If P0 = 0 and vo(t) = vo(t;¢) is any particular solution of (2.45), then each 27r-periodic solution of (2.45) is given by

$$v(t) = \beta \dot{p}(t) + v_0(t, \phi)$$

for some constant P. The solution v will have (v(0), a(0)) orthogonal to (13(0), 13(0)) if and only if

(2.46) 
$$\beta[\dot{p}(0)^2 + \ddot{p}(0)^2] = -\dot{p}(0)v_0(0;\phi) - \ddot{p}(0)\dot{v}_0(0;\phi).$$

This relation uniquely defines 0 = f3(0) as a function of 0. If we define

$$(2.47) \qquad (\mathscr{F}\phi)(t) = \beta(\phi)\dot{p}(t) + v_0(t,\phi), \, \phi \in (I-P)\mathscr{F}_{2\pi},$$

then one can easily verify that X: (I - P).912, -> Y2, is a continuous linear operator.

With this definition of X, (2.40) will have a solution of the form, x = p + z, if and only if the following equations are satisfied:

(2.48a) 
$$z = \mathcal{K}(I - P)[-\lambda_1 \dot{z} - \lambda_1 \dot{p} + \lambda_2 f_\alpha + G(\cdot, z)]$$

$$(2.48b) P[-\lambda_1 \dot{z} - \lambda_1 \dot{p} + \lambda_2 f_\alpha + G(\cdot, z)] = 0.$$

An application of the Implicit Function Theorem to (2.48a) shows there is a neighborhood U C ,912,, of zero and a neighborhood V C R 2 of A= 0 such that (2.48a) has a solution z\*(a,X) for A in V, 0 < a < 21r, this solution is unique in U, has continuous second derivatives with respect to a,A and z\*(a,0) = 0 for all a. Therefore, (2.40) will have a 27r-periodic solution in a sufficiently small neighborhood of I' for A in a sufficiently small neighborhood of zero if and only if (a, A) satisfy Equation (2.48h) with z replaced by z\*(a,X); that is, if and only if (a, A) satisfy the bifurcation equation

$$(2.49) F(\alpha,\lambda) \stackrel{\text{def}}{=} \int_0^{2\pi} \dot{p} [-\lambda_1 \dot{z}^*(\alpha,\lambda) - \lambda_1 \dot{p} + \lambda_2 f_\alpha + G(\cdot,z^*(\alpha,\lambda))]/\eta = 0.$$

The function F(a,A) satisfies F(a, 0) = 0 and

(2.50) 
$$F(\alpha,\lambda) = -\lambda_1 + h(\alpha)\lambda_2 + \text{h.o.t.}$$

where h(a) is given in (H2) and h.o.t. designates terms which are 0(1X12) as IXI-+0.

For any X2 0 0, the Bifurcation Equation (2.50) is equivalent to

(2.51) 
$$h(\alpha) - \frac{\lambda_1}{\lambda_2} + Q\left(\alpha, \frac{\lambda_1}{\lambda_2}, \lambda\right) = 0$$

where Q(a,(3, X) has continuous derivatives up through order two and Q(a, (3, 0) = 0.

It remains to analyse the bifurcation equation (2.51). Finding all possible solutions of (2.51) in a neighborhood of X = 0 is equivalent to finding all possible solutions of the equation

(2.52) 
$$H(\alpha,\beta,\lambda_2) \stackrel{\text{def}}{=} h(\alpha) - \beta + Q(\alpha,\beta,\lambda_2) = 0$$

for all a E R, (i E R, and X2 in a small neighborhood of zero. For X2 = 0, the only possible solutions (a0,f30) are those for which h(a0) = go. If ao is such that h'(ao) \* 0, then the Implicit Function Theorem implies there is a 6(a0,00)> 0 and unique solution a\*(f3, X2) of (2.52) for 10 - (301,1 X21 < 6(a0, 00), a\*(f3n, 0) = a 0 .

It h'(a0) = 0, then Hypothesis (H2) implies h"(ao) 0 0. Therefore, there is a 6(a0,(30) > 0 and a function a\*((3,X2), a\*((30,0) = a0, such that

$$\partial H(\alpha^*(\beta,\lambda_2),\beta,\lambda_2)/\partial\alpha=0$$

for I0 - 1301,1X21 < S(ao,(3o) and a\*((3,X2) is unique in the region la - aol < S(a0,p0). Thus, the function M((3,X2)fPH(a\*((3,A2),f3,X2) is a maximum or a minimum of H(a,(3,X2) with respect to a for (3,X2 fixed. A few elementary calculations shows that M(f30,0) = 0, aM(f30,0)/ai = -1. Therefore, the Implicit Function Theorem implies there is a 6((3o) and a unique function 0\*(A2),f\*(0) = (3p, such that M(6\*(X2),X2) = 0 for IX21 < 8(f3o). There are two simple solutions of (2.52)' near ao on one side of the curve 13 = 0\*(A2) and no solutions on the other. In terms of the original coordinates A, this implies there are two solutions of (2.51) near ao on one side of the curve XI. = (3\*(X2)A2 and none on the other. The curve AI = R\*(A2)X2 is a bifurcation curve and is tangent to the line XI =130A2 at A = 0.

The above analysis can be applied to each of the points aj in Hypothesis (112). One can choose a S > 0 such that all solutions of (2.51) for I a - a I < 1 X I < S are obtained with the argument above.

The complement of these small regions I a - a1I < S in [0,27r] is compact and h'(a) = 0 in this set. A repeated application of the Implicit Function Theorem now shows that no further bifurcation takes place and all solutions are obtained for I A I, I X21 < S. This shows there exist two 27r-periodic solutions in the sectors mentioned in the theorem. If the least period of f(t) is 1/k, k> 1 an integer, then we can obtain other 27r-periodic solutions by replacing t by

t + m/k, k = 0, 1, 2, ... , k - 1. This completes the proof of the theorem.

EXERCISE 2.16. Let S be a sector in Theorem 2.4 which contains 21rperiodic solutions. Suppose y is a continuous curve in S defined parametrically by A = 0 < 0 < 1, X (R) + X2((3) = 0 implies Q = 0 and let x(t,13) be a 27r-periodic solution of (2.40) for Xi = A1(6) which is continuous in 0 for 0 < 0 < 1. Prove that x( ,j3) is continuous at 0 = 0 if and only if

$$\lim_{\beta \to 0} \lambda_1(\beta)/\lambda_2(\beta)$$

exists. If this limit is h0 then p( + ao) where a0 is a solution of h(ao) = ho.

Exercise 2.16 shows the difference between considering parameters independently and considering them varying only along some straight line in X-space. In fact, if one considers Ao = fixed in p 2, puts A = eAo and considers Equation (2.40) for e small, then the most interesting part of the qualitative behavior of the solutions is lost.

EXERCISE 2.17. Generalize Theorem 2.4 to the case where h(a) has a finite number of extreme values aj on [0,27r] with h"(a1) \* 0.

EXERCISE 2.18. Generalize Theorem 2.4 to the equation

$$\ddot{x} + g(x) = \lambda_1 f_1(t) x + \lambda_2 f_2(t)$$

## VIII.3. Periodic Solutions of Perturbed Autonomous Equations

In this section, part of Theorem VI.4.1 is reproved by using the methods of this chapter rather than a coordinate system near a periodic orbit. Consider the equation

$$\dot{x} = f(x) + F(x, \varepsilon),$$

where f : Rn -\* Rn, F: Rn+1 Rn are continuous, f (x), F(x, e) have continuous first partial derivatives with respect to x and F(x, 0) = 0 for all x. If the system

$$\dot{x} = f(x)$$

has a nonconstant periodic solution u(t) of period co whose orbit is W, then the linear variational equation for u is

(3.3) 
$$\dot{y} = A(t) y, \qquad A(t) = \frac{\partial f(u(t))}{\partial x},$$

and this linear periodic system always has at least one characteristic multiplier equal to 1.

T\$rOREM 3.1. If 1 is a simple multiplier of (3.3), then there are an eo 0 and a neighborhood W of ' such that equation (3.1) has a periodic solution u\*(-, e) of period w\*(e), 0< lel < so, such that u\*(-, 0) = u(-), w\*(0) = to, u\*(t, e) and w\*(e) are continuous in t, a for t in R, 0 <\_ 1 81 <\_ so.

PROOF. Let -0. be the space of continuous w-periodic n-vector functions with the supremum norm. For any real number P, consider the transformation t = (1 + f)T in (3.1). If x(t) = y(T), then y satisfies the equation

(3.4) 
$$\frac{dy}{d\tau} = (1+\beta)[f(y) + F(y, \varepsilon)].$$

If (3.4) has a solution in go), then (3.1) has a solution in 9(1+,6)w. If y(r) \_ u(T) + z(T), then z satisfies the equation

(3.5) 
$$\frac{dz}{d\tau} = A(\tau)z + G(\tau, z, \varepsilon, \beta),$$

$$G(\tau, z, \varepsilon, \beta) = (1+\beta)[f(u+z) + F(u+z, \varepsilon)] - A(\tau)z - f(u).$$

Since 1 is a simple characteristic multiplier of (3.3), it follows that u is a basis for the w-periodic solutions of (3.3) and there is an w-periodic row vector 0 which is a basis for the w-periodic solutions of the system adjoint to (3.3). Also, it can be assumed that f o I Ii(t) 1 2 dt = 1. We now apply the preceding theory to determine w-periodic solutions of (3.5). For any h in 9Q, , let

$$\gamma(h) = \int_0^\omega \psi(t)h(t) dt.$$

From Section 2, for any h in Y, we know that the equation

$$rac{dz}{d au} = A( au)z + h( au) - \gamma(h)\psi'( au)$$

has a unique solution Iih in 9. such that f o u'(t),#h(t) dt = 0 and A": 9,,-\* 9w is a continuous linear operator. Let .°F: -0.--\* -0. be defined by

$$\mathcal{F}z = \mathcal{M}G(\cdot, z, \varepsilon, \beta).$$

In the usual way, one shows there are el > 0, fl, > 0, 8i > 0 such that ,F is uniformly contracting on 9.(0 ) = {z in Y.: 11:11 < SI}. Therefore, .F has a unique fixed point z\*(e, f) which is continuous in e, 9 and continuously differentiable in P. Also z\*(0, 0) = 0. This fixed point z\*(e, P) is a solution of

the relation

$$\begin{aligned} \frac{dz}{d\tau} &= A(\tau)z + G(\tau,\,z,\,\varepsilon,\,\beta) - B(\varepsilon,\,\beta)\psi'(\tau), \\ B(\varepsilon,\,\beta) &= \gamma(G(\tau,\,z^*\!(\varepsilon,\,\beta),\,\varepsilon,\,\beta)). \end{aligned}$$

The function B(e, 9) is continuous in E,,8 and satisfies B(0, 0) = 0. Also, since z\*(E, is continuously differentiable with respect to 6, it follows that B(E, 6) is continuously differentiable with respect to fi. Furthermore, one can conclude that 9B(e, fl)/816= f o O(T)ic(T) dT for e = 0, 9 = 0. This last integral must be different from zero for otherwise the equation

$$rac{dz}{d au} = A( au)z + \dot{u}( au)$$

would have a solution in 9.. This is impossible since this equation always has the solution z(T) = Tu(r). Since B(0, 0) = 0 and 0B(0, 0)/8P 0, the implicit function theorem implies the existence of a P \_,6(E) such that B(e, P(E)) = 0 for IEl < so. Thus, the function z\*(E, fl(e)) is an w-periodic solution of (3.1) and the theorem is proved.

## VIll.4. Remarks and Suggestions for Further Study

Poincare [2], in his famous treatise on celestial mechanics, was the first to describe a systematic method for the determination of periodic solutions of differential equations containing a small parameter. In 1940, Cesari [3] gave a method for determining characteristic exponents for linear periodic systems which is in the spirit of the presentation given in this chapter although different in detail. The method of Cesari was extended by Hale [1] and Gambill and Hale [1] to apply to periodic solutions of nonlinear differential equations with small parameters. Further modifications of this basic method by Cesari [3] and [5] led to the presentation given in this chapter. Concurrent with this development, Friedrichs [1], Lewis [1] and Bass [1, 2] gave methods which are very closely related to the above.

Exercise 1.3 is due to Reuter [1]; Exercises 1.5 and 1.6 to Hale [6]; Exercise 1.15 to Hale [7]; Exercise 1.17 to Bailey and Cesari [1]. The Hopf bifurcation theorem was first stated by Hopf [1] although the phenomena was known to marry people (see, for example, Poincare: [2], Minorsky [1], [2]). For a recent book on Hopf bifurcation, see Marsden and MacCracken [1]. The result is also known for equations with delays (see Hale [10]). Exercises 1.22 through 1.27 are in the spirit of bifurcation problems discussed from the general point of view. An extensive literature is available (see, for example, Andronov,

Leontovich, Gordon and Maier [ 1 ], Sotomayor [ 1 ], Newhouse [ 1 ] ). Except for notational changes, Lemma 2.3 is due to Lewis [1]. A less general form of property (E) of Section 2 is given by Hale [7]. Theorem 2.3 was.stated by Lewis in [1]. Exercises 2.7 and 2.8 are special cases of'results by Hale [2]. Exercise 2.9 is due to Lyapunov [1] for analytic systems. Exercise 2.10 is due to Bogoliubov and S`adovnikov [1] while Exercises 2.11 and 2.12 to Golomb [1 ]. The treatment of Duffmg's equation in Section 2 follows Hale and Rodrigues [1]. For the case where damping is also considered, see Hale and Rodrigues [2]. The discussion of periodic solutions near a periodic orbit in Section 2 follows Hale and Taboas [1] (see also Loud [2]). For the case where hypothesis (HI) is violated, see Hale and Taboas [2]. For an abstract version of this problem, see Hale [11].

An interesting extension of the idea of periodicity as well as property (E) is contained in the theory of autosynartetic solutions of differential equations of Lewis [2]. For small perturbations of nonlinear second order equations see Loud [1].

## CHAPTER IX

## Alternative Problems for the Solution of

## Functional Equations

To motivate the discussion in this chapter, let us interpret the procedure of the previous chapter in a more general setting. Let °. AT be the Banach space of T-periodic n-vector functions with the supremum norm; let A be an n x n matrix whose columns are in 9'T; let L be the linear operator defined on continuously differentiable functions in 9T by (Lx)(t) = i(t) -A (t)x(t); let N: 91T - 91T be defined by (Nx)(t) = Ef (t, x(t)) where f is a continuously differentiable function of x and T-periodic in t. The problem of finding a solution of the differential equation

$$\dot{x} - A(t)x = \varepsilon f(t, x)$$

in YT is then equivalent to finding an x in PT which is in the domain of L such that Lx = Nx. With P, Q, A' defined as in relation (VIII.2.5) and Lemma VIII.2.1, the Lemma VIII.2.2 asserts that the equation Lx = Nx is equivalent to the equations

(1) (a) 
$$x = Px + \mathcal{K}(I - Q)Nx$$
  
(b)  $QNx = 0$ .

Equations (1) have a distinct advantage over the original differential equation. In fact, for N " small " and a fixed xo with Pxo = xo, one can determine a solution x\*(xo) of (la) such that Px\*(xo) = xo. The existence of a solution of Lx = Nx is then equivalent to the determination of an xo such that QNx\*(xo) = 0. We have referred to the equations for xo as the determining or bifurcation equations, but, more appropriately, we are going to say that these equations represent an alternative problem for Lx = Nx.

It is the purpose of this chapter to determine larger classes of equations which are equivalent to Lx = Nx for x in a Banach space and then specify alternative problems when N is not necessarily small. This general approach is taken because the ideas are applicable to problems in fields other than ordinary differential equations; for example, integral equations, functional differential equations and partial differential equations. However, our applications are confined to ordinary differential equations.

## IX.1. Equivalent Equations

If X, Z are Banach spaces and B is an operator which takes a subset of X into Z, we let 1(B), c(B), .K(B) denote the domain, range and null space respectively of B. If E is a projection operator defined on a Banach space Z we denote AP(E) by ZE and ZE will always denote a subspace which is obtained through a projection operator E in this way. The symbol I will denote the identity. If L: -9(L) c X Z is a linear operator, then K is said to be a bounded right inverse of L if K is a bounded linear operator taking 3P(L) onto -9(L) and LKz = z for z in GP(L).

Let X, Z be Banach spaces; let N: X --> Z be an operator which may be linear or nonlinear; let L: -9(L) c X -\* Z be a linear operator which may have a nontrivial null space and may have range deficient in Z.

LEMMA 1.1. Suppose .N'(L) and AP(L) admit projections, .N'(L) = Xp, A(L) = ZI\_Q and suppose L has a bounded right inverse K with PK = 0. The equation

$$(1.1) Lx = Nx$$

is equivalent to the equations

(1.2) (a) 
$$x = Px + K(I - Q)Nx$$
,  
(b)  $QNx = 0$ .

PROOF. Equation (1.1) is clearly equivalent to the equations

(1.3) (a) 
$$(I-Q)(Lx-Nx) = 0,$$
  
(b)  $Q(Lx-Nx) = 0.$ 

Since LX = (I -Q)Z and Q is a projection, QL = 0. Therefore, (1.3b) is equivalent to (1.2b) and (1.3a) is equivalent to Lx = (I -Q)Nx. Since (I - Q)Nx belongs to the range of L and K is a bounded right inverse of L, this latter equation is equivalent to x = xo + K(I - Q)Nx where xo is in .K(L). But, PK = 0 implies x0 = Px and the lemma is proved.

The condition PK = 0 in Lemma 1.1 is no restriction. In fact, if M is any bounded right inverse of L, then K = (I - P)M is also a bounded right inverse and PK = 0.

Even with these few elementary remarks, one is in a position to state some alternative problems for (1.1). More specifically, if N were small

enough in some sphere so that the contraction principle is applicable to (1.2a) with Px = xo fixed, then (1.2a) can be solved for an x\*(xo) and an alternative problem for (1.1) is QNx\*(xo) = 0.

In other words, one can fix an arbitrary element xo of .N'(L), solve (1.2a) for x\*(xo) and try to determine xo so that (1.2b) is satisfied. The alternative problem has the same "dimension" as the null space of L. In many cases, this dimension is finite whereas the original equation Lx - Nx is infinite dimensional. This result will be stated precisely in the next section, but now we want to obtain other sets of equations which are equivalent to (1.1) and at the same time permit the discussion of cases when N is not small. The idea is quite simple. If one wishes to apply the contraction principle to (1.2a), then K(I - Q)N must be small in some sense. However, if N is large on the whole space, then one should be able to make the product small by choosing the projection operator Q so that fewer values of x are being considered. This is the idea which now will be made precise.

The accompanying Fig. 1 is useful in visualizing the next lemma.

![](_page_309_Figure_5.jpeg)

LEMMA 1.2. Suppose P, Q, K are as in Lemma 1.1 and let S be any projection operator on X such that Xs c M(K), SP = 0. The following conclusions are then valid:

- (i) P = P + S is a projection operator.
- (ii) The preimage in ZI\_Q under K of Xs, XI\_Pn21(L) induces a projection J: ZI\_Q -- ZI\_Q. If Xs = KZJ(I\_Q), let I - Q = (I - J)(I - Q). Then Q: Z-\* Z is a projection and XI\_pn 21(L) = K(ZI\_Q).

(iii) For any x in  $\mathcal{D}(L)$ ,

$$(1.4) x = K(I - \tilde{Q})Lx + \tilde{P}x.$$

(iv) 
$$\tilde{Q}L = L\tilde{P}$$
.

PROOF. (i) Since  $\mathcal{R}(S) \subset \mathcal{R}(K)$  and PK = 0 it follows that PS = 0. A direct computation now shows that  $\tilde{P} = P + S$  is a projection.

- (ii) K is a one-to-one map of  $Z_{I-Q}$  onto  $X_{I-P}\cap \mathcal{D}(L)$  since  $Kz_1=Kz_2$  implies  $K(z_1-z_2)=0$  and  $0=LK(z_1-z_2)=z_1-z_2$ . If  $Z_1,\ Z_2$  are the primages under K of  $X_S,\ X_{I-\tilde{P}}\cap \mathcal{D}(L)$ , respectively, then  $Z_1\cap Z_2=\{0\}$  and  $Z_{I-Q}=Z_1\oplus Z_2$ . If  $z_n\in Z_2,\ z_n\to z$  as  $n\to\infty$ , then  $Kz_n\to Kz$  as  $n\to\infty$  since K is continuous. Furthermore, there are  $x_n\in X_{I-\tilde{P}}\cap \mathcal{D}(L)$  and  $x\in \mathcal{D}(L)$  such that  $Kz_n=x_n$ , Kz=x. Since  $x_n\to x$  and  $X_{I-\tilde{P}}$  is closed, we have  $x\in X_{I-\tilde{P}}$ . Thus  $x\in X_{I-\tilde{P}}\cap \mathcal{D}(L)$  and  $Z_2$  is closed. In the same way or using the fact that  $X_S$  is closed and K is continuous, one sees that  $Z_1$  is closed. Therefore, a projection J is induced on  $Z_{I-Q}$ . If we let  $X_S=KZ_{J(I-Q)}$  and  $I-\tilde{Q}=(I-J)(I-Q)$  and use the fact that (I-Q)(I-J)=(I-J), it is it is clear that I-Q is a projection. Since  $X_S=KZ_{J(I-Q)}$ , it is also obvious that  $X_{I-\tilde{P}}\cap \mathcal{D}(L)=KZ_{I-\tilde{Q}}$ .
  - (iii) For any x in  $\mathcal{D}(L)$ , x = KLx + Px. Since  $\tilde{Q}$  is a projection operator,

$$(1.5) x = K(I - \tilde{Q})Lx + K\tilde{Q}Lx + Px.$$

From property (ii),  $K(I-\tilde{Q})Lx$  belongs to  $X_{I-S}$  since  $X_{I-\tilde{P}}\subset X_{I-S}$ . Also, a direct computation shows that  $\tilde{Q}(I-Q)=J(I-Q)$  and, therefore,  $K\tilde{Q}Lx=K\tilde{Q}(I-Q)Lx$  belongs to  $X_S$ . Operating on (1.5) with S and using the fact that SP=0, we obtain  $Sx=SK\tilde{Q}Lx=K\tilde{Q}Lx$ . Since  $\tilde{P}=P+S$ , this proves relation (iii).

(iv) Applying L to (1.4) and using the fact that K is a right inverse for L, we have  $Lx = (I - \tilde{Q})Lx + L\tilde{P}x$ . Therefore, property (iv) is satisfied.

This completes the proof of the lemma.

LEMMA 1.3. Suppose X, Z are Banach spaces,  $L: \mathcal{D}(L) \subset X \to Z$  is a linear operator with  $\mathcal{R}(L)$ ,  $\mathcal{N}(L)$  admitting projections by I-Q, P, respectively, L has a bounded right inverse K, PK=0, and  $\tilde{P}, \tilde{Q}$  are the operators defined in Lemma 1.2. For any operator  $N: X \to Z$ , the equation Lx - Nx = 0 has a solution if and only if

(1.6) (a) 
$$x = \tilde{P}x + K(I - \tilde{Q})Nx$$
,  
(b)  $\tilde{Q}(Lx - Nx) = 0$ .

PROOF. With  $\tilde{P}$ ,  $\tilde{Q}$  as in Lemma 1.2, the equation Lx - Nx = 0 is equivalent to the equations  $\tilde{Q}(Lx - Nx) = 0$ ,  $(I - \tilde{Q})(Lx - Nx) = 0$ . If  $(I - \tilde{Q})(Lx - Nx) = 0$ , then relation (1.4) implies that  $K(I - \tilde{Q})Nx = 0$ 

K(I - Q)Lx = (I - P)x and, thus, (1.6a) is satisfied. If Lx - Nx = 0, then (1.6b). is automatically satisfied. Conversely, if (1.6a) is satisfied, then L(I - P)x = (I - Q)Nx. Since relation (iv) of Lemma 1.2 is satisfied, this implies (I - Q)(Lx - Nx) = 0. If (1.6b) is also satisfied, then Lx - Nx = 0. This proves the lemma.

### IX.2. A Generalization

As we have seen in Lemma 1.3, the geometric Lemma 1.3 permits the establishment of many sets of equations which are equivalent to equation (1.1). Some assumptions on the linear operator L were imposed in order to obtain these results. However, once the basic relations between the operators P, Q are obtained, one can give an abstract formulation of the basic processes involved. To do this, let X, Z be Banach spaces; let N: 21 (N) c X - - Z be an operator which may be linear or nonlinear; let L: 21(L) c X -\* Z be a linear operator and let F = L - N. A solution of Fx = 0 will be required to belong to 21(L) n °1(N). The following hypotheses are made:

H1: There are projection operators P: X -- X, Q: Z -\* Z such that QL = LP.

H2: There is a linear map K: ZI\_Q - XI- p such that

- (i) K(I -Q)Lx = (I P)x, x in 2' (L),
- (ii) LK(I f )Nx = (I ()Nx, x in 21 (N).

H3: All fixed points of the operator A =P + K(I - Q)N belong to 21(L) n 2(N).

For the operators L, N satisfying the hypotheses of Lemma 1.3, it was demonstrated that the hypotheses H1-H3 can be satisfied by a large class of operators P, Q. In fact, hypothesis H1 is just relation (iv) of Lemma 1.2 and the operators P, Q depend upon a rather arbitrary subspace of X. Hypothesis H2 (ii) corresponds to the existence of a right inverse of L. Hypothesis H2 (i) is relation (1.4) of Lemma 1.2. Hypotheses H3 was automatically satisfied for the particular P, Q constructed and the bounded right inverse considered. If L, N are, as specified above and K, P, Q exist so that H1-H3 are satisfied, then it is not true that P, Q can be obtained by the construction of Lemma 1.2. In fact, in that construction it was assumed that L had a bounded right inverse and AP(L), X (L) admitted projections. There is no way to deduce these properties from H1-H3. Of course, in the applications, Lemma 1.2 is a rather natural way to obtain P, Q.

LEMMA 2.1. If hypotheses H1-H3. are satisfied, then the equation Fx = 0 has a solution x in 21(L) n 21(N) if and only if

(2.1) (a) 
$$x = \Delta x \stackrel{\text{def}}{=} \tilde{P}x + K(I - \tilde{Q})Nx$$
,

(b) QFx=0.

PROOF. The relation Fx = 0 implies QFx = 0, (I - Q)Fx = 0. Therefore, (I - Q)Lx = (I - Q)Nx and hypothesis H2 (i) implies

$$K(I-\tilde{Q})Nx = K(I-\tilde{Q})Lx = (I-\tilde{P})x.$$

Thus, x = Ax. Conversely, suppose (2.1) is satisfied. If x = Ax, then (I - P)x = K(I - Q)Nx. Hypothesis H3 implies x in .9(L) n -q(N) and H2 (ii) implies that

$$L(I-\tilde{P})x = LK(I-\tilde{Q})Nx = (I-\tilde{Q})Nx.$$

But this fact together with Hl implies that (I - Q)Fx = 0. By hypothesis, QFx = 0 and the lemma is proved.

### IX.3. Alternative Problems

In addition to the hypotheses Hl-H3 imposed on the operators P, Q, K, L, N of the previous section, we also suppose -q(N) = X and

H4: There exist a constant p. and a continuous nondecreasing function a(p), 0< p < oo such that

$$|K(I- ilde{Q})Nx_1 - K(I- ilde{Q})Nx_2| \le lpha(
ho)|x_1 - x_2|,$$
  $|K(I- ilde{Q})Nx_1| \le lpha(
ho)|x_1| + \mu \quad ext{for} \quad |x_1|, |x_2| < 
ho.$ 

For any positive constants c, d with c < d, let

(3.1) (a) 
$$V(c) = \{x \text{ in } X_{\tilde{P}} : |x| \leq c\}.$$

(b) 
$$\mathscr{S}(\tilde{x}, c, d) = \{x \text{ in } X \colon \tilde{P}x = \tilde{x}, \, \tilde{x} \text{ in } V(c), \, |x| \leq d\}.$$

where x" is a fixed element of V(c).

THEOREM 3.1. Suppose !2(N) = X, V(c), Y(x, c, d), c <d, are defined by (3.1), the hypotheses Hl-H3 of the previous section and hypothesis H4 above are satisfied with a(d) < 1, a(d) d < d - c - p.. Then there exists a unique continuous function 0: V(c) -±X, Gx in Y(x, c, d) such that Gx satisfies the equation

$$(3.2) x = \Delta x \stackrel{\text{def}}{=} \tilde{P}x + K(I - \tilde{Q})Nx.$$

If there is an x in V(c) such that

$$\tilde{Q}FG\tilde{x}=0,$$

then FGx = 0. Conversely, if there is an x such that Fx = 0, jxj < d, Pxj < c, then x = GPx and :Z = Px is a solution of (3.3).

PROOF. For any 2 in V (c) and x in X, let H(x, x) = x + K(I - Q)Nx. For any x in 9(2, c, d), PH(x, x) = 2,

$$|H(x, \tilde{x})| \leq c + \alpha(d)|x| + \mu \leq c + \alpha(d) d + \mu < d,$$

and

$$|H(x_1, \tilde{x}) - H(x_2, \tilde{x})| \leq \alpha(d)|x_1 - x_2|.$$

Therefore, H(, x): ,°(x`, c, d) -\* 6'(x, c,d) is a contraction and there is a unique fixed point Gx of H(, x) in 9(x, c, d). The function G is obviously continuous and satisfies (3.2) since x = P2. If x satisfies (3.3), then Lemma 2.1 implies that FGx = 0.

Conversely, if x is a solution of Fx = 0, x = Px, jxj < d, 1x1 < c, then Lemma 2.1 implies that x = Ax and QFx = 0. But the proof of the first part of the lemma showed that A had a unique fixed point with Px = x. Therefore, the solution x of Fx = 0 must satisfy x = Gx, x = Px. Since x must also satisfy QFx = 0, it follows that x satisfies (3.3). This completes the proof of the theorem.

In the sense of Theorem 3.1, finding a solution x in V(c) of (3.3) is equivalent to finding a solution of equation (1.11 with jxj < d, jPxl < c. Therefore, we refer to equation (3.3) as an alternative problem for equation (1.1).

### IX.4. Alternative Problems for Periodic Solutions

In this section, we go into some detail on the construction and more detailed meaning of alternative problems in connection with the existence of periodic solutions of ordinary differential equations.

Suppose g: (-oo, oo) X Cn-\*Cn is continuous, g(t, u) is locally lipschitzian in u, g(t, u) = g(t + 27r, u) for all t e (- oo, oo), u e C. Our problem is the determination of 21r-periodic solutions of the equation

$$\dot{u} = g(t, u).$$

Let us reformulate this problem in terms of our previous notation.

Let Y be the Banach space of continuous functions taking [0, 2ir] into Cn with the uniform norm and let B: 21(B) c Y-\* Y be the linear operator whose domain -9 (B) = {y e Y such that y e Y} and By(t) = y(t), 0 < t < 2ir, for y e .9(B). Let M: Y - Y be the operator defined by (My)(t) = g(t, y(t)), 0 < t <21r, y e Y; P: Y-\*Cn be the bounded linear operator defined by Py = y (0) - y(27r), y e Y. Finding a 21r-periodic solution of (4.1)i s now equivalent to solving the boundary value problem

(4.2) 
$$By = My,$$
$$\Gamma y = 0, \quad y \in Y.$$

If  $X = \mathcal{N}(\Gamma)$  and L, N are the restrictions of B, M to X, then the boundary value problem (4.2) is equivalent to finding a solution of the equation

$$(4.3) Lx = Nx, x \in X.$$

Let  $P: X \to X$  be the projection operator defined by

(4.4) 
$$Px = \frac{1}{2\pi} \int_{0}^{2\pi} x(t) dt;$$

that is, Px is the mean value of the  $2\pi$ -periodic function x in X. With this notation,  $\mathcal{N}(L) = X_P = \{\text{all constant functions in } X\}$ ,  $\mathcal{R}(L) = X_{I-P} = \{\text{all } 2\pi$ -periodic functions with mean value zero}. Therefore, the operator Q in Section 1 is P. If  $z \in X_{I-P}$ , then the equation  $Lx(t) = \dot{x}(t) = z(t)$  has a solution in X and a unique solution with mean value zero which depends continuously upon z. If we designate this solution by Kz, then  $K: X_{I-P} \to X_{I-P}$ , PK = 0, and K is a bounded right inverse of L.

Any x in X has a Fourier series

(4.5) 
$$x \sim \sum_{k=-\infty}^{\infty} a_k e^{ikt}, \qquad a_k = \frac{1}{2\pi} \int_0^{2\pi} e^{-ikt} x(t) dt.$$

For any given integer m > 0, let  $S_m: X \to X$  be defined by

$$S_m x = \sum_{0 < |k| < m} a_k e^{ikt}.$$

One easily checks that  $S_m$  is a projection operator and Lemma 1.2 implies  $\tilde{P}_m$ ,  $\tilde{Q}_m$  of that lemma are given by  $\tilde{P}_m = P + S_m$ ,  $\tilde{Q}_m = \tilde{P}_m$ . Equation (4.3) is then equivalent to the equations

(4.6) 
$$(a) \quad x = \tilde{P}_m x + K(I - \tilde{P}_m) Nx,$$

(b) 
$$\tilde{P}_m(Lx-Nx)=0$$
,

for every integer  $m \ge 0$ .

From the definitions of  $\tilde{P}_m$ , K and the form of x in (4.5),

$$K(I-\tilde{P}_m)x(t) = \sum_{|k|>m} \frac{a_k}{ik} e^{ikt}.$$

Recall that Parseval's relation implies that  $\int_0^{2\pi} |x(t)|^2 dt = \sum_{k=-\infty}^{\infty} |a_k|^2$ . Since

$$\begin{split} \sum_{|k|>m} \left| \frac{a_k}{k} \right| &\leq \left( \sum_{|k|>m} |a_k|^2 \right)^{1/2} \left( \sum_{|k|>m} \frac{1}{k^2} \right)^{1/2} \\ &\leq \left( \int_0^{2\pi} |x(t)|^2 dt \right)^{1/2} \left( \sum_{|k|>m} \frac{1}{k^2} \right)^{1/2} \\ &\leq (2\pi)^{1/2} \left( \sum_{|k|>m} \frac{1}{k^2} \right)^{1/2} |x| \\ &\stackrel{\text{def}}{=} \gamma(m) |x|, \end{split}$$

it follows that the Fourier series for K(I - Pm)x(t) is absolutely convergent and

$$|K(I - \tilde{P}_m)x| \le \gamma(m)|x|$$

or all x e X.\* Note that y(m) -+0 as m -- - oo since the series \_k k\_2 < oo.

Since g(t, u) is assumed to be locally lipschitzian in u, there is a constant v > 0 and a continuous nondecreasing function fl(p), 0 < p < oo, such that Nx(t) = g(t, x(t)) satisfies

$$|Nx_1 - Nx_2| \le eta(
ho)|x_1 - x_2|$$
  $|Nx_1| \le eta(
ho)|x_1| + 
u$ 

for all Ixll < p, Ix2I < p.

For any constant d > 0 and any m, it follows that

$$|K(I-P_m)(Nx_1-Nx_2)| \le \gamma(m)\beta(d)|x_1-x_2|$$
  
 $|K(I-P_m)Nx_1| \le \gamma(m)\beta(d)|x_1| + \gamma(m)\nu$ 

for all I xl I < d, Ix2I < d. Suppose 0 < c < d are arbitrary constants and m is chosen so large that

$$\gamma(m)\beta(d) < 1, \qquad \gamma(m)\beta(d) \ d + \gamma(m)\nu < d - c$$

The operator A defined by (3.2) is then a contraction mapping of the set .°(x, c, d) in (3.1) into itself. This implies that the equation

$$(4.7) x = \tilde{x} + K(I - \tilde{P}_m)Nx$$

has a solution G z f o r every x e {x in X : Ixi < c}. An alternative problem for (4.1) is then the equation

$$\tilde{P}_m(L-N)G\tilde{x}=0.$$

In words, the existence of this alternative problem implies the following. If (4.1) is to have a 21r-periodic solution u, then all of the Fourier coefficients of the function v(t) =,&(t) - g(t, u(t)) must be zero. Let

$$u(t) = u_m(t) + u_m^*(t),$$
 $u_m(t) = \sum_{|k| \le m} a_k e^{ikt},$ 
 $u_m^*(t) = \sum_{|k| > m} a_k e^{ikt}.$ 

The above remarks imply there is always an integer m such that one can fix x = um and determine Gx = u\*m(uyn) in such a way that the Fourier series for v(t) contains only the harmonics e{kt, I kI < m (this is the meaning of the solution Gii of (4.6a)). The alternative problem then involves the determination of u. (t) in such a way that the remaining Fourier coefficients of v(t) vanish.

There are two serious questions remaining concerning the determination of periodic solutions of (4.1) by this method. First, the size of the finite dimensional problem cannot be determined a priori but involves very careful estimates of the norm of the operator K(I - Pm). Also, the finite dimensional problem (4.8) involves a function G which is only implicitly known and trying to assert the actual existence of an x is extremely difficult.

In fact, one cannot hope to solve (4.7) directly, but must use some approximation scheme. Let us write Gx = x + y" where y" is in (I - Pm)X and is given by y = K(I - Pm)NGx. It is impossible to determine y, but if the existence of Gx is proved by the contraction principle, then one has obtained a priori estimates on y" as

$$(4.9) |\tilde{y}| \leq \delta_m,$$

for some constant Sm . The alternative problem (4.8) will certainly have a solution if one can show that the equation

$$\tilde{P}_{m}(L-N)(\tilde{x}+\tilde{y})=0$$

has a solution x for every given y which satisfies the bounds (4.9). To show this latter property, one would naturally look first at the approximate equation obtained by setting y" = 0; namely,

$$(4.11) \tilde{P}_m(L-N)\tilde{x} = 0.$$

Equation (4.11)'is the mth Galerkin approximation for the solution of Lx = Nx. Methods for the determination of explicit solutions of (4.11) and for showing that (4.10) has a solution for every y satisfying (4.9) would take us too far afield. The interested reader may consult the references for the practical applicability of this method.

## IX.5. The Perron-Lettenmeyer Theorem

In this section, we illustrate how the techniques of Sections 1 and 3 can be used to give a proof of a theorem of Perron and Lettenmeyer concerning the number of analytic solutions of a system of linear differential equations of the form

(5.1) 
$$t^{\sigma_j}\dot{x}_j = N_j(t)x, \qquad j = 1, 2, \ldots, n,$$

where x = col(xl, ... , xn), Ng = row(Njl, ... , Npn), the N1k(t) are analytic for I t S, S > 0, and each of is a nonnegative integer.

THEOREM 5.1. If µ = n - \_la1 Z 0, then there are at least p linearly independent solutions of (5.1) which are analytic for Itl < S.

PROOF. Let  $\mathscr{B}$  be the set of all scalar functions which are analytic for  $|t| \leq \delta$ . If b is in  $\mathscr{B}$ , then  $b(t) = \sum_{m=0}^{\infty} b_m t^m$  and we define  $|b| = \sum_{m=0}^{\infty} |b_m| \delta^m$ . The function  $|\cdot|$  is a norm on  $\mathscr{B}$  and  $\mathscr{B}$  is a Banach space. For any nonnegative integer  $\sigma$ , let  $l_{\sigma}: \mathscr{B} \to \mathscr{B}$  be the linear operator defined by

$$(5.2) l_{\sigma}b(t) = t^{\sigma}db(t)/dt.$$

It is clear that

$$\mathcal{N}(l_{\sigma}) = \{ ext{constant functions in } \mathscr{B} \},$$
  
 $\mathscr{B}(l_{\sigma}) = \{ c \text{ in } \mathscr{B} : c = t^{\sigma}b, b \text{ in } \mathscr{B} \}.$ 

If the projection operators p,  $q_{\sigma}$  on  $\mathscr{B}$  are defined by

(5.3) 
$$pb = b_0, q_{\sigma}b = \sum_{m=0}^{\sigma-1} b_m t^m,$$

then p,  $1-q_{\sigma}$  are projections onto  $\mathcal{N}(l_{\sigma})$ ,  $\mathcal{R}(l_{\sigma})$ , respectively. The right inverse  $k_{\sigma}$  of  $l_{\sigma}$  on  $\mathcal{R}(l_{\sigma})$  such that  $pk_{\sigma}=0$  is given by

(5.4) 
$$k_{\sigma}(1-q_{\sigma})b(t) = \sum_{m=0}^{\infty} \frac{b_{m+\sigma}}{m+1} t^{m+1},$$

and  $|k_{\sigma}(1-q_{\sigma})b| \leq \delta^{1-\sigma}|(1-q_{\sigma})b|$ . This proves  $k_{\sigma}$  is continuous.

Let X be the Banach space which is the cross product of n copies of  $\mathcal{B}$  with  $|x|_X = \max_j |x_j|_{\mathcal{B}}$ ,  $x = \operatorname{col}(x_1, \ldots, x_n)$ ,  $x_j$  in  $\mathcal{B}$ . We write |x| for  $|x|_X$  since no confusion will arise. Let  $\sigma_1, \ldots, \sigma_n$  be the nonnegative integers in (5.1),  $\sigma = (\sigma_1, \ldots, \sigma_n)$  and define operators  $L_{\sigma}$ , P,  $Q_{\sigma}$ ,  $K_{\sigma}$ , N by

(5.5) 
$$L_{\sigma}x = \operatorname{col}(l_{\sigma_{1}}x_{1}, \ldots, l_{\sigma_{n}}x_{n}),$$

$$Px = \operatorname{col}(px_{1}, \ldots, px_{n}),$$

$$Q_{\sigma}x = \operatorname{col}(q_{\sigma_{1}}x_{1}, \ldots, q_{\sigma_{n}}x_{n}),$$

$$K_{\sigma}x = \operatorname{col}(k_{\sigma_{1}}x_{1}, \ldots, k_{\sigma_{n}}x_{n}),$$

$$Nx = \operatorname{col}(N_{1}x, \ldots, N_{n}x),$$

where the  $l_{\sigma_j}$  are defined by (5.2), the  $p, q_{\sigma_j}$  by (5.3),  $k_{\sigma_j}$  by (5.4), and  $N_j x$  in (5.1). Equation (5.1) may now be written as

$$(5.6) L_{\sigma} x = Nx, x \text{ in } X,$$

and from Lemma 1.1 is equivalent to the linear equations

(5.7) 
$$x = Px + K_{\sigma}(I - Q_{\sigma})Nx,$$
$$Q_{\sigma}Nx = 0, \qquad x \text{ in } X.$$

If the linear operator  $K_{\sigma}(I-Q_{\sigma})N$  were a contraction operator, then one could fix a constant n-vector  $x_0$  and determine a unique solution  $x^* = x^*(x_0)$ ,

 $Px^* = x_0$ , of the equation  $x = x_0 + K_\sigma(I - Q_\sigma)Nx$ . Equations (5.7) would then have a solution if and only if  $x_0$  satisfied the equations  $Q_\sigma Nx^*(x_0) = 0$ . It is clear that such an  $x^*(x_0)$  is linear in  $x_0$ . Thus there would be  $\sum_{j=1}^n \sigma_j$  homogeneous linear equations for n unknown scalars (the components of  $x_0$ ) and, therefore  $n - \sum_{j=1}^n \sigma_j$  solutions of (5.7). This explains the possible appearance of  $\mu$  in the statement of the theorem except for the fact that the operator  $K_\sigma(I - Q_\sigma)N$  may not be contracting. On the other hand, there is a natural way to use Lemma 1.2 to circumvent this difficulty.

For any given nonnegative integer r, let  $\tilde{P} = P_{r+1}$  be the projection operator on X which takes each component of x in X into the polynomial of degree r consisting of the first (r+1) terms of its power series expansion. The operator  $\tilde{Q}$  in Lemma 1.2 is easily seen to be  $Q_{r+\sigma}$ ,  $r+\sigma=\operatorname{col}(r+\sigma_1,\ldots,r+\sigma_n)$ . Thus, Lemma 1.3 implies that (5.6) is equivalent to the equations

$$(5.8) x = P_{r+1}x + K_{\sigma}(I - Q_{r+\sigma})Nx,$$
 
$$Q_{r+\sigma}(L_{\sigma} - N)x = 0.$$

Furthermore from the definition of  $K_{\sigma}$ , it follows immediately that there is a  $\beta>0$  independent of r such that  $|K_{\sigma}(I-Q_{r+\sigma})Nx| \leq \beta|x|/(r+1)$  for all x in X. Consequently, the operator  $K(I-Q_{r+\sigma})N$  is contracting for r sufficiently large. Finally, fixing an n-vector polynomial f (t) of degree r, one can determine a unique solution  $x^*=x^*(f)$  of  $x=f+K_{\sigma}(I-Q_{r+\sigma})Nx$  which is linear and continuous in f. Therefore, the equations (5.8) have a solution if and only if f satisfies  $Q_{r+\sigma}(L_{\sigma}-N)x^*(f)=0$ . These represent  $nr+\sum_{j=1}^n\sigma_j$  homogeneous linear equations for the n(r+1) coefficients of the polynomial f. Therefore there are always  $\mu=n-\sum_{j=1}^n\sigma_j$  solutions. This proves the theorem.

If all  $\sigma_j - 1$  in (5.1), the equation is said to have a regular singular point at t = 0. In this case, the above theorem says nothing.

## XI.6. Remarks and Suggestions for Further Study

For the case in which  $\tilde{P}=P$ ,  $\tilde{Q}=Q$  and N in (1.1) is small and has a small lipschitz constant, Theorem 3.1 has appeared either explicitly or implicitly in many papers; in particular, Cesari [5, 6], Cronin [1], Bartle [1], Graves [1], Nirenberg [1], Vainberg and Tregonin [1], Antosiewicz [1]. However, Cesari [5, 6] injected a significant new idea when he observed that finite dimensional alternative problems could always be associated with certain types of equations (1.1) even when the nonlinearities N are not small. The construction of  $\tilde{P}$ ,  $\tilde{Q}$  given in Section 1 follows Bancroft, Hale and

Sweet [1] and was motivated by Cesari [6]. The abstract formulation in Section 2 was independently discovered by Locker [1] proceeding along the lines of Section 4.

Cesari has applied the methods of Section 4 to prove in [5] the existence and bound of a 27r-periodic solution of

$$\ddot{x} + x^3 = \sin t$$

by using the second Galerkin approximation x = a sin t + b sin 3t and to show in [6] that the boundary value problem

$$\ddot{x} + x + \alpha x^3 = \beta t, \qquad 0 \le t \le 1,$$
  $x(0) = 0, \qquad x(1) + \dot{x}(1) = 0,$ 

has a solution by using the first Galerkin approximation. Borges [1] has applied the same process to obtain the existence and bounds for periodic solutions of nonlinear (periodic or autonomous) second order differential equations by using only the first Galerkin procedure. Knobloch [1, 2] has also used the method for existence of periodic solutions of second order equations. The papers of Urabe [2] discuss similar procedures for multipoint boundary value problems. Williams [1 ] has discovered interesting connections between Section 4 and the Leray-Schauder degree when the alternative problem is finite dimensional.

When N is small enough to make K(I - Q)N a contraction operator on some subset of the basic space X, Theorem 3.1 is applicable to hyperbolic partial differential equations; see Cesari [7], Hale [9], Rabinowitz [1], Hall [1]. Cesari [8] has also obtained results for elliptic partial differential equations. For applications to functional differential equations, see Perello [1, 2] and to integral equations, see Vainberg and Tregonin [1].

The idea for the proof of the Perron-Lettenmeyer Theorem of Section 5 was communicated to the author by Sibuya. Amplifications of this idea appear in Harris, Sibuya and Weinberg [1]. A paper which is not unrelated to the approach of this chapter is the paper of McGarvey [I] on asymptotic solutions of linear equations with periodic coefficients.

#### CHAPTER X

## The Direct Method of Liapunov

In the previous chapters, we have repeatedly asserted the stability of certain solutions or sets of solutions of a differential equation. The proofs of these results in most cases were based upon an application of the variation of constants formula, and, as a consequence, the analysis was confined to a small neighborhood of the solution or set under discussion. In his famous memoir, Liapunov gave some very simple geometric theorems (generally referred to as the direct method of Liapunov) for deciding the stability or instability of an equilibrium point of a differential equation. The idea is a generalization of the concept of energy and its power and usefulness lie in the fact that the decision is made by investigating the differential equation itself and not by finding solutions of the differential equation. These basic ideas of Liapunov have been exploited extensively with many books in the references being devoted entirely to this subject. The purpose of the present chapter is to give an introduction to some of the fundamental ideas and problems in this field. There is also one section devoted to a generalization known as the principle of Wazewski.

## X.1. Sufficient Conditions for Stability and Instability in Autonomous Systems

Let  $\Omega \subset \mathbb{R}^n$  be an open set in  $\mathbb{R}^n$  with 0 in  $\Omega$ . A scalar function V(x), x in  $\Omega$ , is positive semidefinite on  $\Omega$  if it is continuous on  $\Omega$  and  $V(x) \geq 0$ , x in  $\Omega$ . A scalar function V(x) is positive definite on  $\Omega$  if it is positive semidefinite, V(0) = 0, V(x) > 0,  $x \neq 0$ . A scalar function V(x) is negative semidefinite (negative definite) on  $\Omega$  if -V(x) is positive semidefinite (positive definite) on  $\Omega$ .

The function  $V(x_1, x_2) = x_1^2 + x_2^2$  is positive definite on  $R^2$ ,  $V(x_1, x_2) = x_1^2 + x_2^2 - x_2^3$  is positive definite on a sufficiently small strip about the  $x_1$ -axis,  $V(x_1, x_2) = x_2^2 + x_1^2/(1 + x_1^4)$  is positive definite on  $R^2$ . In each of these cases, there is a  $c_0 > 0$  such that  $\{(x_1, x_2): V(x_1, x_2) = c\}$  is a closed curve for every nonnegative constant  $c \le c_0$ . Near  $(x_1, x_2) = (0, 0)$ , each of these functions have the qualitative properties depicted in Fig. 1.1. Any positive definite

function in  $\mathbb{R}^n$  has some of these same qualitative properties, but a precise characterization of the level curves of V has not yet been solved. However, the following lemma holds.

LEMMA 1.1. If V is positive definite on  $\Omega$ , then there is a neighborhood U of x=0 and a constant  $c_0>0$  such that any continuous curve from the origin to  $\partial U$  must intersect the set  $\{x\colon V(x)=c\}$  provided that  $0\le c\le c_0$ .

Proof. Let U be a bounded open neighborhood of 0 in U with  $\bar{U} \subset \Omega$ . If

$$l = \min_{x \text{ in } \partial U} V(x),$$

then l > 0. Since V(0) = 0,  $V(x) \ge l$  for x in  $\partial U$ , and V is continuous, it follows that the function V(x) must take on all values between 0 and l along any continuous curve going from 0 to  $\partial U$ .

LEMMA 1.2. If  $V(x) = V_p(x) + W(x)$  where  $W(x) = o(|x|^p)$  as  $|x| \to 0$  is continuous and  $V_p$  is a positive definite homogeneous polynomial of degree p, then V(x) is positive definite in a neighborhood of x = 0.

**PROOF.** If  $\min_{|x|=1} V_p(x) = k$ , then k > 0. Therefore

$$V_p(x) = |x|^p V(x/|x|) \ge k|x|^p$$

for  $x \neq 0$ . For any  $\varepsilon > 0$ , there is a  $\delta(\varepsilon) > 0$  such that  $|W(x)| < \varepsilon |x|^p$  for  $|x| < \delta(\varepsilon)$ . If  $\varepsilon = k/2$ , then

$$|V(x)| \ge |V_p(x)| - |W(x)| \ge k|x|^p - \left(\frac{k}{2}\right)|x|^p = \left(\frac{k}{2}\right)|x|^p$$

if  $0 < |x| < \delta(k/2)$ . This proves the lemma.

Lemma 1.3. Suppose  $V_p(x)$  is a homogeneous polynomial of degree p. If p is odd, then  $V_p$  cannot be sign definite.

PROOF. If  $x = (x_1, \ldots, x_n)$ ,  $x_1 \neq 0$ , let  $x = x_1 u$ . Then  $V_p(x) = x_1^p V_p(u)$ . For a given value of u for which  $V_p(u) \neq 0$ , say positive, the function  $V_p(x)$  has the sign of  $x_1^p$ . If p is odd, this implies  $V_p(x)$  must change sign in every neighborhood of x = 0.

General criteria for determining the positive definiteness of an arbitrary homogeneous polynomial of degree p are not known, but for p = 2, we have

Lemma 1.4. (Sylvester). The quadratic form  $x'Ax = \sum_{i,j=1}^{n} a_{ij}x_ix_j$ , A' = A, is positive definite if and only if

$$\det(a_{ij}, i, j = 1, 2, ..., s) > 0, \quad s = 1, 2, ..., n.$$

A proof of this lemma may be found in Bellman [2].

Consider the differential equation

$$(1.1) \dot{x} = f(x),$$

where  $f: \mathbb{R}^n \to \mathbb{R}^n$  is continuous and satisfies enough smoothness conditions to ensure that a solution of (1.1) exists through any point, is unique and depends continuously upon the initial data.

For any scalar function V defined and continuous together with  $\partial V/\partial x$  on an open set  $\Omega$  of  $\mathbb{R}^n$ , we define  $\dot{V} = \dot{V}_{(1,1)}$  as

(1.2) 
$$\dot{V}(x) = \frac{\partial V(x)}{\partial x} f(x).$$

If x(t) is a solution of (1.1), then  $dV(x(t))/dt = \dot{V}(x(t))$ ; that is,  $\dot{V}$  is the derivative of V along the solutions of (1.1). Notice that  $\dot{V}$  can be computed directly from f(x) and, therefore, involves no integrations.

The theory below also remains valid for scalar functions V defined and only continuous on an open set  $\Omega$  of  $\mathbb{R}^n$  provided that V is given as

$$\dot{V}(\xi) = \overline{\lim_{h \to 0^+}} \frac{1}{h} [V(x(h, \xi)) - V(\xi)],$$

where  $x(h, \xi)$  is the solution of (1.1) with initial value  $\xi$  at h = 0. If V is locally lipschitz continuous, then this latter definition can be shown to be equivalent to

$$\dot{V}(\xi) = \overline{\lim_{k \to 0+} \frac{1}{h}} \left[ V(\xi + hf(\xi)) - V(\xi) \right].$$

In the applications, it is sometimes necessary to consider functions V(x) which do not have continuous first partial derivatives at all points x. On the other hand, the functions V(x) are usually piecewise smooth with the sets of discontinuities in the derivatives of V occurring on surfaces of lower dimension than the basic space  $\mathbb{R}^n$ .

Since the proofs of the theorems below do not use the differentiability of V, they are stated without this hypothesis. However, in the majority of the applications,  $\dot{V}$  will be given by (1.2).

THEOREM 1.1. If there is a continuous positive definite function V(x) on  $\Omega$  with  $V \leq 0$ , then x = 0 is a solution of (1.1) and it is stable. If, in addition, V is negative definite on  $\Omega$ , then the solution x = 0 is asymptotically stable.

PROOF. Let B(r) be the ball in  $\mathbb{R}^n$  of radius r with center at the origin. There is an r > 0 such that  $B(r) \subset \Omega$ . For  $0 < \varepsilon < r$ ,  $0 < k = \min_{|x|=\varepsilon} V(x)$ . Suppose that  $0 < \delta \le \varepsilon$  is such that V(x) < k for  $|x| \le \delta$ . Such a  $\delta$  always exist since V(0) = 0 and V is continuous. If  $x_0$  is in  $B(\delta)$ , then the solution x(t) of (1.1) with  $x(0) = x_0$  is in  $B(\varepsilon)$  for  $t \ge 0$  since  $V(x(t)) \le 0$  implies  $V(x(t)) \le V(x_0)$ ,  $t \ge 0$ . This proves x = 0 is a solution and it is stable.

![](_page_323_Figure_2.jpeg)

Figure X.1.1

Since x = 0 is stable, there is a bo > 0, H > 0, such that the solution x(t) exists and satisfies jx(t)l <H for t >\_ 0 provided that Ixol <bo. Also, for any E > 0, there is a S(s) > 0 such that jx(t)l <E for t >\_ 0, Ixol < S(e). To prove asymptotic stability, it is sufficient to show there is a T > 0 such that 1x(t)l < S(E) for t >\_ T, Ixol <bo. Suppose there is an xo with ixol <bo and Ix(t)1 >\_ S(E) fort > 0. If y > 0 is such that TY(x(t)) < - y for S(e) 5 x < Hi; t 0, then

$$V(x(t)) \leq V(x_0) - \gamma t.$$

If fl > 0, k satisfy 0 < P 5 V (x) 5 k for S(e) <\_ Cxj< H, choose T = (k - j9 )/y. For t >\_ T, V(x(t)) < P. Thus, there must exist a to, 0 5 t o ;S T such that jx(to)l < S(e). Stability implies jx(t)l <E for t >\_ to and, in particular, for t Z T. This completes the proof of the theorem.

THEOREM 1.2. Suppose x = 0 is an equilibrium point of (1.1) contained in the closure of an open set U and let f2 be a neighborhood of x = 0. Suppose V is a scalar function on f2 which satisfies:

- (i) V, V positive on U n f2\{0}, V(0) = 0,
- (ii) V = 0 on that part of the boundary of U inside Q.

Then the solution x = 0 of (1.1) is unstable. More specifically, if Do is any bounded neighborhood of x = 0 with .0o in f2, then any solution with initial value in (U n flo)\{0} leaves f2o in finite time.

PROOF. Let r > 0 be such that B(r) a K2. For any 0 < s 5 r, there is an xo 0 in U n B(s) and thus V(xo) > 0. Since V >\_ 0 in U n 0, it follows that the solution x(t) with x(0) = xo satisfies V(x(t)) > V(xo) > 0 for x(t) in U fl 92.

If a = min{V(x): x in U n 0 with V(x) >\_ V(xo)}, then a > 0 and

$$V(x(t)) = V(x_0) + \int_0^t \dot{V}(x(t)) dt \ge V(x_0) + \alpha t$$

for all t for which x(t) remains in U n 0. If ffo is any bounded neighborhood of x = 0 which is contained in n, this implies x(t) reaches eL2o since V(x) is bounded on U n 12o . This completes the proof of the theorem.

Theorems 1.1 and 1.2 give an indication of a procedure for determining stability or instability of the equilibrium point of an autonomous equation without explicitly solving the equation. On the other hand, there is no general way for constructing the functions V and the ingenuity of the investigator must be used to its fullest extent. For linear systems (1.1), the following lemma is useful. In this lemma, Re A(A) designates the real parts of the eigenvalues of a matrix A.

LEMMA 1.5. Suppose A is a real n matrix. The matrix equation

$$(1.3) A'B + BA = -C$$

has a positive definite solution B for every positive definite matrix C if and only if Be A(A) < 0.

PuooF. Consider the linear differential equation

$$(1.4) \dot{x} = Ax,$$

and the scalar function V(x) = x'Bx where B is a symmetric matrix.

$$\dot{V}_{(1,4)}(x) = x'[A'B + BA]x.$$

If there exists a positive definite B such that B satisfies (1.3) with C positive definite, then Theorem 1.1 implies that all solutions of (1.4) approach zero as t - oo. Of course, this implies Be A(A) < 0.

Conversely, if Be A(A) < 0 and C is a positive definite matrix, define

$$(1.6) B = \int_0^\infty e^{A't} Ce^{At} dt.$$

The matrix B is well defined since there are positive constants K, a such that I eAtj < Ke-at, t">\_ 0. Furthermore, it is clear that B is positive definite. Also,

$$A'B + BA = \int_0^\infty \frac{d}{dt} (e^{A't}Ce^{At})dt$$
  
=  $-C$ .

This proves the lemma.

From the proof of Lemma 1.5, it is clear that we have proved the following converse theorem of asymptotic stability for the linear system (1.4).

LEMMA 1.6. If the system (1.4) is asymptotically stable, then there is a positive definite, quadratic form whose derivative along the solutions of (1.4) is negative definite.

Let us now apply Lemma 1.5 to the equation

$$(1.7) \dot{x} = Ax + f(x)$$

where f has continuous first derivatives in Rn with f (0) = 0, Of (0)/8x = 0.

If Re A(A) < 0 then Lemma 1.5 implies there is a positive definite matrix B such that A'B + BA = -I. Let V(x) = x'Bx. Then V = V (1,?) is given by

$$\dot{V} = -x'x + 2x'Bf(x).$$

Lemma 1.2 implies that - V is positive definite in a neighborhood of x = 0 and Theorem 1.1 implies the solution x = 0 of (1.7) is asymptotically stable. This is the same result as obtained in Chapter III using the variation of constants formula.

If Re A(A) 0 0 and an eigenvalue of A has a positive real part, then we can assume without loss of generality that A = diag(A \_ , A+) where Re A(A\_) < 0, Re A(A+) > 0. Let BI be the positive definite solution of A' B1 + B1 A\_ \_ -I and B2 be the positive definite solution of (-A') B2 + B2(-A+) = -I which are guaranteed by Lemma 1.5. If x = (u, v) where u, v have the same dimensions as B1, B2, respectively, let V (x) = -u'B1u + v'B2 v. Then 17(x) = V(l.?)(x) = x'x+o(Jx12) as jxj -'0. Lemma 1.2 implies V(x) is positive definite in a neighborhood of x = 0. On the other hand, the region U where V is positive obviously satisfies the conditions of Theorem 1.2. Thus, the solution x = 0 of (1.7) is unstable if there is an eigenvalue of A with a positive real part. This result was also obtained in Chapter III using the variation of constants formula.

The above results are easily generalized. To simplify the presentation, we say a scalar function V is a Liapunov function on an open set G in Rn if V is continuous on 0, the closure of G, and V (x) = [2V (x)/8x] f (x) < 0 for x in G. Let

$$S = \{x \text{ in } \overline{G} \colon \overrightarrow{V}(x) = 0\},$$

and let M be the largest invariant set of (1.1) in S.

THEOREM 1.3. If V is a Liapunov function on G and y+(xo) is a bounded orbit of (1.1) which lies in G, then the w-limit set of y+ belongs to M; that is, x(t, xo) --M as t -\* oo.

PROOF. Since y+(xo) is bounded, V(x(t, xo)) is bounded below for t >\_ 0 and V(x(t, xo)) < 0 implies V(x(t, xo)) is nonincreasing. Therefore, V(x(t, xo)) -\*a constant c as t -\* oo and continuity of V implies V (y) = c for

any y in w(y+). Since w(y+) is invariant, V(x(t, y)) = c for all t and y in w(y+). Therefore, w(y+) belongs to S. This proves the theorem.

COROLLARY 1.1. If V is a Liapunov function on G = {x in Rn: V(x) < p} and G is bounded, then every solution of (1.1) with initial value in 0 approaches M as t -\* oo.

COROLLARY 1.2. If V(x) -, oo as Ixl -\* oo and V<\_ 0 on Rn, then every solution of (1.1) is bounded and approaches the largest invariant set M of (1.1) in the set where V = 0. In particular, if M = {0}, then the solution x = 0 is globally asymptotically stable.

PROOF. For any constant p, V is a Liapunov function on the bounded set 0 = {x: V(x) < p}. Furthermore, for any xo in Rn there is a p such that xo belongs to G. Corollary 1.1 therefore implies the result.

Notice that r < 0 in G\{0} implies M = {0} and one obtains from Theorem 1.3 the asymptotic stability theorem in Theorem 1.1.

THEOREM 1.4. Suppose x = 0 is an equilibrium point of (1.1) contained in the closure of an open set U and let S2 be a neighborhood of x = 0. Assume that

- (i) V is a Liapunov function on G = U n 0,
- (ii) M n G is either the empty set or zero,
- (iii) V(x)<77on Gwhen x:0,
- (iv) V(0) \_ 71 and V(x) =,q when x is on that part of the boundary of 0 in Q.

Then x = 0 is unstable. More precisely, if S2o is a bounded neighborhood of zero with S20 contained in S2, then any solution with initial value in (U n co)\{0} leaves K20 in finite time.

PROOF. If x0 is in (U n S2o)\{0}, then V(xo) <,q. Furthermore, V <\_ 0 implies V(x(t, xo)) < V(xo) < 77 for all t >\_ 0. If x(t, x0) does not leave 00, then w(y+(xo)) is not empty and in S2o. As in the previous proof, w(y+(xo)) e M. Since w(y+(xo)) is nonempty, this implies w(y+(xo)) = {0} and belongs to the set where V(x) \_ ,7. This contradicts the fact that V(x(t, xo)) < V(xo) < ,7 and proves the theorem.

## Example 1.1. Consider the van der Pol equation

$$(1.8) \ddot{x} + \varepsilon (x^2 - 1)\dot{x} + x = 0,$$

and its equivalent Lienard form

(1.9) 
$$\dot{x} = y - \varepsilon \left(\frac{x^3}{3} - x\right),$$
 
$$\dot{y} = -x.$$

In Chapter II, it was shown that this equation has a unique asymptotically stable limit cycle for every e > 0. The exact location of this cycle in the (x, y)-plane is extremely difficult to obtain but the above theory allows one to determine a region near (0, 0) in which the limit cycle cannot lie. Such a region can be found by determining the stability region of the solution x = 0 of (1.8) with t replaced by -t. This has the same effect as taking a <0.

Therefore, suppose a <0 and let V(x, y) be the total energy of (1.9); that is, V(x, y) = (x2 + y2)/2. Then

$$\dot{V}(x,\,y) = -\,arepsilon x^2 igg(rac{x^2}{3} - 1igg)$$

and V (X, y) 5 0 if x2 < 3. Consider the region G = {(x, y) : V (x y) < 3/2}. It is clear that G is bounded and V is a Liapunov function on G. Furthermore, S = {(x, y): V = 0} = {(0, y), y2 < 3}. Also, from (1.9), M = {(0, 0)} and Corollary 1.1 implies every solution starting in the circle x2 + y2 < 3 approaches zero as t -\* oo. Finally, the limit cycle of (1.8) for e > 0 must be outside this circle.

### Example 1.2. Consider the equation

(1.10) 
$$\ddot{x} + f(x)\dot{x} + h(x) = 0,$$

where xh(x) > 0, x 0 0, f (x) > 0, x 0 0 and H(x) = f o h(s) ds - oo as 1xI --\* oo. Equation (1.10) is equivalent to the system

$$\begin{aligned} \dot{x} &= y, \\ \dot{y} &= -h(x) - f(x)y. \end{aligned}$$

Let V(x, y) be the total energy of the system; that is, V(x, y) = y0/2 + H(x). Then V(x, y) = f (x)y2 < 0. For any p, the function V is a Liapunov function on the bounded set G = {(x, y): V(x, y) < p}. Also, the set S where V = 0 belongs to the union of the x-axis and y-axis. From (1.11), this implies M = {(0, 0)} and Corollary 1.2 implies that x = 0 is globally asymptotically stable.

EXERCISE 1.1. Use Theorems 1.1 and 1.2 to prove Lemmas' V.1.2 and V.1.4.

ExERCISE 1.2. Consider the second order system

$$\dot{x} = y - xf(x, y),$$
  

$$\dot{y} = -x - yf(x, y).$$

Discuss the stability properties of this system when f has a fixed sign.

EXERCISE 1.3. Consider the equation

$$\ddot{x} + a\dot{x} + 2bx + 3x^2 = 0, \quad a > 0, b > 0.$$

Determine the maximal region of asymptotic stability of the zero solution which can be obtained by using the total energy of the system as a Liapunov function.

EXERCISE 1.4. Consider the system i = y, y = z - ay, z = -cx - F(y), F(0)=0, a>0, c>0, aF(y)/y>c for y00 and fo [F(e)-ce/a]de- oo as IyI - co. If F(y) = ky where k >.c/a, verify that the characteristic roots of the linear system have negative real parts. Show that the origin is asymptotically stable even when F is nonlinear. Hint: Choose V as a quadratic form plus the term f o F(s) ds.

EXERCISE 1.5. Suppose there is a positive definite matrix Q such that J'(x)Q + QJ(x) is negative definite for all x 0, where J(x) is the Jacobian matrix of f (x). Prove that the solution x = 0 of x = f (x), f (0) = 0, is globally asymptotically stable. Hint: Prove and make use of the fact that f (x) = fl J(sx)x ds. <sup>0</sup>

EXERCISE 1.6. Suppose you have the function V = y2e\_z defined in the whole (x, y)-plane and that relative to some differential equation V = -y2V. Can one conclude anything about the solutions of the original differential equation? If not, what is the trouble?

EXERCISE 1.7. Suppose h(x, y) is a positive definite function such that h(x, y) -> - as x2 + y2 Discuss the behavior in the phase plane of the solutions of the equations

$$\dot{x} = \varepsilon x + y - xh(x, y),$$
  
 $\dot{y} = \varepsilon y - x - yh(x, y),$ 

for all values of e in (-oo, oo).

EXERCISE 1.8. Consider the n-dimensional system x = f (x) + g(t) where x'f (x) < -kIx12, k > 0, for all x and Jg(t)J < M for all t. Find a sphere of sufficiently large radius so that all trajectories enter this sphere. Show this equation has a T-periodic solution if g is T-periodic. If, in addition, (x - y)'[f (x) -f (y)] < 0 for all x y show there is a unique T-periodic solution. Hint: Use Brouwer's fixed point theorem.

EXERCISE 1.9. Suppose f, g are as in Exercise 1.8 except g(t) is almost periodic. Does the equation. =f (x) + g(t) have an almost periodic solution?

EXERCISE 1.10. Prove the zero solution of (1.7) is unstable if there is an eigenvalue of A with a positive real part even though some eigenvalues may have zero real parts.

### X.2. Circuits Containing Esaki Diodes

In this section, we give an example which illustrates many of the previous ideas. Consider the circuit shown in Fig. 2.1. The square box in this diagram represents an Esaki diode with the characteristic function f (v) representing the current flow as a function of the voltage drop v. Kirchoff's

![](_page_329_Picture_4.jpeg)

Figure X.2.1

laws imply that the relation between the current i and voltage v are given by

(2.1) 
$$L\frac{di}{dt} = E - Ri - v \stackrel{\text{def}}{=} I(i, v),$$
$$-C\frac{dv}{dt} = f(v) - i \stackrel{\text{def}}{=} V(i, v),$$

where E, B, C, L are positive constants and of (v) >\_ 0 for all v.

LEMMA 2.1. If there is an A > 0 such that xf (x) > E2/R for jx>A, then every solution of (2.1) is bounded. In fact, every solution is ultimately in a region bounded by a circle.

PROOF. If W(i, v) = (Li2 + Cv2)/2, then the derivative of W along solutions of (2.1) is

$$egin{aligned} \dot{W} = -\left[ Ri igg(i - rac{E}{R}igg) + v f(v) 
ight]. \end{aligned}$$

Let We = [L(E/R)2 + CA2]/2. If W(i, v) > We, then either I it > E/R or jvj >A. If lil > E/R, then W < 0 and if jil < E/R, Ivi >A, then

$$|W| < -\left\lceil Ri^2 - Ei + rac{E^2}{R} 
ight
ceil = -\left\lceil Ri^2 - E\left(i - rac{E}{R}
ight) 
ight
ceil \leq -Ri^2 \leq 0.$$

For i = 0, 1 vI > A, we have also W < 0. Therefore, W < 0 in the region

 $W(i, v) > W_0$ . Since the region  $W < \rho$  is bounded for any  $\rho$  and  $W(i, v) \to \infty$  as  $|i|, |v| \to \infty$ , it follows that every solution of (2.1) is bounded. This proves the lemma.

The problem at hand is to find conditions on f and the parameters in (2.1) which will ensure that every solution of (2.1) approaches an equilibrium point as  $t \to \infty$ . Let f'(v) = df(v)/dv.

LEMMA 2.2. If the conditions of Lemma 2.1 are satisfied and f'(v) > 0 for all v, then every solution of (2.1) approaches the unique equilibrium point of (2.1).

PROOF. First of all, it is clear there is only one equilibrium point of (2.1) if f'(v) > 0 for all v. If

(2.2) 
$$Q(i, v) = \frac{1}{2L}I^2 + \frac{1}{2C}V^2$$

then the derivative of Q along the solutions of (2.1) is

$$\dot{Q} = -(RL^{-2}I^2 + f'C^{-2}V^2) \le 0.$$

Since Lemma 2.1 implies all solutions of (2.1) are bounded and Q=0 only at the equilibrium point, it follows from Theorem 1.3 that the assertion of Lemma 2.2 is true.

The most interesting cases in the applications are when f' changes sign and, in fact, can take on values  $<-R^{-1}$  so that equation (2.1) has three equilibrium points. However, if  $f'>-R^{-1}$  (only one equilibrium point), then a limit cycle may appear unless there are other restrictions on f. In fact, one can prove

THEOREM 2.1. If  $-f' < R^{-1}$ ,  $\max_{v}(-f'|C) > R/L$ , then there is a value of E such that equation (2.1) has at least one periodic orbit.

PROOF. Choose E so that the equilibrium point  $(i_0, v_0)$  is such that  $-f'(v_0)/C > R/L$ . From Lemma 2.1, there is a circle  $\Omega$  with center at (0, 0) such that the trajectories of (2.1) cross  $\Omega$  from the outside to the inside. If  $i = i_0 + u$ ,  $v = v_0 + w$ , x = (u, w), then

(2.4) 
$$\dot{x} = Ax + \dots \qquad A = \begin{bmatrix} -RL^{-1} & -L^{-1} \\ C^{-1} & -f'_0C^{-1} \end{bmatrix}$$

where ... represents higher order terms in x and  $f'_0 = f'(v_0)$ . The hypotheses of the theorem imply that the eigenvalues of A have positive real parts. Replacing t by -t in (2.4) has the same effect as replacing A by -A, a matrix whose eigenvalues have negative real parts. Lemma 1.6 implies there exist a positive definite matrix B such that the derivative of W(x) = x'Bx along the solutions of (2.4) satisfies  $W(x) = -x'x + o(|x|^2)$  as  $|x| \to 0$ . Returning to the original

time scale and using Lemma 1.2, one sees that the trajectories of (2.4) are crossing the ellipses x'Bx = c for c > 0 sufficiently small from the inside to the outside. The annulus bounded by one of these ellipses and the circle  $\Omega$  contains a positive semiorbit of (2.1). The Poincaré-Bendixson theorem implies the result.

To obtain more information for the case when f' changes sign, observe first that system (2.1) can be written as

(2.5) 
$$L\frac{di}{dt} = \frac{\partial P}{\partial i},$$
$$-C\frac{dv}{dt} = \frac{\partial P}{\partial v},$$

where

(2.6) 
$$P(i, v) = Ei - \frac{Ri^{2}}{2} - iv + \int_{0}^{v} f(s) ds$$
$$= -\frac{I^{2}}{2R} + U(v)$$

and

(2.7) 
$$U(v) = \frac{(E-v)^2}{2R} + \int_0^v f(s) \, ds.$$

Theorem 2.2. If there is an  $A \ge 0$  such that  $vf(v) \ge 0, vf(v) > E^2/R$  for |v| > A and

$$(2.8) \qquad \frac{f'(v)}{C} + \frac{R}{L} > 0$$

for all v, then each solution of (2.1) approaches an equilibrium point of (2.1) as  $t \to \infty$ .

**PROOF.** Consider the function  $S = Q + \lambda P$  where Q is defined in (2.2), P is defined in (2.6) and

$$\frac{-f'}{C} < \lambda < \frac{R}{L}.$$

Some straighforward but tedious calculations show that P along the solutions of (2.1) is given by

$$(2.10) \dot{P} = L^{-1}I^2 - C^{-1}V^2.$$

Thus, relation (2.3) and (2.10) imply that  $\dot{S} = \dot{Q} + \lambda \dot{P}$  satisfies

$$\dot{S} = -[(R - \lambda L)L^{-2}I^{2} + (f' + \lambda C)C^{-2}V^{2}] \le 0$$

![](_page_332_Figure_2.jpeg)

Figure X.2.2

by our choice of A. Furthermore = 0 if and only if I = 0, V = 0; that is, only at the equilibrium points of (2.1). Since all solutions of (2.1) are bounded from Lemma 2.1, the conclusion of the theorem follows from Theorem 3.1.

It is of interest to determine which equilibrium points of (2.1) are stable. Let S be defined as in the proof of Theorem 2.2. If A satisfies (2.9), then one can show that the extreme points of S are the equilibrium points of (2.1). Since 9<\_ 0, it follows from Theorems 1.1 and 1.2 that the stable equilibrium points of (2.1) are the minima of S and the unstable equilibrium points are the other extreme points of S.

LEMMA 2.3. If A satisfies (2.9), A = 0, then the extreme points of S(i, v) coincide with the extreme points of U(v) in the sense that the extreme points of S coincide with the solutions of I = 0, eU/8v = 0. Every strict local minimum of U(v) represents a local minimum of S and hence a stable equilibrium point of (2.1).

PROOF. A few elementary calculations yields

$$egin{align} rac{\partial S}{\partial i} &= -(RL^{-1}-\lambda)I + C^{-1}V, \ rac{\partial S}{\partial v} &= -R^{-1}(RL^{-1}-\lambda)I - f'C^{-1}V + rac{\lambda\partial U}{\partial v}. \end{align}$$

If 8U/av = 0 then R-1(E - v) =f (v). If I = 0, then i = R-1(E - v). Thus, I = 0, aU/8v = 0 implies V = 0 and this in turn implies an extreme point of S. If 8S/ai = 0, aS/av = 0, then I = V = 0 and this in turn implies aU/av = 0. This proves the first part of the lemma.

The proof of the second part of the lemma is left as an exercise and

involves showing that a2U/av2 > 0 implies the quadratic form

$$rac{\partial^2 S}{\partial i^2}\, \xi_0^2 + 2\, rac{\partial^2 S}{\partial i\, \partial v}\, \xi_0\, \xi_1 + rac{\partial^2 S}{\partial v^2}\, \xi_1^2$$

evaluated at an equilibrium point is positive definite.

EXERCISE 2.1. Interpret the above results for f (v) having the shape shown in Figs. 2.2a,b.

### X.3. Sufficient Conditions for Stability in Nonautonomous Systems

In this section, we state some extensions of the results in Section 1 to nonautonomous systems

$$(3.1) \dot{x} = f(t, x)$$

where f : [-r, oo) x Rn --\* Rn, r a constant, is smooth enough to ensure that solutions exists through every point (to, xo) in [T, oo) x Rn, are unique and depend continuously upon the initial data. Let SL be an open set in Rn containing zero. A function V : [T, oo) x 1 --\* R is said to be positive definite if V is continuous, V(t, 0) = 0, and there is a positive definite function W: 0 -\* R such that V(t, x) > W(x) for all (t, x) in [T, co) x Q. V(t, x) is said to possess an infinitely-small upper bound if there is a positive definite function W(x) such that V(t, x) < W(x), (t, x) in [T, co) x K1. If V: [T, 00) X S2 -\* R is continuous, we define the derivative V(t, 6) of V along the solutions of (3.1) as

$$\dot{V}(t,\,\xi) = \overline{\lim_{h\to 0^+}} \frac{1}{h} \left[ V(t+h,\,x(t+h,\,t,\,\xi)) - V(t,\,\xi) \right],$$

where x(t, a, e) is the solution of (3.1) passing through (a, e) e [T, co) x Rn. If V(t, 6) has continuous partial derivatives with respect to t, e, then

$$\dot{V}(t,\,\xi) = \frac{\partial V(t,\,\xi)}{\partial t} + \frac{\partial V(t,\,\xi)}{\partial \xi} f(t,\,\xi).$$

THEOREM 3.1. If V: [T, oo) x SZ R is positive definite and V(t, x) < 0, then the solution x = 0 of (3.1) is stable. If, in addition, V has an infinitely small upper bound then the solution x = 0 is uniformly stable. If, furthermore, - V is positive definite, then the solution x = 0 of (3.1) is uniformly asymptotically stable.

PROOF. Since V(t, x) is positive definite, there exists a positive definite function W(x) such that V(t, x) >: W(x) for all (t, x) a [T, co) x Q.. Let B(r)

be the ball in Rn of radius r with center at the origin. There is an r > 0 such that B(r) c I. For 0 < e <r, 0 <k = minjxj\_EW(x). For any to e [r, oo), let 0 < S < s be a number such that V(to, x) < k for (xI <\_ S. Such a S always exists since V(to, 0) = 0 and V is continuous. If xo is in B(S), then the solution x(t) of (3.1) with x(to) = xo is in B(e) for t >\_ to since P(t, x) S 0 implies V(t, x(t)) < V(to, xo), t > to. This proves stability of x = 0.

If, in addition, V has an infinitely small upper bound, then there is a positive definite function Wl(x) such that V(t, x) < WI(x) for all (t, x) c [T, oo) x 0. With e, k as above, choose S > 0 with Wl(x) < k for IxI < S. Then, for any to e [r, oo), xo in B(S), the solution x(t) of (3.1), x(to) = xo, is in B(e) for t >to since V(t, x(t)) < V(to, xo) < WI(xo) for all t. This proves uniform stability of x = 0.

If, furthermore, -V(t, x) is positive definite, then there is a positive definite function W2(x) such that -V(t, x) >\_ W2(x) for all (t, x) e [r, oo) x S2. The proof now proceeds in a manner similar to the proof of Theorem 1.1.

Let R+ \_ [0, oo ), V (t, x): R+ x Rn -\* R be continuous, G be any set in Rn and 0 be the closure of G. We say V is a Liapunov function of (3.1) on 0 if

- (i) given x in 7 there is a neighborhood N of x such that V(t, x) is bounded from below for all t >\_ 0 and all x in N n G.
- (ii) V(t, x) < -W(x) < 0 for (t, x) in R+ x 0 and W is continuous on 0.

If V is a Lyapunov function for (3.1) on G, we define

$$E = \{x \text{ in } \bar{G}: W(x) = 0\}.$$

THEOREM 3.2. Let V be a Liapunov function for (3.1) on 0 and let x(t) be a solution of (3.1) which is bounded and'remains in 0 for t >\_ to >\_ 0.

- (a) If for each p in 0, there is a neighborhood N of p such that If (t, x)I is bounded for all t >\_ 0 and all x in N n G, then x(t) -\* E as t -\* oo.
- (b) If W has continuous first derivatives on 0.r and l ' = (8W/8x) f (t, x) is bounded from above (or from below) along the solution x(t), then x(t) -\* E ast - oo.

PROOF. Let p be a finite positive limit point of x(t) and {tn} a sequence of real numbers, oo as n oo such that x(tn) -> p as n -\* oo. Conditions (i) and (ii) in the definition of a Liapunov function imply that V(tn, x(tn)) is nonincreasing and bounded below. Therefore, there is a constant c such that V(tn, x(tn)) -\* c as n -\* oo and since V(t, x(t)) is nonincreasing, V(t, x(t)) -.c as t-. oo. Also, V(t, x(t)) < V(to, x(to)) - f t W(x(s)) ds and hence to

$$\int_{t_0}^{\infty} W(x(s)) ds < \infty.$$

Part (a). Assume p is not in E. Let  $\delta > 0$  be such that  $W(p) > 2\delta > 0$ . There is an  $\varepsilon > 0$  such that  $W(x) > \delta$  for x in  $S_{2\varepsilon}(p) = \{x: |x-p| < 2\varepsilon\}$ . Also  $\varepsilon$  can be chosen so that  $S_{2\varepsilon}(p) \subset N$ , the neighborhood given in (a). If x(t) remains in  $S_{2\varepsilon}(p)$  for all  $t \ge t_1 \ge t_0$ , then  $\int_{t_0}^{\infty} W(x(s)) \, ds = +\infty$  which is a contradiction. Since p is in the limit set of x(t), the only other possibility is that x(t) leaves and returns to  $S_{2\varepsilon}(p)$  an infinite number of times. Since |f(t,x)| is bounded in  $S_{2\varepsilon}(p)$ , this implies each time that x(t) returns to  $S_{2\varepsilon}(p)$ , it must remain in  $S_{2\varepsilon}(p)$  at least a positive time  $\tau$ . Again, this implies  $\int_{t_0}^{\infty} W(x(s)) \, ds = +\infty$  and a contradiction. Therefore W(p) = 0 and E contains all limit points.

Part (b). Since  $\int_{t_0}^{\infty} W(x(s)) ds < \infty$  and W(x(t)) is bounded from above (or from below), it follows that  $W(x(t)) \to 0$  as  $t \to \infty$ . Since W is continuous W(p) = 0 and this proves (b).

**Example 3.1.** Consider the equation

(3.2) 
$$\dot{x}=y,$$
 
$$\dot{y}=-x-p(t)y,$$
 where  $p(t)\geq\delta>0.$  If  $V(x,y)=(x^2+y^2)/2,$  then 
$$\dot{V}=-p(t)y^2\leq-\delta y^2.$$

and V is a Liapunov function on  $R^2$  with  $W(x,y) = -\delta y^2$ . Also,  $W = -2\delta(xy+p(t)y^2) \le -2\delta xy$ . Every solution of (3.2) is clearly bounded and, therefore, condition (b) of Theorem 3.2 is satisfied. The set E is the x-axis and Theorem 3.2 implies that each solution x(t), y(t) of (3.2) is such that  $y(t) \to 0$  as  $t \to \infty$ . On the other hand, if  $p(t) = 2 + e^t$ , then there is a solution of (3.2) given as  $x(t) = 1 + e^{-t}$ ,  $y(t) = -e^{-t}$ . Since the equation is linear, every point on the x-axis is a limit point of some solution. This shows that the above result is the best possible without further restrictions on p.

Notice that the condition in (a) of Theorem 3.2 is not satisfied in Example 3.1 unless p(t) is bounded.

A simple way to verify that a solution x(t) of (3.1) remains in G for  $t \ge t_0$  is given in the following lemma whose proof is left as an exercise.

Lemma 3.1. Assume that V(t,x) is a continuous scalar function on  $R^+ \times R^n$  and there are continuous scalar functions a(x), b(x) on  $R^n$  such that  $a(x) \leq V(t,x) \leq b(x)$  for all (t,x) in  $R^+ \times R^n$ . For any real number  $\rho$ , let  $A_{\rho} = \{x \text{ in } R^n \colon a(x) < \rho\}$  and let  $G_0$  be a component of  $A_{\rho}$ . If G is the component of the set  $B_{\rho} = \{x \text{ in } R^n \colon b(x) < \rho\}$  contained in  $G_0$  and  $V \leq 0$  on  $G_0$ , then any solution of (3.1) with  $x(t_0)$  in G remains in  $G_0$  for all  $t \geq t_0$ .

Notice that  $a(x) \to \infty$  as  $|x| \to \infty$  in Lemma 3.1 implies boundedness of the solutions of (3.1).

### X.4. The Converse Theorems for Asymptotic Stability

In this section, we show that a type of converse of Theorem 3.1 for uniform asymptotic stability is true. If V(t, x) is a continuous scalar function on R+ x Rn and x(t, to, xo) is the solution of (3.1) with x(to, to, xo) = xo, we define the derivative T1(3.1)(t, e) along the solutions of as in Section 3; namely,

$$\dot{V}_{(3.1)}(t,\xi) = \overline{\lim_{h \to 0^+}} \frac{1}{h} \left[ V(t+h, x(t+h, t, \xi)) - V(t, \xi) \right].$$

Our first converse theorem deals with the linear system since the essential ideas emerge without any technical difficulties.

THEOREM 4.1. If A(t) is a continuous matrix on [0, oo) and the linear system

$$(4.1) \dot{x} = A(t)x$$

is uniformly asymptotically stable, then there are positive constants K, a and a continuous scalar function V on R+ x R'n such that

(4.2) (a) 
$$|x| \le V(t, x) \le K|x|$$
,  
(b)  $\dot{V}_{(4.1)}(t, x) \le -\alpha V(t, x)$ ,  
(c)  $|V(t, x) - V(t, y)| \le K|x - y|$ ,

for all tin R+, x, y in Rn.

PROOF. From Theorem 111.2. 1, there are positive constants K, « such that the solution x(t, to, xo) of (4.1) with x(to, to, xo) = xo satisfies

$$|x(t, t_0, x_0)| \leq Ke^{-\alpha(t-t_0)}|x_0|$$

for all t >\_ to >\_ 0 and all xo in Rn. Define for t >\_ 0, xo in Rn

(4.4) 
$$V(t, x_0) = \sup_{\tau \ge 0} |x(t + \tau, t, x_0)| e^{\alpha \tau}.$$

It is immediate from (4.3) that V(t, xo) is defined for all t, xo and satisfies (4.2a).

To verify (4.2c) observe that

$$\begin{split} |V(t, x_0) - V(t, y_0)| &\leq \sup_{\tau \geq 0} |x(t + \tau, t, x_0) - x(t + \tau, t, y_0)| e^{\alpha \tau} \\ &= \sup_{\tau \geq 0} |x(t + \tau, t, x_0 - y_0)| e^{\alpha \tau} \\ &= V(t, x_0 - y_0) \leq K |x_0 - y_0|. \end{split}$$

The proof of (4.2b) proceeds as follows:

$$\begin{split} \dot{V}_{(4.1)}(t, x_0) &= \overline{\lim_{h \to 0^+}} \frac{1}{h} \left[ \sup_{\tau \ge 0} |x(t + \tau + h, t + h, x_0)| e^{\alpha \tau} - \sup_{\tau \ge 0} |x(t + \tau, t, x_0)| e^{\alpha \tau} \right] \\ &= \overline{\lim_{h \to 0^+}} \frac{1}{h} \left[ \sup_{\tau \ge h} |x(t + \tau, t, x_0)| e^{\alpha(\tau - h)} - \sup_{\tau \ge 0} |x(t + \tau, t, x_0)| e^{\alpha \tau} \right] \\ &\le \overline{\lim_{h \to 0^+}} \frac{1}{h} \left[ \sup_{\tau \ge 0} |x(t + \tau, t, x_0)| e^{\alpha(\tau - h)} - \sup_{\tau \ge 0} |x(t + \tau, t, x_0)| e^{\alpha \tau} \right] \\ &\le \overline{\lim_{h \to 0^+}} \left[ \frac{1}{h} \sup_{\tau \ge 0} |x(t + \tau, t, x_0)| e^{\alpha \tau} (e^{-\alpha h} - 1) \right] \\ &= -\alpha V(t, x_0). \end{split}$$

It remains only to show that V(t, xo) is continuous. Notice that

$$|V(t+s, x_0+y_0) - V(t, x_0)| \le |V(t+s, x_0+y_0) - V(t+s, x(t+s, t, x_0+y_0))| + |V(t+s, x(t+s, t, x_0+y_0)) - V(t, x_0+y_0)| + |V(t, x_0+y_0) - V(t, x_0)|.$$

The fact that the first and third terms can be made small if s, y are small follows from (4.2c). The continuity of the solution of (4.1) in t and an argument similar to that used in proving that V(4.I1 existed shows the second term can be made small if s is small. This proves right continuity. Left continuity is an exercise for the reader.

Theorem 4.1 is a converse theorem for exponential asymptotic stability. In fact, if there is a function V satisfying (4.2), and x(t) = x(t, to, xo) is a solution of (4.1), then

$$V(t, x(t)) \leq e^{-\alpha(t-t_0)} V(t_0, x_0) \leq K e^{-\alpha(t-t_0)} |x_0|.$$

The fact that V(t, x) > IxI implies that x(t) satisfies (4.3).

The basic elements of the proof of the above theorem are the estimate (4.3) and the lifting of the norm of x in the definition of V. If the lifting factor ear had not been applied one would have only obtained V< 0.

Our next objective is to extend Theorem 4.1 to the nonlinear equation (3.1). We need

LEMMA 4.1. Suppose f (t, 0) =0. The solution x = 0 of (3.1) is uniformly stable if and only if there exists a function p(r) with the following`properties:

(a) p(r) is defined, continuous and monotonically increasing in an interval 0 < r:5 r1,

(b) 
$$\rho(0) = 0$$
,

(c) For any x in Rn, jxj <ri and any to >\_ 0, the solution x(t, to, xo), x(to, to, xo) = xo, of (3.1) satisfies

$$|x(t, t_0, x_0)| \le \rho(|x_0|)$$
 for  $t \ge t_0$ .

PROOF. The sufficiency is obvious. To prove necessity, suppose e > 0 is given and let S(e) be the least upper bound of all numbers S(e) occurring in the definition of uniform stability. Then, for any x in Rn, jxj S S(e), and any to >\_ 0, the solution x(t, to, xo) of (3.1) satisfies lx(t, to, xo) < e fort >\_ to. For every S1 > S, there is an xo in Rn, 1xo1 < S1 such that jx(t, to, x"ofl exceeds a for some value of t. Consequently, S(e) is nondecreasing, positive for e > 0, and tends to zero as a tends to zero. However, S(e) may be discontinuous. Now choose S(e) continuous, monotonically increasing and such that S(e) < S(e) for s > 0. Let p be the inverse function of b. For any xo in Rn, Ixol < S(e), there exists an e1 such that Ixo1 = S(el) and, thus, jx(t, to, xo)l < e1= AxoD. This proves the lemma.

LEMMA 4.2. The solution x = 0 of (3.1) is uniformly asymptotically stable if and only if there exist functions p(r), 0(r) with p(r) satisfying the conditions of Lemma 4.1 and 0(r) defined, continuous and monotonically decreasing in 0<\_ r < oo, 0(r) -\* 0 as r-\* oo such that, for any xo in Rn, ixo! <rr, and every to >\_ 0, the solution x(t, to, xc) of (3.1) satisfies

$$|x(t, t_0, x_0)| \leq \rho(|x_0|)\theta(t-t_0), \qquad t \geq t_0.$$

The proof of this lemma is left as an exercise.

THEOREM 4.2. If f (t, 0) = 0, f (i, x) is locally lipschitzian in x uniformly with respect to t and the solution x = 0 of (3.1) is uniformly asymptotically stable, then there exist an r1 > 0, K = K(r1) > 0, a positive definite function b(r), a positive function c(r) on 0 < r <\_ r1 and a scalar function V(t, x) defined and continuous for t >\_ 0, x in Rn, jxj < rl, such that

- (4.5) (a) jxj <\_ V(t, x):5 b(lxl),
  - (b) V(3.1)(t, x) < -c(lxl) V(t, x) < -Ixj c(lxf ),
  - (6) jV(t,x)-V(t,y)I <\_Kjx-yj,

for all t >\_ 0, x, y in Rn, I xj < r1i jyi < r1.

PROOF. From Lemma 4.2, there exist functions p(r), 0(r), defined, continuous and positive on 0 <\_ r < r1, 0 <\_ r < oo, such that p(r) is strictly increasing in r, p(O) = 0, 0(r) is strictly decreasing in r, 0(r) -\* 0 as r--> co and for any x in Rn, jxj < r1, the solution x(t, to, xo) of (3.1) satisfies

$$|x(t, t_0, x_0)| \le \rho(|x_0|)\theta(t - t_0), \qquad t \ge t_0 \ge 0.$$

One can also assume that 0(T) has a continuous negative derivative, and 0(0) = 1. From the properties of 0(r), there exists a function a(T) defined, continuously differentiable and positive on T > 0, a(0) = 0, a(r) strictly increasing, a(r) - oo as T -> co such that

$$\theta(\tau) = e^{-\alpha(\tau)}, \qquad \tau \ge 0.$$

Suppose q(T) is a bounded continuously differentiable function on 0 <\_ T < oo, such that q(0) = 0, q(r) > 0, q'(r) < a'(T) for T > 0, q' monotone decreasing, and define

$$V(t, x_0) = \sup_{\tau \geq 0} |x(t + \tau, t, x_0)| e^{q(\tau)}.$$

Tne function V(t, xo) is defined for t >\_ 0, xo in Rn, Ixol < ri and satisfies

$$|x_0| \leq V(t, x_0) \leq \rho(|x_0|) \sup_{\tau \geq 0} e^{-\alpha(\tau) + q(\tau)} = \rho(|x_0|) \stackrel{\text{def}}{=} b(|x_0|).$$

Furthermore, since there exists a continuous positive nondecreasing function P(r), 0 < r 5 rI such that

$$\rho(|x|)e^{-\alpha(\tau)+q(\tau)} \leq |x| \quad \text{for} \quad \tau \geq P(|x|),$$

it follows that

$$V(t, x_0) = \sup_{0 \le \tau \le P(|x_0|)} |x(t + \tau, t, x_0)| e^{q(\tau)}.$$

Consequently, for any h > 0, there is a rh , 0 < Th < P(I x(t + h, t, xo) I) such that rh is continuous in h and

$$V(t+h, x(t+h, t, x_0)) = |x(t+h+\tau_h^*, t, x_0)|e^{q(\tau_h^*)}.$$

If h + rh = rh, then

$$V(t+h, x(t+h, t, x_0)) = |x(t+\tau_h, t, x_0)| e^{q(\tau_h)} e^{-q(\tau_h)} e^{q(\tau_h-h)}$$
  

$$\leq V(t, x_0) e^{-q(\tau_h)} e^{q(\tau_h-h)}.$$

Therefore,

$$\begin{split} \dot{V}_{(3.1)}(t, x_0) &\leq -V(t, x_0) \lim_{h \to 0^+} \frac{1}{h} \left[ e^{q(\tau_h)} - e^{q(\tau_h - h)} \right] e^{-q(\tau_h)} \\ &= -V(t, x_0) q'(\tau_0) \leq -V(t, x_0) q'(P(|x_0|)) \\ &\stackrel{\text{def}}{=} -c(|x_0|) V(t, x_0) \\ &\leq -|x_0| \, c(|x_0|), \end{split}$$

which proves (4.5b). Since f in (3.1) is locally Lipschitzian in x uniformly in t, for any ro > 0, there is a constant L = L(ro) such that

$$\big|x(t,\,t_0\,,\,x_0)-x(t,\,t_0\,,\,y_0)\big| \le e^{L(t-t_0)}\,\big|x_0-y_0\big|,$$

for all t >\_ to and xo, yo for which I x(t, to, xo) 15 ro, I x(t, to, yo) l <\_ ro. Choose ro = p(ri). Since P(r) is nondecreasing in r, it follows that

$$\begin{split} |V(t, x_0) - V(t, y_0)| &\leq \sup_{0 \leq \tau \leq P(\tau)} |x(t + \tau, t, x_0) - x(t + \tau, t, y_0)| e^{q(\tau)} \\ & \cdot \leq \left[ \sup_{0 \leq \tau \leq P(\tau)} e^{L\tau} e^{q(\tau)} \right] |x_0 - y_0| \\ & \frac{\operatorname{def}}{} K(r) |x_0 - y_0|, \end{split}$$

for Ixol, Iyol <\_ r. For r = ri, K = K(ri), this proves V satisfies the inequalities of the theorem.

To prove V(t, xo) is continuous in t, xo we observe that

$$|V(t+h, x_{0}+y_{0}) - V(t, x_{0})|$$

$$\leq |V(t+h, x_{0}+y_{0}) - V(t+h, x(t+h, t, x_{0}+y_{0}))|$$

$$+ |V(t+h, x(t+h, t, x_{0}+y_{0})) - V(t, x_{0}+y_{0})|$$

$$+ |V(t, x_{0}+y_{0}) - V(t, x_{0})|.$$

The fact that the first and third terms can be made small if h, yo are small follows from the lipschitzian property of V and the continuity of the solution of (3.1). The second term can be seen to be small if h is small by an argument similar to that used in showing that r existed.

This shows right continuity. Left continuity is an exercise for the reader. In Section 2, it was shown that a function V satisfying (4.5) implies that the solution x = 0 of (3.1) is uniformly asymptotically stable. Therefore, Theorem 4.2 is the converse theorem for uniform asymptotic stability.

## X.5. Implications of Asymptotic Stability

In most of the applications that arise in the real world, the differential equations are not known exactly. Therefore, specific properties of the solutions of these equations which are physically interesting should be insensitive to perturbations in the vector field with, of course, the types of perturbations being dictated by the problem at hand. Therefore, one reasonable criterion on which to judge the usefulness of a definition of stability is to test the sensitiveness of this property to perturbations of the vector field. In this section, we use the converse theorem of Section 4 to discuss the sensitiveness of uniform asymptotic stability to arbitrary perturbations as long as they are "small." We need

LEMMA 5.1. Suppose f satisfies the conditions of Theorem 4.2, V is the function given in that theorem, g(t, x) is any continuous function on R+ x Rn

intoRn and consider the equation

(5.1) 
$$\dot{x} = f(t, x) + g(t, x).$$

Then

(5.2) 
$$\dot{V}_{(5.1)}(t,x) \leq -c(|x|)V(t,x) + K|g(t,x)|$$

for all t >\_ 0, I x) < r1.

PROOF. Let x\*(t, to, xo), x\*(to , to, xo) = xo, be a solution of (5.1) and x(t, to, xo), x(to, to, xo) = xo, a solution of (3.1). Using the definition of V(51) and relations (4.5b), (4.5c), one obtains

$$\begin{split} \dot{V}_{(5.1)}(t, x_0) &= \overline{\lim_{h \to 0^+}} \frac{1}{h} [V(t+h, x^*(t+h, t, x_0)) - V(t, x_0)] \\ &= \overline{\lim_{h \to 0^+}} \frac{1}{h} [V(t+h, x(t+h, t, x_0)) - V(t, x_0) \\ &+ V(t+h, x^*(t+h, t, x_0)) - V(t+h, x(t+h, t, x_0))] \\ &\leq \dot{V}_{(3.1)}(t, x_0) + K \overline{\lim_{h \to 0^+}} \frac{1}{h} |x^*(t+h, t, x_0) - x(t+h, t, x_0)| \\ &\leq \dot{V}_{(3.1)}(t, x_0) + K |g(t, x_0)| \\ &\leq -c(|x_0|) V(t, x_0) + K |g(t, x_0)|. \end{split}$$

This proves the lemma.

Many results now follow directly from Lemma 5.1. In fact, if (3.1) is linear, then equation (5.1) is

$$\dot{x} = A(t)x + g(t, x),$$

and Theorem 4.1 states that c(IxI) in (4.5) can be chosen as a > 0. Therefore, the inequality (5.2) becomes

$$\dot{V}_{(5.3)}(t, x) \leq -\alpha V(t, x) + K |g(t, x)|.$$

If w(t, r) is a continuous function on R+ x B+, nondecreasing in r, such that

$$(5.5) |g(t, x)| \leq \omega(t, |x|),$$

then one sees that (4.2a) and (5.5) imply

$$\dot{V}_{(5,3)} \leq -\alpha V + K\omega(t, V).$$

Using our basic result on differential inequalities in Section 1.6 and relation (4.2), one can state

THEOREM 5.1. Suppose w(t, u) in (5.5) is such that for any to > 0,.uo >\_ 0, the equation

$$\dot{u} = -\alpha u + K\omega(t, u)$$

has a solution passing through to, uo which is unique. If u(t, to, uo), u(to, to, uo) = uo, is a solution of (5.7) which exists for t > to and uo >\_ Kl xo!, xo in Rn, Ixol < r1, then the solution x(t, to, xo), x(to, to, xo) = xo, of (5.3) satisfies

$$|x(t, t_0, x_0)| \leq u(t, t_0, u_0), \qquad t \geq t_0.$$

Another application of Lemma 5.1 is

THEOREM 5.2. If f satisfies the conditions of Theorem 4.2 and the solution x = 0 of (3.1) is uniformly asymptotically stable, then there is an r1 > 0 such that for any e, 0 < e < r1 and any r2, e < r2 < rl, there is a S > 0 and a T > 0 such that for any to > 0 and any xo in Rm, a <\_ Ixol < r2, the solution x(t, to, xo), x(to , to, xo) = xo of (5.1) satisfies I x(t, to, xo) I < e for t >\_ to + T provided that I g(t, x)I < S for all t > 0, I xl < r1.

PROOF. The hypotheses of the theorem imply there is a function V (t, x) satisfying the conditions (4.5) of Theorem 4.2. Choose rl as in Theorem 4.2. Without loss of generality, we may assume the functions b(s), c(s) in (4.5) are nondecreasing. For any e, r2 as in the theorem, we know that a < Ixl < r2 implies c(s) > 0 and e < V(t, x) < b(r2). Furthermore, Lemma 5.1 implies

$$\begin{aligned} \dot{V}_{(5.1)}(t, x) &\leq -c(\varepsilon) V(t, x) + K |g(t, x)| \\ &\leq -c(\varepsilon)\varepsilon + K |g(t, x)| \end{aligned}$$

for all t >\_ 0, a <\_ I xl <\_ r2 . Consequently, if x = x(t) represents a solution of (5.1) with x(to) = xo, s :!g Ixol < r2 and KS < 6c(s)f2 with I g(t, x)l < S for all t >\_ 0, 1 XI < r1, then 'P (5.1)(t, x(t)) < -ec(e)/2 as long as s:5 lx(t)I < r2. This clearly implies that I x(to + t, to, xo) I < e for t >\_ T > 2b(r2)/ec(s). This completes the proof of the theorem.

One could continue to deduce other more specific results but Theorems 5.1 and 5.2 should indicate the usefulness of the converse theorems of Liapunov.

## X.6. Wazewski's Principle

The purpose of this section is to give an introduction to a procedure known as Wazewski's principle for determining the asymptotic behavior of the solutions of differential equations. This principle is an important extension of the method

of Liapunov functions. To motivate the procedure and to bring out some of the essential ideas, we begin with a very elementary example.

Let us consider the scalar equation

$$\dot{x} = x + f(t, x)$$

where f (t, x) is continuous, smooth enough to ensure the uniqueness of solutions and there is a continuous, nondecreasing function K(a), a > 0, constants k E [0,1), a0 > 0, such that

(6.2) 
$$\begin{aligned}
\sigma K(\sigma) &\leq k\sigma^2 & \text{for } \sigma \geq \sigma_0 \\
|f(t,x)| &\leq K(\sigma) & \text{for } t \geq 0, |x| \leq \sigma.
\end{aligned}$$

The objective is to show that hypotheses (6.2) imply that Eq. (6.1) has a solution which exists and is bounded for t > 0.

If V(x) = x2/2, then the derivative V of V along the solutions of Eq. (6.1) satisfy

(6.3) 
$$\dot{V}(x) = x^2 + xf(t,x) \ge (1-k)|x|^2$$

if Ixl > ao. Consequently, on the set IxI = a0, the vector field behaves as depicted in the accompanying figure.

![](_page_343_Picture_11.jpeg)

If x(t,x0) designates the solution of Eq. (6.1) satisfying x(0,x0) = x0, let

$$S_+^* = \{x_0 \in R : |x_0| \le \sigma_0 \text{ and there is a } \tau \text{ with } x(\tau, x_0) = \sigma_0\}$$

$$S_{-}^* = \{x_0 \in R : |x_0| \le \sigma_0 \text{ and there is a } \tau \text{ with } x(\tau, x_0) = -\sigma_0\}$$

$$S^* = S_+^* \cup S_-^*$$

The set S\* represents the initial values of all those solutions with initial value xo in { I x I < go} which leave the region { I x I < ao } at some time, S\* the ones which leave at the top of the rectangle and S\_\* those that leave at the bottom of the rectangle.

Clearly ao E S+, -ao E S\_\*. It is also intuitively clear that S\* [-ao,ao] by the way some paths want to go to the top and some to the bottom. Let us make this precise.

We prove first that St are open in [-ao,ao] . If xo, E S\*, let r be chosen so that Ix(r,xo)I = ao. Inequality (6.3) implies there is an e > 0 such that Ix(t,xo)I > ao for r < t < r + e. Choose a neighborhood Uof x(r + e,xo) such that y E U implies IyI > ao. By continuous dependence on initial data, there is a neighborhood V of xo, V C [-ao,ao] of xo such that, for every z in V, there is a T(z) such that the solution x(t,z) satisfies x(r(z),z) in U. In particular, Ix(T(z), z) I > ao. Consequently, there is a r(z) such that I x(r(z), z) I = ao. This proves S\* are open in [-ao,00] .

Obviously, S+ rl S\_\* \_ . Thus, [-uo, ao ] \S \* is not empty. This is equivalent to saying that there is an xo E [-ao,ao] such that the solution x(t,xo) exists and satisfies I x (t, xo) I < ao for t > 0, as was to be shown.

Let us now generalize these ideas to n-dimensions. Suppose c is an open set in R x R", f : s2 R12 is continuous and the solution o(t, to, xo), o(to, to, xo) = xo, of the n-dimensional system

$$(6.4)$$
 
$$\dot{x} = f(t, x)$$

depends continuously upon (t, to, xo) in its domain of definition.

For notation, let P designate a representative point (t, x) of E2, (a(P),13(P)) designate the maximal interval of existence of the solution ((t,P) through P,I(t,P) = (t,O(t,P)) be the point on the trajectory through P at time t, and for any interval I C (a(P),(3(P)), let fi(I,P) = 0(t,P) = (t,ct(t,P)), t E I} be that part of the trajectory through P corresponding to t in I. Let co C 12 be a fixed open set, w be the closure of w in 92, and let aw denote the boundary of co in 92.

Definition 6.1. A point Po E aw is a point of egress from w with respect to Eq. (6.4) and the set 0 if there is a S > 0 such thatcF([to -5,to),Po) C co. An egress point Po is a point of strict egress from w if there is a 5 > 0 such that I((to, to + 5 ] ,Po)' C S2\ w. The set of points of egress is denoted by S and the points of strict egress by S \*.

Definition 6.2. If A C B are any two sets of a topological space and K:B -A is ' continuous, K(P) = P for all Pin A, then K is said to be a retraction from B to A and A is a retract of B.

With these definitions, we are in a position to prove the following result known as the principle of Wazewski.

THEOREM 6.1. If S =S\* and there is a set Z C w U S such that Z C S is a retract of S but not a retract of Z, then there exists at least one point PO in Z\S such that([t0,a(P0)),P0) C w.

PROOF. For any point P0 in w for which there is a r E [t0,(i(P0)] such that (D(r,PO) is not in w, there is a first time tpo for whichd)(tpo ,P0) is in S, 4)(t, PO) is in w for t in [t0, tpo ). The point (D(tp0 ,P0) is called the consequent of P0 and denoted by C(P0). The set of points in w for which a consequent exists is designated by G, the left shadow of S.

Suppose now S = S \* and define the map K :G U S - S, K(P) = C(P) for P E G, K(P) = P for P E S. We prove K is continuous. If P E w and C(P) = (tp,¢(tp,P)), then S = S\* implies there is a S > 0 such thatc((tp - S,tp),P ) C w, (D((tp,tp + S),P) C SZ\w. Since O(s,P) is continuous in (s,P), for any e> 0, there is an 11 > 0 such that 10(s Q) - O(s,P) I < e for s E (tp - S, tp + S) if I Q - P I < t . This clearly implies that C(Q) - C(P) if Q -> P. If P is in S = S \*, then one repeats the same type of argument to obtain that K is continuous.

If the conclusion of the theorem is not true, then Z\S C G, the left shadow of S. Thus, Z C G U S. Since Z n S is a retract of S, there is a mapping H:S-+Zfl S such thatH(P) =P ifPis in ZfS.ThemapHK:GUS-+ZnS is continuous, (HK)(P) = P if P is in Z n S. Thus G U S is a retract of Z fl S. Since Z C G U S, the map HK : Z - Z fl S is a retraction of Z onto Z fl S. This contradiction proves the theorem.

As an example, consider the second order system

Since K is continuous, K is a retract of G U S into S.

(6.5) 
$$\dot{x} = f(t, x, y)$$

$$\dot{y} = g(t, x, y)$$

for (t, x, y) E 92 = {t> 0, x, y in R }. Let w= { (t, x, y) : t > 0 , I x I < a, l y l <b} , where a > 0, b > 0 are fixed constants. Suppose

(6.6) 
$$xf(t, x, y) > 0 on |x| = a, |y| < b, yg(t, x, y) < 0 on |x| < a, |y| = b.$$

For the set w, we have S = S \* = {(t, x, y) : t > 0, I x I = a, IyI < b}. Let Z = {(t, x, y) : t = 0, y = 0, Ix I < a}. Then Z fl S is clearly a retract of S. However, Z fl S is not a retract of Z. Thus, Theorem 6.1 implies there is a solution of Eq. (6.5) which remains in w for t > 0.

EXERCISE 6.1. Generalize the previous example by replacing the conditions (6.6) on f,gby the following:

$$\omega = \{(t, x, y) : t \ge 0, |x| < u(t), |y| < v(t), u, v \text{ continuous}$$
together with their first derivatives  $u', v'\}$ 

$$xf(t,x,y) > u(t)u'(t) \qquad \text{on } |x| = u(t), |y| < v(t)$$

$$yg(t,x,y) < v(t)v'(t) \qquad \text{on } |x| < u(t), |y| = v(t).$$

Give some examples of u, v, f, g which satisfy these conditions and interpret your results in these special cases.

EXERCISE 6.2. Let H j :R X R" -+ R, j = 1,2, ... , m be continuous together with (heir first derivatives and let Hj (t0, x0) be the derivative of Hj(t, x(t, x(t, t0, x0)) at (to, x0) along the solutions of the Eq. (6.4). Define

$$\omega = \{(t, x) \text{ in } R^{n+1} : H_j(t, x) < 0, \qquad j = 1, 2, \dots, m\}$$

$$\Gamma_k = \{(t, x) \text{ in } R^{n+1} : H_k(t, x) = 0, H_j(t, x) \le 0, \qquad j = 1, 2, \dots, m\}.$$

The I'k are called the faces of w. Suppose for each k = 1,2, . . . ,m, and each (t, x) E Fk, either

(a) 
$$\dot{H}_k(t,x) > 0$$

O'

(b) 
$$(t,x)$$
 is not a point of egress.

Let Lk = {(t, x) in Fk satisfying (a)}, Mk = {(t, x) in Fk satisfying (b)}. Prove S=S\*=Uk 1Lk\Uk=1Mk

EXERCISE 6.3. One can use the results in Exercise 6.2 to prove results on the asymptotic equivalence of systems. Consider the two systems

(6.7) 
$$\dot{x}_j = f_j(t)x_j + g_j(t,x), \qquad j = 1,2,\ldots,n,$$

(6.8) 
$$\dot{y}_j = f_j(t)y_j, \qquad j = 1, 2, \dots, n.$$

Suppose g= (gl' g.), f = (fl, . . fn) are continuous for t> T,(t,x)ES2 = {(t, x) : T < t < -,x in R'} and a unique solution of Eq. (6.7) exists through each point in S2. If there exists a continuous function F: [T,°°) - [0,°°) and constant K such that

$$K \leq \int_{t}^{v} f_{j}(s)ds, \qquad v \geq t \geq T,$$

$$\int_{-\infty}^{\infty} F(t) \exp\left(\int_{T}^{t} f_{j}(s)ds\right)dt < \infty, \qquad j = 1, 2, \dots, n,$$

$$|g(t,x)| \leq |x|F(t) \text{ on } \Omega$$

then, for every solution y of Eq. (6.8), there is a solution x of Eq. (6.7) such that

$$\lim_{t\to\infty} [x(t) - y(t)] = 0.$$

EXERCISE 6.4. Consider the second order equation

$$(6.9) \qquad \qquad \ddot{x} + f(t, x, \dot{x}) = 0$$

where f (t, x, y) is continuous for t > 0, x, y in R'2 and a uniqueness result holds for the initial value problem for Eq. (6.9),

$$x \cdot f(t, x, y) + y \cdot y > 0$$
 for all  $t \ge 0, x$  in  $\mathbb{R}^n, y \ne 0$  in  $\mathbb{R}^n$ .

Then there exists a family of solutions of Eq. (6.9) depending on at least n parameters such that, for any solution x in this family, there is a to > 0 such that x (t) x (t) is nonincreasing for t > t0. Hint: Let b > 0, wb = {(t, x, y) in R21 x, y) < 0, m(t, x, y) < 0} where Q (t, x, y) = x y - b, m(t, x, y) \_ -t-Let Zb be a line segment joining points (t0, i '71),(t0,t2,n12) in distinct components of the set {(t, x, y) in R n+ I :x , y = b, t > 0} with (t0,0,0) not in Zb. The principle of Wazewski yields a solution such that x(t)z(t) < b for t > to. To show x(t)x(t) <0, take a sequence bm - 0.

### X.7. Remarks and Suggestions for Further Study

The main topic in the previous pages has been the application of the direct method of Liapunov to the determination of the stability of solutions of specific differential equations as well as the application of this method to the deduction of qualitative implications of the concept of stability. This chapter should serve only as an introduction and more extensive discussions may be found in Hahn [1], Krasovskii [1], LaSalle and Lefschetz [1], Halanay [1], Yoshizawa [2], Zubov [1]. The definition of Liapunov function used in Sections 1 and 3 may be found in LaSalle [2]. Theorem 1.1, Lemma 1.5 and Theorem 3.1 are due to Liapunov [1], Theorem 1.2 is essentially due to Cetaev [1], Exercise 1.5 to Hartman [2]. Section 2 is based on the paper of Moser [1]. The idea for the proofs of the converse theorems in Section 4 is due to Massera [1].

The basic idea of the direct method of Liapunov is applicable to systems described by functional differential equations as well as partial differential equations. For a discussion of functional differential equations as well as further references, see Krasovskii [1], Halanay [1], Hale [8], Cruz and Hale [1]. For partial differential equations, see Zubov [1], Infante and Slemrod [1].

The formulation of the topological principle in Section 6 was given by Wazewski [ 1 ] although the idea had been used on examples before (see Hartman [1] for more details). Exercise 6.2 is due to Onuchic [1], Exercise 6.3 to Onuchic' [2]. Further extensions of the ideas of Wazewski and a more general theory of isolating blocks may be found in Conley [1].

## Appendix. Almost Periodic Functions

In this appendix, we have assembled the information on almost periodic functions which is relevant for. the discussion in the. text. Only the most elementary results are proved. More details may be found in the following books.

- [A.1] H. Bohr, Almost Periodic Functions, Chelsea, New York, 1947.
- [A.2] A. S. Besicovitch, Almost Periodic Functions, Dover, New York, 1954.
- [A.3] J. Favard, Fonctions presque-periodiques, Gauthier-Villars, Paris, 1933.
- [A.4] A. M. Fink, Almost Periodic Differential Equations, Lecture Notes in Math., Vol. 377(1974), Springer-Verlag.
- [A.5] B. M. Levitan, Almost Periodic Functions (Russian) Moscow, 1953.
- [A.6] T. Yoshizawa, Stability Theory and the Existence of Periodic Solutions and Almost Periodic Solutions, Applied Mathematics Sciences, Vol. 14(1975), Springer-Verlag.

The books of Fink and Yoshizawa are very good presentations of the theory of almost periodic functions and differential equations. The presentation below follows these two books.

Notation. a,0.... will denote sequences {an}, {(3,n}, ... in R. The notation 0 C a denotes R is a subsequence of a, a + 0 = {an + (ifz }, -a = {-an }. We say a,3 are common subsequences of a',/3' if an = an(k), On =1n(kj for some function n(k), k = 1,2, .... If f,g are functions on R and a is a sequence in R, then Taf = g means limn, f (t + an) exists and is equal to g(t) for all t E R. The type of convergence (uniform, pointwise, etc.) will be specified when used. For example, we will write Ta f = g pointwise, Ta f = g uniformly, etc. All functions considered will be continuous and complex valued functions on R unless explicitly stated otherwise.

Definition 1. f is almost periodic if for every a' there is an a C a' such that T, ,,f exists uniformly.

If AP = {f :f is almost periodic}, If[ = sups If(t) I if f E AP, then AP with this norm is a normed linear space. It will be shown to be complete later.

LEMMA 1. Every periodic function is AP.

PROOF. If T is the period of f and  $\alpha'$  is a sequence, then there exists an  $\alpha \subset \alpha'$  such that  $\alpha \pmod{T} = \{\alpha_n \pmod{T}\}$  converges to a point  $\delta$ . Then  $T_{\alpha}f = f(\cdot + \delta)$  uniformly.

LEMMA 2. Every almost periodic function is bounded.

PROOF. If not, there is a sequence  $\alpha' \subset R$  such that  $|f(\alpha'_n)| \to \infty$  as  $n \to \infty$ . But  $f \in AP$  implies there is an  $\alpha \subset \alpha'$  such that  $T_{\alpha}f$  exists uniformly. In particular,  $f(\alpha_n)$  converges which contradicts our supposition.

THEOREM 1. (Properties of almost periodic functions)

- (1) AP is an algebra (closed under addition, product and scalar multiplication).
  - (2) If  $f \in AP$ , F is uniformly continuous on the range of F, then  $F \cdot f \in AP$ .
  - (3) If  $f \in AP$ ,  $\inf_t |f(t)| > 0$ , then  $1/f \in AP$ .
  - (4) If  $f,g \in AP$ , then  $|f|, \overline{f}, \min(f,g), \max(f,g) \in AP$ .
  - (5) AP is closed under uniform limits on R.
  - (6)  $(AP, |\cdot|)$  is a Banach space.
  - (7) If  $f \in AP$  and df/dt is uniformly continuous on R, then  $df/dt \in AP$ .

PROOF. We prove this theorem in detail since it is simple and illustrates the way subsequences are used in Definition 1.

- (1) If  $f,g \in AP$  and  $\alpha'' \subset R$ , there exists  $\alpha' \subset \alpha''$  such that  $T_{\alpha'},f$  exists uniformly,  $T_{\alpha'},af$  exists uniformly for any complex number a. Also there exists  $\alpha \subset \alpha'$  such that  $T_{\alpha}g$  exists uniformly. Thus,  $T_{\alpha}(f+g)$  exists uniformly,  $T_{\alpha}(fg) = (T_{\alpha}f)(T_{\alpha}g)$  exists uniformly.
- (2) If  $f \in AP$  and F is uniformly continuous on the range of f, then, for any  $\alpha' \subset R$ , there exists  $\alpha \subset \alpha'$  such that  $T_{\alpha}(F \cdot f) = F \cdot T_{\alpha} f$  uniformly.
- (3) If  $\inf_t |f(t)| > 0$ , then 1/z is uniformly continuous on the range of f and  $1/f \in AP$ .
- (4) The same argument proves  $|f|, \overline{f} \in AP$  if  $f \in AP$  by using the function F(z) = |z|, z, respectively. Since

$$\min(f,g) = \frac{1}{2} [(f+g) - |f-g|], \qquad \max(f,g) = \frac{1}{2} [(f+g) + |f-g|],$$

the remainder of (4) is proved by using (1).

(5) Suppose  $\{f_n\} \subset AP$ , f continuous,  $|f_n - f| \to 0$  as  $n \to \infty$ . For any  $\alpha' \subset R$ , there exists  $\alpha' \supset \beta' \supset \cdots \supset \beta^n \supset \cdots$  such that  $T_{\beta} n f_n$  exists uniformly,  $n = 1, 2, \ldots$ . Use the diagonalization process to obtain  $\beta \subset \alpha'$  such that  $T_{\beta} f_n$  exists uniformly for all  $n = 1, 2, \ldots$ .

For any  $\epsilon > 0$ , three is a  $k_0(\epsilon)$  such that, for  $n = 1, 2, \ldots, k \ge k_0(\epsilon)$ ,  $t \in R$ 

$$|f(t+\beta_n)-f_k(t+\beta_n)|<\epsilon/3.$$

For a fixed k> ko(e) choose N(k,e) such that, for n, m >N(k, e), t E R

$$|f_k(t+\beta_n)-f_k(t+\beta_m)| < \epsilon/3.$$

Then, for n, m > N(k, e), t E R,

$$|f(t+\beta_n) - f(t+\beta_m)| \le |f(t+\beta_n) - f_k(t+\beta_n)| + |f_k(t+\beta_n) - f_k(t+\beta_m)| + |f_k(t+\beta_m) - f(t+\beta)| < \epsilon.$$

Thus, TRf exists uniformly and f E AP.

- (6) This is obvious from (1) and (5).
- (7) If fn(t) = n[f(t + 1/n) f(t)] , then the mean value theorem implies

$$f'(t) - f_n(t) = f'(t) - f'(t + \theta(t, n))$$

for some t < 6(t, n) < t + 1/n. Since f'(t) is uniformly continuous, we have fn(t) - f'(t) uniformly on R. Since each fn CAP, we have from (5) that f'EE AP. This completes the proof of the theorem.

The space AP contains all periodic functions. Theorem 1 shows that it contains all functions which are sums of periodic functions and thus all trigonometric polynomials. It also contains the uniform limit of trigonometric polynomials. One can actually show (but the proof is not trivial) that AP consists precisely of functions which are uniform limits of trigonometric polynomials.

To obtain other characterizations of almost periodic functions, we need the following concept.

Definition 2. The hull of f,H(f), is defined by

H(f) = {g: there is an a C R such that TQ f = g uniformly}

If f is periodic, then H(f) consists of all translates of f; that is,

$$H(f) = \{f_{\tau} : f_{\tau}(t) = f(t+\tau), t \in R, \tau \in R\}$$

and thus, H(f) is a closed curve in AP if f is periodic. If f E AP, then H(f) may contain elements which are not translates of f. In fact, if f (t) = cos t + cost, then f E AP since it is the sum of periodic functions, but is not periodic since it takes the value 2 only at t = 0. Also, f (t) > -2 for all t and there is an a' = {an } C R such that f (an) - -2. If a C a and TQ f = g uniformly, then g(0) = -2 and g cannot be a translate off.

THEOREM 2. f E AP if and only if H(f) is compact in the topology of uniform convergence on R. Furthermore, if f E AP then H(g) = H(f) for all gEH(f).

PROOF. If H(f) is compact, then for any a CR, there is an a C a' such that Ta f exists uniformly and, thus f E AP.

Conversely, if f E AP, {.5n } C H(f), then there is an a' such that I f (' + an) - gn I < 1/n (we have used the diagonalization process here). Also, there is an a C a' such that Ta f = g exists uniformly. If a = {an } = {akn }, then If( +an) -gknI - 0asn- -.Thus,

$$|g - g_{k_n}| \le |g - f(\cdot + \alpha_n)| + |f(\cdot + \alpha_n) - g_{k_n}| \to 0$$

as n . Thus, H(f) is compact.

To prove the last part of the theorem, if g E H(f) and h E H(g); that is, there is an a = {an} C R such that Tag = h uniformly, then there is a 0 = {on} such thatI If ( + (3n) - g( + an)I < 1/n. Thus, Tpf = h and hEH(f); that is, H(g) C H(f). Conversely, if g E H(f), Taf = g, then T\_ag= f by the change of variables t + an = s. Thus, f E H(g). Since H(g) is compact, this implies H(f) C H(g). Finally, we have H(f) = H(g) and the theorem is proved.

To obtain another characterization of an almost periodic function, we need the following definitions.

Definition 3. A subset S C R is relatively dense if there is an L > 0 such that [a, a+ L] fl S 0 for any a E R.

Definition 4. If f is any continuous complex valued function on R, the e-translation set of f is defined as

$$T(f,\epsilon) = \{\tau : |f(t+\tau) - f(t)| < \epsilon \quad \text{for } t \in R\}.$$

Definition 5. A continuous complex valued function f on R is Bohr almost periodic if for every e> 0, T(f,e) is relatively dense.

Lemma 3. A Bohr almost periodic function is bounded and uniformly continuous.

PROOF. If f (t) is almost periodic, then for any 7) > 0, there exist an 1 and a r in every interval [t -1, t] such that

$$|f(t)-f(t-\tau)|<\eta \quad \text{for all } t \text{ in } (-\infty, \infty).$$

If we let V= t - T then 0:!9 t'< 1 and If (t) -f (t')j <,q. If If (t')l < B for 0 <- t' <\_ l then I f (t) I < B + 71 for all t in (-oo, oo). This proves boundedness.

Suppose q7, l are as above. Since f is continuous, it is uniformly continuous on [-1, 1] and we can find a 8 <1 such that

$$|f(t_1') - f(t_2')| < \eta \qquad \text{if} \qquad |t_1' - t_2'| < \delta, \, t_1', \, t_2' \in [-l, \, l].$$

For any ti, t2 with tl < t2, I ti - t2 l < S, consider the interval [t1, tr + 1]. Let T be an almost period relative to 77 in this interval. Then t',= tl - T, t2 = t2 - T are

in'[-l, l] and I f (ti) -f (ti)I <7), ( f (t2) -f (t2)1 < "1. The triangle inequality shows that I f (tl) - f (t2)I < 3-q and this proves uniform continuity.

THEOREM 3. The following statements are equivalent:

- (i) f E AP
- (ii) H(f )'is compact in the topology of uniform convergence on R.
- (iii) f is Bohr almost periodic.

PROOF. We have already proved (i) - (ii). We next prove (iii) - (i). Suppose a C R. We first show that, for any e > 0, there is an a C a' such that

$$|f(t+\alpha_n)-f(t+\alpha_m)| < \epsilon$$
 for all  $n, m$ 

Let L be as in the definition of relatively dense for T(f, " ), and choose S from Lemma 1 so that I f (t) - f (s) I < e if I t - s I < 28. We may write the sequence a = { an } as an = On + y., an E T(f, 6 ), 0 < 7n < L, 7n - 7 as n - °°, y-S <,yn <y+S. Then

$$|f(t+\alpha_n)-f(t+\alpha_m)| \le |f(t+\beta_n-\beta_m+\gamma_n-\gamma_m)-f(t-\beta_m+\gamma_n-\gamma_m)|$$

$$+|f(t-\beta_m+\gamma_n-\gamma_m)-f(t+\gamma_n-\gamma_m)|$$

$$+|f(t+\gamma_n-\gamma_m)-f(t)| < \epsilon \qquad \forall t \in R.$$

Now use the diagonalization process to get a" C a C a' such that Ta " f exists uniformly.

We now prove (ii) - (iii). H(f) compact is equivalent to H(f) totally bounded is equivalent to (f (t + 7-):7- E R} totally bounded is equivalent to, for any e > 0, there are al, . . . an and a function i(t) from R to {1, . . . ,n} such that I f (t + af (,)) - f (t + r) I < e for all t, r. This is equivalent to

$$|f(t)-f(t+\tau-a_{i(\tau)})| < \epsilon$$
 for all  $t$ .

If L = max Ia I , then r - L <,r - a;(,) < r + L and r - ai(,r) E T(fe).Thus, T(f,e) is relatively dense with constant 2L.

This completes the proof of the theorem.

THEOREM 4. f E AP if and only if

(iv) For any a', /3' C R, there are common subsequences a C a', 0 C (3' such that

$$T_{\alpha+\beta}f = T_{\alpha}T_{\beta}f$$
 pointwise.

PROOF. Suppose f E AP, a', 0' C R are given and choose 0" C /3' such that T f = g uniformly. Since g E AP, for a" C a' common with Q", there is an a" C a" such that T«'.-g = h uniformly. Let C 9" be common with a"'. Then we can find common subsequences, a C al", 0 C R"' such that Ta+ p f = k

uniformly and also note Tgf = g, Tag = h uniformly. If e > 0 is given, then, there is a no such that, for all n > no and all t,

$$|k(t) - f(t + \alpha_n + \beta_n)| < \epsilon, |g(t) - f(t + \beta_n)| < \epsilon, |h(t) - g(t + \alpha_n)| < \epsilon$$
Thus, for  $n \ge n_0$ ,

$$|h(t) - k(t)| \le |h(t) - g(t + \alpha_n)| + |g(t + \alpha_n) - f(t + \alpha_n + \beta_n)|$$
$$+ |f(t + \alpha_n + \beta_n) - k(t)| < 3\epsilon$$

Since a is arbitrary, h = k; i.e. Ta+Rf = TaTTf uniformly and, in particular, pointwise.

To prove (iv) implies f E AP, suppose y' C R. Then there is a y C 'y' such that Tyf exists pointwise. In fact, for a' = {0}, 0' = y', we know there are common subsequences a C a', y C y' such that Ta+yf = TaTyf pointwise. Since a = {0}, this proves the assertion. Suppose that Tyf does not exist uniformly. Then there exist a' C (3, (31' C y, r' C R, e > 0

$$(*) |f(\alpha'_n + \tau'_n) - f(\beta'_n + \tau'_n)| \ge \epsilon.$$

Apply condition (iv) to a',r to obtain common subsequences a' C a', T" C r such that TT"+a"f = T,""Ta"f pointwise. Choose (3" C /3' common to a",r" and apply (iv) to /3",T" to find 0 C /3", r C T" such that T,+Rf = T,TRfpointwise. Choose a + a" common to 0j.. Then T,+a f = T, Ta f pointwise from above. But Ta f = Tyf = TR f pointwise, since a C y, /3 C 'y. Thus, T,+af = TTTJ.f = T,TRf = T,+o f pointwise. At t = 0, this contradicts (\*) since T + 0 C T' + /3" T + a C T' + a'. Thus, the convergence is uniform.

This completes the proof of the theorem.

A remarkable consequence of Theorem 3 is that almost periodicity can be decided by discussing only pointwise convergence as in (iv). This is generally easier to check than uniform convergence on R.

From Proposition 1 and Theorem 1, the space AP contains all trigonometric polynomials and all uniform limits of trigonometric polynomials. The converse is also true and is stated without proof.

THEOREM 5. f E AP if and only if f can be uniformly approximated by trigonometric polynomials.

It is natural to investigate the problem of the existence of a theory of trigonometric series for almost periodic functions analogous to the theory of Fourier series for periodic functions. The first fundamental result is

THEOREM 6. If f EAP, then the mean value

$$M[f] = \lim_{T \to \infty} \frac{1}{T} \int_{t}^{t+T} f(s) ds$$

exists, is independent of t and the convergence is uniform in t.

If fEAP, then fexp E AP for any real number A. Define

$$a(\lambda, f) = M[fe^{-i\lambda^*}] = \lim_{T \to \infty} \frac{1}{T} \int_0^T f(t)e^{-i\lambda t} dt$$

The set

$$\Lambda(f) = \{\lambda \in R : a(\lambda, f) \neq 0\}$$

is called the set of Fourier exponents of f, the numbers a(A,f), A E A(f), the Fourier coefficients and the Fourier series off is designated by

$$f(t) \sim \sum_{\lambda \in \Lambda(f)} a(\lambda, f) e^{i\lambda t}$$
.

Then, one can prove

THEOREM 7. A(f) is denumerable. If f,g E AP, then f = g if and only if A(f) = A(g) and a(X, = a(X,g) for A E A(f). If f ExEA;(f)a(A,f)exp(iAt), then ExCA(f)Ia(A,f)I < -. The usual operations on Fourier series are valid.

For any sequence {X,,} C R, the module of {X,,} is the set consisting of all real numbers which are finite linear combinations of the {An} with integer coefficients. We say {aj} C R is linear independent over the rationals if, for every N > 1 , ZkN= Irkajk = 0 for each r k rational implies r k = 0, k = 1, 2, ... N. The sequence {aj} is said to be an integral base for {An} if {aj} is linearly independent over the rationals and if each element of {An} is a finite linear combination of the {aj} with integer coefficients. If f E AP, the module m[f] of f is the module of A(f). A function f E AP is called quasiperiodic if there exist an integer N > 1, positive real numbers TI, . . . ,TN and a function F on RN such that F(x1,... xN) is periodic in xj of period Tj, j = 1,2, ... N such that f (t) = F(t, . . . ,t).

Example 1. If f is periodic of period 27r/w, then m[f] \_ {nw,n=0,±1, ...} and an integral base for m[f] in {w}.

Example 2. If f(t) = cost + cos2t + cost, then A(f) \_ {1,2,\}, m[f] = {n + m om, n, m = 0,±1, ... } and an integral base for m[f] is {1, V}. This function f is quasiperiodic with

$$f(t) = F(t,t), F(x_1, x_2) = \cos x_1 + \cos 2x_1 + \cos \sqrt{2}x_2.$$

Example 3. If En= I I an I < -, an \*0 for all n, then

$$f(t) = \sum_{n=1}^{\infty} a_n e^{it/n}$$

is in AP, A(f) = {1/n, n = 1,2.... }. What is m[f] and what is an integral base for m[f] ?

The following result is basic for differential equations. The proof is complicated and contained in Fink, p. 61. In the statement of the theorem, "convergence in any sense" may be interpreted as "pointwise-convergence," "uniform convergence on compact sets," "uniform convergence" or "mean convergence"; that is,  $f_n$  converges to f in the mean if  $M(|f_n - f|^2) \to 0$  as  $n \to \infty$ .

THEOREM 8. For  $f, g \in AP$ , the following statements are equivalent:

- (i)  $m[f] \supset m[g]$
- (ii) for any  $\epsilon > 0$ , there is a  $\delta > 0$  such that  $T(f,\delta) \subset T(g,\epsilon)$
- (iii)  $T_{\alpha}f$  exists implies  $T_{\alpha}g$  exists (any sense)
- (iv)  $T_{\alpha}f = f$  implies  $T_{\alpha}g = g$  (any sense)
- (v)  $T_{\alpha}f = f$  implies there exists  $\alpha' \subset \alpha$  such that  $T_{\alpha'}g = g$  (any sense).

In the study of almost periodic differential equations, one encounters frequently the simple equation  $\dot{y} = f(t)$  where  $f \in AP, M[f] = 0$ . For f periodic, this equation always has a periodic solution. However, when  $f \in AP, M[f] = 0$ , this may not be the case. In fact,

$$f(t) \sim \sum_{n=1}^{\infty} \frac{1}{n^2} e^{it/n^2}$$

is in AP, M[f] = 0. However, if  $\int_{-\infty}^{t} f$  is in AP, then

$$\int_{0}^{t} f \sim (\text{constant}) + \sum_{n=1}^{\infty} (-i)e^{it/n^2}$$
.

However, this latter function is not in AP since the sum of squares of the Fourier coefficients does not exist.

The following result is known about the integral of an almost periodic function.

THEOREM 9. If  $f \in AP$ , then  $\int^t f$  is in AP if and only if it is bounded.

In the applications to differential equations, this proposition generally cannot be applied.

The next result due to Bogoliubov [1] is concerned with an AP approximation to the solution of the equation  $\dot{y} - f(t) = 0$  when f is AP, has M[f] = 0 and does not necessarily have a bounded integral.

LEMMA 4. Suppose f is in AP, M[f] = 0. For every  $\eta > 0$ , there is a continuous scalar function  $\zeta(\eta)$ ,  $0 < \eta < \infty$ ,  $\zeta(\eta) \to 0$  as  $\eta \to 0$  such that the almost periodic function  $f_{\eta}$  defined by

(1) 
$$f_{\eta}(t) = \int_{-\infty}^{t} e^{-\eta(t-s)} f(s) ds$$

satisfies

(2) (a) 
$$|f_{\eta}(t)| \leq \eta^{-1} \zeta(\eta)$$
,

(b) 
$$|df_{\eta}(t)/dt - f(t)| \leq \zeta(\eta)$$
,

for all t in R. Also,  $m[f_n] \subset m[f]$ .

PROOF. Since M[f] = 0, there is a continuous nonincreasing scalar function  $\varepsilon(T)$ ,  $0 < T < \infty$ ,  $\varepsilon(T) \to 0$  as  $T \to \infty$  such that  $|T^{-1}\int_t^{t+T} f(s) ds| \le \varepsilon(T)$  for all t in R. Furthermore, for any T > 0,

$$f_{\eta}(t) = \int_0^\infty e^{-\eta s} f(t-s) ds$$
  
=  $\sum_{k=0}^\infty e^{-\eta kT} \int_{kT}^{(k+1)T} f(t-s) e^{-\eta(s-kT)} ds$ .

If B is a bound for |f(t)| on  $(-\infty, \infty)$ , then the above relation yields

$$\begin{split} |f_{\eta}(t)| & \leq \sum_{k=0}^{\infty} e^{-\eta kT} \bigg| \int_{kT}^{(k+1)T} f(t-s) \, ds \, \bigg| \\ & + B \sum_{k=0}^{\infty} e^{-\eta kT} \int_{kT}^{(k+1)T} \left(1 - e^{-\eta (s-kT)}\right) \, ds \\ & \leq \sum_{k=0}^{\infty} e^{-\eta kT} \varepsilon(T) T + B \int_{0}^{T} \left(1 - e^{-\eta s}\right) \, ds \sum_{k=0}^{\infty} e^{-\eta kT} \\ & \leq \varepsilon(T) T [1 - e^{-\eta T}]^{-1} + BT. \end{split}$$

Since  $\varepsilon(T) \to 0$  as  $T \to \infty$  and is nonincreasing, there always exists a unique solution to the equation  $1 - e^{-\eta T} = \varepsilon(T)$ . Suppose  $T_{\eta}$  is chosen to be this solution. Since  $\varepsilon(T) > 0$  for all T, it is clear that  $T_{\eta} \to \infty$  as  $\eta \to 0$  and this together with the fact that  $\varepsilon(T) \to 0$  as  $T \to \infty$  imply that  $\eta T_{\eta} \to 0$  as  $\eta \to 0$ . The solution  $T_{\eta}$  is obviously continuous in  $\eta$ . If we let  $\zeta(\eta) = (B+1)\eta T_{\eta}$ , then relation (2a) is proved.

From (1), it follows that

(3) 
$$\frac{df_{\eta}(t)}{dt} - f(t) = -\eta f_{\eta}(t),$$

and therefore, (2b) follows from (2a).

It remains to show that  $f_{\eta} \in AP$ . Suppose  $\alpha' \subset R$ . Since  $f \in AP$ , there is a sequence  $\alpha \subset \alpha'$  such that  $T_{\alpha}f$  exists uniformly. Thus, for any  $\epsilon > 0$ , there is an  $N(\epsilon)$  such that

$$|f_{\eta}(t+\alpha_n) - f_{\eta}(t+\alpha_m)| \le \int_{-\infty}^{0} e^{\eta s} |f(t+s+\alpha_n) - f(t+s+\alpha_m)| ds$$

$$\le \epsilon \int_{-\infty}^{0} e^{\eta s} = \epsilon/\eta,$$

for  $n, m \ge N(\epsilon)$ . This shows  $f_{\eta} \in AP$ . The fact that  $m[f_{\eta}] \subset m[f]$  follows from Theorem 8. This proves the lemma.

We want to study almost periodic solutions of an almost periodic differential equation  $\dot{x} = f(t, x)$ . Thus, we need to know when  $f(t, \phi(t))$  is almost periodic if  $\phi \in AP$ . In general, this is not true. One can see this from the example  $f(t,x) = \sin xt$  by showing that  $f(t,\sin t) = \sin(t\sin t)$  is not uniformly continuous. The difficulty arises from the fact that the  $\epsilon$ -translation set for  $\sin xt$  is not well behaved in x.

An appropriate generalization of the definition of an almost periodic function depending on parameters is the following one.

**Definition 6.** A continuous function  $f: R \times D \to C^n$ , where D is open in  $C^n$ , is said to be *almost periodic in t* uniformly for  $x \in D$  if for any  $\epsilon > 0$ , the set  $\mathscr{T}(f,\epsilon) = \bigcap_{x \in K} T(f(\cdot,x),\epsilon)$  is relatively dense in R for each compact set  $K \subset D$ . Equivalently, if for any  $\epsilon > 0$ , and any compact set  $K \subset D$ , there exists  $L(\epsilon,K) > 0$  such that any interval of length  $L(\epsilon,K)$  contains a  $\tau$  with

$$|f(t+\tau,x)-f(t,x)| < \epsilon$$
 for all  $t \in R, x \in K$ .

One can then prove the following results (see Fink or Yoshizawa).

THEOREM 10. If f(t,x) is AP in t uniformly for  $x \in D$ , then f is bounded and uniformly continuous on  $R \times K$  for any compact set  $K \subset D$ .

THEOREM 11. If f(t,x) is AP in t uniformly for  $x \in D$ , then, for any  $\alpha' \subset R$ , there is an  $\alpha \subset \alpha'$  and a function g(t,x) which is AP in t uniformly for  $x \in D$  such that  $f(t + \alpha_n, x) \to g(t, x)$  uniformly on  $R \times K$  for any compact set  $K \subset D$ .

Conversely, if  $f: R \times D \to C^n$  is continuous and for any  $\alpha' \subset R$ , there is an  $\alpha \subset \alpha'$  such that, for any compact set  $K \subseteq D$ ,  $f(t + \alpha_n, x)$  converges uniformly on  $R \times K$ , then f(t, x) is AP in t uniformly for  $x \in D$ .

In general, functions AP in t uniformly for  $x \in D$  satisfy the same properties as before if convergence is always uniform on compact sets  $K \subset D$ .

THEOREM 12. If f(t,x) is AP in t uniformly for  $x \in D$ , and  $\xi \in AP$ ,  $\xi(t) \in K$ , a compact set of D, then  $f(\cdot) \in AP$ .

In the applications to differential equations, it is desirable to have an improvement of Lemma 4 in this more general situation. More specifically, one wants an approximating solution of the equation

$$\frac{\partial y}{\partial t} - f(t, x) = 0,$$

which is very smooth in x. One can apply Lemma 4 and more or less classical smoothing operators to achieve this end result. If  $M[f(\cdot, x)]$  denotes the mean value of f(t, x) with respect to t, then we have

Lemma 5. Suppose f(t,x) is AP in t uniformly with respect to x in a set D containing the closed ball  $B_{\sigma} = \{x \text{ in } C^k : |x| \leq \sigma\}$ . If  $M[f(\cdot,x)] = 0$  for x in  $B_{\sigma}$  then for any  $\sigma_1 < \sigma$ , there are an  $\eta_0 > 0$  and a function  $w(t,x,\eta)$  defined and continuous for t in R, x in  $B_{\sigma_1}$ ,  $0 < \eta < \eta_0$ , which is almost periodic in t uniformly with respect to x in  $B_{\sigma_1}$  and  $\eta$  in any compact set of  $(0,\eta_0)$ ,  $m[w(\cdot,x,\eta)] \subset m[f(\cdot,x)]$ ,  $w(t,x,\eta)$  has derivatives of any desired order with respect to x and is such that, if

$$g(t, x, \eta) = \frac{\partial w(t, x, \eta)}{\partial t} - f(t, x),$$

then  $g(t, x, \eta)$ ,  $\eta w(t, x, \eta)$  and  $\eta \partial w(t, x, \eta)/\partial x$  approach zero as  $\eta \to 0$  uniformly with respect to t in R, x in  $B_{\sigma_1}$ . If, in addition, f(t, x) has continuous first partial derivatives with respect to x, then  $\partial g(t, x, \eta)/\partial x \to 0$  as  $\eta \to 0$  uniformly with respect to t in R, x in  $B_{\sigma_1}$ .

PROOF. From Lemma 4, it follows that there is a function  $f_{\eta}(t, x)$  defined by (1) which is a.p. in t uniformly with respect to x in  $B_{\sigma}$  and  $\eta$  in any compact set such that

(4) 
$$|f_{\eta}(t,x)| \leq \eta^{-1}\zeta(\eta),$$
 
$$\frac{\partial f_{\eta}(t,x)}{\partial t} - f(t,x) = -\eta f_{\eta}(t,x),$$

where  $\zeta(\eta) \to 0$  as  $\eta \to 0$ .

For a fixed a>0 and some fixed integer  $q\ge 1$ , consider the function  $\Delta_a(x)$  defined by

$$\Delta_a(x) = \begin{cases} d_a(1-a^{-2}|x|^2)^{2q} & & \text{for } |x| \leq a \\ 0 & & \text{for } |x| > a \end{cases}$$

where the constant  $d_a$  is determined so that  $\int_{B_{\sigma}} \Delta_a(x) dx = 1$ . Define  $w(t, x, \eta)$  by

(5) 
$$w(t, x, \eta) = \int_{B_{\sigma}} \Delta_a(x - y) f_{\eta}(t, y) dy.$$

It is easy to see that  $w(t, x, \eta)$  is a.p. in t uniformly with respect to x in  $B_{\sigma}$  and  $\eta$  in any compact set since  $f_{\eta}(t, x)$  has the same property.

The function  $\Delta_a(x-y)$  possesses continuous partial derivatives up through order 2q-1 with respect to x which are bounded in norm by a function G(a)/(area of integration) where G(a),  $0 < a < \infty$ , is continuous. The function G(a) may approach  $\infty$  as  $a \to 0$ . Therefore, from (4), the function  $w(t, x, \eta)$  defined by (5) has partial derivatives with respect to x up through order 2q-1 which are bounded by  $G(a)\zeta(\eta)\eta^{-1}$ . Since q is an arbitrary integer, the number of derivatives with respect to x may be as large as desired.

Choose  $a = a_{\eta}$  as a function of  $\eta$  in such a way that  $a_{\eta} \to 0$ ,  $G(a_{\eta})\zeta(\eta) \to 0$ 

as ,7 -\* 0. The conclusion of the lemma concerning qw(t, x, q) is therefore valid since ,7w, 778w/8x are bounded by G(a,,)t;(,7).

For any ai < a, choose ,lo so small that al + an < a for 0 < 77 <,70 . From the definition of Da(x), it follows that fB. 1 a (x - y) dy = 1 for every x in Bal, 0 <77 <'o. Therefore, from relations (4) and (5), it follows that

(6) 
$$\overline{g}(t, x, \eta) = \int_{B_{\sigma}} \Delta_{a_{\eta}}(x - y) [f(t, y) - f(t, x)] dy,$$

where g +,7w. From the definition of Da(x), it follows that

$$|g(t, x, \eta)| \leq \sup_{0 \leq |x-y| \leq a_{\eta}} |f(t, y) - f(t, x)|.$$

Since an --> 0 as '] -\* 0 and f (t, x) is uniformly continuous for t in R, x in Be,, there is a continuous function 8(77), 0 <,7 < 77o, 8(,7) -> 0 as ,7 -\* 0 such that

$$\sup_{0 \le |x-y| \le a_{\eta}} |f(t,y) - f(t,x)| < \delta(\eta).$$

Consequently, 1g(t, x, 77)1 < 8(7)) and jg(t, x, 771 < 8(r7) + and g satisfies the properties stated in the first part of the lemma.

If, in addition, f (t, x) has continuous first partial derivatives with respect to x, then an integration by parts in relation (6) yields

$$\frac{\partial \overline{g}(t,\,x,\,\eta)}{\partial x} = \int_{B_{\sigma}} \Delta_{a_{\eta}}(x-y) \left[ \frac{\partial f(t,\,y)}{\partial x} - \frac{\partial f(t,\,x)}{\partial x} \right] dy.$$

The same. type of argument as before shows that this expression is bounded by a function 81(,7) which approaches zero as ,7 -±0. This completes the proof of the lemma.

If, in Lemma 5, the function f (t, x) is periodic in some of the components of x, then the function w(t, x, 7)) can also be chosen periodic in these components with the same period.

If g is an n-vector and 0 is an r-vector, then g(c) is said to be multiply periodic in 0 with vector period w = (wi, ... , wr), wj > 0, j = 1, 2, ..., r, if the function g is periodic in the jth component of 0 with period wj. If g(O) is multiply periodic, then the function g(951 + t, ... , Or + t) is AP in t uniformly with respect to 0. It is therefore meaningful to define the mean value of this function with respect to t. This concept of mean value was first used in differential equations by S. Diliberto [1]. To simplify notations, let + t = (0i + t, ... , Or + t) and designate the above mean value by

(7) 
$$M_{\phi}[g(\phi)] = \lim_{T \to \infty} \frac{1}{T} \int_{0}^{T} g(\phi + t) dt.$$

To understand this concept a little better, consider the case where 0 is a two-vector, 0 = (0i, 02) and

$$g(\phi) \sim \sum_{j,k} a_{jk} e^{i(k\mu\phi_1+j\omega\phi_2)}$$
.

In usual treatises on multiply periodic functions, the mean value of g is the constant term in the Fourier series of g; that is, aoo. According to definition (7),

$$M_{oldsymbol{\phi}}[g(oldsymbol{\phi})] = \sum_{j,\;k:\;k\mu+j\omega=0} a_{jk}\,e^{i(k\mu\phi_1+j\omega\phi_2)}$$

and this could be a function of 0 if the frequencies p, w are such that µ/w is rational.

Lemma 5 has an appropriate generalization to the case of functions of the form g(t, 0, x) which are multiply periodic in the vector 0, AP in t, uniformly with respect to 0. in Cr and x in Ba and Mt,0[g(t, 0, x)] = 0. Under these conditions, for any al < a, there are an -qo > 0 and a function W(t, 0, x, r)), 0 < 7) < 77o, multiply periodic in 0, AP in t such that the function

$$G(t, \phi, x, \eta) = \frac{\partial W}{\partial t} + \sum_{j=0}^{r} \frac{\partial W}{\partial \phi_j} - g(t, \phi, x)$$

as well as sjW, 7)aW1asb, r W/ax -\*0 as q -3,-0 uniformly with respect to t in R, 95 in Cr, x in Ba1. If g(t, 0, x) has continuous first partials with respect to x, then the partial derivatives of G(t, 0, x, q) with respect to 0, x also approach zero as q -\* 0 uniformly with respect to t, 0, x. The proof of this fact is very similar to the proof of Lemma 5 and may be found in Hale [3].

## REFERENCES

- Andrd, J., and P. Seibert [1]. On after-endpoint motions of general discontinuous control systems and their stability properties. Proc. 1st Intern. IFAC Congr. Moscow 1960, II, 919-922.
- Andronov, A. A., S. E. Khaikin, and A. A. Witt [1]. Theory of Oseillator8, Pergamon Press, New York, 1966.
- Andronov, A. A. Leontovich, E. A., Gordon, I. I. and A. G. Maier [1], Theory of Bifurcations of Dynamic Systems on a Plane, John Wiley and Sons, 1973.
- Antosiewicz, H. [1]. Boundary value problems for nonlinear ordinary differential equations. Pac. J. Math. 17 (1966), 191-197. [2]. Un analogue du Principe du pointe file de Banach. Ann. Mat. Pura. Appl. (4) 74 (1966), 61-64. [3]. On an integral inequality. To appear.
- Arnold, V. I. [1]. Small denominators. I. Mapping the circle onto itself. Izv. Akak. Nauk SSSR Ser. Mat. 25 (1961), 21-86. [2]. Small denominators and problems of stability of motion in classical and celestial mechanics. U8pehi Mat. Nauk 18 (1963), no. 6(114), 91-192.

- a Arscott, F. M. [1]. Periodic Differential Equations. Pergamon Press, New York, 1964.
- Auslander, J. and W. H. Gottschalk [1]. Topological Dynamics. W. A. Benjamin, New York, 1968.
- Bailey, H. R. and L. Cesari [1]. Boundedness of solutions of linear differential equations with periodic coefficients. Arch. Rat. Mech. Ana. 1 (1958), 246-271.
- Bancroft, S., J. K. Hale and D. Sweet, [1]. Alternative problems for nonlinear functional equations. J. Diferential Equations 4 (1968), 40-56.
- Bartle, R. G. [1]. Singular points of functional equations. Trans. Am. Math. Soc. 75 (1953), 366-384.
- Bass, R. W. [1]. Equivalent linearization, nonlinear circuit analysis and the stabilization and optimization of control systems. Proc. Symp. Nonlinear Circuit Anal. 6 (1956). [2]. Mathematical legitimacy of equivalent linearization by describing functions. IFAC Congress, 1959.
- Bellman, R. [1]. Stability Theory of Differential Equations, McGraw-Hill, New York, 1953. [2]. Introduction to Matrix Analysis. McGraw-Hill, New York, 1960.
- Bendixson, I. [1]. Sur les courbes defines par des equations differentielles. Acta. Math. 24 (1901), 1-88.
- Birkhoff, G. D. [1]. Dynamical Systems. Am. Math. Soc. Colloq. Publ. New York, 1927. Bogoliubov, N. N. [1]. On some statistical methods in mathematical physics. Akad. Nauk. Ukr. R.S.R. 1945.
- Bogoliubov, N. N. and Y. A. Mitropolskii [1]. Asymptotic Methods in the Theory of Nonlinear Oscillations. Gordon and Breach, New York, 1961. [2]. The method of integral manifolds in nonlinear mechanics. Contributions to Differential Equations 2 (1963), 123-196.
- Bogoliubov, N. N., Jr., and B. I. Sadovnikov [1]. On periodic solutions of differential equations of nth order with a small parameter. Symp. Nonlinear Vibrations, Kiev, USSR, Sept., 1961.
- Borg, G. [1]. On a Liapunov criteria of stability. Am. J. Math. 71 (1949), 67-70.
- Borges, C. [1]. Periodic solutions of nonlinear differential equations: existence and error bounds. Ph.D. dissertation. University of Michigan. 1963.
- Cartwright M., [1]. Forced oscillations in nonlinear systems. Contributions to the Theory of Nonlinear Oscillations, 1 (1950), 149-241, Annals Math. Studies, No. 20, Princeton.
- Cesari, L. [1]. Asymptotic Behavior and Stability Problems. Springer, 1959; Second edition, Academic Press, New York, 1963. [2]. Propriety asintotiche delle equazioni differenziali lineari ordinaire. Rend. Sem. Mat. Roma 3 (1939), 171-193. [3]. Sulla stability. delle soluzioni dei sistemi di equazioni differenziali lineari a coefficienti periodici. Atti Accad. Mem. Classe Fis. Mat. e Nat., (60) 11 (1940), 633-692. [4]. Existence theorems for periodic solutions of nonlinear differential systems. Boletin Soc. Mat. Mexicana 1960,24-41.[5]. Functional analysis and periodic solutions of nonlinear differential equations. Contr. Diff. Equations 1 (1963), 149-167. [6]. Functional analysis and Galerkin's method. Michigan Math. J., 11 (1964), 385-414. [7]. Existence in the large of periodic solutions of hyperbolic partial differential equations. Arch. Rat. Mech. Anal. 20, (1965), 170-190. [8]. A nonlinear problem in potential theory. Michigan Math. J., 1969.
- Cesari, L. and J. K. Hale [1]. A new sufficient condition for periodic solutions of weakly differential systems. Proc. Am. Math. Soc. 8 (1957), 757-764.
- Cetaev, N. G. [1]. Un theorbme sur l'instabilite. Dokl. Akad. Nauk SSSR 2 (1934), 529-534.
- Chafee, N. [1]. The bifurcation of one or more closed orbits from an equilibrium point of an autonomous differential system. J. Differential Equations, 4 (1968), 661-679.
- Chen, K. T. [1]. Equivalence and decomposition of vector fieius about an elementary critical point. Amer. J. Math. 85 (1963), 693-722.

- Coddington, E. A. and N. Levinson [1]. Theory of Ordinary Differential Equations. McGraw-Hill, New York, 1955.
- Conley, C. [11, Isolated invariant sets and the Morse index. CBMS number 38, Am. Math. Soc., Providence, it I.
- Coppel, W. A. [1] Stability and Asymptotic Behavior of Differential Equations. Heath Mathematical Monographs, 1965.
- Coppel, W. A. and A. Howe [1]. On the stability of linear canonical systems with periodic coefficients. J. Austral. Math. Soc. 5 (1965), 169-195. [2]. Corrigendum: On the stability of linear canonical systems with periodic coefficients. J. Austral. Math. Soc. 6 (1966), 256.
- Coppel, W. A. and K. J. Palmer [1], Averaging and integral manifolds. Bull. Australian Math. Soc. 2(1970), 197-222.
- Cronin, J. [1]. Branch points of solutions of equations in a Banach space. Trans. Am. Math. Soc. 69 (1950), 208-231.
- Cruz, M. A. and J. K. Hale [1]. Stability of functional differential equations of neutral type. J. Differential Equations. 7(1970), 334-355.
- Denjoy, A. [1]. Sur les courbes definies par les equations differentielles a la surface du tore. J. de Math. 11 (1932), 333-375.
- Diliberto, S. P. [1]. Perturbation theorems for periodic surfaces. I, II. Rend. Circ. Mat. Palermo 9 (2) 1960, 265-299; 10 (2)(1961), 11]. [2]. On stability of linear mechanical systems. Proc. Internat. Sympos. Nonlinear Vibrations. Izdat. Akad. Nauk Ukrain. SSR, Kiev. 1, 1963, pp. 189-203. . New results on periodic surfaces and the averaging principle. U.S.-Japanese Seminar on Differential and Functional Equations, pp. 49-87. W. A. Benjamin, 1967.
- Fillipov, A. F. [1]. Differential equations with discontinuous right hand side. Mat. Sbornik (N.S.) 51 (1960), 99-128.
- Flugge-Lotz, I. [1]. Discontinuous automatic control. Princeton, 1953.
- Friedrichs, K. [1]. Special Topics in Analysis. Lecture Notes, New York University, 1953-1954. [1]. Advanced Ordinary Differential Equations. Lecture Notes, New York University, 1956.
- Gambill, R. A. and J. K. Hale [1]. Subharmonic and ultraharmonic solutions of weakly nonlinear systems. J. Rat. Mech. Ana. 5 (1956), 353-398.
- Golomb, M. [1]. Expansion and boundedness theorems for solutions of linear differential equations with periodic or almost periodic coefficients. Arch. Rat. Mech. Ana. 2 (1958), 284-308.
- Gottschalk, W. H. and G. A. Hedlund [1]. Topological dynamics. Amer. Math. Soc. Colloq. Publ. 36 (1955).
- Graves, L. M. [1]. Remarks on singular points of functional equations. Trans. Am. Math. Soc. 79 (1955), 150-157.
- Hahn, W. [1]. Theory and Application of Lyapunov's Direct Method. Prentice-Hall, New York, 1963. [2]. Stability of Motion, Springer-Verlag, New York, 1967.
- Halanay, A. [1]. Differential Equations-Stability, Oscillation, Time Lags. Academic Press, New York, 1966.
- Hale, J. K. [1]. Periodic solutions of nonlinear systems of differential equations. Riv. Mat. Univ. Parma 5 (1954), 281-311. [2], Sufficient conditions for the existence of periodic solutions of first and second order differential equations. J. Math. Mech. 7 (1958), 163-172. [3]. Integral manifolds of perturbed differential systems. Ann. Math. 73 (1961), 496-531. [4]. On differential equations containing a small parameter. Contr. Diff. Equations. 1 (1962) [5]. Asymptotic behavior of the solutions of differential difference equations. Proc. Intern. Symp. Nonlinear Oscillations, Kiev. Sept. 1961, 11 (1963), 409-426. [6]. On the behavior of solutions of linear differential

- equations near resonance points. Contr. Theory Nonlinear Oscillations 5 (1960). [7]. Oscillations in Nonlinear Systems. McGraw-Hill, New York, 1963. [8]. Sufficient conditions for stability and instability of autonomous functional differential equations. J. Diff. Equations 1 (1965), 452-482. [9]. Periodic solutions of a class of hyperbolic equations containing a small parameter. Arch. Rat. Mech. Anal. 23 (1967), 380-398. [10], Theory of Functional Differential Equations. Appl. Math. Sciences, Vol. 3, Springer-Verlag, 1977. [11], Bifurcation near families of solutions. Pros Int. Conf. Diff. Eqns., Uppsala (1977).
- Hale, J. K. and A. Stokes [1]. Behavior of solutions near integral manifolds. Arch. Rat. Mech. Ana. 6 (1960), 133-170.
- Hale, J. K. and H. M. Rodriques [1], Bifurcation in the Duffing equation with independent parameters, I. Proc. Royal Soc. Edinburgh, 78A(1977), 56-65; [2] H. Ibid 79A(1977), 317-322.
- Hale, J. K. and P. Z. Tiboas [1], Interaction of damping and forcing in a second order equation. Nonlinear Analysis, 2(1978), 77-84; [2] Bifurcation near degenerate families, Applicable Analysis. To appear.
- Hall, W. S. [1]. Periodic solutions of a class of weakly nonlinear evolution equations. Ph.D. Thesis. Brown University, June, 1968.
- Harris, W. A., Jr., Y. Sibuya, and L. Weinberg [1]. Holomorphic solutions of linear differential systems at singular points. To appear.
- Hartman, P. [1]. Ordinary Differential Equations, Wiley, New York, 1964. [2]. On stability in the large for systems of ordinary differential equations. Canad. J. Math. 13 (1961), 480-492.
- Henry, D. [1] , Geometric Theory of Semilinear Parabolic Equations, Springer-Verlag,'1980. Hopf, E. [I I, Abzweigeneiner periodischen Losung von einer stationaren Losung eines Differentialsystems. Bench. Math. Phys. Sachlischen Akad. Wursenchaften Leipzig 94(1942), 3-22.
- Howe, A. [1]. Linear canonical systems with periodic coefficients. Ph.D. Dissertation, University of Canberra, Australia, 1967.
- Infante, E. F. and M. Slemrod [1]. An invariance principle for dynamical systems on Banach spaces, Proc. I UTAM Symp. on Stability Springer, 1970.
- Kelley, A. [1]. The stable, center-stable, center, center-unstable, unstable manifolds. J. Differential Equations, 3 (1967), 546-570.
- Knobloch, H. W. [1]. Remarks on a paper of Cesari on functional analysis and nonlinear differential equations. Michigan Math. J. 10 (1963), 417-430. [2]. Comparison theorems for nonlinear second order differential equations. J. Diff. Equations 1 (1965), 1-25.
- Kolmogorov, A. N. (1]. Thgorie des systbmes dynamiques et mecanique classique. Proc. Int. Cong. Math. 1954, 1, 315-333. Noordhoff, 1957.
- Krasovskii, N. N. [1]. Stability of Motion. Stanford University Press, 1963.
- Krein, M. G. [1]. The basic propositions in the theory of A-zones of stability of a canonical system of linear differential equations with periodic coefficients (Russian), Pamyati A. A. Andronova, Izdat. Akad. Nauk. SSSR, Moscow, 1955, pp. 413-498.
- Krylov, N. and N. N. Bogoliubov [1]. The application of methods of nonlinear mechanics ,to the theory of stationary oscillations. Publication 8 of the Ukrainian Academy of Science, Kiev, 1934. [2]. Introduction to nonlinear mechanics, Annals Math..Studie8, No. 11, Princeton University Press, Princeton, N.J., 1947.
- Kruzweil, J. [1]. Invariant manifolds for flows, Proc. Sym. DifJ'. Equations and Dynamical Systems. Academic Press, New York, 1967. [2]. The averaging principle in certain special cases of boundary problems for partial differential equations. Casopis Pest.

- Mat. 88 (1963), 444-456. [3]. van der Pol perturbation of the equation for a vibrating string. Czechoslovak Math. J. 17 (92) (1967), 558-608.
- Kyner, W. T. [1]. Invariant manifolds, Rend. Circ. Mat. Palermo, 10 (2) (1961), 98-110. Laksmikantham, V. and S. Leela [1]. Differential Inequalities. Academic Press, New York, 1969.
- Laloy, M. [11, On the inversion of Lagrange-Dirichlet theorem in the case of an analytic potential. Rpt. 107, December 1977, Louvain-la-Neuve.
- LaSalle, J. P. [1], Relaxation oscillations. Quart. Appl. Math. 7 (1949), 1-19. [2]. An invariance principle in the theory of stability. Int. Symp. on Diff. Eqs. and Dyn. Sys., p. 277, Academic Press, New York, 1967.
- LaSalle, J. P. and S. Lefschetz [1]. Stability by Liapunov's Direct Method. Academic Press, New York, 1961.
- Lee, B. and L. Markus [1]. Optimal Control Theory. Wiley, New York, 1967.
- Lefschetz, S. [1]. Differential Equations; Geometric Theory. Second Edition. Interscience, New York, 1959. [2]. Stability of Nonlinear Control Systems. Academic Press, New York, 1965.
- Levinson, N. [1]. Transformation theory of nonlinear differential equations of the second order. Ann. Math. 45 (1944), 723-737. [2]. Small periodic perturbations of an autonomous system with a stable orbit. Ann. Math. 52 (1950), 727-738.
- Lewis, D. C. [1]. On the role of first integrals in the perturbation of periodic solutions. Ann. Math. 63 (1956),535-548.[2]. Autosynartetic solutions of differential equations. Am. J. Math. 83 (1961), 1-32.
- Liapunoff, A. [1]. Probleme General de la Stability du Mouvement. Annals Math. Studies, No. 17, Princeton University Press. 1949.
- Lillo, J. C. [1]. A note on the continuity of characteristic exponents. Proc. Nat. Acad. Sci. U.S.A. 46 (1960), 247-250.
- Locker, J. S. [1]. An existence analysis for nonlinear equations in a Hilbert space. Trans. Am. Math. Soc. 128 (1967), 403-413.
- Lykova, O. B. [1]. Investigation of the solution of a system of differential equations with a small parameter on a two-dimension local integral manifold in the resonance case. Ukrain. Mat. Z. 10 (1958), 365-374.
- Loud, W. [1]. Periodic solutions of x" + cx' + g(x) = Ef (t). Mem. Am. Math. Soc.. No. 31, 1959, 58 pp. [2J, Branching of solutions of two-parameter boundary value problems for second order differential equations. Ingenieur-Archiv 45(1976), 347-359. Magnus, W. and S. Winkler [1]. Hill's Equation. Interscience, New York, 1966.
- ,Malkin, J. G. [1]. Theory of Stability of Motion. AEC-tr-3352. [2]. Some Problems in the
- Theory of Nonlinear Oscillations. Moscow, 1956.
- Markus, L. [1]. Asymptotically autonomous differential systems. Contr. Theory Nonlinear Oscillations, 3 (1956),-17-29.
- Markus, L. and H. Yamabe [1]. Global stability criteria for differential systems. Osaka Math. J. 12 (1960), 305-317.
- Marsden, J. E. and M. McCracken [ 1 ] , The Hopf Bifurcation and its Applications. Springer-Verlag, 1976.
- Massera, J. L. [1]. Contributions to stability theory. Ann. Math. 64 (1956), 182- 206.
- Massera, J. L. and J. J. Sehaffer [1]. Linear Differential Equations and Function Spaces. Academic Press, New York, 1966.
- McCarthy, J. [1]. The stability of invariant manifolds, I, Stanford University, Appl. Math. Stat. Lab., ONR Tech. Rep. 36, 1956.

- McGarvey, D. [1]. Linear differential systems with periodic coefficients involving <sup>i</sup> large parameter. J. Differential Equations. 2 (1966), 115-142.
- McLachlan, N. W. [1]. Theory and Application of Mathieu Functions. The Clarendoi Press, Oxford, 1947.
- Minorsky, N. [1]. Nonlinear Oscillations. van Nostrand, Princeton, N.J., 1962.
- Minorsky, N. [2], Introduction to Nonlinear Mechanics, J. W. Edwards, Publisher, An Arbor, 1947.
- Mishchenko, Z. and L. S. Pontrjagin [1]. Differential equations with a small paramete attached to the higher derivatives and some problems in the theory of oscillation IRE Trans. CT-7 (1960), 527-535.
- Mitropolski, Y. A. [1]. Probleme8 de la thcorie asymptotique des oscillations non 8tationaire4 Gauthier-Villars, Paris, 1966.
- Montandon, B. [ 1 I, Almost periodic solutions and integral manifolds for weakly nonlines nonconservative systems. J. Differential Eqns. 12(1972).'417-425.
- Morrison, J. A. [1]. An averaging scheme for some nonlinear resonance problems. SIA3. J. Appl. Math. 16 (1968), 1024-1047.
- Moser, J. [1]. On invariant curves of area-preserving mappings of an annulus. Nachi Akad. Wise. Gottingen Math.-Phys. Kl. II 1962, 1-20. [2]. Bistable systems c
  - differential equations with applications to tunnel diode circuits. IBM J. Rea Develop. 5 (1961), 226-240. [3], Stable and Random Motions in Dynamical System Princeton University Press. 1973.
- Nemitskii, V. V. and V. V. Stepanov [1]. Qualitative Theory of Differential Equation. Princeton University Press, 1960.
- Newhouse, S. [11, Lectures on Dynamic Systems. CIME, Summer Session on Dynamics Systems, June, 1978.
- Nirenberg, L. [1]. Functional Analysis. Lecture Notes, New York University, 1960-1961 Nitecki, Z. U11, Differentiable Dynamics. M.I.T. Press, Cambridge, Mass., 1971.
- Olech, C. [1]. On global stability of an autonomous system on the plane. Contribution to Differential Equations 1 (1963), 389-400.
- Onuchic, N. [I I, Applications of the topological method of Wa'cewski to certain problem of asymptotic behavior in ordinary differential equations. Pacific J. Math. 11(1961) 1511-1527; [2] On the asymptotic behavior of the solutions of functional differentia equations, pp. 223-233 in Differential Equations and Dynamical Systems. Ed. J. 1{ Hale and J. P. LaSalle, Academic Press. 1967.
- Opial, Z. [1]. Sur Is, dgpendance des solutions d'un systbme d'equations diffirentielle de leurs seconds membres. Applications aux systhmes presques autonomes. Anr Polon. Math. 8 (1960), 75-89.
- Palamadov, V. P. [1], Stability of equilibrium in a potential field. Functional Analysis an its Applications (1978), 277-289.
- Palmore, J. [ 1 ] , Instability of equilibria, Preprint.
- Peixoto, M. [1]. Structural stability on two-dimensional manifolds. Topology 1 (1962) 101-120.
- Perello, C. [1]. Periodic solutions of differential equations with time lag containing, small parameter. J. Diff. Equations. 4(1968), 160-175 [2]. A note on periodic solutior of nonlinear differential equations with time lags, Differential Equations and Dynamic Systems.' Academic Press, 1967, 185-188.
- Perron, O. [1]. Die Stabilithtsfrage bei Differentialgleichungssysteme.. Math. Zeit. 3; (1930), 703-728.
- Plies, V. A. [1]. On the theory of invariant surfaces. Differentialniye Uravnaniya 2 (1966) 1139-1150. [2]. Nonlocal Problems of the Theory of Oscillations. Academic Press New York, 1966.

- Poincare, H. [1]. Sur les courbes defines par les equations differentielles. J. de Math., (3) 7 (1881), 375-422; (3) 8 (1882), 251-296; (4) 1 (1885), 167-244; (4) 2 (1886), 151-217. [2]. Les methodes nouvelles de la mecanique eeleste. Paris, 3 vols., 1892, 1893, 1899.
- Rabinowitz, P. H. [1]. Periodic solutions of a nonlinear wave equation. Comm. Pure Appl. Math. 20 (1967), 145-205.
- Reuter, G. E. H. [1]. Subharmonics in a nonlinear system with unsymmetric restoring forces. Quart. J. Mech. Appl. Math. 2 (1949), 198-207.
- Rouche, N. Habets, P. and M. LaLoy [1], Stability Theory by Liapunov's Direct Method. Appl. Math. Sci. Vol. 22, 1977, Springer-Verlag.
- Sacker, R. J. [1]. A new approach to the perturbation theory of invariant surfaces. Comm. Pure Math. 18 (1965), 717-732.
- Sansone, G. and R. Conti [1]. Nonlinear Differential Equations, Pergamon Press, New York, 1964.
- Schwartz, A. J. [1]. A generalization of a Poincare-Bendixson theorem to closed twodimensional manifolds. Am. J. Math. 85 (1963), 453-458; errata, ibid, 85 (1963), 753.
- Sethna, P. R. [1]. An extension of the method of averaging. Quart. Appl. Math. 25 (1967), 205-211.
- Siegel, C. L. and J. K. Moser [1], Lectures on Celestial Mechanics, Grundlehren, Vol. 187, Springer, 1971.
- Smale, S. [1]. Differentiable dynamical systems. Bull. Amer. Math.Soe.73 (1967),747-817. Sotomayor, J. [11, Generic one parameter families of vector fields, Publ. Math. IHES, 43(1973), 5-46.
- Sternberg, S. [1]. Local contractions and a theorem of Poincare. Am. J. Math. 79 (1957), 809-824. [2]. On the structure of local homeomorphisms of euclidean n-space, II. Am. J. Math. 80 (1958), 623-631. [3]. III, Ibid, 81 (1959), 578-604.
- Szarski, J. [1]. Differential Inequalities. Warszawa, 1965.
- Urabe, M. [1]. Nonlinear Autonomous Oscillations. Academic Press, New York, 1967. [2]. Galerkin's procedure for nonlinear periodic systems and its extension to multipoint boundary value problems for general nonlinear systems. Numerical Solutions of Nonlinear Differential Equations (Proc. Adv. Sympos. Madison, Wis., 1966), pp. 297-327. Wiley, New York, 1966.
- Vainberg, M. M. and V. A. Tregonin [1]. The methods of Lyapunov and Schmidt in the theory of nonlinear differential equations and their further development. Mathematical Surveys, 17 (1962), 1-60.
- van der Pol, B. [1]. Forced oscillations in a circuit with nonlinear resistance. Phil. Mag. 3 (1927), 65-80; Proc. Inst. Radio Eng. 22 (1934), 1051-1086.
- Wasow, W. [1]. Asymptotic Expansions of Ordinary Differential Equations. Interscience, New York, 1965.
- Wafewski, T. [1], Sur un principe topologique de 1'examen de !'allure asymptotique des integrates des equations differentielles ordinaires. Ann. Soc. Polon. Mat. 29(1947), 279-313.
- Williams, S. [1]. A connection between the Cesari and Leray-Schauder methods. Michigan Math. J., 1969.
- Yakubovich, V. A. [1]. Structure of the group of symplectic matrices and the unstable canonical systems with periodic coefficients. Mat. Sbornik N.S. 44 (86) (1958), 313-352. [2]. Critical frequencies of quasi-canonical systems. Vestnik Leningrad Univ. 13 (1958), 35-63.
- Yoshizawa, T. [1]. Asymptotic behavior of solutions of a system of differential equations. Contributions to Differential Equations 1 (1963), 371-387. [2]. Stability Theory of Liapunov's Second Method. Mathematical Society of Japan, 1966.

Yoshizawa, T. and J. Kato [1]. Asymptotic Behavior of Solutions near Integral Manifolds. Equations and Dynamical Systems, J. K. Hale and J. P. LaSalle, Eds., Academic Press, New York, 1967, pp. 267-275.

Zubov, V. I. [1]. Methods of A. M. Lyapunov and their Applications. Noordhoff. 1964.

## Index

| Admissible, definition of, 154<br>strongly, 171<br>Almost periodic function, 339<br>e-translation set, 342<br>hull of, 341<br>module of an, 345<br>uniformly in x, 348<br>Alternative problem, 298, 304<br>Arc, 39<br>Averaging, method of, 175, 190, 252 | Equation, adjoint, 80, 92<br>autonomour, 37<br>Duffing, 168, 199, 206, 287<br>Hill, 131<br>linear variational, 21<br>van der Pol, 60, 198, 254, 263<br>Equations, bifurcation, 258, 261, 269<br>determining, 258, 261, 269<br>Ergodic flow, 71, 72<br>Esadi diode, 300 |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|                                                                                                                                                                                                                                                           | First integrals, 283                                                                                                                                                                                                                                                   |
| Bifurcation,                                                                                                                                                                                                                                              | Fixed point theorem, Brouwer, 10                                                                                                                                                                                                                                       |
| equation, 258, 261, 269                                                                                                                                                                                                                                   | contraction, 5                                                                                                                                                                                                                                                         |
| generie, 273, 274                                                                                                                                                                                                                                         | Schauder, 10                                                                                                                                                                                                                                                           |
| Hopf, 270                                                                                                                                                                                                                                                 | Tychonov,11                                                                                                                                                                                                                                                            |
| several parameter, 268, 274, 287, 290                                                                                                                                                                                                                     | Floquet representation, 118                                                                                                                                                                                                                                            |
|                                                                                                                                                                                                                                                           | Focus, 42, 104                                                                                                                                                                                                                                                         |
| Canonical systems, 133, 136                                                                                                                                                                                                                               | Fourier, coefficients, 345                                                                                                                                                                                                                                             |
| Caratheodory conditions, 28                                                                                                                                                                                                                               | exponents, 345                                                                                                                                                                                                                                                         |
| Cauchy sequence, 1                                                                                                                                                                                                                                        | series, 345                                                                                                                                                                                                                                                            |
| Center, 40, 103                                                                                                                                                                                                                                           | Fredholm's alternative, 146                                                                                                                                                                                                                                            |
| Characteristic exponents, 119                                                                                                                                                                                                                             | Frequency response curve, 201                                                                                                                                                                                                                                          |
| multipliers, 119                                                                                                                                                                                                                                          | Function, Liapunov, 316, 325                                                                                                                                                                                                                                           |
| number, 142                                                                                                                                                                                                                                               | negative definite, 311                                                                                                                                                                                                                                                 |
| Conservative, 176                                                                                                                                                                                                                                         | positive definite, 311                                                                                                                                                                                                                                                 |
| Continuity in parameters,                                                                                                                                                                                                                                 | Fundamental matrix, 80                                                                                                                                                                                                                                                 |
| of fixed points, 7, 8                                                                                                                                                                                                                                     |                                                                                                                                                                                                                                                                        |
| of solutions, 20                                                                                                                                                                                                                                          | Galerkin approximation, 307                                                                                                                                                                                                                                            |
| Contraction mapping principle, 5                                                                                                                                                                                                                          | Green's function, 148                                                                                                                                                                                                                                                  |
| Converse theorems of Liapunov, 327                                                                                                                                                                                                                        |                                                                                                                                                                                                                                                                        |
| Critical point, 38                                                                                                                                                                                                                                        | Hamiltonian systems, 133                                                                                                                                                                                                                                               |
| Curve, 38                                                                                                                                                                                                                                                 | Harmonic forcing, 199                                                                                                                                                                                                                                                  |
|                                                                                                                                                                                                                                                           | Hill's equation, 121                                                                                                                                                                                                                                                   |
| Derivative, Frechet, 6                                                                                                                                                                                                                                    | Homeomorphism, 3                                                                                                                                                                                                                                                       |
| Differentiability in parameters,<br>of fixed points, 8                                                                                                                                                                                                    | Hopf bifurcation, 270                                                                                                                                                                                                                                                  |
| of solutions, 21, 22                                                                                                                                                                                                                                      | Implicit function theorem, 8                                                                                                                                                                                                                                           |
| Duffing equation, 168, 199, 206, 287                                                                                                                                                                                                                      | Inequality, differential, 30                                                                                                                                                                                                                                           |
| Dynamical system, 50                                                                                                                                                                                                                                      | Gronwall, 36                                                                                                                                                                                                                                                           |
|                                                                                                                                                                                                                                                           | Instability, definition of, 26                                                                                                                                                                                                                                         |
| Eigenspace, generalized, 96                                                                                                                                                                                                                               | criteria for, 116, 317                                                                                                                                                                                                                                                 |
| Entrainment of frequency, 203                                                                                                                                                                                                                             | in conservative systems, 177                                                                                                                                                                                                                                           |
|                                                                                                                                                                                                                                                           |                                                                                                                                                                                                                                                                        |

open, 43

| Integrals, 176, 283                       | Path ring, 45                             |
|-------------------------------------------|-------------------------------------------|
| linearly independent, 285                 | Pendulum, conservative, 180               |
| Invariant set, 47                         | with oscillating support, 208             |
|                                           | period, 180                               |
| Jordan canonical form, 99                 | Period in planar systems, 180             |
| Hordan curve, 39                          | Periodic orbit, definition of, 39         |
| theorem, 52                               | stability of, 221, 224                    |
| J-unitary, 134                            | perturbation of, 226, 229                 |
|                                           | Point, critical, 38                       |
| Limit cycle, 42, 54, 57                   | equilibrium, 38                           |
| Limit set, 47                             | regular, 38                               |
| Linear systems, autonomous, 93            | singular, 38                              |
| general, 79                               | Principal matrix, 80                      |
| noncritical, 144                          | Property (E), 280                         |
| nonhomogeneous, 145                       |                                           |
| periodic, 117                             | Quasiperiodic function, 345               |
| stability of, 83                          |                                           |
| Linearly independent, functions, 90       | Reciprocal systems, 131                   |
| subspaces, 96                             | Regular point, 38                         |
| Lip (n), 111                              | Rotation number, 66                       |
| Lip (n,M), 154                            |                                           |
|                                           | Saddle point, two dimensions, 102         |
| Manifold, integral, 230                   | of type (k), 106, 107                     |
| stable, 107, 108, 159                     | Scalar equation, 12                       |
| unstable, 107, 108, 159                   | Secular term, 184                         |
| Mapping, bounded linear, 3<br>compact, 10 | Set, bounded, 2                           |
| completely continuous, 10                 | compact, 2                                |
| contraction, 5                            | convex, 10                                |
| domain of, 3                              | invariant, 47                             |
| linear, 3                                 | minimal, 48                               |
| range of, 3                               | a-limit, 47                               |
| uniform contraction, 6                    | w-limit, 47<br>Singular perturbation, 166 |
| Monodromy matrix, 119                     | Singular point, 38                        |
| Moving orthonormal coordinates, 214       | Solution, definition of, 12               |
| Multiple periodic function, 350           | continuation of, 16                       |
|                                           | domain of definition, 18                  |
| Node, 101, 102                            | existence of, 14                          |
| Nonconservative, 184                      | fundamental matrix, 80                    |
| Noncritical system, 144                   | general, 25                               |
| Norm, vector, 1                           | orbit of, 37                              |
| linear mapping, 3                         | path of, 37                               |
|                                           | principal matrix, 80                      |
| Oribt, definition of, 37                  | trajectory of, 18                         |
| Orbital stability, definition of, 221     | uniqueness of, 18                         |
| conditions for, 22,1, 224                 | Space, Banach, I                          |
|                                           | complete, 1                               |
| Path, 37                                  | c, (D,Rn), 2                              |
| Path cyliner, 43                          | normed linear, 1                          |
| dosed, 44                                 | phase, 37                                 |
|                                           |                                           |

state, 37

INDEX 361

Stability, exponential, 84 of invariant set, 54, 221, 240 of solution, 26 orbital, 221 under constant disturbances, 333 Stable on 132 strongly, 132 Structurally stable, 143 Subharmonic, 206

Torus, existence of, 231, 237 flow on, 70, 74

invariant, 250, 253 ff. Trajectory, 18 Transformation, of van der Pol, 198 Transversal, 43, 52

Uniform boundedness, principle of, 4

Van der Pol equation, 60, 198, 254, 263 Variation of constants formula, 81

Wazewski, principle of, 335 Wronskian, 90